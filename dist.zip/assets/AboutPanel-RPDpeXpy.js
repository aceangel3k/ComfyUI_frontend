var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
import { q as script, ac as script$1, G as script$2, w as script$3 } from "./vendor-primevue-Ch6rhmJJ.js";
import { dj as formatSize, Z as useExtensionStore, bj as useSystemStatsStore, $ as useExternalLink, dk as formatCommitHash, a5 as isElectron, bm as electronAPI, dl as _sfc_main$3 } from "./index-45IpBQOM.js";
import { bq as defineComponent, c as createElementBlock, d as openBlock, F as Fragment, y as renderList, e as createBaseVNode, u as toDisplayString, E as computed, q as createCommentVNode, z as createVNode, br as unref, j as createBlock, k as withCtx, A as createTextVNode, s as normalizeClass } from "./vendor-other-CzYzbUcM.js";
import { d as defineStore } from "./vendor-vue-DLbRHZS7.js";
import "./vendor-xterm-BF8peZ5_.js";
import "./vendor-three-DYL0ZbEr.js";
import "./vendor-tiptap-XfQ74oRB.js";
const _hoisted_1$2 = { class: "grid grid-cols-2 gap-2" };
const _hoisted_2$2 = { class: "font-medium" };
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "DeviceInfo",
  props: {
    device: {}
  },
  setup(__props) {
    const props = __props;
    const deviceColumns = [
      { field: "name", header: "Name" },
      { field: "type", header: "Type" },
      { field: "vram_total", header: "VRAM Total" },
      { field: "vram_free", header: "VRAM Free" },
      { field: "torch_vram_total", header: "Torch VRAM Total" },
      { field: "torch_vram_free", header: "Torch VRAM Free" }
    ];
    const formatValue = /* @__PURE__ */ __name((value, field) => {
      if (["vram_total", "vram_free", "torch_vram_total", "torch_vram_free"].includes(
        field
      )) {
        return formatSize(value);
      }
      return value;
    }, "formatValue");
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$2, [
        (openBlock(), createElementBlock(Fragment, null, renderList(deviceColumns, (col) => {
          return openBlock(), createElementBlock(Fragment, {
            key: col.field
          }, [
            createBaseVNode("div", _hoisted_2$2, toDisplayString(col.header), 1),
            createBaseVNode("div", null, toDisplayString(formatValue(props.device[col.field], col.field)), 1)
          ], 64);
        }), 64))
      ]);
    };
  }
});
const _hoisted_1$1 = { class: "system-stats" };
const _hoisted_2$1 = { class: "mb-6" };
const _hoisted_3$1 = { class: "mb-4 text-2xl font-semibold" };
const _hoisted_4 = { class: "grid grid-cols-2 gap-2" };
const _hoisted_5 = { class: "font-medium" };
const _hoisted_6 = { class: "mb-4 text-2xl font-semibold" };
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "SystemStatsPanel",
  props: {
    stats: {}
  },
  setup(__props) {
    const props = __props;
    const systemInfo = computed(() => ({
      ...props.stats.system,
      argv: props.stats.system.argv.join(" ")
    }));
    const hasDevices = computed(() => props.stats.devices.length > 0);
    const localColumns = [
      { field: "os", header: "OS" },
      { field: "python_version", header: "Python Version" },
      { field: "embedded_python", header: "Embedded Python" },
      { field: "pytorch_version", header: "Pytorch Version" },
      { field: "argv", header: "Arguments" },
      { field: "ram_total", header: "RAM Total", formatNumber: formatSize },
      { field: "ram_free", header: "RAM Free", formatNumber: formatSize }
    ];
    const systemColumns = computed(() => localColumns);
    const getDisplayValue = /* @__PURE__ */ __name((column) => {
      const value = systemInfo.value[column.field];
      if (column.formatNumber && typeof value === "number") {
        return column.formatNumber(value);
      }
      if (column.format && typeof value === "string") {
        return column.format(value);
      }
      return value;
    }, "getDisplayValue");
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$1, [
        createBaseVNode("div", _hoisted_2$1, [
          createBaseVNode("h2", _hoisted_3$1, toDisplayString(_ctx.$t("g.systemInfo")), 1),
          createBaseVNode("div", _hoisted_4, [
            (openBlock(true), createElementBlock(Fragment, null, renderList(systemColumns.value, (col) => {
              return openBlock(), createElementBlock(Fragment, {
                key: col.field
              }, [
                createBaseVNode("div", _hoisted_5, toDisplayString(col.header), 1),
                createBaseVNode("div", null, toDisplayString(getDisplayValue(col)), 1)
              ], 64);
            }), 128))
          ])
        ]),
        hasDevices.value ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [
          createVNode(unref(script)),
          createBaseVNode("div", null, [
            createBaseVNode("h2", _hoisted_6, toDisplayString(_ctx.$t("g.devices")), 1),
            props.stats.devices.length > 1 ? (openBlock(), createBlock(unref(script$1), { key: 0 }, {
              default: withCtx(() => [
                (openBlock(true), createElementBlock(Fragment, null, renderList(props.stats.devices, (device) => {
                  return openBlock(), createBlock(unref(script$2), {
                    key: device.index,
                    header: device.name,
                    value: device.index
                  }, {
                    default: withCtx(() => [
                      createVNode(_sfc_main$2, { device }, null, 8, ["device"])
                    ]),
                    _: 2
                  }, 1032, ["header", "value"]);
                }), 128))
              ]),
              _: 1
            })) : (openBlock(), createBlock(_sfc_main$2, {
              key: 1,
              device: props.stats.devices[0]
            }, null, 8, ["device"]))
          ])
        ], 64)) : createCommentVNode("", true)
      ]);
    };
  }
});
const useAboutPanelStore = defineStore("aboutPanel", () => {
  const frontendVersion = "1.37.2";
  const extensionStore = useExtensionStore();
  const systemStatsStore = useSystemStatsStore();
  const { staticUrls } = useExternalLink();
  const coreVersion = computed(
    () => systemStatsStore?.systemStats?.system?.comfyui_version ?? ""
  );
  const coreBadges = computed(() => [
    // In electron, the ComfyUI is packaged without the git repo,
    // so the python server's API doesn't have the version info.
    {
      label: `ComfyUI ${isElectron() ? "v" + electronAPI().getComfyUIVersion() : formatCommitHash(coreVersion.value)}`,
      url: staticUrls.github,
      icon: "pi pi-github"
    },
    {
      label: `ComfyUI_frontend v${frontendVersion}`,
      url: staticUrls.githubFrontend,
      icon: "pi pi-github"
    },
    {
      label: "Discord",
      url: staticUrls.discord,
      icon: "pi pi-discord"
    },
    { label: "ComfyOrg", url: staticUrls.comfyOrg, icon: "pi pi-globe" }
  ]);
  const allBadges = computed(() => [
    ...coreBadges.value,
    ...extensionStore.extensions.flatMap((e) => e.aboutPageBadges ?? [])
  ]);
  return {
    badges: allBadges
  };
});
const _hoisted_1 = { class: "mb-2 text-2xl font-bold" };
const _hoisted_2 = { class: "space-y-2" };
const _hoisted_3 = ["href", "title"];
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "AboutPanel",
  setup(__props) {
    const systemStatsStore = useSystemStatsStore();
    const aboutPanelStore = useAboutPanelStore();
    return (_ctx, _cache) => {
      return openBlock(), createBlock(_sfc_main$3, {
        value: "About",
        class: "about-container"
      }, {
        default: withCtx(() => [
          createBaseVNode("h2", _hoisted_1, toDisplayString(_ctx.$t("g.about")), 1),
          createBaseVNode("div", _hoisted_2, [
            (openBlock(true), createElementBlock(Fragment, null, renderList(unref(aboutPanelStore).badges, (badge) => {
              return openBlock(), createElementBlock("a", {
                key: badge.url,
                href: badge.url,
                target: "_blank",
                rel: "noopener noreferrer",
                class: "about-badge inline-flex items-center no-underline",
                title: badge.url
              }, [
                createVNode(unref(script$3), { class: "mr-2" }, {
                  icon: withCtx(() => [
                    createBaseVNode("i", {
                      class: normalizeClass([badge.icon, "mr-2 text-xl"])
                    }, null, 2)
                  ]),
                  default: withCtx(() => [
                    createTextVNode(" " + toDisplayString(badge.label), 1)
                  ]),
                  _: 2
                }, 1024)
              ], 8, _hoisted_3);
            }), 128))
          ]),
          createVNode(unref(script)),
          unref(systemStatsStore).systemStats ? (openBlock(), createBlock(_sfc_main$1, {
            key: 0,
            stats: unref(systemStatsStore).systemStats
          }, null, 8, ["stats"])) : createCommentVNode("", true)
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default
};
//# sourceMappingURL=AboutPanel-RPDpeXpy.js.map
