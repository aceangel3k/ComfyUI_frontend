var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
import { s as storeToRefs, u as useI18n } from "./vendor-vue-DLbRHZS7.js";
import { J as script, ag as script$1 } from "./vendor-primevue-Ch6rhmJJ.js";
import { cn as useQueueSettingsStore, e as useSettingStore, d as _export_sfc, p as useWorkspaceStore, C as useNodeDefStore, q as app, z as useCommandStore, _ as _sfc_main$2 } from "./index-c_wVuoti.js";
import { g as graphHasMissingNodes } from "./GraphView-BC5c1aRS.js";
import { bq as defineComponent, E as computed, h as resolveDirective, l as withDirectives, c as createElementBlock, d as openBlock, z as createVNode, br as unref, b9 as isRef, j as createBlock, k as withCtx, q as createCommentVNode, A as createTextVNode, s as normalizeClass, u as toDisplayString, e as createBaseVNode } from "./vendor-other-CzYzbUcM.js";
import "./vendor-xterm-BF8peZ5_.js";
import "./vendor-three-DYL0ZbEr.js";
import "./vendor-tiptap-XfQ74oRB.js";
import "./UserAvatar.vue_vue_type_script_setup_true_lang-DV-9JnFV.js";
import "./index-CaAGXb7g.js";
import "./LazyImage.vue_vue_type_script_setup_true_lang-CWYH5qfm.js";
import "./keybindingService-BgTCe_lY.js";
import "./serverConfigStore-CulKZi3K.js";
import "./WidgetInputNumber.vue_vue_type_script_setup_true_lang-cU9n3YQI.js";
import "./widgetPropFilter-BIbGSUAt.js";
import "./WidgetLayoutField.vue_vue_type_script_setup_true_lang-Byos1Etx.js";
import "./WidgetWithControl.vue_vue_type_script_setup_true_lang-D89FELJf.js";
const _hoisted_1$1 = ["aria-label"];
const minQueueCount = 1;
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "BatchCountEdit",
  setup(__props) {
    const queueSettingsStore = useQueueSettingsStore();
    const { batchCount } = storeToRefs(queueSettingsStore);
    const settingStore = useSettingStore();
    const maxQueueCount = computed(
      () => settingStore.get("Comfy.QueueButton.BatchCountLimit")
    );
    const handleClick = /* @__PURE__ */ __name((increment) => {
      let newCount;
      if (increment) {
        const originalCount = batchCount.value - 1;
        newCount = Math.min(originalCount * 2, maxQueueCount.value);
      } else {
        const originalCount = batchCount.value + 1;
        newCount = Math.floor(originalCount / 2);
      }
      batchCount.value = newCount;
    }, "handleClick");
    return (_ctx, _cache) => {
      const _directive_tooltip = resolveDirective("tooltip");
      return withDirectives((openBlock(), createElementBlock("div", {
        class: "batch-count",
        "aria-label": _ctx.$t("menu.batchCount")
      }, [
        createVNode(unref(script), {
          modelValue: unref(batchCount),
          "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => isRef(batchCount) ? batchCount.value = $event : null),
          class: "w-14",
          min: minQueueCount,
          max: maxQueueCount.value,
          fluid: "",
          "show-buttons": "",
          pt: {
            incrementButton: {
              class: "w-6",
              onmousedown: /* @__PURE__ */ __name(() => {
                handleClick(true);
              }, "onmousedown")
            },
            decrementButton: {
              class: "w-6",
              onmousedown: /* @__PURE__ */ __name(() => {
                handleClick(false);
              }, "onmousedown")
            }
          }
        }, null, 8, ["modelValue", "max", "pt"])
      ], 8, _hoisted_1$1)), [
        [
          _directive_tooltip,
          {
            value: _ctx.$t("menu.batchCount"),
            showDelay: 600
          },
          void 0,
          { bottom: true }
        ]
      ]);
    };
  }
});
const BatchCountEdit = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-19217ad4"]]);
const _hoisted_1 = { class: "queue-button-group flex" };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "ComfyQueueButton",
  setup(__props) {
    const workspaceStore = useWorkspaceStore();
    const { mode: queueMode, batchCount } = storeToRefs(useQueueSettingsStore());
    const nodeDefStore = useNodeDefStore();
    const hasMissingNodes = computed(
      () => graphHasMissingNodes(app.rootGraph, nodeDefStore.nodeDefsByName)
    );
    const { t } = useI18n();
    const queueModeMenuItemLookup = computed(() => {
      const items = {
        disabled: {
          key: "disabled",
          label: t("menu.run"),
          tooltip: t("menu.disabledTooltip"),
          command: /* @__PURE__ */ __name(() => {
            queueMode.value = "disabled";
          }, "command")
        },
        change: {
          key: "change",
          label: `${t("menu.run")} (${t("menu.onChange")})`,
          tooltip: t("menu.onChangeTooltip"),
          command: /* @__PURE__ */ __name(() => {
            queueMode.value = "change";
          }, "command")
        }
      };
      {
        items.instant = {
          key: "instant",
          label: `${t("menu.run")} (${t("menu.instant")})`,
          tooltip: t("menu.instantTooltip"),
          command: /* @__PURE__ */ __name(() => {
            queueMode.value = "instant";
          }, "command")
        };
      }
      return items;
    });
    const activeQueueModeMenuItem = computed(() => {
      return queueModeMenuItemLookup.value[queueMode.value] || queueModeMenuItemLookup.value.disabled;
    });
    const queueModeMenuItems = computed(
      () => Object.values(queueModeMenuItemLookup.value)
    );
    const iconClass = computed(() => {
      if (hasMissingNodes.value) {
        return "icon-[lucide--triangle-alert]";
      }
      if (workspaceStore.shiftDown) {
        return "icon-[lucide--list-start]";
      }
      if (queueMode.value === "disabled") {
        return "icon-[lucide--play]";
      }
      if (queueMode.value === "instant") {
        return "icon-[lucide--fast-forward]";
      }
      if (queueMode.value === "change") {
        return "icon-[lucide--step-forward]";
      }
      return "icon-[lucide--play]";
    });
    const queueButtonTooltip = computed(() => {
      if (hasMissingNodes.value) {
        return t("menu.runWorkflowDisabled");
      }
      if (workspaceStore.shiftDown) {
        return t("menu.runWorkflowFront");
      }
      return t("menu.runWorkflow");
    });
    const commandStore = useCommandStore();
    const queuePrompt = /* @__PURE__ */ __name(async (e) => {
      const isShiftPressed = "shiftKey" in e && e.shiftKey;
      const commandId = isShiftPressed ? "Comfy.QueuePromptFront" : "Comfy.QueuePrompt";
      if (batchCount.value > 1) ;
      await commandStore.execute(commandId, {
        metadata: {
          subscribe_to_run: false,
          trigger_source: "button"
        }
      });
    }, "queuePrompt");
    return (_ctx, _cache) => {
      const _directive_tooltip = resolveDirective("tooltip");
      return openBlock(), createElementBlock("div", _hoisted_1, [
        withDirectives((openBlock(), createBlock(unref(script$1), {
          class: "comfyui-queue-button",
          label: String(activeQueueModeMenuItem.value?.label ?? ""),
          severity: "primary",
          size: "small",
          model: queueModeMenuItems.value,
          "data-testid": "queue-button",
          onClick: queuePrompt
        }, {
          icon: withCtx(() => [
            createBaseVNode("i", {
              class: normalizeClass(iconClass.value)
            }, null, 2)
          ]),
          item: withCtx(({ item }) => [
            withDirectives((openBlock(), createBlock(_sfc_main$2, {
              variant: item.key === unref(queueMode) ? "primary" : "secondary",
              size: "sm",
              class: "w-full justify-start"
            }, {
              default: withCtx(() => [
                item.icon ? (openBlock(), createElementBlock("i", {
                  key: 0,
                  class: normalizeClass(item.icon)
                }, null, 2)) : createCommentVNode("", true),
                createTextVNode(" " + toDisplayString(String(item.label ?? "")), 1)
              ]),
              _: 2
            }, 1032, ["variant"])), [
              [_directive_tooltip, {
                value: item.tooltip,
                showDelay: 600
              }]
            ])
          ]),
          _: 1
        }, 8, ["label", "model"])), [
          [
            _directive_tooltip,
            {
              value: queueButtonTooltip.value,
              showDelay: 600
            },
            void 0,
            { bottom: true }
          ]
        ]),
        createVNode(BatchCountEdit)
      ]);
    };
  }
});
const ComfyQueueButton = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-214102f7"]]);
export {
  ComfyQueueButton as default
};
//# sourceMappingURL=ComfyQueueButton-Dq_bjDgJ.js.map
