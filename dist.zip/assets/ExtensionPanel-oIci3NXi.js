var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
import { v as script, ad as script$1, ae as script$2, w as script$3, L as script$4, o as script$5, s as script$6, af as FilterMatchMode } from "./vendor-primevue-Ch6rhmJJ.js";
import { u as useI18n } from "./vendor-vue-DLbRHZS7.js";
import { Z as useExtensionStore, e as useSettingStore, _ as _sfc_main$1, S as SearchBox, dl as _sfc_main$2 } from "./index-c_wVuoti.js";
import { bq as defineComponent, E as computed, r as ref, o as onMounted, j as createBlock, d as openBlock, k as withCtx, e as createBaseVNode, z as createVNode, br as unref, A as createTextVNode, u as toDisplayString, q as createCommentVNode, c as createElementBlock, F as Fragment, y as renderList } from "./vendor-other-CzYzbUcM.js";
import "./vendor-xterm-BF8peZ5_.js";
import "./vendor-three-DYL0ZbEr.js";
import "./vendor-tiptap-XfQ74oRB.js";
const _hoisted_1 = { class: "flex justify-end" };
const _hoisted_2 = { class: "mb-3 flex gap-2" };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "ExtensionPanel",
  setup(__props) {
    const { t } = useI18n();
    const filterTypeKeys = ["all", "core", "custom"];
    const filterTypes = computed(
      () => filterTypeKeys.map((key) => ({
        label: t(`g.${key}`),
        value: key
      }))
    );
    const filterType = ref("all");
    const selectedExtensions = ref([]);
    const filters = ref({
      global: { value: "", matchMode: FilterMatchMode.CONTAINS }
    });
    const extensionStore = useExtensionStore();
    const settingStore = useSettingStore();
    const editingEnabledExtensions = ref({});
    const filteredExtensions = computed(() => {
      const extensions = extensionStore.extensions;
      switch (filterType.value) {
        case "core":
          return extensions.filter(
            (ext) => extensionStore.isCoreExtension(ext.name)
          );
        case "custom":
          return extensions.filter(
            (ext) => !extensionStore.isCoreExtension(ext.name)
          );
        default:
          return extensions;
      }
    });
    onMounted(() => {
      extensionStore.extensions.forEach((ext) => {
        editingEnabledExtensions.value[ext.name] = extensionStore.isExtensionEnabled(ext.name);
      });
    });
    const changedExtensions = computed(() => {
      return extensionStore.extensions.filter(
        (ext) => editingEnabledExtensions.value[ext.name] !== extensionStore.isExtensionEnabled(ext.name)
      );
    });
    const hasChanges = computed(() => {
      return changedExtensions.value.length > 0;
    });
    const updateExtensionStatus = /* @__PURE__ */ __name(async () => {
      const editingDisabledExtensionNames = Object.entries(
        editingEnabledExtensions.value
      ).filter(([_, enabled]) => !enabled).map(([name]) => name);
      await settingStore.set("Comfy.Extension.Disabled", [
        ...extensionStore.inactiveDisabledExtensionNames,
        ...editingDisabledExtensionNames
      ]);
    }, "updateExtensionStatus");
    const enableAllExtensions = /* @__PURE__ */ __name(async () => {
      extensionStore.extensions.forEach((ext) => {
        if (extensionStore.isExtensionReadOnly(ext.name)) return;
        editingEnabledExtensions.value[ext.name] = true;
      });
      await updateExtensionStatus();
    }, "enableAllExtensions");
    const disableAllExtensions = /* @__PURE__ */ __name(async () => {
      extensionStore.extensions.forEach((ext) => {
        if (extensionStore.isExtensionReadOnly(ext.name)) return;
        editingEnabledExtensions.value[ext.name] = false;
      });
      await updateExtensionStatus();
    }, "disableAllExtensions");
    const disableThirdPartyExtensions = /* @__PURE__ */ __name(async () => {
      extensionStore.extensions.forEach((ext) => {
        if (extensionStore.isCoreExtension(ext.name)) return;
        editingEnabledExtensions.value[ext.name] = false;
      });
      await updateExtensionStatus();
    }, "disableThirdPartyExtensions");
    const applyChanges = /* @__PURE__ */ __name(() => {
      window.location.reload();
    }, "applyChanges");
    const menu = ref();
    const contextMenuItems = computed(() => [
      {
        label: t("g.enableSelected"),
        icon: "pi pi-check",
        command: /* @__PURE__ */ __name(async () => {
          selectedExtensions.value.forEach((ext) => {
            if (!extensionStore.isExtensionReadOnly(ext.name)) {
              editingEnabledExtensions.value[ext.name] = true;
            }
          });
          await updateExtensionStatus();
        }, "command")
      },
      {
        label: t("g.disableSelected"),
        icon: "pi pi-times",
        command: /* @__PURE__ */ __name(async () => {
          selectedExtensions.value.forEach((ext) => {
            if (!extensionStore.isExtensionReadOnly(ext.name)) {
              editingEnabledExtensions.value[ext.name] = false;
            }
          });
          await updateExtensionStatus();
        }, "command")
      },
      {
        separator: true
      },
      {
        label: t("g.enableAll"),
        icon: "pi pi-check",
        command: enableAllExtensions
      },
      {
        label: t("g.disableAll"),
        icon: "pi pi-times",
        command: disableAllExtensions
      },
      {
        label: t("g.disableThirdParty"),
        icon: "pi pi-times",
        command: disableThirdPartyExtensions,
        disabled: !extensionStore.hasThirdPartyExtensions
      }
    ]);
    return (_ctx, _cache) => {
      return openBlock(), createBlock(_sfc_main$2, {
        value: "Extension",
        class: "extension-panel"
      }, {
        header: withCtx(() => [
          createVNode(SearchBox, {
            modelValue: filters.value["global"].value,
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => filters.value["global"].value = $event),
            placeholder: _ctx.$t("g.searchExtensions") + "..."
          }, null, 8, ["modelValue", "placeholder"]),
          hasChanges.value ? (openBlock(), createBlock(unref(script$6), {
            key: 0,
            severity: "info",
            "pt:text": "w-full",
            class: "max-h-96 overflow-y-auto"
          }, {
            default: withCtx(() => [
              createBaseVNode("ul", null, [
                (openBlock(true), createElementBlock(Fragment, null, renderList(changedExtensions.value, (ext) => {
                  return openBlock(), createElementBlock("li", {
                    key: ext.name
                  }, [
                    createBaseVNode("span", null, toDisplayString(unref(extensionStore).isExtensionEnabled(ext.name) ? "[-]" : "[+]"), 1),
                    createTextVNode(" " + toDisplayString(ext.name), 1)
                  ]);
                }), 128))
              ]),
              createBaseVNode("div", _hoisted_1, [
                createVNode(_sfc_main$1, {
                  variant: "destructive",
                  onClick: applyChanges
                }, {
                  default: withCtx(() => [
                    createTextVNode(toDisplayString(_ctx.$t("g.reloadToApplyChanges")), 1)
                  ]),
                  _: 1
                })
              ])
            ]),
            _: 1
          })) : createCommentVNode("", true)
        ]),
        default: withCtx(() => [
          createBaseVNode("div", _hoisted_2, [
            createVNode(unref(script), {
              modelValue: filterType.value,
              "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => filterType.value = $event),
              options: filterTypes.value,
              "option-label": "label",
              "option-value": "value"
            }, null, 8, ["modelValue", "options"])
          ]),
          createVNode(unref(script$1), {
            selection: selectedExtensions.value,
            "onUpdate:selection": _cache[3] || (_cache[3] = ($event) => selectedExtensions.value = $event),
            value: filteredExtensions.value,
            "striped-rows": "",
            size: "small",
            filters: filters.value,
            "selection-mode": "multiple",
            "data-key": "name"
          }, {
            default: withCtx(() => [
              createVNode(unref(script$2), {
                "selection-mode": "multiple",
                frozen: true,
                style: { "width": "3rem" }
              }),
              createVNode(unref(script$2), {
                header: _ctx.$t("g.extensionName"),
                sortable: "",
                field: "name"
              }, {
                body: withCtx((slotProps) => [
                  createTextVNode(toDisplayString(slotProps.data.name) + " ", 1),
                  unref(extensionStore).isCoreExtension(slotProps.data.name) ? (openBlock(), createBlock(unref(script$3), {
                    key: 0,
                    value: _ctx.$t("g.core")
                  }, null, 8, ["value"])) : (openBlock(), createBlock(unref(script$3), {
                    key: 1,
                    value: _ctx.$t("g.custom"),
                    severity: "info"
                  }, null, 8, ["value"]))
                ]),
                _: 1
              }, 8, ["header"]),
              createVNode(unref(script$2), { pt: {
                headerCell: "flex items-center justify-end",
                bodyCell: "flex items-center justify-end"
              } }, {
                header: withCtx(() => [
                  createVNode(_sfc_main$1, {
                    size: "icon",
                    variant: "muted-textonly",
                    onClick: _cache[2] || (_cache[2] = ($event) => menu.value?.show($event))
                  }, {
                    default: withCtx(() => _cache[4] || (_cache[4] = [
                      createBaseVNode("i", { class: "pi pi-ellipsis-h" }, null, -1)
                    ])),
                    _: 1
                  }),
                  createVNode(unref(script$5), {
                    ref_key: "menu",
                    ref: menu,
                    model: contextMenuItems.value
                  }, null, 8, ["model"])
                ]),
                body: withCtx((slotProps) => [
                  createVNode(unref(script$4), {
                    modelValue: editingEnabledExtensions.value[slotProps.data.name],
                    "onUpdate:modelValue": /* @__PURE__ */ __name(($event) => editingEnabledExtensions.value[slotProps.data.name] = $event, "onUpdate:modelValue"),
                    disabled: unref(extensionStore).isExtensionReadOnly(slotProps.data.name),
                    onChange: updateExtensionStatus
                  }, null, 8, ["modelValue", "onUpdate:modelValue", "disabled"])
                ]),
                _: 1
              })
            ]),
            _: 1
          }, 8, ["selection", "value", "filters"])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default
};
//# sourceMappingURL=ExtensionPanel-oIci3NXi.js.map
