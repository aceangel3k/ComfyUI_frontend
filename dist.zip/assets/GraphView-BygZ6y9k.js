const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./SubscriptionRequiredDialogContent-CaS_hNU_.js","./index-Olrb7AGO.js","./vendor-primevue-Ch6rhmJJ.js","./vendor-other-CzYzbUcM.js","./vendor-other-DODGPXtn.css","./vendor-vue-DLbRHZS7.js","./vendor-xterm-BF8peZ5_.js","./vendor-xterm-BKlWQB97.css","./vendor-three-DYL0ZbEr.js","./vendor-tiptap-XfQ74oRB.js","./index-DIm29Vzn.css","./UserAvatar.vue_vue_type_script_setup_true_lang-DV-9JnFV.js","./index-B57RGC9W.js","./LazyImage.vue_vue_type_script_setup_true_lang-DtvOLs5p.js","./keybindingService-D8KatqvS.js","./serverConfigStore-CulKZi3K.js","./WidgetInputNumber.vue_vue_type_script_setup_true_lang-9nxD7VZ-.js","./widgetPropFilter-BIbGSUAt.js","./WidgetLayoutField.vue_vue_type_script_setup_true_lang-MW4Ts3C1.js","./WidgetWithControl.vue_vue_type_script_setup_true_lang-CyCkqv4p.js","./WidgetInputNumber-BxwvhCgJ.css","./SubscriptionRequiredDialogContent-Ds6aZdDU.css","./ComfyQueueButton-BUVTbzou.js","./ComfyQueueButton-L-9x4HP4.css"])))=>i.map(i=>d[i]);
var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
import { bp as shallowRef, r as ref, E as computed, c$ as Fuse, bq as defineComponent, db as useSlots, i as inject, dY as useBreakpoints, w as watch, c as createElementBlock, d as openBlock, l as withDirectives, z as createVNode, e as createBaseVNode, v as vShow, k as withCtx, s as normalizeClass, br as unref, q as createCommentVNode, p as renderSlot, T as Transition, j as createBlock, u as toDisplayString, F as Fragment, y as renderList, A as createTextVNode, cF as mergeModels, cG as useModel, eb as useAttrs, ec as useFuse, m as mergeProps, D as createSlots, I as withModifiers, G as normalizeStyle, L as toValue, ed as uniqWith, dt as useTemplateRef, d$ as useId, ee as useImage, h as resolveDirective, J as withKeys, dZ as breakpointsTailwind, bu as provide, cp as useAsyncState, b9 as isRef, d8 as onBeforeUnmount, df as defineAsyncComponent, n as nextTick, du as watchEffect, o as onMounted, cH as useLocalStorage, ef as useDraggable, d1 as watchDebounced, cX as useEventListener, dV as Suspense, cu as clamp, d3 as debounce, eg as useMutationObserver, dj as useResizeObserver, a as readonly, eh as onUpdated, f as resolveComponent, ei as clamp$1, c6 as onUnmounted, x as Teleport, t as resolveDynamicComponent, cr as useElementBounding, c_ as whenever, dW as useThrottleFn, ej as useRafFn, dw as purify, dh as refDebounced, be as toRef, d9 as vModelText, cy as customRef, b as reactive, bs as shallowReactive, ek as reactiveComputed, el as triggerRef, em as useMouse, bb as toRaw, en as useMouseInElement, ci as axios, cq as semverExports, d5 as until, bc as toRefs, d7 as useScroll, cY as createSharedComposable, eo as computedWithControl, cZ as toolkit, dr as tryOnScopeDispose, dk as useDebounceFn, bg as onScopeDispose, g as getCurrentInstance, bd as markRaw, ds as createStaticVNode, cV as useTimeoutFn, dq as onErrorCaptured, ep as useTitle, e8 as useFavicon, dQ as useStorage } from "./vendor-other-CzYzbUcM.js";
import { d as defineStore, u as useI18n, s as storeToRefs, j as useRoute, k as useRouter } from "./vendor-vue-DLbRHZS7.js";
import { b as script, p as script$1, _ as __vitePreload, u as useToast, a0 as script$2, a1 as script$3, a2 as script$4, O as script$5, w as script$6, a3 as script$7, e as script$8, a4 as script$9, a as script$a, q as script$b, M as script$c, Q as script$d, R as script$e, J as script$f, a5 as script$g, v as script$h, o as script$i, L as script$j, T as script$k, c as script$l, y as script$m, g as script$n, a6 as script$o, a7 as script$p, m as script$q, k as script$r } from "./vendor-primevue-Ch6rhmJJ.js";
import { s as st, n as normalizeI18nKey, a as api, i as i18n, b as isCloud, c as cn, _ as _sfc_main$1Y, d as _export_sfc, S as SearchBox, t, u as useDialogStore, e as useSettingStore, f as useToastStore, g as _sfc_main$1_, E as EditableText, h as assetService, j as d, k as useModelToNodeStore, l as useSubscription, m as useTelemetry, o as useDialogService, p as useWorkspaceStore, q as app, r as showNativeSystemMenu, v as useWorkflowStore, w as useRightSidePanelStore, x as useSidebarTabStore, y as useBottomPanelStore, z as useCommandStore, A as useExecutionStore, B as collectAllNodes, C as useNodeDefStore, D as useWorkflowService, F as ComfyWorkflow, G as appendJsonExt, H as useSubgraphNavigationStore, I as useSubgraphStore, J as useCanvasStore, K as forEachSubgraphNode, L as useQueueStore, M as useCopyToClipboard, N as useLitegraphService, O as useMediaAssetActions, P as createAnnotatedPath, Q as downloadFile, R as downloadBlob, T as mapTaskOutputToAssetItem, U as formatDuration, V as useErrorHandling, W as useAssetsStore, X as useAssetSelectionStore, Y as _sfc_main$1$, Z as useExtensionStore, $ as useExternalLink, a0 as useCurrentUser, a1 as useFirebaseAuthActions, a2 as useFirebaseAuthStore, a3 as formatCreditsFromCents, a4 as useManagerState, a5 as isElectron, a6 as ManagerTab, a7 as useCanvasPositionConversion, a8 as isDOMWidget, a9 as isComponentWidget, aa as useDomWidgetStore, ab as useChainCallback, ac as layoutStore, ad as MinimapDataSourceFactory, ae as renderMinimapToCanvas, af as useColorPaletteStore, ag as enforceMinimumBounds, ah as calculateMinimapScale, ai as useCanvasInteractions, aj as LiteGraph, ak as isOverNodeInput, al as isOverNodeOutput, am as adjustColor, an as LGraphCanvas, ao as isColorable, ap as getItemsColorOption, aq as useSelectionState, ar as isLGraphNode, as as isOutputNode, at as SubgraphNode, au as useSelectedLiteGraphItems, av as useVueFeatureFlags, aw as isLGraphGroup, ax as LGraphNode, ay as LGraphGroup, az as computeUnionBounds, aA as RenderShape, aB as LGraphEventMode, aC as filterOutputNodes, aD as useTitleEditorStore, aE as distributeNodes, aF as alignNodes, aG as useSubgraphOperations, aH as useExtensionService, aI as useNodeHelpStore, aJ as NodeHelpContent, aK as isProxyWidget, aL as useLayoutMutations, aM as LayoutSource, aN as NodeSlotType, aO as shouldExpand, aP as getComponent, aQ as _sfc_main$21, aR as parseProxyWidgets, aS as widgetItemToProperty, aT as matchesPropertyItem, aU as isRecommendedWidget, aV as pruneDisconnected, aW as demoteWidget, aX as promoteWidget, aY as matchesWidgetItem, aZ as DraggableList, a_ as _sfc_main$22, a$ as _sfc_main$23, b0 as useNodeFrequencyStore, b1 as useNodeBookmarkStore, b2 as highlightQuery, b3 as formatNumberWithSuffix, b4 as NodeSourceType, b5 as NodePreview, b6 as NodeSearchFilter, b7 as SearchFilterChip, b8 as LinkReleaseTriggerAction, b9 as _sfc_main$25, ba as _sfc_main$26, bb as _sfc_main$27, bc as _sfc_main$28, bd as useMenuItemStore, be as useColorPaletteService, bf as SettingDialogContent, bg as SettingDialogHeader, bh as isAbortError, bi as getComfyApiBaseUrl, bj as useSystemStatsStore, bk as stringToLocale, bl as useConflictAcknowledgment, bm as electronAPI, bn as useComfyManagerService, bo as formatVersionAnchor, bp as renderMarkdownToHtml, bq as useConflictDetection, br as useUserStore, bs as useKeybindingStore, bt as useWorkflowThumbnail, bu as usePragmaticDraggable, bv as usePragmaticDroppable, bw as useWorkflowBookmarkStore, bx as ensureCorrectLayoutScale, by as removeNodeTitleHeight, bz as formatCreditsFromUsd, bA as LGraphBadge, bB as BadgePosition, bC as NodeBadgeMode, bD as useSharedCanvasPositionConversion, bE as ComfyNodeDefImpl, bF as ComfyModelDef, bG as legacyMenuCompat, bH as te, bI as LGraph, bJ as LLink, bK as DragAndScale, bL as ContextMenu, bM as isImageNode, bN as isVideoNode, bO as isAudioNode, bP as CanvasPointer, bQ as LinkMarkerShape, bR as clearPreservedQuery, bS as PRESERVED_QUERY_NAMESPACES, bT as getStorageValue, bU as hydratePreservedQuery, bV as mergePreservedQueryIntoQuery, bW as setStorageValue, bX as useNodeZIndex, bY as snapPoint, bZ as isMiddlePointerInput, b_ as syncNodeSlotLayoutsFromDOM, b$ as useNodeOutputStore, c0 as getLocatorIdFromNodeData, c1 as TitleMode, c2 as applyLightThemeColor, c3 as nonWidgetedInputs, c4 as isTransparent, c5 as getNodeByLocatorId, c6 as _sfc_main$29, c7 as _sfc_main$2a, c8 as _sfc_main$2b, c9 as _sfc_main$2c, ca as ChangeTracker, cb as UnauthorizedError, cc as isNativeWindow, cd as mergeCustomNodesI18n, ce as forEachNode, cf as IS_CONTROL_WIDGET, cg as updateControlWidgetLabel, ch as migrateLegacyRerouteNodes, ci as assetItemSchema, cj as MODELS_TAG, ck as MISSING_TAG, cl as tryToggleWidgetPromotion, cm as getAllNonIoNodesInSubgraph, cn as useQueueSettingsStore, co as getExecutionIdsForSelectedNodes, cp as DEFAULT_DARK_COLOR_PALETTE, cq as DEFAULT_LIGHT_COLOR_PALETTE, cr as ManagerUIState, cs as config, ct as useQueuePendingTaskCountStore, cu as useAssetsSidebarTab, cv as _imports_0$1, cw as loadLocale, cx as useModelStore } from "./index-Olrb7AGO.js";
import { _ as _sfc_main$20 } from "./UserAvatar.vue_vue_type_script_setup_true_lang-DV-9JnFV.js";
import { W as WidgetInputBaseClass } from "./index-B57RGC9W.js";
import { _ as _sfc_main$1Z, u as useFeatureFlags, a as useModelUpload, b as _imports_0, c as _sfc_main$24, d as useIntersectionObserver } from "./LazyImage.vue_vue_type_script_setup_true_lang-DtvOLs5p.js";
import { u as useKeybindingService } from "./keybindingService-D8KatqvS.js";
import { u as useServerConfigStore } from "./serverConfigStore-CulKZi3K.js";
import { _ as _sfc_main$2d } from "./WidgetInputNumber.vue_vue_type_script_setup_true_lang-9nxD7VZ-.js";
const getCategoryIcon = /* @__PURE__ */ __name((categoryId) => {
  const iconMap = {
    // Main categories
    all: "icon-[lucide--list]",
    "getting-started": "icon-[lucide--graduation-cap]",
    // Generation types
    "generation-image": "icon-[lucide--image]",
    image: "icon-[lucide--image]",
    "generation-video": "icon-[lucide--film]",
    video: "icon-[lucide--film]",
    "generation-3d": "icon-[lucide--box]",
    "3d": "icon-[lucide--box]",
    "generation-audio": "icon-[lucide--volume-2]",
    audio: "icon-[lucide--volume-2]",
    "generation-llm": "icon-[lucide--message-square-text]",
    // API and models
    "api-nodes": "icon-[lucide--hand-coins]",
    "closed-models": "icon-[lucide--hand-coins]",
    // LLMs and AI
    llm: "icon-[lucide--message-square-text]",
    llms: "icon-[lucide--message-square-text]",
    "llm-api": "icon-[lucide--message-square-text]",
    // Performance and hardware
    "small-models": "icon-[lucide--zap]",
    performance: "icon-[lucide--zap]",
    "mac-compatible": "icon-[lucide--command]",
    "runs-on-mac": "icon-[lucide--command]",
    // Training
    "lora-training": "icon-[lucide--dumbbell]",
    training: "icon-[lucide--dumbbell]",
    // Extensions and tools
    extensions: "icon-[lucide--puzzle]",
    tools: "icon-[lucide--wrench]",
    // Fallbacks for common patterns
    upscaling: "icon-[lucide--maximize-2]",
    controlnet: "icon-[lucide--sliders-horizontal]",
    "area-composition": "icon-[lucide--layout-grid]"
  };
  return iconMap[categoryId.toLowerCase()] || "icon-[lucide--folder]";
}, "getCategoryIcon");
const useWorkflowTemplatesStore = defineStore(
  "workflowTemplates",
  () => {
    const customTemplates = shallowRef({});
    const coreTemplates = shallowRef([]);
    const englishTemplates = shallowRef([]);
    const isLoaded = ref(false);
    const knownTemplateNames = ref(/* @__PURE__ */ new Set());
    const getTemplateByName = /* @__PURE__ */ __name((name) => {
      return enhancedTemplates.value.find((template) => template.name === name);
    }, "getTemplateByName");
    const categoryFilters = ref(/* @__PURE__ */ new Map());
    const addLocalizedFieldsToTemplate = /* @__PURE__ */ __name((template, categoryTitle) => ({
      ...template,
      localizedTitle: st(
        `templateWorkflows.template.${normalizeI18nKey(categoryTitle)}.${normalizeI18nKey(template.name)}`,
        template.title ?? template.name
      ),
      localizedDescription: st(
        `templateWorkflows.templateDescription.${normalizeI18nKey(categoryTitle)}.${normalizeI18nKey(template.name)}`,
        template.description
      )
    }), "addLocalizedFieldsToTemplate");
    const localizeTemplateList = /* @__PURE__ */ __name((templates, categoryTitle) => templates.map(
      (template) => addLocalizedFieldsToTemplate(template, categoryTitle)
    ), "localizeTemplateList");
    const localizeTemplateCategory = /* @__PURE__ */ __name((templateCategory) => ({
      ...templateCategory,
      localizedTitle: st(
        `templateWorkflows.category.${normalizeI18nKey(templateCategory.title)}`,
        templateCategory.title ?? templateCategory.moduleName
      ),
      templates: localizeTemplateList(
        templateCategory.templates,
        templateCategory.title
      )
    }), "localizeTemplateCategory");
    const createAllCategory = /* @__PURE__ */ __name(() => {
      const coreTemplatesWithSourceModule = coreTemplates.value.flatMap(
        (category) => (
          // For each template in each category, add the sourceModule and pass through any localized fields
          category.templates.map((template) => {
            const localizedTemplate = addLocalizedFieldsToTemplate(
              template,
              category.title
            );
            return {
              ...localizedTemplate,
              sourceModule: category.moduleName
            };
          })
        )
      );
      const customTemplatesWithSourceModule = Object.entries(
        customTemplates.value
      ).flatMap(
        ([moduleName, templates]) => templates.map((name) => ({
          name,
          mediaType: "image",
          mediaSubtype: "jpg",
          description: name,
          sourceModule: moduleName
        }))
      );
      return {
        moduleName: "all",
        title: "All",
        localizedTitle: st("templateWorkflows.category.All", "All Templates"),
        templates: [
          ...coreTemplatesWithSourceModule,
          ...customTemplatesWithSourceModule
        ]
      };
    }, "createAllCategory");
    const groupedTemplates = computed(() => {
      const allTemplates = [
        ...coreTemplates.value.map(localizeTemplateCategory),
        ...Object.entries(customTemplates.value).map(
          ([moduleName, templates]) => ({
            moduleName,
            title: moduleName,
            localizedTitle: st(
              `templateWorkflows.category.${normalizeI18nKey(moduleName)}`,
              moduleName
            ),
            templates: templates.map((name) => ({
              name,
              mediaType: "image",
              mediaSubtype: "jpg",
              description: name
            }))
          })
        )
      ];
      const groupedByCategory = [
        {
          label: st(
            "templateWorkflows.category.ComfyUI Examples",
            "ComfyUI Examples"
          ),
          modules: [
            createAllCategory(),
            ...allTemplates.filter((t2) => t2.moduleName === "default")
          ]
        },
        ...Object.keys(customTemplates.value).length > 0 ? [
          {
            label: st(
              "templateWorkflows.category.Custom Nodes",
              "Custom Nodes"
            ),
            modules: allTemplates.filter((t2) => t2.moduleName !== "default")
          }
        ] : []
      ];
      return groupedByCategory;
    });
    const enhancedTemplates = computed(() => {
      const allTemplates = [];
      coreTemplates.value.forEach((category) => {
        category.templates.forEach((template) => {
          const enhancedTemplate = {
            ...template,
            sourceModule: category.moduleName,
            category: category.title,
            categoryType: category.type,
            categoryGroup: category.category,
            isEssential: category.isEssential,
            isPartnerNode: template.openSource === false,
            searchableText: [
              template.title || template.name,
              template.description || "",
              category.title,
              ...template.tags || [],
              ...template.models || []
            ].join(" ")
          };
          allTemplates.push(enhancedTemplate);
        });
      });
      Object.entries(customTemplates.value).forEach(
        ([moduleName, templates]) => {
          templates.forEach((name) => {
            const enhancedTemplate = {
              name,
              title: name,
              description: name,
              mediaType: "image",
              mediaSubtype: "jpg",
              sourceModule: moduleName,
              category: "Extensions",
              categoryType: "extension",
              searchableText: `${name} ${moduleName} extension`
            };
            allTemplates.push(enhancedTemplate);
          });
        }
      );
      const filteredTemplates = allTemplates.filter(
        (template) => !template.requiresCustomNodes?.length
      );
      return filteredTemplates;
    });
    const templateFuse = computed(() => {
      const fuseOptions = {
        keys: [
          { name: "searchableText", weight: 0.4 },
          { name: "title", weight: 0.3 },
          { name: "name", weight: 0.2 },
          { name: "tags", weight: 0.1 }
        ],
        threshold: 0.3,
        includeScore: true
      };
      return new Fuse(enhancedTemplates.value, fuseOptions);
    });
    const filterTemplatesByCategory = /* @__PURE__ */ __name((categoryId) => {
      if (categoryId === "all") {
        return enhancedTemplates.value;
      }
      if (categoryId === "basics") {
        return enhancedTemplates.value.filter((t2) => t2.isEssential);
      }
      if (categoryId === "partner-nodes") {
        return enhancedTemplates.value.filter((t2) => t2.isPartnerNode);
      }
      if (categoryId.startsWith("extension-")) {
        const moduleName = categoryId.replace("extension-", "");
        return enhancedTemplates.value.filter(
          (t2) => t2.sourceModule === moduleName
        );
      }
      const filter = categoryFilters.value.get(categoryId);
      if (!filter) {
        return enhancedTemplates.value;
      }
      return enhancedTemplates.value.filter((template) => {
        if (filter.category && template.category !== filter.category) {
          return false;
        }
        if (filter.categoryGroup && template.categoryGroup !== filter.categoryGroup) {
          return false;
        }
        return true;
      });
    }, "filterTemplatesByCategory");
    const navGroupedTemplates = computed(() => {
      if (!isLoaded.value) return [];
      const items = [];
      categoryFilters.value.clear();
      items.push({
        id: "all",
        label: st("templateWorkflows.category.All", "All Templates"),
        icon: getCategoryIcon("all")
      });
      const essentialCat = coreTemplates.value.find(
        (cat) => cat.isEssential && cat.templates.length > 0
      );
      if (essentialCat) {
        const categoryTitle = essentialCat.title ?? "Getting Started";
        items.push({
          id: "basics",
          label: st(
            `templateWorkflows.category.${normalizeI18nKey(categoryTitle)}`,
            categoryTitle
          ),
          icon: "icon-[lucide--graduation-cap]"
        });
      }
      const categoryGroups = /* @__PURE__ */ new Map();
      coreTemplates.value.forEach((category) => {
        if (category.isEssential) return;
        const categoryGroup = category.category;
        const categoryIcon = category.icon;
        if (categoryGroup) {
          if (!categoryGroups.has(categoryGroup)) {
            categoryGroups.set(categoryGroup, {
              title: categoryGroup,
              items: []
            });
          }
          const group = categoryGroups.get(categoryGroup);
          const categoryId = `${categoryGroup.toLowerCase().replace(/\s+/g, "-")}-${category.title.toLowerCase().replace(/\s+/g, "-")}`;
          categoryFilters.value.set(categoryId, {
            category: category.title,
            categoryGroup
          });
          group.items.push({
            id: categoryId,
            label: st(
              `templateWorkflows.category.${normalizeI18nKey(category.title)}`,
              category.title
            ),
            icon: categoryIcon || getCategoryIcon(category.type || "default")
          });
        }
      });
      categoryGroups.forEach((group, groupName) => {
        if (group.items.length > 0) {
          items.push({
            title: st(
              `templateWorkflows.category.${normalizeI18nKey(groupName)}`,
              groupName.split(" ").map(
                (word) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()
              ).join(" ")
            ),
            items: group.items
          });
        }
      });
      const partnerNodeCount = enhancedTemplates.value.filter(
        (t2) => t2.isPartnerNode
      ).length;
      if (partnerNodeCount > 0) {
        items.push({
          id: "partner-nodes",
          label: st(
            "templateWorkflows.category.Partner Nodes",
            "Partner Nodes"
          ),
          icon: "icon-[lucide--handshake]"
        });
      }
      const extensionCounts = enhancedTemplates.value.filter(
        (t2) => t2.sourceModule !== "default"
      ).length;
      if (extensionCounts > 0) {
        const extensionModules = Array.from(
          new Set(
            enhancedTemplates.value.filter((t2) => t2.sourceModule !== "default").map((t2) => t2.sourceModule)
          )
        ).sort();
        const extensionItems = extensionModules.map(
          (moduleName) => ({
            id: `extension-${moduleName}`,
            label: st(
              `templateWorkflows.category.${normalizeI18nKey(moduleName)}`,
              moduleName
            ),
            icon: getCategoryIcon("extensions")
          })
        );
        items.push({
          title: st("templateWorkflows.category.Extensions", "Extensions"),
          items: extensionItems,
          collapsible: true
        });
      }
      return items;
    });
    async function loadWorkflowTemplates() {
      try {
        if (!isLoaded.value) {
          customTemplates.value = await api.getWorkflowTemplates();
          const locale = i18n.global.locale.value;
          const [coreResult, englishResult] = await Promise.all([
            api.getCoreWorkflowTemplates(locale),
            isCloud && locale !== "en" ? api.getCoreWorkflowTemplates("en") : Promise.resolve([])
          ]);
          coreTemplates.value = coreResult;
          englishTemplates.value = englishResult;
          const coreNames = coreTemplates.value.flatMap(
            (category) => category.templates.map((template) => template.name)
          );
          const customNames = Object.values(customTemplates.value).flat();
          knownTemplateNames.value = /* @__PURE__ */ new Set([...coreNames, ...customNames]);
          isLoaded.value = true;
        }
      } catch (error) {
        console.error("Error fetching workflow templates:", error);
      }
    }
    __name(loadWorkflowTemplates, "loadWorkflowTemplates");
    function getEnglishMetadata(templateName) {
      if (englishTemplates.value.length === 0) {
        return null;
      }
      for (const category of englishTemplates.value) {
        const template = category.templates.find((t2) => t2.name === templateName);
        if (template) {
          return {
            tags: template.tags,
            category: category.title,
            useCase: template.useCase,
            models: template.models,
            license: template.license
          };
        }
      }
      return null;
    }
    __name(getEnglishMetadata, "getEnglishMetadata");
    return {
      groupedTemplates,
      navGroupedTemplates,
      enhancedTemplates,
      templateFuse,
      filterTemplatesByCategory,
      isLoaded,
      loadWorkflowTemplates,
      knownTemplateNames,
      getTemplateByName,
      getEnglishMetadata
    };
  }
);
const OnCloseKey = /* @__PURE__ */ Symbol();
const _hoisted_1$1p = { class: "base-widget-layout rounded-2xl overflow-hidden relative" };
const _hoisted_2$12 = { class: "flex h-full w-full" };
const _hoisted_3$P = { class: "flex-1 flex bg-base-background" };
const _hoisted_4$E = { class: "flex h-full w-full flex-col" };
const _hoisted_5$z = {
  key: 0,
  class: "w-full h-18 px-6 flex items-center justify-between gap-2"
};
const _hoisted_6$w = { class: "flex flex-1 shrink-0 gap-2" };
const _hoisted_7$p = { class: "flex min-h-0 flex-1 flex-col" };
const _hoisted_8$k = {
  key: 0,
  class: "text-xxl m-0 px-6 pt-2 pb-6 capitalize"
};
const _hoisted_9$f = { class: "min-h-0 px-6 pt-0 pb-10 overflow-y-auto" };
const _hoisted_10$f = {
  key: 0,
  class: "w-1/4 min-w-40 max-w-80"
};
const _sfc_main$1X = /* @__PURE__ */ defineComponent({
  __name: "BaseModalLayout",
  props: {
    contentTitle: {}
  },
  setup(__props) {
    const BREAKPOINTS = { md: 880 };
    const PANEL_SIZES = {
      width: "w-1/3",
      minWidth: "min-w-40",
      maxWidth: "max-w-56"
    };
    const slots = useSlots();
    const closeDialog = inject(OnCloseKey, () => {
    });
    const breakpoints = useBreakpoints(BREAKPOINTS);
    const notMobile = breakpoints.greater("md");
    const isLeftPanelOpen = ref(true);
    const isRightPanelOpen = ref(false);
    const mobileMenuOpen = ref(false);
    const hasRightPanel = computed(() => !!slots.rightPanel);
    watch(notMobile, (isDesktop) => {
      if (!isDesktop) {
        mobileMenuOpen.value = false;
      }
    });
    const showLeftPanel = computed(() => {
      const shouldShow = notMobile.value ? isLeftPanelOpen.value : mobileMenuOpen.value;
      return shouldShow;
    });
    const toggleLeftPanel = /* @__PURE__ */ __name(() => {
      if (notMobile.value) {
        isLeftPanelOpen.value = !isLeftPanelOpen.value;
      } else {
        mobileMenuOpen.value = !mobileMenuOpen.value;
      }
    }, "toggleLeftPanel");
    const toggleRightPanel = /* @__PURE__ */ __name(() => {
      isRightPanelOpen.value = !isRightPanelOpen.value;
    }, "toggleRightPanel");
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$1p, [
        withDirectives(createVNode(_sfc_main$1Y, {
          size: "icon",
          class: normalizeClass(
            unref(cn)("absolute top-4 right-18 z-10", "transition-opacity duration-200", {
              "opacity-0 pointer-events-none": isRightPanelOpen.value || !hasRightPanel.value
            })
          ),
          onClick: toggleRightPanel
        }, {
          default: withCtx(() => _cache[0] || (_cache[0] = [
            createBaseVNode("i", { class: "icon-[lucide--panel-right] text-sm" }, null, -1)
          ])),
          _: 1
        }, 8, ["class"]), [
          [vShow, !isRightPanelOpen.value && hasRightPanel.value]
        ]),
        createVNode(_sfc_main$1Y, {
          class: "absolute top-4 right-6 z-10 transition-opacity duration-200",
          onClick: unref(closeDialog)
        }, {
          default: withCtx(() => _cache[1] || (_cache[1] = [
            createBaseVNode("i", { class: "pi pi-times text-sm" }, null, -1)
          ])),
          _: 1
        }, 8, ["onClick"]),
        createBaseVNode("div", _hoisted_2$12, [
          createVNode(Transition, { name: "slide-panel" }, {
            default: withCtx(() => [
              _ctx.$slots.leftPanel && showLeftPanel.value ? (openBlock(), createElementBlock("nav", {
                key: 0,
                class: normalizeClass([
                  PANEL_SIZES.width,
                  PANEL_SIZES.minWidth,
                  PANEL_SIZES.maxWidth
                ])
              }, [
                renderSlot(_ctx.$slots, "leftPanel", {}, void 0, true)
              ], 2)) : createCommentVNode("", true)
            ]),
            _: 3
          }),
          createBaseVNode("div", _hoisted_3$P, [
            createBaseVNode("div", _hoisted_4$E, [
              _ctx.$slots.header ? (openBlock(), createElementBlock("header", _hoisted_5$z, [
                createBaseVNode("div", _hoisted_6$w, [
                  !unref(notMobile) ? (openBlock(), createBlock(_sfc_main$1Y, {
                    key: 0,
                    size: "icon",
                    onClick: toggleLeftPanel
                  }, {
                    default: withCtx(() => [
                      createBaseVNode("i", {
                        class: normalizeClass(
                          unref(cn)(
                            showLeftPanel.value ? "icon-[lucide--panel-left]" : "icon-[lucide--panel-left-close]"
                          )
                        )
                      }, null, 2)
                    ]),
                    _: 1
                  })) : createCommentVNode("", true),
                  renderSlot(_ctx.$slots, "header", {}, void 0, true)
                ]),
                renderSlot(_ctx.$slots, "header-right-area", {}, void 0, true),
                createBaseVNode("div", {
                  class: normalizeClass(
                    unref(cn)(
                      "flex justify-end gap-2 w-0",
                      hasRightPanel.value && !isRightPanelOpen.value ? "min-w-22" : "min-w-10"
                    )
                  )
                }, [
                  isRightPanelOpen.value && hasRightPanel.value ? (openBlock(), createBlock(_sfc_main$1Y, {
                    key: 0,
                    size: "icon",
                    onClick: toggleRightPanel
                  }, {
                    default: withCtx(() => _cache[2] || (_cache[2] = [
                      createBaseVNode("i", { class: "icon-[lucide--panel-right-close]" }, null, -1)
                    ])),
                    _: 1
                  })) : createCommentVNode("", true)
                ], 2)
              ])) : createCommentVNode("", true),
              createBaseVNode("main", _hoisted_7$p, [
                renderSlot(_ctx.$slots, "contentFilter", {}, void 0, true),
                !_ctx.$slots.leftPanel ? (openBlock(), createElementBlock("h2", _hoisted_8$k, toDisplayString(_ctx.contentTitle), 1)) : createCommentVNode("", true),
                createBaseVNode("div", _hoisted_9$f, [
                  renderSlot(_ctx.$slots, "content", {}, void 0, true)
                ])
              ])
            ]),
            hasRightPanel.value && isRightPanelOpen.value ? (openBlock(), createElementBlock("aside", _hoisted_10$f, [
              renderSlot(_ctx.$slots, "rightPanel", {}, void 0, true)
            ])) : createCommentVNode("", true)
          ])
        ])
      ]);
    };
  }
});
const BaseModalLayout = /* @__PURE__ */ _export_sfc(_sfc_main$1X, [["__scopeId", "data-v-e9f4fefe"]]);
const _sfc_main$1W = /* @__PURE__ */ defineComponent({
  __name: "NavIcon",
  props: {
    icon: {}
  },
  setup(__props) {
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("i", {
        class: normalizeClass([_ctx.icon, "text-neutral text-sm"])
      }, null, 2);
    };
  }
});
const _hoisted_1$1o = {
  key: 1,
  class: "text-neutral icon-[lucide--folder] text-xs"
};
const _hoisted_2$11 = { class: "flex items-center" };
const _sfc_main$1V = /* @__PURE__ */ defineComponent({
  __name: "NavItem",
  props: {
    icon: {},
    active: { type: Boolean },
    onClick: { type: Function }
  },
  setup(__props) {
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: normalizeClass([
          "flex cursor-pointer items-center gap-2 rounded-md px-4 py-3 text-sm transition-colors text-base-foreground",
          _ctx.active ? "bg-interface-menu-component-surface-selected" : "hover:bg-interface-menu-component-surface-hovered"
        ]),
        role: "button",
        onClick: _cache[0] || (_cache[0] = //@ts-ignore
        (...args) => _ctx.onClick && _ctx.onClick(...args))
      }, [
        _ctx.icon ? (openBlock(), createBlock(_sfc_main$1W, {
          key: 0,
          icon: _ctx.icon
        }, null, 8, ["icon"])) : (openBlock(), createElementBlock("i", _hoisted_1$1o)),
        createBaseVNode("span", _hoisted_2$11, [
          renderSlot(_ctx.$slots, "default")
        ])
      ], 2);
    };
  }
});
const _hoisted_1$1n = { class: "text-xs font-bold text-text-secondary uppercase" };
const _sfc_main$1U = /* @__PURE__ */ defineComponent({
  __name: "NavTitle",
  props: {
    title: {},
    modelValue: { type: Boolean, default: false },
    collapsible: { type: Boolean, default: false }
  },
  emits: ["update:modelValue"],
  setup(__props, { emit: __emit }) {
    const emit = __emit;
    const isCollapsed = computed({
      get: /* @__PURE__ */ __name(() => __props.modelValue, "get"),
      set: /* @__PURE__ */ __name((value) => emit("update:modelValue", value), "set")
    });
    const toggleCollapse = /* @__PURE__ */ __name(() => {
      isCollapsed.value = !isCollapsed.value;
    }, "toggleCollapse");
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: normalizeClass(
          unref(cn)(
            "flex items-center justify-between m-0 px-3 py-0 pt-5",
            _ctx.collapsible && "cursor-pointer select-none"
          )
        ),
        onClick: _cache[0] || (_cache[0] = ($event) => _ctx.collapsible && toggleCollapse())
      }, [
        createBaseVNode("h3", _hoisted_1$1n, toDisplayString(_ctx.title), 1),
        _ctx.collapsible ? (openBlock(), createElementBlock("i", {
          key: 0,
          class: normalizeClass(
            unref(cn)(
              "pi transition-transform duration-200 text-xs text-text-secondary ",
              isCollapsed.value ? "pi-chevron-right" : "pi-chevron-down"
            )
          )
        }, null, 2)) : createCommentVNode("", true)
      ], 2);
    };
  }
});
const _sfc_main$1T = {};
const _hoisted_1$1m = { class: "flex h-16 items-center justify-between px-6" };
const _hoisted_2$10 = { class: "flex items-center gap-2 pl-1" };
const _hoisted_3$O = { class: "text-neutral text-base font-bold" };
function _sfc_render$2(_ctx, _cache) {
  return openBlock(), createElementBlock("header", _hoisted_1$1m, [
    createBaseVNode("div", _hoisted_2$10, [
      renderSlot(_ctx.$slots, "icon", {}, () => [
        _cache[0] || (_cache[0] = createBaseVNode("i", { class: "text-neutral icon-[lucide--puzzle] text-base" }, null, -1))
      ]),
      createBaseVNode("h2", _hoisted_3$O, [
        renderSlot(_ctx.$slots, "default")
      ])
    ])
  ]);
}
__name(_sfc_render$2, "_sfc_render$2");
const PanelHeader = /* @__PURE__ */ _export_sfc(_sfc_main$1T, [["render", _sfc_render$2]]);
const _hoisted_1$1l = { class: "flex h-full w-full flex-col bg-modal-panel-background" };
const _hoisted_2$$ = { class: "flex scrollbar-hide flex-1 flex-col gap-1 overflow-y-auto px-3 py-4" };
const _hoisted_3$N = {
  key: 0,
  class: "flex flex-col gap-2"
};
const _hoisted_4$D = {
  key: 1,
  class: "flex flex-col gap-2"
};
const _sfc_main$1S = /* @__PURE__ */ defineComponent({
  __name: "LeftSidePanel",
  props: {
    navItems: { default: /* @__PURE__ */ __name(() => [], "default") },
    modelValue: {}
  },
  emits: ["update:modelValue"],
  setup(__props, { emit: __emit }) {
    const emit = __emit;
    const collapsedGroups = ref({});
    const getFirstItemId = /* @__PURE__ */ __name(() => {
      if (!__props.navItems || __props.navItems.length === 0) {
        return null;
      }
      const firstEntry = __props.navItems[0];
      if ("items" in firstEntry && firstEntry.items.length > 0) {
        return firstEntry.items[0].id;
      }
      if ("id" in firstEntry) {
        return firstEntry.id;
      }
      return null;
    }, "getFirstItemId");
    const activeItem = computed({
      get: /* @__PURE__ */ __name(() => __props.modelValue ?? getFirstItemId(), "get"),
      set: /* @__PURE__ */ __name((value) => emit("update:modelValue", value), "set")
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$1l, [
        createVNode(PanelHeader, null, {
          icon: withCtx(() => [
            renderSlot(_ctx.$slots, "header-icon")
          ]),
          default: withCtx(() => [
            renderSlot(_ctx.$slots, "header-title")
          ]),
          _: 3
        }),
        createBaseVNode("nav", _hoisted_2$$, [
          (openBlock(true), createElementBlock(Fragment, null, renderList(_ctx.navItems, (item, index) => {
            return openBlock(), createElementBlock(Fragment, { key: index }, [
              "items" in item ? (openBlock(), createElementBlock("div", _hoisted_3$N, [
                createVNode(_sfc_main$1U, {
                  modelValue: collapsedGroups.value[item.title],
                  "onUpdate:modelValue": /* @__PURE__ */ __name(($event) => collapsedGroups.value[item.title] = $event, "onUpdate:modelValue"),
                  title: item.title,
                  collapsible: item.collapsible
                }, null, 8, ["modelValue", "onUpdate:modelValue", "title", "collapsible"]),
                !item.collapsible || !collapsedGroups.value[item.title] ? (openBlock(true), createElementBlock(Fragment, { key: 0 }, renderList(item.items, (subItem) => {
                  return openBlock(), createBlock(_sfc_main$1V, {
                    key: subItem.id,
                    icon: subItem.icon,
                    active: activeItem.value === subItem.id,
                    onClick: /* @__PURE__ */ __name(($event) => activeItem.value = subItem.id, "onClick")
                  }, {
                    default: withCtx(() => [
                      createTextVNode(toDisplayString(subItem.label), 1)
                    ]),
                    _: 2
                  }, 1032, ["icon", "active", "onClick"]);
                }), 128)) : createCommentVNode("", true)
              ])) : (openBlock(), createElementBlock("div", _hoisted_4$D, [
                createVNode(_sfc_main$1V, {
                  icon: item.icon,
                  active: activeItem.value === item.id,
                  onClick: /* @__PURE__ */ __name(($event) => activeItem.value = item.id, "onClick")
                }, {
                  default: withCtx(() => [
                    createTextVNode(toDisplayString(item.label), 1)
                  ]),
                  _: 2
                }, 1032, ["icon", "active", "onClick"])
              ]))
            ], 64);
          }), 128))
        ])
      ]);
    };
  }
});
function usePopoverSizing(options) {
  return computed(() => {
    const { minWidth, maxWidth } = options;
    const style = {};
    if (minWidth) {
      style.minWidth = minWidth;
    }
    if (maxWidth) {
      style.maxWidth = maxWidth;
    }
    return style;
  });
}
__name(usePopoverSizing, "usePopoverSizing");
const _hoisted_1$1k = { class: "flex flex-col px-2 pt-2 pb-0" };
const _hoisted_2$_ = {
  key: 1,
  class: "mt-2 flex items-center justify-between"
};
const _hoisted_3$M = {
  key: 0,
  class: "px-1 text-sm text-base-foreground"
};
const _hoisted_4$C = { class: "text-sm" };
const _hoisted_5$y = {
  key: 0,
  class: "pointer-events-none absolute -top-2 -right-2 z-10 flex h-5 w-5 items-center justify-center rounded-full bg-primary-background text-xs font-semibold text-base-foreground"
};
const _hoisted_6$v = {
  key: 0,
  class: "text-bold icon-[lucide--check] text-xs text-white"
};
const _sfc_main$1R = /* @__PURE__ */ defineComponent({
  ...{
    inheritAttrs: false
  },
  __name: "MultiSelect",
  props: /* @__PURE__ */ mergeModels({
    label: {},
    showSearchBox: { type: Boolean, default: false },
    showSelectedCount: { type: Boolean, default: false },
    showClearButton: { type: Boolean, default: false },
    searchPlaceholder: { default: "Search..." },
    listMaxHeight: { default: "28rem" },
    popoverMinWidth: {},
    popoverMaxWidth: {}
  }, {
    "modelValue": {
      required: true
    },
    "modelModifiers": {},
    "searchQuery": { default: "" },
    "searchQueryModifiers": {}
  }),
  emits: ["update:modelValue", "update:searchQuery"],
  setup(__props) {
    const selectedItems = useModel(__props, "modelValue");
    const searchQuery = useModel(__props, "searchQuery");
    const { t: t2 } = useI18n();
    const selectedCount = computed(() => selectedItems.value.length);
    const popoverStyle = usePopoverSizing({
      minWidth: __props.popoverMinWidth,
      maxWidth: __props.popoverMaxWidth
    });
    const attrs = useAttrs();
    const originalOptions = computed(() => attrs.options || []);
    const fuseOptions = {
      fuseOptions: {
        keys: ["name", "value"],
        threshold: 0.3,
        includeScore: false
      },
      matchAllWhenSearchEmpty: true
    };
    const { results } = useFuse(searchQuery, originalOptions, fuseOptions);
    const filteredOptions = computed(() => {
      if (!searchQuery.value || searchQuery.value.trim() === "") {
        return originalOptions.value;
      }
      const searchResults = results.value.map(
        (result) => result.item
      );
      const selectedButNotInResults = selectedItems.value.filter(
        (item) => !searchResults.some((result) => result.value === item.value)
      );
      return [...selectedButNotInResults, ...searchResults];
    });
    return (_ctx, _cache) => {
      return openBlock(), createBlock(unref(script), mergeProps({
        modelValue: selectedItems.value,
        "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => selectedItems.value = $event)
      }, { ..._ctx.$attrs, options: filteredOptions.value }, {
        "option-label": "name",
        unstyled: "",
        "max-selected-labels": 0,
        pt: {
          root: /* @__PURE__ */ __name(({ props }) => ({
            class: unref(cn)(
              "h-10 relative inline-flex cursor-pointer select-none",
              "rounded-lg bg-secondary-background text-base-foreground",
              "transition-all duration-200 ease-in-out",
              "border-[2.5px] border-solid",
              selectedCount.value > 0 ? "border-node-component-border" : "border-transparent",
              "focus-within:border-node-component-border",
              { "opacity-60 cursor-default": props.disabled }
            )
          }), "root"),
          labelContainer: {
            class: "flex-1 flex items-center overflow-hidden whitespace-nowrap pl-4 py-2 "
          },
          label: {
            class: "p-0"
          },
          dropdown: {
            class: "flex shrink-0 cursor-pointer items-center justify-center px-3"
          },
          header: /* @__PURE__ */ __name(() => ({
            class: _ctx.showSearchBox || _ctx.showSelectedCount || _ctx.showClearButton ? "block" : "hidden"
          }), "header"),
          // Overlay & list visuals unchanged
          overlay: {
            class: unref(cn)(
              "mt-2 rounded-lg py-2 px-2",
              "bg-base-background",
              "text-base-foreground",
              "border border-solid border-border-default"
            )
          },
          listContainer: /* @__PURE__ */ __name(() => ({
            style: { maxHeight: `min(${_ctx.listMaxHeight}, 50vh)` },
            class: "scrollbar-custom"
          }), "listContainer"),
          list: {
            class: "flex flex-col gap-0 p-0 m-0 list-none border-none text-sm"
          },
          // Option row hover and focus tone
          option: /* @__PURE__ */ __name(({ context }) => ({
            class: unref(cn)(
              "flex gap-2 items-center h-10 px-2 rounded-lg cursor-pointer",
              "hover:bg-secondary-background-hover",
              // Add focus/highlight state for keyboard navigation
              context?.focused && "bg-secondary-background-selected hover:bg-secondary-background-selected"
            )
          }), "option"),
          // Hide built-in checkboxes entirely via PT (no :deep)
          pcHeaderCheckbox: {
            root: { class: "hidden" },
            style: { display: "none" }
          },
          pcOptionCheckbox: {
            root: { class: "hidden" },
            style: { display: "none" }
          }
        },
        "aria-label": _ctx.label || unref(t2)("g.multiSelectDropdown"),
        role: "combobox",
        "aria-expanded": false,
        "aria-haspopup": "listbox",
        tabindex: 0
      }), createSlots({
        value: withCtx(() => [
          createBaseVNode("span", _hoisted_4$C, toDisplayString(_ctx.label), 1),
          selectedCount.value > 0 ? (openBlock(), createElementBlock("span", _hoisted_5$y, toDisplayString(selectedCount.value), 1)) : createCommentVNode("", true)
        ]),
        dropdownicon: withCtx(() => [
          _cache[4] || (_cache[4] = createBaseVNode("i", { class: "icon-[lucide--chevron-down] text-muted-foreground" }, null, -1))
        ]),
        option: withCtx((slotProps) => [
          createBaseVNode("div", {
            role: "button",
            class: "flex items-center gap-2 cursor-pointer",
            style: normalizeStyle(unref(popoverStyle))
          }, [
            createBaseVNode("div", {
              class: normalizeClass([
                "flex size-4 shrink-0 items-center justify-center rounded p-0.5 transition-all duration-200",
                slotProps.selected ? "bg-primary-background" : "bg-secondary-background"
              ])
            }, [
              slotProps.selected ? (openBlock(), createElementBlock("i", _hoisted_6$v)) : createCommentVNode("", true)
            ], 2),
            createBaseVNode("span", null, toDisplayString(slotProps.option.name), 1)
          ], 4)
        ]),
        _: 2
      }, [
        _ctx.showSearchBox || _ctx.showSelectedCount || _ctx.showClearButton ? {
          name: "header",
          fn: withCtx(() => [
            createBaseVNode("div", _hoisted_1$1k, [
              _ctx.showSearchBox ? (openBlock(), createBlock(SearchBox, {
                key: 0,
                modelValue: searchQuery.value,
                "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => searchQuery.value = $event),
                class: normalizeClass(_ctx.showSelectedCount || _ctx.showClearButton ? "mb-2" : ""),
                "show-order": true,
                "show-border": true,
                "place-holder": _ctx.searchPlaceholder
              }, null, 8, ["modelValue", "class", "place-holder"])) : createCommentVNode("", true),
              _ctx.showSelectedCount || _ctx.showClearButton ? (openBlock(), createElementBlock("div", _hoisted_2$_, [
                _ctx.showSelectedCount ? (openBlock(), createElementBlock("span", _hoisted_3$M, toDisplayString(selectedCount.value > 0 ? _ctx.$t("g.itemsSelected", { selectedCount: selectedCount.value }) : _ctx.$t("g.itemSelected", { selectedCount: selectedCount.value })), 1)) : createCommentVNode("", true),
                _ctx.showClearButton ? (openBlock(), createBlock(_sfc_main$1Y, {
                  key: 1,
                  variant: "textonly",
                  size: "md",
                  onClick: _cache[1] || (_cache[1] = withModifiers(($event) => selectedItems.value = [], ["stop"]))
                }, {
                  default: withCtx(() => [
                    createTextVNode(toDisplayString(_ctx.$t("g.clearAll")), 1)
                  ]),
                  _: 1
                })) : createCommentVNode("", true)
              ])) : createCommentVNode("", true),
              _cache[3] || (_cache[3] = createBaseVNode("div", { class: "my-4 h-px bg-border-default" }, null, -1))
            ])
          ]),
          key: "0"
        } : void 0
      ]), 1040, ["modelValue", "pt", "aria-label"]);
    };
  }
});
function useAssetFilterOptions(assets) {
  const availableFileFormats = computed(() => {
    const assetList = toValue(assets);
    const extensions = assetList.map((asset) => {
      const extension = asset.name.split(".").pop();
      return extension && extension !== asset.name ? extension : null;
    }).filter((extension) => extension !== null);
    const uniqueExtensions = uniqWith(extensions, (a, b) => a === b);
    return uniqueExtensions.sort().map((format) => ({
      name: `.${format}`,
      value: format
    }));
  });
  const availableBaseModels = computed(() => {
    const assetList = toValue(assets);
    const models = assetList.map((asset) => asset.user_metadata?.base_model).filter(
      (baseModel) => baseModel !== void 0 && typeof baseModel === "string"
    );
    const uniqueModels = uniqWith(models, (a, b) => a === b);
    return uniqueModels.sort().map((model) => ({
      name: model,
      value: model
    }));
  });
  return {
    availableFileFormats,
    availableBaseModels
  };
}
__name(useAssetFilterOptions, "useAssetFilterOptions");
const _hoisted_1$1j = {
  class: "flex gap-4 items-center justify-between px-6 pt-2 pb-6",
  "data-component-id": "asset-filter-bar"
};
const _hoisted_2$Z = {
  class: "flex gap-4 items-center",
  "data-component-id": "asset-filter-bar-left"
};
const _hoisted_3$L = {
  class: "flex items-center",
  "data-component-id": "asset-filter-bar-right"
};
const _sfc_main$1Q = /* @__PURE__ */ defineComponent({
  __name: "AssetFilterBar",
  props: {
    assets: { default: /* @__PURE__ */ __name(() => [], "default") },
    allAssets: { default: /* @__PURE__ */ __name(() => [], "default") }
  },
  emits: ["filterChange"],
  setup(__props, { emit: __emit }) {
    const SORT_OPTIONS = [
      { name: t("assetBrowser.sortRecent"), value: "recent" },
      { name: t("assetBrowser.sortAZ"), value: "name-asc" },
      { name: t("assetBrowser.sortZA"), value: "name-desc" }
    ];
    const sortOptions = [...SORT_OPTIONS];
    const ownershipOptions = [
      { name: t("assetBrowser.ownershipAll"), value: "all" },
      { name: t("assetBrowser.ownershipMyModels"), value: "my-models" },
      { name: t("assetBrowser.ownershipPublicModels"), value: "public-models" }
    ];
    const fileFormats = ref([]);
    const baseModels = ref([]);
    const sortBy = ref("recent");
    const ownership = ref("all");
    const { availableFileFormats, availableBaseModels } = useAssetFilterOptions(__props.assets);
    const hasMutableAssets = computed(() => {
      const assetsToCheck = __props.allAssets.length ? __props.allAssets : __props.assets;
      return assetsToCheck.some((asset) => asset.is_immutable === false);
    });
    const emit = __emit;
    function handleFilterChange() {
      emit("filterChange", {
        fileFormats: fileFormats.value.map((option) => option.value),
        baseModels: baseModels.value.map((option) => option.value),
        sortBy: sortBy.value,
        ownership: ownership.value
      });
    }
    __name(handleFilterChange, "handleFilterChange");
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$1j, [
        createBaseVNode("div", _hoisted_2$Z, [
          unref(availableFileFormats).length > 0 ? (openBlock(), createBlock(_sfc_main$1R, {
            key: 0,
            modelValue: fileFormats.value,
            "onUpdate:modelValue": [
              _cache[0] || (_cache[0] = ($event) => fileFormats.value = $event),
              handleFilterChange
            ],
            label: _ctx.$t("assetBrowser.fileFormats"),
            options: unref(availableFileFormats),
            class: "min-w-32",
            "data-component-id": "asset-filter-file-formats"
          }, null, 8, ["modelValue", "label", "options"])) : createCommentVNode("", true),
          unref(availableBaseModels).length > 0 ? (openBlock(), createBlock(_sfc_main$1R, {
            key: 1,
            modelValue: baseModels.value,
            "onUpdate:modelValue": [
              _cache[1] || (_cache[1] = ($event) => baseModels.value = $event),
              handleFilterChange
            ],
            label: _ctx.$t("assetBrowser.baseModels"),
            options: unref(availableBaseModels),
            class: "min-w-32",
            "data-component-id": "asset-filter-base-models"
          }, null, 8, ["modelValue", "label", "options"])) : createCommentVNode("", true),
          hasMutableAssets.value ? (openBlock(), createBlock(_sfc_main$1Z, {
            key: 2,
            modelValue: ownership.value,
            "onUpdate:modelValue": [
              _cache[2] || (_cache[2] = ($event) => ownership.value = $event),
              handleFilterChange
            ],
            label: _ctx.$t("assetBrowser.ownership"),
            options: ownershipOptions,
            class: "min-w-42",
            "data-component-id": "asset-filter-ownership"
          }, null, 8, ["modelValue", "label"])) : createCommentVNode("", true)
        ]),
        createBaseVNode("div", _hoisted_3$L, [
          createVNode(_sfc_main$1Z, {
            modelValue: sortBy.value,
            "onUpdate:modelValue": [
              _cache[3] || (_cache[3] = ($event) => sortBy.value = $event),
              handleFilterChange
            ],
            label: _ctx.$t("assetBrowser.sortBy"),
            options: sortOptions,
            class: "min-w-32",
            "data-component-id": "asset-filter-sort"
          }, {
            icon: withCtx(() => _cache[4] || (_cache[4] = [
              createBaseVNode("i", { class: "icon-[lucide--arrow-up-down] size-3" }, null, -1)
            ])),
            _: 1
          }, 8, ["modelValue", "label"])
        ])
      ]);
    };
  }
});
const _hoisted_1$1i = { class: "relative inline-flex items-center" };
const _hoisted_2$Y = { class: "flex min-w-40 flex-col gap-2 p-2" };
const _sfc_main$1P = /* @__PURE__ */ defineComponent({
  __name: "MoreButton",
  props: {
    isVertical: { type: Boolean, default: false }
  },
  emits: ["menuOpened", "menuClosed"],
  setup(__props, { expose: __expose }) {
    const isOpen = ref(false);
    const popover = ref();
    function hide() {
      popover.value?.hide();
    }
    __name(hide, "hide");
    __expose({
      hide,
      isOpen
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$1i, [
        createVNode(_sfc_main$1Y, {
          size: "icon",
          variant: "secondary",
          onClick: popover.value?.toggle
        }, {
          default: withCtx(() => [
            createBaseVNode("i", {
              class: normalizeClass(
                unref(cn)(
                  !_ctx.isVertical ? "icon-[lucide--ellipsis]" : "icon-[lucide--more-vertical]",
                  "text-sm"
                )
              )
            }, null, 2)
          ]),
          _: 1
        }, 8, ["onClick"]),
        createVNode(unref(script$1), {
          ref_key: "popover",
          ref: popover,
          "append-to": "body",
          "auto-z-index": "",
          dismissable: "",
          "close-on-escape": "",
          unstyled: "",
          "base-z-index": 1e3,
          pt: {
            root: {
              class: unref(cn)("absolute z-50")
            },
            content: {
              class: unref(cn)(
                "mt-1 rounded-lg",
                "bg-secondary-background text-base-foreground",
                "shadow-lg"
              )
            }
          },
          onShow: _cache[0] || (_cache[0] = () => {
            isOpen.value = true;
            _ctx.$emit("menuOpened");
          }),
          onHide: _cache[1] || (_cache[1] = () => {
            isOpen.value = false;
            _ctx.$emit("menuClosed");
          })
        }, {
          default: withCtx(() => [
            createBaseVNode("div", _hoisted_2$Y, [
              renderSlot(_ctx.$slots, "default", { close: hide })
            ])
          ]),
          _: 3
        }, 8, ["pt"])
      ]);
    };
  }
});
const _hoisted_1$1h = { class: "flex flex-col px-4 py-2 text-sm text-muted-foreground border-t border-border-default" };
const _hoisted_2$X = { key: 0 };
const _sfc_main$1O = /* @__PURE__ */ defineComponent({
  __name: "ConfirmBody",
  props: {
    promptText: {}
  },
  setup(__props) {
    const promptTextReal = computed(() => toValue(__props.promptText));
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$1h, [
        promptTextReal.value ? (openBlock(), createElementBlock("p", _hoisted_2$X, toDisplayString(promptTextReal.value), 1)) : createCommentVNode("", true)
      ]);
    };
  }
});
const _hoisted_1$1g = { class: "w-full flex gap-2 justify-end px-2 pb-2" };
const _sfc_main$1N = /* @__PURE__ */ defineComponent({
  __name: "ConfirmFooter",
  props: {
    cancelText: {},
    confirmText: {},
    confirmClass: {},
    optionsDisabled: {}
  },
  emits: ["cancel", "confirm"],
  setup(__props) {
    const { t: t2 } = useI18n();
    const confirmTextX = computed(() => __props.confirmText || t2("g.confirm"));
    const cancelTextX = computed(() => __props.cancelText || t2("g.cancel"));
    const disabled = computed(() => toValue(__props.optionsDisabled));
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("section", _hoisted_1$1g, [
        createVNode(_sfc_main$1Y, {
          disabled: disabled.value,
          variant: "textonly",
          autofocus: "",
          onClick: _cache[0] || (_cache[0] = ($event) => _ctx.$emit("cancel"))
        }, {
          default: withCtx(() => [
            createTextVNode(toDisplayString(cancelTextX.value), 1)
          ]),
          _: 1
        }, 8, ["disabled"]),
        createVNode(_sfc_main$1Y, {
          disabled: disabled.value,
          variant: "textonly",
          class: normalizeClass(_ctx.confirmClass),
          onClick: _cache[1] || (_cache[1] = ($event) => _ctx.$emit("confirm"))
        }, {
          default: withCtx(() => [
            createTextVNode(toDisplayString(confirmTextX.value), 1)
          ]),
          _: 1
        }, 8, ["disabled", "class"])
      ]);
    };
  }
});
const _hoisted_1$1f = { class: "flex items-center gap-2 p-4 font-bold text-sm text-base-foreground font-inter" };
const _hoisted_2$W = {
  key: 0,
  class: "flex-auto"
};
const _sfc_main$1M = /* @__PURE__ */ defineComponent({
  __name: "ConfirmHeader",
  props: {
    title: {}
  },
  setup(__props) {
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$1f, [
        _ctx.title ? (openBlock(), createElementBlock("span", _hoisted_2$W, toDisplayString(_ctx.title), 1)) : createCommentVNode("", true)
      ]);
    };
  }
});
function showConfirmDialog(options = {}) {
  const dialogStore = useDialogStore();
  const { headerProps, props, footerProps } = options;
  return dialogStore.showDialog({
    headerComponent: _sfc_main$1M,
    component: _sfc_main$1O,
    footerComponent: _sfc_main$1N,
    headerProps,
    props,
    footerProps,
    dialogComponentProps: {
      pt: {
        header: "py-0! px-0!",
        content: "p-0!",
        footer: "p-0!"
      }
    }
  });
}
__name(showConfirmDialog, "showConfirmDialog");
const _hoisted_1$1e = { class: "absolute left-2 bottom-2 flex flex-wrap justify-start gap-1" };
const _sfc_main$1L = /* @__PURE__ */ defineComponent({
  __name: "AssetBadgeGroup",
  props: {
    badges: {}
  },
  setup(__props) {
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$1e, [
        (openBlock(true), createElementBlock(Fragment, null, renderList(_ctx.badges, (badge) => {
          return openBlock(), createElementBlock("span", {
            key: badge.label,
            class: normalizeClass(
              unref(cn)(
                "px-2 py-1 rounded text-xs font-bold uppercase tracking-wider text-modal-card-tag-foreground bg-modal-card-tag-background"
              )
            )
          }, toDisplayString(badge.label), 3);
        }), 128))
      ]);
    };
  }
});
const _hoisted_1$1d = ["data-asset-id", "aria-labelledby", "aria-describedby", "tabindex"];
const _hoisted_2$V = { class: "relative aspect-square w-full overflow-hidden rounded-xl" };
const _hoisted_3$K = ["src", "alt"];
const _hoisted_4$B = { class: "max-h-32 flex flex-col gap-2 justify-between flex-auto" };
const _hoisted_5$x = ["id"];
const _hoisted_6$u = ["id"];
const _hoisted_7$o = { class: "flex gap-4 text-xs text-muted-foreground mt-auto" };
const _hoisted_8$j = {
  key: 0,
  class: "flex items-center gap-1"
};
const _hoisted_9$e = {
  key: 1,
  class: "flex items-center gap-1"
};
const _hoisted_10$e = {
  key: 2,
  class: "flex items-center gap-1"
};
const _sfc_main$1K = /* @__PURE__ */ defineComponent({
  __name: "AssetCard",
  props: {
    asset: {},
    interactive: { type: Boolean }
  },
  emits: ["select"],
  setup(__props) {
    const { t: t2 } = useI18n();
    const settingStore = useSettingStore();
    const { closeDialog } = useDialogStore();
    const { flags } = useFeatureFlags();
    const toastStore = useToastStore();
    const dropdownMenuButton = useTemplateRef(
      "dropdown-menu-button"
    );
    const titleId = useId();
    const descId = useId();
    const isEditing = ref(false);
    const newNameRef = ref();
    const deletedLocal = ref(false);
    const displayName = computed(() => newNameRef.value ?? __props.asset.name);
    const tooltipDelay = computed(
      () => settingStore.get("LiteGraph.Node.TooltipDelay")
    );
    const { isLoading, error } = useImage({
      src: __props.asset.preview_url ?? "",
      alt: __props.asset.name
    });
    function confirmDeletion() {
      dropdownMenuButton.value?.hide();
      const assetName = toValue(displayName);
      const promptText = ref(t2("assetBrowser.deletion.body"));
      const optionsDisabled = ref(false);
      const confirmDialog = showConfirmDialog({
        headerProps: {
          title: t2("assetBrowser.deletion.header")
        },
        props: {
          promptText
        },
        footerProps: {
          confirmText: t2("g.delete"),
          // TODO: These need to be put into the new Button Variants once we have them.
          confirmClass: cn(
            "bg-danger-200 text-base-foreground hover:bg-danger-200/80 focus:bg-danger-200/80 focus:ring ring-base-foreground"
          ),
          optionsDisabled,
          onCancel: /* @__PURE__ */ __name(() => {
            closeDialog(confirmDialog);
          }, "onCancel"),
          onConfirm: /* @__PURE__ */ __name(async () => {
            optionsDisabled.value = true;
            try {
              promptText.value = t2("assetBrowser.deletion.inProgress", {
                assetName
              });
              await assetService.deleteAsset(__props.asset.id);
              promptText.value = t2("assetBrowser.deletion.complete", {
                assetName
              });
              await new Promise((resolve) => setTimeout(resolve, 1e3));
              deletedLocal.value = true;
            } catch (err) {
              console.error(err);
              promptText.value = t2("assetBrowser.deletion.failed", {
                assetName
              });
              await new Promise((resolve) => setTimeout(resolve, 3e3));
            } finally {
              closeDialog(confirmDialog);
            }
          }, "onConfirm")
        }
      });
    }
    __name(confirmDeletion, "confirmDeletion");
    function startAssetRename() {
      dropdownMenuButton.value?.hide();
      isEditing.value = true;
    }
    __name(startAssetRename, "startAssetRename");
    async function assetRename(newName) {
      isEditing.value = false;
      if (newName) {
        newNameRef.value = newName;
        try {
          const result = await assetService.updateAsset(__props.asset.id, {
            name: newName
          });
          newNameRef.value = result.name;
        } catch (err) {
          console.error(err);
          toastStore.add({
            severity: "error",
            summary: t2("assetBrowser.rename.failed"),
            life: 1e4
          });
          newNameRef.value = void 0;
        }
      }
    }
    __name(assetRename, "assetRename");
    return (_ctx, _cache) => {
      const _directive_tooltip = resolveDirective("tooltip");
      return !deletedLocal.value ? (openBlock(), createElementBlock("div", {
        key: 0,
        "data-component-id": "AssetCard",
        "data-asset-id": _ctx.asset.id,
        "aria-labelledby": unref(titleId),
        "aria-describedby": unref(descId),
        tabindex: _ctx.interactive ? 0 : -1,
        class: normalizeClass(
          unref(cn)(
            "rounded-2xl overflow-hidden transition-all duration-200 bg-modal-card-background p-2 gap-2 flex flex-col h-full",
            _ctx.interactive && "group appearance-none bg-transparent m-0 outline-none text-left hover:bg-secondary-background focus:bg-secondary-background border-none focus:outline-solid outline-base-foreground outline-4"
          )
        ),
        onKeydown: _cache[3] || (_cache[3] = withKeys(withModifiers(($event) => _ctx.interactive && _ctx.$emit("select", _ctx.asset), ["self"]), ["enter"]))
      }, [
        createBaseVNode("div", _hoisted_2$V, [
          unref(isLoading) || unref(error) ? (openBlock(), createElementBlock("div", {
            key: 0,
            class: "flex size-full cursor-pointer items-center justify-center bg-gradient-to-br from-smoke-400 via-smoke-800 to-charcoal-400",
            role: "button",
            onClick: _cache[0] || (_cache[0] = withModifiers(($event) => _ctx.interactive && _ctx.$emit("select", _ctx.asset), ["self"]))
          })) : (openBlock(), createElementBlock("img", {
            key: 1,
            src: _ctx.asset.preview_url,
            alt: displayName.value,
            class: "size-full object-cover cursor-pointer",
            role: "button",
            onClick: _cache[1] || (_cache[1] = withModifiers(($event) => _ctx.interactive && _ctx.$emit("select", _ctx.asset), ["self"]))
          }, null, 8, _hoisted_3$K)),
          createVNode(_sfc_main$1L, {
            badges: _ctx.asset.badges
          }, null, 8, ["badges"]),
          unref(flags).assetUpdateOptionsEnabled && !(_ctx.asset.is_immutable ?? true) ? (openBlock(), createBlock(_sfc_main$1_, {
            key: 2,
            class: normalizeClass(
              unref(cn)(
                "absolute top-2 right-2 invisible group-hover:visible",
                unref(dropdownMenuButton)?.isOpen && "visible"
              )
            )
          }, {
            default: withCtx(() => [
              createVNode(_sfc_main$1P, {
                ref: "dropdown-menu-button",
                size: "sm"
              }, {
                default: withCtx(() => [
                  createVNode(_sfc_main$1Y, {
                    variant: "secondary",
                    size: "md",
                    class: "justify-start",
                    onClick: startAssetRename
                  }, {
                    default: withCtx(() => [
                      _cache[4] || (_cache[4] = createBaseVNode("i", { class: "icon-[lucide--pencil]" }, null, -1)),
                      createBaseVNode("span", null, toDisplayString(_ctx.$t("g.rename")), 1)
                    ]),
                    _: 1
                  }),
                  createVNode(_sfc_main$1Y, {
                    variant: "secondary",
                    size: "md",
                    class: "justify-start",
                    onClick: confirmDeletion
                  }, {
                    default: withCtx(() => [
                      _cache[5] || (_cache[5] = createBaseVNode("i", { class: "icon-[lucide--trash-2]" }, null, -1)),
                      createBaseVNode("span", null, toDisplayString(_ctx.$t("g.delete")), 1)
                    ]),
                    _: 1
                  })
                ]),
                _: 1
              }, 512)
            ]),
            _: 1
          }, 8, ["class"])) : createCommentVNode("", true)
        ]),
        createBaseVNode("div", _hoisted_4$B, [
          withDirectives((openBlock(), createElementBlock("h3", {
            id: unref(titleId),
            class: normalizeClass(
              unref(cn)(
                "mb-2 m-0 text-base font-semibold line-clamp-2 wrap-anywhere",
                "text-base-foreground"
              )
            )
          }, [
            createVNode(EditableText, {
              "model-value": displayName.value,
              "is-editing": isEditing.value,
              "input-attrs": { "data-testid": "asset-name-input" },
              onEdit: assetRename,
              onCancel: _cache[2] || (_cache[2] = ($event) => assetRename())
            }, null, 8, ["model-value", "is-editing"])
          ], 10, _hoisted_5$x)), [
            [
              _directive_tooltip,
              { value: displayName.value, showDelay: tooltipDelay.value },
              void 0,
              { top: true }
            ]
          ]),
          withDirectives((openBlock(), createElementBlock("p", {
            id: unref(descId),
            class: normalizeClass(
              unref(cn)(
                "m-0 text-sm leading-6 overflow-hidden [-webkit-box-orient:vertical] [-webkit-line-clamp:2] [display:-webkit-box] text-muted-foreground"
              )
            )
          }, [
            createTextVNode(toDisplayString(_ctx.asset.description), 1)
          ], 10, _hoisted_6$u)), [
            [
              _directive_tooltip,
              { value: _ctx.asset.description, showDelay: tooltipDelay.value },
              void 0,
              { top: true }
            ]
          ]),
          createBaseVNode("div", _hoisted_7$o, [
            _ctx.asset.stats.stars ? (openBlock(), createElementBlock("span", _hoisted_8$j, [
              _cache[6] || (_cache[6] = createBaseVNode("i", { class: "icon-[lucide--star] size-3" }, null, -1)),
              createTextVNode(" " + toDisplayString(_ctx.asset.stats.stars), 1)
            ])) : createCommentVNode("", true),
            _ctx.asset.stats.downloadCount ? (openBlock(), createElementBlock("span", _hoisted_9$e, [
              _cache[7] || (_cache[7] = createBaseVNode("i", { class: "icon-[lucide--download] size-3" }, null, -1)),
              createTextVNode(" " + toDisplayString(_ctx.asset.stats.downloadCount), 1)
            ])) : createCommentVNode("", true),
            _ctx.asset.stats.formattedDate ? (openBlock(), createElementBlock("span", _hoisted_10$e, [
              _cache[8] || (_cache[8] = createBaseVNode("i", { class: "icon-[lucide--clock] size-3" }, null, -1)),
              createTextVNode(" " + toDisplayString(_ctx.asset.stats.formattedDate), 1)
            ])) : createCommentVNode("", true)
          ])
        ])
      ], 42, _hoisted_1$1d)) : createCommentVNode("", true);
    };
  }
});
const _hoisted_1$1c = ["aria-label", "aria-setsize"];
const _hoisted_2$U = {
  key: 0,
  class: "col-span-full flex items-center justify-center py-20"
};
const _hoisted_3$J = {
  key: 1,
  class: "col-span-full flex flex-col items-center justify-center py-16 text-muted-foreground"
};
const _hoisted_4$A = { class: "mb-2 text-lg font-medium" };
const _hoisted_5$w = { class: "text-sm" };
const _sfc_main$1J = /* @__PURE__ */ defineComponent({
  __name: "AssetGrid",
  props: {
    assets: {},
    loading: { type: Boolean }
  },
  emits: ["assetSelect"],
  setup(__props) {
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        "data-component-id": "AssetGrid",
        class: normalizeClass(
          unref(cn)("grid grid-cols-[repeat(auto-fill,minmax(15rem,1fr))] gap-4 p-2")
        ),
        role: "grid",
        "aria-label": _ctx.$t("assetBrowser.assetCollection"),
        "aria-rowcount": -1,
        "aria-colcount": -1,
        "aria-setsize": _ctx.assets.length
      }, [
        _ctx.loading ? (openBlock(), createElementBlock("div", _hoisted_2$U, _cache[1] || (_cache[1] = [
          createBaseVNode("i", { class: "icon-[lucide--loader] size-12 animate-spin text-muted-foreground" }, null, -1)
        ]))) : _ctx.assets.length === 0 ? (openBlock(), createElementBlock("div", _hoisted_3$J, [
          _cache[2] || (_cache[2] = createBaseVNode("i", { class: "mb-4 icon-[lucide--search] size-10" }, null, -1)),
          createBaseVNode("h3", _hoisted_4$A, toDisplayString(_ctx.$t("assetBrowser.noAssetsFound")), 1),
          createBaseVNode("p", _hoisted_5$w, toDisplayString(_ctx.$t("assetBrowser.tryAdjustingFilters")), 1)
        ])) : (openBlock(true), createElementBlock(Fragment, { key: 2 }, renderList(_ctx.assets, (asset) => {
          return openBlock(), createBlock(_sfc_main$1K, {
            key: asset.id,
            asset,
            interactive: true,
            onSelect: _cache[0] || (_cache[0] = ($event) => _ctx.$emit("assetSelect", $event))
          }, null, 8, ["asset"]);
        }), 128))
      ], 10, _hoisted_1$1c);
    };
  }
});
function getAssetDescription(asset) {
  return typeof asset.user_metadata?.description === "string" ? asset.user_metadata.description : null;
}
__name(getAssetDescription, "getAssetDescription");
function getAssetBaseModel(asset) {
  return typeof asset.user_metadata?.base_model === "string" ? asset.user_metadata.base_model : null;
}
__name(getAssetBaseModel, "getAssetBaseModel");
function filterByCategory(category) {
  return (asset) => {
    return category === "all" || asset.tags.includes(category);
  };
}
__name(filterByCategory, "filterByCategory");
function filterByFileFormats(formats) {
  return (asset) => {
    if (formats.length === 0) return true;
    const formatSet = new Set(formats);
    const extension = asset.name.split(".").pop()?.toLowerCase();
    return extension ? formatSet.has(extension) : false;
  };
}
__name(filterByFileFormats, "filterByFileFormats");
function filterByBaseModels(models) {
  return (asset) => {
    if (models.length === 0) return true;
    const modelSet = new Set(models);
    const baseModel = getAssetBaseModel(asset);
    return baseModel ? modelSet.has(baseModel) : false;
  };
}
__name(filterByBaseModels, "filterByBaseModels");
function filterByOwnership(ownership) {
  return (asset) => {
    if (ownership === "all") return true;
    if (ownership === "my-models") return asset.is_immutable === false;
    if (ownership === "public-models") return asset.is_immutable === true;
    return true;
  };
}
__name(filterByOwnership, "filterByOwnership");
function useAssetBrowser(assetsSource = ref([])) {
  const assets = computed(() => assetsSource.value ?? []);
  const searchQuery = ref("");
  const selectedCategory = ref("all");
  const filters = ref({
    sortBy: "recent",
    fileFormats: [],
    baseModels: [],
    ownership: "all"
  });
  function transformAssetForDisplay(asset) {
    const typeTag = asset.tags.find((tag) => tag !== "models");
    const description = getAssetDescription(asset) || `${typeTag || t("assetBrowser.unknown")} model`;
    const badges = [];
    if (typeTag) {
      badges.push({ label: typeTag, type: "type" });
    }
    const baseModel = getAssetBaseModel(asset);
    if (baseModel) {
      badges.push({
        label: baseModel,
        type: "base"
      });
    }
    const stats = {
      formattedDate: d(new Date(asset.created_at), { dateStyle: "short" }),
      downloadCount: void 0,
      // Not available in API
      stars: void 0
      // Not available in API
    };
    return {
      ...asset,
      description,
      badges,
      stats
    };
  }
  __name(transformAssetForDisplay, "transformAssetForDisplay");
  const availableCategories = computed(() => {
    const categories = assets.value.filter((asset) => asset.tags[0] === "models").map((asset) => asset.tags[1]).filter((tag) => typeof tag === "string" && tag.length > 0);
    const uniqueCategories = Array.from(new Set(categories)).sort().map((category) => ({
      id: category,
      label: category.charAt(0).toUpperCase() + category.slice(1),
      icon: "icon-[lucide--package]"
    }));
    return [
      {
        id: "all",
        label: t("assetBrowser.allModels"),
        icon: "icon-[lucide--folder]"
      },
      ...uniqueCategories
    ];
  });
  const contentTitle = computed(() => {
    if (selectedCategory.value === "all") {
      return t("assetBrowser.allModels");
    }
    const category = availableCategories.value.find(
      (cat) => cat.id === selectedCategory.value
    );
    return category?.label || t("assetBrowser.assets");
  });
  const categoryFilteredAssets = computed(() => {
    return assets.value.filter(filterByCategory(selectedCategory.value));
  });
  const fuseOptions = {
    fuseOptions: {
      keys: [
        { name: "name", weight: 0.4 },
        { name: "tags", weight: 0.3 }
      ],
      threshold: 0.4,
      // Higher threshold for typo tolerance (0.0 = exact, 1.0 = match all)
      ignoreLocation: true,
      // Search anywhere in the string, not just at the beginning
      includeScore: true
    },
    matchAllWhenSearchEmpty: true
  };
  const { results: fuseResults } = useFuse(
    searchQuery,
    categoryFilteredAssets,
    fuseOptions
  );
  const searchFiltered = computed(
    () => fuseResults.value.map((result) => result.item)
  );
  const filteredAssets = computed(() => {
    const filtered = searchFiltered.value.filter(filterByFileFormats(filters.value.fileFormats)).filter(filterByBaseModels(filters.value.baseModels)).filter(filterByOwnership(filters.value.ownership));
    const sortedAssets = [...filtered];
    sortedAssets.sort((a, b) => {
      switch (filters.value.sortBy) {
        case "name-desc":
          return b.name.localeCompare(a.name);
        case "recent":
          return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
        case "popular":
          return a.name.localeCompare(b.name);
        case "name-asc":
        default:
          return a.name.localeCompare(b.name);
      }
    });
    return sortedAssets.map(transformAssetForDisplay);
  });
  function updateFilters(newFilters) {
    filters.value = { ...newFilters };
  }
  __name(updateFilters, "updateFilters");
  return {
    searchQuery,
    selectedCategory,
    availableCategories,
    contentTitle,
    categoryFilteredAssets,
    filteredAssets,
    updateFilters
  };
}
__name(useAssetBrowser, "useAssetBrowser");
const ACRONYM_TAGS = /* @__PURE__ */ new Set(["VAE", "CLIP", "GLIGEN"]);
function formatCategoryLabel(raw) {
  if (!raw) return "Models";
  if (raw === "diffusion_models") return "Diffusion";
  return raw.split("_").map((segment) => {
    const upper = segment.toUpperCase();
    if (ACRONYM_TAGS.has(upper)) return upper;
    const lower = segment.toLowerCase();
    return lower.charAt(0).toUpperCase() + lower.slice(1);
  }).join(" ");
}
__name(formatCategoryLabel, "formatCategoryLabel");
const _hoisted_1$1b = { class: "capitalize" };
const _hoisted_2$T = { class: "flex w-full items-center justify-between gap-2" };
const _hoisted_3$I = { class: "hidden md:inline" };
const _sfc_main$1I = /* @__PURE__ */ defineComponent({
  __name: "AssetBrowserModal",
  props: {
    nodeType: {},
    onSelect: { type: Function },
    onClose: { type: Function },
    showLeftPanel: { type: Boolean },
    title: {},
    assetType: {}
  },
  emits: ["asset-select", "close"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const { t: t2 } = useI18n();
    const emit = __emit;
    const breakpoints = useBreakpoints(breakpointsTailwind);
    provide(OnCloseKey, props.onClose ?? (() => {
    }));
    const fetchAssets = /* @__PURE__ */ __name(async () => {
      if (props.nodeType) {
        return await assetService.getAssetsForNodeType(props.nodeType) ?? [];
      }
      if (props.assetType) {
        return await assetService.getAssetsByTag(props.assetType) ?? [];
      }
      return [];
    }, "fetchAssets");
    const {
      state: fetchedAssets,
      isLoading,
      execute
    } = useAsyncState(fetchAssets, [], { immediate: false });
    watch(
      () => [props.nodeType, props.assetType],
      async () => {
        await execute();
      },
      { immediate: true }
    );
    const {
      searchQuery,
      selectedCategory,
      availableCategories,
      categoryFilteredAssets,
      filteredAssets,
      updateFilters
    } = useAssetBrowser(fetchedAssets);
    const modelToNodeStore = useModelToNodeStore();
    const primaryCategoryTag = computed(() => {
      const assets = fetchedAssets.value ?? [];
      const tagFromAssets = assets.map((asset) => asset.tags?.find((tag) => tag !== "models")).find((tag) => typeof tag === "string" && tag.length > 0);
      if (tagFromAssets) return tagFromAssets;
      if (props.nodeType) {
        const mapped = modelToNodeStore.getCategoryForNodeType(props.nodeType);
        if (mapped) return mapped;
      }
      if (props.assetType) return props.assetType;
      return "models";
    });
    const activeCategoryTag = computed(() => {
      if (selectedCategory.value !== "all") {
        return selectedCategory.value;
      }
      return primaryCategoryTag.value;
    });
    const displayTitle = computed(() => {
      if (props.title) return props.title;
      const label = formatCategoryLabel(activeCategoryTag.value);
      return t2("assetBrowser.allCategory", { category: label });
    });
    const shouldShowLeftPanel = computed(() => {
      return props.showLeftPanel ?? true;
    });
    function handleClose() {
      props.onClose?.();
      emit("close");
    }
    __name(handleClose, "handleClose");
    function handleAssetSelectAndEmit(asset) {
      emit("asset-select", asset);
      props.onSelect?.(asset);
    }
    __name(handleAssetSelectAndEmit, "handleAssetSelectAndEmit");
    const { isUploadButtonEnabled, showUploadDialog } = useModelUpload(execute);
    return (_ctx, _cache) => {
      return openBlock(), createBlock(BaseModalLayout, {
        "data-component-id": "AssetBrowserModal",
        class: "size-full max-h-full max-w-full min-w-0",
        "content-title": displayTitle.value,
        onClose: handleClose
      }, createSlots({
        header: withCtx(() => [
          createBaseVNode("div", _hoisted_2$T, [
            createVNode(SearchBox, {
              modelValue: unref(searchQuery),
              "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => isRef(searchQuery) ? searchQuery.value = $event : null),
              autofocus: true,
              size: "lg",
              placeholder: _ctx.$t("g.searchPlaceholder"),
              class: "max-w-96"
            }, null, 8, ["modelValue", "placeholder"]),
            unref(isUploadButtonEnabled) ? (openBlock(), createBlock(_sfc_main$1Y, {
              key: 0,
              variant: "primary",
              size: unref(breakpoints).md ? "md" : "icon",
              "data-attr": "upload-model-button",
              onClick: unref(showUploadDialog)
            }, {
              default: withCtx(() => [
                _cache[3] || (_cache[3] = createBaseVNode("i", { class: "icon-[lucide--folder-input]" }, null, -1)),
                createBaseVNode("span", _hoisted_3$I, toDisplayString(_ctx.$t("assetBrowser.uploadModel")), 1)
              ]),
              _: 1
            }, 8, ["size", "onClick"])) : createCommentVNode("", true)
          ])
        ]),
        contentFilter: withCtx(() => [
          createVNode(_sfc_main$1Q, {
            assets: unref(categoryFilteredAssets),
            "all-assets": unref(fetchedAssets),
            onFilterChange: unref(updateFilters)
          }, null, 8, ["assets", "all-assets", "onFilterChange"])
        ]),
        content: withCtx(() => [
          createVNode(_sfc_main$1J, {
            assets: unref(filteredAssets),
            loading: unref(isLoading),
            onAssetSelect: handleAssetSelectAndEmit
          }, null, 8, ["assets", "loading"])
        ]),
        _: 2
      }, [
        shouldShowLeftPanel.value ? {
          name: "leftPanel",
          fn: withCtx(() => [
            createVNode(_sfc_main$1S, {
              modelValue: unref(selectedCategory),
              "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => isRef(selectedCategory) ? selectedCategory.value = $event : null),
              "data-component-id": "AssetBrowserModal-LeftSidePanel",
              "nav-items": unref(availableCategories)
            }, {
              "header-icon": withCtx(() => _cache[2] || (_cache[2] = [
                createBaseVNode("div", { class: "icon-[lucide--folder] size-4" }, null, -1)
              ])),
              "header-title": withCtx(() => [
                createBaseVNode("span", _hoisted_1$1b, toDisplayString(displayTitle.value), 1)
              ]),
              _: 1
            }, 8, ["modelValue", "nav-items"])
          ]),
          key: "0"
        } : void 0
      ]), 1032, ["content-title"]);
    };
  }
});
const dialogComponentProps = {
  headless: true,
  modal: true,
  closable: true,
  pt: {
    root: {
      class: "rounded-2xl overflow-hidden asset-browser-dialog"
    },
    header: {
      class: "!p-0 hidden"
    },
    content: {
      class: "!p-0 !m-0 h-full w-full"
    }
  }
};
const useAssetBrowserDialog = /* @__PURE__ */ __name(() => {
  const dialogStore = useDialogStore();
  const dialogKey = "global-asset-browser";
  async function show(props) {
    const handleAssetSelected = /* @__PURE__ */ __name((asset) => {
      props.onAssetSelected?.(asset);
      dialogStore.closeDialog({ key: dialogKey });
    }, "handleAssetSelected");
    dialogStore.showDialog({
      key: dialogKey,
      component: _sfc_main$1I,
      props: {
        nodeType: props.nodeType,
        inputName: props.inputName,
        currentValue: props.currentValue,
        onSelect: handleAssetSelected,
        onClose: /* @__PURE__ */ __name(() => dialogStore.closeDialog({ key: dialogKey }), "onClose")
      },
      dialogComponentProps
    });
  }
  __name(show, "show");
  async function browse(options) {
    const handleAssetSelected = /* @__PURE__ */ __name((asset) => {
      options.onAssetSelected?.(asset);
      dialogStore.closeDialog({ key: dialogKey });
    }, "handleAssetSelected");
    dialogStore.showDialog({
      key: dialogKey,
      component: _sfc_main$1I,
      props: {
        showLeftPanel: true,
        assetType: options.assetType,
        title: options.title,
        onSelect: handleAssetSelected,
        onClose: /* @__PURE__ */ __name(() => dialogStore.closeDialog({ key: dialogKey }), "onClose")
      },
      dialogComponentProps
    });
  }
  __name(browse, "browse");
  return { show, browse };
}, "useAssetBrowserDialog");
const _hoisted_1$1a = { class: "flex max-w-xs min-w-40 flex-col gap-2 p-3" };
const _hoisted_2$S = { class: "text-sm font-inter" };
const _hoisted_3$H = {
  key: 1,
  class: "text-xs"
};
const _hoisted_4$z = { class: "flex max-w-xs min-w-40 flex-col gap-2 p-3" };
const _hoisted_5$v = { class: "text-sm font-inter" };
const _hoisted_6$t = {
  key: 1,
  class: "text-xs"
};
const clickableClasses = "cursor-pointer transition-opacity hover:opacity-80";
const _sfc_main$1H = /* @__PURE__ */ defineComponent({
  __name: "TopbarBadge",
  props: {
    badge: {},
    displayMode: { default: "full" },
    reverseOrder: { type: Boolean, default: false },
    noPadding: { type: Boolean, default: false },
    backgroundColor: { default: "var(--comfy-menu-bg)" }
  },
  setup(__props) {
    const props = __props;
    const popover = ref();
    const togglePopover = /* @__PURE__ */ __name((event) => {
      popover.value?.toggle(event);
    }, "togglePopover");
    const variant = computed(() => props.badge.variant ?? "info");
    const menuBackgroundStyle = computed(() => ({
      backgroundColor: props.backgroundColor
    }));
    const labelClasses = computed(() => {
      switch (variant.value) {
        case "error":
          return "bg-danger-100 text-white";
        case "warning":
          return "bg-gold-600 text-black";
        case "info":
        default:
          return "bg-white text-black";
      }
    });
    const textClasses = computed(() => {
      switch (variant.value) {
        case "error":
          return "text-danger-100";
        case "warning":
          return "text-gold-600";
        case "info":
        default:
          return "text-text-primary";
      }
    });
    const iconColorClass = computed(() => textClasses.value);
    const iconClass = computed(() => {
      if (props.badge.icon) {
        return props.badge.icon;
      }
      switch (variant.value) {
        case "error":
          return "pi pi-exclamation-circle";
        case "warning":
          return "pi pi-exclamation-triangle";
        case "info":
        default:
          return void 0;
      }
    });
    const dotClasses = computed(() => {
      switch (variant.value) {
        case "error":
          return "bg-danger-100";
        case "warning":
          return "bg-gold-600";
        case "info":
        default:
          return "bg-slate-100";
      }
    });
    const popoverPt = computed(() => ({
      root: {
        class: cn("absolute z-50")
      },
      content: {
        class: cn(
          "mt-1 rounded-lg",
          "bg-base-background",
          "text-base-foreground",
          "shadow-lg",
          "border border-border-default"
        )
      }
    }));
    return (_ctx, _cache) => {
      const _directive_tooltip = resolveDirective("tooltip");
      return _ctx.displayMode === "icon-only" ? (openBlock(), createElementBlock("div", {
        key: 0,
        class: normalizeClass(["relative inline-flex h-full shrink-0 items-center justify-center px-2", clickableClasses]),
        style: normalizeStyle(menuBackgroundStyle.value),
        onClick: togglePopover
      }, [
        iconClass.value ? (openBlock(), createElementBlock("i", {
          key: 0,
          class: normalizeClass(["shrink-0 text-base", iconClass.value, iconColorClass.value])
        }, null, 2)) : _ctx.badge.label ? (openBlock(), createElementBlock("div", {
          key: 1,
          class: normalizeClass(["shrink-0 rounded-full px-1.5 py-0.5 text-xxxs font-semibold", labelClasses.value])
        }, toDisplayString(_ctx.badge.label), 3)) : (openBlock(), createElementBlock("div", {
          key: 2,
          class: normalizeClass(["size-2 shrink-0 rounded-full", dotClasses.value])
        }, null, 2)),
        createVNode(unref(script$1), {
          ref_key: "popover",
          ref: popover,
          "append-to": "body",
          "auto-z-index": true,
          "base-z-index": 1e3,
          dismissable: true,
          "close-on-escape": true,
          unstyled: "",
          pt: popoverPt.value
        }, {
          default: withCtx(() => [
            createBaseVNode("div", _hoisted_1$1a, [
              _ctx.badge.label ? (openBlock(), createElementBlock("div", {
                key: 0,
                class: normalizeClass(["w-fit rounded-full px-1.5 py-0.5 text-xxxs font-semibold", labelClasses.value])
              }, toDisplayString(_ctx.badge.label), 3)) : createCommentVNode("", true),
              createBaseVNode("div", _hoisted_2$S, toDisplayString(_ctx.badge.text), 1),
              _ctx.badge.tooltip ? (openBlock(), createElementBlock("div", _hoisted_3$H, toDisplayString(_ctx.badge.tooltip), 1)) : createCommentVNode("", true)
            ])
          ]),
          _: 1
        }, 8, ["pt"])
      ], 4)) : _ctx.displayMode === "compact" ? (openBlock(), createElementBlock("div", {
        key: 1,
        class: "relative inline-flex h-full",
        style: normalizeStyle(menuBackgroundStyle.value)
      }, [
        createBaseVNode("div", {
          class: normalizeClass(["flex h-full shrink-0 items-center gap-2 whitespace-nowrap", [
            { "flex-row-reverse": _ctx.reverseOrder },
            _ctx.noPadding ? "" : "px-3",
            clickableClasses
          ]]),
          onClick: togglePopover
        }, [
          iconClass.value ? (openBlock(), createElementBlock("i", {
            key: 0,
            class: normalizeClass(["shrink-0 text-base", iconClass.value, iconColorClass.value])
          }, null, 2)) : createCommentVNode("", true),
          _ctx.badge.label ? (openBlock(), createElementBlock("div", {
            key: 1,
            class: normalizeClass(["shrink-0 rounded-full px-1.5 py-0.5 text-xxxs font-semibold", labelClasses.value])
          }, toDisplayString(_ctx.badge.label), 3)) : createCommentVNode("", true)
        ], 2),
        createVNode(unref(script$1), {
          ref_key: "popover",
          ref: popover,
          "append-to": "body",
          "auto-z-index": true,
          "base-z-index": 1e3,
          dismissable: true,
          "close-on-escape": true,
          unstyled: "",
          pt: popoverPt.value
        }, {
          default: withCtx(() => [
            createBaseVNode("div", _hoisted_4$z, [
              _ctx.badge.label ? (openBlock(), createElementBlock("div", {
                key: 0,
                class: normalizeClass(["w-fit rounded-full px-1.5 py-0.5 text-xxxs font-semibold", labelClasses.value])
              }, toDisplayString(_ctx.badge.label), 3)) : createCommentVNode("", true),
              createBaseVNode("div", _hoisted_5$v, toDisplayString(_ctx.badge.text), 1),
              _ctx.badge.tooltip ? (openBlock(), createElementBlock("div", _hoisted_6$t, toDisplayString(_ctx.badge.tooltip), 1)) : createCommentVNode("", true)
            ])
          ]),
          _: 1
        }, 8, ["pt"])
      ], 4)) : withDirectives((openBlock(), createElementBlock("div", {
        key: 2,
        class: normalizeClass(["flex h-full shrink-0 items-center gap-2 whitespace-nowrap", [{ "flex-row-reverse": _ctx.reverseOrder }, _ctx.noPadding ? "" : "px-3"]]),
        style: normalizeStyle(menuBackgroundStyle.value)
      }, [
        iconClass.value ? (openBlock(), createElementBlock("i", {
          key: 0,
          class: normalizeClass(["shrink-0 text-base", iconClass.value, iconColorClass.value])
        }, null, 2)) : createCommentVNode("", true),
        _ctx.badge.label ? (openBlock(), createElementBlock("div", {
          key: 1,
          class: normalizeClass(["shrink-0 rounded-full px-1.5 py-0.5 text-xxxs font-semibold", labelClasses.value])
        }, toDisplayString(_ctx.badge.label), 3)) : createCommentVNode("", true),
        createBaseVNode("div", {
          class: normalizeClass(["font-inter text-sm", textClasses.value])
        }, toDisplayString(_ctx.badge.text), 3)
      ], 6)), [
        [_directive_tooltip, _ctx.badge.tooltip]
      ]);
    };
  }
});
const POLL_INTERVAL_MS = 3e3;
const MAX_POLL_DURATION_MS = 5 * 60 * 1e3;
const _sfc_main$1G = /* @__PURE__ */ defineComponent({
  __name: "SubscribeButton",
  props: {
    label: {},
    size: { default: "lg" },
    variant: { default: "default" },
    fluid: { type: Boolean, default: true }
  },
  emits: ["subscribed"],
  setup(__props, { emit: __emit }) {
    const emit = __emit;
    const { subscribe, isActiveSubscription: isActiveSubscription2, fetchStatus, showSubscriptionDialog: showSubscriptionDialog2 } = useSubscription();
    const telemetry = useTelemetry();
    const isLoading = ref(false);
    const isPolling = ref(false);
    let pollInterval = null;
    const isAwaitingStripeSubscription = ref(false);
    const startPollingSubscriptionStatus = /* @__PURE__ */ __name(() => {
      isPolling.value = true;
      isLoading.value = true;
      const startTime = Date.now();
      const poll = /* @__PURE__ */ __name(async () => {
        try {
          if (Date.now() - startTime > MAX_POLL_DURATION_MS) {
            stopPolling();
            return;
          }
          await fetchStatus();
          if (isActiveSubscription2.value) {
            stopPolling();
            telemetry?.trackMonthlySubscriptionSucceeded();
            emit("subscribed");
          }
        } catch (error) {
          console.error(
            "[SubscribeButton] Error polling subscription status:",
            error
          );
        }
      }, "poll");
      void poll();
      pollInterval = window.setInterval(poll, POLL_INTERVAL_MS);
    }, "startPollingSubscriptionStatus");
    const stopPolling = /* @__PURE__ */ __name(() => {
      if (pollInterval) {
        clearInterval(pollInterval);
        pollInterval = null;
      }
      isPolling.value = false;
      isLoading.value = false;
    }, "stopPolling");
    watch(
      [isAwaitingStripeSubscription, isActiveSubscription2],
      ([awaiting, isActive]) => {
      }
    );
    const handleSubscribe = /* @__PURE__ */ __name(async () => {
      isLoading.value = true;
      try {
        await subscribe();
        startPollingSubscriptionStatus();
      } catch (error) {
        console.error("[SubscribeButton] Error initiating subscription:", error);
        isLoading.value = false;
      }
    }, "handleSubscribe");
    onBeforeUnmount(() => {
      stopPolling();
      isAwaitingStripeSubscription.value = false;
    });
    return (_ctx, _cache) => {
      return openBlock(), createBlock(_sfc_main$1Y, {
        size: _ctx.size,
        loading: isLoading.value,
        disabled: isPolling.value,
        variant: "primary",
        style: normalizeStyle(
          _ctx.variant === "gradient" ? {
            background: "var(--color-subscription-button-gradient)",
            color: "var(--color-white)"
          } : void 0
        ),
        class: normalizeClass(unref(cn)("font-bold", _ctx.fluid && "w-full")),
        onClick: handleSubscribe
      }, {
        default: withCtx(() => [
          createTextVNode(toDisplayString(_ctx.label || _ctx.$t("subscription.required.subscribe")), 1)
        ]),
        _: 1
      }, 8, ["size", "loading", "disabled", "style", "class"]);
    };
  }
});
const DIALOG_KEY$2 = "subscription-required";
const useSubscriptionDialog = /* @__PURE__ */ __name(() => {
  const dialogService = useDialogService();
  const dialogStore = useDialogStore();
  function hide() {
    dialogStore.closeDialog({ key: DIALOG_KEY$2 });
  }
  __name(hide, "hide");
  function show() {
    dialogService.showLayoutDialog({
      key: DIALOG_KEY$2,
      component: defineAsyncComponent(
        () => __vitePreload(() => import("./SubscriptionRequiredDialogContent-CaS_hNU_.js"), true ? __vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21]) : void 0, import.meta.url)
      ),
      props: {
        onClose: hide
      },
      dialogComponentProps: {
        style: "width: min(1328px, 95vw); max-height: 90vh;",
        pt: {
          root: {
            class: "rounded-2xl bg-transparent"
          },
          content: {
            class: "!p-0 rounded-2xl border border-border-default bg-base-background/60 backdrop-blur-md shadow-[0_25px_80px_rgba(5,6,12,0.45)]"
          }
        }
      }
    });
  }
  __name(show, "show");
  return {
    show,
    hide
  };
}, "useSubscriptionDialog");
const _sfc_main$1F = /* @__PURE__ */ defineComponent({
  __name: "GlobalToast",
  setup(__props) {
    const toast = useToast();
    const toastStore = useToastStore();
    const settingStore = useSettingStore();
    watch(
      () => toastStore.messagesToAdd,
      (newMessages) => {
        if (newMessages.length === 0) {
          return;
        }
        newMessages.forEach((message) => {
          toast.add(message);
        });
        toastStore.messagesToAdd = [];
      },
      { deep: true }
    );
    watch(
      () => toastStore.messagesToRemove,
      (messagesToRemove) => {
        if (messagesToRemove.length === 0) {
          return;
        }
        messagesToRemove.forEach((message) => {
          toast.remove(message);
        });
        toastStore.messagesToRemove = [];
      },
      { deep: true }
    );
    watch(
      () => toastStore.removeAllRequested,
      (requested) => {
        if (requested) {
          toast.removeAllGroups();
          toastStore.removeAllRequested = false;
        }
      }
    );
    function updateToastPosition() {
      const styleElement = document.getElementById("dynamic-toast-style") || createStyleElement();
      const rect = document.querySelector(".graph-canvas-container")?.getBoundingClientRect();
      if (!rect) return;
      styleElement.textContent = `
    .p-toast.p-component.p-toast-top-right {
      top: ${rect.top + 100}px !important;
      right: ${window.innerWidth - (rect.left + rect.width) + 20}px !important;
       z-index: 10000 !important;
    }
  `;
    }
    __name(updateToastPosition, "updateToastPosition");
    function createStyleElement() {
      const style = document.createElement("style");
      style.id = "dynamic-toast-style";
      document.head.appendChild(style);
      return style;
    }
    __name(createStyleElement, "createStyleElement");
    watch(
      () => settingStore.get("Comfy.UseNewMenu"),
      () => nextTick(updateToastPosition),
      { immediate: true }
    );
    watch(
      () => settingStore.get("Comfy.Sidebar.Location"),
      () => nextTick(updateToastPosition),
      { immediate: true }
    );
    return (_ctx, _cache) => {
      return openBlock(), createBlock(unref(script$2));
    };
  }
});
let _runWhenIdle;
let runWhenGlobalIdle;
(function() {
  const safeGlobal = globalThis;
  if (typeof safeGlobal.requestIdleCallback !== "function" || typeof safeGlobal.cancelIdleCallback !== "function") {
    _runWhenIdle = /* @__PURE__ */ __name((_targetWindow, runner, _timeout) => {
      setTimeout(() => {
        if (disposed) {
          return;
        }
        const end = Date.now() + 15;
        const deadline = {
          didTimeout: true,
          timeRemaining() {
            return Math.max(0, end - Date.now());
          }
        };
        runner(Object.freeze(deadline));
      });
      let disposed = false;
      return {
        dispose() {
          if (disposed) {
            return;
          }
          disposed = true;
        }
      };
    }, "_runWhenIdle");
  } else {
    _runWhenIdle = /* @__PURE__ */ __name((targetWindow, runner, timeout) => {
      const handle = targetWindow.requestIdleCallback(
        runner,
        typeof timeout === "number" ? { timeout } : void 0
      );
      let disposed = false;
      return {
        dispose() {
          if (disposed) {
            return;
          }
          disposed = true;
          targetWindow.cancelIdleCallback(handle);
        }
      };
    }, "_runWhenIdle");
  }
  runWhenGlobalIdle = /* @__PURE__ */ __name((runner, timeout) => _runWhenIdle(globalThis, runner, timeout), "runWhenGlobalIdle");
})();
const _hoisted_1$19 = { class: "fixed z-9999 flex flex-row no-drag top-0 right-0" };
const _sfc_main$1E = /* @__PURE__ */ defineComponent({
  __name: "MenuHamburger",
  setup(__props) {
    const workspaceState = useWorkspaceStore();
    const settingStore = useSettingStore();
    const exitFocusMode = /* @__PURE__ */ __name(() => {
      workspaceState.focusMode = false;
    }, "exitFocusMode");
    watchEffect(() => {
      if (settingStore.get("Comfy.UseNewMenu") !== "Disabled") {
        return;
      }
      if (workspaceState.focusMode) {
        app.ui.menuContainer.style.display = "none";
      } else {
        app.ui.menuContainer.style.display = "block";
      }
    });
    return (_ctx, _cache) => {
      const _directive_tooltip = resolveDirective("tooltip");
      return withDirectives((openBlock(), createElementBlock("div", _hoisted_1$19, [
        withDirectives((openBlock(), createBlock(_sfc_main$1Y, {
          variant: "muted-textonly",
          size: "lg",
          "aria-label": _ctx.$t("menu.showMenu"),
          "aria-live": "assertive",
          onClick: exitFocusMode,
          onContextmenu: unref(showNativeSystemMenu)
        }, {
          default: withCtx(() => _cache[0] || (_cache[0] = [
            createBaseVNode("i", { class: "pi pi-bars" }, null, -1)
          ])),
          _: 1
        }, 8, ["aria-label", "onContextmenu"])), [
          [_directive_tooltip, { value: _ctx.$t("menu.showMenu"), showDelay: 300 }]
        ]),
        _cache[1] || (_cache[1] = createBaseVNode("div", { class: "window-actions-spacer" }, null, -1))
      ], 512)), [
        [vShow, unref(workspaceState).focusMode]
      ]);
    };
  }
});
const _sfc_main$1D = /* @__PURE__ */ defineComponent({
  __name: "UnloadWindowConfirmDialog",
  setup(__props) {
    const settingStore = useSettingStore();
    const workflowStore = useWorkflowStore();
    const handleBeforeUnload = /* @__PURE__ */ __name((event) => {
      if (settingStore.get("Comfy.Window.UnloadConfirmation") && workflowStore.modifiedWorkflows.length > 0) {
        event.preventDefault();
        return true;
      }
      return void 0;
    }, "handleBeforeUnload");
    onMounted(() => {
      window.addEventListener("beforeunload", handleBeforeUnload);
    });
    onBeforeUnmount(() => {
      window.removeEventListener("beforeunload", handleBeforeUnload);
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div");
    };
  }
});
const _hoisted_1$18 = { class: "w-full h-full absolute top-0 left-0 z-999 pointer-events-none flex flex-col" };
const _hoisted_2$R = { class: "side-toolbar-container" };
const _sfc_main$1C = /* @__PURE__ */ defineComponent({
  __name: "LiteGraphCanvasSplitterOverlay",
  setup(__props) {
    const workspaceStore = useWorkspaceStore();
    const settingStore = useSettingStore();
    const rightSidePanelStore = useRightSidePanelStore();
    const sidebarTabStore = useSidebarTabStore();
    const { t: t2 } = useI18n();
    const sidebarLocation = computed(
      () => settingStore.get("Comfy.Sidebar.Location")
    );
    const unifiedWidth = computed(
      () => settingStore.get("Comfy.Sidebar.UnifiedWidth")
    );
    const { focusMode } = storeToRefs(workspaceStore);
    const { activeSidebarTabId, activeSidebarTab } = storeToRefs(sidebarTabStore);
    const { bottomPanelVisible } = storeToRefs(useBottomPanelStore());
    const { isOpen: rightSidePanelVisible } = storeToRefs(rightSidePanelStore);
    const sidebarPanelVisible = computed(() => activeSidebarTab.value !== null);
    const sidebarStateKey = computed(() => {
      return unifiedWidth.value ? "unified-sidebar" : (
        // When no tab is active, use a default key to maintain state
        activeSidebarTabId.value ?? "default-sidebar"
      );
    });
    function onResizestart({ originalEvent: event }) {
      event.preventDefault();
    }
    __name(onResizestart, "onResizestart");
    const splitterRefreshKey = computed(() => {
      return `main-splitter${rightSidePanelVisible.value ? "-with-right-panel" : ""}-${sidebarLocation.value}`;
    });
    const firstPanelStyle = computed(() => {
      if (sidebarLocation.value === "left") {
        return { display: sidebarPanelVisible.value ? "flex" : "none" };
      }
      return void 0;
    });
    const lastPanelStyle = computed(() => {
      if (sidebarLocation.value === "right") {
        return { display: sidebarPanelVisible.value ? "flex" : "none" };
      }
      return void 0;
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$18, [
        renderSlot(_ctx.$slots, "workflow-tabs", {}, void 0, true),
        createBaseVNode("div", {
          class: normalizeClass(["pointer-events-none flex flex-1 overflow-hidden", {
            "flex-row": sidebarLocation.value === "left",
            "flex-row-reverse": sidebarLocation.value === "right"
          }])
        }, [
          createBaseVNode("div", _hoisted_2$R, [
            renderSlot(_ctx.$slots, "side-toolbar", {}, void 0, true)
          ]),
          (openBlock(), createBlock(unref(script$3), {
            key: splitterRefreshKey.value,
            class: "bg-transparent pointer-events-none border-none flex-1 overflow-hidden",
            "state-key": sidebarStateKey.value,
            "state-storage": "local",
            onResizestart
          }, {
            default: withCtx(() => [
              !unref(focusMode) && (sidebarLocation.value === "left" || unref(rightSidePanelVisible)) ? (openBlock(), createBlock(unref(script$4), {
                key: 0,
                class: normalizeClass(
                  sidebarLocation.value === "left" ? unref(cn)(
                    "side-bar-panel bg-comfy-menu-bg pointer-events-auto",
                    sidebarPanelVisible.value && "min-w-78"
                  ) : "bg-comfy-menu-bg pointer-events-auto"
                ),
                "min-size": sidebarLocation.value === "left" ? 10 : 15,
                size: 20,
                style: normalizeStyle(firstPanelStyle.value),
                role: sidebarLocation.value === "left" ? "complementary" : void 0,
                "aria-label": sidebarLocation.value === "left" ? unref(t2)("sideToolbar.sidebar") : void 0
              }, {
                default: withCtx(() => [
                  sidebarLocation.value === "left" && sidebarPanelVisible.value ? renderSlot(_ctx.$slots, "side-bar-panel", { key: 0 }, void 0, true) : sidebarLocation.value === "right" ? renderSlot(_ctx.$slots, "right-side-panel", { key: 1 }, void 0, true) : createCommentVNode("", true)
                ]),
                _: 3
              }, 8, ["class", "min-size", "style", "role", "aria-label"])) : createCommentVNode("", true),
              createVNode(unref(script$4), {
                size: 80,
                class: "flex flex-col"
              }, {
                default: withCtx(() => [
                  renderSlot(_ctx.$slots, "topmenu", { sidebarPanelVisible: sidebarPanelVisible.value }, void 0, true),
                  createVNode(unref(script$3), {
                    class: "bg-transparent pointer-events-none border-none splitter-overlay-bottom mr-1 mb-1 ml-1 flex-1",
                    layout: "vertical",
                    "pt:gutter": unref(cn)(
                      "rounded-tl-lg rounded-tr-lg ",
                      !(unref(bottomPanelVisible) && !unref(focusMode)) && "hidden"
                    ),
                    "state-key": "bottom-panel-splitter",
                    "state-storage": "local",
                    onResizestart
                  }, {
                    default: withCtx(() => [
                      createVNode(unref(script$4), { class: "graph-canvas-panel relative" }, {
                        default: withCtx(() => [
                          renderSlot(_ctx.$slots, "graph-canvas-panel", {}, void 0, true)
                        ]),
                        _: 3
                      }),
                      withDirectives(createVNode(unref(script$4), { class: "bottom-panel border border-(--p-panel-border-color) max-w-full overflow-x-auto bg-comfy-menu-bg pointer-events-auto rounded-lg" }, {
                        default: withCtx(() => [
                          renderSlot(_ctx.$slots, "bottom-panel", {}, void 0, true)
                        ]),
                        _: 3
                      }, 512), [
                        [vShow, unref(bottomPanelVisible) && !unref(focusMode)]
                      ])
                    ]),
                    _: 3
                  }, 8, ["pt:gutter"])
                ]),
                _: 3
              }),
              !unref(focusMode) && (sidebarLocation.value === "right" || unref(rightSidePanelVisible)) ? (openBlock(), createBlock(unref(script$4), {
                key: 1,
                class: normalizeClass(
                  sidebarLocation.value === "right" ? unref(cn)(
                    "side-bar-panel bg-comfy-menu-bg pointer-events-auto",
                    sidebarPanelVisible.value && "min-w-78"
                  ) : "bg-comfy-menu-bg pointer-events-auto"
                ),
                "min-size": sidebarLocation.value === "right" ? 10 : 15,
                size: 20,
                style: normalizeStyle(lastPanelStyle.value),
                role: sidebarLocation.value === "right" ? "complementary" : void 0,
                "aria-label": sidebarLocation.value === "right" ? unref(t2)("sideToolbar.sidebar") : void 0
              }, {
                default: withCtx(() => [
                  sidebarLocation.value === "left" ? renderSlot(_ctx.$slots, "right-side-panel", { key: 0 }, void 0, true) : sidebarLocation.value === "right" && sidebarPanelVisible.value ? renderSlot(_ctx.$slots, "side-bar-panel", { key: 1 }, void 0, true) : createCommentVNode("", true)
                ]),
                _: 3
              }, 8, ["class", "min-size", "style", "role", "aria-label"])) : createCommentVNode("", true)
            ]),
            _: 3
          }, 8, ["state-key"]))
        ], 2)
      ]);
    };
  }
});
const LiteGraphCanvasSplitterOverlay = /* @__PURE__ */ _export_sfc(_sfc_main$1C, [["__scopeId", "data-v-78b7f6de"]]);
const buildTooltipConfig = /* @__PURE__ */ __name((value) => ({
  value,
  showDelay: 300,
  hideDelay: 0,
  pt: {
    text: {
      class: "border-node-component-tooltip-border bg-node-component-tooltip-surface text-node-component-tooltip border rounded-md px-2 py-1 text-xs leading-none shadow-none"
    },
    arrow: {
      class: "border-t-node-component-tooltip-border"
    }
  }
}), "buildTooltipConfig");
const ComfyRunButton = defineAsyncComponent(() => __vitePreload(() => import("./ComfyQueueButton-BUVTbzou.js"), true ? __vite__mapDeps([22,5,3,4,2,1,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,23]) : void 0, import.meta.url));
const _hoisted_1$17 = { class: "flex h-full items-center" };
const _sfc_main$1B = /* @__PURE__ */ defineComponent({
  __name: "ComfyActionbar",
  setup(__props) {
    const settingsStore = useSettingStore();
    const commandStore = useCommandStore();
    const { t: t2 } = useI18n();
    const { isIdle: isExecutionIdle } = storeToRefs(useExecutionStore());
    const position = computed(() => settingsStore.get("Comfy.UseNewMenu"));
    const visible = computed(() => position.value !== "Disabled");
    const tabContainer = document.querySelector(".workflow-tabs-container");
    const panelRef = ref(null);
    const dragHandleRef = ref(null);
    const isDocked = useLocalStorage("Comfy.MenuPosition.Docked", true);
    const storedPosition = useLocalStorage("Comfy.MenuPosition.Floating", {
      x: 0,
      y: 0
    });
    const { x, y, style, isDragging } = useDraggable(panelRef, {
      initialValue: { x: 0, y: 0 },
      handle: dragHandleRef,
      containerElement: document.body,
      onMove: /* @__PURE__ */ __name((event) => {
        const minY = tabContainer?.getBoundingClientRect().bottom ?? 40;
        if (event.y < minY) {
          event.y = minY;
        }
      }, "onMove")
    });
    watchDebounced(
      [x, y],
      ([newX, newY]) => {
        storedPosition.value = { x: newX, y: newY };
      },
      { debounce: 300 }
    );
    const setInitialPosition = /* @__PURE__ */ __name(() => {
      if (panelRef.value) {
        const screenWidth = window.innerWidth;
        const screenHeight = window.innerHeight;
        const menuWidth = panelRef.value.offsetWidth;
        const menuHeight = panelRef.value.offsetHeight;
        if (menuWidth === 0 || menuHeight === 0) {
          return;
        }
        if (storedPosition.value.x !== 0 || storedPosition.value.y !== 0) {
          x.value = clamp(storedPosition.value.x, 0, screenWidth - menuWidth);
          y.value = clamp(storedPosition.value.y, 0, screenHeight - menuHeight);
          captureLastDragState();
          return;
        }
        if (x.value === 0 && y.value === 0) {
          x.value = clamp((screenWidth - menuWidth) / 2, 0, screenWidth - menuWidth);
          y.value = clamp(
            screenHeight - menuHeight - 10,
            0,
            screenHeight - menuHeight
          );
          captureLastDragState();
        }
      }
    }, "setInitialPosition");
    async function comfyRunButtonResolved() {
      await nextTick();
      setInitialPosition();
    }
    __name(comfyRunButtonResolved, "comfyRunButtonResolved");
    watch(visible, async (newVisible) => {
      if (newVisible) {
        await nextTick(setInitialPosition);
      }
    });
    useEventListener(dragHandleRef, "mousedown", () => {
    });
    const lastDragState = ref({
      x: x.value,
      y: y.value,
      windowWidth: window.innerWidth,
      windowHeight: window.innerHeight
    });
    const captureLastDragState = /* @__PURE__ */ __name(() => {
      lastDragState.value = {
        x: x.value,
        y: y.value,
        windowWidth: window.innerWidth,
        windowHeight: window.innerHeight
      };
    }, "captureLastDragState");
    watch(
      isDragging,
      (newIsDragging) => {
        if (!newIsDragging) {
          captureLastDragState();
        }
      },
      { immediate: true }
    );
    const adjustMenuPosition = /* @__PURE__ */ __name(() => {
      if (panelRef.value) {
        const screenWidth = window.innerWidth;
        const screenHeight = window.innerHeight;
        const menuWidth = panelRef.value.offsetWidth;
        const menuHeight = panelRef.value.offsetHeight;
        const distanceLeft = lastDragState.value.x;
        const distanceRight = lastDragState.value.windowWidth - (lastDragState.value.x + menuWidth);
        const distanceTop = lastDragState.value.y;
        const distanceBottom = lastDragState.value.windowHeight - (lastDragState.value.y + menuHeight);
        const distances = [
          { edge: "left", distance: distanceLeft },
          { edge: "right", distance: distanceRight },
          { edge: "top", distance: distanceTop },
          { edge: "bottom", distance: distanceBottom }
        ];
        const closestEdge = distances.reduce(
          (min, curr) => curr.distance < min.distance ? curr : min
        );
        const verticalRatio = lastDragState.value.y / lastDragState.value.windowHeight;
        const horizontalRatio = lastDragState.value.x / lastDragState.value.windowWidth;
        if (closestEdge.edge === "left") {
          x.value = closestEdge.distance;
          y.value = verticalRatio * screenHeight;
        } else if (closestEdge.edge === "right") {
          x.value = screenWidth - menuWidth - closestEdge.distance;
          y.value = verticalRatio * screenHeight;
        } else if (closestEdge.edge === "top") {
          x.value = horizontalRatio * screenWidth;
          y.value = closestEdge.distance;
        } else {
          x.value = horizontalRatio * screenWidth;
          y.value = screenHeight - menuHeight - closestEdge.distance;
        }
        x.value = clamp(x.value, 0, screenWidth - menuWidth);
        y.value = clamp(y.value, 0, screenHeight - menuHeight);
      }
    }, "adjustMenuPosition");
    useEventListener(window, "resize", adjustMenuPosition);
    const isMouseOverDropZone = ref(false);
    const onMouseEnterDropZone = /* @__PURE__ */ __name(() => {
      if (isDragging.value) {
        isMouseOverDropZone.value = true;
      }
    }, "onMouseEnterDropZone");
    const onMouseLeaveDropZone = /* @__PURE__ */ __name(() => {
      if (isDragging.value) {
        isMouseOverDropZone.value = false;
      }
    }, "onMouseLeaveDropZone");
    watch(isDragging, (dragging) => {
      if (dragging) {
        if (isDocked.value) {
          isDocked.value = false;
        }
      } else {
        if (isMouseOverDropZone.value) {
          isDocked.value = true;
        }
        isMouseOverDropZone.value = false;
      }
    });
    const cancelJobTooltipConfig = computed(
      () => buildTooltipConfig(t2("menu.interrupt"))
    );
    const cancelCurrentJob = /* @__PURE__ */ __name(async () => {
      if (isExecutionIdle.value) return;
      await commandStore.execute("Comfy.Interrupt");
    }, "cancelCurrentJob");
    const actionbarClass = computed(
      () => cn(
        "w-[200px] border-dashed border-blue-500 opacity-80",
        "m-1.5 flex items-center justify-center self-stretch",
        "rounded-md before:w-50 before:-ml-50 before:h-full",
        "pointer-events-auto",
        isMouseOverDropZone.value && "border-[3px] opacity-100 scale-105 shadow-[0_0_20px] shadow-blue-500"
      )
    );
    const panelClass = computed(
      () => cn(
        "actionbar pointer-events-auto z-1300",
        isDragging.value && "select-none pointer-events-none",
        isDocked.value ? "p-0 static border-none bg-transparent" : "fixed shadow-interface"
      )
    );
    return (_ctx, _cache) => {
      const _directive_tooltip = resolveDirective("tooltip");
      return openBlock(), createElementBlock("div", _hoisted_1$17, [
        unref(isDragging) && !unref(isDocked) ? (openBlock(), createElementBlock("div", {
          key: 0,
          class: normalizeClass(actionbarClass.value),
          onMouseenter: onMouseEnterDropZone,
          onMouseleave: onMouseLeaveDropZone
        }, toDisplayString(unref(t2)("actionbar.dockToTop")), 35)) : createCommentVNode("", true),
        createVNode(unref(script$5), {
          class: normalizeClass(["pointer-events-auto", panelClass.value]),
          style: normalizeStyle(unref(style)),
          pt: {
            header: { class: "hidden" },
            content: { class: unref(isDocked) ? "p-0" : "p-1" }
          }
        }, {
          default: withCtx(() => [
            createBaseVNode("div", {
              ref_key: "panelRef",
              ref: panelRef,
              class: "flex items-center select-none gap-2"
            }, [
              createBaseVNode("span", {
                ref_key: "dragHandleRef",
                ref: dragHandleRef,
                class: normalizeClass(
                  unref(cn)(
                    "drag-handle cursor-grab w-3 h-max",
                    unref(isDragging) && "cursor-grabbing"
                  )
                )
              }, null, 2),
              (openBlock(), createBlock(Suspense, { onResolve: comfyRunButtonResolved }, {
                default: withCtx(() => [
                  createVNode(unref(ComfyRunButton))
                ]),
                _: 1
              })),
              withDirectives((openBlock(), createBlock(_sfc_main$1Y, {
                variant: "destructive",
                size: "icon",
                disabled: unref(isExecutionIdle),
                "aria-label": unref(t2)("menu.interrupt"),
                onClick: cancelCurrentJob
              }, {
                default: withCtx(() => _cache[0] || (_cache[0] = [
                  createBaseVNode("i", { class: "icon-[lucide--x] size-4" }, null, -1)
                ])),
                _: 1
              }, 8, ["disabled", "aria-label"])), [
                [
                  _directive_tooltip,
                  cancelJobTooltipConfig.value,
                  void 0,
                  { bottom: true }
                ]
              ])
            ], 512)
          ]),
          _: 1
        }, 8, ["style", "class", "pt"])
      ]);
    };
  }
});
const isNodeMissingDefinition = /* @__PURE__ */ __name((node, nodeDefsByName) => {
  const nodeName = node?.type;
  if (!nodeName) return false;
  return !nodeDefsByName[nodeName];
}, "isNodeMissingDefinition");
const collectMissingNodes = /* @__PURE__ */ __name((graph, nodeDefsByName) => {
  if (!graph) return [];
  const lookup = unref(nodeDefsByName);
  return collectAllNodes(graph, (node) => isNodeMissingDefinition(node, lookup));
}, "collectMissingNodes");
const graphHasMissingNodes = /* @__PURE__ */ __name((graph, nodeDefsByName) => {
  return collectMissingNodes(graph, nodeDefsByName).length > 0;
}, "graphHasMissingNodes");
const _hoisted_1$16 = {
  key: 0,
  class: "icon-[lucide--triangle-alert] text-warning-background"
};
const _hoisted_2$Q = { class: "p-breadcrumb-item-label px-2" };
const _hoisted_3$G = {
  key: 2,
  class: "pi pi-angle-down text-[10px]"
};
const _sfc_main$1A = /* @__PURE__ */ defineComponent({
  __name: "SubgraphBreadcrumbItem",
  props: {
    item: {},
    isActive: { type: Boolean, default: false }
  },
  setup(__props) {
    const props = __props;
    const nodeDefStore = useNodeDefStore();
    const hasMissingNodes = computed(
      () => graphHasMissingNodes(app.rootGraph, nodeDefStore.nodeDefsByName)
    );
    const { t: t2 } = useI18n();
    const menu = ref();
    const dialogService = useDialogService();
    const workflowStore = useWorkflowStore();
    const workflowService = useWorkflowService();
    const isEditing = ref(false);
    const itemLabel = ref();
    const itemInputRef = ref();
    const wrapperRef = ref();
    const rename = /* @__PURE__ */ __name(async (newName, initialName) => {
      if (newName && newName !== initialName) {
        props.item.updateTitle?.(newName);
        if (workflowStore.activeSubgraph) {
          workflowStore.activeSubgraph.name = newName;
        } else if (workflowStore.activeWorkflow) {
          try {
            await workflowService.renameWorkflow(
              workflowStore.activeWorkflow,
              ComfyWorkflow.basePath + appendJsonExt(newName)
            );
          } catch (error) {
            console.error(error);
            dialogService.showErrorDialog(error);
            return;
          }
        }
        const navigationStore = useSubgraphNavigationStore();
        navigationStore.restoreState(navigationStore.exportState());
      }
    }, "rename");
    const isRoot = props.item.key === "root";
    const tooltipText = computed(() => {
      if (hasMissingNodes.value && isRoot) {
        return t2("breadcrumbsMenu.missingNodesWarning");
      }
      return props.item.label;
    });
    const menuItems = computed(() => {
      return [
        {
          label: t2("g.rename"),
          icon: "pi pi-pencil",
          command: startRename
        },
        {
          label: t2("breadcrumbsMenu.duplicate"),
          icon: "pi pi-copy",
          command: /* @__PURE__ */ __name(async () => {
            await workflowService.duplicateWorkflow(workflowStore.activeWorkflow);
          }, "command"),
          visible: isRoot && !props.item.isBlueprint
        },
        {
          separator: true,
          visible: isRoot
        },
        {
          label: t2("menuLabels.Save"),
          icon: "pi pi-save",
          command: /* @__PURE__ */ __name(async () => {
            await useCommandStore().execute("Comfy.SaveWorkflow");
          }, "command"),
          visible: isRoot
        },
        {
          label: t2("menuLabels.Save As"),
          icon: "pi pi-save",
          command: /* @__PURE__ */ __name(async () => {
            await useCommandStore().execute("Comfy.SaveWorkflowAs");
          }, "command"),
          visible: isRoot
        },
        {
          separator: true
        },
        {
          label: t2("breadcrumbsMenu.clearWorkflow"),
          icon: "pi pi-trash",
          command: /* @__PURE__ */ __name(async () => {
            await useCommandStore().execute("Comfy.ClearWorkflow");
          }, "command")
        },
        {
          separator: true,
          visible: props.item.key === "root" && props.item.isBlueprint
        },
        {
          label: t2("subgraphStore.publish"),
          icon: "pi pi-copy",
          command: /* @__PURE__ */ __name(async () => {
            await workflowService.saveWorkflowAs(workflowStore.activeWorkflow);
          }, "command"),
          visible: props.item.key === "root" && props.item.isBlueprint
        },
        {
          separator: true,
          visible: isRoot
        },
        {
          label: props.item.isBlueprint ? t2("breadcrumbsMenu.deleteBlueprint") : t2("breadcrumbsMenu.deleteWorkflow"),
          icon: "pi pi-times",
          command: /* @__PURE__ */ __name(async () => {
            await workflowService.deleteWorkflow(workflowStore.activeWorkflow);
          }, "command"),
          visible: isRoot
        }
      ];
    });
    const handleClick = /* @__PURE__ */ __name((event) => {
      if (isEditing.value) {
        return;
      }
      if (event.detail === 1) {
        if (props.isActive) {
          menu.value?.toggle(event);
        } else {
          props.item.command?.({ item: props.item, originalEvent: event });
        }
      } else if (props.isActive && event.detail === 2) {
        menu.value?.hide();
        event.stopPropagation();
        event.preventDefault();
        startRename();
      }
    }, "handleClick");
    const startRename = /* @__PURE__ */ __name(() => {
      isEditing.value = true;
      itemLabel.value = props.item.label;
      void nextTick(() => {
        if (itemInputRef.value?.$el) {
          itemInputRef.value.$el.focus();
          itemInputRef.value.$el.select();
          if (wrapperRef.value) {
            itemInputRef.value.$el.style.width = `${Math.max(200, wrapperRef.value.offsetWidth)}px`;
          }
        }
      });
    }, "startRename");
    const inputBlur = /* @__PURE__ */ __name(async (doRename) => {
      if (doRename) {
        await rename(itemLabel.value, props.item.label);
      }
      isEditing.value = false;
    }, "inputBlur");
    return (_ctx, _cache) => {
      const _directive_tooltip = resolveDirective("tooltip");
      return openBlock(), createElementBlock(Fragment, null, [
        withDirectives((openBlock(), createElementBlock("a", {
          ref_key: "wrapperRef",
          ref: wrapperRef,
          draggable: "false",
          href: "#",
          class: normalizeClass(["p-breadcrumb-item-link h-12 cursor-pointer px-2", {
            "flex items-center gap-1": _ctx.isActive,
            "p-breadcrumb-item-link-menu-visible": menu.value?.overlayVisible,
            "p-breadcrumb-item-link-icon-visible": _ctx.isActive,
            "active-breadcrumb-item": _ctx.isActive
          }]),
          onClick: handleClick
        }, [
          hasMissingNodes.value && isRoot ? (openBlock(), createElementBlock("i", _hoisted_1$16)) : createCommentVNode("", true),
          createBaseVNode("span", _hoisted_2$Q, toDisplayString(_ctx.item.label), 1),
          _ctx.item.isBlueprint ? (openBlock(), createBlock(unref(script$6), {
            key: 1,
            value: "Blueprint",
            severity: "primary"
          })) : createCommentVNode("", true),
          _ctx.isActive ? (openBlock(), createElementBlock("i", _hoisted_3$G)) : createCommentVNode("", true)
        ], 2)), [
          [
            _directive_tooltip,
            {
              value: tooltipText.value,
              showDelay: 512
            },
            void 0,
            { bottom: true }
          ]
        ]),
        _ctx.isActive ? (openBlock(), createBlock(unref(script$7), {
          key: 0,
          ref_key: "menu",
          ref: menu,
          model: menuItems.value,
          popup: true,
          pt: {
            root: {
              style: "background-color: var(--comfy-menu-bg)"
            },
            itemLink: {
              class: "py-2"
            }
          }
        }, null, 8, ["model"])) : createCommentVNode("", true),
        isEditing.value ? (openBlock(), createBlock(unref(script$8), {
          key: 1,
          ref_key: "itemInputRef",
          ref: itemInputRef,
          modelValue: itemLabel.value,
          "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => itemLabel.value = $event),
          class: "fixed z-10000 px-2 py-2 text-[.8rem]",
          onBlur: _cache[1] || (_cache[1] = ($event) => inputBlur(false)),
          onClick: _cache[2] || (_cache[2] = withModifiers(() => {
          }, ["stop"])),
          onKeydown: [
            _cache[3] || (_cache[3] = withKeys(($event) => inputBlur(true), ["enter"])),
            _cache[4] || (_cache[4] = withKeys(($event) => inputBlur(false), ["esc"]))
          ]
        }, null, 8, ["modelValue"])) : createCommentVNode("", true)
      ], 64);
    };
  }
});
const SubgraphBreadcrumbItem = /* @__PURE__ */ _export_sfc(_sfc_main$1A, [["__scopeId", "data-v-09d35179"]]);
const useOverflowObserver = /* @__PURE__ */ __name((element, options) => {
  options = {
    debounceTime: 25,
    useMutationObserver: true,
    useResizeObserver: true,
    ...options
  };
  const isOverflowing = ref(false);
  const disposeFns = [];
  const disposed = ref(false);
  const checkOverflowFn = /* @__PURE__ */ __name(() => {
    isOverflowing.value = element.scrollWidth > element.clientWidth;
    options.onCheck?.(isOverflowing.value);
  }, "checkOverflowFn");
  const checkOverflow = options.debounceTime ? debounce(checkOverflowFn, options.debounceTime) : checkOverflowFn;
  if (options.useMutationObserver) {
    disposeFns.push(
      useMutationObserver(element, checkOverflow, {
        subtree: true,
        childList: true
      }).stop
    );
  }
  if (options.useResizeObserver) {
    disposeFns.push(useResizeObserver(element, checkOverflow).stop);
  }
  return {
    isOverflowing: readonly(isOverflowing),
    disposed: readonly(disposed),
    checkOverflow,
    dispose: /* @__PURE__ */ __name(() => {
      disposed.value = true;
      disposeFns.forEach((fn) => fn());
    }, "dispose")
  };
}, "useOverflowObserver");
const MIN_WIDTH = 28;
const ITEM_GAP = 8;
const ITEM_PADDING = 8;
const ICON_WIDTH = 20;
const _sfc_main$1z = /* @__PURE__ */ defineComponent({
  __name: "SubgraphBreadcrumb",
  setup(__props) {
    const workflowStore = useWorkflowStore();
    const navigationStore = useSubgraphNavigationStore();
    const breadcrumbRef = ref();
    const workflowName = computed(() => workflowStore.activeWorkflow?.filename);
    const isBlueprint = computed(
      () => useSubgraphStore().isSubgraphBlueprint(workflowStore.activeWorkflow)
    );
    const collapseTabs = ref(false);
    const overflowingTabs = ref(false);
    const breadcrumbElement = computed(() => {
      if (!breadcrumbRef.value) return null;
      const el = breadcrumbRef.value.$el;
      const list = el?.querySelector(".p-breadcrumb-list");
      return list;
    });
    const items = computed(() => {
      const items2 = navigationStore.navigationStack.map((subgraph) => ({
        label: subgraph.name,
        command: /* @__PURE__ */ __name(() => {
          const canvas = useCanvasStore().getCanvas();
          if (!canvas.graph) throw new TypeError("Canvas has no graph");
          canvas.setGraph(subgraph);
        }, "command"),
        updateTitle: /* @__PURE__ */ __name((title) => {
          const rootGraph = useCanvasStore().getCanvas().graph?.rootGraph;
          if (!rootGraph) return;
          forEachSubgraphNode(rootGraph, subgraph.id, (node) => {
            node.title = title;
          });
        }, "updateTitle")
      }));
      return [home.value, ...items2];
    });
    const home = computed(() => ({
      label: workflowName.value,
      icon: "pi pi-home",
      key: "root",
      isBlueprint: isBlueprint.value,
      command: /* @__PURE__ */ __name(() => {
        const canvas = useCanvasStore().getCanvas();
        if (!canvas.graph) throw new TypeError("Canvas has no graph");
        canvas.setGraph(canvas.graph.rootGraph);
      }, "command")
    }));
    let overflowObserver;
    watch(breadcrumbElement, (el) => {
      overflowObserver?.dispose();
      overflowObserver = void 0;
      if (!el) return;
      overflowObserver = useOverflowObserver(el, {
        onCheck: /* @__PURE__ */ __name((isOverflowing) => {
          overflowingTabs.value = isOverflowing;
          if (collapseTabs.value) {
            if (!isOverflowing) {
              const items2 = [
                ...el.querySelectorAll(".p-breadcrumb-item")
              ];
              if (items2.length < 3) return;
              const itemsWithIcon = items2.filter(
                (item) => item.querySelector(".p-breadcrumb-item-link-icon-visible")
              ).length;
              const separators = el.querySelectorAll(
                ".p-breadcrumb-separator"
              );
              const separator = separators[separators.length - 1];
              const separatorWidth = separator.offsetWidth;
              const itemsWidth = (MIN_WIDTH + ITEM_PADDING + ITEM_PADDING) * items2.length + itemsWithIcon * ICON_WIDTH;
              const separatorsWidth = (items2.length - 1) * separatorWidth;
              const gapsWidth = (items2.length - 1) * (ITEM_GAP * 2);
              const totalWidth = itemsWidth + separatorsWidth + gapsWidth;
              const containerWidth = el.clientWidth;
              if (totalWidth <= containerWidth) {
                collapseTabs.value = false;
              }
            }
          } else if (isOverflowing) {
            collapseTabs.value = true;
          }
        }, "onCheck")
      });
    });
    onUpdated(() => {
      if (!overflowObserver?.disposed.value) {
        overflowObserver?.checkOverflow();
      }
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: normalizeClass(["subgraph-breadcrumb w-auto drop-shadow-[var(--interface-panel-drop-shadow)]", {
          "subgraph-breadcrumb-collapse": collapseTabs.value,
          "subgraph-breadcrumb-overflow": overflowingTabs.value
        }]),
        style: normalizeStyle({
          "--p-breadcrumb-gap": `0px`,
          "--p-breadcrumb-item-margin": `${ITEM_GAP / 2}px`,
          "--p-breadcrumb-item-min-width": `${MIN_WIDTH}px`,
          "--p-breadcrumb-item-padding": `${ITEM_PADDING}px`,
          "--p-breadcrumb-icon-width": `${ICON_WIDTH}px`
        })
      }, [
        createVNode(unref(script$9), {
          ref_key: "breadcrumbRef",
          ref: breadcrumbRef,
          class: "w-fit rounded-lg p-0",
          model: items.value,
          pt: { item: { class: "pointer-events-auto" } },
          "aria-label": _ctx.$t("g.graphNavigation")
        }, {
          item: withCtx(({ item }) => [
            createVNode(SubgraphBreadcrumbItem, {
              item,
              "is-active": item === items.value.at(-1)
            }, null, 8, ["item", "is-active"])
          ]),
          separator: withCtx(() => _cache[0] || (_cache[0] = [
            createBaseVNode("span", { style: { "transform": "scale(1.5)" } }, " / ", -1)
          ])),
          _: 1
        }, 8, ["model", "aria-label"])
      ], 6);
    };
  }
});
const SubgraphBreadcrumb = /* @__PURE__ */ _export_sfc(_sfc_main$1z, [["__scopeId", "data-v-0e6867de"]]);
const _hoisted_1$15 = { class: "flex flex-col gap-3 p-2" };
const _hoisted_2$P = { class: "flex flex-col gap-1" };
const _hoisted_3$F = { class: "relative h-2 w-full overflow-hidden rounded-full border border-interface-stroke bg-interface-panel-surface" };
const _hoisted_4$y = { class: "flex items-start justify-end gap-4 text-[12px] leading-none" };
const _hoisted_5$u = { class: "flex items-center gap-1 text-text-primary opacity-90" };
const _hoisted_6$s = { class: "font-bold" };
const _hoisted_7$n = { class: "flex items-center gap-1 text-text-secondary" };
const _hoisted_8$i = { class: "inline-block max-w-[10rem] truncate" };
const _hoisted_9$d = { class: "flex items-center gap-1" };
const _hoisted_10$d = { class: "flex items-center gap-4 text-[12px] text-text-primary" };
const _hoisted_11$9 = { class: "flex items-center gap-2" };
const _hoisted_12$7 = { class: "opacity-90" };
const _hoisted_13$6 = { class: "font-bold" };
const _hoisted_14$6 = { class: "ml-1" };
const _hoisted_15$5 = { class: "flex items-center gap-2" };
const _hoisted_16$4 = { class: "opacity-90" };
const _hoisted_17$2 = { class: "font-bold" };
const _hoisted_18$2 = { class: "ml-1" };
const _sfc_main$1y = /* @__PURE__ */ defineComponent({
  __name: "QueueOverlayActive",
  props: {
    totalProgressStyle: {},
    currentNodeProgressStyle: {},
    totalPercentFormatted: {},
    currentNodePercentFormatted: {},
    currentNodeName: {},
    runningCount: {},
    queuedCount: {},
    bottomRowClass: {}
  },
  emits: ["interruptAll", "clearQueued", "viewAllJobs"],
  setup(__props) {
    const { t: t2 } = useI18n();
    const cancelJobTooltip = computed(
      () => buildTooltipConfig(t2("sideToolbar.queueProgressOverlay.cancelJobTooltip"))
    );
    const clearQueueTooltip = computed(
      () => buildTooltipConfig(t2("sideToolbar.queueProgressOverlay.clearQueueTooltip"))
    );
    return (_ctx, _cache) => {
      const _component_i18n_t = resolveComponent("i18n-t");
      const _directive_tooltip = resolveDirective("tooltip");
      return openBlock(), createElementBlock("div", _hoisted_1$15, [
        createBaseVNode("div", _hoisted_2$P, [
          createBaseVNode("div", _hoisted_3$F, [
            createBaseVNode("div", {
              class: "absolute inset-0 h-full rounded-full transition-[width]",
              style: normalizeStyle(_ctx.totalProgressStyle)
            }, null, 4),
            createBaseVNode("div", {
              class: "absolute inset-0 h-full rounded-full transition-[width]",
              style: normalizeStyle(_ctx.currentNodeProgressStyle)
            }, null, 4)
          ]),
          createBaseVNode("div", _hoisted_4$y, [
            createBaseVNode("div", _hoisted_5$u, [
              createVNode(_component_i18n_t, { keypath: "sideToolbar.queueProgressOverlay.total" }, {
                percent: withCtx(() => [
                  createBaseVNode("span", _hoisted_6$s, toDisplayString(_ctx.totalPercentFormatted), 1)
                ]),
                _: 1
              })
            ]),
            createBaseVNode("div", _hoisted_7$n, [
              createBaseVNode("span", null, toDisplayString(unref(t2)("sideToolbar.queueProgressOverlay.currentNode")), 1),
              createBaseVNode("span", _hoisted_8$i, toDisplayString(_ctx.currentNodeName), 1),
              createBaseVNode("span", _hoisted_9$d, [
                createBaseVNode("span", null, toDisplayString(_ctx.currentNodePercentFormatted), 1)
              ])
            ])
          ])
        ]),
        createBaseVNode("div", {
          class: normalizeClass(_ctx.bottomRowClass)
        }, [
          createBaseVNode("div", _hoisted_10$d, [
            createBaseVNode("div", _hoisted_11$9, [
              createBaseVNode("span", _hoisted_12$7, [
                createBaseVNode("span", _hoisted_13$6, toDisplayString(_ctx.runningCount), 1),
                createBaseVNode("span", _hoisted_14$6, toDisplayString(unref(t2)("sideToolbar.queueProgressOverlay.running")), 1)
              ]),
              _ctx.runningCount > 0 ? withDirectives((openBlock(), createBlock(_sfc_main$1Y, {
                key: 0,
                variant: "destructive",
                size: "icon",
                "aria-label": unref(t2)("sideToolbar.queueProgressOverlay.interruptAll"),
                onClick: _cache[0] || (_cache[0] = ($event) => _ctx.$emit("interruptAll"))
              }, {
                default: withCtx(() => _cache[3] || (_cache[3] = [
                  createBaseVNode("i", { class: "icon-[lucide--x] block size-4 leading-none text-text-primary" }, null, -1)
                ])),
                _: 1
              }, 8, ["aria-label"])), [
                [
                  _directive_tooltip,
                  cancelJobTooltip.value,
                  void 0,
                  { top: true }
                ]
              ]) : createCommentVNode("", true)
            ]),
            createBaseVNode("div", _hoisted_15$5, [
              createBaseVNode("span", _hoisted_16$4, [
                createBaseVNode("span", _hoisted_17$2, toDisplayString(_ctx.queuedCount), 1),
                createBaseVNode("span", _hoisted_18$2, toDisplayString(unref(t2)("sideToolbar.queueProgressOverlay.queuedSuffix")), 1)
              ]),
              _ctx.queuedCount > 0 ? withDirectives((openBlock(), createBlock(_sfc_main$1Y, {
                key: 0,
                variant: "destructive",
                size: "icon",
                "aria-label": unref(t2)("sideToolbar.queueProgressOverlay.clearQueued"),
                onClick: _cache[1] || (_cache[1] = ($event) => _ctx.$emit("clearQueued"))
              }, {
                default: withCtx(() => _cache[4] || (_cache[4] = [
                  createBaseVNode("i", { class: "icon-[lucide--list-x] block size-4 leading-none text-text-primary" }, null, -1)
                ])),
                _: 1
              }, 8, ["aria-label"])), [
                [
                  _directive_tooltip,
                  clearQueueTooltip.value,
                  void 0,
                  { top: true }
                ]
              ]) : createCommentVNode("", true)
            ])
          ]),
          createVNode(_sfc_main$1Y, {
            class: "min-w-30 flex-1 px-2 py-0",
            variant: "secondary",
            size: "md",
            onClick: _cache[2] || (_cache[2] = ($event) => _ctx.$emit("viewAllJobs"))
          }, {
            default: withCtx(() => [
              createTextVNode(toDisplayString(unref(t2)("sideToolbar.queueProgressOverlay.viewAllJobs")), 1)
            ]),
            _: 1
          })
        ], 2)
      ]);
    };
  }
});
const _hoisted_1$14 = { class: "inline-flex items-center gap-2" };
const _hoisted_2$O = {
  key: 0,
  class: "inline-flex items-center"
};
const _hoisted_3$E = { class: "inline-flex items-center gap-2" };
const _hoisted_4$x = {
  key: 0,
  class: "relative inline-flex h-6 items-center"
};
const _hoisted_5$t = ["src", "alt"];
const _hoisted_6$r = { class: "text-[14px] font-normal text-text-primary" };
const _hoisted_7$m = { class: "font-bold" };
const _hoisted_8$h = { class: "font-bold" };
const _hoisted_9$c = { class: "font-bold" };
const _hoisted_10$c = { class: "font-bold" };
const _sfc_main$1x = /* @__PURE__ */ defineComponent({
  __name: "CompletionSummaryBanner",
  props: {
    mode: {},
    completedCount: {},
    failedCount: {},
    thumbnailUrls: { default: /* @__PURE__ */ __name(() => [], "default") },
    ariaLabel: {}
  },
  emits: ["click"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    return (_ctx, _cache) => {
      const _component_i18n_t = resolveComponent("i18n-t");
      return openBlock(), createBlock(_sfc_main$1Y, {
        variant: "secondary",
        size: "lg",
        class: "group w-full justify-between gap-3 p-1 text-left font-normal hover:cursor-pointer focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary-background",
        "aria-label": props.ariaLabel,
        onClick: _cache[0] || (_cache[0] = ($event) => emit("click", $event))
      }, {
        default: withCtx(() => [
          createBaseVNode("span", _hoisted_1$14, [
            props.mode === "allFailed" ? (openBlock(), createElementBlock("span", _hoisted_2$O, _cache[1] || (_cache[1] = [
              createBaseVNode("i", { class: "ml-1 icon-[lucide--circle-alert] block size-4 leading-none text-destructive-background" }, null, -1)
            ]))) : createCommentVNode("", true),
            createBaseVNode("span", _hoisted_3$E, [
              props.mode !== "allFailed" ? (openBlock(), createElementBlock("span", _hoisted_4$x, [
                (openBlock(true), createElementBlock(Fragment, null, renderList(props.thumbnailUrls, (url, idx) => {
                  return openBlock(), createElementBlock("span", {
                    key: url + idx,
                    class: "inline-block h-6 w-6 overflow-hidden rounded-[6px] border-0 bg-secondary-background",
                    style: normalizeStyle({ marginLeft: idx === 0 ? "0" : "-12px" })
                  }, [
                    createBaseVNode("img", {
                      src: url,
                      alt: _ctx.$t("sideToolbar.queueProgressOverlay.preview"),
                      class: "h-full w-full object-cover"
                    }, null, 8, _hoisted_5$t)
                  ], 4);
                }), 128))
              ])) : createCommentVNode("", true),
              createBaseVNode("span", _hoisted_6$r, [
                props.mode === "allSuccess" ? (openBlock(), createBlock(_component_i18n_t, {
                  key: 0,
                  keypath: "sideToolbar.queueProgressOverlay.jobsCompleted",
                  plural: props.completedCount
                }, {
                  count: withCtx(() => [
                    createBaseVNode("span", _hoisted_7$m, toDisplayString(props.completedCount), 1)
                  ]),
                  _: 1
                }, 8, ["plural"])) : props.mode === "mixed" ? (openBlock(), createElementBlock(Fragment, { key: 1 }, [
                  createVNode(_component_i18n_t, {
                    keypath: "sideToolbar.queueProgressOverlay.jobsCompleted",
                    plural: props.completedCount
                  }, {
                    count: withCtx(() => [
                      createBaseVNode("span", _hoisted_8$h, toDisplayString(props.completedCount), 1)
                    ]),
                    _: 1
                  }, 8, ["plural"]),
                  _cache[2] || (_cache[2] = createBaseVNode("span", null, ", ", -1)),
                  createVNode(_component_i18n_t, {
                    keypath: "sideToolbar.queueProgressOverlay.jobsFailed",
                    plural: props.failedCount
                  }, {
                    count: withCtx(() => [
                      createBaseVNode("span", _hoisted_9$c, toDisplayString(props.failedCount), 1)
                    ]),
                    _: 1
                  }, 8, ["plural"])
                ], 64)) : (openBlock(), createBlock(_component_i18n_t, {
                  key: 2,
                  keypath: "sideToolbar.queueProgressOverlay.jobsFailed",
                  plural: props.failedCount
                }, {
                  count: withCtx(() => [
                    createBaseVNode("span", _hoisted_10$c, toDisplayString(props.failedCount), 1)
                  ]),
                  _: 1
                }, 8, ["plural"]))
              ])
            ])
          ]),
          _cache[3] || (_cache[3] = createBaseVNode("span", { class: "flex items-center justify-center rounded p-1 text-text-secondary transition-colors duration-200 ease-in-out" }, [
            createBaseVNode("i", { class: "icon-[lucide--chevron-down] block size-4 leading-none" })
          ], -1))
        ]),
        _: 1
      }, 8, ["aria-label"]);
    };
  }
});
const _hoisted_1$13 = { class: "pointer-events-auto" };
const _sfc_main$1w = /* @__PURE__ */ defineComponent({
  __name: "QueueOverlayEmpty",
  props: {
    summary: {}
  },
  emits: ["summaryClick"],
  setup(__props) {
    const { t: t2 } = useI18n();
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$13, [
        createVNode(_sfc_main$1x, {
          mode: _ctx.summary.mode,
          "completed-count": _ctx.summary.completedCount,
          "failed-count": _ctx.summary.failedCount,
          "thumbnail-urls": _ctx.summary.thumbnailUrls,
          "aria-label": unref(t2)("sideToolbar.queueProgressOverlay.expandCollapsedQueue"),
          onClick: _cache[0] || (_cache[0] = ($event) => _ctx.$emit("summaryClick"))
        }, null, 8, ["mode", "completed-count", "failed-count", "thumbnail-urls", "aria-label"])
      ]);
    };
  }
});
function useJobMenu(currentMenuItem, onInspectAsset) {
  const workflowStore = useWorkflowStore();
  const workflowService = useWorkflowService();
  const queueStore = useQueueStore();
  const { copyToClipboard } = useCopyToClipboard();
  const litegraphService = useLitegraphService();
  const nodeDefStore = useNodeDefStore();
  const mediaAssetActions = useMediaAssetActions();
  const openJobWorkflow = /* @__PURE__ */ __name(async () => {
    const item = currentMenuItem();
    if (!item) return;
    const data = item.taskRef?.workflow;
    if (!data) return;
    const filename = `Job ${item.id}.json`;
    const temp = workflowStore.createTemporary(filename, data);
    await workflowService.openWorkflow(temp);
  }, "openJobWorkflow");
  const copyJobId = /* @__PURE__ */ __name(async () => {
    const item = currentMenuItem();
    if (!item) return;
    await copyToClipboard(item.id);
  }, "copyJobId");
  const cancelJob = /* @__PURE__ */ __name(async () => {
    const item = currentMenuItem();
    if (!item) return;
    if (item.state === "running" || item.state === "initialization") {
      await api.interrupt(item.id);
    } else if (item.state === "pending") {
      await api.deleteItem("queue", item.id);
    }
    await queueStore.update();
  }, "cancelJob");
  const copyErrorMessage = /* @__PURE__ */ __name(async () => {
    const item = currentMenuItem();
    if (!item) return;
    const msgs = item.taskRef?.status?.messages;
    const err = msgs?.find((m) => m?.[0] === "execution_error")?.[1];
    const message = err?.exception_message;
    if (message) await copyToClipboard(String(message));
  }, "copyErrorMessage");
  const reportError = /* @__PURE__ */ __name(() => {
    const item = currentMenuItem();
    if (!item) return;
    const msgs = item.taskRef?.status?.messages;
    const err = msgs?.find((m) => m?.[0] === "execution_error")?.[1];
    if (err) useDialogService().showExecutionErrorDialog(err);
  }, "reportError");
  const addOutputLoaderNode = /* @__PURE__ */ __name(async () => {
    const item = currentMenuItem();
    if (!item) return;
    const result = item.taskRef?.previewOutput;
    if (!result) return;
    let nodeType = null;
    let widgetName = null;
    if (result.isImage) {
      nodeType = "LoadImage";
      widgetName = "image";
    } else if (result.isVideo) {
      nodeType = "LoadVideo";
      widgetName = "file";
    } else if (result.isAudio) {
      nodeType = "LoadAudio";
      widgetName = "audio";
    }
    if (!nodeType || !widgetName) return;
    const nodeDef = nodeDefStore.nodeDefsByName[nodeType];
    if (!nodeDef) return;
    const node = litegraphService.addNodeOnGraph(nodeDef, {
      pos: litegraphService.getCanvasCenter()
    });
    if (!node) return;
    const isResultItemType = /* @__PURE__ */ __name((v) => v === "input" || v === "output" || v === "temp", "isResultItemType");
    const apiItem = {
      filename: result.filename,
      subfolder: result.subfolder,
      type: isResultItemType(result.type) ? result.type : void 0
    };
    const annotated = createAnnotatedPath(apiItem, {
      rootFolder: apiItem.type
    });
    const widget = node.widgets?.find((w) => w.name === widgetName);
    if (widget) {
      widget.value = annotated;
      widget.callback?.(annotated);
    }
    node.graph?.setDirtyCanvas(true, true);
  }, "addOutputLoaderNode");
  const downloadPreviewAsset = /* @__PURE__ */ __name(() => {
    const item = currentMenuItem();
    if (!item) return;
    const result = item.taskRef?.previewOutput;
    if (!result) return;
    downloadFile(result.url);
  }, "downloadPreviewAsset");
  const exportJobWorkflow = /* @__PURE__ */ __name(async () => {
    const item = currentMenuItem();
    if (!item) return;
    const data = item.taskRef?.workflow;
    if (!data) return;
    const settingStore = useSettingStore();
    let filename = `Job ${item.id}.json`;
    if (settingStore.get("Comfy.PromptFilename")) {
      const input = await useDialogService().prompt({
        title: t("workflowService.exportWorkflow"),
        message: t("workflowService.enterFilename") + ":",
        defaultValue: filename
      });
      if (!input) return;
      filename = appendJsonExt(input);
    }
    const json = JSON.stringify(data, null, 2);
    const blob = new Blob([json], { type: "application/json" });
    downloadBlob(filename, blob);
  }, "exportJobWorkflow");
  const deleteJobAsset = /* @__PURE__ */ __name(async () => {
    const item = currentMenuItem();
    if (!item) return;
    const task = item.taskRef;
    const preview = task?.previewOutput;
    if (!task || !preview) return;
    const asset = mapTaskOutputToAssetItem(task, preview);
    const success = await mediaAssetActions.confirmDelete(asset);
    if (success) {
      await queueStore.update();
    }
  }, "deleteJobAsset");
  const removeFailedJob = /* @__PURE__ */ __name(async () => {
    const task = currentMenuItem()?.taskRef;
    if (!task) return;
    await queueStore.delete(task);
  }, "removeFailedJob");
  const jobMenuOpenWorkflowLabel = computed(
    () => st("queue.jobMenu.openAsWorkflowNewTab", "Open as workflow in new tab")
  );
  const jobMenuOpenWorkflowFailedLabel = computed(
    () => st("queue.jobMenu.openWorkflowNewTab", "Open workflow in new tab")
  );
  const jobMenuCopyJobIdLabel = computed(
    () => st("queue.jobMenu.copyJobId", "Copy job ID")
  );
  const jobMenuCancelLabel = computed(
    () => st("queue.jobMenu.cancelJob", "Cancel job")
  );
  const jobMenuEntries = computed(() => {
    const item = currentMenuItem();
    const state = item?.state;
    if (!state) return [];
    const hasDeletableAsset = !!item?.taskRef?.previewOutput;
    if (state === "completed") {
      return [
        {
          key: "inspect-asset",
          label: st("queue.jobMenu.inspectAsset", "Inspect asset"),
          icon: "icon-[lucide--zoom-in]",
          onClick: onInspectAsset ? () => {
            const item2 = currentMenuItem();
            if (item2) onInspectAsset(item2);
          } : void 0
        },
        {
          key: "add-to-current",
          label: st(
            "queue.jobMenu.addToCurrentWorkflow",
            "Add to current workflow"
          ),
          icon: "icon-[comfy--node]",
          onClick: addOutputLoaderNode
        },
        {
          key: "download",
          label: st("queue.jobMenu.download", "Download"),
          icon: "icon-[lucide--download]",
          onClick: downloadPreviewAsset
        },
        { kind: "divider", key: "d1" },
        {
          key: "open-workflow",
          label: jobMenuOpenWorkflowLabel.value,
          icon: "icon-[comfy--workflow]",
          onClick: openJobWorkflow
        },
        {
          key: "export-workflow",
          label: st("queue.jobMenu.exportWorkflow", "Export workflow"),
          icon: "icon-[comfy--file-output]",
          onClick: exportJobWorkflow
        },
        { kind: "divider", key: "d2" },
        {
          key: "copy-id",
          label: jobMenuCopyJobIdLabel.value,
          icon: "icon-[lucide--copy]",
          onClick: copyJobId
        },
        { kind: "divider", key: "d3" },
        ...hasDeletableAsset ? [
          {
            key: "delete",
            label: st("queue.jobMenu.deleteAsset", "Delete asset"),
            icon: "icon-[lucide--trash-2]",
            onClick: deleteJobAsset
          }
        ] : []
      ];
    }
    if (state === "failed") {
      return [
        {
          key: "open-workflow",
          label: jobMenuOpenWorkflowFailedLabel.value,
          icon: "icon-[comfy--workflow]",
          onClick: openJobWorkflow
        },
        { kind: "divider", key: "d1" },
        {
          key: "copy-id",
          label: jobMenuCopyJobIdLabel.value,
          icon: "icon-[lucide--copy]",
          onClick: copyJobId
        },
        {
          key: "copy-error",
          label: st("queue.jobMenu.copyErrorMessage", "Copy error message"),
          icon: "icon-[lucide--copy]",
          onClick: copyErrorMessage
        },
        {
          key: "report-error",
          label: st("queue.jobMenu.reportError", "Report error"),
          icon: "icon-[lucide--message-circle-warning]",
          onClick: reportError
        },
        { kind: "divider", key: "d2" },
        {
          key: "delete",
          label: st("queue.jobMenu.removeJob", "Remove job"),
          icon: "icon-[lucide--circle-minus]",
          onClick: removeFailedJob
        }
      ];
    }
    return [
      {
        key: "open-workflow",
        label: jobMenuOpenWorkflowLabel.value,
        icon: "icon-[comfy--workflow]",
        onClick: openJobWorkflow
      },
      { kind: "divider", key: "d1" },
      {
        key: "copy-id",
        label: jobMenuCopyJobIdLabel.value,
        icon: "icon-[lucide--copy]",
        onClick: copyJobId
      },
      { kind: "divider", key: "d2" },
      {
        key: "cancel-job",
        label: jobMenuCancelLabel.value,
        icon: "icon-[lucide--x]",
        onClick: cancelJob
      }
    ];
  });
  return {
    jobMenuEntries,
    openJobWorkflow,
    copyJobId,
    cancelJob
  };
}
__name(useJobMenu, "useJobMenu");
const _hoisted_1$12 = { class: "flex h-12 items-center justify-between gap-2 border-b border-interface-stroke px-2" };
const _hoisted_2$N = { class: "px-2 text-[14px] font-normal text-text-primary" };
const _hoisted_3$D = {
  key: 0,
  class: "ml-4 inline-flex items-center gap-1 text-blue-100"
};
const _hoisted_4$w = { class: "font-bold" };
const _hoisted_5$s = { class: "ml-1" };
const _hoisted_6$q = {
  key: 0,
  class: "flex items-center gap-1"
};
const _hoisted_7$l = { class: "flex flex-col items-stretch rounded-lg border border-interface-stroke bg-interface-panel-surface px-2 py-3 font-inter" };
const _sfc_main$1v = /* @__PURE__ */ defineComponent({
  __name: "QueueOverlayHeader",
  props: {
    headerTitle: {},
    showConcurrentIndicator: { type: Boolean },
    concurrentWorkflowCount: {}
  },
  emits: ["clearHistory"],
  setup(__props, { emit: __emit }) {
    const emit = __emit;
    const { t: t2 } = useI18n();
    const morePopoverRef = ref(null);
    const moreTooltipConfig = computed(() => buildTooltipConfig(t2("g.more")));
    const onMoreClick = /* @__PURE__ */ __name((event) => {
      morePopoverRef.value?.toggle(event);
    }, "onMoreClick");
    const onClearHistoryFromMenu = /* @__PURE__ */ __name(() => {
      morePopoverRef.value?.hide();
      emit("clearHistory");
    }, "onClearHistoryFromMenu");
    return (_ctx, _cache) => {
      const _directive_tooltip = resolveDirective("tooltip");
      return openBlock(), createElementBlock("div", _hoisted_1$12, [
        createBaseVNode("div", _hoisted_2$N, [
          createBaseVNode("span", null, toDisplayString(_ctx.headerTitle), 1),
          _ctx.showConcurrentIndicator ? (openBlock(), createElementBlock("span", _hoisted_3$D, [
            _cache[0] || (_cache[0] = createBaseVNode("span", { class: "inline-block size-2 rounded-full bg-blue-100" }, null, -1)),
            createBaseVNode("span", null, [
              createBaseVNode("span", _hoisted_4$w, toDisplayString(_ctx.concurrentWorkflowCount), 1),
              createBaseVNode("span", _hoisted_5$s, toDisplayString(unref(t2)("sideToolbar.queueProgressOverlay.running")), 1)
            ])
          ])) : createCommentVNode("", true)
        ]),
        !unref(isCloud) ? (openBlock(), createElementBlock("div", _hoisted_6$q, [
          withDirectives((openBlock(), createBlock(_sfc_main$1Y, {
            variant: "textonly",
            size: "icon",
            "aria-label": unref(t2)("sideToolbar.queueProgressOverlay.moreOptions"),
            onClick: onMoreClick
          }, {
            default: withCtx(() => _cache[1] || (_cache[1] = [
              createBaseVNode("i", { class: "icon-[lucide--more-horizontal] block size-4 leading-none text-text-secondary" }, null, -1)
            ])),
            _: 1
          }, 8, ["aria-label"])), [
            [
              _directive_tooltip,
              moreTooltipConfig.value,
              void 0,
              { top: true }
            ]
          ]),
          createVNode(unref(script$1), {
            ref_key: "morePopoverRef",
            ref: morePopoverRef,
            dismissable: true,
            "close-on-escape": true,
            unstyled: "",
            pt: {
              root: { class: "absolute z-50" },
              content: {
                class: [
                  "bg-transparent border-none p-0 pt-2 rounded-lg shadow-lg font-inter"
                ]
              }
            }
          }, {
            default: withCtx(() => [
              createBaseVNode("div", _hoisted_7$l, [
                createVNode(_sfc_main$1Y, {
                  class: "w-full justify-start",
                  variant: "textonly",
                  size: "sm",
                  "aria-label": unref(t2)("sideToolbar.queueProgressOverlay.clearHistory"),
                  onClick: onClearHistoryFromMenu
                }, {
                  default: withCtx(() => [
                    _cache[2] || (_cache[2] = createBaseVNode("i", { class: "icon-[lucide--file-x-2] size-4 text-muted" }, null, -1)),
                    createBaseVNode("span", null, toDisplayString(unref(t2)("sideToolbar.queueProgressOverlay.clearHistory")), 1)
                  ]),
                  _: 1
                }, 8, ["aria-label"])
              ])
            ]),
            _: 1
          }, 512)
        ])) : createCommentVNode("", true)
      ]);
    };
  }
});
const _hoisted_1$11 = { class: "flex min-w-[14rem] flex-col items-stretch rounded-lg border border-interface-stroke bg-interface-panel-surface px-2 py-3 font-inter" };
const _hoisted_2$M = {
  key: 0,
  class: "px-2 py-1"
};
const _sfc_main$1u = /* @__PURE__ */ defineComponent({
  __name: "JobContextMenu",
  props: {
    entries: {}
  },
  emits: ["action"],
  setup(__props, { expose: __expose, emit: __emit }) {
    const emit = __emit;
    const jobItemPopoverRef = ref(null);
    function open(event) {
      if (jobItemPopoverRef.value) {
        jobItemPopoverRef.value.toggle(event);
      }
    }
    __name(open, "open");
    function hide() {
      jobItemPopoverRef.value?.hide();
    }
    __name(hide, "hide");
    function onEntry(entry) {
      emit("action", entry);
    }
    __name(onEntry, "onEntry");
    __expose({ open, hide });
    return (_ctx, _cache) => {
      return openBlock(), createBlock(unref(script$1), {
        ref_key: "jobItemPopoverRef",
        ref: jobItemPopoverRef,
        dismissable: true,
        "close-on-escape": true,
        unstyled: "",
        pt: {
          root: { class: "absolute z-50" },
          content: {
            class: [
              "bg-transparent border-none p-0 pt-2 rounded-lg shadow-lg font-inter"
            ]
          }
        }
      }, {
        default: withCtx(() => [
          createBaseVNode("div", _hoisted_1$11, [
            (openBlock(true), createElementBlock(Fragment, null, renderList(_ctx.entries, (entry) => {
              return openBlock(), createElementBlock(Fragment, {
                key: entry.key
              }, [
                entry.kind === "divider" ? (openBlock(), createElementBlock("div", _hoisted_2$M, _cache[0] || (_cache[0] = [
                  createBaseVNode("div", { class: "h-px bg-interface-stroke" }, null, -1)
                ]))) : (openBlock(), createBlock(_sfc_main$1Y, {
                  key: 1,
                  class: "w-full justify-start bg-transparent",
                  variant: "textonly",
                  size: "sm",
                  "aria-label": entry.label,
                  onClick: /* @__PURE__ */ __name(($event) => onEntry(entry), "onClick")
                }, {
                  default: withCtx(() => [
                    entry.icon ? (openBlock(), createElementBlock("i", {
                      key: 0,
                      class: normalizeClass([
                        entry.icon,
                        "block size-4 shrink-0 leading-none text-text-secondary"
                      ])
                    }, null, 2)) : createCommentVNode("", true),
                    createBaseVNode("span", null, toDisplayString(entry.label), 1)
                  ]),
                  _: 2
                }, 1032, ["aria-label", "onClick"]))
              ], 64);
            }), 128))
          ])
        ]),
        _: 1
      }, 512);
    };
  }
});
const clampPercentInt = /* @__PURE__ */ __name((value) => {
  const v = Math.round(value ?? 0);
  return clamp$1(v, 0, 100);
}, "clampPercentInt");
const formatPercent0 = /* @__PURE__ */ __name((locale, value0to100) => {
  const v = clampPercentInt(value0to100);
  return new Intl.NumberFormat(locale, {
    style: "percent",
    maximumFractionDigits: 0
  }).format((v || 0) / 100);
}, "formatPercent0");
function useQueueProgress() {
  const { locale } = useI18n();
  const executionStore = useExecutionStore();
  const totalPercent = computed(
    () => clampPercentInt(Math.round((executionStore.executionProgress ?? 0) * 100))
  );
  const totalPercentFormatted = computed(
    () => formatPercent0(locale.value, totalPercent.value)
  );
  const currentNodePercent = computed(
    () => clampPercentInt(
      Math.round((executionStore.executingNodeProgress ?? 0) * 100)
    )
  );
  const currentNodePercentFormatted = computed(
    () => formatPercent0(locale.value, currentNodePercent.value)
  );
  const totalProgressStyle = computed(() => ({
    width: `${totalPercent.value}%`,
    background: "var(--color-interface-panel-job-progress-primary)"
  }));
  const currentNodeProgressStyle = computed(() => ({
    width: `${currentNodePercent.value}%`,
    background: "var(--color-interface-panel-job-progress-secondary)"
  }));
  return {
    totalPercent,
    totalPercentFormatted,
    currentNodePercent,
    currentNodePercentFormatted,
    totalProgressStyle,
    currentNodeProgressStyle
  };
}
__name(useQueueProgress, "useQueueProgress");
const dateKey = /* @__PURE__ */ __name((ts) => {
  const d2 = new Date(ts);
  const y = d2.getFullYear();
  const m = String(d2.getMonth() + 1).padStart(2, "0");
  const day = String(d2.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}, "dateKey");
const isToday = /* @__PURE__ */ __name((ts) => {
  const d2 = new Date(ts);
  const now = /* @__PURE__ */ new Date();
  return d2.getFullYear() === now.getFullYear() && d2.getMonth() === now.getMonth() && d2.getDate() === now.getDate();
}, "isToday");
const isYesterday = /* @__PURE__ */ __name((ts) => {
  const d2 = new Date(ts);
  const now = /* @__PURE__ */ new Date();
  const yest = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 1);
  return d2.getFullYear() === yest.getFullYear() && d2.getMonth() === yest.getMonth() && d2.getDate() === yest.getDate();
}, "isYesterday");
const formatShortMonthDay = /* @__PURE__ */ __name((ts, locale) => {
  const d2 = new Date(ts);
  return new Intl.DateTimeFormat(locale, {
    month: "short",
    day: "numeric"
  }).format(d2);
}, "formatShortMonthDay");
const formatClockTime = /* @__PURE__ */ __name((ts, locale) => {
  const d2 = new Date(ts);
  return new Intl.DateTimeFormat(locale, {
    hour: "numeric",
    minute: "2-digit",
    second: "2-digit"
  }).format(d2);
}, "formatClockTime");
const iconForJobState = /* @__PURE__ */ __name((state) => {
  switch (state) {
    case "pending":
      return "icon-[lucide--loader-circle]";
    case "initialization":
      return "icon-[lucide--server-crash]";
    case "running":
      return "icon-[lucide--zap]";
    case "completed":
      return "icon-[lucide--check-check]";
    case "failed":
      return "icon-[lucide--alert-circle]";
    default:
      return "icon-[lucide--circle]";
  }
}, "iconForJobState");
const buildTitle = /* @__PURE__ */ __name((task, t2) => {
  const prefix = t2("g.job");
  const shortId = String(task.promptId ?? "").split("-")[0];
  const idx = task.queueIndex;
  if (typeof idx === "number") return `${prefix} #${idx}`;
  if (shortId) return `${prefix} ${shortId}`;
  return prefix;
}, "buildTitle");
const buildQueuedTime = /* @__PURE__ */ __name((task, locale, formatClockTimeFn) => {
  const ts = task.createTime;
  return ts !== void 0 ? formatClockTimeFn(ts, locale) : "";
}, "buildQueuedTime");
const buildJobDisplay = /* @__PURE__ */ __name((task, state, ctx) => {
  if (state === "pending") {
    if (ctx.showAddedHint) {
      return {
        iconName: "icon-[lucide--check]",
        primary: ctx.t("queue.jobAddedToQueue"),
        secondary: buildQueuedTime(task, ctx.locale, ctx.formatClockTimeFn),
        showClear: true
      };
    }
    return {
      iconName: iconForJobState(state),
      primary: ctx.t("queue.inQueue"),
      secondary: buildQueuedTime(task, ctx.locale, ctx.formatClockTimeFn),
      showClear: true
    };
  }
  if (state === "initialization") {
    return {
      iconName: iconForJobState(state),
      primary: ctx.t("queue.initializingAlmostReady"),
      secondary: buildQueuedTime(task, ctx.locale, ctx.formatClockTimeFn),
      showClear: true
    };
  }
  if (state === "running") {
    if (ctx.isActive) {
      const total = formatPercent0(
        ctx.locale,
        clampPercentInt(ctx.totalPercent)
      );
      const curr = formatPercent0(
        ctx.locale,
        clampPercentInt(ctx.currentNodePercent)
      );
      const primary = ctx.t("sideToolbar.queueProgressOverlay.total", {
        percent: total
      });
      const right = ctx.currentNodeName ? `${ctx.currentNodeName} ${ctx.t(
        "sideToolbar.queueProgressOverlay.colonPercent",
        { percent: curr }
      )}` : "";
      return {
        iconName: iconForJobState(state),
        primary,
        secondary: right,
        showClear: true
      };
    }
    return {
      iconName: iconForJobState(state),
      primary: ctx.t("g.running"),
      secondary: "",
      showClear: true
    };
  }
  if (state === "completed") {
    const time = task.executionTimeInSeconds;
    const preview = task.previewOutput;
    const iconImageUrl = preview && preview.isImage ? preview.url : void 0;
    const primary = ctx.isCloud ? ctx.t("queue.completedIn", {
      duration: formatDuration(task.executionTime ?? 0)
    }) : preview?.filename && preview.filename.length ? preview.filename : buildTitle(task, ctx.t);
    return {
      iconName: iconForJobState(state),
      iconImageUrl,
      primary,
      secondary: time !== void 0 ? `${time.toFixed(2)}s` : "",
      showClear: false
    };
  }
  if (state === "failed") {
    return {
      iconName: iconForJobState(state),
      primary: ctx.t("g.failed"),
      secondary: ctx.t("g.failed"),
      showClear: true
    };
  }
  return {
    iconName: iconForJobState(state),
    primary: buildTitle(task, ctx.t),
    secondary: "",
    showClear: true
  };
}, "buildJobDisplay");
const jobStateFromTask = /* @__PURE__ */ __name((task, isInitializing) => {
  if (isInitializing) return "initialization";
  const status = task.displayStatus;
  switch (status) {
    case "Running":
      return "running";
    case "Pending":
      return "pending";
    case "Completed":
      return "completed";
    case "Failed":
    case "Cancelled":
      return "failed";
  }
  return "failed";
}, "jobStateFromTask");
const jobTabs = ["All", "Completed", "Failed"];
const jobSortModes = ["mostRecent", "totalGenerationTime"];
const ADDED_HINT_DURATION_MS = 3e3;
const relativeTimeFormatterCache = /* @__PURE__ */ new Map();
const taskIdToKey = /* @__PURE__ */ __name((id) => {
  if (id === null || id === void 0) return null;
  const key = String(id);
  return key.length ? key : null;
}, "taskIdToKey");
const dateLabelForTimestamp = /* @__PURE__ */ __name((ts, locale, relativeFormatter) => {
  const formatRelativeDay = /* @__PURE__ */ __name((value) => {
    const formatted = relativeFormatter.format(value, "day");
    return formatted ? formatted[0].toLocaleUpperCase(locale) + formatted.slice(1) : formatted;
  }, "formatRelativeDay");
  if (isToday(ts)) {
    return formatRelativeDay(0);
  }
  if (isYesterday(ts)) {
    return formatRelativeDay(-1);
  }
  return formatShortMonthDay(ts, locale);
}, "dateLabelForTimestamp");
function useJobList() {
  const { t: t2, locale } = useI18n();
  const queueStore = useQueueStore();
  const executionStore = useExecutionStore();
  const workflowStore = useWorkflowStore();
  const seenPendingIds = ref(/* @__PURE__ */ new Set());
  const recentlyAddedPendingIds = ref(/* @__PURE__ */ new Set());
  const addedHintTimeouts = /* @__PURE__ */ new Map();
  const clearAddedHintTimeout = /* @__PURE__ */ __name((id) => {
    const timeoutId = addedHintTimeouts.get(id);
    if (timeoutId !== void 0) {
      clearTimeout(timeoutId);
      addedHintTimeouts.delete(id);
    }
  }, "clearAddedHintTimeout");
  const scheduleAddedHintExpiry = /* @__PURE__ */ __name((id) => {
    clearAddedHintTimeout(id);
    const timeoutId = setTimeout(() => {
      addedHintTimeouts.delete(id);
      const updated = new Set(recentlyAddedPendingIds.value);
      if (updated.delete(id)) {
        recentlyAddedPendingIds.value = updated;
      }
    }, ADDED_HINT_DURATION_MS);
    addedHintTimeouts.set(id, timeoutId);
  }, "scheduleAddedHintExpiry");
  watch(
    () => queueStore.pendingTasks.map((task) => taskIdToKey(task.promptId)).filter((id) => !!id),
    (pendingIds) => {
      const pendingSet = new Set(pendingIds);
      const nextAdded = new Set(recentlyAddedPendingIds.value);
      const nextSeen = new Set(seenPendingIds.value);
      pendingIds.forEach((id) => {
        if (!nextSeen.has(id)) {
          nextSeen.add(id);
          nextAdded.add(id);
          scheduleAddedHintExpiry(id);
        }
      });
      for (const id of Array.from(nextSeen)) {
        if (!pendingSet.has(id)) {
          nextSeen.delete(id);
          nextAdded.delete(id);
          clearAddedHintTimeout(id);
        }
      }
      recentlyAddedPendingIds.value = nextAdded;
      seenPendingIds.value = nextSeen;
    },
    { immediate: true }
  );
  const shouldShowAddedHint = /* @__PURE__ */ __name((task, state) => {
    if (state !== "pending") return false;
    const id = taskIdToKey(task.promptId);
    if (!id) return false;
    return recentlyAddedPendingIds.value.has(id);
  }, "shouldShowAddedHint");
  onUnmounted(() => {
    addedHintTimeouts.forEach((timeoutId) => clearTimeout(timeoutId));
    addedHintTimeouts.clear();
    seenPendingIds.value = /* @__PURE__ */ new Set();
    recentlyAddedPendingIds.value = /* @__PURE__ */ new Set();
  });
  const { totalPercent, currentNodePercent } = useQueueProgress();
  const relativeTimeFormatter = computed(() => {
    const localeValue = locale.value;
    let formatter = relativeTimeFormatterCache.get(localeValue);
    if (!formatter) {
      formatter = new Intl.RelativeTimeFormat(localeValue, { numeric: "auto" });
      relativeTimeFormatterCache.set(localeValue, formatter);
    }
    return formatter;
  });
  const undatedLabel = computed(() => t2("queue.jobList.undated") || "Undated");
  const isJobInitializing = /* @__PURE__ */ __name((promptId) => executionStore.isPromptInitializing(promptId), "isJobInitializing");
  const currentNodeName = computed(() => {
    const node = executionStore.executingNode;
    if (!node) return t2("g.emDash");
    const title = (node.title ?? "").toString().trim();
    if (title) return title;
    const nodeType = (node.type ?? "").toString().trim() || t2("g.untitled");
    const key = `nodeDefs.${normalizeI18nKey(nodeType)}.display_name`;
    return st(key, nodeType);
  });
  const selectedJobTab = ref("All");
  const selectedWorkflowFilter = ref("all");
  const selectedSortMode = ref("mostRecent");
  const allTasksSorted = computed(() => {
    const all = [
      ...queueStore.pendingTasks,
      ...queueStore.runningTasks,
      ...queueStore.historyTasks
    ];
    return all.sort((a, b) => b.queueIndex - a.queueIndex);
  });
  const tasksWithJobState = computed(
    () => allTasksSorted.value.map((task) => ({
      task,
      state: jobStateFromTask(task, isJobInitializing(task?.promptId))
    }))
  );
  const hasFailedJobs = computed(
    () => tasksWithJobState.value.some(({ state }) => state === "failed")
  );
  watch(
    () => hasFailedJobs.value,
    (hasFailed) => {
      if (!hasFailed && selectedJobTab.value === "Failed") {
        selectedJobTab.value = "All";
      }
    }
  );
  const filteredTaskEntries = computed(() => {
    let entries = tasksWithJobState.value;
    if (selectedJobTab.value === "Completed") {
      entries = entries.filter(({ state }) => state === "completed");
    } else if (selectedJobTab.value === "Failed") {
      entries = entries.filter(({ state }) => state === "failed");
    }
    if (selectedWorkflowFilter.value === "current") {
      const activeId = workflowStore.activeWorkflow?.activeState?.id;
      if (!activeId) return [];
      entries = entries.filter(({ task }) => {
        const wid = task.workflow?.id;
        return !!wid && wid === activeId;
      });
    }
    return entries;
  });
  const filteredTasks = computed(
    () => filteredTaskEntries.value.map(({ task }) => task)
  );
  const jobItems = computed(() => {
    return filteredTaskEntries.value.map(({ task, state }) => {
      const isActive = String(task.promptId ?? "") === String(executionStore.activePromptId ?? "");
      const showAddedHint = shouldShowAddedHint(task, state);
      const display = buildJobDisplay(task, state, {
        t: t2,
        locale: locale.value,
        formatClockTimeFn: formatClockTime,
        isActive,
        totalPercent: isActive ? totalPercent.value : void 0,
        currentNodePercent: isActive ? currentNodePercent.value : void 0,
        currentNodeName: isActive ? currentNodeName.value : void 0,
        showAddedHint,
        isCloud
      });
      return {
        id: String(task.promptId),
        title: display.primary,
        meta: display.secondary,
        state,
        iconName: display.iconName,
        iconImageUrl: display.iconImageUrl,
        showClear: display.showClear,
        taskRef: task,
        progressTotalPercent: state === "running" && isActive ? totalPercent.value : void 0,
        progressCurrentPercent: state === "running" && isActive ? currentNodePercent.value : void 0,
        runningNodeName: state === "running" && isActive ? currentNodeName.value : void 0,
        executionTimeMs: task.executionTime,
        computeHours: task.executionTime !== void 0 ? task.executionTime / 36e5 : void 0
      };
    });
  });
  const jobItemById = computed(() => {
    const m = /* @__PURE__ */ new Map();
    jobItems.value.forEach((ji) => m.set(ji.id, ji));
    return m;
  });
  const groupedJobItems = computed(() => {
    const groups = [];
    const index = /* @__PURE__ */ new Map();
    const localeValue = locale.value;
    for (const { task, state } of filteredTaskEntries.value) {
      let ts;
      if (state === "completed" || state === "failed") {
        ts = task.executionEndTimestamp;
      } else {
        ts = task.createTime;
      }
      const key = ts === void 0 ? "undated" : dateKey(ts);
      let groupIdx = index.get(key);
      if (groupIdx === void 0) {
        const label = ts === void 0 ? undatedLabel.value : dateLabelForTimestamp(
          ts,
          localeValue,
          relativeTimeFormatter.value
        );
        groups.push({ key, label, items: [] });
        groupIdx = groups.length - 1;
        index.set(key, groupIdx);
      }
      const ji = jobItemById.value.get(String(task.promptId));
      if (ji) groups[groupIdx].items.push(ji);
    }
    if (selectedSortMode.value === "totalGenerationTime") {
      const valueOrDefault = /* @__PURE__ */ __name((value) => typeof value === "number" && !Number.isNaN(value) ? value : -1, "valueOrDefault");
      const sortByExecutionTimeDesc = /* @__PURE__ */ __name((a, b) => valueOrDefault(b.executionTimeMs) - valueOrDefault(a.executionTimeMs), "sortByExecutionTimeDesc");
      groups.forEach((group) => {
        group.items.sort(sortByExecutionTimeDesc);
      });
    }
    return groups;
  });
  return {
    // filters/state
    selectedJobTab,
    selectedWorkflowFilter,
    selectedSortMode,
    hasFailedJobs,
    // data sources
    allTasksSorted,
    filteredTasks,
    jobItems,
    groupedJobItems,
    currentNodeName
  };
}
__name(useJobList, "useJobList");
const _hoisted_1$10 = { class: "flex items-center justify-between gap-2 px-3" };
const _hoisted_2$L = { class: "min-w-0 flex-1 overflow-x-auto" };
const _hoisted_3$C = { class: "inline-flex items-center gap-1 whitespace-nowrap" };
const _hoisted_4$v = { class: "ml-2 flex shrink-0 items-center gap-2" };
const _hoisted_5$r = {
  key: 0,
  class: "pointer-events-none absolute -top-1 -right-1 inline-block size-2 rounded-full bg-base-foreground"
};
const _hoisted_6$p = { class: "flex min-w-[12rem] flex-col items-stretch rounded-lg border border-interface-stroke bg-interface-panel-surface px-2 py-3" };
const _hoisted_7$k = {
  key: 0,
  class: "icon-[lucide--check] size-4"
};
const _hoisted_8$g = {
  key: 0,
  class: "icon-[lucide--check] block size-4 leading-none text-text-secondary"
};
const _hoisted_9$b = {
  key: 0,
  class: "pointer-events-none absolute -top-1 -right-1 inline-block size-2 rounded-full bg-base-foreground"
};
const _hoisted_10$b = { class: "flex min-w-[12rem] flex-col items-stretch rounded-lg border border-interface-stroke bg-interface-panel-surface px-2 py-3" };
const _hoisted_11$8 = {
  key: 0,
  class: "icon-[lucide--check] size-4 text-text-secondary"
};
const _hoisted_12$6 = {
  key: 0,
  class: "mx-2 mt-1 h-px"
};
const _sfc_main$1t = /* @__PURE__ */ defineComponent({
  __name: "JobFiltersBar",
  props: {
    selectedJobTab: {},
    selectedWorkflowFilter: {},
    selectedSortMode: {},
    hasFailedJobs: { type: Boolean }
  },
  emits: ["update:selectedJobTab", "update:selectedWorkflowFilter", "update:selectedSortMode"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const { t: t2 } = useI18n();
    const filterPopoverRef = ref(null);
    const sortPopoverRef = ref(null);
    const filterTooltipConfig = computed(
      () => buildTooltipConfig(t2("sideToolbar.queueProgressOverlay.filterBy"))
    );
    const sortTooltipConfig = computed(
      () => buildTooltipConfig(t2("sideToolbar.queueProgressOverlay.sortBy"))
    );
    const visibleJobTabs = computed(
      () => props.hasFailedJobs ? jobTabs : jobTabs.filter((tab) => tab !== "Failed")
    );
    const onFilterClick = /* @__PURE__ */ __name((event) => {
      if (filterPopoverRef.value) {
        filterPopoverRef.value.toggle(event);
      }
    }, "onFilterClick");
    const selectWorkflowFilter = /* @__PURE__ */ __name((value) => {
      filterPopoverRef.value?.hide?.();
      emit("update:selectedWorkflowFilter", value);
    }, "selectWorkflowFilter");
    const onSortClick = /* @__PURE__ */ __name((event) => {
      if (sortPopoverRef.value) {
        sortPopoverRef.value.toggle(event);
      }
    }, "onSortClick");
    const selectSortMode = /* @__PURE__ */ __name((value) => {
      sortPopoverRef.value?.hide?.();
      emit("update:selectedSortMode", value);
    }, "selectSortMode");
    const tabLabel = /* @__PURE__ */ __name((tab) => {
      if (tab === "All") return t2("g.all");
      if (tab === "Completed") return t2("g.completed");
      return t2("g.failed");
    }, "tabLabel");
    const sortLabel = /* @__PURE__ */ __name((mode) => {
      if (mode === "mostRecent") {
        return t2("queue.jobList.sortMostRecent");
      }
      if (mode === "totalGenerationTime") {
        return t2("queue.jobList.sortTotalGenerationTime");
      }
      return "";
    }, "sortLabel");
    return (_ctx, _cache) => {
      const _directive_tooltip = resolveDirective("tooltip");
      return openBlock(), createElementBlock("div", _hoisted_1$10, [
        createBaseVNode("div", _hoisted_2$L, [
          createBaseVNode("div", _hoisted_3$C, [
            (openBlock(true), createElementBlock(Fragment, null, renderList(visibleJobTabs.value, (tab) => {
              return openBlock(), createBlock(_sfc_main$1Y, {
                key: tab,
                variant: _ctx.selectedJobTab === tab ? "secondary" : "muted-textonly",
                size: "sm",
                class: "px-3",
                onClick: /* @__PURE__ */ __name(($event) => _ctx.$emit("update:selectedJobTab", tab), "onClick")
              }, {
                default: withCtx(() => [
                  createTextVNode(toDisplayString(tabLabel(tab)), 1)
                ]),
                _: 2
              }, 1032, ["variant", "onClick"]);
            }), 128))
          ])
        ]),
        createBaseVNode("div", _hoisted_4$v, [
          withDirectives((openBlock(), createBlock(_sfc_main$1Y, {
            key: 0,
            variant: "secondary",
            size: "icon",
            "aria-label": unref(t2)("sideToolbar.queueProgressOverlay.filterJobs"),
            onClick: onFilterClick
          }, {
            default: withCtx(() => [
              _cache[2] || (_cache[2] = createBaseVNode("i", { class: "icon-[lucide--list-filter] size-4" }, null, -1)),
              _ctx.selectedWorkflowFilter !== "all" ? (openBlock(), createElementBlock("span", _hoisted_5$r)) : createCommentVNode("", true)
            ]),
            _: 1
          }, 8, ["aria-label"])), [
            [
              _directive_tooltip,
              filterTooltipConfig.value,
              void 0,
              { top: true }
            ]
          ]),
          (openBlock(), createBlock(unref(script$1), {
            key: 1,
            ref_key: "filterPopoverRef",
            ref: filterPopoverRef,
            dismissable: true,
            "close-on-escape": true,
            unstyled: "",
            pt: {
              root: { class: "absolute z-50" },
              content: {
                class: [
                  "bg-transparent border-none p-0 pt-2 rounded-lg shadow-lg font-inter"
                ]
              }
            }
          }, {
            default: withCtx(() => [
              createBaseVNode("div", _hoisted_6$p, [
                createVNode(_sfc_main$1Y, {
                  class: "w-full justify-between",
                  variant: "textonly",
                  size: "sm",
                  onClick: _cache[0] || (_cache[0] = ($event) => selectWorkflowFilter("all"))
                }, {
                  default: withCtx(() => [
                    createBaseVNode("span", null, toDisplayString(unref(t2)("sideToolbar.queueProgressOverlay.filterAllWorkflows")), 1),
                    _ctx.selectedWorkflowFilter === "all" ? (openBlock(), createElementBlock("i", _hoisted_7$k)) : createCommentVNode("", true)
                  ]),
                  _: 1
                }),
                _cache[3] || (_cache[3] = createBaseVNode("div", { class: "mx-2 mt-1 h-px" }, null, -1)),
                createVNode(_sfc_main$1Y, {
                  class: "w-full justify-between",
                  variant: "textonly",
                  onClick: _cache[1] || (_cache[1] = ($event) => selectWorkflowFilter("current"))
                }, {
                  default: withCtx(() => [
                    createBaseVNode("span", null, toDisplayString(unref(t2)("sideToolbar.queueProgressOverlay.filterCurrentWorkflow")), 1),
                    _ctx.selectedWorkflowFilter === "current" ? (openBlock(), createElementBlock("i", _hoisted_8$g)) : createCommentVNode("", true)
                  ]),
                  _: 1
                })
              ])
            ]),
            _: 1
          }, 512)),
          withDirectives((openBlock(), createBlock(_sfc_main$1Y, {
            variant: "secondary",
            size: "icon",
            "aria-label": unref(t2)("sideToolbar.queueProgressOverlay.sortJobs"),
            onClick: onSortClick
          }, {
            default: withCtx(() => [
              _cache[4] || (_cache[4] = createBaseVNode("i", { class: "icon-[lucide--arrow-up-down] size-4" }, null, -1)),
              _ctx.selectedSortMode !== "mostRecent" ? (openBlock(), createElementBlock("span", _hoisted_9$b)) : createCommentVNode("", true)
            ]),
            _: 1
          }, 8, ["aria-label"])), [
            [
              _directive_tooltip,
              sortTooltipConfig.value,
              void 0,
              { top: true }
            ]
          ]),
          createVNode(unref(script$1), {
            ref_key: "sortPopoverRef",
            ref: sortPopoverRef,
            dismissable: true,
            "close-on-escape": true,
            unstyled: "",
            pt: {
              root: { class: "absolute z-50" },
              content: {
                class: [
                  "bg-transparent border-none p-0 pt-2 rounded-lg shadow-lg font-inter"
                ]
              }
            }
          }, {
            default: withCtx(() => [
              createBaseVNode("div", _hoisted_10$b, [
                (openBlock(true), createElementBlock(Fragment, null, renderList(unref(jobSortModes), (mode, index) => {
                  return openBlock(), createElementBlock(Fragment, { key: mode }, [
                    createVNode(_sfc_main$1Y, {
                      class: "w-full justify-between",
                      variant: "textonly",
                      size: "sm",
                      onClick: /* @__PURE__ */ __name(($event) => selectSortMode(mode), "onClick")
                    }, {
                      default: withCtx(() => [
                        createBaseVNode("span", null, toDisplayString(sortLabel(mode)), 1),
                        _ctx.selectedSortMode === mode ? (openBlock(), createElementBlock("i", _hoisted_11$8)) : createCommentVNode("", true)
                      ]),
                      _: 2
                    }, 1032, ["onClick"]),
                    index < unref(jobSortModes).length - 1 ? (openBlock(), createElementBlock("div", _hoisted_12$6)) : createCommentVNode("", true)
                  ], 64);
                }), 128))
              ])
            ]),
            _: 1
          }, 512)
        ])
      ]);
    };
  }
});
const extractExecutionError = /* @__PURE__ */ __name((task) => {
  const status = task?.status;
  const messages = status?.messages;
  if (!Array.isArray(messages) || !messages.length) return null;
  const record = messages.find((entry) => {
    return Array.isArray(entry) && entry[0] === "execution_error";
  });
  if (!record) return null;
  const detail = record[1];
  const message = String(detail?.exception_message ?? "");
  return {
    detail,
    message
  };
}, "extractExecutionError");
const useJobErrorReporting = /* @__PURE__ */ __name(({
  taskForJob,
  copyToClipboard,
  dialog
}) => {
  const errorMessageValue = computed(() => {
    const error = extractExecutionError(taskForJob.value);
    return error?.message ?? "";
  });
  const copyErrorMessage = /* @__PURE__ */ __name(() => {
    if (errorMessageValue.value) {
      void copyToClipboard(errorMessageValue.value);
    }
  }, "copyErrorMessage");
  const reportJobError = /* @__PURE__ */ __name(() => {
    const error = extractExecutionError(taskForJob.value);
    if (error?.detail) {
      dialog.showExecutionErrorDialog(error.detail);
      return;
    }
    if (errorMessageValue.value) {
      dialog.showErrorDialog(new Error(errorMessageValue.value), {
        reportType: "queueJobError"
      });
    }
  }, "reportJobError");
  return {
    errorMessageValue,
    copyErrorMessage,
    reportJobError
  };
}, "useJobErrorReporting");
const formatElapsedTime = /* @__PURE__ */ __name((ms) => {
  const totalSec = Math.max(0, Math.floor(ms / 1e3));
  const minutes = Math.floor(totalSec / 60);
  const seconds = totalSec % 60;
  return `${minutes}m ${seconds}s`;
}, "formatElapsedTime");
const pickRecentDurations = /* @__PURE__ */ __name((queueStore) => queueStore.historyTasks.map((task) => Number(task.executionTimeInSeconds)).filter(
  (value) => typeof value === "number" && !Number.isNaN(value)
), "pickRecentDurations");
const useQueueEstimates = /* @__PURE__ */ __name(({
  queueStore,
  executionStore,
  taskForJob,
  jobState,
  firstSeenTs,
  jobsAhead,
  nowTs
}) => {
  const runningWorkflowCount = computed(
    () => executionStore.runningWorkflowCount
  );
  const showParallelQueuedStats = computed(
    () => jobState.value === "pending" && !!firstSeenTs.value && (runningWorkflowCount.value ?? 0) > 1
  );
  const recentDurations = computed(
    () => pickRecentDurations(queueStore).slice(-20)
  );
  const runningRemainingRangeSeconds = computed(() => {
    const durations = recentDurations.value;
    if (!durations.length) return null;
    const sorted = durations.slice().sort((a, b) => a - b);
    const avg = sorted.reduce((sum, value) => sum + value, 0) / sorted.length;
    const p75 = sorted[Math.min(sorted.length - 1, Math.floor(sorted.length * 0.75))];
    const running = queueStore.runningTasks;
    const now = nowTs.value;
    const remaining = running.map((task) => task.executionStartTimestamp).filter((timestamp) => typeof timestamp === "number").map((startTs) => {
      const elapsed = Math.max(0, Math.floor((now - startTs) / 1e3));
      return {
        lo: Math.max(0, Math.round(avg - elapsed)),
        hi: Math.max(0, Math.round(p75 - elapsed))
      };
    });
    if (!remaining.length) return null;
    const minLo = remaining.reduce(
      (min, range) => Math.min(min, range.lo),
      Infinity
    );
    const minHi = remaining.reduce(
      (min, range) => Math.min(min, range.hi),
      Infinity
    );
    return [minLo, minHi];
  });
  const estimateRangeSeconds = computed(() => {
    const durations = recentDurations.value;
    if (!durations.length) return null;
    const ahead = jobsAhead.value;
    if (ahead == null) return null;
    const sorted = durations.slice().sort((a, b) => a - b);
    const avg = sorted.reduce((sum, value) => sum + value, 0) / sorted.length;
    const p75 = sorted[Math.min(sorted.length - 1, Math.floor(sorted.length * 0.75))];
    if (ahead <= 0) {
      return runningRemainingRangeSeconds.value ?? [0, 0];
    }
    const runningCount = Math.max(1, runningWorkflowCount.value || 1);
    const batches = Math.ceil(ahead / runningCount);
    return [Math.round(avg * batches), Math.round(p75 * batches)];
  });
  const estimateRemainingRangeSeconds = computed(() => {
    const durations = recentDurations.value;
    if (!durations.length) return null;
    const sorted = durations.slice().sort((a, b) => a - b);
    const avg = sorted.reduce((sum, value) => sum + value, 0) / sorted.length;
    const p75 = sorted[Math.min(sorted.length - 1, Math.floor(sorted.length * 0.75))];
    const task = taskForJob.value;
    const execStart = jobState.value === "running" ? task?.executionStartTimestamp : void 0;
    const baseTs = execStart ?? firstSeenTs.value;
    const elapsed = baseTs ? Math.max(0, Math.floor((nowTs.value - baseTs) / 1e3)) : 0;
    const lo = Math.max(0, Math.round(avg - elapsed));
    const hi = Math.max(0, Math.round(p75 - elapsed));
    return [lo, hi];
  });
  const timeElapsedValue = computed(() => {
    const task = taskForJob.value;
    const execStart = jobState.value === "running" ? task?.executionStartTimestamp : void 0;
    const baseTs = execStart ?? firstSeenTs.value;
    if (!baseTs) return "";
    return formatElapsedTime(nowTs.value - baseTs);
  });
  return {
    runningWorkflowCount,
    showParallelQueuedStats,
    estimateRangeSeconds,
    estimateRemainingRangeSeconds,
    timeElapsedValue
  };
}, "useQueueEstimates");
const _hoisted_1$$ = { class: "w-[300px] min-w-[260px] rounded-lg border border-interface-stroke bg-interface-panel-surface shadow-md" };
const _hoisted_2$K = { class: "flex items-center border-b border-interface-stroke p-4" };
const _hoisted_3$B = { class: "text-[0.875rem] leading-normal font-normal text-text-primary" };
const _hoisted_4$u = { class: "flex flex-col gap-6 px-4 pt-4 pb-4" };
const _hoisted_5$q = { class: "grid grid-cols-2 items-center gap-x-2 gap-y-2" };
const _hoisted_6$o = { class: "flex items-center text-[0.75rem] leading-normal font-normal text-text-primary" };
const _hoisted_7$j = { class: "flex min-w-0 items-center text-[0.75rem] leading-normal font-normal text-text-secondary" };
const _hoisted_8$f = { class: "block min-w-0 truncate" };
const _hoisted_9$a = {
  key: 0,
  class: "grid grid-cols-2 items-center gap-x-2 gap-y-2"
};
const _hoisted_10$a = { class: "flex items-center text-[0.75rem] leading-normal font-normal text-text-primary" };
const _hoisted_11$7 = { class: "flex min-w-0 items-center text-[0.75rem] leading-normal font-normal text-text-secondary" };
const _hoisted_12$5 = { class: "block min-w-0 truncate" };
const _hoisted_13$5 = {
  key: 1,
  class: "grid grid-cols-2 gap-x-2"
};
const _hoisted_14$5 = { class: "flex items-center text-[0.75rem] leading-normal font-normal text-text-primary" };
const _hoisted_15$4 = { class: "flex items-center justify-between gap-4" };
const _hoisted_16$3 = { class: "col-span-2 mt-2 rounded bg-interface-panel-hover-surface px-4 py-2 text-[0.75rem] leading-normal text-text-secondary" };
const _sfc_main$1s = /* @__PURE__ */ defineComponent({
  __name: "JobDetailsPopover",
  props: {
    jobId: {},
    workflowId: {}
  },
  setup(__props) {
    const props = __props;
    const copyAriaLabel = computed(() => t2("g.copy"));
    const workflowStore = useWorkflowStore();
    const queueStore = useQueueStore();
    const executionStore = useExecutionStore();
    const dialog = useDialogService();
    const { locale, t: t2 } = useI18n();
    const workflowValue = computed(() => {
      const wid = props.workflowId;
      if (!wid) return "";
      const activeId = workflowStore.activeWorkflow?.activeState?.id;
      if (activeId && activeId === wid) {
        return workflowStore.activeWorkflow?.filename ?? wid;
      }
      return wid;
    });
    const jobIdValue = computed(() => props.jobId);
    const { copyToClipboard } = useCopyToClipboard();
    const copyJobId = /* @__PURE__ */ __name(() => void copyToClipboard(jobIdValue.value), "copyJobId");
    const taskForJob = computed(() => {
      const pid = props.jobId;
      const findIn = /* @__PURE__ */ __name((arr) => arr.find((t22) => String(t22.promptId ?? "") === String(pid)), "findIn");
      return findIn(queueStore.pendingTasks) || findIn(queueStore.runningTasks) || findIn(queueStore.historyTasks) || null;
    });
    const jobState = computed(() => {
      const task = taskForJob.value;
      if (!task) return null;
      const isInitializing = executionStore.isPromptInitializing(
        String(task?.promptId)
      );
      return jobStateFromTask(task, isInitializing);
    });
    const firstSeenTs = computed(() => {
      const task = taskForJob.value;
      return task?.createTime;
    });
    const queuedAtValue = computed(
      () => firstSeenTs.value !== void 0 ? formatClockTime(firstSeenTs.value, locale.value) : ""
    );
    const currentQueueIndex = computed(() => {
      const task = taskForJob.value;
      return task ? Number(task.queueIndex) : null;
    });
    const jobsAhead = computed(() => {
      const idx = currentQueueIndex.value;
      if (idx == null) return null;
      const ahead = queueStore.pendingTasks.filter(
        (t22) => Number(t22.queueIndex) < idx
      );
      return ahead.length;
    });
    const queuePositionValue = computed(() => {
      if (jobsAhead.value == null) return "";
      const n = jobsAhead.value;
      return t2("queue.jobDetails.queuePositionValue", { count: n }, n);
    });
    const nowTs = ref(Date.now());
    let timer = null;
    onMounted(() => {
      timer = window.setInterval(() => {
        nowTs.value = Date.now();
      }, 1e3);
    });
    onUnmounted(() => {
      if (timer != null) {
        clearInterval(timer);
        timer = null;
      }
    });
    const {
      showParallelQueuedStats,
      estimateRangeSeconds,
      estimateRemainingRangeSeconds,
      timeElapsedValue
    } = useQueueEstimates({
      queueStore,
      executionStore,
      taskForJob,
      jobState,
      firstSeenTs,
      jobsAhead,
      nowTs
    });
    const formatEta = /* @__PURE__ */ __name((lo, hi) => {
      if (hi <= 60) {
        const hiS = Math.max(1, Math.round(hi));
        const loS = Math.max(1, Math.min(hiS, Math.round(lo)));
        if (loS === hiS)
          return t2("queue.jobDetails.eta.seconds", { count: hiS }, hiS);
        return t2("queue.jobDetails.eta.secondsRange", { lo: loS, hi: hiS });
      }
      if (lo >= 60 && hi < 90) {
        return t2("queue.jobDetails.eta.minutes", { count: 1 }, 1);
      }
      const loM = Math.max(1, Math.floor(lo / 60));
      const hiM = Math.max(loM, Math.ceil(hi / 60));
      if (loM === hiM) {
        return t2("queue.jobDetails.eta.minutes", { count: loM }, loM);
      }
      return t2("queue.jobDetails.eta.minutesRange", { lo: loM, hi: hiM });
    }, "formatEta");
    const estimatedStartInValue = computed(() => {
      const range = estimateRangeSeconds.value;
      if (!range) return "";
      const [lo, hi] = range;
      return formatEta(lo, hi);
    });
    const estimatedFinishInValue = computed(() => {
      const range = estimateRemainingRangeSeconds.value;
      if (!range) return "";
      const [lo, hi] = range;
      return formatEta(lo, hi);
    });
    const baseRows = computed(() => [
      { label: t2("queue.jobDetails.workflow"), value: workflowValue.value },
      { label: t2("queue.jobDetails.jobId"), value: jobIdValue.value, canCopy: true }
    ]);
    const extraRows = computed(() => {
      if (jobState.value === "pending") {
        if (!firstSeenTs.value) return [];
        const rows = [
          { label: t2("queue.jobDetails.queuedAt"), value: queuedAtValue.value }
        ];
        if (showParallelQueuedStats.value) {
          rows.push(
            {
              label: t2("queue.jobDetails.queuePosition"),
              value: queuePositionValue.value
            },
            {
              label: t2("queue.jobDetails.timeElapsed"),
              value: timeElapsedValue.value
            },
            {
              label: t2("queue.jobDetails.estimatedStartIn"),
              value: estimatedStartInValue.value
            }
          );
        }
        return rows;
      }
      if (jobState.value === "running") {
        if (!firstSeenTs.value) return [];
        return [
          { label: t2("queue.jobDetails.queuedAt"), value: queuedAtValue.value },
          {
            label: t2("queue.jobDetails.timeElapsed"),
            value: timeElapsedValue.value
          },
          {
            label: t2("queue.jobDetails.estimatedFinishIn"),
            value: estimatedFinishInValue.value
          }
        ];
      }
      if (jobState.value === "completed") {
        const task = taskForJob.value;
        const endTs = task?.executionEndTimestamp;
        const execMs = task?.executionTime;
        const generatedOnValue = endTs ? formatClockTime(endTs, locale.value) : "";
        const totalGenTimeValue = execMs !== void 0 ? formatElapsedTime(execMs) : "";
        execMs !== void 0 ? (execMs / 36e5).toFixed(3) + " hours" : "";
        const rows = [
          { label: t2("queue.jobDetails.generatedOn"), value: generatedOnValue },
          {
            label: t2("queue.jobDetails.totalGenerationTime"),
            value: totalGenTimeValue
          }
        ];
        return rows;
      }
      if (jobState.value === "failed") {
        const task = taskForJob.value;
        const execMs = task?.executionTime;
        const failedAfterValue = execMs !== void 0 ? formatElapsedTime(execMs) : "";
        execMs !== void 0 ? (execMs / 36e5).toFixed(3) + " hours" : "";
        const rows = [
          { label: t2("queue.jobDetails.queuedAt"), value: queuedAtValue.value },
          { label: t2("queue.jobDetails.failedAfter"), value: failedAfterValue }
        ];
        return rows;
      }
      return [];
    });
    const { errorMessageValue, copyErrorMessage, reportJobError } = useJobErrorReporting({
      taskForJob,
      copyToClipboard,
      dialog
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$$, [
        createBaseVNode("div", _hoisted_2$K, [
          createBaseVNode("span", _hoisted_3$B, toDisplayString(unref(t2)("queue.jobDetails.header")), 1)
        ]),
        createBaseVNode("div", _hoisted_4$u, [
          createBaseVNode("div", _hoisted_5$q, [
            (openBlock(true), createElementBlock(Fragment, null, renderList(baseRows.value, (row) => {
              return openBlock(), createElementBlock(Fragment, {
                key: row.label
              }, [
                createBaseVNode("div", _hoisted_6$o, toDisplayString(row.label), 1),
                createBaseVNode("div", _hoisted_7$j, [
                  createBaseVNode("span", _hoisted_8$f, toDisplayString(row.value), 1),
                  row.canCopy ? (openBlock(), createBlock(_sfc_main$1Y, {
                    key: 0,
                    size: "icon",
                    variant: "muted-textonly",
                    "aria-label": copyAriaLabel.value,
                    onClick: withModifiers(copyJobId, ["stop"])
                  }, {
                    default: withCtx(() => _cache[0] || (_cache[0] = [
                      createBaseVNode("i", { class: "icon-[lucide--copy] size-4" }, null, -1)
                    ])),
                    _: 1
                  }, 8, ["aria-label"])) : createCommentVNode("", true)
                ])
              ], 64);
            }), 128))
          ]),
          extraRows.value.length ? (openBlock(), createElementBlock("div", _hoisted_9$a, [
            (openBlock(true), createElementBlock(Fragment, null, renderList(extraRows.value, (row) => {
              return openBlock(), createElementBlock(Fragment, {
                key: row.label
              }, [
                createBaseVNode("div", _hoisted_10$a, toDisplayString(row.label), 1),
                createBaseVNode("div", _hoisted_11$7, [
                  createBaseVNode("span", _hoisted_12$5, toDisplayString(row.value), 1)
                ])
              ], 64);
            }), 128))
          ])) : createCommentVNode("", true),
          jobState.value === "failed" ? (openBlock(), createElementBlock("div", _hoisted_13$5, [
            createBaseVNode("div", _hoisted_14$5, toDisplayString(unref(t2)("queue.jobDetails.errorMessage")), 1),
            createBaseVNode("div", _hoisted_15$4, [
              createVNode(_sfc_main$1Y, {
                class: "justify-start px-0",
                variant: "muted-textonly",
                size: "sm",
                "icon-position": "right",
                onClick: withModifiers(unref(copyErrorMessage), ["stop"])
              }, {
                default: withCtx(() => [
                  createBaseVNode("span", null, toDisplayString(copyAriaLabel.value), 1),
                  _cache[1] || (_cache[1] = createBaseVNode("i", { class: "icon-[lucide--copy] block size-3.5 leading-none" }, null, -1))
                ]),
                _: 1
              }, 8, ["onClick"]),
              createVNode(_sfc_main$1Y, {
                class: "justify-start px-0",
                variant: "muted-textonly",
                size: "sm",
                "icon-position": "right",
                onClick: withModifiers(unref(reportJobError), ["stop"])
              }, {
                default: withCtx(() => [
                  createBaseVNode("span", null, toDisplayString(unref(t2)("queue.jobDetails.report")), 1),
                  _cache[2] || (_cache[2] = createBaseVNode("i", { class: "icon-[lucide--message-circle-warning] block size-3.5 leading-none" }, null, -1))
                ]),
                _: 1
              }, 8, ["onClick"])
            ]),
            createBaseVNode("div", _hoisted_16$3, toDisplayString(unref(errorMessageValue)), 1)
          ])) : createCommentVNode("", true)
        ])
      ]);
    };
  }
});
const _hoisted_1$_ = { class: "w-[300px] min-w-[260px] rounded-lg shadow-md" };
const _hoisted_2$J = { class: "p-3" };
const _hoisted_3$A = { class: "relative aspect-square w-full overflow-hidden rounded-lg" };
const _hoisted_4$t = ["src", "alt"];
const _hoisted_5$p = {
  key: 0,
  class: "absolute bottom-2 left-2 rounded px-2 py-0.5 text-xs text-text-primary",
  style: {
    background: "rgba(217, 217, 217, 0.40)",
    backdropFilter: "blur(2px)"
  }
};
const _hoisted_6$n = { class: "mt-2 text-center" };
const _hoisted_7$i = ["title"];
const _hoisted_8$e = {
  key: 0,
  class: "mt-1 text-[0.75rem] leading-normal text-text-secondary"
};
const _sfc_main$1r = /* @__PURE__ */ defineComponent({
  ...{ inheritAttrs: false },
  __name: "QueueAssetPreview",
  props: {
    imageUrl: {},
    name: {},
    timeLabel: {}
  },
  emits: ["image-click"],
  setup(__props) {
    const imgRef = ref(null);
    const width = ref(null);
    const height = ref(null);
    const onImgLoad = /* @__PURE__ */ __name(() => {
      const el = imgRef.value;
      if (!el) return;
      width.value = el.naturalWidth || null;
      height.value = el.naturalHeight || null;
    }, "onImgLoad");
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$_, [
        createBaseVNode("div", _hoisted_2$J, [
          createBaseVNode("div", _hoisted_3$A, [
            createBaseVNode("img", {
              ref_key: "imgRef",
              ref: imgRef,
              src: _ctx.imageUrl,
              alt: _ctx.name,
              class: "h-full w-full cursor-pointer object-contain",
              onClick: _cache[0] || (_cache[0] = ($event) => _ctx.$emit("image-click")),
              onLoad: onImgLoad
            }, null, 40, _hoisted_4$t),
            _ctx.timeLabel ? (openBlock(), createElementBlock("div", _hoisted_5$p, toDisplayString(_ctx.timeLabel), 1)) : createCommentVNode("", true)
          ]),
          createBaseVNode("div", _hoisted_6$n, [
            createBaseVNode("div", {
              class: "truncate text-[0.875rem] leading-normal font-semibold text-text-primary",
              title: _ctx.name
            }, toDisplayString(_ctx.name), 9, _hoisted_7$i),
            width.value && height.value ? (openBlock(), createElementBlock("div", _hoisted_8$e, toDisplayString(width.value) + "x" + toDisplayString(height.value), 1)) : createCommentVNode("", true)
          ])
        ])
      ]);
    };
  }
});
const _hoisted_1$Z = {
  key: 0,
  class: "absolute inset-0"
};
const _hoisted_2$I = { class: "relative z-1 flex items-center gap-1" };
const _hoisted_3$z = { class: "relative inline-flex items-center justify-center" };
const _hoisted_4$s = { class: "inline-flex h-6 w-6 items-center justify-center overflow-hidden rounded-[6px]" };
const _hoisted_5$o = ["src"];
const _hoisted_6$m = { class: "relative z-1 min-w-0 flex-1" };
const _hoisted_7$h = ["title"];
const _hoisted_8$d = { class: "relative z-1 flex items-center gap-2 text-text-secondary" };
const _hoisted_9$9 = {
  key: "actions",
  class: "inline-flex items-center gap-2 pr-1"
};
const _hoisted_10$9 = {
  key: "secondary",
  class: "pr-2"
};
const _sfc_main$1q = /* @__PURE__ */ defineComponent({
  __name: "QueueJobItem",
  props: {
    jobId: {},
    workflowId: { default: void 0 },
    state: {},
    title: {},
    rightText: { default: "" },
    iconName: { default: void 0 },
    iconImageUrl: { default: void 0 },
    showClear: { type: Boolean, default: void 0 },
    showMenu: { type: Boolean, default: void 0 },
    progressTotalPercent: { default: void 0 },
    progressCurrentPercent: { default: void 0 },
    activeDetailsId: { default: null }
  },
  emits: ["cancel", "delete", "menu", "view", "details-enter", "details-leave"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const { t: t2 } = useI18n();
    const cancelTooltipConfig = computed(() => buildTooltipConfig(t2("g.cancel")));
    const deleteTooltipConfig = computed(() => buildTooltipConfig(t2("g.delete")));
    const moreTooltipConfig = computed(() => buildTooltipConfig(t2("g.more")));
    const rowRef = ref(null);
    const showDetails = computed(() => props.activeDetailsId === props.jobId);
    const onRowEnter = /* @__PURE__ */ __name(() => {
      if (!isPreviewVisible.value) emit("details-enter", props.jobId);
    }, "onRowEnter");
    const onRowLeave = /* @__PURE__ */ __name(() => emit("details-leave", props.jobId), "onRowLeave");
    const onPopoverEnter = /* @__PURE__ */ __name(() => emit("details-enter", props.jobId), "onPopoverEnter");
    const onPopoverLeave = /* @__PURE__ */ __name(() => emit("details-leave", props.jobId), "onPopoverLeave");
    const isPreviewVisible = ref(false);
    const previewHideTimer = ref(null);
    const previewShowTimer = ref(null);
    const clearPreviewHideTimer = /* @__PURE__ */ __name(() => {
      if (previewHideTimer.value !== null) {
        clearTimeout(previewHideTimer.value);
        previewHideTimer.value = null;
      }
    }, "clearPreviewHideTimer");
    const clearPreviewShowTimer = /* @__PURE__ */ __name(() => {
      if (previewShowTimer.value !== null) {
        clearTimeout(previewShowTimer.value);
        previewShowTimer.value = null;
      }
    }, "clearPreviewShowTimer");
    const canShowPreview = computed(
      () => props.state === "completed" && !!props.iconImageUrl
    );
    const scheduleShowPreview = /* @__PURE__ */ __name(() => {
      if (!canShowPreview.value) return;
      clearPreviewHideTimer();
      clearPreviewShowTimer();
      previewShowTimer.value = window.setTimeout(() => {
        isPreviewVisible.value = true;
        previewShowTimer.value = null;
      }, 200);
    }, "scheduleShowPreview");
    const scheduleHidePreview = /* @__PURE__ */ __name(() => {
      clearPreviewHideTimer();
      clearPreviewShowTimer();
      previewHideTimer.value = window.setTimeout(() => {
        isPreviewVisible.value = false;
        previewHideTimer.value = null;
      }, 150);
    }, "scheduleHidePreview");
    const onIconEnter = /* @__PURE__ */ __name(() => scheduleShowPreview(), "onIconEnter");
    const onIconLeave = /* @__PURE__ */ __name(() => scheduleHidePreview(), "onIconLeave");
    const onPreviewEnter = /* @__PURE__ */ __name(() => scheduleShowPreview(), "onPreviewEnter");
    const onPreviewLeave = /* @__PURE__ */ __name(() => scheduleHidePreview(), "onPreviewLeave");
    const popoverPosition = ref(null);
    const updatePopoverPosition = /* @__PURE__ */ __name(() => {
      const el = rowRef.value;
      if (!el) return;
      const rect = el.getBoundingClientRect();
      const gap = 8;
      popoverPosition.value = {
        top: rect.top,
        right: window.innerWidth - rect.left + gap
      };
    }, "updatePopoverPosition");
    const isAnyPopoverVisible = computed(
      () => showDetails.value || isPreviewVisible.value && canShowPreview.value
    );
    watch(
      isAnyPopoverVisible,
      (visible) => {
        if (visible) {
          nextTick(updatePopoverPosition);
        } else {
          popoverPosition.value = null;
        }
      },
      { immediate: false }
    );
    const isHovered = ref(false);
    const iconClass = computed(() => {
      if (props.iconName) return props.iconName;
      return iconForJobState(props.state);
    });
    const shouldSpin = computed(
      () => props.state === "pending" && iconClass.value === iconForJobState("pending") && !props.iconImageUrl
    );
    const computedShowClear = computed(() => {
      if (props.showClear !== void 0) return props.showClear;
      return props.state !== "completed";
    });
    const emitDetailsLeave = /* @__PURE__ */ __name(() => emit("details-leave", props.jobId), "emitDetailsLeave");
    const onCancelClick = /* @__PURE__ */ __name(() => {
      emitDetailsLeave();
      emit("cancel");
    }, "onCancelClick");
    const onDeleteClick = /* @__PURE__ */ __name(() => {
      emitDetailsLeave();
      emit("delete");
    }, "onDeleteClick");
    const onContextMenu = /* @__PURE__ */ __name((event) => {
      const shouldShowMenu = props.showMenu !== void 0 ? props.showMenu : true;
      if (shouldShowMenu) emit("menu", event);
    }, "onContextMenu");
    return (_ctx, _cache) => {
      const _directive_tooltip = resolveDirective("tooltip");
      return openBlock(), createElementBlock("div", {
        ref_key: "rowRef",
        ref: rowRef,
        class: "relative",
        onMouseenter: onRowEnter,
        onMouseleave: onRowLeave,
        onContextmenu: withModifiers(onContextMenu, ["stop", "prevent"])
      }, [
        (openBlock(), createBlock(Teleport, { to: "body" }, [
          !isPreviewVisible.value && showDetails.value && popoverPosition.value ? (openBlock(), createElementBlock("div", {
            key: 0,
            class: "fixed z-50",
            style: normalizeStyle({
              top: `${popoverPosition.value.top}px`,
              right: `${popoverPosition.value.right}px`
            }),
            onMouseenter: onPopoverEnter,
            onMouseleave: onPopoverLeave
          }, [
            createVNode(_sfc_main$1s, {
              "job-id": props.jobId,
              "workflow-id": props.workflowId
            }, null, 8, ["job-id", "workflow-id"])
          ], 36)) : createCommentVNode("", true)
        ])),
        (openBlock(), createBlock(Teleport, { to: "body" }, [
          isPreviewVisible.value && canShowPreview.value && popoverPosition.value ? (openBlock(), createElementBlock("div", {
            key: 0,
            class: "fixed z-50",
            style: normalizeStyle({
              top: `${popoverPosition.value.top}px`,
              right: `${popoverPosition.value.right}px`
            }),
            onMouseenter: onPreviewEnter,
            onMouseleave: onPreviewLeave
          }, [
            createVNode(_sfc_main$1r, {
              "image-url": _ctx.iconImageUrl,
              name: props.title,
              "time-label": _ctx.rightText || void 0,
              onImageClick: _cache[0] || (_cache[0] = ($event) => emit("view"))
            }, null, 8, ["image-url", "name", "time-label"])
          ], 36)) : createCommentVNode("", true)
        ])),
        createBaseVNode("div", {
          class: "relative flex items-center justify-between gap-2 overflow-hidden rounded-lg border border-secondary-background bg-secondary-background p-1 text-[12px] text-text-primary transition-colors duration-150 ease-in-out hover:border-secondary-background-hover hover:bg-secondary-background-hover",
          onMouseenter: _cache[3] || (_cache[3] = ($event) => isHovered.value = true),
          onMouseleave: _cache[4] || (_cache[4] = ($event) => isHovered.value = false)
        }, [
          props.state === "running" && (props.progressTotalPercent !== void 0 || props.progressCurrentPercent !== void 0) ? (openBlock(), createElementBlock("div", _hoisted_1$Z, [
            props.progressTotalPercent !== void 0 ? (openBlock(), createElementBlock("div", {
              key: 0,
              class: "pointer-events-none absolute inset-y-0 left-0 h-full bg-interface-panel-job-progress-primary transition-[width]",
              style: normalizeStyle({ width: `${props.progressTotalPercent}%` })
            }, null, 4)) : createCommentVNode("", true),
            props.progressCurrentPercent !== void 0 ? (openBlock(), createElementBlock("div", {
              key: 1,
              class: "pointer-events-none absolute inset-y-0 left-0 h-full bg-interface-panel-job-progress-secondary transition-[width]",
              style: normalizeStyle({ width: `${props.progressCurrentPercent}%` })
            }, null, 4)) : createCommentVNode("", true)
          ])) : createCommentVNode("", true),
          createBaseVNode("div", _hoisted_2$I, [
            createBaseVNode("div", _hoisted_3$z, [
              createBaseVNode("div", {
                class: "absolute left-1/2 top-1/2 size-10 -translate-x-1/2 -translate-y-1/2",
                onMouseenter: withModifiers(onIconEnter, ["stop"]),
                onMouseleave: withModifiers(onIconLeave, ["stop"])
              }, null, 32),
              createBaseVNode("div", _hoisted_4$s, [
                _ctx.iconImageUrl ? (openBlock(), createElementBlock("img", {
                  key: 0,
                  src: _ctx.iconImageUrl,
                  class: "h-full w-full object-cover"
                }, null, 8, _hoisted_5$o)) : (openBlock(), createElementBlock("i", {
                  key: 1,
                  class: normalizeClass(unref(cn)(iconClass.value, "size-4", shouldSpin.value && "animate-spin"))
                }, null, 2))
              ])
            ])
          ]),
          createBaseVNode("div", _hoisted_6$m, [
            createBaseVNode("div", {
              class: "truncate opacity-90",
              title: props.title
            }, [
              renderSlot(_ctx.$slots, "primary", {}, () => [
                createTextVNode(toDisplayString(props.title), 1)
              ])
            ], 8, _hoisted_7$h)
          ]),
          createBaseVNode("div", _hoisted_8$d, [
            createVNode(Transition, {
              mode: "out-in",
              "enter-active-class": "transition-opacity transition-transform duration-150 ease-out",
              "leave-active-class": "transition-opacity transition-transform duration-150 ease-in",
              "enter-from-class": "opacity-0 translate-y-0.5",
              "enter-to-class": "opacity-100 translate-y-0",
              "leave-from-class": "opacity-100 translate-y-0",
              "leave-to-class": "opacity-0 translate-y-0.5"
            }, {
              default: withCtx(() => [
                isHovered.value ? (openBlock(), createElementBlock("div", _hoisted_9$9, [
                  props.state === "failed" && computedShowClear.value ? withDirectives((openBlock(), createBlock(_sfc_main$1Y, {
                    key: 0,
                    variant: "destructive",
                    size: "icon",
                    "aria-label": unref(t2)("g.delete"),
                    onClick: withModifiers(onDeleteClick, ["stop"])
                  }, {
                    default: withCtx(() => _cache[5] || (_cache[5] = [
                      createBaseVNode("i", { class: "icon-[lucide--trash-2] size-4" }, null, -1)
                    ])),
                    _: 1
                  }, 8, ["aria-label"])), [
                    [
                      _directive_tooltip,
                      deleteTooltipConfig.value,
                      void 0,
                      { top: true }
                    ]
                  ]) : props.state !== "completed" && props.state !== "running" && computedShowClear.value ? withDirectives((openBlock(), createBlock(_sfc_main$1Y, {
                    key: 1,
                    variant: "destructive",
                    size: "icon",
                    "aria-label": unref(t2)("g.cancel"),
                    onClick: withModifiers(onCancelClick, ["stop"])
                  }, {
                    default: withCtx(() => _cache[6] || (_cache[6] = [
                      createBaseVNode("i", { class: "icon-[lucide--x] size-4" }, null, -1)
                    ])),
                    _: 1
                  }, 8, ["aria-label"])), [
                    [
                      _directive_tooltip,
                      cancelTooltipConfig.value,
                      void 0,
                      { top: true }
                    ]
                  ]) : props.state === "completed" ? (openBlock(), createBlock(_sfc_main$1Y, {
                    key: 2,
                    variant: "textonly",
                    size: "sm",
                    onClick: _cache[1] || (_cache[1] = withModifiers(($event) => emit("view"), ["stop"]))
                  }, {
                    default: withCtx(() => [
                      createTextVNode(toDisplayString(unref(t2)("menuLabels.View")), 1)
                    ]),
                    _: 1
                  })) : createCommentVNode("", true),
                  (props.showMenu !== void 0 ? props.showMenu : true) ? withDirectives((openBlock(), createBlock(_sfc_main$1Y, {
                    key: 3,
                    variant: "textonly",
                    size: "icon-sm",
                    "aria-label": unref(t2)("g.more"),
                    onClick: _cache[2] || (_cache[2] = withModifiers(($event) => emit("menu", $event), ["stop"]))
                  }, {
                    default: withCtx(() => _cache[7] || (_cache[7] = [
                      createBaseVNode("i", { class: "icon-[lucide--more-horizontal] size-4" }, null, -1)
                    ])),
                    _: 1
                  }, 8, ["aria-label"])), [
                    [
                      _directive_tooltip,
                      moreTooltipConfig.value,
                      void 0,
                      { top: true }
                    ]
                  ]) : createCommentVNode("", true)
                ])) : props.state !== "running" ? (openBlock(), createElementBlock("div", _hoisted_10$9, [
                  renderSlot(_ctx.$slots, "secondary", {}, () => [
                    createTextVNode(toDisplayString(props.rightText), 1)
                  ])
                ])) : createCommentVNode("", true)
              ]),
              _: 3
            }),
            props.state === "running" && computedShowClear.value ? withDirectives((openBlock(), createBlock(_sfc_main$1Y, {
              key: 0,
              variant: "destructive",
              size: "icon",
              "aria-label": unref(t2)("g.cancel"),
              onClick: withModifiers(onCancelClick, ["stop"])
            }, {
              default: withCtx(() => _cache[8] || (_cache[8] = [
                createBaseVNode("i", { class: "icon-[lucide--x] size-4" }, null, -1)
              ])),
              _: 1
            }, 8, ["aria-label"])), [
              [
                _directive_tooltip,
                cancelTooltipConfig.value,
                void 0,
                { top: true }
              ]
            ]) : createCommentVNode("", true)
          ])
        ], 32)
      ], 544);
    };
  }
});
const _hoisted_1$Y = { class: "flex flex-col gap-4 px-3 pb-4" };
const _hoisted_2$H = { class: "text-[12px] leading-none text-text-secondary" };
const _sfc_main$1p = /* @__PURE__ */ defineComponent({
  __name: "JobGroupsList",
  props: {
    displayedJobGroups: {}
  },
  emits: ["cancelItem", "deleteItem", "menu", "viewItem"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const emitCancelItem = /* @__PURE__ */ __name((item) => {
      emit("cancelItem", item);
    }, "emitCancelItem");
    const emitDeleteItem = /* @__PURE__ */ __name((item) => {
      emit("deleteItem", item);
    }, "emitDeleteItem");
    const activeDetailsId = ref(null);
    const hideTimer = ref(null);
    const showTimer = ref(null);
    const clearHideTimer = /* @__PURE__ */ __name(() => {
      if (hideTimer.value !== null) {
        clearTimeout(hideTimer.value);
        hideTimer.value = null;
      }
    }, "clearHideTimer");
    const clearShowTimer = /* @__PURE__ */ __name(() => {
      if (showTimer.value !== null) {
        clearTimeout(showTimer.value);
        showTimer.value = null;
      }
    }, "clearShowTimer");
    const onDetailsEnter = /* @__PURE__ */ __name((jobId) => {
      clearHideTimer();
      clearShowTimer();
      showTimer.value = window.setTimeout(() => {
        activeDetailsId.value = jobId;
        showTimer.value = null;
      }, 200);
    }, "onDetailsEnter");
    const onDetailsLeave = /* @__PURE__ */ __name((jobId) => {
      clearHideTimer();
      clearShowTimer();
      hideTimer.value = window.setTimeout(() => {
        if (activeDetailsId.value === jobId) activeDetailsId.value = null;
        hideTimer.value = null;
      }, 150);
    }, "onDetailsLeave");
    const resetActiveDetails = /* @__PURE__ */ __name(() => {
      clearHideTimer();
      clearShowTimer();
      activeDetailsId.value = null;
    }, "resetActiveDetails");
    watch(
      () => props.displayedJobGroups,
      (groups) => {
        const activeId = activeDetailsId.value;
        if (!activeId) return;
        const hasActiveJob = groups.some(
          (group) => group.items.some((item) => item.id === activeId)
        );
        if (!hasActiveJob) resetActiveDetails();
      }
    );
    onBeforeUnmount(resetActiveDetails);
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$Y, [
        (openBlock(true), createElementBlock(Fragment, null, renderList(_ctx.displayedJobGroups, (group) => {
          return openBlock(), createElementBlock("div", {
            key: group.key,
            class: "flex flex-col gap-2"
          }, [
            createBaseVNode("div", _hoisted_2$H, toDisplayString(group.label), 1),
            (openBlock(true), createElementBlock(Fragment, null, renderList(group.items, (ji) => {
              return openBlock(), createBlock(_sfc_main$1q, {
                key: ji.id,
                "job-id": ji.id,
                "workflow-id": ji.taskRef?.workflow?.id,
                state: ji.state,
                title: ji.title,
                "right-text": ji.meta,
                "icon-name": ji.iconName,
                "icon-image-url": ji.iconImageUrl,
                "show-clear": ji.showClear,
                "show-menu": true,
                "progress-total-percent": ji.progressTotalPercent,
                "progress-current-percent": ji.progressCurrentPercent,
                "running-node-name": ji.runningNodeName,
                "active-details-id": activeDetailsId.value,
                onCancel: /* @__PURE__ */ __name(($event) => emitCancelItem(ji), "onCancel"),
                onDelete: /* @__PURE__ */ __name(($event) => emitDeleteItem(ji), "onDelete"),
                onMenu: /* @__PURE__ */ __name((ev) => _ctx.$emit("menu", ji, ev), "onMenu"),
                onView: /* @__PURE__ */ __name(($event) => _ctx.$emit("viewItem", ji), "onView"),
                onDetailsEnter,
                onDetailsLeave
              }, null, 8, ["job-id", "workflow-id", "state", "title", "right-text", "icon-name", "icon-image-url", "show-clear", "progress-total-percent", "progress-current-percent", "running-node-name", "active-details-id", "onCancel", "onDelete", "onMenu", "onView"]);
            }), 128))
          ]);
        }), 128))
      ]);
    };
  }
});
const _hoisted_1$X = { class: "flex w-full flex-col gap-4" };
const _hoisted_2$G = { class: "flex items-center justify-between px-3" };
const _hoisted_3$y = { class: "ml-4 inline-flex items-center" };
const _hoisted_4$r = { class: "inline-flex h-6 items-center text-[12px] leading-none text-text-primary opacity-90" };
const _hoisted_5$n = { class: "font-bold" };
const _hoisted_6$l = { class: "ml-1" };
const _hoisted_7$g = { class: "flex-1 min-h-0 overflow-y-auto" };
const _sfc_main$1o = /* @__PURE__ */ defineComponent({
  __name: "QueueOverlayExpanded",
  props: {
    headerTitle: {},
    showConcurrentIndicator: { type: Boolean },
    concurrentWorkflowCount: {},
    queuedCount: {},
    selectedJobTab: {},
    selectedWorkflowFilter: {},
    selectedSortMode: {},
    displayedJobGroups: {},
    hasFailedJobs: { type: Boolean }
  },
  emits: ["showAssets", "clearHistory", "clearQueued", "update:selectedJobTab", "update:selectedWorkflowFilter", "update:selectedSortMode", "cancelItem", "deleteItem", "viewItem"],
  setup(__props, { emit: __emit }) {
    const emit = __emit;
    const { t: t2 } = useI18n();
    const currentMenuItem = ref(null);
    const jobContextMenuRef = ref(null);
    const { jobMenuEntries } = useJobMenu(
      () => currentMenuItem.value,
      (item) => emit("viewItem", item)
    );
    const onCancelItemEvent = /* @__PURE__ */ __name((item) => {
      emit("cancelItem", item);
    }, "onCancelItemEvent");
    const onDeleteItemEvent = /* @__PURE__ */ __name((item) => {
      emit("deleteItem", item);
    }, "onDeleteItemEvent");
    const onMenuItem = /* @__PURE__ */ __name((item, event) => {
      currentMenuItem.value = item;
      jobContextMenuRef.value?.open(event);
    }, "onMenuItem");
    const onJobMenuAction = /* @__PURE__ */ __name(async (entry) => {
      if (entry.kind === "divider") return;
      if (entry.onClick) await entry.onClick();
      jobContextMenuRef.value?.hide();
    }, "onJobMenuAction");
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$X, [
        createVNode(_sfc_main$1v, {
          "header-title": _ctx.headerTitle,
          "show-concurrent-indicator": _ctx.showConcurrentIndicator,
          "concurrent-workflow-count": _ctx.concurrentWorkflowCount,
          onClearHistory: _cache[0] || (_cache[0] = ($event) => _ctx.$emit("clearHistory"))
        }, null, 8, ["header-title", "show-concurrent-indicator", "concurrent-workflow-count"]),
        createBaseVNode("div", _hoisted_2$G, [
          createVNode(_sfc_main$1Y, {
            class: "grow gap-1 justify-center",
            variant: "secondary",
            size: "sm",
            onClick: _cache[1] || (_cache[1] = ($event) => _ctx.$emit("showAssets"))
          }, {
            default: withCtx(() => [
              _cache[7] || (_cache[7] = createBaseVNode("i", { class: "icon-[comfy--image-ai-edit] size-4" }, null, -1)),
              createBaseVNode("span", null, toDisplayString(unref(t2)("sideToolbar.queueProgressOverlay.showAssets")), 1)
            ]),
            _: 1
          }),
          createBaseVNode("div", _hoisted_3$y, [
            createBaseVNode("div", _hoisted_4$r, [
              createBaseVNode("span", _hoisted_5$n, toDisplayString(_ctx.queuedCount), 1),
              createBaseVNode("span", _hoisted_6$l, toDisplayString(unref(t2)("sideToolbar.queueProgressOverlay.queuedSuffix")), 1)
            ]),
            _ctx.queuedCount > 0 ? (openBlock(), createBlock(_sfc_main$1Y, {
              key: 0,
              class: "ml-2",
              variant: "destructive",
              size: "icon",
              "aria-label": unref(t2)("sideToolbar.queueProgressOverlay.clearQueued"),
              onClick: _cache[2] || (_cache[2] = ($event) => _ctx.$emit("clearQueued"))
            }, {
              default: withCtx(() => _cache[8] || (_cache[8] = [
                createBaseVNode("i", { class: "icon-[lucide--list-x] size-4" }, null, -1)
              ])),
              _: 1
            }, 8, ["aria-label"])) : createCommentVNode("", true)
          ])
        ]),
        createVNode(_sfc_main$1t, {
          "selected-job-tab": _ctx.selectedJobTab,
          "selected-workflow-filter": _ctx.selectedWorkflowFilter,
          "selected-sort-mode": _ctx.selectedSortMode,
          "has-failed-jobs": _ctx.hasFailedJobs,
          "onUpdate:selectedJobTab": _cache[3] || (_cache[3] = ($event) => _ctx.$emit("update:selectedJobTab", $event)),
          "onUpdate:selectedWorkflowFilter": _cache[4] || (_cache[4] = ($event) => _ctx.$emit("update:selectedWorkflowFilter", $event)),
          "onUpdate:selectedSortMode": _cache[5] || (_cache[5] = ($event) => _ctx.$emit("update:selectedSortMode", $event))
        }, null, 8, ["selected-job-tab", "selected-workflow-filter", "selected-sort-mode", "has-failed-jobs"]),
        createBaseVNode("div", _hoisted_7$g, [
          createVNode(_sfc_main$1p, {
            "displayed-job-groups": _ctx.displayedJobGroups,
            onCancelItem: onCancelItemEvent,
            onDeleteItem: onDeleteItemEvent,
            onViewItem: _cache[6] || (_cache[6] = ($event) => _ctx.$emit("viewItem", $event)),
            onMenu: onMenuItem
          }, null, 8, ["displayed-job-groups"])
        ]),
        createVNode(_sfc_main$1u, {
          ref_key: "jobContextMenuRef",
          ref: jobContextMenuRef,
          entries: unref(jobMenuEntries),
          onAction: onJobMenuAction
        }, null, 8, ["entries"])
      ]);
    };
  }
});
const _hoisted_1$W = { class: "w-[360px] rounded-2xl border border-interface-stroke bg-interface-panel-surface text-text-primary shadow-interface font-inter" };
const _hoisted_2$F = { class: "flex items-center justify-between border-b border-interface-stroke px-4 py-4" };
const _hoisted_3$x = { class: "m-0 text-[14px] font-normal leading-none" };
const _hoisted_4$q = { class: "flex flex-col gap-4 px-4 py-4 text-[14px] text-text-secondary" };
const _hoisted_5$m = { class: "m-0" };
const _hoisted_6$k = { class: "m-0" };
const _hoisted_7$f = { class: "flex items-center justify-end px-4 py-4" };
const _hoisted_8$c = { class: "flex items-center gap-4 leading-none" };
const _sfc_main$1n = /* @__PURE__ */ defineComponent({
  __name: "QueueClearHistoryDialog",
  setup(__props) {
    const dialogStore = useDialogStore();
    const queueStore = useQueueStore();
    const { t: t2 } = useI18n();
    const { wrapWithErrorHandlingAsync } = useErrorHandling();
    const isClearing = ref(false);
    const clearHistory = wrapWithErrorHandlingAsync(
      async () => {
        await queueStore.clear(["history"]);
        dialogStore.closeDialog();
      },
      void 0,
      () => {
        isClearing.value = false;
      }
    );
    const onConfirm = /* @__PURE__ */ __name(async () => {
      if (isClearing.value) return;
      isClearing.value = true;
      await clearHistory();
    }, "onConfirm");
    const onCancel = /* @__PURE__ */ __name(() => {
      dialogStore.closeDialog();
    }, "onCancel");
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("section", _hoisted_1$W, [
        createBaseVNode("header", _hoisted_2$F, [
          createBaseVNode("p", _hoisted_3$x, toDisplayString(unref(t2)("sideToolbar.queueProgressOverlay.clearHistoryDialogTitle")), 1),
          createVNode(_sfc_main$1Y, {
            size: "icon",
            variant: "muted-textonly",
            "aria-label": unref(t2)("g.close"),
            onClick: onCancel
          }, {
            default: withCtx(() => _cache[0] || (_cache[0] = [
              createBaseVNode("i", { class: "icon-[lucide--x] block size-4 leading-none" }, null, -1)
            ])),
            _: 1
          }, 8, ["aria-label"])
        ]),
        createBaseVNode("div", _hoisted_4$q, [
          createBaseVNode("p", _hoisted_5$m, toDisplayString(unref(t2)("sideToolbar.queueProgressOverlay.clearHistoryDialogDescription")), 1),
          createBaseVNode("p", _hoisted_6$k, toDisplayString(unref(t2)("sideToolbar.queueProgressOverlay.clearHistoryDialogAssetsNote")), 1)
        ]),
        createBaseVNode("footer", _hoisted_7$f, [
          createBaseVNode("div", _hoisted_8$c, [
            createVNode(_sfc_main$1Y, {
              variant: "muted-textonly",
              size: "lg",
              onClick: onCancel
            }, {
              default: withCtx(() => [
                createTextVNode(toDisplayString(unref(t2)("g.cancel")), 1)
              ]),
              _: 1
            }),
            createVNode(_sfc_main$1Y, {
              variant: "secondary",
              size: "lg",
              disabled: isClearing.value,
              onClick: onConfirm
            }, {
              default: withCtx(() => [
                createTextVNode(toDisplayString(unref(t2)("g.clear")), 1)
              ]),
              _: 1
            }, 8, ["disabled"])
          ])
        ])
      ]);
    };
  }
});
const useCompletionSummary = /* @__PURE__ */ __name(() => {
  const queueStore = useQueueStore();
  const executionStore = useExecutionStore();
  const isActive = computed(
    () => queueStore.runningTasks.length > 0 || !executionStore.isIdle
  );
  const lastActiveStartTs = ref(null);
  const _summary = ref(null);
  const dismissTimer = ref(null);
  const clearDismissTimer = /* @__PURE__ */ __name(() => {
    if (dismissTimer.value !== null) {
      clearTimeout(dismissTimer.value);
      dismissTimer.value = null;
    }
  }, "clearDismissTimer");
  const startDismissTimer = /* @__PURE__ */ __name(() => {
    clearDismissTimer();
    dismissTimer.value = window.setTimeout(() => {
      _summary.value = null;
      dismissTimer.value = null;
    }, 6e3);
  }, "startDismissTimer");
  const clearSummary = /* @__PURE__ */ __name(() => {
    _summary.value = null;
    clearDismissTimer();
  }, "clearSummary");
  watch(
    isActive,
    (active, prev) => {
      if (!prev && active) {
        lastActiveStartTs.value = Date.now();
      }
      if (prev && !active) {
        const start = lastActiveStartTs.value ?? 0;
        const finished = queueStore.historyTasks.filter((t2) => {
          const ts = t2.executionEndTimestamp;
          return typeof ts === "number" && ts >= start;
        });
        if (!finished.length) {
          _summary.value = null;
          clearDismissTimer();
          return;
        }
        let completedCount = 0;
        let failedCount = 0;
        const imagePreviews = [];
        for (const task of finished) {
          const state = jobStateFromTask(task, false);
          if (state === "completed") {
            completedCount++;
            const preview = task.previewOutput;
            if (preview?.isImage) {
              imagePreviews.push(preview.urlWithTimestamp);
            }
          } else if (state === "failed") {
            failedCount++;
          }
        }
        if (completedCount === 0 && failedCount === 0) {
          _summary.value = null;
          clearDismissTimer();
          return;
        }
        let mode = "mixed";
        if (failedCount === 0) mode = "allSuccess";
        else if (completedCount === 0) mode = "allFailed";
        _summary.value = {
          mode,
          completedCount,
          failedCount,
          thumbnailUrls: imagePreviews.slice(0, 3)
        };
        startDismissTimer();
      }
    },
    { immediate: true }
  );
  const summary = computed(() => _summary.value);
  return {
    summary,
    clearSummary
  };
}, "useCompletionSummary");
function useResultGallery(getFilteredTasks) {
  const galleryActiveIndex = ref(-1);
  const galleryItems = shallowRef([]);
  const onViewItem = /* @__PURE__ */ __name((item) => {
    const items = getFilteredTasks().flatMap((t2) => {
      const preview = t2.previewOutput;
      return preview && preview.supportsPreview ? [preview] : [];
    });
    if (!items.length) return;
    galleryItems.value = items;
    const activeUrl = item.taskRef?.previewOutput?.url;
    const idx = activeUrl ? items.findIndex((o) => o.url === activeUrl) : 0;
    galleryActiveIndex.value = idx >= 0 ? idx : 0;
  }, "onViewItem");
  return {
    galleryActiveIndex,
    galleryItems,
    onViewItem
  };
}
__name(useResultGallery, "useResultGallery");
const _hoisted_1$V = {
  class: /* @__PURE__ */ normalizeClass(["flex", "justify-end", "w-full", "pointer-events-none"])
};
const _sfc_main$1m = /* @__PURE__ */ defineComponent({
  __name: "QueueProgressOverlay",
  props: {
    expanded: { type: Boolean },
    menuHovered: { type: Boolean, default: false }
  },
  emits: ["update:expanded"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const { t: t2 } = useI18n();
    const queueStore = useQueueStore();
    const commandStore = useCommandStore();
    const executionStore = useExecutionStore();
    const sidebarTabStore = useSidebarTabStore();
    const dialogStore = useDialogStore();
    const assetsStore = useAssetsStore();
    const assetSelectionStore = useAssetSelectionStore();
    const { wrapWithErrorHandlingAsync } = useErrorHandling();
    const {
      totalPercentFormatted,
      currentNodePercentFormatted,
      totalProgressStyle,
      currentNodeProgressStyle
    } = useQueueProgress();
    const isHovered = ref(false);
    const isOverlayHovered = computed(() => isHovered.value || props.menuHovered);
    const internalExpanded = ref(false);
    const isExpanded = computed({
      get: /* @__PURE__ */ __name(() => props.expanded === void 0 ? internalExpanded.value : props.expanded, "get"),
      set: /* @__PURE__ */ __name((value) => {
        if (props.expanded === void 0) {
          internalExpanded.value = value;
        }
        emit("update:expanded", value);
      }, "set")
    });
    const { summary: completionSummary, clearSummary } = useCompletionSummary();
    const hasCompletionSummary = computed(() => completionSummary.value !== null);
    const runningCount = computed(() => queueStore.runningTasks.length);
    const queuedCount = computed(() => queueStore.pendingTasks.length);
    const isExecuting = computed(() => !executionStore.isIdle);
    const hasActiveJob = computed(() => runningCount.value > 0 || isExecuting.value);
    const activeJobsCount = computed(() => runningCount.value + queuedCount.value);
    const overlayState = computed(() => {
      if (isExpanded.value) return "expanded";
      if (hasActiveJob.value) return "active";
      if (hasCompletionSummary.value) return "empty";
      return "hidden";
    });
    const showBackground = computed(
      () => overlayState.value === "expanded" || overlayState.value === "empty" || overlayState.value === "active" && isOverlayHovered.value
    );
    const isVisible = computed(() => overlayState.value !== "hidden");
    const containerClass = computed(
      () => showBackground.value ? "border-interface-stroke bg-interface-panel-surface shadow-interface" : "border-transparent bg-transparent shadow-none"
    );
    const bottomRowClass = computed(
      () => `flex items-center justify-end gap-4 transition-opacity duration-200 ease-in-out ${overlayState.value === "active" && isOverlayHovered.value ? "opacity-100 pointer-events-auto" : "opacity-0 pointer-events-none"}`
    );
    const headerTitle = computed(
      () => hasActiveJob.value ? `${activeJobsCount.value} ${t2("sideToolbar.queueProgressOverlay.activeJobsSuffix")}` : t2("sideToolbar.queueProgressOverlay.jobQueue")
    );
    const concurrentWorkflowCount = computed(
      () => executionStore.runningWorkflowCount
    );
    const showConcurrentIndicator = computed(
      () => concurrentWorkflowCount.value > 1
    );
    const {
      selectedJobTab,
      selectedWorkflowFilter,
      selectedSortMode,
      hasFailedJobs,
      filteredTasks,
      groupedJobItems,
      currentNodeName
    } = useJobList();
    const displayedJobGroups = computed(() => groupedJobItems.value);
    const onCancelItem = wrapWithErrorHandlingAsync(async (item) => {
      const promptId = item.taskRef?.promptId;
      if (!promptId) return;
      if (item.state === "running" || item.state === "initialization") {
        await api.interrupt(promptId);
        await queueStore.update();
      } else if (item.state === "pending") {
        await api.deleteItem("queue", promptId);
        await queueStore.update();
      }
    });
    const onDeleteItem = wrapWithErrorHandlingAsync(async (item) => {
      if (!item.taskRef) return;
      await queueStore.delete(item.taskRef);
    });
    const {
      galleryActiveIndex,
      galleryItems,
      onViewItem: openResultGallery
    } = useResultGallery(() => filteredTasks.value);
    const setExpanded = /* @__PURE__ */ __name((expanded) => {
      isExpanded.value = expanded;
    }, "setExpanded");
    const openExpandedFromEmpty = /* @__PURE__ */ __name(() => {
      setExpanded(true);
    }, "openExpandedFromEmpty");
    const viewAllJobs = /* @__PURE__ */ __name(() => {
      setExpanded(true);
    }, "viewAllJobs");
    const onSummaryClick = /* @__PURE__ */ __name(() => {
      openExpandedFromEmpty();
      clearSummary();
    }, "onSummaryClick");
    const openAssetsSidebar = /* @__PURE__ */ __name(() => {
      sidebarTabStore.activeSidebarTabId = "assets";
    }, "openAssetsSidebar");
    const focusAssetInSidebar = /* @__PURE__ */ __name(async (item) => {
      const task = item.taskRef;
      const promptId = task?.promptId;
      const preview = task?.previewOutput;
      if (!promptId || !preview) return;
      const assetId = String(promptId);
      openAssetsSidebar();
      await nextTick();
      await assetsStore.updateHistory();
      const asset = assetsStore.historyAssets.find(
        (existingAsset) => existingAsset.id === assetId
      );
      if (!asset) {
        throw new Error("Asset not found in media assets panel");
      }
      assetSelectionStore.setSelection([assetId]);
    }, "focusAssetInSidebar");
    const inspectJobAsset = wrapWithErrorHandlingAsync(
      async (item) => {
        openResultGallery(item);
        await focusAssetInSidebar(item);
      }
    );
    const cancelQueuedWorkflows = wrapWithErrorHandlingAsync(async () => {
      await commandStore.execute("Comfy.ClearPendingTasks");
    });
    const interruptAll = wrapWithErrorHandlingAsync(async () => {
      const tasks = queueStore.runningTasks;
      const promptIds = tasks.map((task) => task.promptId).filter((id) => typeof id === "string" && id.length > 0);
      if (!promptIds.length) return;
      await Promise.all(promptIds.map((id) => api.interrupt(id)));
    });
    const showClearHistoryDialog = /* @__PURE__ */ __name(() => {
      dialogStore.showDialog({
        key: "queue-clear-history",
        component: _sfc_main$1n,
        dialogComponentProps: {
          headless: true,
          closable: false,
          closeOnEscape: true,
          dismissableMask: true,
          pt: {
            root: {
              class: "max-w-[360px] w-auto bg-transparent border-none shadow-none"
            },
            content: {
              class: "!p-0 bg-transparent"
            }
          }
        }
      });
    }, "showClearHistoryDialog");
    const onClearHistoryFromMenu = /* @__PURE__ */ __name(() => {
      showClearHistoryDialog();
    }, "onClearHistoryFromMenu");
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        withDirectives(createBaseVNode("div", _hoisted_1$V, [
          createBaseVNode("div", {
            class: normalizeClass(["pointer-events-auto flex w-[350px] min-w-[310px] max-h-[60vh] flex-col overflow-hidden rounded-lg border font-inter transition-colors duration-200 ease-in-out", containerClass.value]),
            onMouseenter: _cache[3] || (_cache[3] = ($event) => isHovered.value = true),
            onMouseleave: _cache[4] || (_cache[4] = ($event) => isHovered.value = false)
          }, [
            isExpanded.value ? (openBlock(), createBlock(_sfc_main$1o, {
              key: 0,
              "selected-job-tab": unref(selectedJobTab),
              "onUpdate:selectedJobTab": _cache[0] || (_cache[0] = ($event) => isRef(selectedJobTab) ? selectedJobTab.value = $event : null),
              "selected-workflow-filter": unref(selectedWorkflowFilter),
              "onUpdate:selectedWorkflowFilter": _cache[1] || (_cache[1] = ($event) => isRef(selectedWorkflowFilter) ? selectedWorkflowFilter.value = $event : null),
              "selected-sort-mode": unref(selectedSortMode),
              "onUpdate:selectedSortMode": _cache[2] || (_cache[2] = ($event) => isRef(selectedSortMode) ? selectedSortMode.value = $event : null),
              class: "flex-1 min-h-0",
              "header-title": headerTitle.value,
              "show-concurrent-indicator": showConcurrentIndicator.value,
              "concurrent-workflow-count": concurrentWorkflowCount.value,
              "queued-count": queuedCount.value,
              "displayed-job-groups": displayedJobGroups.value,
              "has-failed-jobs": unref(hasFailedJobs),
              onShowAssets: openAssetsSidebar,
              onClearHistory: onClearHistoryFromMenu,
              onClearQueued: unref(cancelQueuedWorkflows),
              onCancelItem: unref(onCancelItem),
              onDeleteItem: unref(onDeleteItem),
              onViewItem: unref(inspectJobAsset)
            }, null, 8, ["selected-job-tab", "selected-workflow-filter", "selected-sort-mode", "header-title", "show-concurrent-indicator", "concurrent-workflow-count", "queued-count", "displayed-job-groups", "has-failed-jobs", "onClearQueued", "onCancelItem", "onDeleteItem", "onViewItem"])) : hasActiveJob.value ? (openBlock(), createBlock(_sfc_main$1y, {
              key: 1,
              "total-progress-style": unref(totalProgressStyle),
              "current-node-progress-style": unref(currentNodeProgressStyle),
              "total-percent-formatted": unref(totalPercentFormatted),
              "current-node-percent-formatted": unref(currentNodePercentFormatted),
              "current-node-name": unref(currentNodeName),
              "running-count": runningCount.value,
              "queued-count": queuedCount.value,
              "bottom-row-class": bottomRowClass.value,
              onInterruptAll: unref(interruptAll),
              onClearQueued: unref(cancelQueuedWorkflows),
              onViewAllJobs: viewAllJobs
            }, null, 8, ["total-progress-style", "current-node-progress-style", "total-percent-formatted", "current-node-percent-formatted", "current-node-name", "running-count", "queued-count", "bottom-row-class", "onInterruptAll", "onClearQueued"])) : unref(completionSummary) ? (openBlock(), createBlock(_sfc_main$1w, {
              key: 2,
              summary: unref(completionSummary),
              onSummaryClick
            }, null, 8, ["summary"])) : createCommentVNode("", true)
          ], 34)
        ], 512), [
          [vShow, isVisible.value]
        ]),
        createVNode(_sfc_main$1$, {
          "active-index": unref(galleryActiveIndex),
          "onUpdate:activeIndex": _cache[5] || (_cache[5] = ($event) => isRef(galleryActiveIndex) ? galleryActiveIndex.value = $event : null),
          "all-gallery-items": unref(galleryItems)
        }, null, 8, ["active-index", "all-gallery-items"])
      ], 64);
    };
  }
});
const useActionBarButtonStore = defineStore("actionBarButton", () => {
  const extensionStore = useExtensionStore();
  const buttons = computed(
    () => extensionStore.extensions.flatMap((e) => e.actionBarButtons ?? [])
  );
  return {
    buttons
  };
});
const _hoisted_1$U = { class: "flex h-full shrink-0 items-center gap-1" };
const _hoisted_2$E = { key: 0 };
const _sfc_main$1l = /* @__PURE__ */ defineComponent({
  __name: "ActionBarButtons",
  setup(__props) {
    const actionBarButtonStore = useActionBarButtonStore();
    const breakpoints = useBreakpoints(breakpointsTailwind);
    const isMobile = breakpoints.smaller("sm");
    return (_ctx, _cache) => {
      const _directive_tooltip = resolveDirective("tooltip");
      return openBlock(), createElementBlock("div", _hoisted_1$U, [
        (openBlock(true), createElementBlock(Fragment, null, renderList(unref(actionBarButtonStore).buttons, (button, index) => {
          return withDirectives((openBlock(), createBlock(_sfc_main$1Y, {
            key: index,
            "aria-label": button.tooltip || button.label,
            class: normalizeClass([button.class, "h-7 rounded-full"]),
            variant: "muted-textonly",
            size: "sm",
            onClick: button.onClick
          }, {
            default: withCtx(() => [
              createBaseVNode("i", {
                class: normalizeClass(button.icon)
              }, null, 2),
              !unref(isMobile) && button.label ? (openBlock(), createElementBlock("span", _hoisted_2$E, toDisplayString(button.label), 1)) : createCommentVNode("", true)
            ]),
            _: 2
          }, 1032, ["aria-label", "class", "onClick"])), [
            [
              _directive_tooltip,
              button.tooltip,
              void 0,
              { bottom: true }
            ]
          ]);
        }), 128))
      ]);
    };
  }
});
const _hoisted_1$T = { class: "current-user-popover w-80 -m-3 p-2 rounded-lg border border-border-default bg-base-background shadow-[1px_1px_8px_0_rgba(0,0,0,0.4)]" };
const _hoisted_2$D = { class: "flex flex-col items-center px-0 py-3 mb-4" };
const _hoisted_3$w = { class: "my-0 mb-1 truncate text-base font-bold text-base-foreground" };
const _hoisted_4$p = {
  key: 0,
  class: "my-0 truncate text-sm text-muted"
};
const _hoisted_5$l = {
  key: 1,
  class: "my-0 text-xs text-foreground bg-secondary-background-hover rounded-full uppercase px-2 py-0.5 font-bold mt-2"
};
const _hoisted_6$j = {
  key: 0,
  class: "flex items-center gap-2 px-4 py-2"
};
const _hoisted_7$e = {
  key: 1,
  class: "text-base font-semibold text-base-foreground"
};
const _hoisted_8$b = { class: "icon-[lucide--circle-help] cursor-help text-base text-muted-foreground mr-auto" };
const _hoisted_9$8 = {
  key: 1,
  class: "flex justify-center px-4"
};
const _hoisted_10$8 = { class: "text-sm text-base-foreground flex-1" };
const _hoisted_11$6 = { class: "text-sm text-base-foreground flex-1" };
const _hoisted_12$4 = {
  key: 0,
  class: "text-xs font-bold text-base-background bg-base-foreground px-1.5 py-0.5 rounded-full"
};
const _hoisted_13$4 = { class: "text-sm text-base-foreground flex-1" };
const _hoisted_14$4 = { class: "text-sm text-base-foreground flex-1" };
const _hoisted_15$3 = { class: "text-sm text-base-foreground flex-1" };
const _sfc_main$1k = /* @__PURE__ */ defineComponent({
  __name: "CurrentUserPopover",
  emits: ["close"],
  setup(__props, { emit: __emit }) {
    const emit = __emit;
    const { buildDocsUrl, docsPaths } = useExternalLink();
    const { userDisplayName, userEmail, userPhotoUrl, handleSignOut } = useCurrentUser();
    const authActions = useFirebaseAuthActions();
    const authStore = useFirebaseAuthStore();
    const dialogService = useDialogService();
    const {
      isActiveSubscription: isActiveSubscription2,
      subscriptionTierName,
      subscriptionTier,
      fetchStatus
    } = useSubscription();
    const subscriptionDialog = useSubscriptionDialog();
    const { locale } = useI18n();
    const formattedBalance = computed(() => {
      const cents = authStore.balance?.effective_balance_micros ?? authStore.balance?.amount_micros ?? 0;
      return formatCreditsFromCents({
        cents,
        locale: locale.value,
        numberOptions: {
          minimumFractionDigits: 0,
          maximumFractionDigits: 2
        }
      });
    });
    const canUpgrade = computed(() => {
      const tier = subscriptionTier.value;
      return tier === "FOUNDERS_EDITION" || tier === "STANDARD" || tier === "CREATOR";
    });
    const handleOpenUserSettings = /* @__PURE__ */ __name(() => {
      dialogService.showSettingsDialog("user");
      emit("close");
    }, "handleOpenUserSettings");
    const handleOpenPlansAndPricing = /* @__PURE__ */ __name(() => {
      subscriptionDialog.show();
      emit("close");
    }, "handleOpenPlansAndPricing");
    const handleOpenPlanAndCreditsSettings = /* @__PURE__ */ __name(() => {
      {
        dialogService.showSettingsDialog("credits");
      }
      emit("close");
    }, "handleOpenPlanAndCreditsSettings");
    const handleTopUp = /* @__PURE__ */ __name(() => {
      dialogService.showTopUpCreditsDialog();
      emit("close");
    }, "handleTopUp");
    const handleOpenPartnerNodesInfo = /* @__PURE__ */ __name(() => {
      window.open(
        buildDocsUrl(docsPaths.partnerNodesPricing, { includeLocale: true }),
        "_blank"
      );
      emit("close");
    }, "handleOpenPartnerNodesInfo");
    const handleLogout = /* @__PURE__ */ __name(async () => {
      await handleSignOut();
      emit("close");
    }, "handleLogout");
    const handleSubscribed = /* @__PURE__ */ __name(async () => {
      await fetchStatus();
    }, "handleSubscribed");
    onMounted(() => {
      void authActions.fetchBalance();
    });
    return (_ctx, _cache) => {
      const _directive_tooltip = resolveDirective("tooltip");
      return openBlock(), createElementBlock("div", _hoisted_1$T, [
        createBaseVNode("div", _hoisted_2$D, [
          createVNode(_sfc_main$20, {
            class: "mb-1",
            "photo-url": unref(userPhotoUrl),
            "pt:icon:class": {
              "text-2xl!": !unref(userPhotoUrl)
            },
            size: "large"
          }, null, 8, ["photo-url", "pt:icon:class"]),
          createBaseVNode("h3", _hoisted_3$w, toDisplayString(unref(userDisplayName) || _ctx.$t("g.user")), 1),
          unref(userEmail) ? (openBlock(), createElementBlock("p", _hoisted_4$p, toDisplayString(unref(userEmail)), 1)) : createCommentVNode("", true),
          unref(subscriptionTierName) ? (openBlock(), createElementBlock("span", _hoisted_5$l, toDisplayString(unref(subscriptionTierName)), 1)) : createCommentVNode("", true)
        ]),
        unref(isActiveSubscription2) ? (openBlock(), createElementBlock("div", _hoisted_6$j, [
          _cache[0] || (_cache[0] = createBaseVNode("i", { class: "icon-[lucide--component] text-amber-400 text-sm" }, null, -1)),
          unref(authStore).isFetchingBalance ? (openBlock(), createBlock(unref(script$a), {
            key: 0,
            width: "4rem",
            height: "1.25rem",
            class: "w-full"
          })) : (openBlock(), createElementBlock("span", _hoisted_7$e, toDisplayString(formattedBalance.value), 1)),
          withDirectives(createBaseVNode("i", _hoisted_8$b, null, 512), [
            [_directive_tooltip, { value: _ctx.$t("credits.unified.tooltip"), showDelay: 300 }]
          ]),
          createVNode(_sfc_main$1Y, {
            variant: "secondary",
            size: "sm",
            class: "text-base-foreground",
            "data-testid": "add-credits-button",
            onClick: handleTopUp
          }, {
            default: withCtx(() => [
              createTextVNode(toDisplayString(_ctx.$t("subscription.addCredits")), 1)
            ]),
            _: 1
          })
        ])) : (openBlock(), createElementBlock("div", _hoisted_9$8, [
          createVNode(_sfc_main$1G, {
            fluid: false,
            label: _ctx.$t("subscription.subscribeToComfyCloud"),
            size: "sm",
            variant: "gradient",
            onSubscribed: handleSubscribed
          }, null, 8, ["label"])
        ])),
        createVNode(unref(script$b), { class: "my-2 mx-0" }),
        unref(isActiveSubscription2) ? (openBlock(), createElementBlock("div", {
          key: 2,
          class: "flex items-center gap-2 px-4 py-2 cursor-pointer hover:bg-secondary-background-hover",
          "data-testid": "partner-nodes-menu-item",
          onClick: handleOpenPartnerNodesInfo
        }, [
          _cache[1] || (_cache[1] = createBaseVNode("i", { class: "icon-[lucide--tag] text-muted-foreground text-sm" }, null, -1)),
          createBaseVNode("span", _hoisted_10$8, toDisplayString(_ctx.$t("subscription.partnerNodesCredits")), 1)
        ])) : createCommentVNode("", true),
        createBaseVNode("div", {
          class: "flex items-center gap-2 px-4 py-2 cursor-pointer hover:bg-secondary-background-hover",
          "data-testid": "plans-pricing-menu-item",
          onClick: handleOpenPlansAndPricing
        }, [
          _cache[2] || (_cache[2] = createBaseVNode("i", { class: "icon-[lucide--receipt-text] text-muted-foreground text-sm" }, null, -1)),
          createBaseVNode("span", _hoisted_11$6, toDisplayString(_ctx.$t("subscription.plansAndPricing")), 1),
          canUpgrade.value ? (openBlock(), createElementBlock("span", _hoisted_12$4, toDisplayString(_ctx.$t("subscription.upgrade")), 1)) : createCommentVNode("", true)
        ]),
        unref(isActiveSubscription2) ? (openBlock(), createElementBlock("div", {
          key: 3,
          class: "flex items-center gap-2 px-4 py-2 cursor-pointer hover:bg-secondary-background-hover",
          "data-testid": "manage-plan-menu-item",
          onClick: handleOpenPlanAndCreditsSettings
        }, [
          _cache[3] || (_cache[3] = createBaseVNode("i", { class: "icon-[lucide--file-text] text-muted-foreground text-sm" }, null, -1)),
          createBaseVNode("span", _hoisted_13$4, toDisplayString(_ctx.$t("subscription.managePlan")), 1)
        ])) : createCommentVNode("", true),
        createBaseVNode("div", {
          class: "flex items-center gap-2 px-4 py-2 cursor-pointer hover:bg-secondary-background-hover",
          "data-testid": "user-settings-menu-item",
          onClick: handleOpenUserSettings
        }, [
          _cache[4] || (_cache[4] = createBaseVNode("i", { class: "icon-[lucide--settings-2] text-muted-foreground text-sm" }, null, -1)),
          createBaseVNode("span", _hoisted_14$4, toDisplayString(_ctx.$t("userSettings.accountSettings")), 1)
        ]),
        createVNode(unref(script$b), { class: "my-2 mx-0" }),
        createBaseVNode("div", {
          class: "flex items-center gap-2 px-4 py-2 cursor-pointer hover:bg-secondary-background-hover",
          "data-testid": "logout-menu-item",
          onClick: handleLogout
        }, [
          _cache[5] || (_cache[5] = createBaseVNode("i", { class: "icon-[lucide--log-out] text-muted-foreground text-sm" }, null, -1)),
          createBaseVNode("span", _hoisted_15$3, toDisplayString(_ctx.$t("auth.signOut.signOut")), 1)
        ])
      ]);
    };
  }
});
const _hoisted_1$S = { class: "flex items-center gap-1 rounded-full hover:bg-interface-button-hover-surface" };
const _sfc_main$1j = /* @__PURE__ */ defineComponent({
  __name: "CurrentUserButton",
  setup(__props) {
    const { isLoggedIn, userPhotoUrl } = useCurrentUser();
    const popover = ref(null);
    const photoURL = computed(
      () => userPhotoUrl.value ?? void 0
    );
    const closePopover = /* @__PURE__ */ __name(() => {
      popover.value?.hide();
    }, "closePopover");
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", null, [
        unref(isLoggedIn) ? (openBlock(), createBlock(_sfc_main$1Y, {
          key: 0,
          class: "p-1 hover:bg-transparent",
          variant: "muted-textonly",
          "aria-label": _ctx.$t("g.currentUser"),
          onClick: _cache[0] || (_cache[0] = ($event) => popover.value?.toggle($event))
        }, {
          default: withCtx(() => [
            createBaseVNode("div", _hoisted_1$S, [
              createVNode(_sfc_main$20, { "photo-url": photoURL.value }, null, 8, ["photo-url"]),
              _cache[1] || (_cache[1] = createBaseVNode("i", { class: "icon-[lucide--chevron-down] size-3 px-1" }, null, -1))
            ])
          ]),
          _: 1
        }, 8, ["aria-label"])) : createCommentVNode("", true),
        createVNode(unref(script$1), {
          ref_key: "popover",
          ref: popover,
          "show-arrow": false,
          pt: {
            root: {
              class: "rounded-lg"
            }
          }
        }, {
          default: withCtx(() => [
            createVNode(_sfc_main$1k, { onClose: closePopover })
          ]),
          _: 1
        }, 512)
      ]);
    };
  }
});
const _hoisted_1$R = { class: "mb-1" };
const _hoisted_2$C = ["href"];
const _sfc_main$1i = /* @__PURE__ */ defineComponent({
  __name: "LoginButton",
  setup(__props) {
    const { isLoggedIn, handleSignIn } = useCurrentUser();
    const { buildDocsUrl } = useExternalLink();
    const apiNodesOverviewUrl = buildDocsUrl(
      "/tutorials/api-nodes/overview#api-nodes",
      {
        includeLocale: true
      }
    );
    const popoverRef = ref(null);
    let hideTimeout = null;
    let showTimeout = null;
    const showPopover = /* @__PURE__ */ __name((event) => {
      if (hideTimeout) {
        clearTimeout(hideTimeout);
        hideTimeout = null;
      }
      if (showTimeout) {
        clearTimeout(showTimeout);
        showTimeout = null;
      }
      showTimeout = setTimeout(() => {
        if (popoverRef.value) {
          popoverRef.value.show(event, event.target);
        }
      }, 200);
    }, "showPopover");
    const cancelHidePopover = /* @__PURE__ */ __name(() => {
      if (hideTimeout) {
        clearTimeout(hideTimeout);
        hideTimeout = null;
      }
    }, "cancelHidePopover");
    const hidePopover = /* @__PURE__ */ __name(() => {
      if (showTimeout) {
        clearTimeout(showTimeout);
        showTimeout = null;
      }
      hideTimeout = setTimeout(() => {
        if (popoverRef.value) {
          popoverRef.value.hide();
        }
      }, 150);
    }, "hidePopover");
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        !unref(isLoggedIn) ? (openBlock(), createBlock(_sfc_main$1Y, {
          key: 0,
          variant: "secondary",
          size: "icon",
          class: "rounded-full bg-secondary-background text-base-foreground hover:bg-secondary-background-hover",
          "aria-label": unref(t)("g.login"),
          onClick: _cache[0] || (_cache[0] = ($event) => unref(handleSignIn)()),
          onMouseenter: showPopover,
          onMouseleave: hidePopover
        }, {
          default: withCtx(() => _cache[1] || (_cache[1] = [
            createBaseVNode("i", { class: "icon-[lucide--user] size-4" }, null, -1)
          ])),
          _: 1
        }, 8, ["aria-label"])) : createCommentVNode("", true),
        createVNode(unref(script$1), {
          ref_key: "popoverRef",
          ref: popoverRef,
          class: "p-2",
          onMouseout: hidePopover,
          onMouseover: cancelHidePopover
        }, {
          default: withCtx(() => [
            createBaseVNode("div", null, [
              createBaseVNode("div", _hoisted_1$R, toDisplayString(unref(t)("auth.loginButton.tooltipHelp")), 1),
              createBaseVNode("a", {
                href: unref(apiNodesOverviewUrl),
                target: "_blank",
                class: "text-neutral-500 hover:text-primary"
              }, toDisplayString(unref(t)("auth.loginButton.tooltipLearnMore")), 9, _hoisted_2$C)
            ])
          ]),
          _: 1
        }, 512)
      ], 64);
    };
  }
});
const _hoisted_1$Q = { class: "min-w-0 flex-1" };
const _hoisted_2$B = { class: "mx-1 flex flex-col items-end gap-1" };
const _hoisted_3$v = { class: "flex items-center gap-2" };
const _hoisted_4$o = {
  key: 0,
  class: "pointer-events-auto flex h-12 shrink-0 items-center rounded-lg border border-interface-stroke bg-comfy-menu-bg px-2 shadow-interface"
};
const _hoisted_5$k = { class: "actionbar-container pointer-events-auto flex gap-2 h-12 items-center rounded-lg border border-interface-stroke bg-comfy-menu-bg px-2 shadow-interface" };
const _hoisted_6$i = {
  key: 0,
  class: "absolute -top-1 -right-1 min-w-[16px] rounded-full bg-primary-background py-0.25 text-[10px] font-medium leading-[14px] text-white"
};
const _sfc_main$1h = /* @__PURE__ */ defineComponent({
  __name: "TopMenuSection",
  setup(__props) {
    const workspaceStore = useWorkspaceStore();
    const rightSidePanelStore = useRightSidePanelStore();
    const managerState = useManagerState();
    const { isLoggedIn } = useCurrentUser();
    const isDesktop = isElectron();
    const { t: t2 } = useI18n();
    const { toastErrorHandler } = useErrorHandling();
    const isQueueOverlayExpanded = ref(false);
    const queueStore = useQueueStore();
    const isTopMenuHovered = ref(false);
    const queuedCount = computed(() => queueStore.pendingTasks.length);
    const queueHistoryTooltipConfig = computed(
      () => buildTooltipConfig(t2("sideToolbar.queueProgressOverlay.viewJobHistory"))
    );
    const customNodesManagerTooltipConfig = computed(
      () => buildTooltipConfig(t2("menu.customNodesManager"))
    );
    const { isOpen: isRightSidePanelOpen } = storeToRefs(rightSidePanelStore);
    const rightSidePanelTooltipConfig = computed(
      () => buildTooltipConfig(t2("rightSidePanel.togglePanel"))
    );
    const legacyCommandsContainerRef = ref();
    onMounted(() => {
      if (legacyCommandsContainerRef.value) {
        app.menu.element.style.width = "fit-content";
        legacyCommandsContainerRef.value.appendChild(app.menu.element);
      }
    });
    const toggleQueueOverlay = /* @__PURE__ */ __name(() => {
      isQueueOverlayExpanded.value = !isQueueOverlayExpanded.value;
    }, "toggleQueueOverlay");
    const openCustomNodeManager = /* @__PURE__ */ __name(async () => {
      try {
        await managerState.openManager({
          initialTab: ManagerTab.All,
          showToastOnLegacyError: false
        });
      } catch (error) {
        try {
          toastErrorHandler(error);
        } catch (toastError) {
          console.error(error);
          console.error(toastError);
        }
      }
    }, "openCustomNodeManager");
    return (_ctx, _cache) => {
      const _directive_tooltip = resolveDirective("tooltip");
      return !unref(workspaceStore).focusMode ? (openBlock(), createElementBlock("div", {
        key: 0,
        class: "ml-1 flex gap-x-0.5 pt-1",
        onMouseenter: _cache[1] || (_cache[1] = ($event) => isTopMenuHovered.value = true),
        onMouseleave: _cache[2] || (_cache[2] = ($event) => isTopMenuHovered.value = false)
      }, [
        createBaseVNode("div", _hoisted_1$Q, [
          createVNode(SubgraphBreadcrumb)
        ]),
        createBaseVNode("div", _hoisted_2$B, [
          createBaseVNode("div", _hoisted_3$v, [
            unref(managerState).shouldShowManagerButtons.value ? (openBlock(), createElementBlock("div", _hoisted_4$o, [
              withDirectives((openBlock(), createBlock(_sfc_main$1Y, {
                variant: "secondary",
                size: "icon",
                "aria-label": unref(t2)("menu.customNodesManager"),
                onClick: openCustomNodeManager
              }, {
                default: withCtx(() => _cache[3] || (_cache[3] = [
                  createBaseVNode("i", { class: "icon-[lucide--puzzle] size-4" }, null, -1)
                ])),
                _: 1
              }, 8, ["aria-label"])), [
                [
                  _directive_tooltip,
                  customNodesManagerTooltipConfig.value,
                  void 0,
                  { bottom: true }
                ]
              ])
            ])) : createCommentVNode("", true),
            createBaseVNode("div", _hoisted_5$k, [
              createVNode(_sfc_main$1l),
              createBaseVNode("div", {
                ref_key: "legacyCommandsContainerRef",
                ref: legacyCommandsContainerRef,
                class: "[&:not(:has(*>*:not(:empty)))]:hidden"
              }, null, 512),
              createVNode(_sfc_main$1B),
              withDirectives((openBlock(), createBlock(_sfc_main$1Y, {
                type: "destructive",
                size: "icon",
                "aria-pressed": isQueueOverlayExpanded.value,
                "aria-label": unref(t2)("sideToolbar.queueProgressOverlay.expandCollapsedQueue"),
                onClick: toggleQueueOverlay
              }, {
                default: withCtx(() => [
                  _cache[4] || (_cache[4] = createBaseVNode("i", { class: "icon-[lucide--history] size-4" }, null, -1)),
                  queuedCount.value > 0 ? (openBlock(), createElementBlock("span", _hoisted_6$i, toDisplayString(queuedCount.value), 1)) : createCommentVNode("", true)
                ]),
                _: 1
              }, 8, ["aria-pressed", "aria-label"])), [
                [
                  _directive_tooltip,
                  queueHistoryTooltipConfig.value,
                  void 0,
                  { bottom: true }
                ]
              ]),
              unref(isLoggedIn) ? (openBlock(), createBlock(_sfc_main$1j, {
                key: 0,
                class: "shrink-0"
              })) : unref(isDesktop) ? (openBlock(), createBlock(_sfc_main$1i, { key: 1 })) : createCommentVNode("", true),
              !unref(isRightSidePanelOpen) ? withDirectives((openBlock(), createBlock(_sfc_main$1Y, {
                key: 2,
                type: "secondary",
                size: "icon",
                "aria-label": unref(t2)("rightSidePanel.togglePanel"),
                onClick: unref(rightSidePanelStore).togglePanel
              }, {
                default: withCtx(() => _cache[5] || (_cache[5] = [
                  createBaseVNode("i", { class: "icon-[lucide--panel-right] size-4" }, null, -1)
                ])),
                _: 1
              }, 8, ["aria-label", "onClick"])), [
                [
                  _directive_tooltip,
                  rightSidePanelTooltipConfig.value,
                  void 0,
                  { bottom: true }
                ]
              ]) : createCommentVNode("", true)
            ])
          ]),
          createVNode(_sfc_main$1m, {
            expanded: isQueueOverlayExpanded.value,
            "onUpdate:expanded": _cache[0] || (_cache[0] = ($event) => isQueueOverlayExpanded.value = $event),
            "menu-hovered": isTopMenuHovered.value
          }, null, 8, ["expanded", "menu-hovered"])
        ])
      ], 32)) : createCommentVNode("", true);
    };
  }
});
const _sfc_main$1g = /* @__PURE__ */ defineComponent({
  __name: "ExtensionSlot",
  props: {
    extension: {}
  },
  setup(__props) {
    const props = __props;
    const mountCustomExtension = /* @__PURE__ */ __name((extension, el) => {
      extension.render(el);
    }, "mountCustomExtension");
    onBeforeUnmount(() => {
      if (props.extension.type === "custom" && props.extension.destroy) {
        props.extension.destroy();
      }
    });
    return (_ctx, _cache) => {
      return _ctx.extension.type === "vue" ? (openBlock(), createBlock(resolveDynamicComponent(_ctx.extension.component), { key: 0 })) : (openBlock(), createElementBlock("div", {
        key: 1,
        ref: /* @__PURE__ */ __name((el) => {
          if (el)
            mountCustomExtension(
              props.extension,
              el
            );
        }, "ref")
      }, null, 512));
    };
  }
});
const _hoisted_1$P = { class: "flex h-full flex-col" };
const _hoisted_2$A = { class: "flex w-full justify-between" };
const _hoisted_3$u = { class: "tabs-container font-inter" };
const _hoisted_4$n = { class: "font-normal" };
const _hoisted_5$j = { class: "flex items-center gap-2" };
const _hoisted_6$h = { class: "h-0 grow" };
const _sfc_main$1f = /* @__PURE__ */ defineComponent({
  __name: "BottomPanel",
  setup(__props) {
    const bottomPanelStore = useBottomPanelStore();
    const dialogService = useDialogService();
    const { t: t2 } = useI18n();
    const isShortcutsTabActive = computed(() => {
      const activeTabId = bottomPanelStore.activeBottomPanelTabId;
      return activeTabId === "shortcuts-essentials" || activeTabId === "shortcuts-view-controls";
    });
    const shouldCapitalizeTab = /* @__PURE__ */ __name((tabId) => {
      return tabId !== "shortcuts-essentials" && tabId !== "shortcuts-view-controls";
    }, "shouldCapitalizeTab");
    const getTabDisplayTitle = /* @__PURE__ */ __name((tab) => {
      const title = tab.titleKey ? t2(tab.titleKey) : tab.title || "";
      return shouldCapitalizeTab(tab.id) ? title.toUpperCase() : title;
    }, "getTabDisplayTitle");
    const openKeybindingSettings = /* @__PURE__ */ __name(async () => {
      dialogService.showSettingsDialog("keybinding");
    }, "openKeybindingSettings");
    const closeBottomPanel = /* @__PURE__ */ __name(() => {
      bottomPanelStore.activePanel = null;
    }, "closeBottomPanel");
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$P, [
        (openBlock(), createBlock(unref(script$c), {
          key: _ctx.$i18n.locale,
          value: unref(bottomPanelStore).activeBottomPanelTabId,
          "onUpdate:value": _cache[0] || (_cache[0] = ($event) => unref(bottomPanelStore).activeBottomPanelTabId = $event),
          style: { "--p-tabs-tablist-background": "var(--comfy-menu-bg)" }
        }, {
          default: withCtx(() => [
            createVNode(unref(script$d), {
              "pt:tab-list": "border-none h-full flex items-center py-2 border-b-1 border-solid",
              class: "bg-transparent"
            }, {
              default: withCtx(() => [
                createBaseVNode("div", _hoisted_2$A, [
                  createBaseVNode("div", _hoisted_3$u, [
                    (openBlock(true), createElementBlock(Fragment, null, renderList(unref(bottomPanelStore).bottomPanelTabs, (tab) => {
                      return openBlock(), createBlock(unref(script$e), {
                        key: tab.id,
                        value: tab.id,
                        class: normalizeClass(["m-1 mx-2 border-none font-inter", {
                          "tab-list-single-item": unref(bottomPanelStore).bottomPanelTabs.length === 1
                        }]),
                        "pt:root": /* @__PURE__ */ __name((x) => ({
                          class: {
                            "p-3 rounded-lg": true,
                            "pointer-events-none": unref(bottomPanelStore).bottomPanelTabs.length === 1
                          },
                          style: {
                            color: "var(--fg-color)",
                            backgroundColor: !x.context.active || unref(bottomPanelStore).bottomPanelTabs.length === 1 ? "" : "var(--bg-color)"
                          }
                        }), "pt:root")
                      }, {
                        default: withCtx(() => [
                          createBaseVNode("span", _hoisted_4$n, toDisplayString(getTabDisplayTitle(tab)), 1)
                        ]),
                        _: 2
                      }, 1032, ["value", "class", "pt:root"]);
                    }), 128))
                  ]),
                  createBaseVNode("div", _hoisted_5$j, [
                    isShortcutsTabActive.value ? (openBlock(), createBlock(_sfc_main$1Y, {
                      key: 0,
                      variant: "muted-textonly",
                      size: "sm",
                      onClick: openKeybindingSettings
                    }, {
                      default: withCtx(() => [
                        _cache[1] || (_cache[1] = createBaseVNode("i", { class: "pi pi-cog" }, null, -1)),
                        createTextVNode(" " + toDisplayString(_ctx.$t("shortcuts.manageShortcuts")), 1)
                      ]),
                      _: 1
                    })) : createCommentVNode("", true),
                    createVNode(_sfc_main$1Y, {
                      class: "justify-self-end",
                      variant: "muted-textonly",
                      size: "sm",
                      "aria-label": unref(t2)("g.close"),
                      onClick: closeBottomPanel
                    }, {
                      default: withCtx(() => _cache[2] || (_cache[2] = [
                        createBaseVNode("i", { class: "pi pi-times" }, null, -1)
                      ])),
                      _: 1
                    }, 8, ["aria-label"])
                  ])
                ])
              ]),
              _: 1
            })
          ]),
          _: 1
        }, 8, ["value"])),
        createBaseVNode("div", _hoisted_6$h, [
          unref(bottomPanelStore).bottomPanelVisible && unref(bottomPanelStore).activeBottomPanelTab ? (openBlock(), createBlock(_sfc_main$1g, {
            key: 0,
            extension: unref(bottomPanelStore).activeBottomPanelTab
          }, null, 8, ["extension"])) : createCommentVNode("", true)
        ])
      ]);
    };
  }
});
const BottomPanel = /* @__PURE__ */ _export_sfc(_sfc_main$1f, [["__scopeId", "data-v-9d1ea2c9"]]);
function useAbsolutePosition(options = {}) {
  const { useTransform = false } = options;
  const canvasStore = useCanvasStore();
  const lgCanvas = canvasStore.getCanvas();
  const { canvasPosToClientPos, update: updateCanvasPosition } = useCanvasPositionConversion(lgCanvas.canvas, lgCanvas);
  const settingStore = useSettingStore();
  watch(
    [
      () => settingStore.get("Comfy.Sidebar.Location"),
      () => settingStore.get("Comfy.Sidebar.Size"),
      () => settingStore.get("Comfy.UseNewMenu")
    ],
    () => updateCanvasPosition(),
    { flush: "post" }
  );
  const style = ref({});
  const computeStyle = /* @__PURE__ */ __name((position) => {
    const { pos, size, scale = lgCanvas.ds.scale } = position;
    const [left, top] = canvasPosToClientPos(pos);
    const [width, height] = size;
    return useTransform ? {
      position: "fixed",
      transformOrigin: "0 0",
      transform: `scale(${scale})`,
      left: `${left}px`,
      top: `${top}px`,
      width: `${width}px`,
      height: `${height}px`
    } : {
      position: "fixed",
      left: `${left}px`,
      top: `${top}px`,
      width: `${width * scale}px`,
      height: `${height * scale}px`
    };
  }, "computeStyle");
  const updatePosition = /* @__PURE__ */ __name((config2) => {
    style.value = computeStyle(config2);
  }, "updatePosition");
  return {
    style,
    updatePosition
  };
}
__name(useAbsolutePosition, "useAbsolutePosition");
function intersect(a, b) {
  const x1 = Math.max(a.x, b.x);
  const y1 = Math.max(a.y, b.y);
  const x2 = Math.min(a.x + a.width, b.x + b.width);
  const y2 = Math.min(a.y + a.height, b.y + b.height);
  if (x1 >= x2 || y1 >= y2) {
    return null;
  }
  return [x1, y1, x2 - x1, y2 - y1];
}
__name(intersect, "intersect");
const useDomClipping = /* @__PURE__ */ __name((options = {}) => {
  const style = ref({});
  const { margin = 4 } = options;
  const calculateClipPath = /* @__PURE__ */ __name((elementRect, canvasRect, isSelected, selectedArea) => {
    if (!isSelected && selectedArea) {
      const { scale, offset } = selectedArea;
      const intersection = intersect(
        {
          x: elementRect.left - canvasRect.left,
          y: elementRect.top - canvasRect.top,
          width: elementRect.width,
          height: elementRect.height
        },
        {
          x: (selectedArea.x + offset[0] - margin) * scale,
          y: (selectedArea.y + offset[1] - margin) * scale,
          width: (selectedArea.width + 2 * margin) * scale,
          height: (selectedArea.height + 2 * margin) * scale
        }
      );
      if (!intersection) {
        return "";
      }
      const clipX = (intersection[0] - elementRect.left + canvasRect.left) / scale + "px";
      const clipY = (intersection[1] - elementRect.top + canvasRect.top) / scale + "px";
      const clipWidth = intersection[2] / scale + "px";
      const clipHeight = intersection[3] / scale + "px";
      return `polygon(0% 0%, 0% 100%, ${clipX} 100%, ${clipX} ${clipY}, calc(${clipX} + ${clipWidth}) ${clipY}, calc(${clipX} + ${clipWidth}) calc(${clipY} + ${clipHeight}), ${clipX} calc(${clipY} + ${clipHeight}), ${clipX} 100%, 100% 100%, 100% 0%)`;
    }
    return "";
  }, "calculateClipPath");
  const updateClipPath = /* @__PURE__ */ __name((element, canvasElement, isSelected, selectedArea) => {
    const elementRect = element.getBoundingClientRect();
    const canvasRect = canvasElement.getBoundingClientRect();
    const clipPath = calculateClipPath(
      elementRect,
      canvasRect,
      isSelected,
      selectedArea
    );
    style.value = {
      clipPath: clipPath || "none",
      willChange: "clip-path"
    };
  }, "updateClipPath");
  return {
    style,
    updateClipPath
  };
}, "useDomClipping");
const _hoisted_1$O = ["title"];
const _sfc_main$1e = /* @__PURE__ */ defineComponent({
  __name: "DomWidget",
  props: {
    widgetState: {}
  },
  emits: ["update:widgetValue"],
  setup(__props, { emit: __emit }) {
    const widget = __props.widgetState.widget;
    const emit = __emit;
    const widgetElement = ref();
    const style = ref({});
    const { style: positionStyle, updatePosition } = useAbsolutePosition({
      useTransform: true
    });
    const { style: clippingStyle, updateClipPath } = useDomClipping();
    const canvasStore = useCanvasStore();
    const settingStore = useSettingStore();
    const enableDomClipping = computed(
      () => settingStore.get("Comfy.DOMClippingEnabled")
    );
    const updateDomClipping = /* @__PURE__ */ __name(() => {
      const lgCanvas = canvasStore.canvas;
      if (!lgCanvas || !widgetElement.value) return;
      const selectedNode = Object.values(lgCanvas.selected_nodes ?? {})[0];
      if (!selectedNode) {
        updateClipPath(widgetElement.value, lgCanvas.canvas, false, void 0);
        return;
      }
      const isSelected = selectedNode === __props.widgetState.widget.node;
      const renderArea = selectedNode?.renderArea;
      const offset = lgCanvas.ds.offset;
      const scale = lgCanvas.ds.scale;
      const selectedAreaConfig = renderArea ? {
        x: renderArea[0],
        y: renderArea[1],
        width: renderArea[2],
        height: renderArea[3],
        scale,
        offset: [offset[0], offset[1]]
      } : void 0;
      updateClipPath(
        widgetElement.value,
        lgCanvas.canvas,
        isSelected,
        selectedAreaConfig
      );
    }, "updateDomClipping");
    const { left, top } = useElementBounding(canvasStore.getCanvas().canvas);
    watch(
      [() => __props.widgetState, left, top],
      ([widgetState, _, __]) => {
        updatePosition(widgetState);
        if (enableDomClipping.value) {
          updateDomClipping();
        }
        style.value = {
          ...positionStyle.value,
          ...enableDomClipping.value ? clippingStyle.value : {},
          zIndex: widgetState.zIndex,
          pointerEvents: widgetState.readonly || widget.computedDisabled ? "none" : "auto",
          opacity: widget.computedDisabled ? 0.5 : 1
        };
      },
      { deep: true }
    );
    watch(
      () => __props.widgetState.visible,
      (newVisible, oldVisible) => {
        if (!newVisible && oldVisible) {
          widget.options.onHide?.(widget);
        }
      }
    );
    useEventListener(document, "mousedown", (event) => {
      if (!isDOMWidget(widget) || !__props.widgetState.visible || !widget.element.blur) {
        return;
      }
      if (!widget.element.contains(event.target)) {
        widget.element.blur();
      }
    });
    onMounted(() => {
      if (!isDOMWidget(widget)) {
        return;
      }
      useEventListener(
        widget.element,
        widget.options.selectOn ?? ["focus", "click"],
        () => {
          const lgCanvas = canvasStore.canvas;
          lgCanvas?.selectNode(__props.widgetState.widget.node);
          lgCanvas?.bringToFront(__props.widgetState.widget.node);
        }
      );
    });
    const inputSpec = widget.node.constructor.nodeData;
    const tooltip = inputSpec?.inputs?.[widget.name]?.tooltip;
    const mountElementIfVisible = /* @__PURE__ */ __name(() => {
      if (!(__props.widgetState.visible && isDOMWidget(widget) && widgetElement.value)) {
        return;
      }
      if (widgetElement.value.contains(widget.element)) {
        return;
      }
      widgetElement.value.appendChild(widget.element);
    }, "mountElementIfVisible");
    onMounted(() => {
      nextTick(() => {
        mountElementIfVisible();
      }).catch((error) => {
        console.error("Error mounting DOM widget element:", error);
      });
    });
    watch(
      () => __props.widgetState.visible,
      () => {
        mountElementIfVisible();
      }
    );
    return (_ctx, _cache) => {
      return withDirectives((openBlock(), createElementBlock("div", {
        ref_key: "widgetElement",
        ref: widgetElement,
        class: "dom-widget",
        title: unref(tooltip),
        style: normalizeStyle(style.value)
      }, [
        unref(isComponentWidget)(unref(widget)) ? (openBlock(), createBlock(resolveDynamicComponent(unref(widget).component), mergeProps({
          key: 0,
          "model-value": unref(widget).value,
          widget: unref(widget)
        }, unref(widget).props, {
          "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => emit("update:widgetValue", $event))
        }), null, 16, ["model-value", "widget"])) : createCommentVNode("", true)
      ], 12, _hoisted_1$O)), [
        [vShow, _ctx.widgetState.visible]
      ]);
    };
  }
});
const DomWidget = /* @__PURE__ */ _export_sfc(_sfc_main$1e, [["__scopeId", "data-v-781496d2"]]);
const _hoisted_1$N = { class: "isolate" };
const _sfc_main$1d = /* @__PURE__ */ defineComponent({
  __name: "DomWidgets",
  setup(__props) {
    const domWidgetStore = useDomWidgetStore();
    const widgetStates = computed(() => [...domWidgetStore.widgetStates.values()]);
    const updateWidgets = /* @__PURE__ */ __name(() => {
      const lgCanvas = canvasStore.canvas;
      if (!lgCanvas) return;
      const lowQuality = lgCanvas.low_quality;
      const currentGraph = lgCanvas.graph;
      for (const widgetState of widgetStates.value) {
        const widget = widgetState.widget;
        if (!widget.isVisible() || !widgetState.active) {
          widgetState.visible = false;
          continue;
        }
        const node = widget.node;
        const isInCorrectGraph = currentGraph?.nodes.includes(node);
        widgetState.visible = !!isInCorrectGraph && lgCanvas.isNodeVisible(node) && !(widget.options.hideOnZoom && lowQuality);
        if (widgetState.visible && node) {
          const margin = widget.margin;
          widgetState.pos = [node.pos[0] + margin, node.pos[1] + margin + widget.y];
          widgetState.size = [
            (widget.width ?? node.width) - margin * 2,
            (widget.computedHeight ?? 50) - margin * 2
          ];
          widgetState.zIndex = lgCanvas.graph?.nodes.indexOf(node) ?? -1;
          widgetState.readonly = lgCanvas.read_only;
        }
      }
    }, "updateWidgets");
    const canvasStore = useCanvasStore();
    whenever(
      () => canvasStore.canvas,
      (canvas) => canvas.onDrawForeground = useChainCallback(
        canvas.onDrawForeground,
        updateWidgets
      ),
      { immediate: true }
    );
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$N, [
        (openBlock(true), createElementBlock(Fragment, null, renderList(widgetStates.value, (widgetState) => {
          return openBlock(), createBlock(DomWidget, {
            key: widgetState.widget.id,
            "widget-state": widgetState,
            "onUpdate:widgetValue": /* @__PURE__ */ __name(($event) => widgetState.widget.value = $event, "onUpdate:widgetValue")
          }, null, 8, ["widget-state", "onUpdate:widgetValue"]);
        }), 128))
      ]);
    };
  }
});
function useZoomControls() {
  const isModalVisible = ref(false);
  const showModal = /* @__PURE__ */ __name(() => {
    isModalVisible.value = true;
  }, "showModal");
  const hideModal = /* @__PURE__ */ __name(() => {
    isModalVisible.value = false;
  }, "hideModal");
  const toggleModal = /* @__PURE__ */ __name(() => {
    isModalVisible.value = !isModalVisible.value;
  }, "toggleModal");
  const hasActivePopup = computed(() => isModalVisible.value);
  return {
    isModalVisible,
    showModal,
    hideModal,
    toggleModal,
    hasActivePopup
  };
}
__name(useZoomControls, "useZoomControls");
function useMinimapGraph(graph, onGraphChanged) {
  const nodeStatesCache = /* @__PURE__ */ new Map();
  const linksCache = ref("");
  const lastNodeCount = ref(0);
  const updateFlags = ref({
    bounds: false,
    nodes: false,
    connections: false,
    viewport: false
  });
  const layoutStoreVersion = layoutStore.getVersion();
  const originalCallbacksMap = /* @__PURE__ */ new Map();
  const handleGraphChangedThrottled = useThrottleFn(() => {
    onGraphChanged();
  }, 500);
  const setupEventListeners = /* @__PURE__ */ __name(() => {
    const g = graph.value;
    if (!g) return;
    if (originalCallbacksMap.has(g.id)) {
      return;
    }
    const originalCallbacks = {
      onNodeAdded: g.onNodeAdded,
      onNodeRemoved: g.onNodeRemoved,
      onConnectionChange: g.onConnectionChange,
      onTrigger: g.onTrigger
    };
    originalCallbacksMap.set(g.id, originalCallbacks);
    g.onNodeAdded = function(node) {
      originalCallbacks.onNodeAdded?.call(this, node);
      void handleGraphChangedThrottled();
    };
    g.onNodeRemoved = function(node) {
      originalCallbacks.onNodeRemoved?.call(this, node);
      nodeStatesCache.delete(node.id);
      void handleGraphChangedThrottled();
    };
    g.onConnectionChange = function(node) {
      originalCallbacks.onConnectionChange?.call(this, node);
      void handleGraphChangedThrottled();
    };
    g.onTrigger = function(event) {
      originalCallbacks.onTrigger?.call(this, event);
      if (event.type === "node:property:changed" && (event.property === "mode" || event.property === "bgcolor" || event.property === "color")) {
        nodeStatesCache.delete(String(event.nodeId));
        void handleGraphChangedThrottled();
      }
    };
  }, "setupEventListeners");
  const cleanupEventListeners = /* @__PURE__ */ __name((oldGraph) => {
    const g = oldGraph || graph.value;
    if (!g) return;
    const originalCallbacks = originalCallbacksMap.get(g.id);
    if (!originalCallbacks) {
      console.error(
        "Attempted to cleanup event listeners for graph that was never set up"
      );
      return;
    }
    g.onNodeAdded = originalCallbacks.onNodeAdded;
    g.onNodeRemoved = originalCallbacks.onNodeRemoved;
    g.onConnectionChange = originalCallbacks.onConnectionChange;
    g.onTrigger = originalCallbacks.onTrigger;
    originalCallbacksMap.delete(g.id);
  }, "cleanupEventListeners");
  const checkForChangesInternal = /* @__PURE__ */ __name(() => {
    const g = graph.value;
    if (!g) return false;
    let structureChanged = false;
    let positionChanged = false;
    let connectionChanged = false;
    const dataSource = MinimapDataSourceFactory.create(g);
    const currentNodeCount = dataSource.getNodeCount();
    if (currentNodeCount !== lastNodeCount.value) {
      structureChanged = true;
      lastNodeCount.value = currentNodeCount;
    }
    const nodes = dataSource.getNodes();
    for (const node of nodes) {
      const nodeId = node.id;
      const currentState = `${node.x},${node.y},${node.width},${node.height}`;
      if (nodeStatesCache.get(nodeId) !== currentState) {
        positionChanged = true;
        nodeStatesCache.set(nodeId, currentState);
      }
    }
    const currentNodeIds = new Set(nodes.map((n) => n.id));
    for (const [nodeId] of nodeStatesCache) {
      if (!currentNodeIds.has(nodeId)) {
        nodeStatesCache.delete(nodeId);
        structureChanged = true;
      }
    }
    const currentLinks = JSON.stringify(g.links || {});
    if (currentLinks !== linksCache.value) {
      connectionChanged = true;
      linksCache.value = currentLinks;
    }
    if (structureChanged || positionChanged) {
      updateFlags.value.bounds = true;
      updateFlags.value.nodes = true;
    }
    if (connectionChanged) {
      updateFlags.value.connections = true;
    }
    return structureChanged || positionChanged || connectionChanged;
  }, "checkForChangesInternal");
  const init = /* @__PURE__ */ __name(() => {
    setupEventListeners();
    api.addEventListener("graphChanged", handleGraphChangedThrottled);
    watch(layoutStoreVersion, () => {
      void handleGraphChangedThrottled();
    });
  }, "init");
  const destroy = /* @__PURE__ */ __name(() => {
    cleanupEventListeners();
    api.removeEventListener("graphChanged", handleGraphChangedThrottled);
    nodeStatesCache.clear();
  }, "destroy");
  const clearCache = /* @__PURE__ */ __name(() => {
    nodeStatesCache.clear();
    linksCache.value = "";
    lastNodeCount.value = 0;
  }, "clearCache");
  return {
    updateFlags,
    setupEventListeners,
    cleanupEventListeners,
    checkForChanges: checkForChangesInternal,
    init,
    destroy,
    clearCache
  };
}
__name(useMinimapGraph, "useMinimapGraph");
function useMinimapInteraction(containerRef, bounds, scale, width, height, centerViewOn, canvas) {
  const isDragging = ref(false);
  const containerRect = ref({
    left: 0,
    top: 0,
    width,
    height
  });
  const updateContainerRect = /* @__PURE__ */ __name(() => {
    if (!containerRef.value) return;
    const rect = containerRef.value.getBoundingClientRect();
    containerRect.value = {
      left: rect.left,
      top: rect.top,
      width: rect.width,
      height: rect.height
    };
  }, "updateContainerRect");
  const handlePointerDown = /* @__PURE__ */ __name((e) => {
    isDragging.value = true;
    updateContainerRect();
    const target = e.currentTarget;
    if (target instanceof HTMLElement) {
      target.setPointerCapture(e.pointerId);
    }
    handlePointerMove(e);
  }, "handlePointerDown");
  const handlePointerMove = /* @__PURE__ */ __name((e) => {
    if (!isDragging.value || !canvas.value) return;
    const x = e.clientX - containerRect.value.left;
    const y = e.clientY - containerRect.value.top;
    const offsetX = (width - bounds.value.width * scale.value) / 2;
    const offsetY = (height - bounds.value.height * scale.value) / 2;
    const worldX = (x - offsetX) / scale.value + bounds.value.minX;
    const worldY = (y - offsetY) / scale.value + bounds.value.minY;
    centerViewOn(worldX, worldY);
  }, "handlePointerMove");
  const releasePointer = /* @__PURE__ */ __name((e) => {
    isDragging.value = false;
    if (!e) return;
    const target = e.currentTarget;
    if (target instanceof HTMLElement && target.hasPointerCapture(e.pointerId)) {
      target.releasePointerCapture(e.pointerId);
    }
  }, "releasePointer");
  const handlePointerUp = releasePointer;
  const handlePointerCancel = releasePointer;
  const handleWheel = /* @__PURE__ */ __name((e) => {
    e.preventDefault();
    const c = canvas.value;
    if (!c) return;
    if (containerRect.value.left === 0 && containerRect.value.top === 0 && containerRef.value) {
      updateContainerRect();
    }
    const ds = c.ds;
    const delta = e.deltaY > 0 ? 0.9 : 1.1;
    const newScale = ds.scale * delta;
    const MIN_SCALE = 0.1;
    const MAX_SCALE = 10;
    if (newScale < MIN_SCALE || newScale > MAX_SCALE) return;
    const x = e.clientX - containerRect.value.left;
    const y = e.clientY - containerRect.value.top;
    const offsetX = (width - bounds.value.width * scale.value) / 2;
    const offsetY = (height - bounds.value.height * scale.value) / 2;
    const worldX = (x - offsetX) / scale.value + bounds.value.minX;
    const worldY = (y - offsetY) / scale.value + bounds.value.minY;
    ds.scale = newScale;
    centerViewOn(worldX, worldY);
  }, "handleWheel");
  return {
    isDragging,
    containerRect,
    updateContainerRect,
    handlePointerDown,
    handlePointerMove,
    handlePointerUp,
    handlePointerCancel,
    handleWheel
  };
}
__name(useMinimapInteraction, "useMinimapInteraction");
function useMinimapRenderer(canvasRef, graph, bounds, scale, updateFlags, settings, width, height) {
  const needsFullRedraw = ref(true);
  const needsBoundsUpdate = ref(true);
  const renderMinimap = /* @__PURE__ */ __name(() => {
    const g = graph.value;
    if (!canvasRef.value || !g) return;
    const ctx = canvasRef.value.getContext("2d");
    if (!ctx) return;
    if (!g._nodes || g._nodes.length === 0) {
      ctx.clearRect(0, 0, width, height);
      return;
    }
    const needsRedraw = needsFullRedraw.value || updateFlags.value.nodes || updateFlags.value.connections;
    if (needsRedraw) {
      renderMinimapToCanvas(canvasRef.value, g, {
        bounds: bounds.value,
        scale: scale.value,
        settings: {
          nodeColors: settings.nodeColors.value,
          showLinks: settings.showLinks.value,
          showGroups: settings.showGroups.value,
          renderBypass: settings.renderBypass.value,
          renderError: settings.renderError.value
        },
        width,
        height
      });
      needsFullRedraw.value = false;
      updateFlags.value.nodes = false;
      updateFlags.value.connections = false;
    }
  }, "renderMinimap");
  const updateMinimap = /* @__PURE__ */ __name((updateBounds, updateViewport) => {
    if (needsBoundsUpdate.value || updateFlags.value.bounds) {
      updateBounds();
      needsBoundsUpdate.value = false;
      updateFlags.value.bounds = false;
      needsFullRedraw.value = true;
      updateFlags.value.viewport = true;
    }
    if (needsFullRedraw.value || updateFlags.value.nodes || updateFlags.value.connections) {
      renderMinimap();
    }
    if (updateFlags.value.viewport) {
      updateViewport();
      updateFlags.value.viewport = false;
    }
  }, "updateMinimap");
  const forceFullRedraw = /* @__PURE__ */ __name(() => {
    needsFullRedraw.value = true;
    updateFlags.value.bounds = true;
    updateFlags.value.nodes = true;
    updateFlags.value.connections = true;
    updateFlags.value.viewport = true;
  }, "forceFullRedraw");
  return {
    needsFullRedraw,
    needsBoundsUpdate,
    renderMinimap,
    updateMinimap,
    forceFullRedraw
  };
}
__name(useMinimapRenderer, "useMinimapRenderer");
function useMinimapSettings() {
  const settingStore = useSettingStore();
  const colorPaletteStore = useColorPaletteStore();
  const nodeColors = computed(
    () => settingStore.get("Comfy.Minimap.NodeColors")
  );
  const showLinks = computed(() => settingStore.get("Comfy.Minimap.ShowLinks"));
  const showGroups = computed(
    () => settingStore.get("Comfy.Minimap.ShowGroups")
  );
  const renderBypass = computed(
    () => settingStore.get("Comfy.Minimap.RenderBypassState")
  );
  const renderError = computed(
    () => settingStore.get("Comfy.Minimap.RenderErrorState")
  );
  const width = 253;
  const height = 200;
  const isLightTheme = computed(
    () => colorPaletteStore.completedActivePalette.light_theme
  );
  const containerStyles = computed(() => ({
    width: `${width}px`,
    height: `${height}px`,
    border: "1px solid var(--interface-stroke)",
    borderRadius: "8px"
  }));
  const panelStyles = computed(() => ({
    width: `210px`,
    height: `${height}px`,
    border: "1px solid var(--interface-stroke)",
    borderRadius: "8px"
  }));
  return {
    nodeColors,
    showLinks,
    showGroups,
    renderBypass,
    renderError,
    containerStyles,
    panelStyles,
    isLightTheme
  };
}
__name(useMinimapSettings, "useMinimapSettings");
function useMinimapViewport(canvas, graph, width, height) {
  const bounds = ref({
    minX: 0,
    minY: 0,
    maxX: 0,
    maxY: 0,
    width: 0,
    height: 0
  });
  const scale = ref(1);
  const viewportTransform = ref({
    x: 0,
    y: 0,
    width: 0,
    height: 0
  });
  const canvasDimensions = ref({
    width: 0,
    height: 0
  });
  const updateCanvasDimensions = /* @__PURE__ */ __name(() => {
    const c = canvas.value;
    if (!c) return;
    const canvasEl = c.canvas;
    const dpr = window.devicePixelRatio || 1;
    canvasDimensions.value = {
      width: canvasEl.clientWidth || canvasEl.width / dpr,
      height: canvasEl.clientHeight || canvasEl.height / dpr
    };
  }, "updateCanvasDimensions");
  const calculateGraphBounds = /* @__PURE__ */ __name(() => {
    const dataSource = MinimapDataSourceFactory.create(graph.value);
    if (!dataSource.hasData()) {
      return { minX: 0, minY: 0, maxX: 100, maxY: 100, width: 100, height: 100 };
    }
    const sourceBounds = dataSource.getBounds();
    return enforceMinimumBounds(sourceBounds);
  }, "calculateGraphBounds");
  const calculateScale = /* @__PURE__ */ __name(() => {
    return calculateMinimapScale(bounds.value, width, height);
  }, "calculateScale");
  const updateViewport = /* @__PURE__ */ __name(() => {
    const c = canvas.value;
    if (!c) return;
    if (canvasDimensions.value.width === 0 || canvasDimensions.value.height === 0) {
      updateCanvasDimensions();
    }
    const ds = c.ds;
    const viewportWidth = canvasDimensions.value.width / ds.scale;
    const viewportHeight = canvasDimensions.value.height / ds.scale;
    const worldX = -ds.offset[0];
    const worldY = -ds.offset[1];
    const centerOffsetX = (width - bounds.value.width * scale.value) / 2;
    const centerOffsetY = (height - bounds.value.height * scale.value) / 2;
    viewportTransform.value = {
      x: (worldX - bounds.value.minX) * scale.value + centerOffsetX,
      y: (worldY - bounds.value.minY) * scale.value + centerOffsetY,
      width: viewportWidth * scale.value,
      height: viewportHeight * scale.value
    };
  }, "updateViewport");
  const updateBounds = /* @__PURE__ */ __name(() => {
    bounds.value = calculateGraphBounds();
    scale.value = calculateScale();
  }, "updateBounds");
  const centerViewOn = /* @__PURE__ */ __name((worldX, worldY) => {
    const c = canvas.value;
    if (!c) return;
    if (canvasDimensions.value.width === 0 || canvasDimensions.value.height === 0) {
      updateCanvasDimensions();
    }
    const ds = c.ds;
    const viewportWidth = canvasDimensions.value.width / ds.scale;
    const viewportHeight = canvasDimensions.value.height / ds.scale;
    ds.offset[0] = -(worldX - viewportWidth / 2);
    ds.offset[1] = -(worldY - viewportHeight / 2);
    c.setDirty(true, true);
  }, "centerViewOn");
  const { resume: startViewportSync, pause: stopViewportSync } = useRafFn(updateViewport);
  return {
    bounds: computed(() => bounds.value),
    scale: computed(() => scale.value),
    viewportTransform: computed(() => viewportTransform.value),
    canvasDimensions: computed(() => canvasDimensions.value),
    updateCanvasDimensions,
    updateViewport,
    updateBounds,
    centerViewOn,
    startViewportSync,
    stopViewportSync
  };
}
__name(useMinimapViewport, "useMinimapViewport");
function useMinimap({
  canvasRefMaybe,
  containerRefMaybe
} = {}) {
  const canvasStore = useCanvasStore();
  const workflowStore = useWorkflowStore();
  const settingStore = useSettingStore();
  const minimapRef = ref(null);
  const canvasRef = canvasRefMaybe ?? shallowRef(null);
  const containerRef = containerRefMaybe ?? shallowRef(null);
  const visible = ref(true);
  const initialized = ref(false);
  const width = 250;
  const height = 200;
  const canvas = computed(() => canvasStore.canvas);
  const graph = computed(() => {
    const activeSubgraph = workflowStore.activeSubgraph;
    return activeSubgraph || canvas.value?.graph;
  });
  const settings = useMinimapSettings();
  const {
    nodeColors,
    showLinks,
    showGroups,
    renderBypass,
    renderError,
    containerStyles,
    panelStyles
  } = settings;
  const updateOption = /* @__PURE__ */ __name(async (key, value) => {
    await settingStore.set(key, value);
    renderer.forceFullRedraw();
    renderer.updateMinimap(viewport.updateBounds, viewport.updateViewport);
  }, "updateOption");
  const viewport = useMinimapViewport(canvas, graph, width, height);
  const interaction = useMinimapInteraction(
    containerRef,
    viewport.bounds,
    viewport.scale,
    width,
    height,
    viewport.centerViewOn,
    canvas
  );
  const graphManager = useMinimapGraph(graph, () => {
    renderer.forceFullRedraw();
    renderer.updateMinimap(viewport.updateBounds, viewport.updateViewport);
  });
  const renderer = useMinimapRenderer(
    canvasRef,
    graph,
    viewport.bounds,
    viewport.scale,
    graphManager.updateFlags,
    settings,
    width,
    height
  );
  const { pause: pauseChangeDetection, resume: resumeChangeDetection } = useRafFn(
    async () => {
      if (visible.value) {
        const hasChanges = await graphManager.checkForChanges();
        if (hasChanges) {
          renderer.updateMinimap(
            viewport.updateBounds,
            viewport.updateViewport
          );
        }
      }
    },
    { immediate: false }
  );
  const init = /* @__PURE__ */ __name(async () => {
    if (initialized.value) return;
    visible.value = settingStore.get("Comfy.Minimap.Visible");
    if (canvas.value && graph.value) {
      graphManager.init();
      if (containerRef.value) {
        interaction.updateContainerRect();
      }
      viewport.updateCanvasDimensions();
      window.addEventListener("resize", interaction.updateContainerRect);
      window.addEventListener("scroll", interaction.updateContainerRect);
      window.addEventListener("resize", viewport.updateCanvasDimensions);
      renderer.forceFullRedraw();
      renderer.updateMinimap(viewport.updateBounds, viewport.updateViewport);
      viewport.updateViewport();
      if (visible.value) {
        resumeChangeDetection();
        viewport.startViewportSync();
      }
      initialized.value = true;
    }
  }, "init");
  const destroy = /* @__PURE__ */ __name(() => {
    pauseChangeDetection();
    viewport.stopViewportSync();
    graphManager.destroy();
    window.removeEventListener("resize", interaction.updateContainerRect);
    window.removeEventListener("scroll", interaction.updateContainerRect);
    window.removeEventListener("resize", viewport.updateCanvasDimensions);
    initialized.value = false;
  }, "destroy");
  watch(
    canvas,
    async (newCanvas, oldCanvas) => {
      if (oldCanvas) {
        graphManager.cleanupEventListeners();
        pauseChangeDetection();
        viewport.stopViewportSync();
        graphManager.destroy();
        window.removeEventListener("resize", interaction.updateContainerRect);
        window.removeEventListener("scroll", interaction.updateContainerRect);
        window.removeEventListener("resize", viewport.updateCanvasDimensions);
      }
      if (newCanvas && !initialized.value) {
        await init();
      }
    },
    { immediate: true, flush: "post" }
  );
  watch(graph, (newGraph, oldGraph) => {
    if (newGraph && newGraph !== oldGraph) {
      graphManager.cleanupEventListeners(oldGraph || void 0);
      graphManager.setupEventListeners();
      renderer.forceFullRedraw();
      renderer.updateMinimap(viewport.updateBounds, viewport.updateViewport);
    }
  });
  watch(visible, async (isVisible) => {
    if (isVisible) {
      if (containerRef.value) {
        interaction.updateContainerRect();
      }
      viewport.updateCanvasDimensions();
      renderer.forceFullRedraw();
      await nextTick();
      await nextTick();
      renderer.updateMinimap(viewport.updateBounds, viewport.updateViewport);
      viewport.updateViewport();
      resumeChangeDetection();
      viewport.startViewportSync();
    } else {
      pauseChangeDetection();
      viewport.stopViewportSync();
    }
  });
  const toggle = /* @__PURE__ */ __name(async () => {
    visible.value = !visible.value;
    await settingStore.set("Comfy.Minimap.Visible", visible.value);
  }, "toggle");
  const setMinimapRef = /* @__PURE__ */ __name((ref2) => {
    minimapRef.value = ref2;
  }, "setMinimapRef");
  const viewportStyles = computed(() => {
    const transform = viewport.viewportTransform.value;
    return {
      transform: `translate(${transform.x}px, ${transform.y}px)`,
      width: `${transform.width}px`,
      height: `${transform.height}px`,
      border: `2px solid ${settings.isLightTheme.value ? "#E0E0E0" : "#FFF"}`,
      backgroundColor: `rgba(255, 255, 255, 0.2)`,
      willChange: "transform",
      backfaceVisibility: "hidden",
      perspective: "1000px",
      pointerEvents: "none"
    };
  });
  return {
    visible: computed(() => visible.value),
    initialized: computed(() => initialized.value),
    containerStyles,
    viewportStyles,
    panelStyles,
    width,
    height,
    nodeColors,
    showLinks,
    showGroups,
    renderBypass,
    renderError,
    init,
    destroy,
    toggle,
    renderMinimap: renderer.renderMinimap,
    handlePointerDown: interaction.handlePointerDown,
    handlePointerMove: interaction.handlePointerMove,
    handlePointerUp: interaction.handlePointerUp,
    handlePointerCancel: interaction.handlePointerCancel,
    handleWheel: interaction.handleWheel,
    setMinimapRef,
    updateOption
  };
}
__name(useMinimap, "useMinimap");
const _hoisted_1$M = { class: "flex items-center gap-1 pr-0.5" };
const _hoisted_2$z = { class: "rounded-lg bg-interface-panel-selected-surface p-2 group-hover:bg-interface-button-hover-surface" };
const _hoisted_3$t = { class: "flex flex-col gap-1" };
const _hoisted_4$m = { class: "flex items-center gap-2" };
const _hoisted_5$i = { class: "text-[9px] text-text-primary" };
const _hoisted_6$g = { class: "flex items-center gap-2" };
const _hoisted_7$d = { class: "text-[9px] text-text-primary" };
const _sfc_main$1c = /* @__PURE__ */ defineComponent({
  __name: "CanvasModeSelector",
  props: {
    buttonStyles: {}
  },
  setup(__props) {
    const buttonRef = ref();
    const popover = ref();
    const commandStore = useCommandStore();
    const canvasStore = useCanvasStore();
    const isCanvasReadOnly = computed(() => canvasStore.canvas?.read_only ?? false);
    const currentModeIcon = computed(
      () => isCanvasReadOnly.value ? "icon-[lucide--hand]" : "icon-[lucide--mouse-pointer-2]"
    );
    const unlockCommandText = computed(
      () => commandStore.formatKeySequence(commandStore.getCommand("Comfy.Canvas.Unlock")).toUpperCase()
    );
    const lockCommandText = computed(
      () => commandStore.formatKeySequence(commandStore.getCommand("Comfy.Canvas.Lock")).toUpperCase()
    );
    const toggle = /* @__PURE__ */ __name((event) => {
      const el = buttonRef.value?.$el || buttonRef.value;
      popover.value?.toggle(event, el);
    }, "toggle");
    const setMode = /* @__PURE__ */ __name((mode) => {
      if (mode === "select" && isCanvasReadOnly.value) {
        void commandStore.execute("Comfy.Canvas.Unlock");
      } else if (mode === "hand" && !isCanvasReadOnly.value) {
        void commandStore.execute("Comfy.Canvas.Lock");
      }
      popover.value?.hide();
    }, "setMode");
    const popoverPt = computed(() => ({
      root: {
        class: "absolute z-50 -translate-y-2"
      },
      content: {
        class: [
          "mb-2 text-text-primary",
          "shadow-lg border border-interface-stroke",
          "bg-nav-background",
          "rounded-lg",
          "p-2 px-3",
          "min-w-39",
          "select-none"
        ]
      }
    }));
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createVNode(_sfc_main$1Y, {
          ref_key: "buttonRef",
          ref: buttonRef,
          variant: "secondary",
          class: "group h-8 rounded-none! bg-comfy-menu-bg p-0 transition-none! hover:rounded-lg! hover:bg-interface-button-hover-surface!",
          style: normalizeStyle(_ctx.buttonStyles),
          onClick: toggle
        }, {
          default: withCtx(() => [
            createBaseVNode("div", _hoisted_1$M, [
              createBaseVNode("div", _hoisted_2$z, [
                createBaseVNode("i", {
                  class: normalizeClass([currentModeIcon.value, "block h-4 w-4"])
                }, null, 2)
              ]),
              _cache[2] || (_cache[2] = createBaseVNode("i", { class: "icon-[lucide--chevron-down] block h-4 w-4 pr-1.5" }, null, -1))
            ])
          ]),
          _: 1
        }, 8, ["style"]),
        createVNode(unref(script$1), {
          ref_key: "popover",
          ref: popover,
          "auto-z-index": true,
          "base-z-index": 1e3,
          dismissable: true,
          "close-on-escape": true,
          unstyled: "",
          pt: popoverPt.value
        }, {
          default: withCtx(() => [
            createBaseVNode("div", _hoisted_3$t, [
              createBaseVNode("div", {
                class: "flex cursor-pointer items-center justify-between px-3 py-2 text-sm hover:bg-node-component-surface-hovered",
                onClick: _cache[0] || (_cache[0] = ($event) => setMode("select"))
              }, [
                createBaseVNode("div", _hoisted_4$m, [
                  _cache[3] || (_cache[3] = createBaseVNode("i", { class: "icon-[lucide--mouse-pointer-2] h-4 w-4" }, null, -1)),
                  createBaseVNode("span", null, toDisplayString(_ctx.$t("graphCanvasMenu.select")), 1)
                ]),
                createBaseVNode("span", _hoisted_5$i, toDisplayString(unlockCommandText.value), 1)
              ]),
              createBaseVNode("div", {
                class: "flex cursor-pointer items-center justify-between rounded px-3 py-2 text-sm hover:bg-node-component-surface-hovered",
                onClick: _cache[1] || (_cache[1] = ($event) => setMode("hand"))
              }, [
                createBaseVNode("div", _hoisted_6$g, [
                  _cache[4] || (_cache[4] = createBaseVNode("i", { class: "icon-[lucide--hand] h-4 w-4" }, null, -1)),
                  createBaseVNode("span", null, toDisplayString(_ctx.$t("graphCanvasMenu.hand")), 1)
                ]),
                createBaseVNode("span", _hoisted_7$d, toDisplayString(lockCommandText.value), 1)
              ])
            ])
          ]),
          _: 1
        }, 8, ["pt"])
      ], 64);
    };
  }
});
const _hoisted_1$L = {
  key: 0,
  class: "absolute right-0 bottom-[62px] z-1300 flex w-[250px] justify-center border-0! bg-inherit!"
};
const _hoisted_2$y = { class: "flex flex-col gap-1" };
const _hoisted_3$s = { class: "font-medium" };
const _hoisted_4$l = { class: "text-[9px] text-text-primary" };
const _hoisted_5$h = { class: "font-medium" };
const _hoisted_6$f = { class: "text-[9px] text-text-primary" };
const _hoisted_7$c = { class: "font-medium" };
const _hoisted_8$a = { class: "text-[9px] text-text-primary" };
const _sfc_main$1b = /* @__PURE__ */ defineComponent({
  __name: "ZoomControlsModal",
  props: {
    visible: { type: Boolean }
  },
  setup(__props) {
    const minimap = useMinimap();
    const commandStore = useCommandStore();
    const canvasStore = useCanvasStore();
    const { formatKeySequence } = useCommandStore();
    const props = __props;
    const interval = ref(null);
    const applyZoom = /* @__PURE__ */ __name((val) => {
      const inputValue = val.value;
      if (isNaN(inputValue) || inputValue < 1 || inputValue > 1e3) {
        return;
      }
      canvasStore.setAppZoomFromPercentage(inputValue);
    }, "applyZoom");
    const executeCommand = /* @__PURE__ */ __name((command) => {
      void commandStore.execute(command);
    }, "executeCommand");
    const startRepeat = /* @__PURE__ */ __name((command) => {
      if (interval.value) return;
      const cmd = /* @__PURE__ */ __name(() => commandStore.execute(command), "cmd");
      void cmd();
      interval.value = window.setInterval(cmd, 100);
    }, "startRepeat");
    const stopRepeat = /* @__PURE__ */ __name(() => {
      if (interval.value) {
        clearInterval(interval.value);
        interval.value = null;
      }
    }, "stopRepeat");
    const filteredMinimapStyles = computed(() => {
      return {
        ...minimap.containerStyles.value,
        height: void 0,
        width: void 0
      };
    });
    const zoomInCommandText = computed(
      () => formatKeySequence(commandStore.getCommand("Comfy.Canvas.ZoomIn"))
    );
    const zoomOutCommandText = computed(
      () => formatKeySequence(commandStore.getCommand("Comfy.Canvas.ZoomOut"))
    );
    const zoomToFitCommandText = computed(
      () => formatKeySequence(commandStore.getCommand("Comfy.Canvas.FitView"))
    );
    const zoomInputContainer = ref(null);
    watch(
      () => props.visible,
      async (newVal) => {
        if (newVal) {
          await nextTick();
          const input = zoomInputContainer.value?.querySelector(
            "input"
          );
          input?.focus();
        }
      }
    );
    return (_ctx, _cache) => {
      return _ctx.visible ? (openBlock(), createElementBlock("div", _hoisted_1$L, [
        createBaseVNode("div", {
          class: "w-4/5 rounded-lg border border-interface-stroke bg-interface-panel-surface p-2 text-text-primary shadow-lg select-none",
          style: normalizeStyle(filteredMinimapStyles.value),
          onClick: _cache[3] || (_cache[3] = withModifiers(() => {
          }, ["stop"]))
        }, [
          createBaseVNode("div", _hoisted_2$y, [
            createBaseVNode("div", {
              class: "flex cursor-pointer items-center justify-between rounded px-3 py-2 text-sm hover:bg-node-component-surface-hovered",
              onMousedown: _cache[0] || (_cache[0] = ($event) => startRepeat("Comfy.Canvas.ZoomIn")),
              onMouseup: stopRepeat,
              onMouseleave: stopRepeat
            }, [
              createBaseVNode("span", _hoisted_3$s, toDisplayString(_ctx.$t("graphCanvasMenu.zoomIn")), 1),
              createBaseVNode("span", _hoisted_4$l, toDisplayString(zoomInCommandText.value), 1)
            ], 32),
            createBaseVNode("div", {
              class: "flex cursor-pointer items-center justify-between rounded px-3 py-2 text-sm hover:bg-node-component-surface-hovered",
              onMousedown: _cache[1] || (_cache[1] = ($event) => startRepeat("Comfy.Canvas.ZoomOut")),
              onMouseup: stopRepeat,
              onMouseleave: stopRepeat
            }, [
              createBaseVNode("span", _hoisted_5$h, toDisplayString(_ctx.$t("graphCanvasMenu.zoomOut")), 1),
              createBaseVNode("span", _hoisted_6$f, toDisplayString(zoomOutCommandText.value), 1)
            ], 32),
            createBaseVNode("div", {
              class: "flex cursor-pointer items-center justify-between rounded px-3 py-2 text-sm hover:bg-node-component-surface-hovered",
              onClick: _cache[2] || (_cache[2] = ($event) => executeCommand("Comfy.Canvas.FitView"))
            }, [
              createBaseVNode("span", _hoisted_7$c, toDisplayString(_ctx.$t("zoomControls.zoomToFit")), 1),
              createBaseVNode("span", _hoisted_8$a, toDisplayString(zoomToFitCommandText.value), 1)
            ]),
            createBaseVNode("div", {
              ref_key: "zoomInputContainer",
              ref: zoomInputContainer,
              class: "zoomInputContainer flex items-center gap-1 rounded bg-input-surface p-2"
            }, [
              createVNode(unref(script$f), {
                "default-value": unref(canvasStore).appScalePercentage,
                min: 1,
                max: 1e3,
                "show-buttons": false,
                "use-grouping": false,
                unstyled: true,
                "input-class": "bg-transparent border-none outline-hidden text-sm shadow-none my-0 w-full",
                fluid: "",
                onInput: applyZoom,
                onKeyup: withKeys(applyZoom, ["enter"])
              }, null, 8, ["default-value"]),
              _cache[4] || (_cache[4] = createBaseVNode("span", { class: "flex-shrink-0 text-sm text-text-primary" }, "%", -1))
            ], 512)
          ])
        ], 4)
      ])) : createCommentVNode("", true);
    };
  }
});
const _hoisted_1$K = { class: "inline-flex items-center gap-1 px-2 text-xs" };
const _sfc_main$1a = /* @__PURE__ */ defineComponent({
  __name: "GraphCanvasMenu",
  setup(__props) {
    const { t: t2 } = useI18n();
    const commandStore = useCommandStore();
    const { formatKeySequence } = useCommandStore();
    const canvasStore = useCanvasStore();
    const settingStore = useSettingStore();
    const canvasInteractions = useCanvasInteractions();
    const minimap = useMinimap();
    const { isModalVisible, toggleModal, hideModal, hasActivePopup } = useZoomControls();
    const stringifiedMinimapStyles = computed(() => {
      const buttonGroupKeys = ["borderRadius"];
      const buttonKeys = ["borderRadius"];
      const additionalButtonStyles = {
        border: "none"
      };
      const containerStyles = minimap.containerStyles.value;
      const buttonStyles = {
        ...Object.fromEntries(
          Object.entries(containerStyles).filter(
            ([key]) => buttonKeys.includes(key)
          )
        ),
        ...additionalButtonStyles
      };
      const buttonGroupStyles = Object.entries(containerStyles).filter(([key]) => buttonGroupKeys.includes(key)).reduce((acc, [key, value]) => ({ ...acc, [key]: value }), {});
      return { buttonStyles, buttonGroupStyles };
    });
    const linkHidden = computed(
      () => settingStore.get("Comfy.LinkRenderMode") === LiteGraph.HIDDEN_LINK
    );
    const fitViewCommandText = computed(
      () => formatKeySequence(
        commandStore.getCommand("Comfy.Canvas.FitView")
      ).toUpperCase()
    );
    const minimapCommandText = computed(
      () => formatKeySequence(
        commandStore.getCommand("Comfy.Canvas.ToggleMinimap")
      ).toUpperCase()
    );
    const zoomButtonClass = computed(() => [
      "bg-comfy-menu-bg",
      isModalVisible.value ? "not-active:bg-interface-panel-selected-surface!" : "",
      "hover:bg-interface-button-hover-surface!",
      "p-0",
      "h-8",
      "w-15"
    ]);
    const minimapButtonClass = computed(() => ({
      "bg-comfy-menu-bg": true,
      "hover:bg-interface-button-hover-surface!": true,
      "not-active:bg-interface-panel-selected-surface!": settingStore.get(
        "Comfy.Minimap.Visible"
      ),
      "p-0": true,
      "w-8": true,
      "h-8": true
    }));
    const fitViewTooltip = computed(() => {
      const label = t2("graphCanvasMenu.fitView");
      const shortcut = fitViewCommandText.value;
      return shortcut ? `${label} (${shortcut})` : label;
    });
    const minimapTooltip = computed(() => {
      const label = settingStore.get("Comfy.Minimap.Visible") ? t2("zoomControls.hideMinimap") : t2("zoomControls.showMinimap");
      const shortcut = minimapCommandText.value;
      return shortcut ? `${label} (${shortcut})` : label;
    });
    const linkVisibilityTooltip = computed(
      () => linkHidden.value ? t2("graphCanvasMenu.showLinks") : t2("graphCanvasMenu.hideLinks")
    );
    const linkVisibilityAriaLabel = computed(
      () => linkHidden.value ? t2("graphCanvasMenu.showLinks") : t2("graphCanvasMenu.hideLinks")
    );
    const linkVisibleClass = computed(() => [
      "bg-comfy-menu-bg",
      linkHidden.value ? "not-active:bg-interface-panel-selected-surface!" : "",
      "hover:bg-interface-button-hover-surface!",
      "p-0",
      "w-8",
      "h-8"
    ]);
    onMounted(() => {
      canvasStore.initScaleSync();
    });
    const onMinimapToggleClick = /* @__PURE__ */ __name(() => {
      void commandStore.execute("Comfy.Canvas.ToggleMinimap");
    }, "onMinimapToggleClick");
    const onLinkVisibilityToggleClick = /* @__PURE__ */ __name(() => {
      void commandStore.execute("Comfy.Canvas.ToggleLinkVisibility");
    }, "onLinkVisibilityToggleClick");
    onBeforeUnmount(() => {
      canvasStore.cleanupScaleSync();
    });
    return (_ctx, _cache) => {
      const _directive_tooltip = resolveDirective("tooltip");
      return openBlock(), createElementBlock("div", null, [
        createVNode(_sfc_main$1b, {
          visible: unref(isModalVisible),
          onClose: unref(hideModal)
        }, null, 8, ["visible", "onClose"]),
        unref(hasActivePopup) ? (openBlock(), createElementBlock("div", {
          key: 0,
          class: "fixed inset-0 z-1200",
          onClick: _cache[0] || (_cache[0] = //@ts-ignore
          (...args) => unref(hideModal) && unref(hideModal)(...args))
        })) : createCommentVNode("", true),
        createVNode(unref(script$g), {
          class: "absolute right-0 bottom-0 z-1200 flex-row gap-1 border-[1px] border-interface-stroke bg-comfy-menu-bg p-2",
          style: normalizeStyle({
            ...stringifiedMinimapStyles.value.buttonGroupStyles
          }),
          onWheel: unref(canvasInteractions).handleWheel
        }, {
          default: withCtx(() => [
            createVNode(_sfc_main$1c, {
              "button-styles": stringifiedMinimapStyles.value.buttonStyles
            }, null, 8, ["button-styles"]),
            _cache[6] || (_cache[6] = createBaseVNode("div", { class: "h-[27px] w-[1px] self-center bg-node-divider" }, null, -1)),
            withDirectives((openBlock(), createBlock(_sfc_main$1Y, {
              variant: "secondary",
              "aria-label": fitViewTooltip.value,
              style: normalizeStyle(stringifiedMinimapStyles.value.buttonStyles),
              class: "h-8 w-8 bg-comfy-menu-bg p-0 hover:bg-interface-button-hover-surface!",
              onClick: _cache[1] || (_cache[1] = () => unref(commandStore).execute("Comfy.Canvas.FitView"))
            }, {
              default: withCtx(() => _cache[2] || (_cache[2] = [
                createBaseVNode("i", { class: "icon-[lucide--focus] h-4 w-4" }, null, -1)
              ])),
              _: 1
            }, 8, ["aria-label", "style"])), [
              [
                _directive_tooltip,
                fitViewTooltip.value,
                void 0,
                { top: true }
              ]
            ]),
            withDirectives((openBlock(), createBlock(_sfc_main$1Y, {
              variant: "secondary",
              class: normalizeClass(zoomButtonClass.value),
              "aria-label": unref(t2)("zoomControls.label"),
              "data-testid": "zoom-controls-button",
              style: normalizeStyle(stringifiedMinimapStyles.value.buttonStyles),
              onClick: unref(toggleModal)
            }, {
              default: withCtx(() => [
                createBaseVNode("span", _hoisted_1$K, [
                  createBaseVNode("span", null, toDisplayString(unref(canvasStore).appScalePercentage) + "%", 1),
                  _cache[3] || (_cache[3] = createBaseVNode("i", { class: "icon-[lucide--chevron-down] h-4 w-4" }, null, -1))
                ])
              ]),
              _: 1
            }, 8, ["class", "aria-label", "style", "onClick"])), [
              [
                _directive_tooltip,
                unref(t2)("zoomControls.label"),
                void 0,
                { top: true }
              ]
            ]),
            _cache[7] || (_cache[7] = createBaseVNode("div", { class: "h-[27px] w-[1px] self-center bg-node-divider" }, null, -1)),
            withDirectives((openBlock(), createBlock(_sfc_main$1Y, {
              variant: "secondary",
              "aria-label": minimapTooltip.value,
              "data-testid": "toggle-minimap-button",
              style: normalizeStyle(stringifiedMinimapStyles.value.buttonStyles),
              class: normalizeClass(minimapButtonClass.value),
              onClick: onMinimapToggleClick
            }, {
              default: withCtx(() => _cache[4] || (_cache[4] = [
                createBaseVNode("i", { class: "icon-[lucide--map] h-4 w-4" }, null, -1)
              ])),
              _: 1
            }, 8, ["aria-label", "style", "class"])), [
              [
                _directive_tooltip,
                minimapTooltip.value,
                void 0,
                { top: true }
              ]
            ]),
            withDirectives((openBlock(), createBlock(_sfc_main$1Y, {
              variant: "secondary",
              class: normalizeClass(linkVisibleClass.value),
              "aria-label": linkVisibilityAriaLabel.value,
              "data-testid": "toggle-link-visibility-button",
              style: normalizeStyle(stringifiedMinimapStyles.value.buttonStyles),
              onClick: onLinkVisibilityToggleClick
            }, {
              default: withCtx(() => _cache[5] || (_cache[5] = [
                createBaseVNode("i", { class: "icon-[lucide--route-off] h-4 w-4" }, null, -1)
              ])),
              _: 1
            }, 8, ["class", "aria-label", "style"])), [
              [
                _directive_tooltip,
                {
                  value: linkVisibilityTooltip.value,
                  pt: {
                    root: {
                      style: "z-index: 2; transform: translateY(-20px);"
                    }
                  }
                },
                void 0,
                { top: true }
              ]
            ])
          ]),
          _: 1
        }, 8, ["style", "onWheel"])
      ]);
    };
  }
});
const _sfc_main$19 = /* @__PURE__ */ defineComponent({
  __name: "NodeTooltip",
  setup(__props) {
    let idleTimeout;
    const nodeDefStore = useNodeDefStore();
    const settingStore = useSettingStore();
    const tooltipRef = ref();
    const tooltipText = ref("");
    const left = ref();
    const top = ref();
    function hideTooltip() {
      return tooltipText.value = "";
    }
    __name(hideTooltip, "hideTooltip");
    async function showTooltip(tooltip) {
      if (!tooltip) return;
      left.value = app.canvas.mouse[0] + "px";
      top.value = app.canvas.mouse[1] + "px";
      tooltipText.value = tooltip;
      await nextTick();
      const rect = tooltipRef.value?.getBoundingClientRect();
      if (!rect) return;
      if (rect.right > window.innerWidth) {
        left.value = app.canvas.mouse[0] - rect.width + "px";
      }
      if (rect.top < 0) {
        top.value = app.canvas.mouse[1] + rect.height + "px";
      }
    }
    __name(showTooltip, "showTooltip");
    function onIdle() {
      const { canvas } = app;
      const node = canvas?.node_over;
      if (!node) return;
      const ctor = node.constructor;
      const nodeDef = nodeDefStore.nodeDefsByName[node.type ?? ""];
      if (ctor.title_mode !== LiteGraph.NO_TITLE && canvas.graph_mouse[1] < node.pos[1]) {
        return showTooltip(nodeDef?.description);
      }
      if (node.flags?.collapsed) return;
      const inputSlot = isOverNodeInput(
        node,
        canvas.graph_mouse[0],
        canvas.graph_mouse[1],
        [0, 0]
      );
      if (inputSlot !== -1) {
        const inputName = node.inputs[inputSlot].name;
        const translatedTooltip = st(
          `nodeDefs.${normalizeI18nKey(node.type ?? "")}.inputs.${normalizeI18nKey(inputName)}.tooltip`,
          nodeDef?.inputs[inputName]?.tooltip ?? ""
        );
        return showTooltip(translatedTooltip);
      }
      const outputSlot = isOverNodeOutput(
        node,
        canvas.graph_mouse[0],
        canvas.graph_mouse[1],
        [0, 0]
      );
      if (outputSlot !== -1) {
        const translatedTooltip = st(
          `nodeDefs.${normalizeI18nKey(node.type ?? "")}.outputs.${outputSlot}.tooltip`,
          nodeDef?.outputs[outputSlot]?.tooltip ?? ""
        );
        return showTooltip(translatedTooltip);
      }
      const widget = app.canvas.getWidgetAtCursor();
      if (widget && !isDOMWidget(widget)) {
        const translatedTooltip = st(
          `nodeDefs.${normalizeI18nKey(node.type ?? "")}.inputs.${normalizeI18nKey(widget.name)}.tooltip`,
          nodeDef?.inputs[widget.name]?.tooltip ?? ""
        );
        return showTooltip(widget.tooltip ?? translatedTooltip);
      }
    }
    __name(onIdle, "onIdle");
    const onMouseMove = /* @__PURE__ */ __name((e) => {
      hideTooltip();
      clearTimeout(idleTimeout);
      if (e.target.nodeName !== "CANVAS") return;
      idleTimeout = window.setTimeout(
        onIdle,
        settingStore.get("LiteGraph.Node.TooltipDelay")
      );
    }, "onMouseMove");
    useEventListener(window, "mousemove", onMouseMove);
    useEventListener(window, "click", hideTooltip);
    return (_ctx, _cache) => {
      return tooltipText.value ? (openBlock(), createElementBlock("div", {
        key: 0,
        ref_key: "tooltipRef",
        ref: tooltipRef,
        class: "node-tooltip",
        style: normalizeStyle({ left: left.value, top: top.value })
      }, toDisplayString(tooltipText.value), 5)) : createCommentVNode("", true);
    };
  }
});
const NodeTooltip = /* @__PURE__ */ _export_sfc(_sfc_main$19, [["__scopeId", "data-v-96b1458a"]]);
const _sfc_main$18 = /* @__PURE__ */ defineComponent({
  __name: "BypassButton",
  setup(__props) {
    const commandStore = useCommandStore();
    const toggleBypass = /* @__PURE__ */ __name(async () => {
      await commandStore.execute("Comfy.Canvas.ToggleSelectedNodes.Bypass");
    }, "toggleBypass");
    return (_ctx, _cache) => {
      const _directive_tooltip = resolveDirective("tooltip");
      return withDirectives((openBlock(), createBlock(_sfc_main$1Y, {
        variant: "muted-textonly",
        "aria-label": _ctx.$t("commands.Comfy_Canvas_ToggleSelectedNodes_Bypass.label"),
        "data-testid": "bypass-button",
        class: "hover:bg-secondary-background",
        onClick: toggleBypass
      }, {
        default: withCtx(() => _cache[0] || (_cache[0] = [
          createBaseVNode("i", { class: "icon-[lucide--redo-dot] size-4" }, null, -1)
        ])),
        _: 1
      }, 8, ["aria-label"])), [
        [
          _directive_tooltip,
          {
            value: _ctx.$t("commands.Comfy_Canvas_ToggleSelectedNodes_Bypass.label"),
            showDelay: 1e3
          },
          void 0,
          { top: true }
        ]
      ]);
    };
  }
});
const _hoisted_1$J = { class: "relative" };
const _hoisted_2$x = { class: "flex items-center gap-1 px-0" };
const _hoisted_3$r = {
  key: 0,
  class: "color-picker-container absolute -top-10 left-1/2"
};
const _hoisted_4$k = ["data-testid"];
const _sfc_main$17 = /* @__PURE__ */ defineComponent({
  __name: "ColorPickerButton",
  setup(__props) {
    const { t: t2 } = useI18n();
    const canvasStore = useCanvasStore();
    const colorPaletteStore = useColorPaletteStore();
    const workflowStore = useWorkflowStore();
    const isLightTheme = computed(
      () => colorPaletteStore.completedActivePalette.light_theme
    );
    const toLightThemeColor = /* @__PURE__ */ __name((color) => adjustColor(color, { lightness: 0.5 }), "toLightThemeColor");
    const showColorPicker = ref(false);
    const NO_COLOR_OPTION = {
      name: "noColor",
      localizedName: t2("color.noColor"),
      value: {
        dark: LiteGraph.NODE_DEFAULT_BGCOLOR,
        light: toLightThemeColor(LiteGraph.NODE_DEFAULT_BGCOLOR)
      }
    };
    const colorOptions = [
      NO_COLOR_OPTION,
      ...Object.entries(LGraphCanvas.node_colors).map(([name, color]) => ({
        name,
        localizedName: t2(`color.${name}`),
        value: {
          dark: color.bgcolor,
          light: toLightThemeColor(color.bgcolor)
        }
      }))
    ];
    const selectedColorOption = ref(null);
    const applyColor = /* @__PURE__ */ __name((colorOption) => {
      const colorName = colorOption?.name ?? NO_COLOR_OPTION.name;
      const canvasColorOption = colorName === NO_COLOR_OPTION.name ? null : LGraphCanvas.node_colors[colorName];
      for (const item of canvasStore.selectedItems) {
        if (isColorable(item)) {
          item.setColorOption(canvasColorOption);
        }
      }
      canvasStore.canvas?.setDirty(true, true);
      currentColorOption.value = canvasColorOption;
      showColorPicker.value = false;
      workflowStore.activeWorkflow?.changeTracker.checkState();
    }, "applyColor");
    const currentColorOption = ref(null);
    const currentColor = computed(
      () => currentColorOption.value ? isLightTheme.value ? toLightThemeColor(currentColorOption.value?.bgcolor) : currentColorOption.value?.bgcolor : null
    );
    const localizedCurrentColorName = computed(() => {
      if (!currentColorOption.value?.bgcolor) return null;
      const colorOption = colorOptions.find(
        (option) => option.value.dark === currentColorOption.value?.bgcolor || option.value.light === currentColorOption.value?.bgcolor
      );
      return colorOption?.localizedName ?? NO_COLOR_OPTION.localizedName;
    });
    const updateColorSelectionFromNode = /* @__PURE__ */ __name((newSelectedItems) => {
      showColorPicker.value = false;
      selectedColorOption.value = null;
      currentColorOption.value = getItemsColorOption(newSelectedItems);
    }, "updateColorSelectionFromNode");
    watch(
      () => canvasStore.selectedItems,
      (newSelectedItems) => {
        updateColorSelectionFromNode(newSelectedItems);
      },
      { immediate: true }
    );
    return (_ctx, _cache) => {
      const _directive_tooltip = resolveDirective("tooltip");
      return openBlock(), createElementBlock("div", _hoisted_1$J, [
        withDirectives((openBlock(), createBlock(_sfc_main$1Y, {
          "data-testid": "color-picker-button",
          variant: "muted-textonly",
          "aria-label": unref(t2)("g.color"),
          onClick: _cache[0] || (_cache[0] = () => showColorPicker.value = !showColorPicker.value)
        }, {
          default: withCtx(() => [
            createBaseVNode("div", _hoisted_2$x, [
              createBaseVNode("i", {
                class: "pi pi-circle-fill",
                style: normalizeStyle({ color: currentColor.value ?? "" })
              }, null, 4),
              _cache[1] || (_cache[1] = createBaseVNode("i", { class: "icon-[lucide--chevron-down]" }, null, -1))
            ])
          ]),
          _: 1
        }, 8, ["aria-label"])), [
          [
            _directive_tooltip,
            {
              value: localizedCurrentColorName.value ?? unref(t2)("color.noColor"),
              showDelay: 1e3
            },
            void 0,
            { top: true }
          ]
        ]),
        showColorPicker.value ? (openBlock(), createElementBlock("div", _hoisted_3$r, [
          createVNode(unref(script$h), {
            "model-value": selectedColorOption.value,
            options: colorOptions,
            "option-label": "name",
            "data-key": "value",
            "onUpdate:modelValue": applyColor
          }, {
            option: withCtx(({ option }) => [
              withDirectives(createBaseVNode("i", {
                class: "pi pi-circle-fill",
                style: normalizeStyle({
                  color: isLightTheme.value ? option.value.light : option.value.dark
                }),
                "data-testid": option.name
              }, null, 12, _hoisted_4$k), [
                [
                  _directive_tooltip,
                  option.localizedName,
                  void 0,
                  { top: true }
                ]
              ])
            ]),
            _: 1
          }, 8, ["model-value"])
        ])) : createCommentVNode("", true)
      ]);
    };
  }
});
const ColorPickerButton = /* @__PURE__ */ _export_sfc(_sfc_main$17, [["__scopeId", "data-v-2197e0a1"]]);
const _sfc_main$16 = /* @__PURE__ */ defineComponent({
  __name: "ConfigureSubgraph",
  setup(__props) {
    const rightSidePanelStore = useRightSidePanelStore();
    const handleClick = /* @__PURE__ */ __name(() => {
      rightSidePanelStore.openPanel("subgraph");
    }, "handleClick");
    return (_ctx, _cache) => {
      const _directive_tooltip = resolveDirective("tooltip");
      return withDirectives((openBlock(), createBlock(_sfc_main$1Y, {
        variant: "muted-textonly",
        "aria-label": _ctx.$t("commands.Comfy_Graph_EditSubgraphWidgets.label"),
        onClick: handleClick
      }, {
        default: withCtx(() => _cache[0] || (_cache[0] = [
          createBaseVNode("i", { class: "icon-[lucide--settings-2]" }, null, -1)
        ])),
        _: 1
      }, 8, ["aria-label"])), [
        [
          _directive_tooltip,
          {
            value: _ctx.$t("commands.Comfy_Graph_EditSubgraphWidgets.label"),
            showDelay: 1e3
          },
          void 0,
          { top: true }
        ]
      ]);
    };
  }
});
const _sfc_main$15 = /* @__PURE__ */ defineComponent({
  __name: "ConvertToSubgraphButton",
  setup(__props) {
    const commandStore = useCommandStore();
    const { isSingleSubgraph, hasAnySelection } = useSelectionState();
    const isUnpackVisible = isSingleSubgraph;
    const isConvertVisible = computed(
      () => hasAnySelection.value && !isSingleSubgraph.value
    );
    return (_ctx, _cache) => {
      const _directive_tooltip = resolveDirective("tooltip");
      return unref(isUnpackVisible) ? withDirectives((openBlock(), createBlock(_sfc_main$1Y, {
        key: 0,
        variant: "muted-textonly",
        "aria-label": _ctx.$t("commands.Comfy_Graph_UnpackSubgraph.label"),
        "data-testid": "convert-to-subgraph-button",
        onClick: _cache[0] || (_cache[0] = () => unref(commandStore).execute("Comfy.Graph.UnpackSubgraph"))
      }, {
        default: withCtx(() => _cache[2] || (_cache[2] = [
          createBaseVNode("i", { class: "icon-[lucide--expand] size-4" }, null, -1)
        ])),
        _: 1
      }, 8, ["aria-label"])), [
        [
          _directive_tooltip,
          {
            value: _ctx.$t("commands.Comfy_Graph_UnpackSubgraph.label"),
            showDelay: 1e3
          },
          void 0,
          { top: true }
        ]
      ]) : isConvertVisible.value ? withDirectives((openBlock(), createBlock(_sfc_main$1Y, {
        key: 1,
        variant: "muted-textonly",
        size: "icon",
        "aria-label": _ctx.$t("commands.Comfy_Graph_ConvertToSubgraph.label"),
        "data-testid": "convert-to-subgraph-button",
        onClick: _cache[1] || (_cache[1] = () => unref(commandStore).execute("Comfy.Graph.ConvertToSubgraph"))
      }, {
        default: withCtx(() => _cache[3] || (_cache[3] = [
          createBaseVNode("i", { class: "icon-[lucide--shrink] size-4" }, null, -1)
        ])),
        _: 1
      }, 8, ["aria-label"])), [
        [
          _directive_tooltip,
          {
            value: _ctx.$t("commands.Comfy_Graph_ConvertToSubgraph.label"),
            showDelay: 1e3
          },
          void 0,
          { top: true }
        ]
      ]) : createCommentVNode("", true);
    };
  }
});
const _sfc_main$14 = /* @__PURE__ */ defineComponent({
  __name: "DeleteButton",
  setup(__props) {
    const commandStore = useCommandStore();
    const { selectedItems } = useSelectionState();
    const isDeletable = computed(
      () => selectedItems.value.some((x) => x.removable !== false)
    );
    return (_ctx, _cache) => {
      const _directive_tooltip = resolveDirective("tooltip");
      return withDirectives((openBlock(), createBlock(_sfc_main$1Y, {
        variant: "muted-textonly",
        "aria-label": _ctx.$t("commands.Comfy_Canvas_DeleteSelectedItems.label"),
        "data-testid": "delete-button",
        onClick: _cache[0] || (_cache[0] = () => unref(commandStore).execute("Comfy.Canvas.DeleteSelectedItems"))
      }, {
        default: withCtx(() => _cache[1] || (_cache[1] = [
          createBaseVNode("i", { class: "icon-[lucide--trash-2]" }, null, -1)
        ])),
        _: 1
      }, 8, ["aria-label"])), [
        [vShow, isDeletable.value],
        [
          _directive_tooltip,
          {
            value: _ctx.$t("commands.Comfy_Canvas_DeleteSelectedItems.label"),
            showDelay: 1e3
          },
          void 0,
          { top: true }
        ]
      ]);
    };
  }
});
const _sfc_main$13 = /* @__PURE__ */ defineComponent({
  __name: "ExecuteButton",
  setup(__props) {
    const { t: t2 } = useI18n();
    const commandStore = useCommandStore();
    const canvasStore = useCanvasStore();
    const { selectedNodes } = useSelectionState();
    const canvas = canvasStore.getCanvas();
    const buttonHovered = ref(false);
    const selectedOutputNodes = computed(
      () => selectedNodes.value.filter(isLGraphNode).filter(isOutputNode)
    );
    function outputNodeStokeStyle() {
      if (this.selected && this.constructor.nodeData?.output_node && buttonHovered.value) {
        return { color: "orange", lineWidth: 2, padding: 10 };
      }
    }
    __name(outputNodeStokeStyle, "outputNodeStokeStyle");
    const handleMouseEnter = /* @__PURE__ */ __name(() => {
      buttonHovered.value = true;
      for (const node of selectedOutputNodes.value) {
        node.strokeStyles["outputNode"] = outputNodeStokeStyle;
      }
      canvas.setDirty(true);
    }, "handleMouseEnter");
    const handleMouseLeave = /* @__PURE__ */ __name(() => {
      buttonHovered.value = false;
      canvas.setDirty(true);
    }, "handleMouseLeave");
    const handleClick = /* @__PURE__ */ __name(async () => {
      await commandStore.execute("Comfy.QueueSelectedOutputNodes");
    }, "handleClick");
    return (_ctx, _cache) => {
      const _directive_tooltip = resolveDirective("tooltip");
      return withDirectives((openBlock(), createBlock(_sfc_main$1Y, {
        variant: "primary",
        "aria-label": unref(t2)("selectionToolbox.executeButton.tooltip"),
        onMouseenter: _cache[0] || (_cache[0] = () => handleMouseEnter()),
        onMouseleave: _cache[1] || (_cache[1] = () => handleMouseLeave()),
        onClick: handleClick
      }, {
        default: withCtx(() => _cache[2] || (_cache[2] = [
          createBaseVNode("i", { class: "icon-[lucide--play]" }, null, -1)
        ])),
        _: 1
      }, 8, ["aria-label"])), [
        [
          _directive_tooltip,
          {
            value: unref(t2)("selectionToolbox.executeButton.tooltip"),
            showDelay: 1e3
          },
          void 0,
          { top: true }
        ]
      ]);
    };
  }
});
const _sfc_main$12 = /* @__PURE__ */ defineComponent({
  __name: "ExtensionCommandButton",
  props: {
    command: {}
  },
  setup(__props) {
    const commandStore = useCommandStore();
    return (_ctx, _cache) => {
      const _directive_tooltip = resolveDirective("tooltip");
      return withDirectives((openBlock(), createBlock(_sfc_main$1Y, {
        variant: "muted-textonly",
        "aria-label": unref(st)(`commands.${unref(normalizeI18nKey)(_ctx.command.id)}.label`, ""),
        onClick: _cache[0] || (_cache[0] = () => unref(commandStore).execute(_ctx.command.id))
      }, {
        default: withCtx(() => [
          createBaseVNode("i", {
            class: normalizeClass([
              typeof _ctx.command.icon === "function" ? _ctx.command.icon() : _ctx.command.icon
            ])
          }, null, 2)
        ]),
        _: 1
      }, 8, ["aria-label"])), [
        [
          _directive_tooltip,
          {
            value: unref(st)(`commands.${unref(normalizeI18nKey)(_ctx.command.id)}.label`, "") || void 0,
            showDelay: 1e3
          },
          void 0,
          { top: true }
        ]
      ]);
    };
  }
});
const _sfc_main$11 = /* @__PURE__ */ defineComponent({
  __name: "InfoButton",
  setup(__props) {
    const rightSidePanelStore = useRightSidePanelStore();
    const onInfoClick = /* @__PURE__ */ __name(() => {
      rightSidePanelStore.openPanel("info");
    }, "onInfoClick");
    return (_ctx, _cache) => {
      const _directive_tooltip = resolveDirective("tooltip");
      return withDirectives((openBlock(), createBlock(_sfc_main$1Y, {
        "data-testid": "info-button",
        variant: "muted-textonly",
        "aria-label": _ctx.$t("g.info"),
        onClick: onInfoClick
      }, {
        default: withCtx(() => _cache[0] || (_cache[0] = [
          createBaseVNode("i", { class: "icon-[lucide--info]" }, null, -1)
        ])),
        _: 1
      }, 8, ["aria-label"])), [
        [
          _directive_tooltip,
          {
            value: _ctx.$t("g.info"),
            showDelay: 1e3
          },
          void 0,
          { top: true }
        ]
      ]);
    };
  }
});
const _sfc_main$10 = /* @__PURE__ */ defineComponent({
  __name: "Load3DViewerButton",
  setup(__props) {
    const commandStore = useCommandStore();
    const open3DViewer = /* @__PURE__ */ __name(() => {
      void commandStore.execute("Comfy.3DViewer.Open3DViewer");
    }, "open3DViewer");
    return (_ctx, _cache) => {
      const _directive_tooltip = resolveDirective("tooltip");
      return withDirectives((openBlock(), createBlock(_sfc_main$1Y, {
        variant: "muted-textonly",
        "aria-label": _ctx.$t("commands.Comfy_3DViewer_Open3DViewer.label"),
        onClick: open3DViewer
      }, {
        default: withCtx(() => _cache[0] || (_cache[0] = [
          createBaseVNode("i", { class: "icon-[lucide--pencil]" }, null, -1)
        ])),
        _: 1
      }, 8, ["aria-label"])), [
        [
          _directive_tooltip,
          {
            value: _ctx.$t("commands.Comfy_3DViewer_Open3DViewer.label"),
            showDelay: 1e3
          },
          void 0,
          { top: true }
        ]
      ]);
    };
  }
});
const _sfc_main$$ = /* @__PURE__ */ defineComponent({
  __name: "MaskEditorButton",
  setup(__props) {
    const commandStore = useCommandStore();
    const { isSingleImageNode } = useSelectionState();
    const openMaskEditor = /* @__PURE__ */ __name(() => {
      void commandStore.execute("Comfy.MaskEditor.OpenMaskEditor");
    }, "openMaskEditor");
    return (_ctx, _cache) => {
      const _directive_tooltip = resolveDirective("tooltip");
      return withDirectives((openBlock(), createBlock(_sfc_main$1Y, {
        variant: "muted-textonly",
        "aria-label": _ctx.$t("commands.Comfy_MaskEditor_OpenMaskEditor.label"),
        onClick: openMaskEditor
      }, {
        default: withCtx(() => _cache[0] || (_cache[0] = [
          createBaseVNode("i", { class: "icon-[comfy--mask]" }, null, -1)
        ])),
        _: 1
      }, 8, ["aria-label"])), [
        [vShow, unref(isSingleImageNode)],
        [
          _directive_tooltip,
          {
            value: _ctx.$t("commands.Comfy_MaskEditor_OpenMaskEditor.label"),
            showDelay: 1e3
          },
          void 0,
          { top: true }
        ]
      ]);
    };
  }
});
const isRefreshableWidget = /* @__PURE__ */ __name((widget) => widget != null && typeof widget === "object" && "refresh" in widget && typeof widget.refresh === "function", "isRefreshableWidget");
const useRefreshableSelection = /* @__PURE__ */ __name(() => {
  const graphStore = useCanvasStore();
  const selectedNodes = ref([]);
  watchEffect(() => {
    selectedNodes.value = graphStore.selectedItems.filter(isLGraphNode);
  });
  const refreshableWidgets = computed(
    () => selectedNodes.value.flatMap((node) => {
      if (!node.widgets) return [];
      const items = [];
      for (const widget of node.widgets) {
        if (isRefreshableWidget(widget)) {
          items.push(widget);
        }
      }
      return items;
    })
  );
  const isRefreshable = computed(() => refreshableWidgets.value.length > 0);
  async function refreshSelected() {
    if (!isRefreshable.value) return;
    await Promise.all(refreshableWidgets.value.map((item) => item.refresh()));
  }
  __name(refreshSelected, "refreshSelected");
  return {
    isRefreshable,
    refreshSelected
  };
}, "useRefreshableSelection");
const _sfc_main$_ = /* @__PURE__ */ defineComponent({
  __name: "RefreshSelectionButton",
  setup(__props) {
    const { t: t2 } = useI18n();
    const { isRefreshable, refreshSelected } = useRefreshableSelection();
    return (_ctx, _cache) => {
      const _directive_tooltip = resolveDirective("tooltip");
      return withDirectives((openBlock(), createBlock(_sfc_main$1Y, {
        variant: "muted-textonly",
        "aria-label": unref(t2)("g.refreshNode"),
        "data-testid": "refresh-button",
        onClick: unref(refreshSelected)
      }, {
        default: withCtx(() => _cache[0] || (_cache[0] = [
          createBaseVNode("i", { class: "icon-[lucide--refresh-cw]" }, null, -1)
        ])),
        _: 1
      }, 8, ["aria-label", "onClick"])), [
        [vShow, unref(isRefreshable)],
        [
          _directive_tooltip,
          unref(t2)("g.refreshNode"),
          void 0,
          { top: true }
        ]
      ]);
    };
  }
});
const _sfc_main$Z = /* @__PURE__ */ defineComponent({
  __name: "SaveToSubgraphLibrary",
  setup(__props) {
    const commandStore = useCommandStore();
    const canvasStore = useCanvasStore();
    const isVisible = computed(() => {
      return canvasStore.selectedItems?.length === 1 && canvasStore.selectedItems[0] instanceof SubgraphNode;
    });
    return (_ctx, _cache) => {
      const _directive_tooltip = resolveDirective("tooltip");
      return withDirectives((openBlock(), createBlock(_sfc_main$1Y, {
        variant: "muted-textonly",
        "aria-label": _ctx.$t("commands.Comfy_PublishSubgraph.label"),
        onClick: _cache[0] || (_cache[0] = () => unref(commandStore).execute("Comfy.PublishSubgraph"))
      }, {
        default: withCtx(() => _cache[1] || (_cache[1] = [
          createBaseVNode("i", { class: "icon-[lucide--book-open]" }, null, -1)
        ])),
        _: 1
      }, 8, ["aria-label"])), [
        [vShow, isVisible.value],
        [
          _directive_tooltip,
          {
            value: _ctx.$t("commands.Comfy_PublishSubgraph.label"),
            showDelay: 1e3
          },
          void 0,
          { top: true }
        ]
      ]);
    };
  }
});
const moreOptionsOpen = ref(false);
const forceCloseMoreOptionsSignal = ref(0);
const restoreMoreOptionsSignal = ref(0);
const moreOptionsRestorePending = ref(false);
let moreOptionsWasOpenBeforeDrag = false;
let moreOptionsSelectionSignature = null;
function buildSelectionSignature(store) {
  const c = store.canvas;
  if (!c) return null;
  const items = Array.from(c.selectedItems);
  if (items.length !== 1) return null;
  const item = items[0];
  if (isLGraphNode(item)) return `N:${item.id}`;
  if (isLGraphGroup(item)) return `G:${item.id}`;
  return null;
}
__name(buildSelectionSignature, "buildSelectionSignature");
function currentSelectionMatchesSignature(store) {
  if (!moreOptionsSelectionSignature) return false;
  return buildSelectionSignature(store) === moreOptionsSelectionSignature;
}
__name(currentSelectionMatchesSignature, "currentSelectionMatchesSignature");
function useSelectionToolboxPosition(toolboxRef) {
  const canvasStore = useCanvasStore();
  const lgCanvas = canvasStore.getCanvas();
  const { getSelectableItems } = useSelectedLiteGraphItems();
  const { shouldRenderVueNodes } = useVueFeatureFlags();
  const worldPosition = ref({ x: 0, y: 0 });
  const visible = ref(false);
  const { left: canvasLeft, top: canvasTop } = useElementBounding(
    lgCanvas.canvas
  );
  const isDragging = computed(() => {
    const litegraphDragging = canvasStore.canvas?.state?.draggingItems ?? false;
    const vueNodeDragging = shouldRenderVueNodes.value && layoutStore.isDraggingVueNodes.value;
    return litegraphDragging || vueNodeDragging;
  });
  const updateSelectionBounds = /* @__PURE__ */ __name(() => {
    const selectableItems = getSelectableItems();
    if (!selectableItems.size) {
      visible.value = false;
      return;
    }
    if (isDragging.value) {
      visible.value = false;
      return;
    }
    visible.value = true;
    const allBounds = [];
    for (const item of selectableItems) {
      if (item.id == null) continue;
      if (shouldRenderVueNodes.value && typeof item.id === "string") {
        const layout = layoutStore.getNodeLayoutRef(item.id).value;
        if (layout) {
          allBounds.push([
            layout.bounds.x,
            layout.bounds.y,
            layout.bounds.width,
            layout.bounds.height
          ]);
        }
      } else {
        if (item instanceof LGraphNode || item instanceof LGraphGroup) {
          allBounds.push([
            item.pos[0],
            item.pos[1] - LiteGraph.NODE_TITLE_HEIGHT,
            item.size[0],
            item.size[1] + LiteGraph.NODE_TITLE_HEIGHT
          ]);
        }
      }
    }
    const unionBounds = computeUnionBounds(allBounds);
    if (!unionBounds) return;
    worldPosition.value = {
      x: unionBounds.x + unionBounds.width / 2,
      // createBounds() applied a default padding of 10px
      // so adjust Y to maintain visual consistency
      y: unionBounds.y - 10
    };
    updateTransform();
  }, "updateSelectionBounds");
  const updateTransform = /* @__PURE__ */ __name(() => {
    if (!visible.value) return;
    const { scale, offset } = lgCanvas.ds;
    const screenX = (worldPosition.value.x + offset[0]) * scale + canvasLeft.value;
    const screenY = (worldPosition.value.y + offset[1]) * scale + canvasTop.value;
    if (toolboxRef.value) {
      toolboxRef.value.style.setProperty("--tb-x", `${screenX}px`);
      toolboxRef.value.style.setProperty("--tb-y", `${screenY}px`);
    }
  }, "updateTransform");
  const { resume: startSync, pause: stopSync } = useRafFn(updateTransform);
  watchEffect(() => {
    if (visible.value) {
      startSync();
    } else {
      stopSync();
    }
  });
  watch(
    () => canvasStore.getCanvas().state.selectionChanged,
    (changed) => {
      if (changed) {
        if (moreOptionsRestorePending.value || moreOptionsSelectionSignature) {
          moreOptionsRestorePending.value = false;
          moreOptionsWasOpenBeforeDrag = false;
          if (!moreOptionsOpen.value) {
            moreOptionsSelectionSignature = null;
          } else {
            moreOptionsSelectionSignature = buildSelectionSignature(canvasStore);
          }
        }
        updateSelectionBounds();
        canvasStore.getCanvas().state.selectionChanged = false;
      }
    },
    { immediate: true }
  );
  watch(
    () => moreOptionsOpen.value,
    (v) => {
      if (v) {
        moreOptionsSelectionSignature = buildSelectionSignature(canvasStore);
      } else if (!canvasStore.canvas?.state?.draggingItems) {
        moreOptionsSelectionSignature = null;
        if (moreOptionsRestorePending.value)
          moreOptionsRestorePending.value = false;
      }
    }
  );
  const handleDragStateChange = /* @__PURE__ */ __name((dragging) => {
    if (dragging) {
      handleDragStart();
      return;
    }
    handleDragEnd();
  }, "handleDragStateChange");
  const handleDragStart = /* @__PURE__ */ __name(() => {
    visible.value = false;
    if (!moreOptionsOpen.value) {
      moreOptionsRestorePending.value = false;
      moreOptionsWasOpenBeforeDrag = false;
      return;
    }
    const currentSig = buildSelectionSignature(canvasStore);
    const selectionChanged = currentSig !== moreOptionsSelectionSignature;
    if (selectionChanged) {
      moreOptionsSelectionSignature = null;
    }
    moreOptionsOpen.value = false;
    moreOptionsWasOpenBeforeDrag = true;
    moreOptionsRestorePending.value = !!moreOptionsSelectionSignature;
    if (moreOptionsRestorePending.value) {
      forceCloseMoreOptionsSignal.value++;
      return;
    }
    moreOptionsWasOpenBeforeDrag = false;
  }, "handleDragStart");
  const handleDragEnd = /* @__PURE__ */ __name(() => {
    requestAnimationFrame(() => {
      updateSelectionBounds();
      const selectionMatches = currentSelectionMatchesSignature(canvasStore);
      const shouldRestore = moreOptionsWasOpenBeforeDrag && visible.value && moreOptionsRestorePending.value && selectionMatches;
      moreOptionsRestorePending.value = shouldRestore && moreOptionsRestorePending.value;
      moreOptionsWasOpenBeforeDrag = false;
      if (shouldRestore) {
        restoreMoreOptionsSignal.value++;
      }
    });
  }, "handleDragEnd");
  watch(isDragging, handleDragStateChange);
  onUnmounted(() => {
    resetMoreOptionsState();
  });
  return {
    visible
  };
}
__name(useSelectionToolboxPosition, "useSelectionToolboxPosition");
function resetMoreOptionsState() {
  moreOptionsOpen.value = false;
  moreOptionsRestorePending.value = false;
  moreOptionsWasOpenBeforeDrag = false;
  moreOptionsSelectionSignature = null;
}
__name(resetMoreOptionsState, "resetMoreOptionsState");
const HARD_BLACKLIST = /* @__PURE__ */ new Set([
  "Properties",
  // Never include Properties submenu
  "Colors",
  // Use singular "Color" instead
  "Shapes",
  // Use singular "Shape" instead
  "Title",
  "Mode",
  "Properties Panel",
  "Copy (Clipspace)"
]);
const CORE_MENU_ITEMS = /* @__PURE__ */ new Set([
  // Basic operations
  "Rename",
  "Copy",
  "Duplicate",
  "Clone",
  // Node state operations
  "Run Branch",
  "Pin",
  "Unpin",
  "Bypass",
  "Remove Bypass",
  "Mute",
  // Structure operations
  "Convert to Subgraph",
  "Frame selection",
  "Minimize Node",
  "Expand",
  "Collapse",
  // Info and adjustments
  "Node Info",
  "Resize",
  "Title",
  "Properties Panel",
  "Adjust Size",
  // Visual
  "Color",
  "Colors",
  "Shape",
  "Shapes",
  "Mode",
  // Built-in node operations (node-specific)
  "Open Image",
  "Copy Image",
  "Save Image",
  "Open in Mask Editor",
  "Edit Subgraph Widgets",
  "Unpack Subgraph",
  "Copy (Clipspace)",
  "Paste (Clipspace)",
  // Selection and alignment
  "Align Selected To",
  "Distribute Nodes",
  // Deletion
  "Delete",
  "Remove",
  // LiteGraph base items
  "Show Advanced",
  "Hide Advanced"
]);
function normalizeLabel(label) {
  return label.toLowerCase().replace(/^un/, "").trim();
}
__name(normalizeLabel, "normalizeLabel");
function isDuplicateItem(label, existingItems) {
  const normalizedLabel = normalizeLabel(label);
  const equivalents = {
    color: ["color", "colors"],
    shape: ["shape", "shapes"],
    pin: ["pin", "unpin"],
    delete: ["remove", "delete"],
    duplicate: ["clone", "duplicate"]
  };
  return existingItems.some((item) => {
    if (!item.label) return false;
    const existingNormalized = normalizeLabel(item.label);
    if (existingNormalized === normalizedLabel) return true;
    for (const values of Object.values(equivalents)) {
      if (values.includes(normalizedLabel) && values.includes(existingNormalized)) {
        return true;
      }
    }
    return false;
  });
}
__name(isDuplicateItem, "isDuplicateItem");
function isCoreMenuItem(label) {
  return CORE_MENU_ITEMS.has(label);
}
__name(isCoreMenuItem, "isCoreMenuItem");
function removeDuplicateMenuOptions(options) {
  const itemsByLabel = /* @__PURE__ */ new Map();
  const itemsWithoutLabel = [];
  for (const opt of options) {
    if (opt.type === "divider" || opt.type === "category") {
      itemsWithoutLabel.push(opt);
      continue;
    }
    if (!opt.label) {
      itemsWithoutLabel.push(opt);
      continue;
    }
    if (!itemsByLabel.has(opt.label)) {
      itemsByLabel.set(opt.label, []);
    }
    itemsByLabel.get(opt.label).push(opt);
  }
  const result = [];
  const seenLabels = /* @__PURE__ */ new Set();
  for (const opt of options) {
    if (opt.type === "divider" || opt.type === "category" || !opt.label) {
      if (itemsWithoutLabel.includes(opt)) {
        result.push(opt);
        const idx = itemsWithoutLabel.indexOf(opt);
        itemsWithoutLabel.splice(idx, 1);
      }
      continue;
    }
    if (seenLabels.has(opt.label)) {
      continue;
    }
    seenLabels.add(opt.label);
    const duplicates = itemsByLabel.get(opt.label);
    if (duplicates.length === 1) {
      result.push(duplicates[0]);
      continue;
    }
    const vueItem = duplicates.find((item) => item.source === "vue");
    if (vueItem) {
      result.push(vueItem);
    } else {
      result.push(duplicates[0]);
    }
  }
  return result;
}
__name(removeDuplicateMenuOptions, "removeDuplicateMenuOptions");
const MENU_ORDER = [
  // Section 1: Basic operations
  "Rename",
  "Copy",
  "Duplicate",
  // Section 2: Node actions
  "Run Branch",
  "Pin",
  "Unpin",
  "Bypass",
  "Remove Bypass",
  "Mute",
  // Section 3: Structure operations
  "Convert to Subgraph",
  "Frame selection",
  "Minimize Node",
  "Expand",
  "Collapse",
  "Resize",
  "Clone",
  // Section 4: Node properties
  "Node Info",
  "Color",
  // Section 5: Node-specific operations
  "Open in Mask Editor",
  "Open Image",
  "Copy Image",
  "Save Image",
  "Copy (Clipspace)",
  "Paste (Clipspace)",
  // Fallback for other core items
  "Convert to Group Node (Deprecated)"
];
function getMenuItemOrder(label) {
  const index = MENU_ORDER.indexOf(label);
  return index === -1 ? 999 : index;
}
__name(getMenuItemOrder, "getMenuItemOrder");
function buildStructuredMenu(options) {
  const deduplicated = removeDuplicateMenuOptions(options);
  const coreItemsMap = /* @__PURE__ */ new Map();
  const extensionItems = [];
  let deleteItem;
  for (const option of deduplicated) {
    if (option.type === "divider") {
      continue;
    }
    if (option.type === "category") {
      continue;
    }
    const isDeleteItem = option.label === "Delete" || option.label === "Remove";
    if (isDeleteItem && !option.hasSubmenu) {
      deleteItem = option;
      continue;
    }
    if (option.label && isCoreMenuItem(option.label)) {
      coreItemsMap.set(option.label, option);
    } else {
      extensionItems.push(option);
    }
  }
  const orderedCoreItems = [];
  const coreLabels = Array.from(coreItemsMap.keys());
  coreLabels.sort((a, b) => getMenuItemOrder(a) - getMenuItemOrder(b));
  const getSectionNumber = /* @__PURE__ */ __name((index) => {
    if (index <= 2) return 1;
    if (index <= 8) return 2;
    if (index <= 15) return 3;
    if (index <= 17) return 4;
    return 5;
  }, "getSectionNumber");
  let lastSection = 0;
  for (const label of coreLabels) {
    const item = coreItemsMap.get(label);
    const itemIndex = getMenuItemOrder(label);
    const currentSection = getSectionNumber(itemIndex);
    if (lastSection > 0 && currentSection !== lastSection) {
      orderedCoreItems.push({ type: "divider" });
    }
    orderedCoreItems.push(item);
    lastSection = currentSection;
  }
  const result = [];
  result.push(...orderedCoreItems);
  if (extensionItems.length > 0) {
    result.push({ type: "divider" });
    result.push({
      label: "Extensions",
      type: "category",
      disabled: true
    });
    result.push(...extensionItems);
  }
  if (deleteItem) {
    result.push({ type: "divider" });
    result.push(deleteItem);
  }
  return result;
}
__name(buildStructuredMenu, "buildStructuredMenu");
function convertContextMenuToOptions(items, node, applyStructuring = true) {
  const result = [];
  for (const item of items) {
    if (item === null) {
      result.push({ type: "divider" });
      continue;
    }
    if (!item.content) {
      continue;
    }
    if (HARD_BLACKLIST.has(item.content)) {
      continue;
    }
    if (isDuplicateItem(item.content, result)) {
      continue;
    }
    const option = {
      label: item.content,
      source: "litegraph"
    };
    if (item.disabled) {
      option.disabled = true;
    }
    if (item.has_submenu) {
      if (item.submenu?.options) {
        option.hasSubmenu = true;
        option.submenu = convertSubmenuToOptions(item.submenu.options);
      } else if (item.callback && !item.disabled) {
        option.hasSubmenu = true;
        const capturedSubmenu = captureDynamicSubmenu(item, node);
        if (capturedSubmenu) {
          option.submenu = capturedSubmenu;
        } else {
          console.warn(
            "[ContextMenuConverter] Failed to capture submenu for:",
            item.content
          );
        }
      }
    } else if (item.callback && !item.disabled) {
      option.action = () => {
        try {
          void item.callback?.call(
            item,
            item.value,
            {},
            void 0,
            void 0,
            item
          );
        } catch (error) {
          console.error("Error executing context menu callback:", error);
        }
      };
    }
    result.push(option);
  }
  if (applyStructuring) {
    return buildStructuredMenu(result);
  }
  return result;
}
__name(convertContextMenuToOptions, "convertContextMenuToOptions");
function captureDynamicSubmenu(item, node) {
  let capturedItems;
  let capturedOptions;
  const OriginalContextMenu = LiteGraph.ContextMenu;
  try {
    LiteGraph.ContextMenu = function(items, options) {
      capturedItems = items;
      capturedOptions = options;
      return {
        close: /* @__PURE__ */ __name(() => {
        }, "close"),
        root: document.createElement("div")
      };
    };
    try {
      const mockEvent = new MouseEvent("click", {
        bubbles: true,
        cancelable: true,
        clientX: 0,
        clientY: 0
      });
      const mockMenu = {
        close: /* @__PURE__ */ __name(() => {
        }, "close"),
        root: document.createElement("div")
      };
      void item.callback?.call(
        item,
        item.value,
        {},
        mockEvent,
        mockMenu,
        node
        // Pass the node context for callbacks that need it
      );
    } catch (error) {
      console.warn(
        "[ContextMenuConverter] Error executing callback for:",
        item.content,
        error
      );
    }
  } finally {
    LiteGraph.ContextMenu = OriginalContextMenu;
  }
  if (capturedItems) {
    const converted = convertSubmenuToOptions(capturedItems, capturedOptions);
    return converted;
  }
  console.warn("[ContextMenuConverter] No items captured for:", item.content);
  return void 0;
}
__name(captureDynamicSubmenu, "captureDynamicSubmenu");
function convertSubmenuToOptions(items, options) {
  const result = [];
  for (const item of items) {
    if (item === null) {
      continue;
    }
    if (typeof item === "string") {
      const subOption2 = {
        label: item,
        action: /* @__PURE__ */ __name(() => {
          try {
            if (options?.callback) {
              void options.callback.call(
                null,
                item,
                options,
                void 0,
                void 0,
                options.extra
              );
            }
          } catch (error) {
            console.error("Error executing string item callback:", error);
          }
        }, "action")
      };
      result.push(subOption2);
      continue;
    }
    if (!item.content) {
      continue;
    }
    const content = stripHtmlTags(item.content);
    const subOption = {
      label: content,
      action: /* @__PURE__ */ __name(() => {
        try {
          void item.callback?.call(
            item,
            item.value,
            {},
            void 0,
            void 0,
            item
          );
        } catch (error) {
          console.error("Error executing submenu callback:", error);
        }
      }, "action")
    };
    if (item.disabled) {
      subOption.disabled = true;
    }
    result.push(subOption);
  }
  return result;
}
__name(convertSubmenuToOptions, "convertSubmenuToOptions");
function stripHtmlTags(html) {
  const sanitized = purify.sanitize(html, { ALLOWED_TAGS: [] });
  const result = sanitized.trim();
  return result || html.replace(/<[^>]*>/g, "").trim() || html;
}
__name(stripHtmlTags, "stripHtmlTags");
function useCanvasRefresh() {
  const canvasStore = useCanvasStore();
  const workflowStore = useWorkflowStore();
  const refreshCanvas = /* @__PURE__ */ __name(() => {
    canvasStore.canvas?.emitBeforeChange();
    canvasStore.canvas?.setDirty(true, true);
    canvasStore.canvas?.graph?.afterChange();
    canvasStore.canvas?.emitAfterChange();
    workflowStore.activeWorkflow?.changeTracker?.checkState();
  }, "refreshCanvas");
  return {
    refreshCanvas
  };
}
__name(useCanvasRefresh, "useCanvasRefresh");
function useNodeCustomization() {
  const { t: t2 } = useI18n();
  const canvasStore = useCanvasStore();
  const colorPaletteStore = useColorPaletteStore();
  const canvasRefresh = useCanvasRefresh();
  const isLightTheme = computed(
    () => colorPaletteStore.completedActivePalette.light_theme
  );
  const toLightThemeColor = /* @__PURE__ */ __name((color) => adjustColor(color, { lightness: 0.5 }), "toLightThemeColor");
  const NO_COLOR_OPTION = {
    name: "noColor",
    localizedName: t2("color.noColor"),
    value: {
      dark: LiteGraph.NODE_DEFAULT_BGCOLOR,
      light: toLightThemeColor(LiteGraph.NODE_DEFAULT_BGCOLOR)
    }
  };
  const colorOptions = [
    NO_COLOR_OPTION,
    ...Object.entries(LGraphCanvas.node_colors).map(([name, color]) => ({
      name,
      localizedName: t2(`color.${name}`),
      value: {
        dark: color.bgcolor,
        light: toLightThemeColor(color.bgcolor)
      }
    }))
  ];
  const shapeOptions = [
    {
      name: "default",
      localizedName: t2("shape.default"),
      value: RenderShape.ROUND
    },
    {
      name: "box",
      localizedName: t2("shape.box"),
      value: RenderShape.BOX
    },
    {
      name: "card",
      localizedName: t2("shape.CARD"),
      value: RenderShape.CARD
    }
  ];
  const applyColor = /* @__PURE__ */ __name((colorOption) => {
    const colorName = colorOption?.name ?? NO_COLOR_OPTION.name;
    const canvasColorOption = colorName === NO_COLOR_OPTION.name ? null : LGraphCanvas.node_colors[colorName];
    for (const item of canvasStore.selectedItems) {
      if (isColorable(item)) {
        item.setColorOption(canvasColorOption);
      }
    }
    canvasRefresh.refreshCanvas();
  }, "applyColor");
  const applyShape = /* @__PURE__ */ __name((shapeOption) => {
    const selectedNodes = Array.from(canvasStore.selectedItems).filter(
      (item) => item instanceof LGraphNode
    );
    if (selectedNodes.length === 0) {
      return;
    }
    selectedNodes.forEach((node) => {
      node.shape = shapeOption.value;
    });
    canvasRefresh.refreshCanvas();
  }, "applyShape");
  const getCurrentColor = /* @__PURE__ */ __name(() => {
    const selectedItems = Array.from(canvasStore.selectedItems);
    if (selectedItems.length === 0) return null;
    const firstColorableItem = selectedItems.find((item) => isColorable(item));
    if (!firstColorableItem || !isColorable(firstColorableItem)) return null;
    const currentColorOption = firstColorableItem.getColorOption();
    const currentBgColor = currentColorOption?.bgcolor ?? null;
    return colorOptions.find(
      (option) => option.value.dark === currentBgColor || option.value.light === currentBgColor
    ) ?? NO_COLOR_OPTION;
  }, "getCurrentColor");
  const getCurrentShape = /* @__PURE__ */ __name(() => {
    const selectedNodes = Array.from(canvasStore.selectedItems).filter(
      (item) => item instanceof LGraphNode
    );
    if (selectedNodes.length === 0) return null;
    const firstNode = selectedNodes[0];
    const currentShape = firstNode.shape ?? RenderShape.ROUND;
    return shapeOptions.find((option) => option.value === currentShape) ?? shapeOptions[0];
  }, "getCurrentShape");
  return {
    colorOptions,
    shapeOptions,
    applyColor,
    applyShape,
    getCurrentColor,
    getCurrentShape,
    isLightTheme
  };
}
__name(useNodeCustomization, "useNodeCustomization");
function useGroupMenuOptions() {
  const { t: t2 } = useI18n();
  const canvasStore = useCanvasStore();
  const workflowStore = useWorkflowStore();
  const settingStore = useSettingStore();
  const canvasRefresh = useCanvasRefresh();
  const { shapeOptions, colorOptions, isLightTheme } = useNodeCustomization();
  const getFitGroupToNodesOption = /* @__PURE__ */ __name((groupContext) => ({
    label: "Fit Group To Nodes",
    icon: "icon-[lucide--move-diagonal-2]",
    action: /* @__PURE__ */ __name(() => {
      try {
        groupContext.recomputeInsideNodes();
      } catch (e) {
        console.warn("Failed to recompute group nodes:", e);
        return;
      }
      const padding = settingStore.get("Comfy.GroupSelectedNodes.Padding");
      groupContext.resizeTo(groupContext.children, padding);
      groupContext.graph?.change();
      canvasStore.canvas?.setDirty(true, true);
      workflowStore.activeWorkflow?.changeTracker?.checkState();
    }, "action")
  }), "getFitGroupToNodesOption");
  const getGroupShapeOptions = /* @__PURE__ */ __name((groupContext, bump) => ({
    label: t2("contextMenu.Shape"),
    icon: "icon-[lucide--box]",
    hasSubmenu: true,
    submenu: shapeOptions.map((shape) => ({
      label: shape.localizedName,
      action: /* @__PURE__ */ __name(() => {
        const nodes = groupContext.nodes || [];
        nodes.forEach((node) => node.shape = shape.value);
        canvasRefresh.refreshCanvas();
        bump();
      }, "action")
    }))
  }), "getGroupShapeOptions");
  const getGroupColorOptions = /* @__PURE__ */ __name((groupContext, bump) => ({
    label: t2("contextMenu.Color"),
    icon: "icon-[lucide--palette]",
    hasSubmenu: true,
    submenu: colorOptions.map((colorOption) => ({
      label: colorOption.localizedName,
      color: isLightTheme.value ? colorOption.value.light : colorOption.value.dark,
      action: /* @__PURE__ */ __name(() => {
        groupContext.color = isLightTheme.value ? colorOption.value.light : colorOption.value.dark;
        canvasRefresh.refreshCanvas();
        bump();
      }, "action")
    }))
  }), "getGroupColorOptions");
  const getGroupModeOptions = /* @__PURE__ */ __name((groupContext, bump) => {
    const options = [];
    try {
      groupContext.recomputeInsideNodes();
    } catch (e) {
      console.warn("Failed to recompute group nodes for mode options:", e);
      return options;
    }
    const groupNodes = groupContext.nodes || [];
    if (!groupNodes.length) return options;
    let allSame = true;
    for (let i = 1; i < groupNodes.length; i++) {
      if (groupNodes[i].mode !== groupNodes[0].mode) {
        allSame = false;
        break;
      }
    }
    const createModeAction = /* @__PURE__ */ __name((label, mode) => ({
      label: t2(`selectionToolbox.${label}`),
      icon: mode === LGraphEventMode.BYPASS ? "icon-[lucide--ban]" : mode === LGraphEventMode.NEVER ? "icon-[lucide--zap-off]" : "icon-[lucide--play]",
      action: /* @__PURE__ */ __name(() => {
        groupNodes.forEach((n) => {
          n.mode = mode;
        });
        canvasStore.canvas?.setDirty(true, true);
        groupContext.graph?.change();
        workflowStore.activeWorkflow?.changeTracker?.checkState();
        bump();
      }, "action")
    }), "createModeAction");
    if (allSame) {
      const current = groupNodes[0].mode;
      switch (current) {
        case LGraphEventMode.ALWAYS:
          options.push(
            createModeAction("Set Group Nodes to Never", LGraphEventMode.NEVER)
          );
          options.push(
            createModeAction("Bypass Group Nodes", LGraphEventMode.BYPASS)
          );
          break;
        case LGraphEventMode.NEVER:
          options.push(
            createModeAction(
              "Set Group Nodes to Always",
              LGraphEventMode.ALWAYS
            )
          );
          options.push(
            createModeAction("Bypass Group Nodes", LGraphEventMode.BYPASS)
          );
          break;
        case LGraphEventMode.BYPASS:
          options.push(
            createModeAction(
              "Set Group Nodes to Always",
              LGraphEventMode.ALWAYS
            )
          );
          options.push(
            createModeAction("Set Group Nodes to Never", LGraphEventMode.NEVER)
          );
          break;
        default:
          options.push(
            createModeAction(
              "Set Group Nodes to Always",
              LGraphEventMode.ALWAYS
            )
          );
          options.push(
            createModeAction("Set Group Nodes to Never", LGraphEventMode.NEVER)
          );
          options.push(
            createModeAction("Bypass Group Nodes", LGraphEventMode.BYPASS)
          );
          break;
      }
    } else {
      options.push(
        createModeAction("Set Group Nodes to Always", LGraphEventMode.ALWAYS)
      );
      options.push(
        createModeAction("Set Group Nodes to Never", LGraphEventMode.NEVER)
      );
      options.push(
        createModeAction("Bypass Group Nodes", LGraphEventMode.BYPASS)
      );
    }
    return options;
  }, "getGroupModeOptions");
  return {
    getFitGroupToNodesOption,
    getGroupShapeOptions,
    getGroupColorOptions,
    getGroupModeOptions
  };
}
__name(useGroupMenuOptions, "useGroupMenuOptions");
function useImageMenuOptions() {
  const { t: t2 } = useI18n();
  const openMaskEditor = /* @__PURE__ */ __name(() => {
    const commandStore = useCommandStore();
    void commandStore.execute("Comfy.MaskEditor.OpenMaskEditor");
  }, "openMaskEditor");
  const openImage = /* @__PURE__ */ __name((node) => {
    if (!node?.imgs?.length) return;
    const img = node.imgs[node.imageIndex ?? 0];
    if (!img) return;
    const url = new URL(img.src);
    url.searchParams.delete("preview");
    window.open(url.toString(), "_blank");
  }, "openImage");
  const copyImage = /* @__PURE__ */ __name(async (node) => {
    if (!node?.imgs?.length) return;
    const img = node.imgs[node.imageIndex ?? 0];
    if (!img) return;
    const canvas = document.createElement("canvas");
    const ctx = canvas.getContext("2d");
    if (!ctx) return;
    canvas.width = img.naturalWidth;
    canvas.height = img.naturalHeight;
    ctx.drawImage(img, 0, 0);
    try {
      const blob = await new Promise((resolve) => {
        canvas.toBlob(resolve, "image/png");
      });
      if (!blob) {
        console.warn("Failed to create image blob");
        return;
      }
      if (!navigator.clipboard?.write) {
        console.warn("Clipboard API not available");
        return;
      }
      await navigator.clipboard.write([
        new ClipboardItem({ "image/png": blob })
      ]);
    } catch (error) {
      console.error("Failed to copy image to clipboard:", error);
    }
  }, "copyImage");
  const saveImage = /* @__PURE__ */ __name((node) => {
    if (!node?.imgs?.length) return;
    const img = node.imgs[node.imageIndex ?? 0];
    if (!img) return;
    try {
      const url = new URL(img.src);
      url.searchParams.delete("preview");
      downloadFile(url.toString());
    } catch (error) {
      console.error("Failed to save image:", error);
    }
  }, "saveImage");
  const getImageMenuOptions = /* @__PURE__ */ __name((node) => {
    if (!node?.imgs?.length) return [];
    return [
      {
        label: t2("contextMenu.Open in Mask Editor"),
        action: /* @__PURE__ */ __name(() => openMaskEditor(), "action")
      },
      {
        label: t2("contextMenu.Open Image"),
        icon: "icon-[lucide--external-link]",
        action: /* @__PURE__ */ __name(() => openImage(node), "action")
      },
      {
        label: t2("contextMenu.Copy Image"),
        icon: "icon-[lucide--copy]",
        action: /* @__PURE__ */ __name(() => copyImage(node), "action")
      },
      {
        label: t2("contextMenu.Save Image"),
        icon: "icon-[lucide--download]",
        action: /* @__PURE__ */ __name(() => saveImage(node), "action")
      }
    ];
  }, "getImageMenuOptions");
  return {
    getImageMenuOptions
  };
}
__name(useImageMenuOptions, "useImageMenuOptions");
function useSelectedNodeActions() {
  const { getSelectedNodes, toggleSelectedNodesMode } = useSelectedLiteGraphItems();
  const commandStore = useCommandStore();
  const workflowStore = useWorkflowStore();
  const adjustNodeSize = /* @__PURE__ */ __name(() => {
    const selectedNodes = getSelectedNodes();
    selectedNodes.forEach((node) => {
      const optimalSize = node.computeSize();
      node.setSize([optimalSize[0], optimalSize[1]]);
    });
    app.canvas.setDirty(true, true);
    workflowStore.activeWorkflow?.changeTracker?.checkState();
  }, "adjustNodeSize");
  const toggleNodeCollapse = /* @__PURE__ */ __name(() => {
    const selectedNodes = getSelectedNodes();
    selectedNodes.forEach((node) => {
      node.collapse();
    });
    app.canvas.setDirty(true, true);
    workflowStore.activeWorkflow?.changeTracker?.checkState();
  }, "toggleNodeCollapse");
  const toggleNodePin = /* @__PURE__ */ __name(() => {
    const selectedNodes = getSelectedNodes();
    selectedNodes.forEach((node) => {
      node.pin(!node.pinned);
    });
    app.canvas.setDirty(true, true);
    workflowStore.activeWorkflow?.changeTracker?.checkState();
  }, "toggleNodePin");
  const toggleNodeBypass = /* @__PURE__ */ __name(() => {
    toggleSelectedNodesMode(LGraphEventMode.BYPASS);
    app.canvas.setDirty(true, true);
  }, "toggleNodeBypass");
  const runBranch = /* @__PURE__ */ __name(async () => {
    const selectedNodes = getSelectedNodes();
    const selectedOutputNodes = filterOutputNodes(selectedNodes);
    if (selectedOutputNodes.length === 0) return;
    await commandStore.execute("Comfy.QueueSelectedOutputNodes");
  }, "runBranch");
  return {
    adjustNodeSize,
    toggleNodeCollapse,
    toggleNodePin,
    toggleNodeBypass,
    runBranch
  };
}
__name(useSelectedNodeActions, "useSelectedNodeActions");
function useNodeMenuOptions() {
  const { t: t2 } = useI18n();
  const { shapeOptions, applyShape, applyColor, colorOptions, isLightTheme } = useNodeCustomization();
  const {
    adjustNodeSize,
    toggleNodeCollapse,
    toggleNodePin,
    toggleNodeBypass,
    runBranch
  } = useSelectedNodeActions();
  const shapeSubmenu = computed(
    () => shapeOptions.map((shape) => ({
      label: shape.localizedName,
      action: /* @__PURE__ */ __name(() => applyShape(shape), "action")
    }))
  );
  const colorSubmenu = computed(() => {
    return colorOptions.map((colorOption) => ({
      label: colorOption.localizedName,
      color: isLightTheme.value ? colorOption.value.light : colorOption.value.dark,
      action: /* @__PURE__ */ __name(() => applyColor(colorOption.name === "noColor" ? null : colorOption), "action")
    }));
  });
  const getAdjustSizeOption = /* @__PURE__ */ __name(() => ({
    label: t2("contextMenu.Adjust Size"),
    icon: "icon-[lucide--move-diagonal-2]",
    action: adjustNodeSize
  }), "getAdjustSizeOption");
  const getNodeVisualOptions = /* @__PURE__ */ __name((states, bump) => [
    {
      label: states.collapsed ? t2("contextMenu.Expand Node") : t2("contextMenu.Minimize Node"),
      icon: states.collapsed ? "icon-[lucide--maximize-2]" : "icon-[lucide--minimize-2]",
      action: /* @__PURE__ */ __name(() => {
        toggleNodeCollapse();
        bump();
      }, "action")
    },
    {
      label: t2("contextMenu.Shape"),
      icon: "icon-[lucide--box]",
      hasSubmenu: true,
      submenu: shapeSubmenu.value,
      action: /* @__PURE__ */ __name(() => {
      }, "action")
    },
    {
      label: t2("contextMenu.Color"),
      icon: "icon-[lucide--palette]",
      hasSubmenu: true,
      submenu: colorSubmenu.value,
      isColorPicker: true,
      action: /* @__PURE__ */ __name(() => {
      }, "action")
    }
  ], "getNodeVisualOptions");
  const getPinOption = /* @__PURE__ */ __name((states, bump) => ({
    label: states.pinned ? t2("contextMenu.Unpin") : t2("contextMenu.Pin"),
    icon: states.pinned ? "icon-[lucide--pin-off]" : "icon-[lucide--pin]",
    action: /* @__PURE__ */ __name(() => {
      toggleNodePin();
      bump();
    }, "action")
  }), "getPinOption");
  const getBypassOption = /* @__PURE__ */ __name((states, bump) => ({
    label: states.bypassed ? t2("contextMenu.Remove Bypass") : t2("contextMenu.Bypass"),
    icon: "icon-[lucide--redo-dot]",
    shortcut: "Ctrl+B",
    action: /* @__PURE__ */ __name(() => {
      toggleNodeBypass();
      bump();
    }, "action")
  }), "getBypassOption");
  const getRunBranchOption = /* @__PURE__ */ __name(() => ({
    label: t2("contextMenu.Run Branch"),
    icon: "icon-[lucide--play]",
    action: runBranch
  }), "getRunBranchOption");
  const getNodeInfoOption = /* @__PURE__ */ __name((showNodeHelp) => ({
    label: t2("contextMenu.Node Info"),
    icon: "icon-[lucide--info]",
    action: showNodeHelp
  }), "getNodeInfoOption");
  return {
    getNodeInfoOption,
    getAdjustSizeOption,
    getNodeVisualOptions,
    getPinOption,
    getBypassOption,
    getRunBranchOption,
    colorSubmenu
  };
}
__name(useNodeMenuOptions, "useNodeMenuOptions");
function useFrameNodes() {
  const settingStore = useSettingStore();
  const titleEditorStore = useTitleEditorStore();
  const { hasMultipleSelection } = useSelectionState();
  const canFrame = computed(() => hasMultipleSelection.value);
  const frameNodes = /* @__PURE__ */ __name(() => {
    const { canvas } = app;
    if (!canvas.selectedItems?.size) return;
    const group = new LGraphGroup();
    const padding = settingStore.get("Comfy.GroupSelectedNodes.Padding");
    group.resizeTo(canvas.selectedItems, padding);
    canvas.graph?.add(group);
    titleEditorStore.titleEditorTarget = group;
  }, "frameNodes");
  return { frameNodes, canFrame };
}
__name(useFrameNodes, "useFrameNodes");
function useNodeArrangement() {
  const { t: t2 } = useI18n();
  const canvasStore = useCanvasStore();
  const canvasRefresh = useCanvasRefresh();
  const alignOptions = [
    {
      name: "top",
      localizedName: t2("contextMenu.Top"),
      value: "top",
      icon: "icon-[lucide--align-start-vertical]"
    },
    {
      name: "bottom",
      localizedName: t2("contextMenu.Bottom"),
      value: "bottom",
      icon: "icon-[lucide--align-end-vertical]"
    },
    {
      name: "left",
      localizedName: t2("contextMenu.Left"),
      value: "left",
      icon: "icon-[lucide--align-start-horizontal]"
    },
    {
      name: "right",
      localizedName: t2("contextMenu.Right"),
      value: "right",
      icon: "icon-[lucide--align-end-horizontal]"
    }
  ];
  const distributeOptions = [
    {
      name: "horizontal",
      localizedName: t2("contextMenu.Horizontal"),
      value: true,
      icon: "icon-[lucide--align-center-horizontal]"
    },
    {
      name: "vertical",
      localizedName: t2("contextMenu.Vertical"),
      value: false,
      icon: "icon-[lucide--align-center-vertical]"
    }
  ];
  const applyAlign = /* @__PURE__ */ __name((alignOption) => {
    const selectedNodes = Array.from(canvasStore.selectedItems).filter(
      (item) => isLGraphNode(item)
    );
    if (selectedNodes.length === 0) {
      return;
    }
    const newPositions = alignNodes(selectedNodes, alignOption.value);
    canvasStore.canvas?.repositionNodesVueMode(newPositions);
    canvasRefresh.refreshCanvas();
  }, "applyAlign");
  const applyDistribute = /* @__PURE__ */ __name((distributeOption) => {
    const selectedNodes = Array.from(canvasStore.selectedItems).filter(
      (item) => isLGraphNode(item)
    );
    if (selectedNodes.length < 2) {
      return;
    }
    const newPositions = distributeNodes(selectedNodes, distributeOption.value);
    canvasStore.canvas?.repositionNodesVueMode(newPositions);
    canvasRefresh.refreshCanvas();
  }, "applyDistribute");
  return {
    alignOptions,
    distributeOptions,
    applyAlign,
    applyDistribute
  };
}
__name(useNodeArrangement, "useNodeArrangement");
function useSelectionOperations() {
  const canvasStore = useCanvasStore();
  const toastStore = useToastStore();
  const dialogService = useDialogService();
  const titleEditorStore = useTitleEditorStore();
  const workflowStore = useWorkflowStore();
  const copySelection = /* @__PURE__ */ __name(() => {
    const canvas = app.canvas;
    if (!canvas.selectedItems || canvas.selectedItems.size === 0) {
      toastStore.add({
        severity: "warn",
        summary: t("g.nothingToCopy"),
        detail: t("g.selectItemsToCopy"),
        life: 3e3
      });
      return;
    }
    canvas.copyToClipboard();
    toastStore.add({
      severity: "success",
      summary: t("g.copied"),
      detail: t("g.itemsCopiedToClipboard"),
      life: 2e3
    });
  }, "copySelection");
  const pasteSelection = /* @__PURE__ */ __name(() => {
    const canvas = app.canvas;
    canvas.pasteFromClipboard({ connectInputs: false });
    workflowStore.activeWorkflow?.changeTracker?.checkState();
  }, "pasteSelection");
  const duplicateSelection = /* @__PURE__ */ __name(() => {
    const canvas = app.canvas;
    if (!canvas.selectedItems || canvas.selectedItems.size === 0) {
      toastStore.add({
        severity: "warn",
        summary: t("g.nothingToDuplicate"),
        detail: t("g.selectItemsToDuplicate"),
        life: 3e3
      });
      return;
    }
    canvas.copyToClipboard();
    canvas.selectedItems.clear();
    canvasStore.updateSelectedItems();
    canvas.pasteFromClipboard({ connectInputs: false });
    workflowStore.activeWorkflow?.changeTracker?.checkState();
  }, "duplicateSelection");
  const deleteSelection = /* @__PURE__ */ __name(() => {
    const canvas = app.canvas;
    if (!canvas.selectedItems || canvas.selectedItems.size === 0) {
      toastStore.add({
        severity: "warn",
        summary: t("g.nothingToDelete"),
        detail: t("g.selectItemsToDelete"),
        life: 3e3
      });
      return;
    }
    canvas.deleteSelected();
    canvas.setDirty(true, true);
    workflowStore.activeWorkflow?.changeTracker?.checkState();
  }, "deleteSelection");
  const renameSelection = /* @__PURE__ */ __name(async () => {
    const selectedItems = Array.from(canvasStore.selectedItems);
    if (selectedItems.length === 1) {
      const item = selectedItems[0];
      if (item instanceof LGraphNode) {
        titleEditorStore.titleEditorTarget = item;
        return;
      }
      const currentTitle = "title" in item ? item.title : "";
      const newTitle = await dialogService.prompt({
        title: t("g.rename"),
        message: t("g.enterNewName"),
        defaultValue: currentTitle
      });
      if (newTitle && newTitle !== currentTitle) {
        if ("title" in item) {
          const titledItem = item;
          titledItem.title = newTitle;
          app.canvas.setDirty(true, true);
          workflowStore.activeWorkflow?.changeTracker?.checkState();
        }
      }
      return;
    }
    if (selectedItems.length > 1) {
      const baseTitle = await dialogService.prompt({
        title: t("g.batchRename"),
        message: t("g.enterBaseName"),
        defaultValue: "Item"
      });
      if (baseTitle) {
        selectedItems.forEach((item, index) => {
          if ("title" in item) {
            const titledItem = item;
            titledItem.title = `${baseTitle} ${index + 1}`;
          }
        });
        app.canvas.setDirty(true, true);
        workflowStore.activeWorkflow?.changeTracker?.checkState();
      }
      return;
    }
    toastStore.add({
      severity: "warn",
      summary: t("g.nothingToRename"),
      detail: t("g.selectItemsToRename"),
      life: 3e3
    });
  }, "renameSelection");
  return {
    copySelection,
    pasteSelection,
    duplicateSelection,
    deleteSelection,
    renameSelection
  };
}
__name(useSelectionOperations, "useSelectionOperations");
function useSelectionMenuOptions() {
  const { t: t2 } = useI18n();
  const {
    copySelection,
    duplicateSelection,
    deleteSelection,
    renameSelection
  } = useSelectionOperations();
  const { alignOptions, distributeOptions, applyAlign, applyDistribute } = useNodeArrangement();
  const { convertToSubgraph, unpackSubgraph, addSubgraphToLibrary } = useSubgraphOperations();
  const { frameNodes } = useFrameNodes();
  const alignSubmenu = computed(
    () => alignOptions.map((align) => ({
      label: align.localizedName,
      icon: align.icon,
      action: /* @__PURE__ */ __name(() => applyAlign(align), "action")
    }))
  );
  const distributeSubmenu = computed(
    () => distributeOptions.map((distribute) => ({
      label: distribute.localizedName,
      icon: distribute.icon,
      action: /* @__PURE__ */ __name(() => applyDistribute(distribute), "action")
    }))
  );
  const getBasicSelectionOptions = /* @__PURE__ */ __name(() => [
    {
      label: t2("contextMenu.Rename"),
      action: renameSelection
    },
    {
      label: t2("contextMenu.Copy"),
      shortcut: "Ctrl+C",
      action: copySelection
    },
    {
      label: t2("contextMenu.Duplicate"),
      shortcut: "Ctrl+D",
      action: duplicateSelection
    }
  ], "getBasicSelectionOptions");
  const getSubgraphOptions = /* @__PURE__ */ __name(({
    hasSubgraphs,
    hasMultipleSelection
  }) => {
    const convertOption = {
      label: t2("contextMenu.Convert to Subgraph"),
      icon: "icon-[lucide--shrink]",
      action: convertToSubgraph,
      badge: BadgeVariant.NEW
    };
    const options = [];
    const showConvertOption = !hasSubgraphs || hasMultipleSelection;
    if (showConvertOption) {
      options.push(convertOption);
    }
    if (hasSubgraphs) {
      options.push(
        {
          label: t2("contextMenu.Add Subgraph to Library"),
          icon: "icon-[lucide--folder-plus]",
          action: addSubgraphToLibrary
        },
        {
          label: t2("contextMenu.Unpack Subgraph"),
          icon: "icon-[lucide--expand]",
          action: unpackSubgraph
        }
      );
    }
    return options;
  }, "getSubgraphOptions");
  const getMultipleNodesOptions = /* @__PURE__ */ __name(() => {
    const convertToGroupNodes = /* @__PURE__ */ __name(() => {
      const commandStore = useCommandStore();
      void commandStore.execute(
        "Comfy.GroupNode.ConvertSelectedNodesToGroupNode"
      );
    }, "convertToGroupNodes");
    return [
      {
        label: t2("contextMenu.Convert to Group Node"),
        icon: "icon-[lucide--group]",
        action: convertToGroupNodes,
        badge: BadgeVariant.DEPRECATED
      },
      {
        label: t2("g.frameNodes"),
        icon: "icon-[lucide--frame]",
        action: frameNodes
      }
    ];
  }, "getMultipleNodesOptions");
  const getAlignmentOptions = /* @__PURE__ */ __name(() => [
    {
      label: t2("contextMenu.Align Selected To"),
      icon: "icon-[lucide--align-start-horizontal]",
      hasSubmenu: true,
      submenu: alignSubmenu.value,
      action: /* @__PURE__ */ __name(() => {
      }, "action")
    },
    {
      label: t2("contextMenu.Distribute Nodes"),
      icon: "icon-[lucide--align-center-horizontal]",
      hasSubmenu: true,
      submenu: distributeSubmenu.value,
      action: /* @__PURE__ */ __name(() => {
      }, "action")
    }
  ], "getAlignmentOptions");
  const getDeleteOption = /* @__PURE__ */ __name(() => ({
    label: t2("contextMenu.Delete"),
    icon: "icon-[lucide--trash-2]",
    shortcut: "Delete",
    action: deleteSelection
  }), "getDeleteOption");
  return {
    getBasicSelectionOptions,
    getSubgraphOptions,
    getMultipleNodesOptions,
    getDeleteOption,
    getAlignmentOptions,
    alignSubmenu,
    distributeSubmenu
  };
}
__name(useSelectionMenuOptions, "useSelectionMenuOptions");
var BadgeVariant = /* @__PURE__ */ ((BadgeVariant2) => {
  BadgeVariant2["NEW"] = "new";
  BadgeVariant2["DEPRECATED"] = "deprecated";
  return BadgeVariant2;
})(BadgeVariant || {});
let nodeOptionsInstance = null;
function toggleNodeOptions(event) {
  if (nodeOptionsInstance?.toggle) {
    nodeOptionsInstance.toggle(event);
  }
}
__name(toggleNodeOptions, "toggleNodeOptions");
function showNodeOptions(event) {
  if (nodeOptionsInstance?.show) {
    nodeOptionsInstance.show(event);
  }
}
__name(showNodeOptions, "showNodeOptions");
function registerNodeOptionsInstance(instance) {
  nodeOptionsInstance = instance;
}
__name(registerNodeOptionsInstance, "registerNodeOptionsInstance");
function markAsVueOptions(options) {
  return options.map((opt) => {
    if (opt.type === "divider" || opt.type === "category") {
      return opt;
    }
    return { ...opt, source: "vue" };
  });
}
__name(markAsVueOptions, "markAsVueOptions");
function useMoreOptionsMenu() {
  const {
    selectedItems,
    selectedNodes,
    nodeDef,
    showNodeHelp,
    hasSubgraphs: hasSubgraphsComputed,
    hasImageNode,
    hasOutputNodesSelected,
    hasMultipleSelection,
    computeSelectionFlags
  } = useSelectionState();
  const canvasStore = useCanvasStore();
  const { getImageMenuOptions } = useImageMenuOptions();
  const {
    getNodeInfoOption,
    getNodeVisualOptions,
    getPinOption,
    getBypassOption,
    getRunBranchOption
  } = useNodeMenuOptions();
  const {
    getFitGroupToNodesOption,
    getGroupColorOptions,
    getGroupModeOptions
  } = useGroupMenuOptions();
  const {
    getBasicSelectionOptions,
    getSubgraphOptions,
    getMultipleNodesOptions
  } = useSelectionMenuOptions();
  const hasSubgraphs = hasSubgraphsComputed;
  const hasMultipleNodes = hasMultipleSelection;
  const optionsVersion = ref(0);
  const bump = /* @__PURE__ */ __name(() => {
    optionsVersion.value++;
  }, "bump");
  const menuOptions = computed(() => {
    optionsVersion.value;
    const states = computeSelectionFlags();
    const selectedGroups = selectedItems.value.filter(
      isLGraphGroup
    );
    const groupContext = selectedGroups.length === 1 && selectedNodes.value.length === 0 ? selectedGroups[0] : null;
    const hasSubgraphsSelected = hasSubgraphs.value;
    const litegraphOptions = [];
    if (selectedNodes.value.length === 1 && !groupContext && canvasStore.canvas) {
      try {
        const node = selectedNodes.value[0];
        const rawItems = canvasStore.canvas.getNodeMenuOptions(node);
        litegraphOptions.push(
          ...convertContextMenuToOptions(rawItems, node, false)
        );
      } catch (error) {
        console.error("Error getting LiteGraph menu items:", error);
      }
    }
    const options = [];
    const basicOps = getBasicSelectionOptions();
    options.push(...basicOps);
    options.push({ type: "divider" });
    if (hasOutputNodesSelected.value) {
      const runBranch = getRunBranchOption();
      options.push(runBranch);
    }
    if (!groupContext) {
      const pin = getPinOption(states, bump);
      const bypass = getBypassOption(states, bump);
      options.push(pin);
      options.push(bypass);
    }
    if (groupContext) {
      const groupModes = getGroupModeOptions(groupContext, bump);
      options.push(...groupModes);
    }
    options.push({ type: "divider" });
    options.push(
      ...getSubgraphOptions({
        hasSubgraphs: hasSubgraphsSelected,
        hasMultipleSelection: hasMultipleNodes.value
      })
    );
    if (hasMultipleNodes.value) {
      options.push(...getMultipleNodesOptions());
    }
    if (groupContext) {
      options.push(getFitGroupToNodesOption(groupContext));
    } else {
      const visualOptions = getNodeVisualOptions(states, bump);
      if (visualOptions.length > 0) {
        options.push(visualOptions[0]);
      }
    }
    options.push({ type: "divider" });
    if (nodeDef.value) {
      options.push(getNodeInfoOption(showNodeHelp));
    }
    if (groupContext) {
      options.push(getGroupColorOptions(groupContext, bump));
    } else {
      const visualOptions = getNodeVisualOptions(states, bump);
      if (visualOptions.length > 1) {
        options.push(visualOptions[1]);
      }
      if (visualOptions.length > 2) {
        options.push(visualOptions[2]);
      }
    }
    options.push({ type: "divider" });
    if (hasImageNode.value && selectedNodes.value.length > 0) {
      options.push(...getImageMenuOptions(selectedNodes.value[0]));
      options.push({ type: "divider" });
    }
    const markedVueOptions = markAsVueOptions(options);
    if (litegraphOptions.length > 0) {
      const merged = [...litegraphOptions, ...markedVueOptions];
      return buildStructuredMenu(merged);
    }
    const result = buildStructuredMenu(markedVueOptions);
    return result;
  });
  const menuOptionsWithSubmenu = computed(
    () => menuOptions.value.filter((option) => option.hasSubmenu && option.submenu)
  );
  return {
    menuOptions,
    menuOptionsWithSubmenu,
    bump,
    hasSubgraphs,
    registerNodeOptionsInstance
  };
}
__name(useMoreOptionsMenu, "useMoreOptionsMenu");
const _hoisted_1$I = ["title", "onClick"];
const _hoisted_2$w = {
  key: 0,
  class: "icon-[lucide--check] size-4 flex-shrink-0"
};
const _hoisted_3$q = {
  key: 1,
  class: "w-4 flex-shrink-0"
};
const _sfc_main$Y = /* @__PURE__ */ defineComponent({
  __name: "ColorPickerMenu",
  props: {
    option: {}
  },
  emits: ["submenu-click"],
  setup(__props, { expose: __expose, emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const { getCurrentShape } = useNodeCustomization();
    const popoverRef = ref();
    const toggle = /* @__PURE__ */ __name((event, target) => {
      popoverRef.value?.toggle(event, target);
    }, "toggle");
    __expose({
      toggle
    });
    const handleSubmenuClick = /* @__PURE__ */ __name((subOption) => {
      if (subOption.disabled) {
        return;
      }
      emit("submenu-click", subOption);
      popoverRef.value?.hide();
    }, "handleSubmenuClick");
    const isShapeSelected = /* @__PURE__ */ __name((subOption) => {
      if (subOption.color) return false;
      const currentShape = getCurrentShape();
      if (!currentShape) return false;
      return currentShape.localizedName === subOption.label;
    }, "isShapeSelected");
    const isColorSubmenu = computed(() => {
      return props.option.submenu && props.option.submenu.length > 0 && props.option.submenu.every((item) => item.color && !item.icon);
    });
    return (_ctx, _cache) => {
      return openBlock(), createBlock(unref(script$1), {
        ref_key: "popoverRef",
        ref: popoverRef,
        "auto-z-index": true,
        "base-z-index": 1100,
        dismissable: true,
        "close-on-escape": true,
        unstyled: "",
        pt: {
          root: {
            class: "absolute z-60"
          },
          content: {
            class: [
              "text-base-foreground rounded-lg",
              "shadow-lg border border-base-background",
              "bg-interface-panel-surface"
            ]
          }
        }
      }, {
        default: withCtx(() => [
          createBaseVNode("div", {
            class: normalizeClass(
              isColorSubmenu.value ? "flex flex-col gap-1 p-2" : "flex flex-col p-2 min-w-40"
            )
          }, [
            (openBlock(true), createElementBlock(Fragment, null, renderList(_ctx.option.submenu, (subOption) => {
              return openBlock(), createElementBlock("div", {
                key: subOption.label,
                class: normalizeClass(
                  unref(cn)(
                    "hover:bg-secondary-background-hover rounded cursor-pointer",
                    isColorSubmenu.value ? "w-7 h-7 flex items-center justify-center" : "flex items-center gap-2 px-3 py-1.5 text-sm",
                    subOption.disabled ? "cursor-not-allowed pointer-events-none text-node-icon-disabled" : "hover:bg-secondary-background-hover"
                  )
                ),
                title: subOption.label,
                onClick: /* @__PURE__ */ __name(($event) => handleSubmenuClick(subOption), "onClick")
              }, [
                subOption.color ? (openBlock(), createElementBlock("div", {
                  key: 0,
                  class: "size-5 rounded-full border border-border-default",
                  style: normalizeStyle({ backgroundColor: subOption.color })
                }, null, 4)) : !subOption.color ? (openBlock(), createElementBlock(Fragment, { key: 1 }, [
                  isShapeSelected(subOption) ? (openBlock(), createElementBlock("i", _hoisted_2$w)) : (openBlock(), createElementBlock("div", _hoisted_3$q)),
                  createBaseVNode("span", null, toDisplayString(subOption.label), 1)
                ], 64)) : createCommentVNode("", true)
              ], 10, _hoisted_1$I);
            }), 128))
          ], 2)
        ]),
        _: 1
      }, 512);
    };
  }
});
const _hoisted_1$H = ["onClick"];
const _hoisted_2$v = { class: "flex-1" };
const _hoisted_3$p = {
  key: 1,
  class: "flex h-3.5 min-w-3.5 items-center justify-center rounded bg-interface-menu-keybind-surface-default px-1 py-0 text-xs"
};
const _hoisted_4$j = {
  key: 2,
  class: "icon-[lucide--chevron-right] size-4 opacity-60"
};
const _sfc_main$X = /* @__PURE__ */ defineComponent({
  __name: "NodeContextMenu",
  setup(__props, { expose: __expose }) {
    const contextMenu = ref();
    const colorPickerMenu = ref();
    const isOpen = ref(false);
    const { menuOptions, bump } = useMoreOptionsMenu();
    const canvasStore = useCanvasStore();
    const worldPosition = ref({ x: 0, y: 0 });
    const lgCanvas = canvasStore.getCanvas();
    const { left: canvasLeft, top: canvasTop } = useElementBounding(lgCanvas.canvas);
    let lastScale = 0;
    let lastOffsetX = 0;
    let lastOffsetY = 0;
    const updateMenuPosition = /* @__PURE__ */ __name(() => {
      if (!isOpen.value) return;
      const menuInstance = contextMenu.value;
      const menuEl = menuInstance?.container;
      if (!menuEl) return;
      const { scale, offset } = lgCanvas.ds;
      if (scale === lastScale && offset[0] === lastOffsetX && offset[1] === lastOffsetY) {
        return;
      }
      lastScale = scale;
      lastOffsetX = offset[0];
      lastOffsetY = offset[1];
      const screenX = (worldPosition.value.x + offset[0]) * scale + canvasLeft.value;
      const screenY = (worldPosition.value.y + offset[1]) * scale + canvasTop.value;
      menuEl.style.left = `${screenX}px`;
      menuEl.style.top = `${screenY}px`;
    }, "updateMenuPosition");
    const { resume: startSync, pause: stopSync } = useRafFn(updateMenuPosition, {
      immediate: false
    });
    watchEffect(() => {
      if (isOpen.value) {
        startSync();
      } else {
        stopSync();
      }
    });
    useEventListener(
      window,
      "touchstart",
      (event) => {
        if (!isOpen.value || !contextMenu.value) return;
        const target = event.target;
        const contextMenuInstance = contextMenu.value;
        const menuEl = contextMenuInstance.container || contextMenuInstance.$el;
        if (menuEl && !menuEl.contains(target)) {
          hide();
        }
      },
      { passive: true }
    );
    const colorOption = computed(
      () => menuOptions.value.find((opt) => opt.isColorPicker)
    );
    function isColorOption(option) {
      return Boolean(option.isColorPicker);
    }
    __name(isColorOption, "isColorOption");
    function convertToMenuItem(option) {
      if (option.type === "divider") return { separator: true };
      const isColor = isColorOption(option);
      const item = {
        label: option.label,
        icon: option.icon,
        disabled: option.disabled,
        shortcut: option.shortcut,
        isColorSubmenu: isColor,
        originalOption: option
      };
      if (option.hasSubmenu && option.submenu && !isColor) {
        item.items = option.submenu.map((sub) => ({
          label: sub.label,
          icon: sub.icon,
          disabled: sub.disabled,
          command: /* @__PURE__ */ __name(() => {
            sub.action();
            hide();
          }, "command")
        }));
      }
      if (!option.hasSubmenu && option.action) {
        item.command = () => {
          option.action?.();
          hide();
        };
      }
      return item;
    }
    __name(convertToMenuItem, "convertToMenuItem");
    const menuItems = computed(
      () => menuOptions.value.map(convertToMenuItem)
    );
    function show(event) {
      bump();
      const screenX = event.clientX - canvasLeft.value;
      const screenY = event.clientY - canvasTop.value;
      const { scale, offset } = lgCanvas.ds;
      worldPosition.value = {
        x: screenX / scale - offset[0],
        y: screenY / scale - offset[1]
      };
      isOpen.value = true;
      contextMenu.value?.show(event);
    }
    __name(show, "show");
    function hide() {
      contextMenu.value?.hide();
    }
    __name(hide, "hide");
    function toggle(event) {
      if (isOpen.value) {
        hide();
      } else {
        show(event);
      }
    }
    __name(toggle, "toggle");
    __expose({ toggle, hide, isOpen, show });
    function showColorPopover(event) {
      event.stopPropagation();
      event.preventDefault();
      const target = Array.from(event.currentTarget.children).find(
        (el) => el.classList.contains("icon-[lucide--chevron-right]")
      );
      colorPickerMenu.value?.toggle(event, target);
    }
    __name(showColorPopover, "showColorPopover");
    function handleColorSelect(subOption) {
      subOption.action();
      hide();
    }
    __name(handleColorSelect, "handleColorSelect");
    function onMenuShow() {
      isOpen.value = true;
    }
    __name(onMenuShow, "onMenuShow");
    function onMenuHide() {
      isOpen.value = false;
    }
    __name(onMenuHide, "onMenuHide");
    onMounted(() => {
      registerNodeOptionsInstance({ toggle, show, hide, isOpen });
    });
    onUnmounted(() => {
      registerNodeOptionsInstance(null);
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createVNode(unref(script$i), {
          ref_key: "contextMenu",
          ref: contextMenu,
          model: menuItems.value,
          class: "max-h-[80vh] md:max-h-none overflow-y-auto md:overflow-y-visible",
          onShow: onMenuShow,
          onHide: onMenuHide
        }, {
          item: withCtx(({ item, props, hasSubmenu }) => [
            createBaseVNode("a", mergeProps(props.action, {
              class: "flex items-center gap-2 px-3 py-1.5",
              onClick: /* @__PURE__ */ __name(($event) => item.isColorSubmenu ? showColorPopover($event) : void 0, "onClick")
            }), [
              item.icon ? (openBlock(), createElementBlock("i", {
                key: 0,
                class: normalizeClass([item.icon, "size-4"])
              }, null, 2)) : createCommentVNode("", true),
              createBaseVNode("span", _hoisted_2$v, toDisplayString(item.label), 1),
              item.shortcut ? (openBlock(), createElementBlock("span", _hoisted_3$p, toDisplayString(item.shortcut), 1)) : createCommentVNode("", true),
              hasSubmenu || item.isColorSubmenu ? (openBlock(), createElementBlock("i", _hoisted_4$j)) : createCommentVNode("", true)
            ], 16, _hoisted_1$H)
          ]),
          _: 1
        }, 8, ["model"]),
        colorOption.value ? (openBlock(), createBlock(_sfc_main$Y, {
          ref_key: "colorPickerMenu",
          ref: colorPickerMenu,
          key: "color-picker-menu",
          option: colorOption.value,
          onSubmenuClick: handleColorSelect
        }, null, 8, ["option"])) : createCommentVNode("", true)
      ], 64);
    };
  }
});
const _sfc_main$W = /* @__PURE__ */ defineComponent({
  __name: "FrameNodes",
  setup(__props) {
    const { frameNodes } = useFrameNodes();
    return (_ctx, _cache) => {
      const _directive_tooltip = resolveDirective("tooltip");
      return withDirectives((openBlock(), createBlock(_sfc_main$1Y, {
        variant: "muted-textonly",
        "aria-label": _ctx.$t("g.frameNodes"),
        onClick: unref(frameNodes)
      }, {
        default: withCtx(() => _cache[0] || (_cache[0] = [
          createBaseVNode("i", { class: "icon-[lucide--frame]" }, null, -1)
        ])),
        _: 1
      }, 8, ["aria-label", "onClick"])), [
        [
          _directive_tooltip,
          {
            value: _ctx.$t("g.frameNodes"),
            showDelay: 1e3
          },
          void 0,
          { top: true }
        ]
      ]);
    };
  }
});
const _sfc_main$V = /* @__PURE__ */ defineComponent({
  __name: "NodeOptionsButton",
  setup(__props) {
    const handleClick = /* @__PURE__ */ __name((event) => {
      toggleNodeOptions(event);
    }, "handleClick");
    return (_ctx, _cache) => {
      const _directive_tooltip = resolveDirective("tooltip");
      return withDirectives((openBlock(), createBlock(_sfc_main$1Y, {
        "data-testid": "more-options-button",
        variant: "muted-textonly",
        "aria-label": _ctx.$t("g.moreOptions"),
        onClick: handleClick
      }, {
        default: withCtx(() => _cache[0] || (_cache[0] = [
          createBaseVNode("i", { class: "icon-[lucide--more-vertical]" }, null, -1)
        ])),
        _: 1
      }, 8, ["aria-label"])), [
        [
          _directive_tooltip,
          {
            value: _ctx.$t("g.moreOptions"),
            showDelay: 1e3
          },
          void 0,
          { top: true }
        ]
      ]);
    };
  }
});
const _sfc_main$U = {};
const _hoisted_1$G = { class: "h-6 w-px self-center bg-border-default" };
function _sfc_render$1(_ctx, _cache) {
  return openBlock(), createElementBlock("div", _hoisted_1$G);
}
__name(_sfc_render$1, "_sfc_render$1");
const VerticalDivider = /* @__PURE__ */ _export_sfc(_sfc_main$U, [["render", _sfc_render$1]]);
const _sfc_main$T = /* @__PURE__ */ defineComponent({
  __name: "SelectionToolbox",
  setup(__props) {
    const commandStore = useCommandStore();
    const canvasStore = useCanvasStore();
    const extensionService = useExtensionService();
    const canvasInteractions = useCanvasInteractions();
    const toolboxRef = ref();
    const { visible } = useSelectionToolboxPosition(toolboxRef);
    const extensionToolboxCommands = computed(() => {
      const commandIds = new Set(
        canvasStore.selectedItems.map(
          (item) => extensionService.invokeExtensions("getSelectionToolboxCommands", item).flat()
        ).flat()
      );
      return Array.from(commandIds).map((commandId) => commandStore.getCommand(commandId)).filter((command) => command !== void 0);
    });
    const {
      hasAnySelection,
      hasMultipleSelection,
      isSingleNode,
      isSingleSubgraph,
      isSingleImageNode,
      hasAny3DNodeSelected,
      hasOutputNodesSelected,
      nodeDef
    } = useSelectionState();
    const showInfoButton = computed(() => !!nodeDef.value);
    const showColorPicker = computed(() => hasAnySelection.value);
    const showConvertToSubgraph = computed(() => hasAnySelection.value);
    const showFrameNodes = computed(() => hasMultipleSelection.value);
    const showSubgraphButtons = computed(() => isSingleSubgraph.value);
    const showBypass = computed(
      () => isSingleNode.value || isSingleSubgraph.value || hasMultipleSelection.value
    );
    const showLoad3DViewer = computed(() => hasAny3DNodeSelected.value);
    const showMaskEditor = computed(() => isSingleImageNode.value);
    const showDelete = computed(() => hasAnySelection.value);
    const showRefresh = computed(() => hasAnySelection.value);
    const showExecute = computed(() => hasOutputNodesSelected.value);
    const showAnyPrimaryActions = computed(
      () => showColorPicker.value || showConvertToSubgraph.value || showFrameNodes.value || showSubgraphButtons.value
    );
    const showAnyControlActions = computed(() => showBypass.value);
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createBaseVNode("div", {
          ref_key: "toolboxRef",
          ref: toolboxRef,
          style: { "transform": "translate(var(--tb-x), var(--tb-y))" },
          class: "pointer-events-none fixed top-0 left-0 z-40"
        }, [
          createVNode(Transition, { name: "slide-up" }, {
            default: withCtx(() => [
              unref(visible) ? (openBlock(), createBlock(unref(script$5), {
                key: 0,
                class: "selection-toolbox pointer-events-auto rounded-lg border border-interface-stroke bg-interface-panel-surface",
                pt: {
                  header: "hidden",
                  content: "p-2 h-12 flex flex-row gap-1"
                },
                onWheel: unref(canvasInteractions).forwardEventToCanvas
              }, {
                default: withCtx(() => [
                  showDelete.value ? (openBlock(), createBlock(_sfc_main$14, { key: 0 })) : createCommentVNode("", true),
                  showInfoButton.value && showAnyPrimaryActions.value ? (openBlock(), createBlock(VerticalDivider, { key: 1 })) : createCommentVNode("", true),
                  showInfoButton.value ? (openBlock(), createBlock(_sfc_main$11, { key: 2 })) : createCommentVNode("", true),
                  showColorPicker.value ? (openBlock(), createBlock(ColorPickerButton, { key: 3 })) : createCommentVNode("", true),
                  showFrameNodes.value ? (openBlock(), createBlock(_sfc_main$W, { key: 4 })) : createCommentVNode("", true),
                  showConvertToSubgraph.value ? (openBlock(), createBlock(_sfc_main$15, { key: 5 })) : createCommentVNode("", true),
                  showSubgraphButtons.value ? (openBlock(), createBlock(_sfc_main$16, { key: 6 })) : createCommentVNode("", true),
                  showSubgraphButtons.value ? (openBlock(), createBlock(_sfc_main$Z, { key: 7 })) : createCommentVNode("", true),
                  showMaskEditor.value ? (openBlock(), createBlock(_sfc_main$$, { key: 8 })) : createCommentVNode("", true),
                  showAnyPrimaryActions.value && showAnyControlActions.value ? (openBlock(), createBlock(VerticalDivider, { key: 9 })) : createCommentVNode("", true),
                  showBypass.value ? (openBlock(), createBlock(_sfc_main$18, { key: 10 })) : createCommentVNode("", true),
                  showRefresh.value ? (openBlock(), createBlock(_sfc_main$_, { key: 11 })) : createCommentVNode("", true),
                  showLoad3DViewer.value ? (openBlock(), createBlock(_sfc_main$10, { key: 12 })) : createCommentVNode("", true),
                  (openBlock(true), createElementBlock(Fragment, null, renderList(extensionToolboxCommands.value, (command) => {
                    return openBlock(), createBlock(_sfc_main$12, {
                      key: command.id,
                      command
                    }, null, 8, ["command"]);
                  }), 128)),
                  showExecute.value ? (openBlock(), createBlock(_sfc_main$13, { key: 13 })) : createCommentVNode("", true),
                  createVNode(_sfc_main$V)
                ]),
                _: 1
              }, 8, ["onWheel"])) : createCommentVNode("", true)
            ]),
            _: 1
          })
        ], 512),
        createVNode(_sfc_main$X)
      ], 64);
    };
  }
});
const SelectionToolbox = /* @__PURE__ */ _export_sfc(_sfc_main$T, [["__scopeId", "data-v-c6489a20"]]);
const _sfc_main$S = /* @__PURE__ */ defineComponent({
  __name: "TitleEditor",
  setup(__props) {
    const settingStore = useSettingStore();
    const showInput = ref(false);
    const editedTitle = ref("");
    const { style: inputPositionStyle, updatePosition } = useAbsolutePosition();
    const inputFontStyle = ref({});
    const inputStyle = computed(() => ({
      ...inputPositionStyle.value,
      ...inputFontStyle.value
    }));
    const titleEditorStore = useTitleEditorStore();
    const canvasStore = useCanvasStore();
    const previousCanvasDraggable = ref(true);
    const onEdit = /* @__PURE__ */ __name((newValue) => {
      if (titleEditorStore.titleEditorTarget && newValue?.trim()) {
        const trimmedTitle = newValue.trim();
        titleEditorStore.titleEditorTarget.title = trimmedTitle;
        const target = titleEditorStore.titleEditorTarget;
        if (target instanceof LGraphNode && target.isSubgraphNode?.()) {
          target.subgraph.name = trimmedTitle;
        }
        app.canvas.setDirty(true, true);
      }
      showInput.value = false;
      titleEditorStore.titleEditorTarget = null;
      canvasStore.canvas.allow_dragcanvas = previousCanvasDraggable.value;
    }, "onEdit");
    watch(
      () => titleEditorStore.titleEditorTarget,
      (target) => {
        if (target === null) {
          return;
        }
        editedTitle.value = target.title;
        showInput.value = true;
        const canvas = canvasStore.canvas;
        previousCanvasDraggable.value = canvas.allow_dragcanvas;
        canvas.allow_dragcanvas = false;
        const scale = canvas.ds.scale;
        if (target instanceof LGraphGroup) {
          const group = target;
          updatePosition({
            pos: group.pos,
            size: [group.size[0], group.titleHeight]
          });
          inputFontStyle.value = { fontSize: `${group.font_size * scale}px` };
        } else if (target instanceof LGraphNode) {
          const node = target;
          const [x, y] = node.getBounding();
          updatePosition({
            pos: [x, y],
            size: [node.width, LiteGraph.NODE_TITLE_HEIGHT]
          });
          inputFontStyle.value = { fontSize: `${12 * scale}px` };
        }
      }
    );
    const canvasEventHandler = /* @__PURE__ */ __name((event) => {
      if (event.detail.subType === "group-double-click") {
        if (!settingStore.get("Comfy.Group.DoubleClickTitleToEdit")) {
          return;
        }
        const group = event.detail.group;
        const [_, y] = group.pos;
        const e = event.detail.originalEvent;
        const relativeY = e.canvasY - y;
        if (relativeY <= group.titleHeight) {
          titleEditorStore.titleEditorTarget = group;
        }
      } else if (event.detail.subType === "node-double-click") {
        if (!settingStore.get("Comfy.Node.DoubleClickTitleToEdit")) {
          return;
        }
        const node = event.detail.node;
        const [_, y] = node.pos;
        const e = event.detail.originalEvent;
        const relativeY = e.canvasY - y;
        if (relativeY <= 0) {
          titleEditorStore.titleEditorTarget = node;
        }
      }
    }, "canvasEventHandler");
    useEventListener(document, "litegraph:canvas", canvasEventHandler);
    return (_ctx, _cache) => {
      return showInput.value ? (openBlock(), createElementBlock("div", {
        key: 0,
        class: "group-title-editor node-title-editor",
        style: normalizeStyle(inputStyle.value)
      }, [
        createVNode(EditableText, {
          "is-editing": showInput.value,
          "model-value": editedTitle.value,
          onEdit
        }, null, 8, ["is-editing", "model-value"])
      ], 4)) : createCommentVNode("", true);
    };
  }
});
const TitleEditor = /* @__PURE__ */ _export_sfc(_sfc_main$S, [["__scopeId", "data-v-aceb018c"]]);
const _hoisted_1$F = {
  key: 0,
  class: "p-3"
};
const _sfc_main$R = /* @__PURE__ */ defineComponent({
  __name: "TabInfo",
  props: {
    nodes: {}
  },
  setup(__props) {
    const node = computed(() => __props.nodes[0]);
    const nodeDefStore = useNodeDefStore();
    const nodeHelpStore = useNodeHelpStore();
    const nodeInfo = computed(() => {
      return nodeDefStore.fromLGraphNode(node.value);
    });
    whenever(
      nodeInfo,
      (info) => {
        nodeHelpStore.openHelp(info);
      },
      { immediate: true }
    );
    return (_ctx, _cache) => {
      return nodeInfo.value ? (openBlock(), createElementBlock("div", _hoisted_1$F, [
        createVNode(NodeHelpContent, { node: nodeInfo.value }, null, 8, ["node"])
      ])) : createCommentVNode("", true);
    };
  }
});
const _hoisted_1$E = ["placeholder"];
const _sfc_main$Q = /* @__PURE__ */ defineComponent({
  __name: "SidePanelSearch",
  props: /* @__PURE__ */ mergeModels({
    searcher: { type: Function, default: /* @__PURE__ */ __name(async () => {
    }, "default") },
    updateKey: {}
  }, {
    "modelValue": { default: "" },
    "modelModifiers": {}
  }),
  emits: ["update:modelValue"],
  setup(__props) {
    const searchQuery = useModel(__props, "modelValue");
    const isQuerying = ref(false);
    const debouncedSearchQuery = refDebounced(searchQuery, 100, {
      maxWait: 100
    });
    watch(searchQuery, (value) => {
      isQuerying.value = value !== debouncedSearchQuery.value;
    });
    const updateKeyRef = toRef(() => toValue(__props.updateKey));
    watch(
      [debouncedSearchQuery, updateKeyRef],
      (_, __, onCleanup) => {
        let isCleanup = false;
        let cleanupFn;
        onCleanup(() => {
          isCleanup = true;
          cleanupFn?.();
        });
        void __props.searcher(debouncedSearchQuery.value, (cb) => cleanupFn = cb).catch((error) => {
          console.error("[SidePanelSearch] searcher failed", error);
        }).finally(() => {
          if (!isCleanup) isQuerying.value = false;
        });
      },
      { immediate: true }
    );
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("label", {
        class: normalizeClass(
          unref(cn)(
            "mt-1 py-1.5 bg-secondary-background rounded-lg transition-all duration-150",
            "flex-1 flex gap-2 px-2 items-center",
            "text-base-foreground border-0",
            "focus-within:ring focus-within:ring-component-node-widget-background-highlighted/80"
          )
        )
      }, [
        createBaseVNode("i", {
          class: normalizeClass(
            unref(cn)(
              "size-4 text-muted-foreground",
              isQuerying.value ? "icon-[lucide--loader-circle] animate-spin" : "icon-[lucide--search]"
            )
          )
        }, null, 2),
        withDirectives(createBaseVNode("input", {
          "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => searchQuery.value = $event),
          type: "text",
          class: "bg-transparent border-0 outline-0 ring-0 h-5",
          placeholder: _ctx.$t("g.searchPlaceholder")
        }, null, 8, _hoisted_1$E), [
          [vModelText, searchQuery.value]
        ])
      ], 2);
    };
  }
});
const CONTROL_OPTIONS = [
  "fixed",
  "increment",
  "decrement",
  "randomize"
];
function isControlOption(val) {
  return CONTROL_OPTIONS.includes(val);
}
__name(isControlOption, "isControlOption");
function normalizeControlOption(val) {
  if (isControlOption(val)) return val;
  return "randomize";
}
__name(normalizeControlOption, "normalizeControlOption");
function widgetWithVueTrack(widget) {
  if (widget.vueTrack) return;
  customRef((track, trigger) => {
    widget.callback = useChainCallback(widget.callback, trigger);
    widget.vueTrack = track;
    return { get() {
    }, set() {
    } };
  });
}
__name(widgetWithVueTrack, "widgetWithVueTrack");
function useReactiveWidgetValue(widget) {
  widgetWithVueTrack(widget);
  widget.vueTrack();
  return widget.value;
}
__name(useReactiveWidgetValue, "useReactiveWidgetValue");
function getControlWidget(widget) {
  const cagWidget = widget.linkedWidgets?.find(
    (w) => w.name == "control_after_generate"
  );
  if (!cagWidget) return;
  return {
    value: normalizeControlOption(cagWidget.value),
    update: /* @__PURE__ */ __name((value) => cagWidget.value = normalizeControlOption(value), "update")
  };
}
__name(getControlWidget, "getControlWidget");
function getNodeType(node, widget) {
  if (!node.isSubgraphNode() || !isProxyWidget(widget)) return void 0;
  const subNode = node.subgraph.getNodeById(widget._overlay.nodeId);
  return subNode?.type;
}
__name(getNodeType, "getNodeType");
const normalizeWidgetValue = /* @__PURE__ */ __name((value) => {
  if (value === null || value === void 0 || value === void 0) {
    return void 0;
  }
  if (typeof value === "string" || typeof value === "number" || typeof value === "boolean") {
    return value;
  }
  if (typeof value === "object") {
    if (Array.isArray(value) && value.length > 0 && value.every((item) => item instanceof File)) {
      return value;
    }
    return value;
  }
  console.warn(`Invalid widget value type: ${typeof value}`, value);
  return void 0;
}, "normalizeWidgetValue");
function safeWidgetMapper(node, slotMetadata) {
  const nodeDefStore = useNodeDefStore();
  return function(widget) {
    try {
      const spec = nodeDefStore.getInputSpecForWidget(node, widget.name);
      const slotInfo = slotMetadata.get(widget.name);
      const borderStyle = widget.promoted ? "ring ring-component-node-widget-promoted" : widget.advanced ? "ring ring-component-node-widget-advanced" : void 0;
      const callback = /* @__PURE__ */ __name((v) => {
        const value = normalizeWidgetValue(v);
        widget.value = value ?? void 0;
        widget.callback?.(value);
      }, "callback");
      return {
        name: widget.name,
        type: widget.type,
        value: useReactiveWidgetValue(widget),
        borderStyle,
        callback,
        controlWidget: getControlWidget(widget),
        isDOMWidget: isDOMWidget(widget),
        label: widget.label,
        nodeType: getNodeType(node, widget),
        options: widget.options,
        spec,
        slotMetadata: slotInfo
      };
    } catch (error) {
      return {
        name: widget.name || "unknown",
        type: widget.type || "text",
        value: void 0
      };
    }
  };
}
__name(safeWidgetMapper, "safeWidgetMapper");
function isValidWidgetValue(value) {
  return value === null || value === void 0 || typeof value === "string" || typeof value === "number" || typeof value === "boolean" || typeof value === "object";
}
__name(isValidWidgetValue, "isValidWidgetValue");
function useGraphNodeManager(graph) {
  const { createNode, deleteNode, setSource } = useLayoutMutations();
  const vueNodeData = reactive(/* @__PURE__ */ new Map());
  const nodeRefs = /* @__PURE__ */ new Map();
  const refreshNodeSlots = /* @__PURE__ */ __name((nodeId) => {
    const nodeRef = nodeRefs.get(nodeId);
    const currentData = vueNodeData.get(nodeId);
    if (!nodeRef || !currentData) return;
    const slotMetadata = /* @__PURE__ */ new Map();
    nodeRef.inputs?.forEach((input, index) => {
      if (!input?.widget?.name) return;
      slotMetadata.set(input.widget.name, {
        index,
        linked: input.link != null
      });
    });
    const updatedWidgets = currentData.widgets?.map((widget) => {
      const slotInfo = slotMetadata.get(widget.name);
      return slotInfo ? { ...widget, slotMetadata: slotInfo } : widget;
    });
    vueNodeData.set(nodeId, {
      ...currentData,
      widgets: updatedWidgets,
      inputs: nodeRef.inputs ? [...nodeRef.inputs] : void 0,
      outputs: nodeRef.outputs ? [...nodeRef.outputs] : void 0
    });
  }, "refreshNodeSlots");
  function extractVueNodeData(node) {
    const subgraphId = node.graph && "id" in node.graph && node.graph !== node.graph.rootGraph ? String(node.graph.id) : null;
    const slotMetadata = /* @__PURE__ */ new Map();
    const reactiveWidgets = shallowReactive(node.widgets ?? []);
    Object.defineProperty(node, "widgets", {
      get() {
        return reactiveWidgets;
      },
      set(v) {
        reactiveWidgets.splice(0, reactiveWidgets.length, ...v);
      }
    });
    const reactiveInputs = shallowReactive(node.inputs ?? []);
    Object.defineProperty(node, "inputs", {
      get() {
        return reactiveInputs;
      },
      set(v) {
        reactiveInputs.splice(0, reactiveInputs.length, ...v);
      }
    });
    const safeWidgets = reactiveComputed(() => {
      node.inputs?.forEach((input, index) => {
        if (!input?.widget?.name) return;
        slotMetadata.set(input.widget.name, {
          index,
          linked: input.link != null
        });
      });
      return node.widgets?.map(safeWidgetMapper(node, slotMetadata)) ?? [];
    });
    const nodeType = node.type || node.constructor?.comfyClass || node.constructor?.title || node.constructor?.name || "Unknown";
    const apiNode = node.constructor?.nodeData?.api_node ?? false;
    const badges = node.badges;
    return {
      id: String(node.id),
      title: typeof node.title === "string" ? node.title : "",
      type: nodeType,
      mode: node.mode || 0,
      titleMode: node.title_mode,
      selected: node.selected || false,
      executing: false,
      // Will be updated separately based on execution state
      subgraphId,
      apiNode,
      badges,
      hasErrors: !!node.has_errors,
      widgets: safeWidgets,
      inputs: reactiveInputs,
      outputs: node.outputs ? [...node.outputs] : void 0,
      flags: node.flags ? { ...node.flags } : void 0,
      color: node.color || void 0,
      bgcolor: node.bgcolor || void 0,
      shape: node.shape
    };
  }
  __name(extractVueNodeData, "extractVueNodeData");
  const getNode = /* @__PURE__ */ __name((id) => {
    return nodeRefs.get(id);
  }, "getNode");
  const syncWithGraph = /* @__PURE__ */ __name(() => {
    if (!graph?._nodes) return;
    const currentNodes = new Set(graph._nodes.map((n) => String(n.id)));
    for (const id of Array.from(vueNodeData.keys())) {
      if (!currentNodes.has(id)) {
        nodeRefs.delete(id);
        vueNodeData.delete(id);
      }
    }
    graph._nodes.forEach((node) => {
      const id = String(node.id);
      nodeRefs.set(id, node);
      vueNodeData.set(id, extractVueNodeData(node));
    });
  }, "syncWithGraph");
  const handleNodeAdded = /* @__PURE__ */ __name((node, originalCallback) => {
    const id = String(node.id);
    nodeRefs.set(id, node);
    vueNodeData.set(id, extractVueNodeData(node));
    const initializeVueNodeLayout = /* @__PURE__ */ __name(() => {
      const nodePosition = { x: node.pos[0], y: node.pos[1] };
      const nodeSize = { width: node.size[0], height: node.size[1] };
      setSource(LayoutSource.Canvas);
      void createNode(id, {
        position: nodePosition,
        size: nodeSize,
        zIndex: node.order || 0,
        visible: true
      });
    }, "initializeVueNodeLayout");
    if (window.app?.configuringGraph) {
      node.onAfterGraphConfigured = useChainCallback(
        node.onAfterGraphConfigured,
        () => {
          vueNodeData.set(id, extractVueNodeData(node));
          initializeVueNodeLayout();
        }
      );
    } else {
      initializeVueNodeLayout();
    }
    if (originalCallback) {
      void originalCallback(node);
    }
  }, "handleNodeAdded");
  const handleNodeRemoved = /* @__PURE__ */ __name((node, originalCallback) => {
    const id = String(node.id);
    setSource(LayoutSource.Canvas);
    void deleteNode(id);
    nodeRefs.delete(id);
    vueNodeData.delete(id);
    if (originalCallback) {
      originalCallback(node);
    }
  }, "handleNodeRemoved");
  const createCleanupFunction = /* @__PURE__ */ __name((originalOnNodeAdded, originalOnNodeRemoved, originalOnTrigger) => {
    return () => {
      graph.onNodeAdded = originalOnNodeAdded || void 0;
      graph.onNodeRemoved = originalOnNodeRemoved || void 0;
      graph.onTrigger = originalOnTrigger || void 0;
      nodeRefs.clear();
      vueNodeData.clear();
    };
  }, "createCleanupFunction");
  const setupEventListeners = /* @__PURE__ */ __name(() => {
    const originalOnNodeAdded = graph.onNodeAdded;
    const originalOnNodeRemoved = graph.onNodeRemoved;
    const originalOnTrigger = graph.onTrigger;
    graph.onNodeAdded = (node) => {
      handleNodeAdded(node, originalOnNodeAdded);
    };
    graph.onNodeRemoved = (node) => {
      handleNodeRemoved(node, originalOnNodeRemoved);
    };
    const triggerHandlers = {
      "node:property:changed": /* @__PURE__ */ __name((propertyEvent) => {
        const nodeId = String(propertyEvent.nodeId);
        const currentData = vueNodeData.get(nodeId);
        if (currentData) {
          switch (propertyEvent.property) {
            case "title":
              vueNodeData.set(nodeId, {
                ...currentData,
                title: String(propertyEvent.newValue)
              });
              break;
            case "flags.collapsed":
              vueNodeData.set(nodeId, {
                ...currentData,
                flags: {
                  ...currentData.flags,
                  collapsed: Boolean(propertyEvent.newValue)
                }
              });
              break;
            case "flags.pinned":
              vueNodeData.set(nodeId, {
                ...currentData,
                flags: {
                  ...currentData.flags,
                  pinned: Boolean(propertyEvent.newValue)
                }
              });
              break;
            case "mode":
              vueNodeData.set(nodeId, {
                ...currentData,
                mode: typeof propertyEvent.newValue === "number" ? propertyEvent.newValue : 0
              });
              break;
            case "color":
              vueNodeData.set(nodeId, {
                ...currentData,
                color: typeof propertyEvent.newValue === "string" ? propertyEvent.newValue : void 0
              });
              break;
            case "bgcolor":
              vueNodeData.set(nodeId, {
                ...currentData,
                bgcolor: typeof propertyEvent.newValue === "string" ? propertyEvent.newValue : void 0
              });
              break;
            case "shape":
              vueNodeData.set(nodeId, {
                ...currentData,
                shape: typeof propertyEvent.newValue === "number" ? propertyEvent.newValue : void 0
              });
          }
        }
      }, "node:property:changed"),
      "node:slot-errors:changed": /* @__PURE__ */ __name((slotErrorsEvent) => {
        refreshNodeSlots(String(slotErrorsEvent.nodeId));
      }, "node:slot-errors:changed"),
      "node:slot-links:changed": /* @__PURE__ */ __name((slotLinksEvent) => {
        if (slotLinksEvent.slotType === NodeSlotType.INPUT) {
          refreshNodeSlots(String(slotLinksEvent.nodeId));
        }
      }, "node:slot-links:changed")
    };
    graph.onTrigger = (event) => {
      switch (event.type) {
        case "node:property:changed":
          triggerHandlers["node:property:changed"](event);
          break;
        case "node:slot-errors:changed":
          triggerHandlers["node:slot-errors:changed"](event);
          break;
        case "node:slot-links:changed":
          triggerHandlers["node:slot-links:changed"](event);
          break;
      }
      originalOnTrigger?.(event);
    };
    syncWithGraph();
    return createCleanupFunction(
      originalOnNodeAdded || void 0,
      originalOnNodeRemoved || void 0,
      originalOnTrigger || void 0
    );
  }, "setupEventListeners");
  const cleanup = setupEventListeners();
  if (graph._nodes && graph._nodes.length > 0) {
    graph._nodes.forEach((node) => {
      if (graph.onNodeAdded) {
        graph.onNodeAdded(node);
      }
    });
  }
  return {
    vueNodeData,
    getNode,
    cleanup
  };
}
__name(useGraphNodeManager, "useGraphNodeManager");
const _hoisted_1$D = { class: "flex flex-col bg-interface-panel-surface" };
const _hoisted_2$u = { class: "sticky top-0 z-10 flex items-center justify-between backdrop-blur-xl bg-inherit" };
const _hoisted_3$o = ["disabled"];
const _hoisted_4$i = { class: "text-sm font-semibold line-clamp-2" };
const _hoisted_5$g = {
  key: 0,
  class: "pb-4"
};
const _sfc_main$P = /* @__PURE__ */ defineComponent({
  __name: "PropertiesAccordionItem",
  props: /* @__PURE__ */ mergeModels({
    isEmpty: { type: Boolean }
  }, {
    "collapse": { type: Boolean, ...{ default: false } },
    "collapseModifiers": {}
  }),
  emits: ["update:collapse"],
  setup(__props) {
    const isCollapse = useModel(__props, "collapse");
    return (_ctx, _cache) => {
      const _directive_tooltip = resolveDirective("tooltip");
      return openBlock(), createElementBlock("div", _hoisted_1$D, [
        createBaseVNode("div", _hoisted_2$u, [
          withDirectives((openBlock(), createElementBlock("button", {
            type: "button",
            class: normalizeClass(
              unref(cn)(
                "group min-h-12 bg-transparent border-0 outline-0 ring-0 w-full text-left flex items-center justify-between pl-4 pr-3",
                !_ctx.isEmpty && "cursor-pointer"
              )
            ),
            disabled: _ctx.isEmpty,
            onClick: _cache[0] || (_cache[0] = ($event) => isCollapse.value = !isCollapse.value)
          }, [
            createBaseVNode("span", _hoisted_4$i, [
              renderSlot(_ctx.$slots, "label")
            ]),
            !_ctx.isEmpty ? (openBlock(), createElementBlock("i", {
              key: 0,
              class: normalizeClass(
                unref(cn)(
                  "text-muted-foreground group-hover:text-base-foreground group-focus:text-base-foreground icon-[lucide--chevron-up] size-4 transition-all",
                  isCollapse.value && "-rotate-180"
                )
              )
            }, null, 2)) : createCommentVNode("", true)
          ], 10, _hoisted_3$o)), [
            [
              _directive_tooltip,
              _ctx.isEmpty ? {
                value: _ctx.$t("rightSidePanel.inputsNoneTooltip"),
                showDelay: 1e3
              } : void 0
            ]
          ])
        ]),
        !isCollapse.value && !_ctx.isEmpty ? (openBlock(), createElementBlock("div", _hoisted_5$g, [
          renderSlot(_ctx.$slots, "default")
        ])) : createCommentVNode("", true)
      ]);
    };
  }
});
const _hoisted_1$C = {
  key: 0,
  class: "space-y-4 rounded-lg bg-interface-surface px-4"
};
const _hoisted_2$t = { class: "min-h-8" };
const _hoisted_3$n = {
  key: 0,
  class: "text-sm leading-8 p-0 m-0 line-clamp-1"
};
const _sfc_main$O = /* @__PURE__ */ defineComponent({
  __name: "SectionWidgets",
  props: {
    label: {},
    widgets: {}
  },
  setup(__props) {
    provide("hideLayoutField", true);
    const canvasStore = useCanvasStore();
    const { t: t2 } = useI18n();
    function getWidgetComponent(widget) {
      const component = getComponent(widget.type, widget.name);
      return component || _sfc_main$21;
    }
    __name(getWidgetComponent, "getWidgetComponent");
    function onWidgetValueChange(widget, value) {
      widget.value = value;
      widget.callback?.(value);
      canvasStore.canvas?.setDirty(true, true);
    }
    __name(onWidgetValueChange, "onWidgetValueChange");
    const isEmpty = computed(() => __props.widgets.length === 0);
    const displayLabel = computed(
      () => __props.label ?? (isEmpty.value ? t2("rightSidePanel.inputsNone") : t2("rightSidePanel.inputs"))
    );
    return (_ctx, _cache) => {
      return openBlock(), createBlock(_sfc_main$P, { "is-empty": isEmpty.value }, {
        label: withCtx(() => [
          renderSlot(_ctx.$slots, "label", {}, () => [
            createTextVNode(toDisplayString(displayLabel.value), 1)
          ])
        ]),
        default: withCtx(() => [
          !isEmpty.value ? (openBlock(), createElementBlock("div", _hoisted_1$C, [
            (openBlock(true), createElementBlock(Fragment, null, renderList(_ctx.widgets, ({ widget, node }, index) => {
              return openBlock(), createElementBlock("div", {
                key: `widget-${index}-${widget.name}`,
                class: "widget-item gap-1.5 col-span-full grid grid-cols-subgrid"
              }, [
                createBaseVNode("div", _hoisted_2$t, [
                  widget.name ? (openBlock(), createElementBlock("p", _hoisted_3$n, toDisplayString(widget.label || widget.name), 1)) : createCommentVNode("", true)
                ]),
                (openBlock(), createBlock(resolveDynamicComponent(getWidgetComponent(widget)), {
                  widget,
                  "model-value": unref(useReactiveWidgetValue)(widget),
                  "node-id": String(node.id),
                  "node-type": node.type,
                  class: normalizeClass(unref(cn)("col-span-1", unref(shouldExpand)(widget.type) && "min-h-36")),
                  "onUpdate:modelValue": /* @__PURE__ */ __name((value) => onWidgetValueChange(widget, value), "onUpdate:modelValue")
                }, null, 8, ["widget", "model-value", "node-id", "node-type", "class", "onUpdate:modelValue"]))
              ]);
            }), 128))
          ])) : createCommentVNode("", true)
        ]),
        _: 3
      }, 8, ["is-empty"]);
    };
  }
});
const _hoisted_1$B = { class: "px-4 pb-4 flex gap-2 border-b border-interface-stroke" };
const _sfc_main$N = /* @__PURE__ */ defineComponent({
  __name: "TabParameters",
  props: {
    nodes: {}
  },
  setup(__props) {
    const widgetsSectionDataList = computed(() => {
      return __props.nodes.map((node) => {
        const { widgets = [] } = node;
        const shownWidgets = widgets.filter((w) => !(w.options?.canvasOnly || w.options?.hidden)).map((widget) => ({ node, widget }));
        return {
          widgets: shownWidgets,
          node
        };
      });
    });
    const searchedWidgetsSectionDataList = shallowRef([]);
    async function searcher(query) {
      if (query.trim() === "") {
        searchedWidgetsSectionDataList.value = widgetsSectionDataList.value;
        return;
      }
      const words = query.trim().toLowerCase().split(" ");
      searchedWidgetsSectionDataList.value = widgetsSectionDataList.value.map((item) => {
        return {
          ...item,
          widgets: item.widgets.filter(({ widget }) => {
            const label = widget.label?.toLowerCase();
            const name = widget.name.toLowerCase();
            const type = widget.type.toLowerCase();
            const value = widget.value?.toString().toLowerCase();
            return words.every(
              (word) => name.includes(word) || label?.includes(word) || type?.includes(word) || value?.includes(word)
            );
          })
        };
      }).filter((item) => item.widgets.length > 0);
    }
    __name(searcher, "searcher");
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createBaseVNode("div", _hoisted_1$B, [
          createVNode(_sfc_main$Q, {
            searcher,
            "update-key": widgetsSectionDataList.value
          }, null, 8, ["update-key"])
        ]),
        (openBlock(true), createElementBlock(Fragment, null, renderList(searchedWidgetsSectionDataList.value, (section) => {
          return openBlock(), createBlock(_sfc_main$O, {
            key: section.node.id,
            label: widgetsSectionDataList.value.length > 1 ? section.node.title : void 0,
            widgets: section.widgets,
            "default-collapse": widgetsSectionDataList.value.length > 1 && widgetsSectionDataList.value === searchedWidgetsSectionDataList.value,
            class: "border-b border-interface-stroke"
          }, null, 8, ["label", "widgets", "default-collapse"]);
        }), 128))
      ], 64);
    };
  }
});
const _hoisted_1$A = ["disabled", "onClick"];
const _sfc_main$M = /* @__PURE__ */ defineComponent({
  __name: "FormSelectButton",
  props: {
    modelValue: {},
    options: {},
    optionLabel: { default: "label" },
    optionValue: { default: "value" },
    disabled: { type: Boolean, default: false }
  },
  emits: ["update:modelValue"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const getOptionValue = /* @__PURE__ */ __name((option, index) => {
      if (typeof option !== "object") {
        return option;
      }
      const valueField = props.optionValue;
      const value = option[valueField] ?? option.value ?? option.name ?? option.label ?? index;
      return value;
    }, "getOptionValue");
    const getOptionLabel = /* @__PURE__ */ __name((option) => {
      if (typeof option === "object" && option !== null) {
        const labelField = props.optionLabel;
        return option[labelField] ?? option.label ?? option.name ?? option.value ?? String(option);
      }
      return String(option);
    }, "getOptionLabel");
    const isSelected = /* @__PURE__ */ __name((index) => {
      const optionValue = getOptionValue(props.options[index], index);
      return String(optionValue) === String(props.modelValue ?? "");
    }, "isSelected");
    const handleSelect = /* @__PURE__ */ __name((index) => {
      if (props.disabled) return;
      const optionValue = getOptionValue(props.options[index], index);
      emit("update:modelValue", optionValue);
    }, "handleSelect");
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: normalizeClass(
          unref(cn)(
            unref(WidgetInputBaseClass),
            "p-1 inline-flex justify-center items-center gap-1"
          )
        )
      }, [
        (openBlock(true), createElementBlock(Fragment, null, renderList(_ctx.options, (option, index) => {
          return openBlock(), createElementBlock("button", {
            key: getOptionValue(option, index),
            class: normalizeClass(
              unref(cn)(
                "flex-1 h-6 px-5 py-[5px] rounded flex justify-center items-center gap-1 transition-all duration-150 ease-in-out truncate min-w-[4ch]",
                "bg-transparent border-none",
                "text-center text-xs font-normal",
                {
                  "bg-interface-menu-component-surface-selected": isSelected(index) && !_ctx.disabled,
                  "hover:bg-interface-menu-component-surface-selected/50": !isSelected(index) && !_ctx.disabled,
                  "opacity-50 cursor-not-allowed": _ctx.disabled,
                  "cursor-pointer": !_ctx.disabled
                },
                isSelected(index) && !_ctx.disabled ? "text-text-primary" : "text-text-secondary"
              )
            ),
            disabled: _ctx.disabled,
            onClick: /* @__PURE__ */ __name(($event) => handleSelect(index), "onClick")
          }, toDisplayString(getOptionLabel(option)), 11, _hoisted_1$A);
        }), 128))
      ], 2);
    };
  }
});
const _hoisted_1$z = { class: "space-y-4 p-3 text-sm text-muted-foreground" };
const _hoisted_2$s = { class: "flex flex-col gap-2" };
const _hoisted_3$m = { class: "flex flex-col gap-2" };
const _hoisted_4$h = { class: "bg-secondary-background border-none rounded-lg p-1 grid grid-cols-5 gap-1 justify-items-center" };
const _hoisted_5$f = ["onClick"];
const _hoisted_6$e = ["data-testid"];
const _hoisted_7$b = { class: "flex items-center justify-between" };
const _sfc_main$L = /* @__PURE__ */ defineComponent({
  __name: "TabSettings",
  props: {
    nodes: {}
  },
  setup(__props) {
    const props = __props;
    const targetNodes = shallowRef([]);
    watchEffect(() => {
      if (props.nodes) {
        targetNodes.value = props.nodes;
      } else {
        targetNodes.value = [];
      }
    });
    const { t: t2 } = useI18n();
    const canvasStore = useCanvasStore();
    const colorPaletteStore = useColorPaletteStore();
    const isLightTheme = computed(
      () => colorPaletteStore.completedActivePalette.light_theme
    );
    const nodeState = computed({
      get() {
        let mode = null;
        const nodes = targetNodes.value;
        if (nodes.length === 0) return null;
        if (nodes.length > 1) {
          mode = nodes[0].mode;
          if (!nodes.every((node) => node.mode === mode)) {
            mode = null;
          }
        } else {
          mode = nodes[0].mode;
        }
        return mode;
      },
      set(value) {
        targetNodes.value.forEach((node) => {
          node.mode = value;
        });
        triggerRef(targetNodes);
        canvasStore.canvas?.setDirty(true, true);
      }
    });
    const isPinned = computed({
      get() {
        return targetNodes.value.some((node) => node.pinned);
      },
      set(value) {
        targetNodes.value.forEach((node) => node.pin(value));
        triggerRef(targetNodes);
        canvasStore.canvas?.setDirty(true, true);
      }
    });
    function getColorValue(color) {
      return {
        dark: adjustColor(color, { lightness: 0.3 }),
        light: adjustColor(color, { lightness: 0.4 }),
        ringDark: adjustColor(color, { lightness: 0.5 }),
        ringLight: adjustColor(color, { lightness: 0.1 })
      };
    }
    __name(getColorValue, "getColorValue");
    const NO_COLOR_OPTION = {
      name: "noColor",
      localizedName: /* @__PURE__ */ __name(() => t2("color.noColor"), "localizedName"),
      value: getColorValue(LiteGraph.NODE_DEFAULT_BGCOLOR)
    };
    const nodeColorEntries = Object.entries(LGraphCanvas.node_colors);
    const colorOptions = [
      NO_COLOR_OPTION,
      ...nodeColorEntries.map(([name, color]) => ({
        name,
        localizedName: /* @__PURE__ */ __name(() => t2(`color.${name}`), "localizedName"),
        value: getColorValue(color.bgcolor)
      }))
    ];
    const nodeColor = computed({
      get() {
        if (targetNodes.value.length === 0) return null;
        const theColorOptions = targetNodes.value.map(
          (item) => item.getColorOption()
        );
        let colorOption = theColorOptions[0];
        if (!theColorOptions.every((option) => option === colorOption)) {
          colorOption = false;
        }
        if (colorOption === false) return null;
        if (colorOption == null || !colorOption.bgcolor && !colorOption.color)
          return NO_COLOR_OPTION.name;
        return nodeColorEntries.find(
          ([_, color]) => color.bgcolor === colorOption.bgcolor && color.color === colorOption.color
        )?.[0] ?? null;
      },
      set(colorName) {
        if (colorName === null) return;
        const canvasColorOption = colorName === NO_COLOR_OPTION.name ? null : LGraphCanvas.node_colors[colorName];
        for (const item of targetNodes.value) {
          item.setColorOption(canvasColorOption);
        }
        triggerRef(targetNodes);
        canvasStore.canvas?.setDirty(true, true);
      }
    });
    return (_ctx, _cache) => {
      const _directive_tooltip = resolveDirective("tooltip");
      return openBlock(), createElementBlock("div", _hoisted_1$z, [
        createBaseVNode("div", _hoisted_2$s, [
          createBaseVNode("span", null, toDisplayString(unref(t2)("rightSidePanel.nodeState")), 1),
          createVNode(_sfc_main$M, {
            modelValue: nodeState.value,
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => nodeState.value = $event),
            class: "w-full",
            options: [
              {
                label: unref(t2)("rightSidePanel.normal"),
                value: unref(LGraphEventMode).ALWAYS
              },
              {
                label: unref(t2)("rightSidePanel.bypass"),
                value: unref(LGraphEventMode).BYPASS
              },
              {
                label: unref(t2)("rightSidePanel.mute"),
                value: unref(LGraphEventMode).NEVER
              }
            ]
          }, null, 8, ["modelValue", "options"])
        ]),
        createBaseVNode("div", _hoisted_3$m, [
          createBaseVNode("span", null, toDisplayString(unref(t2)("rightSidePanel.color")), 1),
          createBaseVNode("div", _hoisted_4$h, [
            (openBlock(), createElementBlock(Fragment, null, renderList(colorOptions, (option) => {
              return createBaseVNode("button", {
                key: option.name,
                class: normalizeClass(
                  unref(cn)(
                    "size-8 rounded-lg bg-transparent border-0 outline-0 ring-0 text-left flex justify-center items-center cursor-pointer",
                    option.name === nodeColor.value ? "bg-interface-menu-component-surface-selected" : "hover:bg-interface-menu-component-surface-selected"
                  )
                ),
                onClick: /* @__PURE__ */ __name(($event) => nodeColor.value = option.name, "onClick")
              }, [
                withDirectives(createBaseVNode("div", {
                  class: normalizeClass(unref(cn)("size-4 rounded-full ring-2 ring-gray-500/10")),
                  style: normalizeStyle({
                    backgroundColor: isLightTheme.value ? option.value.light : option.value.dark,
                    "--tw-ring-color": option.name === nodeColor.value ? isLightTheme.value ? option.value.ringLight : option.value.ringDark : void 0
                  }),
                  "data-testid": option.name
                }, null, 14, _hoisted_6$e), [
                  [
                    _directive_tooltip,
                    option.localizedName(),
                    void 0,
                    { top: true }
                  ]
                ])
              ], 10, _hoisted_5$f);
            }), 64))
          ])
        ]),
        createBaseVNode("div", _hoisted_7$b, [
          createBaseVNode("span", null, toDisplayString(unref(t2)("rightSidePanel.pinned")), 1),
          createVNode(unref(script$j), {
            modelValue: isPinned.value,
            "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => isPinned.value = $event)
          }, null, 8, ["modelValue"])
        ])
      ]);
    };
  }
});
const _hoisted_1$y = { class: "pointer-events-none flex-1" };
const _hoisted_2$r = { class: "text-xs text-text-secondary line-clamp-1" };
const _hoisted_3$l = { class: "text-sm line-clamp-1 leading-8" };
const _hoisted_4$g = {
  key: 0,
  class: "size-4 pointer-events-none icon-[lucide--grip-vertical]"
};
const _sfc_main$K = /* @__PURE__ */ defineComponent({
  __name: "SubgraphNodeWidget",
  props: {
    nodeTitle: {},
    widgetName: {},
    isDraggable: { type: Boolean },
    isPhysical: { type: Boolean },
    class: { type: [Array, Object, String, Number, null, Boolean] }
  },
  emits: ["toggleVisibility"],
  setup(__props) {
    const props = __props;
    function getIcon() {
      return props.isPhysical ? "icon-[lucide--link]" : props.isDraggable ? "icon-[lucide--eye]" : "icon-[lucide--eye-off]";
    }
    __name(getIcon, "getIcon");
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: normalizeClass(
          unref(cn)(
            "flex py-1 px-2 break-all rounded items-center gap-1",
            "bg-node-component-surface",
            props.isDraggable && "draggable-item drag-handle cursor-grab [&.is-draggable]:cursor-grabbing hover:ring-1 ring-accent-background",
            props.class
          )
        )
      }, [
        createBaseVNode("div", _hoisted_1$y, [
          createBaseVNode("div", _hoisted_2$r, toDisplayString(_ctx.nodeTitle), 1),
          createBaseVNode("div", _hoisted_3$l, toDisplayString(_ctx.widgetName), 1)
        ]),
        createVNode(_sfc_main$1Y, {
          variant: "muted-textonly",
          size: "sm",
          disabled: _ctx.isPhysical,
          onClick: _cache[0] || (_cache[0] = withModifiers(($event) => _ctx.$emit("toggleVisibility"), ["stop"]))
        }, {
          default: withCtx(() => [
            createBaseVNode("i", {
              class: normalizeClass(getIcon())
            }, null, 2)
          ]),
          _: 1
        }, 8, ["disabled"]),
        _ctx.isDraggable ? (openBlock(), createElementBlock("div", _hoisted_4$g)) : createCommentVNode("", true)
      ], 2);
    };
  }
});
const _hoisted_1$x = {
  key: 0,
  class: "subgraph-edit-section flex h-full flex-col"
};
const _hoisted_2$q = { class: "p-4 flex gap-2" };
const _hoisted_3$k = { class: "flex-1" };
const _hoisted_4$f = {
  key: 0,
  class: "flex flex-col border-t border-interface-stroke"
};
const _hoisted_5$e = { class: "sticky top-0 z-10 flex items-center justify-between backdrop-blur-xl min-h-12 px-4" };
const _hoisted_6$d = { class: "text-sm font-semibold uppercase line-clamp-1" };
const _hoisted_7$a = {
  key: 1,
  class: "flex flex-col border-t border-interface-stroke"
};
const _hoisted_8$9 = { class: "sticky top-0 z-10 flex items-center justify-between backdrop-blur-xl min-h-12 px-4" };
const _hoisted_9$7 = { class: "text-sm font-semibold uppercase line-clamp-1" };
const _hoisted_10$7 = { class: "pb-2 px-2 space-y-0.5 mt-0.5" };
const _hoisted_11$5 = {
  key: 2,
  class: "flex justify-center border-t border-interface-stroke py-4"
};
const _sfc_main$J = /* @__PURE__ */ defineComponent({
  __name: "SubgraphEditor",
  setup(__props) {
    const canvasStore = useCanvasStore();
    const draggableList = ref(void 0);
    const draggableItems = ref();
    const searchQuery = ref("");
    const proxyWidgets = customRef((track, trigger) => ({
      get() {
        track();
        const node = activeNode.value;
        if (!node) return [];
        return parseProxyWidgets(node.properties.proxyWidgets);
      },
      set(value) {
        trigger();
        const node = activeNode.value;
        if (!value) return;
        if (!node) {
          console.error("Attempted to toggle widgets with no node selected");
          return;
        }
        node.properties.proxyWidgets = value;
      }
    }));
    async function searcher(query) {
      searchQuery.value = query;
    }
    __name(searcher, "searcher");
    const activeNode = computed(() => {
      const node = canvasStore.selectedItems[0];
      if (node instanceof SubgraphNode) return node;
      return void 0;
    });
    const activeWidgets = computed({
      get() {
        if (!activeNode.value) return [];
        const node = activeNode.value;
        function mapWidgets([id, name]) {
          if (id === "-1") {
            const widget2 = node.widgets.find((w) => w.name === name);
            if (!widget2) return [];
            return [[{ id: -1, title: "(Linked)", type: "" }, widget2]];
          }
          const wNode = node.subgraph._nodes_by_id[id];
          if (!wNode?.widgets) return [];
          const widget = wNode.widgets.find((w) => w.name === name);
          if (!widget) return [];
          return [[wNode, widget]];
        }
        __name(mapWidgets, "mapWidgets");
        return proxyWidgets.value.flatMap(mapWidgets);
      },
      set(value) {
        const node = activeNode.value;
        if (!node) {
          console.error("Attempted to toggle widgets with no node selected");
          return;
        }
        proxyWidgets.value = value.map(widgetItemToProperty);
      }
    });
    const interiorWidgets = computed(() => {
      const node = activeNode.value;
      if (!node) return [];
      const { updatePreviews } = useLitegraphService();
      const interiorNodes = node.subgraph.nodes;
      for (const node2 of interiorNodes) {
        node2.updateComputedDisabled();
        updatePreviews(node2);
      }
      return interiorNodes.flatMap(nodeWidgets).filter(([_, w]) => !w.computedDisabled);
    });
    const candidateWidgets = computed(() => {
      const node = activeNode.value;
      if (!node) return [];
      const widgets = proxyWidgets.value;
      return interiorWidgets.value.filter(
        (widgetItem) => !widgets.some(matchesPropertyItem(widgetItem))
      );
    });
    const filteredCandidates = computed(() => {
      const query = searchQuery.value.toLowerCase();
      if (!query) return candidateWidgets.value;
      return candidateWidgets.value.filter(
        ([n, w]) => n.title.toLowerCase().includes(query) || w.name.toLowerCase().includes(query)
      );
    });
    const recommendedWidgets = computed(() => {
      const node = activeNode.value;
      if (!node) return [];
      return filteredCandidates.value.filter(isRecommendedWidget);
    });
    const filteredActive = computed(() => {
      const query = searchQuery.value.toLowerCase();
      if (!query) return activeWidgets.value;
      return activeWidgets.value.filter(
        ([n, w]) => n.title.toLowerCase().includes(query) || w.name.toLowerCase().includes(query)
      );
    });
    function toKey(item) {
      return `${item[0].id}: ${item[1].name}`;
    }
    __name(toKey, "toKey");
    function nodeWidgets(n) {
      if (!n.widgets) return [];
      return n.widgets.map((w) => [n, w]);
    }
    __name(nodeWidgets, "nodeWidgets");
    function demote([node, widget]) {
      const subgraphNode = activeNode.value;
      if (!subgraphNode) return [];
      demoteWidget(node, widget, [subgraphNode]);
      triggerRef(proxyWidgets);
    }
    __name(demote, "demote");
    function promote([node, widget]) {
      const subgraphNode = activeNode.value;
      if (!subgraphNode) return [];
      promoteWidget(node, widget, [subgraphNode]);
      triggerRef(proxyWidgets);
    }
    __name(promote, "promote");
    function showAll() {
      const node = activeNode.value;
      if (!node) return;
      const widgets = proxyWidgets.value;
      const toAdd = filteredCandidates.value.map(widgetItemToProperty);
      widgets.push(...toAdd);
      proxyWidgets.value = widgets;
    }
    __name(showAll, "showAll");
    function hideAll() {
      const node = activeNode.value;
      if (!node) return;
      proxyWidgets.value = proxyWidgets.value.filter(
        (propertyItem) => !filteredActive.value.some(matchesWidgetItem(propertyItem)) || propertyItem[0] === "-1"
      );
    }
    __name(hideAll, "hideAll");
    function showRecommended() {
      const node = activeNode.value;
      if (!node) return;
      const widgets = proxyWidgets.value;
      const toAdd = recommendedWidgets.value.map(widgetItemToProperty);
      widgets.push(...toAdd);
      proxyWidgets.value = widgets;
    }
    __name(showRecommended, "showRecommended");
    function setDraggableState() {
      draggableList.value?.dispose();
      if (searchQuery.value || !draggableItems.value?.children?.length) return;
      draggableList.value = new DraggableList(
        draggableItems.value,
        ".draggable-item"
      );
      draggableList.value.applyNewItemsOrder = function() {
        const reorderedItems = [];
        let oldPosition = -1;
        this.getAllItems().forEach((item, index) => {
          if (item === this.draggableItem) {
            oldPosition = index;
            return;
          }
          if (!this.isItemToggled(item)) {
            reorderedItems[index] = item;
            return;
          }
          const newIndex = this.isItemAbove(item) ? index + 1 : index - 1;
          reorderedItems[newIndex] = item;
        });
        for (let index = 0; index < this.getAllItems().length; index++) {
          const item = reorderedItems[index];
          if (typeof item === "undefined") {
            reorderedItems[index] = this.draggableItem;
          }
        }
        const newPosition = reorderedItems.indexOf(this.draggableItem);
        const aw = activeWidgets.value;
        const [w] = aw.splice(oldPosition, 1);
        aw.splice(newPosition, 0, w);
        activeWidgets.value = aw;
      };
    }
    __name(setDraggableState, "setDraggableState");
    watchDebounced(
      filteredActive,
      () => {
        setDraggableState();
      },
      { debounce: 100 }
    );
    onMounted(() => {
      setDraggableState();
      if (activeNode.value) pruneDisconnected(activeNode.value);
    });
    onBeforeUnmount(() => {
      draggableList.value?.dispose();
    });
    return (_ctx, _cache) => {
      return activeNode.value ? (openBlock(), createElementBlock("div", _hoisted_1$x, [
        createBaseVNode("div", _hoisted_2$q, [
          createVNode(_sfc_main$Q, { searcher })
        ]),
        createBaseVNode("div", _hoisted_3$k, [
          filteredActive.value.length ? (openBlock(), createElementBlock("div", _hoisted_4$f, [
            createBaseVNode("div", _hoisted_5$e, [
              createBaseVNode("div", _hoisted_6$d, toDisplayString(_ctx.$t("subgraphStore.shown")), 1),
              createBaseVNode("a", {
                class: "cursor-pointer text-right text-xs font-normal text-text-secondary hover:text-azure-600 whitespace-nowrap",
                onClick: withModifiers(hideAll, ["stop"])
              }, toDisplayString(_ctx.$t("subgraphStore.hideAll")), 1)
            ]),
            createBaseVNode("div", {
              ref_key: "draggableItems",
              ref: draggableItems,
              class: "pb-2 px-2 space-y-0.5 mt-0.5"
            }, [
              (openBlock(true), createElementBlock(Fragment, null, renderList(filteredActive.value, ([node, widget]) => {
                return openBlock(), createBlock(_sfc_main$K, {
                  key: toKey([node, widget]),
                  class: "bg-interface-panel-surface",
                  "node-title": node.title,
                  "widget-name": widget.name,
                  "is-shown": true,
                  "is-draggable": !searchQuery.value,
                  "is-physical": node.id === -1,
                  onToggleVisibility: /* @__PURE__ */ __name(($event) => demote([node, widget]), "onToggleVisibility")
                }, null, 8, ["node-title", "widget-name", "is-draggable", "is-physical", "onToggleVisibility"]);
              }), 128))
            ], 512)
          ])) : createCommentVNode("", true),
          filteredCandidates.value.length ? (openBlock(), createElementBlock("div", _hoisted_7$a, [
            createBaseVNode("div", _hoisted_8$9, [
              createBaseVNode("div", _hoisted_9$7, toDisplayString(_ctx.$t("subgraphStore.hidden")), 1),
              createBaseVNode("a", {
                class: "cursor-pointer text-right text-xs font-normal text-text-secondary hover:text-azure-600 whitespace-nowrap",
                onClick: withModifiers(showAll, ["stop"])
              }, toDisplayString(_ctx.$t("subgraphStore.showAll")), 1)
            ]),
            createBaseVNode("div", _hoisted_10$7, [
              (openBlock(true), createElementBlock(Fragment, null, renderList(filteredCandidates.value, ([node, widget]) => {
                return openBlock(), createBlock(_sfc_main$K, {
                  key: toKey([node, widget]),
                  class: "bg-interface-panel-surface",
                  "node-title": node.title,
                  "widget-name": widget.name,
                  onToggleVisibility: /* @__PURE__ */ __name(($event) => promote([node, widget]), "onToggleVisibility")
                }, null, 8, ["node-title", "widget-name", "onToggleVisibility"]);
              }), 128))
            ])
          ])) : createCommentVNode("", true),
          recommendedWidgets.value.length ? (openBlock(), createElementBlock("div", _hoisted_11$5, [
            createVNode(_sfc_main$1Y, {
              size: "sm",
              class: "rounded border-none px-3 py-0.5",
              onClick: withModifiers(showRecommended, ["stop"])
            }, {
              default: withCtx(() => [
                createTextVNode(toDisplayString(_ctx.$t("subgraphStore.showRecommended")), 1)
              ]),
              _: 1
            })
          ])) : createCommentVNode("", true)
        ])
      ])) : createCommentVNode("", true);
    };
  }
});
const _hoisted_1$w = {
  "data-testid": "properties-panel",
  class: "flex size-full flex-col bg-interface-panel-surface"
};
const _hoisted_2$p = { class: "pt-1" };
const _hoisted_3$j = { class: "flex items-center justify-between pl-4 pr-3" };
const _hoisted_4$e = { class: "my-3.5 text-sm font-semibold line-clamp-2" };
const _hoisted_5$d = { class: "flex gap-2" };
const _hoisted_6$c = {
  key: 0,
  class: "px-4 pb-2 pt-1"
};
const _hoisted_7$9 = { class: "scrollbar-thin flex-1 overflow-y-auto" };
const _hoisted_8$8 = {
  key: 0,
  class: "flex size-full p-4 items-start justify-start text-sm text-muted-foreground"
};
const _sfc_main$I = /* @__PURE__ */ defineComponent({
  __name: "RightSidePanel",
  setup(__props) {
    const canvasStore = useCanvasStore();
    const rightSidePanelStore = useRightSidePanelStore();
    const settingStore = useSettingStore();
    const { t: t2 } = useI18n();
    const { selectedItems } = storeToRefs(canvasStore);
    const { activeTab, isEditingSubgraph } = storeToRefs(rightSidePanelStore);
    const sidebarLocation = computed(
      () => settingStore.get("Comfy.Sidebar.Location")
    );
    const panelIcon = computed(
      () => sidebarLocation.value === "right" ? "icon-[lucide--panel-left]" : "icon-[lucide--panel-right]"
    );
    const hasSelection = computed(() => selectedItems.value.length > 0);
    const selectedNodes = computed(() => {
      return selectedItems.value.filter(isLGraphNode);
    });
    const isSubgraphNode = computed(() => {
      return selectedNode.value instanceof SubgraphNode;
    });
    const isSingleNodeSelected = computed(() => selectedNodes.value.length === 1);
    const selectedNode = computed(() => {
      return isSingleNodeSelected.value ? selectedNodes.value[0] : null;
    });
    const selectionCount = computed(() => selectedItems.value.length);
    const panelTitle = computed(() => {
      if (isSingleNodeSelected.value && selectedNode.value) {
        return selectedNode.value.title || selectedNode.value.type || "Node";
      }
      return t2("rightSidePanel.title", { count: selectionCount.value });
    });
    function closePanel() {
      rightSidePanelStore.closePanel();
    }
    __name(closePanel, "closePanel");
    const tabs = computed(() => {
      const list = [
        {
          label: /* @__PURE__ */ __name(() => t2("rightSidePanel.parameters"), "label"),
          value: "parameters"
        },
        {
          label: /* @__PURE__ */ __name(() => t2("g.settings"), "label"),
          value: "settings"
        }
      ];
      if (!hasSelection.value || isSingleNodeSelected.value && !isSubgraphNode.value) {
        list.push({
          label: /* @__PURE__ */ __name(() => t2("rightSidePanel.info"), "label"),
          value: "info"
        });
      }
      return list;
    });
    watchEffect(() => {
      if (!tabs.value.some((tab) => tab.value === activeTab.value) && !(activeTab.value === "subgraph" && isSubgraphNode.value)) {
        rightSidePanelStore.openPanel(tabs.value[0].value);
      }
    });
    const isEditing = ref(false);
    function handleTitleEdit(newTitle) {
      isEditing.value = false;
      const trimmedTitle = newTitle.trim();
      if (!trimmedTitle) return;
      const node = toValue(selectedNode);
      if (!node) return;
      if (trimmedTitle === node.title) return;
      node.title = trimmedTitle;
      canvasStore.canvas?.setDirty(true, false);
    }
    __name(handleTitleEdit, "handleTitleEdit");
    function handleTitleCancel() {
      isEditing.value = false;
    }
    __name(handleTitleCancel, "handleTitleCancel");
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$w, [
        createBaseVNode("section", _hoisted_2$p, [
          createBaseVNode("div", _hoisted_3$j, [
            createBaseVNode("h3", _hoisted_4$e, [
              isSingleNodeSelected.value ? (openBlock(), createBlock(EditableText, {
                key: 0,
                "model-value": panelTitle.value,
                "is-editing": isEditing.value,
                "input-attrs": { "data-testid": "node-title-input" },
                onEdit: handleTitleEdit,
                onCancel: handleTitleCancel,
                onDblclick: _cache[0] || (_cache[0] = ($event) => isEditing.value = true)
              }, null, 8, ["model-value", "is-editing"])) : (openBlock(), createElementBlock(Fragment, { key: 1 }, [
                createTextVNode(toDisplayString(panelTitle.value), 1)
              ], 64))
            ]),
            createBaseVNode("div", _hoisted_5$d, [
              isSubgraphNode.value ? (openBlock(), createBlock(_sfc_main$1Y, {
                key: 0,
                variant: "secondary",
                size: "icon",
                class: normalizeClass(unref(cn)(unref(isEditingSubgraph) && "bg-secondary-background-selected")),
                onClick: _cache[1] || (_cache[1] = ($event) => unref(rightSidePanelStore).openPanel(
                  unref(isEditingSubgraph) ? "parameters" : "subgraph"
                ))
              }, {
                default: withCtx(() => _cache[3] || (_cache[3] = [
                  createBaseVNode("i", { class: "icon-[lucide--settings-2]" }, null, -1)
                ])),
                _: 1
              }, 8, ["class"])) : createCommentVNode("", true),
              createVNode(_sfc_main$1Y, {
                variant: "secondary",
                size: "icon",
                "aria-pressed": unref(rightSidePanelStore).isOpen,
                "aria-label": unref(t2)("rightSidePanel.togglePanel"),
                onClick: closePanel
              }, {
                default: withCtx(() => [
                  createBaseVNode("i", {
                    class: normalizeClass(unref(cn)(panelIcon.value, "size-4"))
                  }, null, 2)
                ]),
                _: 1
              }, 8, ["aria-pressed", "aria-label"])
            ])
          ]),
          hasSelection.value ? (openBlock(), createElementBlock("nav", _hoisted_6$c, [
            createVNode(_sfc_main$22, {
              "model-value": unref(activeTab),
              "onUpdate:modelValue": _cache[2] || (_cache[2] = (newTab) => {
                unref(rightSidePanelStore).openPanel(newTab);
              })
            }, {
              default: withCtx(() => [
                (openBlock(true), createElementBlock(Fragment, null, renderList(tabs.value, (tab) => {
                  return openBlock(), createBlock(_sfc_main$23, {
                    key: tab.value,
                    class: "text-sm py-1 px-2 font-inter",
                    value: tab.value
                  }, {
                    default: withCtx(() => [
                      createTextVNode(toDisplayString(tab.label()), 1)
                    ]),
                    _: 2
                  }, 1032, ["value"]);
                }), 128))
              ]),
              _: 1
            }, 8, ["model-value"])
          ])) : createCommentVNode("", true)
        ]),
        createBaseVNode("div", _hoisted_7$9, [
          !hasSelection.value ? (openBlock(), createElementBlock("div", _hoisted_8$8, toDisplayString(_ctx.$t("rightSidePanel.noSelection")), 1)) : isSubgraphNode.value && unref(isEditingSubgraph) ? (openBlock(), createBlock(_sfc_main$J, {
            key: 1,
            node: selectedNode.value
          }, null, 8, ["node"])) : (openBlock(), createElementBlock(Fragment, { key: 2 }, [
            unref(activeTab) === "parameters" ? (openBlock(), createBlock(_sfc_main$N, {
              key: 0,
              nodes: selectedNodes.value
            }, null, 8, ["nodes"])) : unref(activeTab) === "info" ? (openBlock(), createBlock(_sfc_main$R, {
              key: 1,
              nodes: selectedNodes.value
            }, null, 8, ["nodes"])) : unref(activeTab) === "settings" ? (openBlock(), createBlock(_sfc_main$L, {
              key: 2,
              nodes: selectedNodes.value
            }, null, 8, ["nodes"])) : createCommentVNode("", true)
          ], 64))
        ])
      ]);
    };
  }
});
const useSearchBoxStore = defineStore("searchBox", () => {
  const settingStore = useSettingStore();
  const { x, y } = useMouse();
  const newSearchBoxEnabled = computed(
    () => settingStore.get("Comfy.NodeSearchBoxImpl") === "default"
  );
  const popoverRef = shallowRef(null);
  function setPopoverRef(popover) {
    popoverRef.value = popover;
  }
  __name(setPopoverRef, "setPopoverRef");
  const visible = ref(false);
  function toggleVisible() {
    if (newSearchBoxEnabled.value) {
      visible.value = !visible.value;
      return;
    }
    if (!popoverRef.value) return;
    popoverRef.value.showSearchBox(
      new MouseEvent("click", {
        clientX: x.value,
        clientY: y.value,
        // @ts-expect-error layerY is a nonstandard property
        layerY: y.value
      })
    );
  }
  __name(toggleVisible, "toggleVisible");
  return {
    newSearchBoxEnabled,
    setPopoverRef,
    toggleVisible,
    visible
  };
});
const _sfc_main$H = {
  name: "AutoCompletePlus",
  extends: script$k,
  emits: ["focused-option-changed"],
  data() {
    return {
      // Flag to determine if IME is active
      isComposing: false
    };
  },
  mounted() {
    if (typeof script$k.mounted === "function") {
      script$k.mounted.call(this);
    }
    const inputEl = this.$el.querySelector("input");
    if (inputEl) {
      inputEl.addEventListener("compositionstart", () => {
        this.isComposing = true;
      });
      inputEl.addEventListener("compositionend", () => {
        this.isComposing = false;
      });
    }
    this.$watch(
      () => this.focusedOptionIndex,
      (newVal, oldVal) => {
        this.$emit("focused-option-changed", newVal);
      }
    );
  },
  methods: {
    // Override onKeyDown to block Enter when IME is active
    onKeyDown(event) {
      if (event.key === "Enter" && this.isComposing) {
        event.preventDefault();
        event.stopPropagation();
        return;
      }
      script$k.methods.onKeyDown.call(this, event);
    }
  }
};
const _hoisted_1$v = { class: "option-container flex w-full cursor-pointer items-center justify-between overflow-hidden px-2 py-0" };
const _hoisted_2$o = { class: "option-display-name flex flex-col font-semibold" };
const _hoisted_3$i = { key: 0 };
const _hoisted_4$d = ["innerHTML"];
const _hoisted_5$c = ["innerHTML"];
const _hoisted_6$b = {
  key: 0,
  class: "option-category truncate text-sm font-light text-muted"
};
const _hoisted_7$8 = { class: "option-badges" };
const _sfc_main$G = /* @__PURE__ */ defineComponent({
  __name: "NodeSearchItem",
  props: {
    nodeDef: {},
    currentQuery: {}
  },
  setup(__props) {
    const settingStore = useSettingStore();
    const showCategory = computed(
      () => settingStore.get("Comfy.NodeSearchBoxImpl.ShowCategory")
    );
    const showIdName = computed(
      () => settingStore.get("Comfy.NodeSearchBoxImpl.ShowIdName")
    );
    const showNodeFrequency = computed(
      () => settingStore.get("Comfy.NodeSearchBoxImpl.ShowNodeFrequency")
    );
    const nodeFrequencyStore = useNodeFrequencyStore();
    const nodeFrequency = computed(
      () => nodeFrequencyStore.getNodeFrequency(props.nodeDef)
    );
    const nodeBookmarkStore = useNodeBookmarkStore();
    const isBookmarked = computed(
      () => nodeBookmarkStore.isBookmarked(props.nodeDef)
    );
    const props = __props;
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$v, [
        createBaseVNode("div", _hoisted_2$o, [
          createBaseVNode("div", null, [
            isBookmarked.value ? (openBlock(), createElementBlock("span", _hoisted_3$i, _cache[0] || (_cache[0] = [
              createBaseVNode("i", { class: "pi pi-bookmark-fill mr-1 text-sm" }, null, -1)
            ]))) : createCommentVNode("", true),
            createBaseVNode("span", {
              innerHTML: unref(highlightQuery)(_ctx.nodeDef.display_name, _ctx.currentQuery)
            }, null, 8, _hoisted_4$d),
            _cache[1] || (_cache[1] = createBaseVNode("span", null, " ", -1)),
            showIdName.value ? (openBlock(), createBlock(unref(script$6), {
              key: 1,
              severity: "secondary"
            }, {
              default: withCtx(() => [
                createBaseVNode("span", {
                  innerHTML: unref(highlightQuery)(_ctx.nodeDef.name, _ctx.currentQuery)
                }, null, 8, _hoisted_5$c)
              ]),
              _: 1
            })) : createCommentVNode("", true)
          ]),
          showCategory.value ? (openBlock(), createElementBlock("div", _hoisted_6$b, toDisplayString(_ctx.nodeDef.category.replaceAll("/", " > ")), 1)) : createCommentVNode("", true)
        ]),
        createBaseVNode("div", _hoisted_7$8, [
          _ctx.nodeDef.experimental ? (openBlock(), createBlock(unref(script$6), {
            key: 0,
            value: _ctx.$t("g.experimental"),
            severity: "primary"
          }, null, 8, ["value"])) : createCommentVNode("", true),
          _ctx.nodeDef.deprecated ? (openBlock(), createBlock(unref(script$6), {
            key: 1,
            value: _ctx.$t("g.deprecated"),
            severity: "danger"
          }, null, 8, ["value"])) : createCommentVNode("", true),
          showNodeFrequency.value && nodeFrequency.value > 0 ? (openBlock(), createBlock(unref(script$6), {
            key: 2,
            value: unref(formatNumberWithSuffix)(nodeFrequency.value, { roundToInt: true }),
            severity: "secondary"
          }, null, 8, ["value"])) : createCommentVNode("", true),
          _ctx.nodeDef.nodeSource.type !== unref(NodeSourceType).Unknown ? (openBlock(), createBlock(unref(script$l), {
            key: 3,
            class: "text-sm font-light"
          }, {
            default: withCtx(() => [
              createTextVNode(toDisplayString(_ctx.nodeDef.nodeSource.displayText), 1)
            ]),
            _: 1
          })) : createCommentVNode("", true)
        ])
      ]);
    };
  }
});
const NodeSearchItem = /* @__PURE__ */ _export_sfc(_sfc_main$G, [["__scopeId", "data-v-acda36a0"]]);
const _hoisted_1$u = { class: "comfy-vue-node-search-container flex w-full min-w-96 items-center justify-center" };
const _hoisted_2$n = { class: "_dialog-body" };
const _sfc_main$F = /* @__PURE__ */ defineComponent({
  __name: "NodeSearchBox",
  props: {
    filters: {},
    searchLimit: { default: 64 }
  },
  emits: ["addFilter", "removeFilter", "addNode"],
  setup(__props, { emit: __emit }) {
    const settingStore = useSettingStore();
    const { t: t2 } = useI18n();
    const enableNodePreview = computed(
      () => settingStore.get("Comfy.NodeSearchBoxImpl.NodePreview")
    );
    const autoCompletePlus = ref();
    const nodeSearchFilterVisible = ref(false);
    const inputId = `comfy-vue-node-search-box-input-${Math.random()}`;
    const suggestions = ref([]);
    const hoveredSuggestion = ref(null);
    const currentQuery = ref("");
    const placeholder = computed(() => {
      return __props.filters.length === 0 ? t2("g.searchNodes") + "..." : "";
    });
    const nodeDefStore = useNodeDefStore();
    const nodeFrequencyStore = useNodeFrequencyStore();
    const debouncedTrackSearch = debounce((query) => {
      if (query.trim()) ;
    }, 500);
    const search = /* @__PURE__ */ __name((query) => {
      const queryIsEmpty = query === "" && __props.filters.length === 0;
      currentQuery.value = query;
      suggestions.value = queryIsEmpty ? nodeFrequencyStore.topNodeDefs : [
        ...nodeDefStore.nodeSearchService.searchNode(query, __props.filters, {
          limit: __props.searchLimit
        })
      ];
      debouncedTrackSearch(query);
    }, "search");
    const emit = __emit;
    const onAddNode = /* @__PURE__ */ __name((nodeDef) => {
      emit("addNode", nodeDef);
    }, "onAddNode");
    let inputElement = null;
    const reFocusInput = /* @__PURE__ */ __name(async () => {
      inputElement ??= document.getElementById(inputId);
      if (inputElement) {
        inputElement.blur();
        await nextTick(() => inputElement?.focus());
      }
    }, "reFocusInput");
    onMounted(() => {
      inputElement ??= document.getElementById(inputId);
      if (inputElement) inputElement.focus();
      autoCompletePlus.value.hide = () => search("");
      search("");
      autoCompletePlus.value.show();
    });
    const onAddFilter = /* @__PURE__ */ __name((filterAndValue) => {
      nodeSearchFilterVisible.value = false;
      emit("addFilter", filterAndValue);
    }, "onAddFilter");
    const onRemoveFilter = /* @__PURE__ */ __name(async (event, filterAndValue) => {
      event.stopPropagation();
      event.preventDefault();
      emit("removeFilter", filterAndValue);
      await reFocusInput();
    }, "onRemoveFilter");
    const setHoverSuggestion = /* @__PURE__ */ __name((index) => {
      if (index === -1) {
        hoveredSuggestion.value = null;
        return;
      }
      const value = suggestions.value[index];
      hoveredSuggestion.value = value;
    }, "setHoverSuggestion");
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$u, [
        enableNodePreview.value && hoveredSuggestion.value ? (openBlock(), createElementBlock("div", {
          key: 0,
          class: "comfy-vue-node-preview-container absolute top-[50px] left-[-375px] z-50 cursor-pointer",
          onMousedown: _cache[0] || (_cache[0] = withModifiers(($event) => onAddNode(hoveredSuggestion.value), ["stop"]))
        }, [
          (openBlock(), createBlock(NodePreview, {
            key: hoveredSuggestion.value?.name || "",
            "node-def": hoveredSuggestion.value
          }, null, 8, ["node-def"]))
        ], 32)) : createCommentVNode("", true),
        createVNode(_sfc_main$1Y, {
          variant: "secondary",
          "aria-label": _ctx.$t("g.addNodeFilterCondition"),
          class: "filter-button z-10",
          onClick: _cache[1] || (_cache[1] = ($event) => nodeSearchFilterVisible.value = true)
        }, {
          default: withCtx(() => _cache[6] || (_cache[6] = [
            createBaseVNode("i", { class: "pi pi-filter" }, null, -1)
          ])),
          _: 1
        }, 8, ["aria-label"]),
        createVNode(unref(script$m), {
          visible: nodeSearchFilterVisible.value,
          "onUpdate:visible": _cache[2] || (_cache[2] = ($event) => nodeSearchFilterVisible.value = $event),
          class: "min-w-96",
          "dismissable-mask": "",
          modal: "",
          onHide: reFocusInput
        }, {
          header: withCtx(() => [
            createBaseVNode("h3", null, toDisplayString(_ctx.$t("g.addNodeFilterCondition")), 1)
          ]),
          default: withCtx(() => [
            createBaseVNode("div", _hoisted_2$n, [
              createVNode(NodeSearchFilter, { onAddFilter })
            ])
          ]),
          _: 1
        }, 8, ["visible"]),
        createVNode(_sfc_main$H, {
          ref_key: "autoCompletePlus",
          ref: autoCompletePlus,
          "model-value": _ctx.filters,
          class: "comfy-vue-node-search-box z-10 grow",
          "scroll-height": "40vh",
          placeholder: placeholder.value,
          "input-id": inputId,
          "append-to": "self",
          suggestions: suggestions.value,
          delay: 100,
          loading: !unref(nodeFrequencyStore).isLoaded,
          "complete-on-focus": "",
          "auto-option-focus": "",
          "force-selection": "",
          multiple: "",
          "option-label": "display_name",
          onComplete: _cache[3] || (_cache[3] = ($event) => search($event.query)),
          onOptionSelect: _cache[4] || (_cache[4] = ($event) => onAddNode($event.value)),
          onFocusedOptionChanged: _cache[5] || (_cache[5] = ($event) => setHoverSuggestion($event))
        }, {
          option: withCtx(({ option }) => [
            createVNode(NodeSearchItem, {
              "node-def": option,
              "current-query": currentQuery.value
            }, null, 8, ["node-def", "current-query"])
          ]),
          chip: withCtx(({ value }) => [
            value.filterDef && value.value ? (openBlock(), createBlock(SearchFilterChip, {
              key: `${value.filterDef.id}-${value.value}`,
              text: value.value,
              badge: value.filterDef.invokeSequence.toUpperCase(),
              "badge-class": value.filterDef.invokeSequence + "-badge",
              onRemove: /* @__PURE__ */ __name(($event) => onRemoveFilter(
                $event,
                value
              ), "onRemove")
            }, null, 8, ["text", "badge", "badge-class", "onRemove"])) : createCommentVNode("", true)
          ]),
          _: 1
        }, 8, ["model-value", "placeholder", "suggestions", "loading"])
      ]);
    };
  }
});
const _sfc_main$E = /* @__PURE__ */ defineComponent({
  __name: "NodeSearchBoxPopover",
  setup(__props, { expose: __expose }) {
    let triggerEvent = null;
    let listenerController = null;
    let disconnectOnReset = false;
    const settingStore = useSettingStore();
    const searchBoxStore = useSearchBoxStore();
    const litegraphService = useLitegraphService();
    const { visible, newSearchBoxEnabled } = storeToRefs(searchBoxStore);
    const dismissable = ref(true);
    function getNewNodeLocation() {
      return triggerEvent ? [triggerEvent.canvasX, triggerEvent.canvasY] : litegraphService.getCanvasCenter();
    }
    __name(getNewNodeLocation, "getNewNodeLocation");
    const nodeFilters = ref([]);
    function addFilter(filter) {
      nodeFilters.value.push(filter);
    }
    __name(addFilter, "addFilter");
    function removeFilter(filter) {
      nodeFilters.value = nodeFilters.value.filter(
        (f) => toRaw(f) !== toRaw(filter)
      );
    }
    __name(removeFilter, "removeFilter");
    function clearFilters() {
      nodeFilters.value = [];
    }
    __name(clearFilters, "clearFilters");
    function closeDialog() {
      visible.value = false;
    }
    __name(closeDialog, "closeDialog");
    const canvasStore = useCanvasStore();
    function addNode(nodeDef) {
      const node = litegraphService.addNodeOnGraph(nodeDef, {
        pos: getNewNodeLocation()
      });
      if (disconnectOnReset && triggerEvent) {
        canvasStore.getCanvas().linkConnector.connectToNode(node, triggerEvent);
      } else if (!triggerEvent) {
        console.warn("The trigger event was undefined when addNode was called.");
      }
      disconnectOnReset = false;
      useWorkflowStore().activeWorkflow?.changeTracker?.checkState();
      window.requestAnimationFrame(closeDialog);
    }
    __name(addNode, "addNode");
    function showSearchBox(e) {
      if (newSearchBoxEnabled.value) {
        if (e?.pointerType === "touch") {
          setTimeout(() => {
            showNewSearchBox(e);
          }, 128);
        } else {
          showNewSearchBox(e);
        }
      } else {
        canvasStore.getCanvas().showSearchBox(e);
      }
    }
    __name(showSearchBox, "showSearchBox");
    function getFirstLink() {
      return canvasStore.getCanvas().linkConnector.renderLinks.at(0);
    }
    __name(getFirstLink, "getFirstLink");
    const nodeDefStore = useNodeDefStore();
    function showNewSearchBox(e) {
      const firstLink = getFirstLink();
      if (firstLink) {
        const filter = firstLink.toType === "input" ? nodeDefStore.nodeSearchService.inputTypeFilter : nodeDefStore.nodeSearchService.outputTypeFilter;
        const dataType = firstLink.fromSlot.type?.toString() ?? "";
        addFilter({
          filterDef: filter,
          value: dataType
        });
      }
      visible.value = true;
      triggerEvent = e;
      dismissable.value = false;
      setTimeout(() => {
        dismissable.value = true;
      }, 300);
    }
    __name(showNewSearchBox, "showNewSearchBox");
    function showContextMenu(e) {
      const firstLink = getFirstLink();
      if (!firstLink) return;
      const { node, fromSlot, toType } = firstLink;
      const commonOptions = {
        e,
        allow_searchbox: true,
        showSearchBox: /* @__PURE__ */ __name(() => {
          cancelResetOnContextClose();
          showSearchBox(e);
        }, "showSearchBox")
      };
      const afterRerouteId = firstLink.fromReroute?.id;
      const connectionOptions = toType === "input" ? { nodeFrom: node, slotFrom: fromSlot, afterRerouteId } : { nodeTo: node, slotTo: fromSlot, afterRerouteId };
      const canvas = canvasStore.getCanvas();
      const menu = canvas.showConnectionMenu({
        ...connectionOptions,
        ...commonOptions
      });
      if (!menu) {
        console.warn("No menu was returned from showConnectionMenu");
        return;
      }
      triggerEvent = e;
      listenerController = new AbortController();
      const { signal } = listenerController;
      const options = { once: true, signal };
      useEventListener(
        canvas.canvas,
        "connect-new-default-node",
        (createEvent) => {
          if (!(createEvent instanceof CustomEvent))
            throw new Error("Invalid event");
          const node2 = createEvent.detail?.node;
          if (!(node2 instanceof LGraphNode)) throw new Error("Invalid node");
          disconnectOnReset = false;
          createEvent.preventDefault();
          canvas.linkConnector.connectToNode(node2, e);
        },
        options
      );
      const cancelResetOnContextClose = useEventListener(
        menu.controller.signal,
        "abort",
        reset,
        options
      );
    }
    __name(showContextMenu, "showContextMenu");
    watchEffect(() => {
      const { canvas } = canvasStore;
      if (!canvas) return;
      LiteGraph.release_link_on_empty_shows_menu = false;
      canvas.allow_searchbox = false;
      useEventListener(
        canvas.linkConnector.events,
        "dropped-on-canvas",
        handleDroppedOnCanvas
      );
    });
    function canvasEventHandler(e) {
      if (e.detail.subType === "empty-double-click") {
        showSearchBox(e.detail.originalEvent);
      } else if (e.detail.subType === "group-double-click") {
        const group = e.detail.group;
        const [_, y] = group.pos;
        const relativeY = e.detail.originalEvent.canvasY - y;
        if (relativeY > group.titleHeight) {
          showSearchBox(e.detail.originalEvent);
        }
      }
    }
    __name(canvasEventHandler, "canvasEventHandler");
    const linkReleaseAction = computed(
      () => settingStore.get("Comfy.LinkRelease.Action")
    );
    const linkReleaseActionShift = computed(
      () => settingStore.get("Comfy.LinkRelease.ActionShift")
    );
    function preventDefault(e) {
      return e.preventDefault();
    }
    __name(preventDefault, "preventDefault");
    function cancelNextReset(e) {
      e.preventDefault();
      const canvas = canvasStore.getCanvas();
      canvas.linkConnector.state.snapLinksPos = [e.detail.canvasX, e.detail.canvasY];
      useEventListener(canvas.linkConnector.events, "reset", preventDefault, {
        once: true
      });
    }
    __name(cancelNextReset, "cancelNextReset");
    function handleDroppedOnCanvas(e) {
      disconnectOnReset = true;
      const action = e.detail.shiftKey ? linkReleaseActionShift.value : linkReleaseAction.value;
      switch (action) {
        case LinkReleaseTriggerAction.SEARCH_BOX:
          cancelNextReset(e);
          showSearchBox(e.detail);
          break;
        case LinkReleaseTriggerAction.CONTEXT_MENU:
          cancelNextReset(e);
          showContextMenu(e.detail);
          break;
        case LinkReleaseTriggerAction.NO_ACTION:
      }
    }
    __name(handleDroppedOnCanvas, "handleDroppedOnCanvas");
    function reset() {
      listenerController?.abort();
      listenerController = null;
      triggerEvent = null;
      const canvas = canvasStore.getCanvas();
      canvas.linkConnector.events.removeEventListener("reset", preventDefault);
      if (disconnectOnReset) canvas.linkConnector.disconnectLinks();
      canvas.linkConnector.reset();
      canvas.setDirty(true, true);
    }
    __name(reset, "reset");
    watch(visible, () => {
      if (!visible.value) reset();
    });
    useEventListener(document, "litegraph:canvas", canvasEventHandler);
    __expose({ showSearchBox });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", null, [
        createVNode(unref(script$m), {
          visible: unref(visible),
          "onUpdate:visible": _cache[0] || (_cache[0] = ($event) => isRef(visible) ? visible.value = $event : null),
          modal: "",
          "dismissable-mask": dismissable.value,
          pt: {
            root: {
              class: "invisible-dialog-root",
              role: "search"
            },
            mask: { class: "node-search-box-dialog-mask" },
            transition: {
              enterFromClass: "opacity-0 scale-75",
              // 100ms is the duration of the transition in the dialog component
              enterActiveClass: "transition-all duration-100 ease-out",
              leaveActiveClass: "transition-all duration-100 ease-in",
              leaveToClass: "opacity-0 scale-75"
            }
          },
          onHide: clearFilters
        }, {
          container: withCtx(() => [
            createVNode(_sfc_main$F, {
              filters: nodeFilters.value,
              onAddFilter: addFilter,
              onRemoveFilter: removeFilter,
              onAddNode: addNode
            }, null, 8, ["filters"])
          ]),
          _: 1
        }, 8, ["visible", "dismissable-mask"])
      ]);
    };
  }
});
const _hoisted_1$t = ["width", "height"];
const _sfc_main$D = /* @__PURE__ */ defineComponent({
  __name: "ComfyLogo",
  props: {
    size: { default: 16 },
    color: { default: "currentColor" },
    class: {},
    mode: { default: "outline" }
  },
  setup(__props) {
    const iconClass = computed(() => __props.class || "");
    const attributes = computed(() => ({
      stroke: __props.mode === "outline" ? __props.color : void 0,
      strokeWidth: __props.mode === "outline" ? 1 : void 0,
      fill: __props.mode === "fill" ? __props.color : "none"
    }));
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("svg", {
        class: normalizeClass(iconClass.value),
        width: _ctx.size,
        height: _ctx.size,
        viewBox: "0 0 18 18",
        xmlns: "http://www.w3.org/2000/svg"
      }, [
        createBaseVNode("path", mergeProps({ d: "M14.8193 0.600586C15.1248 0.600586 15.3296 0.70893 15.459 0.881836C15.5914 1.05888 15.6471 1.33774 15.5527 1.66895L14.8037 4.30176C14.7063 4.64386 14.4729 4.97024 14.1641 5.21191C13.8544 5.45415 13.496 5.58984 13.1699 5.58984H13.1689L9.5791 5.59668H7.90625C7.52654 5.59668 7.19496 5.84986 7.09082 6.21289L5.69434 11.0889C5.63007 11.3133 5.66134 11.5534 5.77734 11.7529L5.83203 11.8359C5.99177 12.0491 6.24252 12.1758 6.50977 12.1758H6.51074L8.88281 12.1709H11.4971C11.7643 12.171 11.9541 12.254 12.084 12.3906L12.1357 12.4521C12.2685 12.6295 12.3249 12.9089 12.2305 13.2402L11.4805 15.8721C11.383 16.2144 11.1498 16.5415 10.8408 16.7832C10.5314 17.0252 10.1736 17.161 9.84766 17.1611H9.84668L6.25684 17.168H3.64258C3.33762 17.1679 3.13349 17.0588 3.00391 16.8857C2.87135 16.7087 2.81482 16.43 2.90918 16.0986L3.39551 14.3887C3.46841 14.1327 3.41794 13.8576 3.25879 13.6445V13.6436C3.09901 13.4303 2.84745 13.3037 2.58008 13.3037H1.18066C0.875088 13.3037 0.670398 13.1953 0.541016 13.0225C0.408483 12.8451 0.351891 12.5655 0.446289 12.2344L2.11914 6.38965L2.30371 5.74707V5.74609C2.40139 5.40341 2.63456 5.07671 2.94336 4.83496C3.25302 4.59258 3.61143 4.45705 3.9375 4.45703H5.6123C5.94484 4.45703 6.24083 4.26316 6.37891 3.9707L6.42773 3.83984L6.98145 1.89551C7.07894 1.55317 7.31212 1.22614 7.62109 0.984375C7.93074 0.742127 8.2892 0.606445 8.61523 0.606445H8.61621L12.1982 0.600586H14.8193Z" }, attributes.value), null, 16)
      ], 10, _hoisted_1$t);
    };
  }
});
const _hoisted_1$s = { class: "relative aspect-square w-full overflow-hidden rounded-t-lg select-none" };
const _hoisted_2$m = {
  key: 1,
  class: "flex h-full w-full items-center justify-center"
};
const _sfc_main$C = /* @__PURE__ */ defineComponent({
  __name: "BaseThumbnail",
  props: {
    hoverZoom: { default: 4 },
    isHovered: { type: Boolean }
  },
  setup(__props) {
    const error = ref(false);
    const contentRef = ref(null);
    onMounted(() => {
      const images = Array.from(contentRef.value?.getElementsByTagName("img") ?? []);
      images.forEach((img) => {
        useEventListener(img, "error", () => {
          error.value = true;
        });
      });
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$s, [
        !error.value ? (openBlock(), createElementBlock("div", {
          key: 0,
          ref_key: "contentRef",
          ref: contentRef,
          class: "h-full w-full transform-gpu transition-transform duration-1000 ease-out",
          style: normalizeStyle(
            _ctx.isHovered ? { transform: `scale(${1 + _ctx.hoverZoom / 100})` } : void 0
          )
        }, [
          renderSlot(_ctx.$slots, "default", {}, void 0, true)
        ], 4)) : (openBlock(), createElementBlock("div", _hoisted_2$m, _cache[0] || (_cache[0] = [
          createBaseVNode("img", {
            src: _imports_0,
            draggable: "false",
            class: "h-full w-full transform-gpu object-cover transition-transform duration-300 ease-out"
          }, null, -1)
        ])))
      ]);
    };
  }
});
const BaseThumbnail = /* @__PURE__ */ _export_sfc(_sfc_main$C, [["__scopeId", "data-v-c216f2c0"]]);
const _hoisted_1$r = {
  class: "flex h-full w-full items-center justify-center p-4",
  style: {
    backgroundImage: "url(/assets/images/default-template.png)",
    backgroundRepeat: "round"
  }
};
const _hoisted_2$l = ["src"];
const _sfc_main$B = /* @__PURE__ */ defineComponent({
  __name: "AudioThumbnail",
  props: {
    src: {}
  },
  setup(__props) {
    return (_ctx, _cache) => {
      return openBlock(), createBlock(BaseThumbnail, null, {
        default: withCtx(() => [
          createBaseVNode("div", _hoisted_1$r, [
            createBaseVNode("audio", {
              controls: "",
              class: "relative w-full",
              src: _ctx.src,
              onClick: _cache[0] || (_cache[0] = withModifiers(() => {
              }, ["stop"]))
            }, null, 8, _hoisted_2$l)
          ])
        ]),
        _: 1
      });
    };
  }
});
const SLIDER_START_POSITION = 50;
const _sfc_main$A = /* @__PURE__ */ defineComponent({
  __name: "CompareSliderThumbnail",
  props: {
    baseImageSrc: {},
    overlayImageSrc: {},
    alt: {},
    isHovered: { type: Boolean },
    isVideo: { type: Boolean }
  },
  setup(__props) {
    const isVideoType = __props.isVideo || __props.baseImageSrc?.toLowerCase().endsWith(".webp") || __props.overlayImageSrc?.toLowerCase().endsWith(".webp") || false;
    const sliderPosition = ref(SLIDER_START_POSITION);
    const containerRef = ref(null);
    const { elementX, elementWidth, isOutside } = useMouseInElement(containerRef);
    watch(
      [() => __props.isHovered, elementX, elementWidth, isOutside],
      ([isHovered, x, width, outside]) => {
        if (!isHovered) return;
        if (!outside) {
          sliderPosition.value = x / width * 100;
        }
      }
    );
    return (_ctx, _cache) => {
      return openBlock(), createBlock(BaseThumbnail, { "is-hovered": _ctx.isHovered }, {
        default: withCtx(() => [
          createVNode(_sfc_main$24, {
            src: _ctx.baseImageSrc,
            alt: _ctx.alt,
            "image-class": unref(isVideoType) ? "w-full h-full object-cover" : "max-w-full max-h-64 object-contain"
          }, null, 8, ["src", "alt", "image-class"]),
          createBaseVNode("div", {
            ref_key: "containerRef",
            ref: containerRef,
            class: "absolute inset-0"
          }, [
            createVNode(_sfc_main$24, {
              src: _ctx.overlayImageSrc,
              alt: _ctx.alt,
              "image-class": unref(isVideoType) ? "w-full h-full object-cover" : "max-w-full max-h-64 object-contain",
              "image-style": {
                clipPath: `inset(0 ${100 - sliderPosition.value}% 0 0)`
              }
            }, null, 8, ["src", "alt", "image-class", "image-style"]),
            createBaseVNode("div", {
              class: "pointer-events-none absolute inset-y-0 z-10 w-0.5 bg-white/30 backdrop-blur-sm",
              style: normalizeStyle({
                left: `${sliderPosition.value}%`
              })
            }, null, 4)
          ], 512)
        ]),
        _: 1
      }, 8, ["is-hovered"]);
    };
  }
});
const _sfc_main$z = /* @__PURE__ */ defineComponent({
  __name: "DefaultThumbnail",
  props: {
    src: {},
    alt: {},
    hoverZoom: {},
    isHovered: { type: Boolean },
    isVideo: { type: Boolean }
  },
  setup(__props) {
    const isVideoType = __props.isVideo ?? (__props.src?.toLowerCase().endsWith(".webp") || false);
    return (_ctx, _cache) => {
      return openBlock(), createBlock(BaseThumbnail, {
        "hover-zoom": _ctx.hoverZoom,
        "is-hovered": _ctx.isHovered
      }, {
        default: withCtx(() => [
          createVNode(_sfc_main$24, {
            src: _ctx.src,
            alt: _ctx.alt,
            "image-class": [
              "transform-gpu transition-transform duration-300 ease-out",
              unref(isVideoType) ? "w-full h-full object-cover" : "max-w-full max-h-64 object-contain"
            ],
            "image-style": _ctx.isHovered ? { transform: `scale(${1 + _ctx.hoverZoom / 100})` } : void 0
          }, null, 8, ["src", "alt", "image-class", "image-style"])
        ]),
        _: 1
      }, 8, ["hover-zoom", "is-hovered"]);
    };
  }
});
const _hoisted_1$q = { class: "relative h-full w-full" };
const _hoisted_2$k = { class: "absolute inset-0" };
const _hoisted_3$h = { class: "absolute inset-0 z-10" };
const _sfc_main$y = /* @__PURE__ */ defineComponent({
  __name: "HoverDissolveThumbnail",
  props: {
    baseImageSrc: {},
    overlayImageSrc: {},
    alt: {},
    isHovered: { type: Boolean },
    isVideo: { type: Boolean }
  },
  setup(__props) {
    const isVideoType = __props.isVideo || __props.baseImageSrc?.toLowerCase().endsWith(".webp") || __props.overlayImageSrc?.toLowerCase().endsWith(".webp") || false;
    const baseImageClass = computed(() => {
      const sizeClasses = isVideoType ? "size-full object-cover" : "size-full object-contain";
      return sizeClasses;
    });
    const overlayImageClass = computed(() => {
      const baseClasses = "size-full transition-opacity duration-300";
      const sizeClasses = isVideoType ? "object-cover" : "object-contain";
      const opacityClasses = __props.isHovered ? "opacity-100" : "opacity-0";
      return `${baseClasses} ${sizeClasses} ${opacityClasses}`;
    });
    return (_ctx, _cache) => {
      return openBlock(), createBlock(BaseThumbnail, { "is-hovered": _ctx.isHovered }, {
        default: withCtx(() => [
          createBaseVNode("div", _hoisted_1$q, [
            createBaseVNode("div", _hoisted_2$k, [
              createVNode(_sfc_main$24, {
                src: _ctx.baseImageSrc,
                alt: _ctx.alt,
                "image-class": baseImageClass.value
              }, null, 8, ["src", "alt", "image-class"])
            ]),
            createBaseVNode("div", _hoisted_3$h, [
              createVNode(_sfc_main$24, {
                src: _ctx.overlayImageSrc,
                alt: _ctx.alt,
                "image-class": overlayImageClass.value
              }, null, 8, ["src", "alt", "image-class"])
            ])
          ])
        ]),
        _: 1
      }, 8, ["is-hovered"]);
    };
  }
});
function useLazyPagination(items, options = {}) {
  const { itemsPerPage = 12, initialPage = 1 } = options;
  const currentPage = ref(initialPage);
  const isLoading = ref(false);
  const loadedPages = shallowRef(/* @__PURE__ */ new Set([]));
  const itemsArray = computed(() => {
    const itemData = "value" in items ? items.value : items;
    return Array.isArray(itemData) ? itemData : [];
  });
  const paginatedItems = computed(() => {
    const itemData = itemsArray.value;
    if (itemData.length === 0) {
      return [];
    }
    const loadedPageNumbers = Array.from(loadedPages.value).sort(
      (a, b) => a - b
    );
    const maxLoadedPage = Math.max(...loadedPageNumbers, 0);
    const endIndex = maxLoadedPage * itemsPerPage;
    return itemData.slice(0, endIndex);
  });
  const hasMoreItems = computed(() => {
    const itemData = itemsArray.value;
    if (itemData.length === 0) {
      return false;
    }
    const loadedPagesArray = Array.from(loadedPages.value);
    const maxLoadedPage = Math.max(...loadedPagesArray, 0);
    return maxLoadedPage * itemsPerPage < itemData.length;
  });
  const totalPages = computed(() => {
    const itemData = itemsArray.value;
    if (itemData.length === 0) {
      return 0;
    }
    return Math.ceil(itemData.length / itemsPerPage);
  });
  const loadNextPage = /* @__PURE__ */ __name(async () => {
    if (isLoading.value || !hasMoreItems.value) return;
    isLoading.value = true;
    const loadedPagesArray = Array.from(loadedPages.value);
    const nextPage = Math.max(...loadedPagesArray, 0) + 1;
    const newLoadedPages = new Set(loadedPages.value);
    newLoadedPages.add(nextPage);
    loadedPages.value = newLoadedPages;
    currentPage.value = nextPage;
    isLoading.value = false;
  }, "loadNextPage");
  watch(
    () => itemsArray.value.length,
    (length) => {
      if (length > 0 && loadedPages.value.size === 0) {
        loadedPages.value = /* @__PURE__ */ new Set([1]);
      }
    },
    { immediate: true }
  );
  const reset = /* @__PURE__ */ __name(() => {
    currentPage.value = initialPage;
    loadedPages.value = /* @__PURE__ */ new Set([]);
    isLoading.value = false;
    const itemData = itemsArray.value;
    if (itemData.length > 0) {
      loadedPages.value = /* @__PURE__ */ new Set([1]);
    }
  }, "reset");
  return {
    paginatedItems,
    isLoading,
    hasMoreItems,
    currentPage,
    totalPages,
    loadNextPage,
    reset
  };
}
__name(useLazyPagination, "useLazyPagination");
function useTemplateFiltering(templates) {
  const settingStore = useSettingStore();
  const searchQuery = ref("");
  const selectedModels = ref(
    settingStore.get("Comfy.Templates.SelectedModels")
  );
  const selectedUseCases = ref(
    settingStore.get("Comfy.Templates.SelectedUseCases")
  );
  const selectedRunsOn = ref(
    settingStore.get("Comfy.Templates.SelectedRunsOn")
  );
  const sortBy = ref(settingStore.get("Comfy.Templates.SortBy"));
  const templatesArray = computed(() => {
    const templateData = "value" in templates ? templates.value : templates;
    return Array.isArray(templateData) ? templateData : [];
  });
  const fuseOptions = {
    keys: [
      { name: "name", weight: 0.3 },
      { name: "title", weight: 0.3 },
      { name: "description", weight: 0.1 },
      { name: "tags", weight: 0.2 },
      { name: "models", weight: 0.3 }
    ],
    threshold: 0.33,
    includeScore: true,
    includeMatches: true
  };
  const fuse = computed(() => new Fuse(templatesArray.value, fuseOptions));
  const availableModels = computed(() => {
    const modelSet = /* @__PURE__ */ new Set();
    templatesArray.value.forEach((template) => {
      if (Array.isArray(template.models)) {
        template.models.forEach((model) => modelSet.add(model));
      }
    });
    return Array.from(modelSet).sort();
  });
  const availableUseCases = computed(() => {
    const tagSet = /* @__PURE__ */ new Set();
    templatesArray.value.forEach((template) => {
      if (template.tags && Array.isArray(template.tags)) {
        template.tags.forEach((tag) => tagSet.add(tag));
      }
    });
    return Array.from(tagSet).sort();
  });
  const availableRunsOn = computed(() => {
    return ["ComfyUI", "External or Remote API"];
  });
  const debouncedSearchQuery = refDebounced(searchQuery, 50);
  const filteredBySearch = computed(() => {
    if (!debouncedSearchQuery.value.trim()) {
      return templatesArray.value;
    }
    const results = fuse.value.search(debouncedSearchQuery.value);
    return results.map((result) => result.item);
  });
  const filteredByModels = computed(() => {
    if (selectedModels.value.length === 0) {
      return filteredBySearch.value;
    }
    return filteredBySearch.value.filter((template) => {
      if (!template.models || !Array.isArray(template.models)) {
        return false;
      }
      return selectedModels.value.some(
        (selectedModel) => template.models?.includes(selectedModel)
      );
    });
  });
  const filteredByUseCases = computed(() => {
    if (selectedUseCases.value.length === 0) {
      return filteredByModels.value;
    }
    return filteredByModels.value.filter((template) => {
      if (!template.tags || !Array.isArray(template.tags)) {
        return false;
      }
      return selectedUseCases.value.some(
        (selectedTag) => template.tags?.includes(selectedTag)
      );
    });
  });
  const filteredByRunsOn = computed(() => {
    if (selectedRunsOn.value.length === 0) {
      return filteredByUseCases.value;
    }
    return filteredByUseCases.value.filter((template) => {
      const isExternalAPI = template.openSource === false;
      const isComfyUI = template.openSource !== false;
      return selectedRunsOn.value.some((selectedRunsOn2) => {
        if (selectedRunsOn2 === "External or Remote API") {
          return isExternalAPI;
        } else if (selectedRunsOn2 === "ComfyUI") {
          return isComfyUI;
        }
        return false;
      });
    });
  });
  const getVramMetric = /* @__PURE__ */ __name((template) => {
    if (typeof template.vram === "number" && Number.isFinite(template.vram) && template.vram > 0) {
      return template.vram;
    }
    return Number.POSITIVE_INFINITY;
  }, "getVramMetric");
  const sortedTemplates = computed(() => {
    const templates2 = [...filteredByRunsOn.value];
    switch (sortBy.value) {
      case "alphabetical":
        return templates2.sort((a, b) => {
          const nameA = a.title || a.name || "";
          const nameB = b.title || b.name || "";
          return nameA.localeCompare(nameB);
        });
      case "newest":
        return templates2.sort((a, b) => {
          const dateA = new Date(a.date || "1970-01-01");
          const dateB = new Date(b.date || "1970-01-01");
          return dateB.getTime() - dateA.getTime();
        });
      case "vram-low-to-high":
        return templates2.sort((a, b) => {
          const vramA = getVramMetric(a);
          const vramB = getVramMetric(b);
          if (vramA === vramB) {
            const nameA = a.title || a.name || "";
            const nameB = b.title || b.name || "";
            return nameA.localeCompare(nameB);
          }
          if (vramA === Number.POSITIVE_INFINITY) return 1;
          if (vramB === Number.POSITIVE_INFINITY) return -1;
          return vramA - vramB;
        });
      case "model-size-low-to-high":
        return templates2.sort((a, b) => {
          const sizeA = typeof a.size === "number" ? a.size : Number.POSITIVE_INFINITY;
          const sizeB = typeof b.size === "number" ? b.size : Number.POSITIVE_INFINITY;
          if (sizeA === sizeB) return 0;
          return sizeA - sizeB;
        });
      case "default":
      default:
        return templates2;
    }
  });
  const filteredTemplates = computed(() => sortedTemplates.value);
  const resetFilters = /* @__PURE__ */ __name(() => {
    searchQuery.value = "";
    selectedModels.value = [];
    selectedUseCases.value = [];
    selectedRunsOn.value = [];
    sortBy.value = "newest";
  }, "resetFilters");
  const removeModelFilter = /* @__PURE__ */ __name((model) => {
    selectedModels.value = selectedModels.value.filter((m) => m !== model);
  }, "removeModelFilter");
  const removeUseCaseFilter = /* @__PURE__ */ __name((tag) => {
    selectedUseCases.value = selectedUseCases.value.filter((t2) => t2 !== tag);
  }, "removeUseCaseFilter");
  const removeRunsOnFilter = /* @__PURE__ */ __name((runsOn) => {
    selectedRunsOn.value = selectedRunsOn.value.filter((r) => r !== runsOn);
  }, "removeRunsOnFilter");
  const filteredCount = computed(() => filteredTemplates.value.length);
  const totalCount = computed(() => templatesArray.value.length);
  const debouncedTrackFilterChange = debounce(() => {
  }, 500);
  watch(
    [searchQuery, selectedModels, selectedUseCases, selectedRunsOn, sortBy],
    () => {
      const hasActiveFilters = searchQuery.value.trim() !== "" || selectedModels.value.length > 0 || selectedUseCases.value.length > 0 || selectedRunsOn.value.length > 0 || sortBy.value !== "default";
      if (hasActiveFilters) {
        debouncedTrackFilterChange();
      }
    },
    { deep: true }
  );
  watchDebounced(
    selectedModels,
    (newValue) => {
      void settingStore.set("Comfy.Templates.SelectedModels", newValue);
    },
    { debounce: 500, deep: true }
  );
  watchDebounced(
    selectedUseCases,
    (newValue) => {
      void settingStore.set("Comfy.Templates.SelectedUseCases", newValue);
    },
    { debounce: 500, deep: true }
  );
  watchDebounced(
    selectedRunsOn,
    (newValue) => {
      void settingStore.set("Comfy.Templates.SelectedRunsOn", newValue);
    },
    { debounce: 500, deep: true }
  );
  watchDebounced(
    sortBy,
    (newValue) => {
      void settingStore.set("Comfy.Templates.SortBy", newValue);
    },
    { debounce: 500 }
  );
  return {
    // State
    searchQuery,
    selectedModels,
    selectedUseCases,
    selectedRunsOn,
    sortBy,
    // Computed
    filteredTemplates,
    availableModels,
    availableUseCases,
    availableRunsOn,
    filteredCount,
    totalCount,
    // Methods
    resetFilters,
    removeModelFilter,
    removeUseCaseFilter,
    removeRunsOnFilter
  };
}
__name(useTemplateFiltering, "useTemplateFiltering");
function useTemplateWorkflows() {
  const { t: t2 } = useI18n();
  const workflowTemplatesStore = useWorkflowTemplatesStore();
  const dialogStore = useDialogStore();
  const selectedTemplate = ref(null);
  const loadingTemplateId = ref(null);
  const isTemplatesLoaded = computed(() => workflowTemplatesStore.isLoaded);
  const allTemplateGroups = computed(
    () => workflowTemplatesStore.groupedTemplates
  );
  const loadTemplates = /* @__PURE__ */ __name(async () => {
    if (!workflowTemplatesStore.isLoaded) {
      await workflowTemplatesStore.loadWorkflowTemplates();
    }
    return workflowTemplatesStore.isLoaded;
  }, "loadTemplates");
  const selectFirstTemplateCategory = /* @__PURE__ */ __name(() => {
    if (allTemplateGroups.value.length > 0) {
      const firstCategory = allTemplateGroups.value[0].modules[0];
      selectTemplateCategory(firstCategory);
    }
  }, "selectFirstTemplateCategory");
  const selectTemplateCategory = /* @__PURE__ */ __name((category) => {
    selectedTemplate.value = category;
    return category !== null;
  }, "selectTemplateCategory");
  const getTemplateThumbnailUrl = /* @__PURE__ */ __name((template, sourceModule, index = "1") => {
    const basePath = sourceModule === "default" ? api.fileURL(`/templates/${template.name}`) : api.apiURL(`/workflow_templates/${sourceModule}/${template.name}`);
    const indexSuffix = sourceModule === "default" && index ? `-${index}` : "";
    return `${basePath}${indexSuffix}.${template.mediaSubtype}`;
  }, "getTemplateThumbnailUrl");
  const getTemplateTitle = /* @__PURE__ */ __name((template, sourceModule) => {
    const fallback = template.title ?? template.name ?? `${sourceModule} Template`;
    return sourceModule === "default" ? template.localizedTitle ?? fallback : fallback;
  }, "getTemplateTitle");
  const getTemplateDescription = /* @__PURE__ */ __name((template) => {
    return (template.localizedDescription || template.description)?.replace(/[-_]/g, " ").trim() ?? "";
  }, "getTemplateDescription");
  const loadWorkflowTemplate = /* @__PURE__ */ __name(async (id, sourceModule) => {
    if (!isTemplatesLoaded.value) return false;
    loadingTemplateId.value = id;
    let json;
    try {
      if (sourceModule === "all") {
        const comfyExamplesGroup = allTemplateGroups.value.find(
          (g) => g.label === t2("templateWorkflows.category.ComfyUI Examples", "ComfyUI Examples")
        );
        const allCategory = comfyExamplesGroup?.modules.find(
          (m) => m.moduleName === "all"
        );
        const template = allCategory?.templates.find((t22) => t22.name === id);
        if (!template || !template.sourceModule) return false;
        const actualSourceModule = template.sourceModule;
        json = await fetchTemplateJson(id, actualSourceModule);
        const workflowName2 = actualSourceModule === "default" ? t2(`templateWorkflows.template.${id}`, id) : id;
        if (isCloud) ;
        dialogStore.closeDialog();
        await app.loadGraphData(json, true, true, workflowName2, {
          openSource: "template"
        });
        return true;
      }
      json = await fetchTemplateJson(id, sourceModule);
      const workflowName = sourceModule === "default" ? t2(`templateWorkflows.template.${id}`, id) : id;
      if (isCloud) ;
      dialogStore.closeDialog();
      await app.loadGraphData(json, true, true, workflowName, {
        openSource: "template"
      });
      return true;
    } catch (error) {
      console.error("Error loading workflow template:", error);
      return false;
    } finally {
      loadingTemplateId.value = null;
    }
  }, "loadWorkflowTemplate");
  const fetchTemplateJson = /* @__PURE__ */ __name(async (id, sourceModule) => {
    if (sourceModule === "default") {
      return fetch(api.fileURL(`/templates/${id}.json`)).then((r) => r.json());
    } else {
      return fetch(
        api.apiURL(`/workflow_templates/${sourceModule}/${id}.json`)
      ).then((r) => r.json());
    }
  }, "fetchTemplateJson");
  return {
    // State
    selectedTemplate,
    loadingTemplateId,
    // Computed
    isTemplatesLoaded,
    allTemplateGroups,
    // Methods
    loadTemplates,
    selectFirstTemplateCategory,
    selectTemplateCategory,
    getTemplateThumbnailUrl,
    getTemplateTitle,
    getTemplateDescription,
    loadWorkflowTemplate
  };
}
__name(useTemplateWorkflows, "useTemplateWorkflows");
function createGridStyle(options = {}) {
  const {
    minWidth = "15rem",
    maxWidth = "1fr",
    padding = "0",
    gap = "1rem",
    columns
  } = options;
  if (columns !== void 0 && columns < 1) {
    console.warn("createGridStyle: columns must be >= 1, defaulting to 1");
  }
  const gridTemplateColumns = columns ? `repeat(${Math.max(1, columns ?? 1)}, 1fr)` : `repeat(auto-fill, minmax(${minWidth}, ${maxWidth}))`;
  return {
    display: "grid",
    gridTemplateColumns,
    padding,
    gap
  };
}
__name(createGridStyle, "createGridStyle");
const _hoisted_1$p = { class: "text-neutral text-base" };
const _hoisted_2$j = { class: "flex gap-2" };
const _hoisted_3$g = { class: "relative flex flex-wrap justify-between gap-2 px-6 pb-4" };
const _hoisted_4$c = { class: "flex flex-wrap gap-2" };
const _hoisted_5$b = {
  key: 0,
  class: "text-neutral px-6 pt-4 pb-2 text-2xl font-semibold"
};
const _hoisted_6$a = {
  key: 0,
  class: "flex h-64 flex-col items-center justify-center text-neutral-500"
};
const _hoisted_7$7 = { class: "mb-2 text-lg" };
const _hoisted_8$7 = { class: "text-sm" };
const _hoisted_9$6 = { key: 1 };
const _hoisted_10$6 = {
  key: 0,
  class: "inline-block h-8 w-48 animate-pulse rounded bg-dialog-surface"
};
const _hoisted_11$4 = { class: "relative h-full w-full overflow-hidden rounded-lg" };
const _hoisted_12$3 = { class: "flex flex-col gap-2 pt-3" };
const _hoisted_13$3 = ["title"];
const _hoisted_14$3 = { class: "flex justify-between gap-2" };
const _hoisted_15$2 = { class: "flex-1" };
const _hoisted_16$2 = ["title"];
const _hoisted_17$1 = {
  key: 0,
  class: "flex flex-col-reverse justify-center"
};
const _hoisted_18$1 = {
  key: 0,
  class: "text-sm text-muted"
};
const _hoisted_19$1 = {
  key: 3,
  class: "mt-6 px-6 text-sm text-muted"
};
const _sfc_main$x = /* @__PURE__ */ defineComponent({
  __name: "WorkflowTemplateSelectorDialog",
  props: {
    onClose: { type: Function }
  },
  setup(__props) {
    const { t: t2 } = useI18n();
    const sessionStartTime = ref(0);
    const templateWasSelected = ref(false);
    onMounted(() => {
      sessionStartTime.value = Date.now();
    });
    const onClose = /* @__PURE__ */ __name(() => {
      __props.onClose();
    }, "onClose");
    provide(OnCloseKey, onClose);
    const workflowTemplatesStore = useWorkflowTemplatesStore();
    const {
      loadTemplates,
      loadWorkflowTemplate,
      getTemplateThumbnailUrl,
      getTemplateTitle,
      getTemplateDescription
    } = useTemplateWorkflows();
    const getEffectiveSourceModule = /* @__PURE__ */ __name((template) => template.sourceModule || "default", "getEffectiveSourceModule");
    const getBaseThumbnailSrc = /* @__PURE__ */ __name((template) => {
      const sm = getEffectiveSourceModule(template);
      return getTemplateThumbnailUrl(template, sm, sm === "default" ? "1" : "");
    }, "getBaseThumbnailSrc");
    const getOverlayThumbnailSrc = /* @__PURE__ */ __name((template) => {
      const sm = getEffectiveSourceModule(template);
      return getTemplateThumbnailUrl(template, sm, sm === "default" ? "2" : "");
    }, "getOverlayThumbnailSrc");
    const openTutorial = /* @__PURE__ */ __name((template) => {
      if (template.tutorialUrl) {
        window.open(template.tutorialUrl, "_blank");
      }
    }, "openTutorial");
    const navItems = computed(() => {
      if (isLoading.value) {
        return [
          {
            id: "skeleton-all",
            label: "All Templates",
            icon: "icon-[lucide--layout-grid]"
          },
          {
            id: "skeleton-basics",
            label: "Basics",
            icon: "icon-[lucide--graduation-cap]"
          },
          {
            title: "Generation Type",
            items: [
              { id: "skeleton-1", label: "...", icon: "icon-[lucide--loader-2]" },
              { id: "skeleton-2", label: "...", icon: "icon-[lucide--loader-2]" }
            ]
          },
          {
            title: "Closed Source Models",
            items: [
              { id: "skeleton-3", label: "...", icon: "icon-[lucide--loader-2]" }
            ]
          }
        ];
      }
      return workflowTemplatesStore.navGroupedTemplates;
    });
    const gridStyle = computed(() => createGridStyle());
    const allTemplates = computed(() => {
      return workflowTemplatesStore.enhancedTemplates;
    });
    const navigationFilteredTemplates = computed(() => {
      if (!selectedNavItem.value) {
        return allTemplates.value;
      }
      return workflowTemplatesStore.filterTemplatesByCategory(selectedNavItem.value);
    });
    const {
      searchQuery,
      selectedModels,
      selectedUseCases,
      selectedRunsOn,
      sortBy,
      filteredTemplates,
      availableModels,
      availableUseCases,
      availableRunsOn,
      filteredCount,
      totalCount,
      resetFilters
    } = useTemplateFiltering(navigationFilteredTemplates);
    const selectedModelObjects = computed({
      get() {
        return selectedModels.value.map((model) => ({ name: model, value: model }));
      },
      set(value) {
        selectedModels.value = value.map((item) => item.value);
      }
    });
    const selectedUseCaseObjects = computed({
      get() {
        return selectedUseCases.value.map((useCase) => ({
          name: useCase,
          value: useCase
        }));
      },
      set(value) {
        selectedUseCases.value = value.map((item) => item.value);
      }
    });
    const selectedRunsOnObjects = computed({
      get() {
        return selectedRunsOn.value.map((runsOn) => ({
          name: runsOn,
          value: runsOn
        }));
      },
      set(value) {
        selectedRunsOn.value = value.map((item) => item.value);
      }
    });
    const loadingTemplate = ref(null);
    const hoveredTemplate = ref(null);
    const cardRefs = ref([]);
    const templateListKey = ref(0);
    const selectedNavItem = ref("all");
    const modelSearchText = ref("");
    const modelOptions = computed(
      () => availableModels.value.map((model) => ({
        name: model,
        value: model
      }))
    );
    const useCaseOptions = computed(
      () => availableUseCases.value.map((useCase) => ({
        name: useCase,
        value: useCase
      }))
    );
    const runsOnOptions = computed(
      () => availableRunsOn.value.map((runsOn) => ({
        name: runsOn,
        value: runsOn
      }))
    );
    const modelFilterLabel = computed(() => {
      if (selectedModelObjects.value.length === 0) {
        return t2("templateWorkflows.modelFilter", "Model Filter");
      } else if (selectedModelObjects.value.length === 1) {
        return selectedModelObjects.value[0].name;
      } else {
        return t2("templateWorkflows.modelsSelected", {
          count: selectedModelObjects.value.length
        });
      }
    });
    const useCaseFilterLabel = computed(() => {
      if (selectedUseCaseObjects.value.length === 0) {
        return t2("templateWorkflows.useCaseFilter", "Use Case");
      } else if (selectedUseCaseObjects.value.length === 1) {
        return selectedUseCaseObjects.value[0].name;
      } else {
        return t2("templateWorkflows.useCasesSelected", {
          count: selectedUseCaseObjects.value.length
        });
      }
    });
    const runsOnFilterLabel = computed(() => {
      if (selectedRunsOnObjects.value.length === 0) {
        return t2("templateWorkflows.runsOnFilter", "Runs On");
      } else if (selectedRunsOnObjects.value.length === 1) {
        return selectedRunsOnObjects.value[0].name;
      } else {
        return t2("templateWorkflows.runsOnSelected", {
          count: selectedRunsOnObjects.value.length
        });
      }
    });
    const sortOptions = computed(() => [
      { name: t2("templateWorkflows.sort.newest", "Newest"), value: "newest" },
      {
        name: t2("templateWorkflows.sort.default", "Default"),
        value: "default"
      },
      {
        name: t2("templateWorkflows.sort.vramLowToHigh", "VRAM Usage (Low to High)"),
        value: "vram-low-to-high"
      },
      {
        name: t2(
          "templateWorkflows.sort.modelSizeLowToHigh",
          "Model Size (Low to High)"
        ),
        value: "model-size-low-to-high"
      },
      {
        name: t2("templateWorkflows.sort.alphabetical", "Alphabetical (A-Z)"),
        value: "alphabetical"
      }
    ]);
    const loadTrigger = ref(null);
    const shouldUsePagination = computed(() => !searchQuery.value.trim());
    const {
      paginatedItems: paginatedTemplates,
      isLoading: isLoadingMore,
      hasMoreItems: hasMoreTemplates,
      loadNextPage,
      reset: resetPagination
    } = useLazyPagination(filteredTemplates, { itemsPerPage: 24 });
    const displayTemplates = computed(() => {
      return shouldUsePagination.value ? paginatedTemplates.value : filteredTemplates.value;
    });
    useIntersectionObserver(loadTrigger, () => {
      if (shouldUsePagination.value && hasMoreTemplates.value && !isLoadingMore.value) {
        void loadNextPage();
      }
    });
    watch(
      [
        searchQuery,
        selectedNavItem,
        sortBy,
        selectedModels,
        selectedUseCases,
        selectedRunsOn
      ],
      () => {
        resetPagination();
        loadingTemplate.value = null;
        templateListKey.value++;
      }
    );
    const onLoadWorkflow = /* @__PURE__ */ __name(async (template) => {
      loadingTemplate.value = template.name;
      try {
        await loadWorkflowTemplate(
          template.name,
          getEffectiveSourceModule(template)
        );
        templateWasSelected.value = true;
        onClose();
      } finally {
        loadingTemplate.value = null;
      }
    }, "onLoadWorkflow");
    const pageTitle = computed(() => {
      const navItem = navItems.value.find(
        (item) => "id" in item ? item.id === selectedNavItem.value : item.items?.some((sub) => sub.id === selectedNavItem.value)
      );
      if (!navItem) {
        return t2("templateWorkflows.allTemplates", "All Templates");
      }
      return "id" in navItem ? navItem.label : navItem.items?.find((i) => i.id === selectedNavItem.value)?.label || t2("templateWorkflows.allTemplates", "All Templates");
    });
    const { isLoading } = useAsyncState(
      async () => {
        await Promise.all([
          loadTemplates(),
          workflowTemplatesStore.loadWorkflowTemplates()
        ]);
        return true;
      },
      false,
      // initial state
      {
        immediate: true
        // Start loading immediately
      }
    );
    onBeforeUnmount(() => {
      cardRefs.value = [];
    });
    return (_ctx, _cache) => {
      const _directive_tooltip = resolveDirective("tooltip");
      return openBlock(), createBlock(BaseModalLayout, {
        "content-title": _ctx.$t("templateWorkflows.title", "Workflow Templates"),
        class: "workflow-template-selector-dialog"
      }, {
        leftPanel: withCtx(() => [
          createVNode(_sfc_main$1S, {
            modelValue: selectedNavItem.value,
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => selectedNavItem.value = $event),
            "nav-items": navItems.value
          }, {
            "header-icon": withCtx(() => _cache[8] || (_cache[8] = [
              createBaseVNode("i", { class: "icon-[comfy--template]" }, null, -1)
            ])),
            "header-title": withCtx(() => [
              createBaseVNode("span", _hoisted_1$p, toDisplayString(_ctx.$t("sideToolbar.templates", "Templates")), 1)
            ]),
            _: 1
          }, 8, ["modelValue", "nav-items"])
        ]),
        header: withCtx(() => [
          createVNode(SearchBox, {
            modelValue: unref(searchQuery),
            "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => isRef(searchQuery) ? searchQuery.value = $event : null),
            size: "lg",
            class: "max-w-[384px]"
          }, null, 8, ["modelValue"])
        ]),
        "header-right-area": withCtx(() => [
          createBaseVNode("div", _hoisted_2$j, [
            unref(filteredCount) !== unref(totalCount) ? (openBlock(), createBlock(_sfc_main$1Y, {
              key: 0,
              variant: "secondary",
              size: "lg",
              onClick: unref(resetFilters)
            }, {
              default: withCtx(() => [
                _cache[9] || (_cache[9] = createBaseVNode("i", { class: "icon-[lucide--filter-x]" }, null, -1)),
                createBaseVNode("span", null, toDisplayString(_ctx.$t("templateWorkflows.resetFilters", "Clear Filters")), 1)
              ]),
              _: 1
            }, 8, ["onClick"])) : createCommentVNode("", true)
          ])
        ]),
        contentFilter: withCtx(() => [
          createBaseVNode("div", _hoisted_3$g, [
            createBaseVNode("div", _hoisted_4$c, [
              createVNode(_sfc_main$1R, {
                modelValue: selectedModelObjects.value,
                "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => selectedModelObjects.value = $event),
                "search-query": modelSearchText.value,
                "onUpdate:searchQuery": _cache[3] || (_cache[3] = ($event) => modelSearchText.value = $event),
                class: "w-[250px]",
                label: modelFilterLabel.value,
                options: modelOptions.value,
                "show-search-box": true,
                "show-selected-count": true,
                "show-clear-button": true
              }, {
                icon: withCtx(() => _cache[10] || (_cache[10] = [
                  createBaseVNode("i", { class: "icon-[lucide--cpu]" }, null, -1)
                ])),
                _: 1
              }, 8, ["modelValue", "search-query", "label", "options"]),
              createVNode(_sfc_main$1R, {
                modelValue: selectedUseCaseObjects.value,
                "onUpdate:modelValue": _cache[4] || (_cache[4] = ($event) => selectedUseCaseObjects.value = $event),
                label: useCaseFilterLabel.value,
                options: useCaseOptions.value,
                "show-search-box": true,
                "show-selected-count": true,
                "show-clear-button": true
              }, {
                icon: withCtx(() => _cache[11] || (_cache[11] = [
                  createBaseVNode("i", { class: "icon-[lucide--target]" }, null, -1)
                ])),
                _: 1
              }, 8, ["modelValue", "label", "options"]),
              createVNode(_sfc_main$1R, {
                modelValue: selectedRunsOnObjects.value,
                "onUpdate:modelValue": _cache[5] || (_cache[5] = ($event) => selectedRunsOnObjects.value = $event),
                label: runsOnFilterLabel.value,
                options: runsOnOptions.value,
                "show-search-box": true,
                "show-selected-count": true,
                "show-clear-button": true
              }, {
                icon: withCtx(() => _cache[12] || (_cache[12] = [
                  createBaseVNode("i", { class: "icon-[lucide--server]" }, null, -1)
                ])),
                _: 1
              }, 8, ["modelValue", "label", "options"])
            ]),
            createBaseVNode("div", null, [
              createVNode(_sfc_main$1Z, {
                modelValue: unref(sortBy),
                "onUpdate:modelValue": _cache[6] || (_cache[6] = ($event) => isRef(sortBy) ? sortBy.value = $event : null),
                label: _ctx.$t("templateWorkflows.sorting", "Sort by"),
                options: sortOptions.value,
                class: "w-62.5"
              }, {
                icon: withCtx(() => _cache[13] || (_cache[13] = [
                  createBaseVNode("i", { class: "icon-[lucide--arrow-up-down] text-muted-foreground" }, null, -1)
                ])),
                _: 1
              }, 8, ["modelValue", "label", "options"])
            ])
          ]),
          !unref(isLoading) ? (openBlock(), createElementBlock("div", _hoisted_5$b, [
            createBaseVNode("span", null, toDisplayString(pageTitle.value), 1)
          ])) : createCommentVNode("", true)
        ]),
        content: withCtx(() => [
          !unref(isLoading) && unref(filteredTemplates).length === 0 ? (openBlock(), createElementBlock("div", _hoisted_6$a, [
            _cache[14] || (_cache[14] = createBaseVNode("i", { class: "mb-4 icon-[lucide--search] h-12 w-12 opacity-50" }, null, -1)),
            createBaseVNode("p", _hoisted_7$7, toDisplayString(_ctx.$t("templateWorkflows.noResults", "No templates found")), 1),
            createBaseVNode("p", _hoisted_8$7, toDisplayString(_ctx.$t(
              "templateWorkflows.noResultsHint",
              "Try adjusting your search or filters"
            )), 1)
          ])) : (openBlock(), createElementBlock("div", _hoisted_9$6, [
            unref(isLoading) ? (openBlock(), createElementBlock("span", _hoisted_10$6)) : createCommentVNode("", true),
            (openBlock(), createElementBlock("div", {
              key: templateListKey.value,
              style: normalizeStyle(gridStyle.value),
              "data-testid": "template-workflows-content"
            }, [
              (openBlock(true), createElementBlock(Fragment, null, renderList(unref(isLoading) ? 12 : 0, (n) => {
                return openBlock(), createBlock(_sfc_main$25, {
                  key: `initial-skeleton-${n}`,
                  size: "compact",
                  variant: "ghost",
                  rounded: "lg",
                  class: "hover:bg-base-background"
                }, {
                  top: withCtx(() => [
                    createVNode(_sfc_main$27, { ratio: "landscape" }, {
                      default: withCtx(() => _cache[15] || (_cache[15] = [
                        createBaseVNode("div", { class: "h-full w-full animate-pulse bg-dialog-surface" }, null, -1)
                      ])),
                      _: 1
                    })
                  ]),
                  bottom: withCtx(() => [
                    createVNode(_sfc_main$26, null, {
                      default: withCtx(() => _cache[16] || (_cache[16] = [
                        createBaseVNode("div", { class: "px-4 py-3" }, [
                          createBaseVNode("div", { class: "mb-2 h-6 animate-pulse rounded bg-dialog-surface" }),
                          createBaseVNode("div", { class: "h-4 animate-pulse rounded bg-dialog-surface" })
                        ], -1)
                      ])),
                      _: 1
                    })
                  ]),
                  _: 2
                }, 1024);
              }), 128)),
              (openBlock(true), createElementBlock(Fragment, null, renderList(unref(isLoading) ? [] : displayTemplates.value, (template) => {
                return openBlock(), createBlock(_sfc_main$25, {
                  key: template.name,
                  ref_for: true,
                  ref_key: "cardRefs",
                  ref: cardRefs,
                  size: "compact",
                  variant: "ghost",
                  rounded: "lg",
                  "data-testid": `template-workflow-${template.name}`,
                  class: "hover:bg-base-background",
                  onMouseenter: /* @__PURE__ */ __name(($event) => hoveredTemplate.value = template.name, "onMouseenter"),
                  onMouseleave: _cache[7] || (_cache[7] = ($event) => hoveredTemplate.value = null),
                  onClick: /* @__PURE__ */ __name(($event) => onLoadWorkflow(template), "onClick")
                }, {
                  top: withCtx(() => [
                    createVNode(_sfc_main$27, { ratio: "square" }, {
                      default: withCtx(() => [
                        createBaseVNode("div", _hoisted_11$4, [
                          template.mediaType === "audio" ? (openBlock(), createBlock(_sfc_main$B, {
                            key: 0,
                            src: getBaseThumbnailSrc(template)
                          }, null, 8, ["src"])) : template.thumbnailVariant === "compareSlider" ? (openBlock(), createBlock(_sfc_main$A, {
                            key: 1,
                            "base-image-src": getBaseThumbnailSrc(template),
                            "overlay-image-src": getOverlayThumbnailSrc(template),
                            alt: unref(getTemplateTitle)(
                              template,
                              getEffectiveSourceModule(template)
                            ),
                            "is-hovered": hoveredTemplate.value === template.name,
                            "is-video": template.mediaType === "video" || template.mediaSubtype === "webp"
                          }, null, 8, ["base-image-src", "overlay-image-src", "alt", "is-hovered", "is-video"])) : template.thumbnailVariant === "hoverDissolve" ? (openBlock(), createBlock(_sfc_main$y, {
                            key: 2,
                            "base-image-src": getBaseThumbnailSrc(template),
                            "overlay-image-src": getOverlayThumbnailSrc(template),
                            alt: unref(getTemplateTitle)(
                              template,
                              getEffectiveSourceModule(template)
                            ),
                            "is-hovered": hoveredTemplate.value === template.name,
                            "is-video": template.mediaType === "video" || template.mediaSubtype === "webp"
                          }, null, 8, ["base-image-src", "overlay-image-src", "alt", "is-hovered", "is-video"])) : (openBlock(), createBlock(_sfc_main$z, {
                            key: 3,
                            src: getBaseThumbnailSrc(template),
                            alt: unref(getTemplateTitle)(
                              template,
                              getEffectiveSourceModule(template)
                            ),
                            "is-hovered": hoveredTemplate.value === template.name,
                            "is-video": template.mediaType === "video" || template.mediaSubtype === "webp",
                            "hover-zoom": template.thumbnailVariant === "zoomHover" ? 16 : 5
                          }, null, 8, ["src", "alt", "is-hovered", "is-video", "hover-zoom"])),
                          loadingTemplate.value === template.name ? (openBlock(), createBlock(unref(script$n), {
                            key: 4,
                            class: "absolute inset-0 z-10 m-auto h-12 w-12"
                          })) : createCommentVNode("", true)
                        ])
                      ]),
                      "bottom-right": withCtx(() => [
                        template.tags && template.tags.length > 0 ? (openBlock(true), createElementBlock(Fragment, { key: 0 }, renderList(template.tags, (tag) => {
                          return openBlock(), createBlock(_sfc_main$28, {
                            key: tag,
                            label: tag
                          }, null, 8, ["label"]);
                        }), 128)) : createCommentVNode("", true)
                      ]),
                      _: 2
                    }, 1024)
                  ]),
                  bottom: withCtx(() => [
                    createVNode(_sfc_main$26, null, {
                      default: withCtx(() => [
                        createBaseVNode("div", _hoisted_12$3, [
                          createBaseVNode("h3", {
                            class: "m-0 line-clamp-1 text-sm",
                            title: unref(getTemplateTitle)(
                              template,
                              getEffectiveSourceModule(template)
                            )
                          }, toDisplayString(unref(getTemplateTitle)(
                            template,
                            getEffectiveSourceModule(template)
                          )), 9, _hoisted_13$3),
                          createBaseVNode("div", _hoisted_14$3, [
                            createBaseVNode("div", _hoisted_15$2, [
                              createBaseVNode("p", {
                                class: "m-0 line-clamp-2 text-sm text-muted",
                                title: unref(getTemplateDescription)(template)
                              }, toDisplayString(unref(getTemplateDescription)(template)), 9, _hoisted_16$2)
                            ]),
                            template.tutorialUrl ? (openBlock(), createElementBlock("div", _hoisted_17$1, [
                              hoveredTemplate.value === template.name ? withDirectives((openBlock(), createBlock(_sfc_main$1Y, mergeProps({
                                key: 0,
                                ref_for: true
                              }, _ctx.$attrs, {
                                variant: "inverted",
                                size: "icon",
                                onClick: withModifiers(($event) => openTutorial(template), ["stop"])
                              }), {
                                default: withCtx(() => _cache[17] || (_cache[17] = [
                                  createBaseVNode("i", { class: "icon-[lucide--info] size-4" }, null, -1)
                                ])),
                                _: 2
                              }, 1040, ["onClick"])), [
                                [
                                  _directive_tooltip,
                                  _ctx.$t("g.seeTutorial"),
                                  void 0,
                                  { bottom: true }
                                ]
                              ]) : createCommentVNode("", true)
                            ])) : createCommentVNode("", true)
                          ])
                        ])
                      ]),
                      _: 2
                    }, 1024)
                  ]),
                  _: 2
                }, 1032, ["data-testid", "onMouseenter", "onClick"]);
              }), 128)),
              (openBlock(true), createElementBlock(Fragment, null, renderList(unref(isLoadingMore) ? 6 : 0, (n) => {
                return openBlock(), createBlock(_sfc_main$25, {
                  key: `skeleton-${n}`,
                  size: "compact",
                  variant: "ghost",
                  rounded: "lg",
                  class: "hover:bg-base-background"
                }, {
                  top: withCtx(() => [
                    createVNode(_sfc_main$27, { ratio: "square" }, {
                      default: withCtx(() => _cache[18] || (_cache[18] = [
                        createBaseVNode("div", { class: "h-full w-full animate-pulse bg-dialog-surface" }, null, -1)
                      ])),
                      _: 1
                    })
                  ]),
                  bottom: withCtx(() => [
                    createVNode(_sfc_main$26, null, {
                      default: withCtx(() => _cache[19] || (_cache[19] = [
                        createBaseVNode("div", { class: "px-4 py-3" }, [
                          createBaseVNode("div", { class: "mb-2 h-6 animate-pulse rounded bg-dialog-surface" }),
                          createBaseVNode("div", { class: "h-4 animate-pulse rounded bg-dialog-surface" })
                        ], -1)
                      ])),
                      _: 1
                    })
                  ]),
                  _: 2
                }, 1024);
              }), 128))
            ], 4))
          ])),
          !unref(isLoading) && unref(hasMoreTemplates) ? (openBlock(), createElementBlock("div", {
            key: 2,
            ref_key: "loadTrigger",
            ref: loadTrigger,
            class: "mt-4 flex h-4 w-full items-center justify-center"
          }, [
            unref(isLoadingMore) ? (openBlock(), createElementBlock("div", _hoisted_18$1, toDisplayString(_ctx.$t("templateWorkflows.loadingMore", "Loading more...")), 1)) : createCommentVNode("", true)
          ], 512)) : createCommentVNode("", true),
          !unref(isLoading) ? (openBlock(), createElementBlock("div", _hoisted_19$1, toDisplayString(_ctx.$t("templateWorkflows.resultsCount", {
            count: unref(filteredCount),
            total: unref(totalCount)
          })), 1)) : createCommentVNode("", true)
        ]),
        _: 1
      }, 8, ["content-title"]);
    };
  }
});
const DIALOG_KEY$1 = "global-workflow-template-selector";
const useWorkflowTemplateSelectorDialog = /* @__PURE__ */ __name(() => {
  const dialogService = useDialogService();
  const dialogStore = useDialogStore();
  function hide() {
    dialogStore.closeDialog({ key: DIALOG_KEY$1 });
  }
  __name(hide, "hide");
  function show(source = "command") {
    dialogService.showLayoutDialog({
      key: DIALOG_KEY$1,
      component: _sfc_main$x,
      props: {
        onClose: hide
      },
      dialogComponentProps: {
        pt: {
          content: { class: "!px-0 overflow-hidden h-full !py-0" },
          root: {
            style: "width: 90vw; height: 85vh; max-width: 1400px; display: flex;"
          }
        }
      }
    });
  }
  __name(show, "show");
  return {
    show,
    hide
  };
}, "useWorkflowTemplateSelectorDialog");
const whileMouseDown = /* @__PURE__ */ __name((elementOrEvent, callback, interval = 30) => {
  const element = elementOrEvent instanceof HTMLElement ? elementOrEvent : elementOrEvent.target;
  let iteration = 0;
  const intervalId = setInterval(() => {
    callback(iteration++);
  }, interval);
  const dispose = /* @__PURE__ */ __name(() => {
    clearInterval(intervalId);
    disposeGlobal();
    disposeLocal();
  }, "dispose");
  const disposeGlobal = useEventListener(document, "mouseup", dispose);
  const disposeLocal = useEventListener(element, "mouseup", dispose);
  return {
    dispose
  };
}, "whileMouseDown");
const _hoisted_1$o = { class: "flex h-8 w-8 items-center justify-center rounded-lg bg-black" };
const _hoisted_2$i = ["href", "onMousedown", "onClick"];
const _hoisted_3$f = { class: "p-menubar-item-label text-nowrap" };
const _hoisted_4$b = {
  key: 3,
  class: "keybinding-tag ml-auto rounded border border-surface p-1 text-xs text-nowrap text-muted"
};
const _hoisted_5$a = {
  key: 4,
  class: "pi pi-angle-right ml-auto"
};
const _hoisted_6$9 = { class: "p-menubar-item-label text-nowrap" };
const _sfc_main$w = /* @__PURE__ */ defineComponent({
  __name: "ComfyMenuButton",
  setup(__props) {
    const { t: t2 } = useI18n();
    const commandStore = useCommandStore();
    const menuItemStore = useMenuItemStore();
    const colorPaletteStore = useColorPaletteStore();
    const colorPaletteService = useColorPaletteService();
    const dialogStore = useDialogStore();
    const managerState = useManagerState();
    const settingStore = useSettingStore();
    const menuRef = ref(null);
    const nodes2Enabled = computed({
      get: /* @__PURE__ */ __name(() => settingStore.get("Comfy.VueNodes.Enabled") ?? false, "get"),
      set: /* @__PURE__ */ __name(async (value) => {
        await settingStore.set("Comfy.VueNodes.Enabled", value);
      }, "set")
    });
    function onLogoMenuClick(event) {
      menuRef.value?.toggle(event);
    }
    __name(onLogoMenuClick, "onLogoMenuClick");
    const translateMenuItem = /* @__PURE__ */ __name((item) => {
      const label = typeof item.label === "function" ? item.label() : item.label;
      const translatedLabel = label ? t2(`menuLabels.${normalizeI18nKey(label)}`, label) : void 0;
      return {
        ...item,
        label: translatedLabel,
        items: item.items?.map(translateMenuItem)
      };
    }, "translateMenuItem");
    const showSettings = /* @__PURE__ */ __name((defaultPanel) => {
      dialogStore.showDialog({
        key: "global-settings",
        headerComponent: SettingDialogHeader,
        component: SettingDialogContent,
        props: {
          defaultPanel
        }
      });
    }, "showSettings");
    const showManageExtensions = /* @__PURE__ */ __name(async () => {
      await managerState.openManager({
        initialTab: ManagerTab.All,
        showToastOnLegacyError: false
      });
    }, "showManageExtensions");
    const themeMenuItems = computed(() => {
      return colorPaletteStore.palettes.map((palette) => ({
        key: `theme-${palette.id}`,
        label: palette.name,
        parentPath: "theme",
        comfyCommand: {
          active: /* @__PURE__ */ __name(() => colorPaletteStore.activePaletteId === palette.id, "active")
        },
        command: /* @__PURE__ */ __name(async () => {
          await colorPaletteService.loadColorPalette(palette.id);
        }, "command")
      }));
    });
    const extraMenuItems = computed(() => [
      { separator: true },
      {
        key: "theme",
        label: t2("menu.theme"),
        items: themeMenuItems.value
      },
      {
        key: "nodes-2.0-toggle",
        label: "Nodes 2.0"
      },
      { separator: true },
      {
        key: "browse-templates",
        label: t2("menuLabels.Browse Templates"),
        icon: "icon-[comfy--template]",
        command: /* @__PURE__ */ __name(() => useWorkflowTemplateSelectorDialog().show("menu"), "command")
      },
      {
        key: "settings",
        label: t2("g.settings"),
        icon: "mdi mdi-cog-outline",
        command: /* @__PURE__ */ __name(() => {
          showSettings();
        }, "command")
      },
      {
        key: "manage-extensions",
        label: t2("menu.manageExtensions"),
        icon: "mdi mdi-puzzle-outline",
        command: showManageExtensions
      }
    ]);
    const translatedItems = computed(() => {
      const items = menuItemStore.menuItems.map(translateMenuItem);
      let helpIndex = items.findIndex((item) => item.key === "Help");
      let helpItem;
      if (helpIndex !== -1) {
        items[helpIndex].icon = "mdi mdi-help-circle-outline";
        const isLastItem = helpIndex !== items.length - 1;
        helpItem = items.splice(
          helpIndex,
          1,
          ...isLastItem ? [
            {
              separator: true
            }
          ] : []
        )[0];
      }
      helpIndex = items.length;
      items.splice(
        helpIndex,
        0,
        ...extraMenuItems.value,
        ...helpItem ? [
          {
            separator: true
          },
          helpItem
        ] : []
      );
      return items;
    });
    const onMenuShow = /* @__PURE__ */ __name(() => {
      void nextTick(() => {
        if (menuRef.value) {
          menuRef.value.dirty = true;
        }
      });
    }, "onMenuShow");
    const isZoomCommand = /* @__PURE__ */ __name((item) => {
      return item.comfyCommand?.id === "Comfy.Canvas.ZoomIn" || item.comfyCommand?.id === "Comfy.Canvas.ZoomOut";
    }, "isZoomCommand");
    const handleZoomMouseDown = /* @__PURE__ */ __name((item, event) => {
      if (item.comfyCommand) {
        whileMouseDown(
          event,
          async () => {
            await commandStore.execute(item.comfyCommand.id);
          },
          50
        );
      }
    }, "handleZoomMouseDown");
    const handleItemClick = /* @__PURE__ */ __name((item, event) => {
      if (isZoomCommand(item) || item.comfyCommand?.active) {
        event.preventDefault();
        event.stopPropagation();
        if (item.comfyCommand?.active) {
          item.command?.({
            item,
            originalEvent: event
          });
        }
        return false;
      }
    }, "handleItemClick");
    const hasActiveStateSiblings = /* @__PURE__ */ __name((item) => {
      return item.parentPath && (item.parentPath === "theme" || menuItemStore.menuItemHasActiveStateChildren[item.parentPath]);
    }, "hasActiveStateSiblings");
    const handleNodes2ToggleClick = /* @__PURE__ */ __name(() => {
      return false;
    }, "handleNodes2ToggleClick");
    const onNodes2ToggleChange = /* @__PURE__ */ __name(async (value) => {
      await settingStore.set("Comfy.VueNodes.Enabled", value);
    }, "onNodes2ToggleChange");
    return (_ctx, _cache) => {
      const _directive_tooltip = resolveDirective("tooltip");
      return openBlock(), createElementBlock(Fragment, null, [
        withDirectives((openBlock(), createElementBlock("div", {
          class: normalizeClass(["comfy-menu-button-wrapper flex shrink-0 cursor-pointer flex-col items-center justify-center p-2 transition-colors", {
            "comfy-menu-button-active": menuRef.value?.visible
          }]),
          onClick: _cache[0] || (_cache[0] = ($event) => onLogoMenuClick($event))
        }, [
          createBaseVNode("div", _hoisted_1$o, [
            createVNode(_sfc_main$D, {
              alt: "ComfyUI Logo",
              class: "comfyui-logo h-[18px] w-[18px] text-white",
              mode: "fill"
            })
          ])
        ], 2)), [
          [_directive_tooltip, {
            value: unref(t2)("sideToolbar.labels.menu"),
            showDelay: 300,
            hideDelay: 300
          }]
        ]),
        createVNode(unref(script$o), {
          ref_key: "menuRef",
          ref: menuRef,
          model: translatedItems.value,
          popup: true,
          class: "comfy-command-menu",
          onShow: onMenuShow
        }, {
          item: withCtx(({ item, props }) => [
            item.key !== "nodes-2.0-toggle" ? (openBlock(), createElementBlock("a", mergeProps({
              key: 0,
              class: "p-menubar-item-link px-4 py-2"
            }, props.action, {
              href: item.url,
              target: "_blank",
              class: typeof item.class === "function" ? item.class() : item.class,
              onMousedown: /* @__PURE__ */ __name(($event) => isZoomCommand(item) ? handleZoomMouseDown(item, $event) : void 0, "onMousedown"),
              onClick: /* @__PURE__ */ __name(($event) => handleItemClick(item, $event), "onClick")
            }), [
              hasActiveStateSiblings(item) ? (openBlock(), createElementBlock("i", {
                key: 0,
                class: normalizeClass(["p-menubar-item-icon pi pi-check text-sm", { invisible: !item.comfyCommand?.active?.() }])
              }, null, 2)) : item.icon && item.comfyCommand?.id !== "Comfy.NewBlankWorkflow" ? (openBlock(), createElementBlock("span", {
                key: 1,
                class: normalizeClass(["p-menubar-item-icon text-sm", item.icon])
              }, null, 2)) : createCommentVNode("", true),
              createBaseVNode("span", _hoisted_3$f, toDisplayString(item.label), 1),
              item.comfyCommand?.id === "Comfy.NewBlankWorkflow" ? (openBlock(), createElementBlock("i", {
                key: 2,
                class: normalizeClass(["ml-auto", item.icon])
              }, null, 2)) : createCommentVNode("", true),
              item?.comfyCommand?.keybinding ? (openBlock(), createElementBlock("span", _hoisted_4$b, toDisplayString(item.comfyCommand.keybinding.combo.toString()), 1)) : createCommentVNode("", true),
              item.items ? (openBlock(), createElementBlock("i", _hoisted_5$a)) : createCommentVNode("", true)
            ], 16, _hoisted_2$i)) : (openBlock(), createElementBlock("div", {
              key: 1,
              class: "flex items-center justify-between px-4 py-2",
              onClick: withModifiers(handleNodes2ToggleClick, ["stop"])
            }, [
              createBaseVNode("span", _hoisted_6$9, toDisplayString(item.label), 1),
              createVNode(unref(script$6), {
                severity: "info",
                class: "ml-2 text-xs"
              }, {
                default: withCtx(() => [
                  createTextVNode(toDisplayString(_ctx.$t("g.beta")), 1)
                ]),
                _: 1
              }),
              createVNode(unref(script$j), {
                modelValue: nodes2Enabled.value,
                "onUpdate:modelValue": [
                  _cache[1] || (_cache[1] = ($event) => nodes2Enabled.value = $event),
                  onNodes2ToggleChange
                ],
                class: "ml-4",
                "aria-label": item.label,
                pt: {
                  root: {
                    style: {
                      width: "38px",
                      height: "20px"
                    }
                  },
                  handle: {
                    style: {
                      width: "16px",
                      height: "16px"
                    }
                  }
                },
                onClick: _cache[2] || (_cache[2] = withModifiers(() => {
                }, ["stop"]))
              }, null, 8, ["modelValue", "aria-label"])
            ]))
          ]),
          _: 1
        }, 8, ["model"])
      ], 64);
    };
  }
});
const ComfyMenuButton = /* @__PURE__ */ _export_sfc(_sfc_main$w, [["__scopeId", "data-v-7f8c3b49"]]);
const _hoisted_1$n = { class: "side-bar-button-content" };
const _hoisted_2$h = {
  key: 0,
  class: "side-bar-button-label"
};
const _sfc_main$v = /* @__PURE__ */ defineComponent({
  __name: "SidebarIcon",
  props: {
    icon: { default: "" },
    selected: { type: Boolean, default: false },
    tooltip: { default: "" },
    tooltipSuffix: { default: "" },
    iconBadge: { type: [String, Function], default: "" },
    label: { default: "" },
    isSmall: { type: Boolean, default: false }
  },
  emits: ["click"],
  setup(__props, { emit: __emit }) {
    const { t: t2 } = useI18n();
    const emit = __emit;
    const overlayValue = computed(
      () => typeof __props.iconBadge === "function" ? __props.iconBadge() ?? "" : __props.iconBadge
    );
    const shouldShowBadge = computed(() => !!overlayValue.value);
    const computedTooltip = computed(() => t2(__props.tooltip) + __props.tooltipSuffix);
    return (_ctx, _cache) => {
      const _directive_tooltip = resolveDirective("tooltip");
      return withDirectives((openBlock(), createBlock(_sfc_main$1Y, {
        class: normalizeClass(
          unref(cn)(
            "side-bar-button cursor-pointer border-none",
            _ctx.selected && "side-bar-button-selected"
          )
        ),
        variant: "muted-textonly",
        "aria-label": computedTooltip.value,
        onClick: _cache[0] || (_cache[0] = ($event) => emit("click", $event))
      }, {
        default: withCtx(() => [
          createBaseVNode("div", _hoisted_1$n, [
            renderSlot(_ctx.$slots, "icon", {}, () => [
              shouldShowBadge.value ? (openBlock(), createBlock(unref(script$p), {
                key: 0,
                value: overlayValue.value
              }, {
                default: withCtx(() => [
                  typeof _ctx.icon === "string" ? (openBlock(), createElementBlock("i", {
                    key: 0,
                    class: normalizeClass(_ctx.icon + " side-bar-button-icon")
                  }, null, 2)) : (openBlock(), createBlock(resolveDynamicComponent(_ctx.icon), {
                    key: 1,
                    class: "side-bar-button-icon"
                  }))
                ]),
                _: 1
              }, 8, ["value"])) : typeof _ctx.icon === "string" ? (openBlock(), createElementBlock("i", {
                key: 1,
                class: normalizeClass(_ctx.icon + " side-bar-button-icon")
              }, null, 2)) : typeof _ctx.icon === "object" ? (openBlock(), createBlock(resolveDynamicComponent(_ctx.icon), {
                key: 2,
                class: "side-bar-button-icon"
              })) : createCommentVNode("", true)
            ], true),
            _ctx.label && !_ctx.isSmall ? (openBlock(), createElementBlock("span", _hoisted_2$h, toDisplayString(unref(t2)(_ctx.label)), 1)) : createCommentVNode("", true)
          ])
        ]),
        _: 3
      }, 8, ["class", "aria-label"])), [
        [_directive_tooltip, {
          value: computedTooltip.value,
          showDelay: 300,
          hideDelay: 300
        }]
      ]);
    };
  }
});
const SidebarIcon = /* @__PURE__ */ _export_sfc(_sfc_main$v, [["__scopeId", "data-v-bbb98ec9"]]);
const _sfc_main$u = /* @__PURE__ */ defineComponent({
  __name: "SidebarBottomPanelToggleButton",
  setup(__props) {
    const bottomPanelStore = useBottomPanelStore();
    const toggleConsole = /* @__PURE__ */ __name(() => {
      bottomPanelStore.toggleBottomPanel();
    }, "toggleConsole");
    return (_ctx, _cache) => {
      return openBlock(), createBlock(SidebarIcon, {
        icon: "icon-[ph--terminal-bold]",
        label: _ctx.$t("sideToolbar.labels.console"),
        tooltip: _ctx.$t("menu.toggleBottomPanel"),
        selected: unref(bottomPanelStore).activePanel == "terminal",
        onClick: toggleConsole
      }, null, 8, ["label", "tooltip", "selected"]);
    };
  }
});
const _sfc_main$t = /* @__PURE__ */ defineComponent({
  __name: "SidebarSettingsButton",
  setup(__props) {
    const { t: t2 } = useI18n();
    const { getCommand, formatKeySequence } = useCommandStore();
    const command = getCommand("Comfy.ShowSettingsDialog");
    const tooltipText = computed(
      () => `${t2("g.settings")} (${formatKeySequence(command)})`
    );
    const showSettingsDialog = /* @__PURE__ */ __name(() => {
      command.function();
    }, "showSettingsDialog");
    return (_ctx, _cache) => {
      return openBlock(), createBlock(SidebarIcon, {
        icon: "icon-[lucide--settings]",
        label: _ctx.$t("g.settings"),
        tooltip: tooltipText.value,
        onClick: showSettingsDialog
      }, null, 8, ["label", "tooltip"]);
    };
  }
});
const _sfc_main$s = /* @__PURE__ */ defineComponent({
  __name: "SidebarShortcutsToggleButton",
  setup(__props) {
    const { t: t2 } = useI18n();
    const bottomPanelStore = useBottomPanelStore();
    const commandStore = useCommandStore();
    const command = commandStore.getCommand("Workspace.ToggleBottomPanel.Shortcuts");
    const { formatKeySequence } = commandStore;
    const isShortcutsPanelVisible = computed(
      () => bottomPanelStore.activePanel === "shortcuts"
    );
    const tooltipText = computed(
      () => `${t2("shortcuts.keyboardShortcuts")} (${formatKeySequence(command)})`
    );
    const toggleShortcutsPanel = /* @__PURE__ */ __name(() => {
      bottomPanelStore.togglePanel("shortcuts");
    }, "toggleShortcutsPanel");
    return (_ctx, _cache) => {
      return openBlock(), createBlock(SidebarIcon, {
        icon: "icon-[lucide--keyboard]",
        label: _ctx.$t("shortcuts.shortcuts"),
        tooltip: tooltipText.value,
        selected: isShortcutsPanelVisible.value,
        onClick: toggleShortcutsPanel
      }, null, 8, ["label", "tooltip", "selected"]);
    };
  }
});
const _hoisted_1$m = ["width", "height"];
const _hoisted_2$g = { "clip-path": "url(#clip0_1099_16244)" };
const _hoisted_3$e = ["stroke"];
const _sfc_main$r = /* @__PURE__ */ defineComponent({
  __name: "PuzzleIcon",
  props: {
    size: { default: 16 },
    color: { default: "currentColor" },
    class: {}
  },
  setup(__props) {
    const iconClass = computed(() => __props.class || "");
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: _ctx.size,
        height: _ctx.size,
        viewBox: "0 0 16 16",
        fill: "none",
        class: normalizeClass(iconClass.value)
      }, [
        createBaseVNode("g", _hoisted_2$g, [
          createBaseVNode("path", {
            d: "M4.99992 3.00016C4.99992 2.07969 5.74611 1.3335 6.66658 1.3335C7.58706 1.3335 8.33325 2.07969 8.33325 3.00016V4.00016H8.99992C9.9318 4.00016 10.3977 4.00016 10.7653 4.1524C11.2553 4.35539 11.6447 4.74474 11.8477 5.2348C11.9999 5.60234 11.9999 6.06828 11.9999 7.00016H12.9999C13.9204 7.00016 14.6666 7.74635 14.6666 8.66683C14.6666 9.5873 13.9204 10.3335 12.9999 10.3335H11.9999V11.4668C11.9999 12.5869 11.9999 13.147 11.7819 13.5748C11.5902 13.9511 11.2842 14.2571 10.9079 14.4488C10.4801 14.6668 9.92002 14.6668 8.79992 14.6668H8.33325V13.5002C8.33325 12.6717 7.66168 12.0002 6.83325 12.0002C6.00482 12.0002 5.33325 12.6717 5.33325 13.5002V14.6668H4.53325C3.41315 14.6668 2.85309 14.6668 2.42527 14.4488C2.04895 14.2571 1.74299 13.9511 1.55124 13.5748C1.33325 13.147 1.33325 12.5869 1.33325 11.4668V10.3335H2.33325C3.25373 10.3335 3.99992 9.5873 3.99992 8.66683C3.99992 7.74635 3.25373 7.00016 2.33325 7.00016H1.33325C1.33325 6.06828 1.33325 5.60234 1.48549 5.2348C1.68848 4.74474 2.07783 4.35539 2.56789 4.1524C2.93543 4.00016 3.40137 4.00016 4.33325 4.00016H4.99992V3.00016Z",
            stroke: _ctx.color,
            "stroke-width": "1.2",
            "stroke-linecap": "round",
            "stroke-linejoin": "round"
          }, null, 8, _hoisted_3$e)
        ]),
        _cache[0] || (_cache[0] = createBaseVNode("defs", null, [
          createBaseVNode("clipPath", { id: "clip0_1099_16244" }, [
            createBaseVNode("rect", {
              width: "16",
              height: "16",
              fill: "white"
            })
          ])
        ], -1))
      ], 10, _hoisted_1$m);
    };
  }
});
const releaseApiClient = axios.create({
  baseURL: getComfyApiBaseUrl(),
  headers: {
    "Content-Type": "application/json"
  }
});
const useReleaseService = /* @__PURE__ */ __name(() => {
  const isLoading = ref(false);
  const error = ref(null);
  watch(
    () => getComfyApiBaseUrl(),
    (url) => {
      releaseApiClient.defaults.baseURL = url;
    }
  );
  const handleApiError = /* @__PURE__ */ __name((err, context, routeSpecificErrors) => {
    if (!axios.isAxiosError(err))
      return err instanceof Error ? `${context}: ${err.message}` : `${context}: Unknown error occurred`;
    const axiosError = err;
    if (axiosError.response) {
      const { status, data } = axiosError.response;
      if (routeSpecificErrors && routeSpecificErrors[status])
        return routeSpecificErrors[status];
      switch (status) {
        case 400:
          return `Bad request: ${data?.message || "Invalid input"}`;
        case 401:
          return "Unauthorized: Authentication required";
        case 403:
          return `Forbidden: ${data?.message || "Access denied"}`;
        case 404:
          return `Not found: ${data?.message || "Resource not found"}`;
        case 500:
          return `Server error: ${data?.message || "Internal server error"}`;
        default:
          return `${context}: ${data?.message || axiosError.message}`;
      }
    }
    return `${context}: ${axiosError.message}`;
  }, "handleApiError");
  const executeApiRequest = /* @__PURE__ */ __name(async (apiCall, errorContext, routeSpecificErrors) => {
    isLoading.value = true;
    error.value = null;
    try {
      const response = await apiCall();
      return response.data;
    } catch (err) {
      if (isAbortError(err)) return null;
      error.value = handleApiError(err, errorContext, routeSpecificErrors);
      return null;
    } finally {
      isLoading.value = false;
    }
  }, "executeApiRequest");
  const getReleases = /* @__PURE__ */ __name(async (params, signal) => {
    const endpoint = "/releases";
    const errorContext = "Failed to get releases";
    const routeSpecificErrors = {
      400: "Invalid project or version parameter"
    };
    const apiResponse = await executeApiRequest(
      () => releaseApiClient.get(endpoint, {
        params,
        signal
      }),
      errorContext,
      routeSpecificErrors
    );
    return apiResponse;
  }, "getReleases");
  return {
    isLoading,
    error,
    getReleases
  };
}, "useReleaseService");
const useReleaseStore = defineStore("release", () => {
  const releases = ref([]);
  const isLoading = ref(false);
  const error = ref(null);
  const releaseService = useReleaseService();
  const systemStatsStore = useSystemStatsStore();
  const settingStore = useSettingStore();
  const currentVersion = computed(() => {
    return systemStatsStore?.systemStats?.system?.comfyui_version ?? "";
  });
  const locale = computed(() => settingStore.get("Comfy.Locale"));
  const releaseVersion = computed(
    () => settingStore.get("Comfy.Release.Version")
  );
  const releaseStatus = computed(() => settingStore.get("Comfy.Release.Status"));
  const releaseTimestamp = computed(
    () => settingStore.get("Comfy.Release.Timestamp")
  );
  const showVersionUpdates = computed(
    () => settingStore.get("Comfy.Notification.ShowVersionUpdates")
  );
  const recentRelease = computed(() => {
    return releases.value[0] ?? null;
  });
  const recentReleases = computed(() => {
    return releases.value.slice(0, 3);
  });
  const THREE_DAYS_MS = 3 * 24 * 60 * 60 * 1e3;
  const compareVersions = /* @__PURE__ */ __name((releaseVersion2, currentVer) => {
    if (semverExports.valid(releaseVersion2) && semverExports.valid(currentVer)) {
      return semverExports.compare(releaseVersion2, currentVer);
    }
    return releaseVersion2 === currentVer ? 0 : 1;
  }, "compareVersions");
  const isNewVersionAvailable = computed(
    () => !!recentRelease.value && compareVersions(
      recentRelease.value.version,
      currentVersion.value || "0.0.0"
    ) > 0
  );
  const isLatestVersion = computed(
    () => !!recentRelease.value && compareVersions(
      recentRelease.value.version,
      currentVersion.value || "0.0.0"
    ) === 0
  );
  const hasMediumOrHighAttention = computed(() => {
    const attention = recentRelease.value?.attention;
    return attention === "medium" || attention === "high";
  });
  const shouldShowToast = computed(() => {
    if (!isElectron() || isCloud) {
      return false;
    }
    if (!showVersionUpdates.value) {
      return false;
    }
    if (!isNewVersionAvailable.value) {
      return false;
    }
    if (!hasMediumOrHighAttention.value) {
      return false;
    }
    if (releaseVersion.value === recentRelease.value?.version && ["skipped", "changelog seen"].includes(releaseStatus.value)) {
      return false;
    }
    return true;
  });
  const shouldShowRedDot = computed(() => {
    if (!isElectron() || isCloud) {
      return false;
    }
    if (!showVersionUpdates.value) {
      return false;
    }
    if (!isNewVersionAvailable.value) {
      return false;
    }
    const { version } = recentRelease.value;
    if (releaseVersion.value === version && releaseStatus.value === "changelog seen") {
      return false;
    }
    if (hasMediumOrHighAttention.value) {
      return true;
    }
    if (releaseVersion.value === version && releaseStatus.value === "skipped" && releaseTimestamp.value && Date.now() - releaseTimestamp.value >= THREE_DAYS_MS) {
      return false;
    }
    return true;
  });
  const shouldShowPopup = computed(() => {
    if (!isElectron() && !isCloud) {
      return false;
    }
    if (!showVersionUpdates.value) {
      return false;
    }
    if (!recentRelease.value) {
      return false;
    }
    const skipVersionCheck = !semverExports.valid(currentVersion.value);
    if (!skipVersionCheck && !isLatestVersion.value) {
      return false;
    }
    if (releaseVersion.value === recentRelease.value.version && releaseStatus.value === "what's new seen") {
      return false;
    }
    return true;
  });
  async function handleSkipRelease(version) {
    if (version !== recentRelease.value?.version || releaseStatus.value === "changelog seen") {
      return;
    }
    await settingStore.set("Comfy.Release.Version", version);
    await settingStore.set("Comfy.Release.Status", "skipped");
    await settingStore.set("Comfy.Release.Timestamp", Date.now());
  }
  __name(handleSkipRelease, "handleSkipRelease");
  async function handleShowChangelog(version) {
    if (version !== recentRelease.value?.version) {
      return;
    }
    await settingStore.set("Comfy.Release.Version", version);
    await settingStore.set("Comfy.Release.Status", "changelog seen");
    await settingStore.set("Comfy.Release.Timestamp", Date.now());
  }
  __name(handleShowChangelog, "handleShowChangelog");
  async function handleWhatsNewSeen(version) {
    if (version !== recentRelease.value?.version) {
      return;
    }
    await settingStore.set("Comfy.Release.Version", version);
    await settingStore.set("Comfy.Release.Status", "what's new seen");
    await settingStore.set("Comfy.Release.Timestamp", Date.now());
  }
  __name(handleWhatsNewSeen, "handleWhatsNewSeen");
  async function fetchReleases() {
    if (isLoading.value) {
      return;
    }
    if (!showVersionUpdates.value) {
      return;
    }
    if (systemStatsStore.systemStats?.system?.argv?.includes(
      "--disable-api-nodes"
    )) {
      return;
    }
    isLoading.value = true;
    error.value = null;
    try {
      if (!systemStatsStore.systemStats) {
        await until(systemStatsStore.isInitialized);
      }
      const fetchedReleases = await releaseService.getReleases({
        project: isCloud ? "cloud" : "comfyui",
        current_version: currentVersion.value,
        form_factor: systemStatsStore.getFormFactor(),
        locale: stringToLocale(locale.value)
      });
      if (fetchedReleases !== null) {
        releases.value = fetchedReleases;
      } else if (releaseService.error.value) {
        error.value = releaseService.error.value;
      }
    } catch (err) {
      error.value = err instanceof Error ? err.message : "Unknown error occurred";
    } finally {
      isLoading.value = false;
    }
  }
  __name(fetchReleases, "fetchReleases");
  async function initialize() {
    await fetchReleases();
  }
  __name(initialize, "initialize");
  return {
    releases,
    isLoading,
    error,
    recentRelease,
    recentReleases,
    shouldShowToast,
    shouldShowRedDot,
    shouldShowPopup,
    shouldShowUpdateButton: isNewVersionAvailable,
    handleSkipRelease,
    handleShowChangelog,
    handleWhatsNewSeen,
    fetchReleases,
    initialize
  };
});
const releaseStore = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  useReleaseStore
}, Symbol.toStringTag, { value: "Module" }));
const _hoisted_1$l = ["aria-label"];
const _hoisted_2$f = { class: "w-full" };
const _hoisted_3$d = {
  class: "flex w-full flex-col gap-2",
  role: "menubar"
};
const _hoisted_4$a = ["onClick", "onMouseenter", "onMouseleave"];
const _hoisted_5$9 = { class: "help-menu-icon-container" };
const _hoisted_6$8 = { class: "help-menu-icon" };
const _hoisted_7$6 = {
  key: 0,
  class: "menu-red-dot"
};
const _hoisted_8$6 = { class: "menu-label" };
const _hoisted_9$5 = {
  key: 0,
  class: "icon-[lucide--external-link] text-primary w-4 h-4 ml-auto"
};
const _hoisted_10$5 = {
  key: 1,
  class: "pi pi-chevron-right ml-auto"
};
const _hoisted_11$3 = {
  key: 0,
  class: "submenu-divider"
};
const _hoisted_12$2 = ["onClick"];
const _hoisted_13$2 = { class: "menu-label" };
const _hoisted_14$2 = {
  key: 0,
  class: "w-full",
  "data-testid": "whats-new-section"
};
const _hoisted_15$1 = { class: "section-description flex items-center gap-2.5 self-stretch px-8 pt-2 pb-2" };
const _hoisted_16$1 = ["aria-label"];
const _hoisted_17 = ["onClick", "onKeydown"];
const _hoisted_18 = { class: "release-content" };
const _hoisted_19 = { class: "release-title" };
const _hoisted_20 = ["datetime"];
const _hoisted_21 = { class: "normal-state" };
const _hoisted_22 = { class: "hover-state" };
const _hoisted_23 = {
  key: 1,
  class: "help-menu-item",
  role: "status",
  "aria-live": "polite"
};
const _hoisted_24 = {
  key: 2,
  class: "help-menu-item",
  role: "status"
};
const _sfc_main$q = /* @__PURE__ */ defineComponent({
  __name: "HelpCenterMenuContent",
  emits: ["close"],
  setup(__props, { emit: __emit }) {
    const TIME_UNITS = {
      MINUTE: 60 * 1e3,
      HOUR: 60 * 60 * 1e3,
      DAY: 24 * 60 * 60 * 1e3,
      WEEK: 7 * 24 * 60 * 60 * 1e3,
      MONTH: 30 * 24 * 60 * 60 * 1e3,
      YEAR: 365 * 24 * 60 * 60 * 1e3
    };
    const SUBMENU_CONFIG = {
      DELAY_MS: 100,
      OFFSET_PX: 8,
      Z_INDEX: 10001
    };
    const { t: t2 } = useI18n();
    const toast = useToast();
    const { staticUrls, buildDocsUrl } = useExternalLink();
    const releaseStore2 = useReleaseStore();
    const commandStore = useCommandStore();
    const settingStore = useSettingStore();
    const openedAt = ref(Date.now());
    const emit = __emit;
    const isSubmenuVisible = ref(false);
    const submenuRef = ref(null);
    const submenuStyle = ref({});
    let hoverTimeout = null;
    const hasReleases = computed(() => releaseStore2.releases.length > 0);
    const showVersionUpdates = computed(
      () => settingStore.get("Comfy.Notification.ShowVersionUpdates")
    );
    const { shouldShowRedDot: shouldShowManagerRedDot } = useConflictAcknowledgment();
    const { isNewManagerUI } = useManagerState();
    const moreItems = computed(() => {
      const allMoreItems = [
        {
          key: "desktop-guide",
          type: "item",
          label: t2("helpCenter.desktopUserGuide"),
          visible: isElectron(),
          action: /* @__PURE__ */ __name(() => {
            openExternalLink(
              buildDocsUrl("/installation/desktop", {
                includeLocale: true,
                platform: true
              })
            );
            emit("close");
          }, "action")
        },
        {
          key: "dev-tools",
          type: "item",
          label: t2("helpCenter.openDevTools"),
          visible: isElectron(),
          action: /* @__PURE__ */ __name(() => {
            openDevTools();
            emit("close");
          }, "action")
        },
        {
          key: "divider-1",
          type: "divider",
          visible: isElectron()
        },
        {
          key: "reinstall",
          type: "item",
          label: t2("helpCenter.reinstall"),
          visible: isElectron(),
          action: /* @__PURE__ */ __name(() => {
            onReinstall();
            emit("close");
          }, "action")
        }
      ];
      return allMoreItems.filter((item) => item.visible !== false);
    });
    const hasVisibleMoreItems = computed(() => {
      return !!moreItems.value.length;
    });
    const moreMenuItem = computed(
      () => menuItems.value.find((item) => item.key === "more")
    );
    const menuItems = computed(() => {
      const items = [
        {
          key: "feedback",
          type: "item",
          icon: "icon-[lucide--clipboard-pen]",
          label: t2("helpCenter.feedback"),
          action: /* @__PURE__ */ __name(() => {
            void commandStore.execute("Comfy.ContactSupport");
            emit("close");
          }, "action")
        },
        {
          key: "help",
          type: "item",
          icon: "icon-[lucide--message-circle-question]",
          label: t2("helpCenter.help"),
          action: /* @__PURE__ */ __name(() => {
            void commandStore.execute("Comfy.ContactSupport");
            emit("close");
          }, "action")
        },
        {
          key: "docs",
          type: "item",
          icon: "icon-[lucide--book-open]",
          label: t2("helpCenter.docs"),
          showExternalIcon: true,
          action: /* @__PURE__ */ __name(() => {
            const path = "/";
            openExternalLink(buildDocsUrl(path, { includeLocale: true }));
            emit("close");
          }, "action")
        },
        {
          key: "discord",
          type: "item",
          icon: "pi pi-discord",
          label: "Discord",
          showExternalIcon: true,
          action: /* @__PURE__ */ __name(() => {
            openExternalLink(staticUrls.discord);
            emit("close");
          }, "action")
        },
        {
          key: "github",
          type: "item",
          icon: "icon-[lucide--github]",
          label: t2("helpCenter.github"),
          showExternalIcon: true,
          action: /* @__PURE__ */ __name(() => {
            openExternalLink(staticUrls.github);
            emit("close");
          }, "action")
        }
      ];
      {
        items.push({
          key: "manager",
          type: "item",
          icon: _sfc_main$r,
          label: t2("helpCenter.managerExtension"),
          showRedDot: shouldShowManagerRedDot.value,
          action: /* @__PURE__ */ __name(async () => {
            await useManagerState().openManager({
              initialTab: ManagerTab.All,
              showToastOnLegacyError: false
            });
            emit("close");
          }, "action")
        });
      }
      if (!isElectron() && !isCloud && isNewManagerUI.value) {
        items.push({
          key: "update-comfyui",
          type: "item",
          icon: "icon-[lucide--download]",
          label: t2("helpCenter.updateComfyUI"),
          action: /* @__PURE__ */ __name(() => {
            onUpdateComfyUI();
            emit("close");
          }, "action")
        });
      }
      items.push({
        key: "more",
        type: "item",
        icon: "",
        label: t2("helpCenter.more"),
        visible: hasVisibleMoreItems.value,
        action: /* @__PURE__ */ __name(() => {
        }, "action"),
        // No action for more item
        items: moreItems.value
      });
      return items;
    });
    const openExternalLink = /* @__PURE__ */ __name((url) => {
      window.open(url, "_blank", "noopener,noreferrer");
    }, "openExternalLink");
    const clearHoverTimeout = /* @__PURE__ */ __name(() => {
      if (hoverTimeout) {
        clearTimeout(hoverTimeout);
        hoverTimeout = null;
      }
    }, "clearHoverTimeout");
    const calculateSubmenuPosition = /* @__PURE__ */ __name((button) => {
      const rect = button.getBoundingClientRect();
      const submenuWidth = 210;
      const visibleItemCount = moreMenuItem.value?.items?.filter((item) => item.visible !== false).length || 0;
      const estimatedHeight = visibleItemCount * 48 + 16;
      const submenuHeight = submenuRef.value?.offsetHeight || estimatedHeight;
      const viewportWidth = window.innerWidth;
      const viewportHeight = window.innerHeight;
      let top = rect.top;
      let left = rect.right + SUBMENU_CONFIG.OFFSET_PX;
      if (left + submenuWidth > viewportWidth) {
        left = rect.left - submenuWidth - SUBMENU_CONFIG.OFFSET_PX;
      }
      if (top + submenuHeight > viewportHeight) {
        top = Math.max(
          SUBMENU_CONFIG.OFFSET_PX,
          // Minimum distance from top of viewport
          rect.bottom - submenuHeight
        );
      }
      if (top < SUBMENU_CONFIG.OFFSET_PX) {
        top = SUBMENU_CONFIG.OFFSET_PX;
      }
      top -= 8;
      return {
        position: "fixed",
        top: `${top}px`,
        left: `${left}px`,
        zIndex: SUBMENU_CONFIG.Z_INDEX
      };
    }, "calculateSubmenuPosition");
    const formatReleaseDate = /* @__PURE__ */ __name((dateString) => {
      if (!dateString) return "date";
      const date = new Date(dateString);
      const now = /* @__PURE__ */ new Date();
      const diffTime = Math.abs(now.getTime() - date.getTime());
      const timeUnits = [
        { unit: TIME_UNITS.YEAR, key: "yearsAgo" },
        { unit: TIME_UNITS.MONTH, key: "monthsAgo" },
        { unit: TIME_UNITS.WEEK, key: "weeksAgo" },
        { unit: TIME_UNITS.DAY, key: "daysAgo" },
        { unit: TIME_UNITS.HOUR, key: "hoursAgo" },
        { unit: TIME_UNITS.MINUTE, key: "minutesAgo" }
      ];
      for (const { unit, key } of timeUnits) {
        const value = Math.floor(diffTime / unit);
        if (value > 0) {
          return t2(`g.relativeTime.${key}`, { count: value });
        }
      }
      return t2("g.relativeTime.now");
    }, "formatReleaseDate");
    const onMenuItemHover = /* @__PURE__ */ __name(async (key, event) => {
      if (key !== "more" || !moreMenuItem.value?.items) return;
      const hasVisibleItems = moreMenuItem.value.items.some(
        (item) => item.visible !== false
      );
      if (!hasVisibleItems) return;
      clearHoverTimeout();
      const moreButton = event.currentTarget;
      submenuStyle.value = calculateSubmenuPosition(moreButton);
      isSubmenuVisible.value = true;
      await nextTick();
      if (submenuRef.value) {
        submenuStyle.value = calculateSubmenuPosition(moreButton);
      }
    }, "onMenuItemHover");
    const onMenuItemLeave = /* @__PURE__ */ __name((key) => {
      if (key !== "more") return;
      hoverTimeout = window.setTimeout(() => {
        isSubmenuVisible.value = false;
      }, SUBMENU_CONFIG.DELAY_MS);
    }, "onMenuItemLeave");
    const onSubmenuHover = /* @__PURE__ */ __name(() => {
      clearHoverTimeout();
    }, "onSubmenuHover");
    const onSubmenuLeave = /* @__PURE__ */ __name(() => {
      isSubmenuVisible.value = false;
    }, "onSubmenuLeave");
    const openDevTools = /* @__PURE__ */ __name(() => {
      if (isElectron()) {
        electronAPI().openDevTools();
      }
    }, "openDevTools");
    const onReinstall = /* @__PURE__ */ __name(() => {
      if (isElectron()) {
        void electronAPI().reinstall();
      }
    }, "onReinstall");
    const onUpdateComfyUI = /* @__PURE__ */ __name(async () => {
      const { updateComfyUI, rebootComfyUI, error } = useComfyManagerService();
      toast.add({
        severity: "info",
        summary: t2("helpCenter.updateComfyUIStarted"),
        detail: t2("helpCenter.updateComfyUIStartedDetail"),
        life: 3e3
      });
      try {
        const result = await updateComfyUI({ is_stable: true });
        if (result === null || error.value) {
          toast.add({
            severity: "error",
            summary: t2("g.error"),
            detail: error.value || t2("helpCenter.updateComfyUIFailed"),
            life: 5e3
          });
          return;
        }
        toast.add({
          severity: "success",
          summary: t2("helpCenter.updateComfyUISuccess"),
          detail: t2("helpCenter.updateComfyUISuccessDetail"),
          life: 3e3
        });
        await rebootComfyUI();
      } catch (err) {
        toast.add({
          severity: "error",
          summary: t2("g.error"),
          detail: err instanceof Error ? err.message : t2("g.unknownError"),
          life: 5e3
        });
      }
    }, "onUpdateComfyUI");
    const onReleaseClick = /* @__PURE__ */ __name((release) => {
      void releaseStore2.handleShowChangelog(release.version);
      const versionAnchor = formatVersionAnchor(release.version);
      const changelogUrl = `${buildDocsUrl("/changelog", { includeLocale: true })}#${versionAnchor}`;
      openExternalLink(changelogUrl);
      emit("close");
    }, "onReleaseClick");
    onMounted(async () => {
      if (!hasReleases.value) {
        await releaseStore2.fetchReleases();
      }
    });
    onBeforeUnmount(() => {
      Math.round((Date.now() - openedAt.value) / 1e3);
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: "help-center-menu flex flex-col items-start gap-1",
        role: "menu",
        "aria-label": _ctx.$t("help.helpCenterMenu")
      }, [
        createBaseVNode("div", _hoisted_2$f, [
          createBaseVNode("nav", _hoisted_3$d, [
            (openBlock(true), createElementBlock(Fragment, null, renderList(menuItems.value, (menuItem) => {
              return withDirectives((openBlock(), createElementBlock("button", {
                key: menuItem.key,
                type: "button",
                class: normalizeClass(["help-menu-item", { "more-item": menuItem.key === "more" }]),
                role: "menuitem",
                onClick: menuItem.action,
                onMouseenter: /* @__PURE__ */ __name(($event) => onMenuItemHover(menuItem.key, $event), "onMouseenter"),
                onMouseleave: /* @__PURE__ */ __name(($event) => onMenuItemLeave(menuItem.key), "onMouseleave")
              }, [
                createBaseVNode("div", _hoisted_5$9, [
                  createBaseVNode("div", _hoisted_6$8, [
                    typeof menuItem.icon === "object" ? (openBlock(), createBlock(resolveDynamicComponent(menuItem.icon), {
                      key: 0,
                      size: 16
                    })) : (openBlock(), createElementBlock("i", {
                      key: 1,
                      class: normalizeClass(menuItem.icon)
                    }, null, 2))
                  ]),
                  menuItem.showRedDot ? (openBlock(), createElementBlock("div", _hoisted_7$6)) : createCommentVNode("", true)
                ]),
                createBaseVNode("span", _hoisted_8$6, toDisplayString(menuItem.label), 1),
                menuItem.showExternalIcon ? (openBlock(), createElementBlock("i", _hoisted_9$5)) : createCommentVNode("", true),
                menuItem.key === "more" ? (openBlock(), createElementBlock("i", _hoisted_10$5)) : createCommentVNode("", true)
              ], 42, _hoisted_4$a)), [
                [vShow, menuItem.visible !== false]
              ]);
            }), 128))
          ]),
          _cache[0] || (_cache[0] = createBaseVNode("div", { class: "flex h-4 flex-col items-center justify-between self-stretch p-2" }, [
            createBaseVNode("div", { class: "w-full border-b border-interface-menu-stroke" })
          ], -1))
        ]),
        (openBlock(), createBlock(Teleport, { to: "body" }, [
          isSubmenuVisible.value ? (openBlock(), createElementBlock("div", {
            key: 0,
            ref_key: "submenuRef",
            ref: submenuRef,
            class: "more-submenu",
            style: normalizeStyle(submenuStyle.value),
            onMouseenter: onSubmenuHover,
            onMouseleave: onSubmenuLeave
          }, [
            (openBlock(true), createElementBlock(Fragment, null, renderList(moreMenuItem.value?.items, (submenuItem) => {
              return openBlock(), createElementBlock(Fragment, {
                key: submenuItem.key
              }, [
                submenuItem.type === "divider" ? withDirectives((openBlock(), createElementBlock("div", _hoisted_11$3, null, 512)), [
                  [vShow, submenuItem.visible !== false]
                ]) : withDirectives((openBlock(), createElementBlock("button", {
                  key: 1,
                  type: "button",
                  class: "help-menu-item submenu-item",
                  role: "menuitem",
                  onClick: submenuItem.action
                }, [
                  createBaseVNode("span", _hoisted_13$2, toDisplayString(submenuItem.label), 1)
                ], 8, _hoisted_12$2)), [
                  [vShow, submenuItem.visible !== false]
                ])
              ], 64);
            }), 128))
          ], 36)) : createCommentVNode("", true)
        ])),
        showVersionUpdates.value ? (openBlock(), createElementBlock("section", _hoisted_14$2, [
          createBaseVNode("h3", _hoisted_15$1, toDisplayString(_ctx.$t("helpCenter.whatsNew")), 1),
          hasReleases.value ? (openBlock(), createElementBlock("div", {
            key: 0,
            role: "group",
            "aria-label": _ctx.$t("help.recentReleases")
          }, [
            (openBlock(true), createElementBlock(Fragment, null, renderList(unref(releaseStore2).recentReleases, (release) => {
              return openBlock(), createElementBlock("article", {
                key: release.id || release.version,
                class: "release-menu-item flex h-12 min-h-6 cursor-pointer items-center gap-2 self-stretch rounded p-2 transition-colors hover:bg-interface-menu-component-surface-hovered",
                role: "button",
                tabindex: "0",
                onClick: /* @__PURE__ */ __name(($event) => onReleaseClick(release), "onClick"),
                onKeydown: [
                  withKeys(($event) => onReleaseClick(release), ["enter"]),
                  withKeys(withModifiers(($event) => onReleaseClick(release), ["prevent"]), ["space"])
                ]
              }, [
                _cache[1] || (_cache[1] = createBaseVNode("i", {
                  class: "help-menu-icon icon-[lucide--package]",
                  "aria-hidden": "true"
                }, null, -1)),
                createBaseVNode("div", _hoisted_18, [
                  createBaseVNode("span", _hoisted_19, toDisplayString(_ctx.$t("g.releaseTitle", {
                    package: "Comfy",
                    version: release.version
                  })), 1),
                  createBaseVNode("time", {
                    class: "release-date",
                    datetime: release.published_at
                  }, [
                    createBaseVNode("span", _hoisted_21, toDisplayString(formatReleaseDate(release.published_at)), 1),
                    createBaseVNode("span", _hoisted_22, toDisplayString(_ctx.$t("helpCenter.clickToLearnMore")), 1)
                  ], 8, _hoisted_20)
                ])
              ], 40, _hoisted_17);
            }), 128))
          ], 8, _hoisted_16$1)) : unref(releaseStore2).isLoading ? (openBlock(), createElementBlock("div", _hoisted_23, [
            _cache[2] || (_cache[2] = createBaseVNode("i", {
              class: "pi pi-spin pi-spinner help-menu-icon",
              "aria-hidden": "true"
            }, null, -1)),
            createBaseVNode("span", null, toDisplayString(_ctx.$t("helpCenter.loadingReleases")), 1)
          ])) : (openBlock(), createElementBlock("div", _hoisted_24, [
            _cache[3] || (_cache[3] = createBaseVNode("i", {
              class: "pi pi-info-circle help-menu-icon",
              "aria-hidden": "true"
            }, null, -1)),
            createBaseVNode("span", null, toDisplayString(_ctx.$t("helpCenter.noRecentReleases")), 1)
          ]))
        ])) : createCommentVNode("", true)
      ], 8, _hoisted_1$l);
    };
  }
});
const HelpCenterMenuContent = /* @__PURE__ */ _export_sfc(_sfc_main$q, [["__scopeId", "data-v-8ecd06e2"]]);
const _hoisted_1$k = {
  key: 0,
  class: "release-toast-popup"
};
const _hoisted_2$e = { class: "w-96 max-h-96 bg-base-background border border-border-default rounded-lg shadow-[1px_1px_8px_0_rgba(0,0,0,0.4)] flex flex-col" };
const _hoisted_3$c = { class: "p-4 flex flex-col gap-4 flex-1 min-h-0" };
const _hoisted_4$9 = { class: "flex items-center gap-4" };
const _hoisted_5$8 = { class: "flex flex-col gap-1" };
const _hoisted_6$7 = { class: "text-sm font-normal text-base-foreground leading-[1.429]" };
const _hoisted_7$5 = { class: "text-sm font-normal text-muted-foreground leading-[1.21]" };
const _hoisted_8$5 = ["innerHTML"];
const _hoisted_9$4 = { class: "flex justify-between items-center px-4 pb-4" };
const _hoisted_10$4 = ["href"];
const _hoisted_11$2 = { class: "flex items-center gap-4" };
const _sfc_main$p = /* @__PURE__ */ defineComponent({
  __name: "ReleaseNotificationToast",
  setup(__props, { expose: __expose }) {
    const { buildDocsUrl } = useExternalLink();
    const { toastErrorHandler } = useErrorHandling();
    const releaseStore2 = useReleaseStore();
    const { t: t2 } = useI18n();
    const isDismissed = ref(false);
    const latestRelease = computed(() => {
      return releaseStore2.recentRelease;
    });
    const shouldShow = computed(
      () => releaseStore2.shouldShowToast && !isDismissed.value
    );
    const changelogUrl = computed(() => {
      const changelogBaseUrl = buildDocsUrl("/changelog", { includeLocale: true });
      if (latestRelease.value?.version) {
        const versionAnchor = formatVersionAnchor(latestRelease.value.version);
        return `${changelogBaseUrl}#${versionAnchor}`;
      }
      return changelogBaseUrl;
    });
    const formattedContent = computed(() => {
      if (!latestRelease.value?.content) {
        return purify.sanitize(`<p>${t2("releaseToast.description")}</p>`);
      }
      try {
        const markdown = latestRelease.value.content;
        const contentWithoutTitle = markdown.replace(/^# .+$/m, "");
        const contentWithoutImages = contentWithoutTitle.replace(
          /!\[.*?\]\(.*?\)/g,
          ""
        );
        const trimmedContent = contentWithoutImages.trim();
        if (!trimmedContent || trimmedContent.replace(/\s+/g, "") === "") {
          return purify.sanitize(`<p>${t2("releaseToast.description")}</p>`);
        }
        return renderMarkdownToHtml(contentWithoutImages);
      } catch (error) {
        console.error("Error parsing markdown:", error);
        const fallbackContent = latestRelease.value.content.replace(/\n/g, "<br>");
        return fallbackContent.trim() ? purify.sanitize(fallbackContent) : purify.sanitize(`<p>${t2("releaseToast.description")}</p>`);
      }
    });
    let hideTimer = null;
    const startAutoHide = /* @__PURE__ */ __name(() => {
      if (hideTimer) clearTimeout(hideTimer);
      hideTimer = setTimeout(() => {
        dismissToast();
      }, 8e3);
    }, "startAutoHide");
    const clearAutoHide = /* @__PURE__ */ __name(() => {
      if (hideTimer) {
        clearTimeout(hideTimer);
        hideTimer = null;
      }
    }, "clearAutoHide");
    const dismissToast = /* @__PURE__ */ __name(() => {
      isDismissed.value = true;
      clearAutoHide();
    }, "dismissToast");
    const handleSkip = /* @__PURE__ */ __name(() => {
      if (latestRelease.value) {
        void releaseStore2.handleSkipRelease(latestRelease.value.version);
      }
      dismissToast();
    }, "handleSkip");
    const handleLearnMore = /* @__PURE__ */ __name(() => {
      if (latestRelease.value) {
        void releaseStore2.handleShowChangelog(latestRelease.value.version);
      }
      dismissToast();
    }, "handleLearnMore");
    const handleUpdate = /* @__PURE__ */ __name(async () => {
      if (isElectron()) {
        try {
          await useCommandStore().execute("Comfy-Desktop.CheckForUpdates");
          dismissToast();
        } catch (error) {
          toastErrorHandler(error);
        }
        return;
      }
      window.open(
        buildDocsUrl("/installation/update_comfyui", { includeLocale: true }),
        "_blank"
      );
      dismissToast();
    }, "handleUpdate");
    watch(shouldShow, (isVisible) => {
      if (isVisible) {
        startAutoHide();
      } else {
        clearAutoHide();
      }
    });
    onMounted(async () => {
      if (!releaseStore2.releases.length) {
        await releaseStore2.fetchReleases();
      }
    });
    __expose({
      handleSkip,
      handleLearnMore,
      handleUpdate
    });
    return (_ctx, _cache) => {
      return shouldShow.value ? (openBlock(), createElementBlock("div", _hoisted_1$k, [
        createBaseVNode("div", _hoisted_2$e, [
          createBaseVNode("div", _hoisted_3$c, [
            createBaseVNode("div", _hoisted_4$9, [
              _cache[0] || (_cache[0] = createBaseVNode("div", { class: "p-3 bg-primary-background-hover rounded-lg flex items-center justify-center shrink-0" }, [
                createBaseVNode("i", { class: "icon-[lucide--rocket] w-4 h-4 text-white" })
              ], -1)),
              createBaseVNode("div", _hoisted_5$8, [
                createBaseVNode("div", _hoisted_6$7, toDisplayString(_ctx.$t("releaseToast.newVersionAvailable")), 1),
                createBaseVNode("div", _hoisted_7$5, toDisplayString(latestRelease.value?.version), 1)
              ])
            ]),
            createBaseVNode("div", {
              class: "pl-14 text-sm font-normal text-muted-foreground leading-[1.21] overflow-y-auto flex-1 min-h-0",
              innerHTML: formattedContent.value
            }, null, 8, _hoisted_8$5)
          ]),
          createBaseVNode("div", _hoisted_9$4, [
            createBaseVNode("a", {
              class: "flex items-center gap-2 text-sm font-normal py-1 text-muted-foreground hover:text-base-foreground",
              href: changelogUrl.value,
              target: "_blank",
              rel: "noopener noreferrer",
              onClick: handleLearnMore
            }, [
              _cache[1] || (_cache[1] = createBaseVNode("i", { class: "icon-[lucide--external-link] w-4 h-4" }, null, -1)),
              createTextVNode(" " + toDisplayString(_ctx.$t("releaseToast.whatsNew")), 1)
            ], 8, _hoisted_10$4),
            createBaseVNode("div", _hoisted_11$2, [
              createBaseVNode("button", {
                class: "h-6 px-0 bg-transparent border-none text-sm font-normal text-muted-foreground hover:text-base-foreground cursor-pointer",
                onClick: handleSkip
              }, toDisplayString(_ctx.$t("releaseToast.skip")), 1),
              createBaseVNode("button", {
                class: "h-10 px-4 bg-secondary-background hover:bg-secondary-background-hover rounded-lg border-none text-sm font-normal text-base-foreground cursor-pointer",
                onClick: handleUpdate
              }, toDisplayString(_ctx.$t("releaseToast.update")), 1)
            ])
          ])
        ])
      ])) : createCommentVNode("", true);
    };
  }
});
const ReleaseNotificationToast = /* @__PURE__ */ _export_sfc(_sfc_main$p, [["__scopeId", "data-v-ba02c61a"]]);
const _hoisted_1$j = {
  key: 0,
  class: "whats-new-popup-container left-4"
};
const _hoisted_2$d = { class: "modal-body flex flex-col gap-4 px-0 pt-0 pb-2 flex-1" };
const _hoisted_3$b = ["innerHTML"];
const _hoisted_4$8 = { class: "modal-footer flex justify-between items-center gap-4 px-4 pb-4" };
const _hoisted_5$7 = ["href"];
const _hoisted_6$6 = { class: "footer-actions flex items-center gap-4" };
const _sfc_main$o = /* @__PURE__ */ defineComponent({
  __name: "WhatsNewPopup",
  emits: ["whats-new-dismissed"],
  setup(__props, { expose: __expose, emit: __emit }) {
    const { buildDocsUrl } = useExternalLink();
    const releaseStore2 = useReleaseStore();
    const { t: t2 } = useI18n();
    const emit = __emit;
    const isDismissed = ref(false);
    const latestRelease = computed(() => {
      return releaseStore2.recentRelease;
    });
    const shouldShow = computed(
      () => releaseStore2.shouldShowPopup && !isDismissed.value
    );
    const changelogUrl = computed(() => {
      const changelogBaseUrl = buildDocsUrl("/changelog", { includeLocale: true });
      if (latestRelease.value?.version) {
        const versionAnchor = formatVersionAnchor(latestRelease.value.version);
        return `${changelogBaseUrl}#${versionAnchor}`;
      }
      return changelogBaseUrl;
    });
    const formattedContent = computed(() => {
      if (!latestRelease.value?.content) {
        return purify.sanitize(`<p>${t2("whatsNewPopup.noReleaseNotes")}</p>`);
      }
      try {
        const markdown = latestRelease.value.content;
        const trimmedContent = markdown.trim();
        if (!trimmedContent || trimmedContent.replace(/\s+/g, "") === "") {
          return purify.sanitize(`<p>${t2("whatsNewPopup.noReleaseNotes")}</p>`);
        }
        const imageMatch = markdown.match(/!\[.*?\]\(.*?\)/);
        const image = imageMatch ? imageMatch[0] : "";
        const contentWithoutImage = markdown.replace(/!\[.*?\]\(.*?\)/, "").trim();
        const reorderedContent = [image, contentWithoutImage].filter(Boolean).join("\n\n");
        return renderMarkdownToHtml(reorderedContent);
      } catch (error) {
        console.error("Error parsing markdown:", error);
        const fallbackContent = latestRelease.value.content.replace(/\n/g, "<br>");
        return fallbackContent.trim() ? purify.sanitize(fallbackContent) : purify.sanitize(`<p>${t2("whatsNewPopup.noReleaseNotes")}</p>`);
      }
    });
    const show = /* @__PURE__ */ __name(() => {
      isDismissed.value = false;
    }, "show");
    const hide = /* @__PURE__ */ __name(() => {
      isDismissed.value = true;
      emit("whats-new-dismissed");
    }, "hide");
    const closePopup = /* @__PURE__ */ __name(async () => {
      if (latestRelease.value) {
        await releaseStore2.handleWhatsNewSeen(latestRelease.value.version);
      }
      hide();
    }, "closePopup");
    onMounted(async () => {
      if (!releaseStore2.releases.length) {
        await releaseStore2.fetchReleases();
      }
    });
    __expose({
      show,
      hide,
      closePopup
    });
    return (_ctx, _cache) => {
      return shouldShow.value ? (openBlock(), createElementBlock("div", _hoisted_1$j, [
        createBaseVNode("div", {
          class: "whats-new-popup",
          onClick: _cache[0] || (_cache[0] = withModifiers(() => {
          }, ["stop"]))
        }, [
          createVNode(_sfc_main$1Y, {
            class: "close-button absolute top-2 right-2 z-10 w-8 h-8 p-2 rounded-lg opacity-50",
            "aria-label": _ctx.$t("g.close"),
            size: "icon-sm",
            variant: "muted-textonly",
            onClick: closePopup
          }, {
            default: withCtx(() => _cache[1] || (_cache[1] = [
              createBaseVNode("i", { class: "icon-[lucide--x]" }, null, -1)
            ])),
            _: 1
          }, 8, ["aria-label"]),
          createBaseVNode("div", _hoisted_2$d, [
            createBaseVNode("div", {
              class: "content-text max-h-96 overflow-y-auto",
              innerHTML: formattedContent.value
            }, null, 8, _hoisted_3$b)
          ]),
          createBaseVNode("div", _hoisted_4$8, [
            createBaseVNode("a", {
              class: "learn-more-link flex items-center gap-2 text-sm font-normal py-1",
              href: changelogUrl.value,
              target: "_blank",
              rel: "noopener noreferrer",
              onClick: closePopup
            }, [
              _cache[2] || (_cache[2] = createBaseVNode("i", { class: "icon-[lucide--external-link]" }, null, -1)),
              createTextVNode(" " + toDisplayString(_ctx.$t("whatsNewPopup.learnMore")), 1)
            ], 8, _hoisted_5$7),
            createBaseVNode("div", _hoisted_6$6, [
              createVNode(_sfc_main$1Y, {
                class: "h-8",
                size: "sm",
                variant: "muted-textonly",
                onClick: closePopup
              }, {
                default: withCtx(() => [
                  createTextVNode(toDisplayString(_ctx.$t("whatsNewPopup.later")), 1)
                ]),
                _: 1
              })
            ])
          ])
        ])
      ])) : createCommentVNode("", true);
    };
  }
});
const WhatsNewPopup = /* @__PURE__ */ _export_sfc(_sfc_main$o, [["__scopeId", "data-v-98a9f324"]]);
const useHelpCenterStore = defineStore("helpCenter", () => {
  const isVisible = ref(false);
  const toggle = /* @__PURE__ */ __name(() => {
    isVisible.value = !isVisible.value;
  }, "toggle");
  const show = /* @__PURE__ */ __name(() => {
    isVisible.value = true;
  }, "show");
  const hide = /* @__PURE__ */ __name(() => {
    isVisible.value = false;
  }, "hide");
  return {
    isVisible,
    toggle,
    show,
    hide
  };
});
const _sfc_main$n = /* @__PURE__ */ defineComponent({
  __name: "SidebarHelpCenterIcon",
  props: {
    isSmall: { type: Boolean }
  },
  setup(__props) {
    const settingStore = useSettingStore();
    const releaseStore2 = useReleaseStore();
    const helpCenterStore = useHelpCenterStore();
    const { isVisible: isHelpCenterVisible } = storeToRefs(helpCenterStore);
    const { shouldShowRedDot: showReleaseRedDot } = storeToRefs(releaseStore2);
    const conflictDetection = useConflictDetection();
    const { showNodeConflictDialog } = useDialogService();
    const { shouldShowRedDot: shouldShowConflictRedDot, markConflictsAsSeen } = useConflictAcknowledgment();
    const props = __props;
    const { isSmall } = toRefs(props);
    const shouldShowRedDot = computed(() => {
      const releaseRedDot = showReleaseRedDot.value;
      return releaseRedDot || shouldShowConflictRedDot.value;
    });
    const sidebarLocation = computed(
      () => settingStore.get("Comfy.Sidebar.Location")
    );
    const toggleHelpCenter = /* @__PURE__ */ __name(() => {
      helpCenterStore.toggle();
    }, "toggleHelpCenter");
    const closeHelpCenter = /* @__PURE__ */ __name(() => {
      helpCenterStore.hide();
    }, "closeHelpCenter");
    const handleWhatsNewDismissed = /* @__PURE__ */ __name(async () => {
      try {
        const shouldShow = await conflictDetection.shouldShowConflictModalAfterUpdate();
        if (shouldShow) {
          showConflictModal();
        }
      } catch (error) {
        console.error("[HelpCenter] Error checking conflict modal:", error);
      }
    }, "handleWhatsNewDismissed");
    const showConflictModal = /* @__PURE__ */ __name(() => {
      showNodeConflictDialog({
        showAfterWhatsNew: true,
        dialogComponentProps: {
          onClose: /* @__PURE__ */ __name(() => {
            markConflictsAsSeen();
          }, "onClose")
        }
      });
    }, "showConflictModal");
    onMounted(async () => {
      await releaseStore2.initialize();
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", null, [
        createVNode(SidebarIcon, {
          icon: "pi pi-question-circle",
          class: "comfy-help-center-btn",
          label: _ctx.$t("menu.help"),
          tooltip: _ctx.$t("sideToolbar.helpCenter"),
          "icon-badge": shouldShowRedDot.value ? "•" : "",
          "is-small": unref(isSmall),
          onClick: toggleHelpCenter
        }, null, 8, ["label", "tooltip", "icon-badge", "is-small"]),
        (openBlock(), createBlock(Teleport, { to: "#graph-canvas-container" }, [
          unref(isHelpCenterVisible) ? (openBlock(), createElementBlock("div", {
            key: 0,
            class: normalizeClass(["help-center-popup", {
              "sidebar-left": sidebarLocation.value === "left",
              "sidebar-right": sidebarLocation.value === "right",
              "small-sidebar": unref(isSmall)
            }])
          }, [
            createVNode(HelpCenterMenuContent, { onClose: closeHelpCenter })
          ], 2)) : createCommentVNode("", true)
        ])),
        (openBlock(), createBlock(Teleport, { to: "#graph-canvas-container" }, [
          createVNode(ReleaseNotificationToast, {
            class: normalizeClass({
              "sidebar-left": sidebarLocation.value === "left",
              "sidebar-right": sidebarLocation.value === "right",
              "small-sidebar": unref(isSmall)
            })
          }, null, 8, ["class"])
        ])),
        (openBlock(), createBlock(Teleport, { to: "#graph-canvas-container" }, [
          createVNode(WhatsNewPopup, {
            class: normalizeClass({
              "sidebar-left": sidebarLocation.value === "left",
              "sidebar-right": sidebarLocation.value === "right",
              "small-sidebar": unref(isSmall)
            }),
            onWhatsNewDismissed: handleWhatsNewDismissed
          }, null, 8, ["class"])
        ])),
        (openBlock(), createBlock(Teleport, { to: "body" }, [
          unref(isHelpCenterVisible) ? (openBlock(), createElementBlock("div", {
            key: 0,
            class: "help-center-backdrop",
            onClick: closeHelpCenter
          })) : createCommentVNode("", true)
        ]))
      ]);
    };
  }
});
const SidebarHelpCenterIcon = /* @__PURE__ */ _export_sfc(_sfc_main$n, [["__scopeId", "data-v-91ae5559"]]);
const _sfc_main$m = /* @__PURE__ */ defineComponent({
  __name: "SidebarLogoutIcon",
  setup(__props) {
    const { t: t2 } = useI18n();
    const userStore = useUserStore();
    const tooltip = computed(
      () => `${t2("sideToolbar.logout")} (${userStore.currentUser?.username})`
    );
    const logout = /* @__PURE__ */ __name(async () => {
      await userStore.logout();
      window.location.reload();
    }, "logout");
    return (_ctx, _cache) => {
      return openBlock(), createBlock(SidebarIcon, {
        icon: "pi pi-sign-out",
        tooltip: tooltip.value,
        label: _ctx.$t("sideToolbar.logout"),
        onClick: logout
      }, null, 8, ["tooltip", "label"]);
    };
  }
});
const _sfc_main$l = /* @__PURE__ */ defineComponent({
  __name: "SidebarTemplatesButton",
  setup(__props) {
    const settingStore = useSettingStore();
    const isSmall = computed(
      () => settingStore.get("Comfy.Sidebar.Size") === "small"
    );
    const openTemplates = /* @__PURE__ */ __name(() => {
      useWorkflowTemplateSelectorDialog().show("sidebar");
    }, "openTemplates");
    return (_ctx, _cache) => {
      return openBlock(), createBlock(SidebarIcon, {
        icon: "icon-[comfy--template]",
        tooltip: _ctx.$t("sideToolbar.templates"),
        label: _ctx.$t("sideToolbar.labels.templates"),
        "is-small": isSmall.value,
        class: "templates-tab-button",
        onClick: openTemplates
      }, null, 8, ["tooltip", "label", "is-small"]);
    };
  }
});
const ENTER_OVERFLOW_MARGIN = 20;
const EXIT_OVERFLOW_MARGIN = 50;
const _sfc_main$k = /* @__PURE__ */ defineComponent({
  __name: "SideToolbar",
  setup(__props) {
    const workspaceStore = useWorkspaceStore();
    const settingStore = useSettingStore();
    const userStore = useUserStore();
    const commandStore = useCommandStore();
    const canvasStore = useCanvasStore();
    const sideToolbarRef = ref();
    const topToolbarRef = ref();
    const bottomToolbarRef = ref();
    const isSmall = computed(
      () => settingStore.get("Comfy.Sidebar.Size") === "small"
    );
    const sidebarLocation = computed(
      () => settingStore.get("Comfy.Sidebar.Location")
    );
    const sidebarStyle = computed(() => settingStore.get("Comfy.Sidebar.Style"));
    const isConnected = computed(
      () => selectedTab.value || isOverflowing.value || sidebarStyle.value === "connected"
    );
    const tabs = computed(() => workspaceStore.getSidebarTabs());
    const selectedTab = computed(() => workspaceStore.sidebarTab.activeSidebarTab);
    const onTabClick = /* @__PURE__ */ __name(async (item) => {
      item.id === "node-library";
      item.id === "model-library";
      item.id === "workflows";
      item.id === "assets";
      await commandStore.commands.find((cmd) => cmd.id === `Workspace.ToggleSidebarTab.${item.id}`)?.function?.();
    }, "onTabClick");
    const keybindingStore = useKeybindingStore();
    const getTabTooltipSuffix = /* @__PURE__ */ __name((tab) => {
      const keybinding = keybindingStore.getKeybindingByCommandId(
        `Workspace.ToggleSidebarTab.${tab.id}`
      );
      return keybinding ? ` (${keybinding.combo.toString()})` : "";
    }, "getTabTooltipSuffix");
    const isOverflowing = ref(false);
    const groupClasses = computed(
      () => cn(
        "sidebar-item-group flex flex-col items-center overflow-hidden flex-shrink-0" + (isConnected.value ? "" : " rounded-lg shadow-interface")
      )
    );
    const checkOverflow = debounce(() => {
      if (!sideToolbarRef.value || !topToolbarRef.value || !bottomToolbarRef.value)
        return;
      const containerHeight = sideToolbarRef.value.clientHeight;
      const topHeight = topToolbarRef.value.scrollHeight;
      const bottomHeight = bottomToolbarRef.value.scrollHeight;
      const contentHeight = topHeight + bottomHeight;
      if (isOverflowing.value) {
        isOverflowing.value = containerHeight < contentHeight + EXIT_OVERFLOW_MARGIN;
      } else {
        isOverflowing.value = containerHeight < contentHeight + ENTER_OVERFLOW_MARGIN;
      }
    }, 16);
    onMounted(() => {
      if (!sideToolbarRef.value) return;
      const overflowObserver = useResizeObserver(
        sideToolbarRef.value,
        checkOverflow
      );
      checkOverflow();
      onBeforeUnmount(() => {
        overflowObserver.stop();
      });
      watch(
        [isSmall, sidebarLocation],
        async () => {
          if (canvasStore.canvas) {
            if (sidebarLocation.value === "left") {
              await nextTick();
              canvasStore.canvas.fpsInfoLocation = [
                sideToolbarRef.value?.getBoundingClientRect()?.right,
                null
              ];
            } else {
              canvasStore.canvas.fpsInfoLocation = null;
            }
            canvasStore.canvas.setDirty(false, true);
          }
        },
        { immediate: true }
      );
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("nav", {
        ref_key: "sideToolbarRef",
        ref: sideToolbarRef,
        class: normalizeClass(["side-tool-bar-container flex h-full flex-col items-center bg-transparent [.floating-sidebar]:-mr-2 pointer-events-auto", {
          "small-sidebar": isSmall.value,
          "connected-sidebar": isConnected.value,
          "floating-sidebar": !isConnected.value,
          "overflowing-sidebar": isOverflowing.value,
          "border-r border-[var(--interface-stroke)] shadow-interface": isConnected.value
        }])
      }, [
        createBaseVNode("div", {
          class: normalizeClass(
            isOverflowing.value ? "side-tool-bar-container overflow-y-auto" : "flex flex-col h-full"
          )
        }, [
          createBaseVNode("div", {
            ref_key: "topToolbarRef",
            ref: topToolbarRef,
            class: normalizeClass(groupClasses.value)
          }, [
            createVNode(ComfyMenuButton),
            (openBlock(true), createElementBlock(Fragment, null, renderList(tabs.value, (tab) => {
              return openBlock(), createBlock(SidebarIcon, {
                key: tab.id,
                icon: tab.icon,
                "icon-badge": tab.iconBadge,
                tooltip: tab.tooltip,
                "tooltip-suffix": getTabTooltipSuffix(tab),
                label: tab.label || tab.title,
                "is-small": isSmall.value,
                selected: tab.id === selectedTab.value?.id,
                class: normalizeClass(tab.id + "-tab-button"),
                onClick: /* @__PURE__ */ __name(($event) => onTabClick(tab), "onClick")
              }, null, 8, ["icon", "icon-badge", "tooltip", "tooltip-suffix", "label", "is-small", "selected", "class", "onClick"]);
            }), 128)),
            createVNode(_sfc_main$l)
          ], 2),
          createBaseVNode("div", {
            ref_key: "bottomToolbarRef",
            ref: bottomToolbarRef,
            class: normalizeClass(["mt-auto", groupClasses.value])
          }, [
            unref(userStore).isMultiUserServer ? (openBlock(), createBlock(_sfc_main$m, {
              key: 0,
              "is-small": isSmall.value
            }, null, 8, ["is-small"])) : createCommentVNode("", true),
            createVNode(SidebarHelpCenterIcon, { "is-small": isSmall.value }, null, 8, ["is-small"]),
            createVNode(_sfc_main$u, { "is-small": isSmall.value }, null, 8, ["is-small"]),
            createVNode(_sfc_main$s, { "is-small": isSmall.value }, null, 8, ["is-small"]),
            createVNode(_sfc_main$t, { "is-small": isSmall.value }, null, 8, ["is-small"])
          ], 2)
        ], 2)
      ], 2);
    };
  }
});
const SideToolbar = /* @__PURE__ */ _export_sfc(_sfc_main$k, [["__scopeId", "data-v-2a2f0be8"]]);
const useTopbarBadgeStore = defineStore("topbarBadge", () => {
  const extensionStore = useExtensionStore();
  const badges = computed(
    () => extensionStore.extensions.flatMap((e) => e.topbarBadges ?? [])
  );
  return {
    badges
  };
});
const _hoisted_1$i = { class: "flex h-full shrink-0 items-center" };
const _sfc_main$j = /* @__PURE__ */ defineComponent({
  __name: "TopbarBadges",
  props: {
    reverseOrder: { type: Boolean, default: false },
    noPadding: { type: Boolean, default: false }
  },
  setup(__props) {
    const breakpoints = useBreakpoints(breakpointsTailwind);
    const isXl = breakpoints.greaterOrEqual("xl");
    const isLg = breakpoints.greaterOrEqual("lg");
    const displayMode = computed(() => {
      if (isXl.value) return "full";
      if (isLg.value) return "compact";
      return "icon-only";
    });
    const topbarBadgeStore = useTopbarBadgeStore();
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$i, [
        (openBlock(true), createElementBlock(Fragment, null, renderList(unref(topbarBadgeStore).badges, (badge) => {
          return openBlock(), createBlock(_sfc_main$1H, {
            key: badge.text,
            badge,
            "display-mode": displayMode.value,
            "reverse-order": _ctx.reverseOrder,
            "no-padding": _ctx.noPadding
          }, null, 8, ["badge", "display-mode", "reverse-order", "no-padding"]);
        }), 128))
      ]);
    };
  }
});
const _hoisted_1$h = { class: "workflow-preview-content" };
const _hoisted_2$c = {
  key: 0,
  class: "workflow-preview-thumbnail relative"
};
const _hoisted_3$a = ["src"];
const _hoisted_4$7 = { class: "workflow-preview-footer" };
const _hoisted_5$6 = { class: "workflow-preview-name" };
const POPOVER_WIDTH = 250;
const _sfc_main$i = /* @__PURE__ */ defineComponent({
  __name: "WorkflowTabPopover",
  props: {
    workflowFilename: {},
    thumbnailUrl: {},
    isActiveTab: { type: Boolean }
  },
  setup(__props, { expose: __expose }) {
    const props = __props;
    const { thumbnailUrl, isActiveTab } = toRefs(props);
    const popoverRef = ref(null);
    const positionRef = ref(null);
    let hideTimeout = null;
    let showTimeout = null;
    const id = useId();
    const showPopover = /* @__PURE__ */ __name((event) => {
      if (hideTimeout) {
        clearTimeout(hideTimeout);
        hideTimeout = null;
      }
      if (showTimeout) {
        clearTimeout(showTimeout);
        showTimeout = null;
      }
      showTimeout = setTimeout(async () => {
        if (popoverRef.value && positionRef.value) {
          popoverRef.value.show(event, positionRef.value);
          await nextTick();
          const el = document.querySelector(
            `.workflow-popover-fade[data-popover-id="${id}"]`
          );
          if (el) {
            const middle = positionRef.value.getBoundingClientRect().left;
            const popoverWidth = el.getBoundingClientRect().width;
            const halfWidth = popoverWidth / 2;
            let pos = middle - halfWidth;
            let shift = 0;
            if (pos < 0) {
              shift = pos - 8;
              pos = 8;
            } else if (pos + popoverWidth > window.innerWidth) {
              const newPos = window.innerWidth - popoverWidth - 16;
              shift = pos - newPos;
              pos = newPos;
            }
            if (shift + halfWidth < 0) {
              shift = -halfWidth + 24;
            }
            el.style.left = `${pos}px`;
            el.style.setProperty("--shift", `${shift}px`);
          }
        }
      }, 200);
    }, "showPopover");
    const cancelHidePopover = /* @__PURE__ */ __name(() => {
    }, "cancelHidePopover");
    const hidePopover = /* @__PURE__ */ __name(() => {
      if (showTimeout) {
        clearTimeout(showTimeout);
        showTimeout = null;
      }
      hideTimeout = setTimeout(() => {
        if (popoverRef.value) {
          popoverRef.value.hide();
        }
      }, 100);
    }, "hidePopover");
    const togglePopover = /* @__PURE__ */ __name((event) => {
      if (popoverRef.value) {
        popoverRef.value.toggle(event);
      }
    }, "togglePopover");
    __expose({
      showPopover,
      hidePopover,
      togglePopover
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createBaseVNode("div", {
          ref_key: "positionRef",
          ref: positionRef,
          class: "absolute bottom-0 left-1/2 -translate-x-1/2"
        }, null, 512),
        createVNode(unref(script$1), {
          ref_key: "popoverRef",
          ref: popoverRef,
          "append-to": "body",
          pt: {
            root: {
              class: "workflow-popover-fade fit-content",
              "data-popover-id": unref(id)
            }
          },
          onMouseenter: cancelHidePopover,
          onMouseleave: hidePopover
        }, {
          default: withCtx(() => [
            createBaseVNode("div", _hoisted_1$h, [
              unref(thumbnailUrl) && !unref(isActiveTab) ? (openBlock(), createElementBlock("div", _hoisted_2$c, [
                createBaseVNode("img", {
                  src: unref(thumbnailUrl),
                  class: "block h-[200px] rounded-lg object-cover p-2",
                  style: normalizeStyle({ width: `${POPOVER_WIDTH}px` })
                }, null, 12, _hoisted_3$a)
              ])) : createCommentVNode("", true),
              createBaseVNode("div", _hoisted_4$7, [
                createBaseVNode("span", _hoisted_5$6, toDisplayString(_ctx.workflowFilename), 1)
              ])
            ])
          ]),
          _: 1
        }, 8, ["pt"])
      ], 64);
    };
  }
});
const WorkflowTabPopover = /* @__PURE__ */ _export_sfc(_sfc_main$i, [["__scopeId", "data-v-4c13cb50"]]);
const _hoisted_1$g = { class: "workflow-label inline-block max-w-[150px] truncate text-sm" };
const _hoisted_2$b = { class: "relative" };
const _hoisted_3$9 = {
  key: 0,
  class: "absolute top-1/2 left-1/2 z-10 w-4 -translate-1/2 bg-(--comfy-menu-bg) text-2xl font-bold group-hover:hidden"
};
const _sfc_main$h = /* @__PURE__ */ defineComponent({
  __name: "WorkflowTab",
  props: {
    workflowOption: {}
  },
  setup(__props) {
    const props = __props;
    const { t: t2 } = useI18n();
    const workspaceStore = useWorkspaceStore();
    const workflowStore = useWorkflowStore();
    const settingStore = useSettingStore();
    const workflowTabRef = ref(null);
    const popoverRef = ref(null);
    const workflowThumbnail = useWorkflowThumbnail();
    const autoSaveSetting = computed(
      () => settingStore.get("Comfy.Workflow.AutoSave")
    );
    const autoSaveDelay = computed(
      () => settingStore.get("Comfy.Workflow.AutoSaveDelay")
    );
    const shouldShowStatusIndicator = computed(() => {
      if (workspaceStore.shiftDown) {
        return false;
      }
      if (!props.workflowOption.workflow.isPersisted) {
        return true;
      }
      if (props.workflowOption.workflow.isModified) {
        if (autoSaveSetting.value === "off") {
          return true;
        }
        if (autoSaveSetting.value === "after delay" && autoSaveDelay.value > 3e3) {
          return true;
        }
        return false;
      }
      return false;
    });
    const isActiveTab = computed(() => {
      return workflowStore.activeWorkflow?.key === props.workflowOption.workflow.key;
    });
    const thumbnailUrl = computed(() => {
      return workflowThumbnail.getThumbnail(props.workflowOption.workflow.key);
    });
    const handleMouseEnter = /* @__PURE__ */ __name((event) => {
      popoverRef.value?.showPopover(event);
    }, "handleMouseEnter");
    const handleMouseLeave = /* @__PURE__ */ __name(() => {
      popoverRef.value?.hidePopover();
    }, "handleMouseLeave");
    const handleClick = /* @__PURE__ */ __name((event) => {
      popoverRef.value?.togglePopover(event);
    }, "handleClick");
    const closeWorkflows = /* @__PURE__ */ __name(async (options) => {
      for (const opt of options) {
        if (!await useWorkflowService().closeWorkflow(opt.workflow, {
          warnIfUnsaved: !workspaceStore.shiftDown,
          hint: t2("sideToolbar.workflowTab.dirtyCloseHint")
        })) {
          break;
        }
      }
    }, "closeWorkflows");
    const onCloseWorkflow = /* @__PURE__ */ __name(async (option) => {
      await closeWorkflows([option]);
    }, "onCloseWorkflow");
    const tabGetter = /* @__PURE__ */ __name(() => workflowTabRef.value, "tabGetter");
    usePragmaticDraggable(tabGetter, {
      getInitialData: /* @__PURE__ */ __name(() => {
        return {
          workflowKey: props.workflowOption.workflow.key
        };
      }, "getInitialData")
    });
    usePragmaticDroppable(tabGetter, {
      getData: /* @__PURE__ */ __name(() => {
        return {
          workflowKey: props.workflowOption.workflow.key
        };
      }, "getData"),
      onDrop: /* @__PURE__ */ __name((e) => {
        const fromIndex = workflowStore.openWorkflows.findIndex(
          (wf) => wf.key === e.source.data.workflowKey
        );
        const toIndex = workflowStore.openWorkflows.findIndex(
          (wf) => wf.key === e.location.current.dropTargets[0]?.data.workflowKey
        );
        if (fromIndex !== toIndex) {
          workflowStore.reorderWorkflows(fromIndex, toIndex);
        }
      }, "onDrop")
    });
    onUnmounted(() => {
      popoverRef.value?.hidePopover();
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createBaseVNode("div", mergeProps({
          ref_key: "workflowTabRef",
          ref: workflowTabRef,
          class: "workflow-tab group flex gap-2 p-2"
        }, _ctx.$attrs, {
          onMouseenter: handleMouseEnter,
          onMouseleave: handleMouseLeave,
          onClick: handleClick
        }), [
          createBaseVNode("span", _hoisted_1$g, toDisplayString(_ctx.workflowOption.workflow.filename), 1),
          createBaseVNode("div", _hoisted_2$b, [
            shouldShowStatusIndicator.value ? (openBlock(), createElementBlock("span", _hoisted_3$9, "•")) : createCommentVNode("", true),
            createVNode(_sfc_main$1Y, {
              class: "close-button invisible w-auto p-0",
              variant: "muted-textonly",
              size: "icon-sm",
              "aria-label": unref(t2)("g.close"),
              onClick: _cache[0] || (_cache[0] = withModifiers(($event) => onCloseWorkflow(_ctx.workflowOption), ["stop"]))
            }, {
              default: withCtx(() => _cache[1] || (_cache[1] = [
                createBaseVNode("i", { class: "pi pi-times" }, null, -1)
              ])),
              _: 1
            }, 8, ["aria-label"])
          ])
        ], 16),
        createVNode(WorkflowTabPopover, {
          ref_key: "popoverRef",
          ref: popoverRef,
          "workflow-filename": _ctx.workflowOption.workflow.filename,
          "thumbnail-url": thumbnailUrl.value,
          "is-active-tab": isActiveTab.value
        }, null, 8, ["workflow-filename", "thumbnail-url", "is-active-tab"])
      ], 64);
    };
  }
});
const _sfc_main$g = /* @__PURE__ */ defineComponent({
  __name: "WorkflowOverflowMenu",
  props: {
    workflows: {},
    activeWorkflow: {}
  },
  setup(__props) {
    const props = __props;
    const menu = ref(null);
    const workflowService = useWorkflowService();
    const menuItems = computed(
      () => props.workflows.map((workflow) => ({
        label: workflow.filename,
        icon: props.activeWorkflow?.key === workflow.key ? "pi pi-check" : void 0,
        command: /* @__PURE__ */ __name(() => {
          void workflowService.openWorkflow(workflow);
        }, "command")
      }))
    );
    return (_ctx, _cache) => {
      const _directive_tooltip = resolveDirective("tooltip");
      return openBlock(), createElementBlock("div", null, [
        withDirectives((openBlock(), createBlock(_sfc_main$1Y, {
          class: "rounded-none h-full w-auto aspect-square",
          variant: "muted-textonly",
          size: "icon",
          "aria-label": _ctx.$t("g.moreWorkflows"),
          onClick: _cache[0] || (_cache[0] = ($event) => menu.value?.toggle($event))
        }, {
          default: withCtx(() => _cache[1] || (_cache[1] = [
            createBaseVNode("i", { class: "pi pi-ellipsis-h" }, null, -1)
          ])),
          _: 1
        }, 8, ["aria-label"])), [
          [_directive_tooltip, { value: _ctx.$t("g.moreWorkflows"), showDelay: 300 }]
        ]),
        createVNode(unref(script$7), {
          ref_key: "menu",
          ref: menu,
          model: menuItems.value,
          popup: true,
          class: "max-h-[40vh] overflow-auto"
        }, null, 8, ["model"])
      ]);
    };
  }
});
const _hoisted_1$f = {
  key: 3,
  class: "window-actions-spacer app-drag shrink-0"
};
const _sfc_main$f = /* @__PURE__ */ defineComponent({
  __name: "WorkflowTabs",
  props: {
    class: {}
  },
  setup(__props) {
    const props = __props;
    const { t: t2 } = useI18n();
    const workspaceStore = useWorkspaceStore();
    const workflowStore = useWorkflowStore();
    const workflowBookmarkStore = useWorkflowBookmarkStore();
    const workflowService = useWorkflowService();
    const rightClickedTab = ref();
    const menu = ref();
    const containerRef = ref(null);
    const showOverflowArrows = ref(false);
    const leftArrowEnabled = ref(false);
    const rightArrowEnabled = ref(false);
    const isDesktop = isElectron();
    const workflowToOption = /* @__PURE__ */ __name((workflow) => ({
      value: workflow.path,
      workflow
    }), "workflowToOption");
    const options = computed(
      () => workflowStore.openWorkflows.map(workflowToOption)
    );
    const selectedWorkflow = computed(
      () => workflowStore.activeWorkflow ? workflowToOption(workflowStore.activeWorkflow) : null
    );
    const onWorkflowChange = /* @__PURE__ */ __name(async (option) => {
      if (!option) {
        return;
      }
      if (selectedWorkflow.value?.value === option.value) {
        return;
      }
      await workflowService.openWorkflow(option.workflow);
    }, "onWorkflowChange");
    const closeWorkflows = /* @__PURE__ */ __name(async (options2) => {
      for (const opt of options2) {
        if (!await workflowService.closeWorkflow(opt.workflow, {
          warnIfUnsaved: !workspaceStore.shiftDown
        })) {
          break;
        }
      }
    }, "closeWorkflows");
    const onCloseWorkflow = /* @__PURE__ */ __name(async (option) => {
      await closeWorkflows([option]);
    }, "onCloseWorkflow");
    const showContextMenu = /* @__PURE__ */ __name((event, option) => {
      rightClickedTab.value = option;
      menu.value.show(event);
    }, "showContextMenu");
    const contextMenuItems = computed(() => {
      const tab = rightClickedTab.value;
      if (!tab) return [];
      const index = options.value.findIndex((v) => v.workflow === tab.workflow);
      return [
        {
          label: t2("tabMenu.duplicateTab"),
          command: /* @__PURE__ */ __name(async () => {
            await workflowService.duplicateWorkflow(tab.workflow);
          }, "command")
        },
        {
          separator: true
        },
        {
          label: t2("tabMenu.closeTab"),
          command: /* @__PURE__ */ __name(() => onCloseWorkflow(tab), "command")
        },
        {
          label: t2("tabMenu.closeTabsToLeft"),
          command: /* @__PURE__ */ __name(() => closeWorkflows(options.value.slice(0, index)), "command"),
          disabled: index <= 0
        },
        {
          label: t2("tabMenu.closeTabsToRight"),
          command: /* @__PURE__ */ __name(() => closeWorkflows(options.value.slice(index + 1)), "command"),
          disabled: index === options.value.length - 1
        },
        {
          label: t2("tabMenu.closeOtherTabs"),
          command: /* @__PURE__ */ __name(() => closeWorkflows([
            ...options.value.slice(index + 1),
            ...options.value.slice(0, index)
          ]), "command"),
          disabled: options.value.length <= 1
        },
        {
          label: workflowBookmarkStore.isBookmarked(tab.workflow.path) ? t2("tabMenu.removeFromBookmarks") : t2("tabMenu.addToBookmarks"),
          command: /* @__PURE__ */ __name(() => workflowBookmarkStore.toggleBookmarked(tab.workflow.path), "command"),
          disabled: tab.workflow.isTemporary
        }
      ];
    });
    const commandStore = useCommandStore();
    const handleWheel = /* @__PURE__ */ __name((event) => {
      const scrollElement = event.currentTarget;
      const scrollAmount = event.deltaX || event.deltaY;
      scrollElement.scroll({
        left: scrollElement.scrollLeft + scrollAmount
      });
    }, "handleWheel");
    const scrollContent = computed(
      () => containerRef.value?.querySelector(
        ".p-scrollpanel-content"
      ) ?? null
    );
    const scroll = /* @__PURE__ */ __name((direction) => {
      const el = scrollContent.value;
      if (!el) return;
      el.scrollBy({ left: direction * 20 });
    }, "scroll");
    const ensureActiveTabVisible = /* @__PURE__ */ __name(async (options2 = {}) => {
      if (!selectedWorkflow.value) return;
      if (options2.waitForDom !== false) {
        await nextTick();
      }
      const containerElement = containerRef.value;
      if (!containerElement) return;
      const activeTabElement = containerElement.querySelector(
        ".p-togglebutton-checked"
      );
      if (!activeTabElement) return;
      activeTabElement.scrollIntoView({ block: "nearest", inline: "nearest" });
    }, "ensureActiveTabVisible");
    watch(
      () => workflowStore.activeWorkflow,
      () => {
        void ensureActiveTabVisible();
      },
      { immediate: true }
    );
    let overflowObserver = null;
    let stopArrivedWatch = null;
    let stopOverflowWatch = null;
    watch(
      scrollContent,
      (el, _prev, onCleanup) => {
        stopArrivedWatch?.();
        stopOverflowWatch?.();
        overflowObserver?.dispose();
        if (!el) return;
        const scrollState = useScroll(el);
        stopArrivedWatch = watch(
          [
            () => scrollState.arrivedState.left,
            () => scrollState.arrivedState.right
          ],
          ([atLeft, atRight]) => {
            leftArrowEnabled.value = !atLeft;
            rightArrowEnabled.value = !atRight;
          },
          { immediate: true }
        );
        overflowObserver = useOverflowObserver(el);
        stopOverflowWatch = watch(
          overflowObserver.isOverflowing,
          (isOverflow) => {
            showOverflowArrows.value = isOverflow;
            if (!isOverflow) return;
            void nextTick(() => {
              scrollState.measure();
              void ensureActiveTabVisible({ waitForDom: false });
            });
          },
          { immediate: true }
        );
        onCleanup(() => {
          stopArrivedWatch?.();
          stopOverflowWatch?.();
          overflowObserver?.dispose();
        });
      },
      { immediate: true }
    );
    onUpdated(() => {
      if (!overflowObserver?.disposed.value) {
        overflowObserver?.checkOverflow();
      }
    });
    return (_ctx, _cache) => {
      const _directive_tooltip = resolveDirective("tooltip");
      return openBlock(), createElementBlock("div", {
        ref_key: "containerRef",
        ref: containerRef,
        class: normalizeClass(["workflow-tabs-container flex h-full max-w-full flex-auto flex-row overflow-hidden", { "workflow-tabs-container-desktop": unref(isDesktop) }])
      }, [
        showOverflowArrows.value ? (openBlock(), createBlock(_sfc_main$1Y, {
          key: 0,
          variant: "muted-textonly",
          size: "icon",
          class: "overflow-arrow overflow-arrow-left h-full w-auto aspect-square",
          "aria-label": _ctx.$t("g.scrollLeft"),
          disabled: !leftArrowEnabled.value,
          onMousedown: _cache[0] || (_cache[0] = ($event) => unref(whileMouseDown)($event, () => scroll(-1)))
        }, {
          default: withCtx(() => _cache[3] || (_cache[3] = [
            createBaseVNode("i", { class: "icon-[lucide--chevron-left] size-full" }, null, -1)
          ])),
          _: 1
        }, 8, ["aria-label", "disabled"])) : createCommentVNode("", true),
        createVNode(unref(script$q), {
          class: "no-drag overflow-hidden",
          "pt:content": {
            class: "p-0 w-full flex",
            onwheel: handleWheel
          },
          "pt:bar-x": "h-1"
        }, {
          default: withCtx(() => [
            createVNode(unref(script$h), {
              class: normalizeClass(["workflow-tabs bg-transparent", props.class]),
              "model-value": selectedWorkflow.value,
              options: options.value,
              "option-label": "label",
              "data-key": "value",
              "onUpdate:modelValue": onWorkflowChange
            }, {
              option: withCtx(({ option }) => [
                createVNode(_sfc_main$h, {
                  "workflow-option": option,
                  onContextmenu: /* @__PURE__ */ __name(($event) => showContextMenu($event, option), "onContextmenu"),
                  onMouseup: withModifiers(($event) => onCloseWorkflow(option), ["middle"])
                }, null, 8, ["workflow-option", "onContextmenu", "onMouseup"])
              ]),
              _: 1
            }, 8, ["class", "model-value", "options"])
          ]),
          _: 1
        }, 8, ["pt:content"]),
        showOverflowArrows.value ? (openBlock(), createBlock(_sfc_main$1Y, {
          key: 1,
          variant: "muted-textonly",
          size: "icon",
          class: "overflow-arrow overflow-arrow-right h-full w-auto aspect-square",
          "aria-label": _ctx.$t("g.scrollRight"),
          disabled: !rightArrowEnabled.value,
          onMousedown: _cache[1] || (_cache[1] = ($event) => unref(whileMouseDown)($event, () => scroll(1)))
        }, {
          default: withCtx(() => _cache[4] || (_cache[4] = [
            createBaseVNode("i", { class: "icon-[lucide--chevron-right] size-full" }, null, -1)
          ])),
          _: 1
        }, 8, ["aria-label", "disabled"])) : createCommentVNode("", true),
        showOverflowArrows.value ? (openBlock(), createBlock(_sfc_main$g, {
          key: 2,
          workflows: unref(workflowStore).openWorkflows,
          "active-workflow": unref(workflowStore).activeWorkflow
        }, null, 8, ["workflows", "active-workflow"])) : createCommentVNode("", true),
        withDirectives((openBlock(), createBlock(_sfc_main$1Y, {
          class: "new-blank-workflow-button no-drag shrink-0 rounded-none h-full w-auto aspect-square",
          variant: "muted-textonly",
          size: "icon",
          "aria-label": _ctx.$t("sideToolbar.newBlankWorkflow"),
          onClick: _cache[2] || (_cache[2] = () => unref(commandStore).execute("Comfy.NewBlankWorkflow"))
        }, {
          default: withCtx(() => _cache[5] || (_cache[5] = [
            createBaseVNode("i", { class: "pi pi-plus" }, null, -1)
          ])),
          _: 1
        }, 8, ["aria-label"])), [
          [_directive_tooltip, { value: _ctx.$t("sideToolbar.newBlankWorkflow"), showDelay: 300 }]
        ]),
        createVNode(unref(script$i), {
          ref_key: "menu",
          ref: menu,
          model: contextMenuItems.value
        }, null, 8, ["model"]),
        unref(isDesktop) ? (openBlock(), createElementBlock("div", _hoisted_1$f)) : createCommentVNode("", true)
      ], 2);
    };
  }
});
const WorkflowTabs = /* @__PURE__ */ _export_sfc(_sfc_main$f, [["__scopeId", "data-v-3fb85a76"]]);
function useLayoutSync() {
  const unsubscribe = ref();
  function startSync(canvas) {
    if (!canvas?.graph) return;
    stopSync();
    unsubscribe.value = layoutStore.onChange((change) => {
      for (const nodeId of change.nodeIds) {
        const layout = layoutStore.getNodeLayoutRef(nodeId).value;
        if (!layout) continue;
        const liteNode = canvas.graph?.getNodeById(parseInt(nodeId));
        if (!liteNode) continue;
        if (liteNode.pos[0] !== layout.position.x || liteNode.pos[1] !== layout.position.y) {
          liteNode.pos[0] = layout.position.x;
          liteNode.pos[1] = layout.position.y;
        }
        if (liteNode.size[0] !== layout.size.width || liteNode.size[1] !== layout.size.height) {
          liteNode.setSize([layout.size.width, layout.size.height]);
        }
      }
      canvas.setDirty(true, true);
    });
  }
  __name(startSync, "startSync");
  function stopSync() {
    unsubscribe.value?.();
    unsubscribe.value = void 0;
  }
  __name(stopSync, "stopSync");
  onUnmounted(stopSync);
  return {
    startSync,
    stopSync
  };
}
__name(useLayoutSync, "useLayoutSync");
function useVueNodeLifecycleIndividual() {
  const canvasStore = useCanvasStore();
  const layoutMutations = useLayoutMutations();
  const { shouldRenderVueNodes } = useVueFeatureFlags();
  const nodeManager = shallowRef(null);
  const { startSync } = useLayoutSync();
  const initializeNodeManager = /* @__PURE__ */ __name(() => {
    const activeGraph = app.canvas?.graph;
    if (!activeGraph || nodeManager.value) return;
    const manager = useGraphNodeManager(activeGraph);
    nodeManager.value = manager;
    const nodes = activeGraph._nodes.map((node) => ({
      id: node.id.toString(),
      pos: [node.pos[0], node.pos[1]],
      size: [node.size[0], removeNodeTitleHeight(node.size[1])]
    }));
    layoutStore.initializeFromLiteGraph(nodes);
    for (const reroute of activeGraph.reroutes.values()) {
      const [x, y] = reroute.pos;
      const parent = reroute.parentId ?? void 0;
      const linkIds = Array.from(reroute.linkIds);
      layoutMutations.createReroute(reroute.id, { x, y }, parent, linkIds);
    }
    for (const link of activeGraph._links.values()) {
      layoutMutations.createLink(
        link.id,
        link.origin_id,
        link.origin_slot,
        link.target_id,
        link.target_slot
      );
    }
    startSync(canvasStore.canvas);
  }, "initializeNodeManager");
  const disposeNodeManagerAndSyncs = /* @__PURE__ */ __name(() => {
    if (!nodeManager.value) return;
    try {
      nodeManager.value.cleanup();
    } catch {
    }
    nodeManager.value = null;
  }, "disposeNodeManagerAndSyncs");
  watch(
    () => shouldRenderVueNodes.value && Boolean(app.canvas?.graph),
    (enabled) => {
      if (enabled) {
        initializeNodeManager();
        ensureCorrectLayoutScale(
          app.canvas?.graph?.extra.workflowRendererVersion
        );
      }
    },
    { immediate: true }
  );
  whenever(
    () => !shouldRenderVueNodes.value,
    () => {
      ensureCorrectLayoutScale(
        app.canvas?.graph?.extra.workflowRendererVersion
      );
      disposeNodeManagerAndSyncs();
      app.canvas?.setDirty(true, true);
    }
  );
  watch(
    () => shouldRenderVueNodes.value,
    (vueMode, oldVueMode) => {
      const modeChanged = vueMode !== oldVueMode;
      if (modeChanged) {
        layoutStore.clearAllSlotLayouts();
      }
    },
    { immediate: true, flush: "sync" }
  );
  const setupEmptyGraphListener = /* @__PURE__ */ __name(() => {
    const activeGraph = app.canvas?.graph;
    if (!shouldRenderVueNodes.value || nodeManager.value || activeGraph?._nodes.length !== 0) {
      return;
    }
    const originalOnNodeAdded = activeGraph.onNodeAdded;
    activeGraph.onNodeAdded = function(node) {
      activeGraph.onNodeAdded = originalOnNodeAdded;
      if (shouldRenderVueNodes.value && !nodeManager.value) {
        initializeNodeManager();
      }
      if (originalOnNodeAdded) {
        originalOnNodeAdded.call(this, node);
      }
    };
  }, "setupEmptyGraphListener");
  const cleanup = /* @__PURE__ */ __name(() => {
    if (nodeManager.value) {
      nodeManager.value.cleanup();
      nodeManager.value = null;
    }
  }, "cleanup");
  return {
    nodeManager,
    // Lifecycle methods
    initializeNodeManager,
    disposeNodeManagerAndSyncs,
    setupEmptyGraphListener,
    cleanup
  };
}
__name(useVueNodeLifecycleIndividual, "useVueNodeLifecycleIndividual");
const useVueNodeLifecycle = createSharedComposable(
  useVueNodeLifecycleIndividual
);
const DEFAULT_NUMBER_OPTIONS = {
  minimumFractionDigits: 0,
  maximumFractionDigits: 0
};
const formatCreditsValue = /* @__PURE__ */ __name((usd) => formatCreditsFromUsd({
  usd,
  numberOptions: DEFAULT_NUMBER_OPTIONS
}), "formatCreditsValue");
const makePrefix = /* @__PURE__ */ __name((approximate) => approximate ? "~" : "", "makePrefix");
const makeSuffix = /* @__PURE__ */ __name((suffix) => suffix ?? "/Run", "makeSuffix");
const appendNote = /* @__PURE__ */ __name((note) => note ? ` ${note}` : "", "appendNote");
const formatCreditsLabel = /* @__PURE__ */ __name((usd, { suffix, note, approximate } = {}) => `${makePrefix(approximate)}${formatCreditsValue(usd)} credits${makeSuffix(suffix)}${appendNote(note)}`, "formatCreditsLabel");
const formatCreditsRangeLabel = /* @__PURE__ */ __name((minUsd, maxUsd, { suffix, note, approximate } = {}) => {
  const min = formatCreditsValue(minUsd);
  const max = formatCreditsValue(maxUsd);
  const rangeValue = min === max ? min : `${min}-${max}`;
  return `${makePrefix(approximate)}${rangeValue} credits${makeSuffix(suffix)}${appendNote(note)}`;
}, "formatCreditsRangeLabel");
const formatCreditsListLabel = /* @__PURE__ */ __name((usdValues, { suffix, note, approximate, separator } = {}) => {
  const parts = usdValues.map((value2) => formatCreditsValue(value2));
  const value = parts.join(separator ?? "/");
  return `${makePrefix(approximate)}${value} credits${makeSuffix(suffix)}${appendNote(note)}`;
}, "formatCreditsListLabel");
function safePricingExecution(fn, node, fallback = "") {
  try {
    return fn(node);
  } catch (error) {
    return fallback;
  }
}
__name(safePricingExecution, "safePricingExecution");
const calculateRunwayDurationPrice = /* @__PURE__ */ __name((node) => {
  const durationWidget = node.widgets?.find(
    (w) => w.name === "duration"
  );
  if (!durationWidget) return formatCreditsLabel(0.0715, { suffix: "/second" });
  const duration = Number(durationWidget.value);
  const validDuration = isNaN(duration) ? 5 : duration;
  const cost = 0.0715 * validDuration;
  return formatCreditsLabel(cost);
}, "calculateRunwayDurationPrice");
const makeOmniProDurationCalculator = /* @__PURE__ */ __name((pricePerSecond) => (node) => {
  const durationWidget = node.widgets?.find(
    (w) => w.name === "duration"
  );
  if (!durationWidget)
    return formatCreditsLabel(pricePerSecond, { suffix: "/second" });
  const seconds = parseFloat(String(durationWidget.value));
  if (!Number.isFinite(seconds))
    return formatCreditsLabel(pricePerSecond, { suffix: "/second" });
  const cost = pricePerSecond * seconds;
  return formatCreditsLabel(cost);
}, "makeOmniProDurationCalculator");
const klingMotionControlPricingCalculator = /* @__PURE__ */ __name((node) => {
  const modeWidget = node.widgets?.find(
    (w) => w.name === "mode"
  );
  if (!modeWidget) {
    return formatCreditsListLabel([0.07, 0.112], {
      suffix: "/second",
      note: "(std/pro)"
    });
  }
  const mode = String(modeWidget.value).toLowerCase();
  if (mode === "pro") return formatCreditsLabel(0.112, { suffix: "/second" });
  if (mode === "std") return formatCreditsLabel(0.07, { suffix: "/second" });
  return formatCreditsListLabel([0.07, 0.112], {
    suffix: "/second",
    note: "(std/pro)"
  });
}, "klingMotionControlPricingCalculator");
const pixversePricingCalculator = /* @__PURE__ */ __name((node) => {
  const durationWidget = node.widgets?.find(
    (w) => w.name === "duration_seconds"
  );
  const qualityWidget = node.widgets?.find(
    (w) => w.name === "quality"
  );
  const motionModeWidget = node.widgets?.find(
    (w) => w.name === "motion_mode"
  );
  if (!durationWidget || !qualityWidget) {
    return formatCreditsRangeLabel(0.45, 1.2, {
      note: "(varies with duration, quality & motion mode)"
    });
  }
  const duration = String(durationWidget.value);
  const quality = String(qualityWidget.value);
  const motionMode = String(motionModeWidget?.value);
  if (duration.includes("5")) {
    if (quality.includes("1080p")) return formatCreditsLabel(1.2);
    if (quality.includes("720p") && motionMode?.includes("fast"))
      return formatCreditsLabel(1.2);
    if (quality.includes("720p") && motionMode?.includes("normal"))
      return formatCreditsLabel(0.6);
    if (quality.includes("540p") && motionMode?.includes("fast"))
      return formatCreditsLabel(0.9);
    if (quality.includes("540p") && motionMode?.includes("normal"))
      return formatCreditsLabel(0.45);
    if (quality.includes("360p") && motionMode?.includes("fast"))
      return formatCreditsLabel(0.9);
    if (quality.includes("360p") && motionMode?.includes("normal"))
      return formatCreditsLabel(0.45);
  } else if (duration.includes("8")) {
    if (quality.includes("540p") && motionMode?.includes("normal"))
      return formatCreditsLabel(0.9);
    if (quality.includes("540p") && motionMode?.includes("fast"))
      return formatCreditsLabel(1.2);
    if (quality.includes("360p") && motionMode?.includes("normal"))
      return formatCreditsLabel(0.9);
    if (quality.includes("360p") && motionMode?.includes("fast"))
      return formatCreditsLabel(1.2);
    if (quality.includes("1080p") && motionMode?.includes("normal"))
      return formatCreditsLabel(1.2);
    if (quality.includes("1080p") && motionMode?.includes("fast"))
      return formatCreditsLabel(1.2);
    if (quality.includes("720p") && motionMode?.includes("normal"))
      return formatCreditsLabel(1.2);
    if (quality.includes("720p") && motionMode?.includes("fast"))
      return formatCreditsLabel(1.2);
  }
  return formatCreditsLabel(0.9);
}, "pixversePricingCalculator");
const byteDanceVideoPricingCalculator = /* @__PURE__ */ __name((node) => {
  const modelWidget = node.widgets?.find(
    (w) => w.name === "model"
  );
  const durationWidget = node.widgets?.find(
    (w) => w.name === "duration"
  );
  const resolutionWidget = node.widgets?.find(
    (w) => w.name === "resolution"
  );
  if (!modelWidget || !durationWidget || !resolutionWidget) return "Token-based";
  const model = String(modelWidget.value).toLowerCase();
  const resolution = String(resolutionWidget.value).toLowerCase();
  const seconds = parseFloat(String(durationWidget.value));
  const priceByModel = {
    "seedance-1-0-pro": {
      "480p": [0.23, 0.24],
      "720p": [0.51, 0.56],
      "1080p": [1.18, 1.22]
    },
    "seedance-1-0-pro-fast": {
      "480p": [0.09, 0.1],
      "720p": [0.21, 0.23],
      "1080p": [0.47, 0.49]
    },
    "seedance-1-0-lite": {
      "480p": [0.17, 0.18],
      "720p": [0.37, 0.41],
      "1080p": [0.85, 0.88]
    }
  };
  const modelKey = model.includes("seedance-1-0-pro-fast") ? "seedance-1-0-pro-fast" : model.includes("seedance-1-0-pro") ? "seedance-1-0-pro" : model.includes("seedance-1-0-lite") ? "seedance-1-0-lite" : "";
  const resKey = resolution.includes("1080") ? "1080p" : resolution.includes("720") ? "720p" : resolution.includes("480") ? "480p" : "";
  const baseRange = modelKey && resKey ? priceByModel[modelKey]?.[resKey] : void 0;
  if (!baseRange) return "Token-based";
  const [min10s, max10s] = baseRange;
  const scale = seconds / 10;
  const minCost = min10s * scale;
  const maxCost = max10s * scale;
  if (minCost === maxCost) return formatCreditsLabel(minCost);
  return formatCreditsRangeLabel(minCost, maxCost);
}, "byteDanceVideoPricingCalculator");
const ltxvPricingCalculator = /* @__PURE__ */ __name((node) => {
  const modelWidget = node.widgets?.find(
    (w) => w.name === "model"
  );
  const durationWidget = node.widgets?.find(
    (w) => w.name === "duration"
  );
  const resolutionWidget = node.widgets?.find(
    (w) => w.name === "resolution"
  );
  const fallback = formatCreditsRangeLabel(0.04, 0.24, {
    suffix: "/second"
  });
  if (!modelWidget || !durationWidget || !resolutionWidget) return fallback;
  const model = String(modelWidget.value).toLowerCase();
  const resolution = String(resolutionWidget.value).toLowerCase();
  const seconds = parseFloat(String(durationWidget.value));
  const priceByModel = {
    "ltx-2 (pro)": {
      "1920x1080": 0.06,
      "2560x1440": 0.12,
      "3840x2160": 0.24
    },
    "ltx-2 (fast)": {
      "1920x1080": 0.04,
      "2560x1440": 0.08,
      "3840x2160": 0.16
    }
  };
  const modelTable = priceByModel[model];
  if (!modelTable) return fallback;
  const pps = modelTable[resolution];
  if (!pps) return fallback;
  const cost = pps * seconds;
  return formatCreditsLabel(cost);
}, "ltxvPricingCalculator");
const klingVideoWithAudioPricingCalculator = /* @__PURE__ */ __name((node) => {
  const durationWidget = node.widgets?.find(
    (w) => w.name === "duration"
  );
  const generateAudioWidget = node.widgets?.find(
    (w) => w.name === "generate_audio"
  );
  if (!durationWidget || !generateAudioWidget) {
    return formatCreditsRangeLabel(0.35, 1.4, {
      note: "(varies with duration & audio)"
    });
  }
  const duration = String(durationWidget.value);
  const generateAudio = String(generateAudioWidget.value).toLowerCase() === "true";
  if (duration === "5") {
    return generateAudio ? formatCreditsLabel(0.7) : formatCreditsLabel(0.35);
  }
  if (duration === "10") {
    return generateAudio ? formatCreditsLabel(1.4) : formatCreditsLabel(0.7);
  }
  return formatCreditsRangeLabel(0.35, 1.4, {
    note: "(varies with duration & audio)"
  });
}, "klingVideoWithAudioPricingCalculator");
const SORA_SIZES = {
  BASIC: /* @__PURE__ */ new Set(["720x1280", "1280x720"]),
  PRO: /* @__PURE__ */ new Set(["1024x1792", "1792x1024"])
};
const ALL_SIZES = /* @__PURE__ */ new Set([...SORA_SIZES.BASIC, ...SORA_SIZES.PRO]);
function validateSora2Selection(modelRaw, duration, sizeRaw) {
  const model = modelRaw?.toLowerCase() ?? "";
  const size = sizeRaw?.toLowerCase() ?? "";
  if (!duration || Number.isNaN(duration)) return "Set duration (4s / 8s / 12s)";
  if (!size) return "Set size (720x1280, 1280x720, 1024x1792, 1792x1024)";
  if (!ALL_SIZES.has(size))
    return "Invalid size. Must be 720x1280, 1280x720, 1024x1792, or 1792x1024.";
  if (model.includes("sora-2-pro")) return void 0;
  if (model.includes("sora-2") && !SORA_SIZES.BASIC.has(size))
    return "sora-2 supports only 720x1280 or 1280x720";
  if (!model.includes("sora-2")) return "Unsupported model";
  return void 0;
}
__name(validateSora2Selection, "validateSora2Selection");
function perSecForSora2(modelRaw, sizeRaw) {
  const model = modelRaw?.toLowerCase() ?? "";
  const size = sizeRaw?.toLowerCase() ?? "";
  if (model.includes("sora-2-pro")) {
    return SORA_SIZES.PRO.has(size) ? 0.5 : 0.3;
  }
  if (model.includes("sora-2")) return 0.1;
  return SORA_SIZES.PRO.has(size) ? 0.5 : 0.1;
}
__name(perSecForSora2, "perSecForSora2");
function formatRunPrice(perSec, duration) {
  return formatCreditsLabel(Number((perSec * duration).toFixed(2)));
}
__name(formatRunPrice, "formatRunPrice");
const sora2PricingCalculator = /* @__PURE__ */ __name((node) => {
  const getWidgetValue = /* @__PURE__ */ __name((name) => String(node.widgets?.find((w) => w.name === name)?.value ?? ""), "getWidgetValue");
  const model = getWidgetValue("model");
  const size = getWidgetValue("size");
  const duration = Number(
    node.widgets?.find((w) => ["duration", "duration_s"].includes(w.name))?.value
  );
  if (!model || !size || !duration) return "Set model, duration & size";
  const validationError = validateSora2Selection(model, duration, size);
  if (validationError) return validationError;
  const perSec = perSecForSora2(model, size);
  return formatRunPrice(perSec, duration);
}, "sora2PricingCalculator");
const calculateTripo3DGenerationPrice = /* @__PURE__ */ __name((node, task) => {
  const getWidget = /* @__PURE__ */ __name((name) => node.widgets?.find((w) => w.name === name), "getWidget");
  const getString = /* @__PURE__ */ __name((name, defaultValue) => {
    const widget = getWidget(name);
    if (!widget || widget.value === void 0 || widget.value === null) {
      return defaultValue;
    }
    return String(widget.value);
  }, "getString");
  const getBool = /* @__PURE__ */ __name((name, defaultValue) => {
    const widget = getWidget(name);
    if (!widget || widget.value === void 0 || widget.value === null) {
      return defaultValue;
    }
    const v = widget.value;
    if (typeof v === "number") return v !== 0;
    const lower = String(v).toLowerCase();
    if (lower === "true") return true;
    if (lower === "false") return false;
    return defaultValue;
  }, "getBool");
  const modelVersionRaw = getString("model_version", "").toLowerCase();
  if (modelVersionRaw === "")
    return formatCreditsRangeLabel(0.1, 0.65, {
      note: "(varies with quad, style, texture & quality)"
    });
  const styleRaw = getString("style", "None");
  const hasStyle = styleRaw.toLowerCase() !== "none";
  const hasTexture = getBool("texture", false);
  const hasPbr = getBool("pbr", false);
  const quad = getBool("quad", false);
  const textureQualityRaw = getString(
    "texture_quality",
    "standard"
  ).toLowerCase();
  const geometryQualityRaw = getString(
    "geometry_quality",
    "standard"
  ).toLowerCase();
  const isHdTexture = textureQualityRaw === "detailed";
  const isDetailedGeometry = geometryQualityRaw === "detailed";
  const withTexture = hasTexture || hasPbr;
  let baseCredits;
  if (modelVersionRaw.includes("v1.4")) {
    if (task === "text") {
      baseCredits = 20;
    } else {
      baseCredits = 30;
    }
  } else {
    if (!withTexture) {
      if (task === "text") {
        baseCredits = 10;
      } else {
        baseCredits = 20;
      }
    } else {
      if (task === "text") {
        baseCredits = 20;
      } else {
        baseCredits = 30;
      }
    }
  }
  let credits = baseCredits;
  if (hasStyle) credits += 5;
  if (quad) credits += 5;
  if (isHdTexture) credits += 10;
  if (isDetailedGeometry) credits += 20;
  const dollars = credits * 0.01;
  return formatCreditsLabel(dollars);
}, "calculateTripo3DGenerationPrice");
const apiNodeCosts = {
  FluxProCannyNode: {
    displayPrice: formatCreditsLabel(0.05)
  },
  FluxProDepthNode: {
    displayPrice: formatCreditsLabel(0.05)
  },
  FluxProExpandNode: {
    displayPrice: formatCreditsLabel(0.05)
  },
  FluxProFillNode: {
    displayPrice: formatCreditsLabel(0.05)
  },
  FluxProUltraImageNode: {
    displayPrice: formatCreditsLabel(0.06)
  },
  FluxProKontextProNode: {
    displayPrice: formatCreditsLabel(0.04)
  },
  FluxProKontextMaxNode: {
    displayPrice: formatCreditsLabel(0.08)
  },
  Flux2ProImageNode: {
    displayPrice: /* @__PURE__ */ __name((node) => {
      const widthW = node.widgets?.find(
        (w2) => w2.name === "width"
      );
      const heightW = node.widgets?.find(
        (w2) => w2.name === "height"
      );
      const w = Number(widthW?.value);
      const h = Number(heightW?.value);
      if (!Number.isFinite(w) || !Number.isFinite(h) || w <= 0 || h <= 0) {
        return formatCreditsRangeLabel(0.03, 0.15);
      }
      const imagesInput = node.inputs?.find(
        (i) => i.name === "images"
      );
      const hasRefs = typeof imagesInput?.link !== "undefined" && imagesInput.link != null;
      const MP = 1024 * 1024;
      const outMP = Math.max(1, Math.floor((w * h + MP - 1) / MP));
      const outputCost = 0.03 + 0.015 * Math.max(outMP - 1, 0);
      if (hasRefs) {
        const minTotal = outputCost + 0.015;
        const maxTotal = outputCost + 0.12;
        return formatCreditsRangeLabel(minTotal, maxTotal, {
          approximate: true
        });
      }
      return formatCreditsLabel(outputCost);
    }, "displayPrice")
  },
  Flux2MaxImageNode: {
    displayPrice: /* @__PURE__ */ __name((node) => {
      const widthW = node.widgets?.find(
        (w2) => w2.name === "width"
      );
      const heightW = node.widgets?.find(
        (w2) => w2.name === "height"
      );
      const w = Number(widthW?.value);
      const h = Number(heightW?.value);
      if (!Number.isFinite(w) || !Number.isFinite(h) || w <= 0 || h <= 0) {
        return formatCreditsRangeLabel(0.07, 0.35);
      }
      const imagesInput = node.inputs?.find(
        (i) => i.name === "images"
      );
      const hasRefs = typeof imagesInput?.link !== "undefined" && imagesInput.link != null;
      const MP = 1024 * 1024;
      const outMP = Math.max(1, Math.floor((w * h + MP - 1) / MP));
      const outputCost = 0.07 + 0.03 * Math.max(outMP - 1, 0);
      if (hasRefs) {
        const minTotal = outputCost + 0.03;
        const maxTotal = outputCost + 0.24;
        return formatCreditsRangeLabel(minTotal, maxTotal);
      }
      return formatCreditsLabel(outputCost);
    }, "displayPrice")
  },
  OpenAIVideoSora2: {
    displayPrice: sora2PricingCalculator
  },
  IdeogramV1: {
    displayPrice: /* @__PURE__ */ __name((node) => {
      const numImagesWidget = node.widgets?.find(
        (w) => w.name === "num_images"
      );
      const turboWidget = node.widgets?.find(
        (w) => w.name === "turbo"
      );
      if (!numImagesWidget)
        return formatCreditsRangeLabel(0.03, 0.09, {
          suffix: " x num_images/Run"
        });
      const numImages = Number(numImagesWidget.value) || 1;
      const turbo = String(turboWidget?.value).toLowerCase() === "true";
      const basePrice = turbo ? 0.0286 : 0.0858;
      const cost = Number((basePrice * numImages).toFixed(2));
      return formatCreditsLabel(cost);
    }, "displayPrice")
  },
  IdeogramV2: {
    displayPrice: /* @__PURE__ */ __name((node) => {
      const numImagesWidget = node.widgets?.find(
        (w) => w.name === "num_images"
      );
      const turboWidget = node.widgets?.find(
        (w) => w.name === "turbo"
      );
      if (!numImagesWidget)
        return formatCreditsRangeLabel(0.07, 0.11, {
          suffix: " x num_images/Run"
        });
      const numImages = Number(numImagesWidget.value) || 1;
      const turbo = String(turboWidget?.value).toLowerCase() === "true";
      const basePrice = turbo ? 0.0715 : 0.1144;
      const cost = Number((basePrice * numImages).toFixed(2));
      return formatCreditsLabel(cost);
    }, "displayPrice")
  },
  IdeogramV3: {
    displayPrice: /* @__PURE__ */ __name((node) => {
      const renderingSpeedWidget = node.widgets?.find(
        (w) => w.name === "rendering_speed"
      );
      const numImagesWidget = node.widgets?.find(
        (w) => w.name === "num_images"
      );
      const characterInput = node.inputs?.find(
        (i) => i.name === "character_image"
      );
      const hasCharacter = typeof characterInput?.link !== "undefined" && characterInput.link != null;
      if (!renderingSpeedWidget)
        return formatCreditsRangeLabel(0.04, 0.11, {
          suffix: " x num_images/Run",
          note: "(varies with rendering speed & num_images)"
        });
      const numImages = Number(numImagesWidget?.value) || 1;
      let basePrice = 0.0858;
      const renderingSpeed = String(renderingSpeedWidget.value);
      if (renderingSpeed.toLowerCase().includes("quality")) {
        if (hasCharacter) {
          basePrice = 0.286;
        } else {
          basePrice = 0.1287;
        }
      } else if (renderingSpeed.toLowerCase().includes("default")) {
        if (hasCharacter) {
          basePrice = 0.2145;
        } else {
          basePrice = 0.0858;
        }
      } else if (renderingSpeed.toLowerCase().includes("turbo")) {
        if (hasCharacter) {
          basePrice = 0.143;
        } else {
          basePrice = 0.0429;
        }
      }
      const totalCost = Number((basePrice * numImages).toFixed(2));
      return formatCreditsLabel(totalCost);
    }, "displayPrice")
  },
  KlingCameraControlI2VNode: {
    displayPrice: formatCreditsLabel(0.49)
  },
  KlingCameraControlT2VNode: {
    displayPrice: formatCreditsLabel(0.14)
  },
  KlingDualCharacterVideoEffectNode: {
    displayPrice: /* @__PURE__ */ __name((node) => {
      const modeWidget = node.widgets?.find(
        (w) => w.name === "mode"
      );
      const modelWidget = node.widgets?.find(
        (w) => w.name === "model_name"
      );
      const durationWidget = node.widgets?.find(
        (w) => w.name === "duration"
      );
      if (!modeWidget || !modelWidget || !durationWidget)
        return formatCreditsRangeLabel(0.14, 2.8, {
          note: "(varies with model, mode & duration)"
        });
      const modeValue = String(modeWidget.value);
      const durationValue = String(durationWidget.value);
      const modelValue = String(modelWidget.value);
      if (modelValue.includes("v1-6") || modelValue.includes("v1-5")) {
        if (modeValue.includes("pro")) {
          return durationValue.includes("10") ? formatCreditsLabel(0.98) : formatCreditsLabel(0.49);
        } else {
          return durationValue.includes("10") ? formatCreditsLabel(0.56) : formatCreditsLabel(0.28);
        }
      } else if (modelValue.includes("v1")) {
        if (modeValue.includes("pro")) {
          return durationValue.includes("10") ? formatCreditsLabel(0.98) : formatCreditsLabel(0.49);
        } else {
          return durationValue.includes("10") ? formatCreditsLabel(0.28) : formatCreditsLabel(0.14);
        }
      }
      return formatCreditsLabel(0.14);
    }, "displayPrice")
  },
  KlingImage2VideoNode: {
    displayPrice: /* @__PURE__ */ __name((node) => {
      const modeWidget = node.widgets?.find(
        (w) => w.name === "mode"
      );
      const modelWidget = node.widgets?.find(
        (w) => w.name === "model_name"
      );
      const durationWidget = node.widgets?.find(
        (w) => w.name === "duration"
      );
      if (!modeWidget) {
        if (!modelWidget)
          return formatCreditsRangeLabel(0.14, 2.8, {
            note: "(varies with model, mode & duration)"
          });
        const modelValue2 = String(modelWidget.value);
        if (modelValue2.includes("v2-1-master") || modelValue2.includes("v2-master")) {
          return formatCreditsLabel(1.4);
        } else if (modelValue2.includes("v1-6") || modelValue2.includes("v1-5")) {
          return formatCreditsLabel(0.28);
        }
        return formatCreditsLabel(0.14);
      }
      const modeValue = String(modeWidget.value);
      const durationValue = String(durationWidget.value);
      const modelValue = String(modelWidget.value);
      if (modelValue.includes("v2-5-turbo")) {
        if (durationValue.includes("10")) {
          return formatCreditsLabel(0.7);
        }
        return formatCreditsLabel(0.35);
      } else if (modelValue.includes("v2-1-master") || modelValue.includes("v2-master")) {
        if (durationValue.includes("10")) {
          return formatCreditsLabel(2.8);
        }
        return formatCreditsLabel(1.4);
      } else if (modelValue.includes("v2-1") || modelValue.includes("v1-6") || modelValue.includes("v1-5")) {
        if (modeValue.includes("pro")) {
          return durationValue.includes("10") ? formatCreditsLabel(0.98) : formatCreditsLabel(0.49);
        } else {
          return durationValue.includes("10") ? formatCreditsLabel(0.56) : formatCreditsLabel(0.28);
        }
      } else if (modelValue.includes("v1")) {
        if (modeValue.includes("pro")) {
          return durationValue.includes("10") ? formatCreditsLabel(0.98) : formatCreditsLabel(0.49);
        } else {
          return durationValue.includes("10") ? formatCreditsLabel(0.28) : formatCreditsLabel(0.14);
        }
      }
      return formatCreditsLabel(0.14);
    }, "displayPrice")
  },
  KlingImageGenerationNode: {
    displayPrice: /* @__PURE__ */ __name((node) => {
      const imageInputWidget = node.inputs?.find((i) => i.name === "image");
      const modality = imageInputWidget?.link ? "image to image" : "text to image";
      const modelWidget = node.widgets?.find(
        (w) => w.name === "model_name"
      );
      const nWidget = node.widgets?.find(
        (w) => w.name === "n"
      );
      if (!modelWidget)
        return formatCreditsRangeLabel(35e-4, 0.028, {
          suffix: " x n/Run",
          note: "(varies with modality & model)"
        });
      const model = String(modelWidget.value);
      const n = Number(nWidget?.value) || 1;
      let basePrice = 0.014;
      if (modality.includes("text to image")) {
        if (model.includes("kling-v1-5") || model.includes("kling-v2")) {
          basePrice = 0.014;
        } else if (model.includes("kling-v1")) {
          basePrice = 35e-4;
        }
      } else if (modality.includes("image to image")) {
        if (model.includes("kling-v1-5")) {
          basePrice = 0.028;
        } else if (model.includes("kling-v1")) {
          basePrice = 35e-4;
        }
      }
      const totalCost = basePrice * n;
      return formatCreditsLabel(totalCost);
    }, "displayPrice")
  },
  KlingLipSyncAudioToVideoNode: {
    displayPrice: formatCreditsLabel(0.1, { approximate: true })
  },
  KlingLipSyncTextToVideoNode: {
    displayPrice: formatCreditsLabel(0.1, { approximate: true })
  },
  KlingSingleImageVideoEffectNode: {
    displayPrice: /* @__PURE__ */ __name((node) => {
      const effectSceneWidget = node.widgets?.find(
        (w) => w.name === "effect_scene"
      );
      if (!effectSceneWidget)
        return formatCreditsRangeLabel(0.28, 0.49, {
          note: "(varies with effect scene)"
        });
      const effectScene = String(effectSceneWidget.value);
      if (effectScene.includes("fuzzyfuzzy") || effectScene.includes("squish")) {
        return formatCreditsLabel(0.28);
      } else if (effectScene.includes("dizzydizzy")) {
        return formatCreditsLabel(0.49);
      } else if (effectScene.includes("bloombloom")) {
        return formatCreditsLabel(0.49);
      } else if (effectScene.includes("expansion")) {
        return formatCreditsLabel(0.28);
      }
      return formatCreditsLabel(0.28);
    }, "displayPrice")
  },
  KlingStartEndFrameNode: {
    displayPrice: /* @__PURE__ */ __name((node) => {
      const modeWidget = node.widgets?.find(
        (w) => w.name === "mode"
      );
      if (!modeWidget)
        return formatCreditsRangeLabel(0.14, 2.8, {
          note: "(varies with model, mode & duration)"
        });
      const modeValue = String(modeWidget.value);
      if (modeValue.includes("v2-5-turbo")) {
        if (modeValue.includes("10")) {
          return formatCreditsLabel(0.7);
        }
        return formatCreditsLabel(0.35);
      } else if (modeValue.includes("v2-1")) {
        if (modeValue.includes("10s")) {
          return formatCreditsLabel(0.98);
        }
        return formatCreditsLabel(0.49);
      } else if (modeValue.includes("v2-master")) {
        if (modeValue.includes("10s")) {
          return formatCreditsLabel(2.8);
        }
        return formatCreditsLabel(1.4);
      } else if (modeValue.includes("v1-6")) {
        if (modeValue.includes("pro")) {
          return modeValue.includes("10s") ? formatCreditsLabel(0.98) : formatCreditsLabel(0.49);
        } else {
          return modeValue.includes("10s") ? formatCreditsLabel(0.56) : formatCreditsLabel(0.28);
        }
      } else if (modeValue.includes("v1")) {
        if (modeValue.includes("pro")) {
          return modeValue.includes("10s") ? formatCreditsLabel(0.98) : formatCreditsLabel(0.49);
        } else {
          return modeValue.includes("10s") ? formatCreditsLabel(0.28) : formatCreditsLabel(0.14);
        }
      }
      return formatCreditsLabel(0.14);
    }, "displayPrice")
  },
  KlingTextToVideoNode: {
    displayPrice: /* @__PURE__ */ __name((node) => {
      const modeWidget = node.widgets?.find(
        (w) => w.name === "mode"
      );
      if (!modeWidget)
        return formatCreditsRangeLabel(0.14, 2.8, {
          note: "(varies with model, mode & duration)"
        });
      const modeValue = String(modeWidget.value);
      if (modeValue.includes("v2-5-turbo")) {
        if (modeValue.includes("10")) {
          return formatCreditsLabel(0.7);
        }
        return formatCreditsLabel(0.35);
      } else if (modeValue.includes("v2-1-master")) {
        if (modeValue.includes("10s")) {
          return formatCreditsLabel(2.8);
        }
        return formatCreditsLabel(1.4);
      } else if (modeValue.includes("v2-master")) {
        if (modeValue.includes("10s")) {
          return formatCreditsLabel(2.8);
        }
        return formatCreditsLabel(1.4);
      } else if (modeValue.includes("v1-6")) {
        if (modeValue.includes("pro")) {
          return modeValue.includes("10s") ? formatCreditsLabel(0.98) : formatCreditsLabel(0.49);
        } else {
          return modeValue.includes("10s") ? formatCreditsLabel(0.56) : formatCreditsLabel(0.28);
        }
      } else if (modeValue.includes("v1")) {
        if (modeValue.includes("pro")) {
          return modeValue.includes("10s") ? formatCreditsLabel(0.98) : formatCreditsLabel(0.49);
        } else {
          return modeValue.includes("10s") ? formatCreditsLabel(0.28) : formatCreditsLabel(0.14);
        }
      }
      return formatCreditsLabel(0.14);
    }, "displayPrice")
  },
  KlingVideoExtendNode: {
    displayPrice: formatCreditsLabel(0.28)
  },
  KlingVirtualTryOnNode: {
    displayPrice: formatCreditsLabel(0.07)
  },
  KlingOmniProTextToVideoNode: {
    displayPrice: makeOmniProDurationCalculator(0.112)
  },
  KlingOmniProFirstLastFrameNode: {
    displayPrice: makeOmniProDurationCalculator(0.112)
  },
  KlingOmniProImageToVideoNode: {
    displayPrice: makeOmniProDurationCalculator(0.112)
  },
  KlingOmniProVideoToVideoNode: {
    displayPrice: makeOmniProDurationCalculator(0.168)
  },
  KlingMotionControl: {
    displayPrice: klingMotionControlPricingCalculator
  },
  KlingOmniProEditVideoNode: {
    displayPrice: formatCreditsLabel(0.168, { suffix: "/second" })
  },
  KlingOmniProImageNode: {
    displayPrice: formatCreditsLabel(0.028)
  },
  KlingTextToVideoWithAudio: {
    displayPrice: klingVideoWithAudioPricingCalculator
  },
  KlingImageToVideoWithAudio: {
    displayPrice: klingVideoWithAudioPricingCalculator
  },
  LumaImageToVideoNode: {
    displayPrice: /* @__PURE__ */ __name((node) => {
      const modelWidget = node.widgets?.find(
        (w) => w.name === "model"
      );
      const resolutionWidget = node.widgets?.find(
        (w) => w.name === "resolution"
      );
      const durationWidget = node.widgets?.find(
        (w) => w.name === "duration"
      );
      if (!modelWidget || !resolutionWidget || !durationWidget) {
        return formatCreditsRangeLabel(0.2, 16.4, {
          note: "(varies with model, resolution & duration)"
        });
      }
      const model = String(modelWidget.value);
      const resolution = String(resolutionWidget.value).toLowerCase();
      const duration = String(durationWidget.value);
      if (model.includes("ray-flash-2")) {
        if (duration.includes("5s")) {
          if (resolution.includes("4k")) return formatCreditsLabel(3.13);
          if (resolution.includes("1080p")) return formatCreditsLabel(0.79);
          if (resolution.includes("720p")) return formatCreditsLabel(0.34);
          if (resolution.includes("540p")) return formatCreditsLabel(0.2);
        } else if (duration.includes("9s")) {
          if (resolution.includes("4k")) return formatCreditsLabel(5.65);
          if (resolution.includes("1080p")) return formatCreditsLabel(1.42);
          if (resolution.includes("720p")) return formatCreditsLabel(0.61);
          if (resolution.includes("540p")) return formatCreditsLabel(0.36);
        }
      } else if (model.includes("ray-2")) {
        if (duration.includes("5s")) {
          if (resolution.includes("4k")) return formatCreditsLabel(9.11);
          if (resolution.includes("1080p")) return formatCreditsLabel(2.27);
          if (resolution.includes("720p")) return formatCreditsLabel(1.02);
          if (resolution.includes("540p")) return formatCreditsLabel(0.57);
        } else if (duration.includes("9s")) {
          if (resolution.includes("4k")) return formatCreditsLabel(16.4);
          if (resolution.includes("1080p")) return formatCreditsLabel(4.1);
          if (resolution.includes("720p")) return formatCreditsLabel(1.83);
          if (resolution.includes("540p")) return formatCreditsLabel(1.03);
        }
      } else if (model.includes("ray-1-6")) {
        return formatCreditsLabel(0.5);
      }
      return formatCreditsLabel(0.79);
    }, "displayPrice")
  },
  LumaVideoNode: {
    displayPrice: /* @__PURE__ */ __name((node) => {
      const modelWidget = node.widgets?.find(
        (w) => w.name === "model"
      );
      const resolutionWidget = node.widgets?.find(
        (w) => w.name === "resolution"
      );
      const durationWidget = node.widgets?.find(
        (w) => w.name === "duration"
      );
      if (!modelWidget || !resolutionWidget || !durationWidget) {
        return formatCreditsRangeLabel(0.2, 16.4, {
          note: "(varies with model, resolution & duration)"
        });
      }
      const model = String(modelWidget.value);
      const resolution = String(resolutionWidget.value).toLowerCase();
      const duration = String(durationWidget.value);
      if (model.includes("ray-flash-2")) {
        if (duration.includes("5s")) {
          if (resolution.includes("4k")) return formatCreditsLabel(3.13);
          if (resolution.includes("1080p")) return formatCreditsLabel(0.79);
          if (resolution.includes("720p")) return formatCreditsLabel(0.34);
          if (resolution.includes("540p")) return formatCreditsLabel(0.2);
        } else if (duration.includes("9s")) {
          if (resolution.includes("4k")) return formatCreditsLabel(5.65);
          if (resolution.includes("1080p")) return formatCreditsLabel(1.42);
          if (resolution.includes("720p")) return formatCreditsLabel(0.61);
          if (resolution.includes("540p")) return formatCreditsLabel(0.36);
        }
      } else if (model.includes("ray-2")) {
        if (duration.includes("5s")) {
          if (resolution.includes("4k")) return formatCreditsLabel(9.11);
          if (resolution.includes("1080p")) return formatCreditsLabel(2.27);
          if (resolution.includes("720p")) return formatCreditsLabel(1.02);
          if (resolution.includes("540p")) return formatCreditsLabel(0.57);
        } else if (duration.includes("9s")) {
          if (resolution.includes("4k")) return formatCreditsLabel(16.4);
          if (resolution.includes("1080p")) return formatCreditsLabel(4.1);
          if (resolution.includes("720p")) return formatCreditsLabel(1.83);
          if (resolution.includes("540p")) return formatCreditsLabel(1.03);
        }
      } else if (model.includes("ray-1-6")) {
        return formatCreditsLabel(0.5);
      }
      return formatCreditsLabel(0.79);
    }, "displayPrice")
  },
  MinimaxImageToVideoNode: {
    displayPrice: formatCreditsLabel(0.43)
  },
  MinimaxTextToVideoNode: {
    displayPrice: formatCreditsLabel(0.43)
  },
  MinimaxHailuoVideoNode: {
    displayPrice: /* @__PURE__ */ __name((node) => {
      const resolutionWidget = node.widgets?.find(
        (w) => w.name === "resolution"
      );
      const durationWidget = node.widgets?.find(
        (w) => w.name === "duration"
      );
      if (!resolutionWidget || !durationWidget) {
        return formatCreditsRangeLabel(0.28, 0.56, {
          note: "(varies with resolution & duration)"
        });
      }
      const resolution = String(resolutionWidget.value);
      const duration = String(durationWidget.value);
      if (resolution.includes("768P")) {
        if (duration.includes("6")) return formatCreditsLabel(0.28);
        if (duration.includes("10")) return formatCreditsLabel(0.56);
      } else if (resolution.includes("1080P")) {
        if (duration.includes("6")) return formatCreditsLabel(0.49);
      }
      return formatCreditsLabel(0.43);
    }, "displayPrice")
  },
  OpenAIDalle2: {
    displayPrice: /* @__PURE__ */ __name((node) => {
      const sizeWidget = node.widgets?.find(
        (w) => w.name === "size"
      );
      const nWidget = node.widgets?.find(
        (w) => w.name === "n"
      );
      if (!sizeWidget)
        return formatCreditsRangeLabel(0.016, 0.02, {
          suffix: " x n/Run",
          note: "(varies with size & n)"
        });
      const size = String(sizeWidget.value);
      const n = Number(nWidget?.value) || 1;
      let basePrice = 0.02;
      if (size.includes("1024x1024")) {
        basePrice = 0.02;
      } else if (size.includes("512x512")) {
        basePrice = 0.018;
      } else if (size.includes("256x256")) {
        basePrice = 0.016;
      }
      const totalCost = Number((basePrice * n).toFixed(3));
      return formatCreditsLabel(totalCost);
    }, "displayPrice")
  },
  OpenAIDalle3: {
    displayPrice: /* @__PURE__ */ __name((node) => {
      const sizeWidget = node.widgets?.find(
        (w) => w.name === "size"
      );
      const qualityWidget = node.widgets?.find(
        (w) => w.name === "quality"
      );
      if (!sizeWidget || !qualityWidget)
        return formatCreditsRangeLabel(0.04, 0.12, {
          note: "(varies with size & quality)"
        });
      const size = String(sizeWidget.value);
      const quality = String(qualityWidget.value);
      if (size.includes("1024x1024")) {
        return quality.includes("hd") ? formatCreditsLabel(0.08) : formatCreditsLabel(0.04);
      } else if (size.includes("1792x1024") || size.includes("1024x1792")) {
        return quality.includes("hd") ? formatCreditsLabel(0.12) : formatCreditsLabel(0.08);
      }
      return formatCreditsLabel(0.04);
    }, "displayPrice")
  },
  OpenAIGPTImage1: {
    displayPrice: /* @__PURE__ */ __name((node) => {
      const qualityWidget = node.widgets?.find(
        (w) => w.name === "quality"
      );
      const nWidget = node.widgets?.find(
        (w) => w.name === "n"
      );
      if (!qualityWidget)
        return formatCreditsRangeLabel(0.011, 0.3, {
          suffix: " x n/Run",
          note: "(varies with quality & n)"
        });
      const quality = String(qualityWidget.value);
      const n = Number(nWidget?.value) || 1;
      let range = [0.046, 0.07];
      if (quality.includes("high")) {
        range = [0.167, 0.3];
      } else if (quality.includes("medium")) {
        range = [0.046, 0.07];
      } else if (quality.includes("low")) {
        range = [0.011, 0.02];
      }
      if (n === 1) {
        return formatCreditsRangeLabel(range[0], range[1]);
      }
      return formatCreditsRangeLabel(range[0], range[1], {
        suffix: ` x ${n}/Run`
      });
    }, "displayPrice")
  },
  PixverseImageToVideoNode: {
    displayPrice: pixversePricingCalculator
  },
  PixverseTextToVideoNode: {
    displayPrice: pixversePricingCalculator
  },
  PixverseTransitionVideoNode: {
    displayPrice: pixversePricingCalculator
  },
  RecraftCreativeUpscaleNode: {
    displayPrice: formatCreditsLabel(0.25)
  },
  RecraftCrispUpscaleNode: {
    displayPrice: formatCreditsLabel(4e-3)
  },
  RecraftGenerateColorFromImageNode: {
    displayPrice: /* @__PURE__ */ __name((node) => {
      const nWidget = node.widgets?.find(
        (w) => w.name === "n"
      );
      if (!nWidget) return formatCreditsLabel(0.04, { suffix: " x n/Run" });
      const n = Number(nWidget.value) || 1;
      const cost = Number((0.04 * n).toFixed(2));
      return formatCreditsLabel(cost);
    }, "displayPrice")
  },
  RecraftGenerateImageNode: {
    displayPrice: /* @__PURE__ */ __name((node) => {
      const nWidget = node.widgets?.find(
        (w) => w.name === "n"
      );
      if (!nWidget) return formatCreditsLabel(0.04, { suffix: " x n/Run" });
      const n = Number(nWidget.value) || 1;
      const cost = Number((0.04 * n).toFixed(2));
      return formatCreditsLabel(cost);
    }, "displayPrice")
  },
  RecraftGenerateVectorImageNode: {
    displayPrice: /* @__PURE__ */ __name((node) => {
      const nWidget = node.widgets?.find(
        (w) => w.name === "n"
      );
      if (!nWidget) return formatCreditsLabel(0.08, { suffix: " x n/Run" });
      const n = Number(nWidget.value) || 1;
      const cost = Number((0.08 * n).toFixed(2));
      return formatCreditsLabel(cost);
    }, "displayPrice")
  },
  RecraftImageInpaintingNode: {
    displayPrice: /* @__PURE__ */ __name((node) => {
      const nWidget = node.widgets?.find(
        (w) => w.name === "n"
      );
      if (!nWidget) return formatCreditsLabel(0.04, { suffix: " x n/Run" });
      const n = Number(nWidget.value) || 1;
      const cost = Number((0.04 * n).toFixed(2));
      return formatCreditsLabel(cost);
    }, "displayPrice")
  },
  RecraftImageToImageNode: {
    displayPrice: /* @__PURE__ */ __name((node) => {
      const nWidget = node.widgets?.find(
        (w) => w.name === "n"
      );
      if (!nWidget) return formatCreditsLabel(0.04, { suffix: " x n/Run" });
      const n = Number(nWidget.value) || 1;
      const cost = Number((0.04 * n).toFixed(2));
      return formatCreditsLabel(cost);
    }, "displayPrice")
  },
  RecraftRemoveBackgroundNode: {
    displayPrice: formatCreditsLabel(0.01)
  },
  RecraftReplaceBackgroundNode: {
    displayPrice: formatCreditsLabel(0.04)
  },
  RecraftTextToImageNode: {
    displayPrice: /* @__PURE__ */ __name((node) => {
      const nWidget = node.widgets?.find(
        (w) => w.name === "n"
      );
      if (!nWidget) return formatCreditsLabel(0.04, { suffix: " x n/Run" });
      const n = Number(nWidget.value) || 1;
      const cost = Number((0.04 * n).toFixed(2));
      return formatCreditsLabel(cost);
    }, "displayPrice")
  },
  RecraftTextToVectorNode: {
    displayPrice: /* @__PURE__ */ __name((node) => {
      const nWidget = node.widgets?.find(
        (w) => w.name === "n"
      );
      if (!nWidget) return formatCreditsLabel(0.08, { suffix: " x n/Run" });
      const n = Number(nWidget.value) || 1;
      const cost = Number((0.08 * n).toFixed(2));
      return formatCreditsLabel(cost);
    }, "displayPrice")
  },
  RecraftVectorizeImageNode: {
    displayPrice: /* @__PURE__ */ __name((node) => {
      const nWidget = node.widgets?.find(
        (w) => w.name === "n"
      );
      if (!nWidget) return formatCreditsLabel(0.01, { suffix: " x n/Run" });
      const n = Number(nWidget.value) || 1;
      const cost = Number((0.01 * n).toFixed(2));
      return formatCreditsLabel(cost);
    }, "displayPrice")
  },
  StabilityStableImageSD_3_5Node: {
    displayPrice: /* @__PURE__ */ __name((node) => {
      const modelWidget = node.widgets?.find(
        (w) => w.name === "model"
      );
      if (!modelWidget)
        return formatCreditsRangeLabel(0.035, 0.065, {
          note: "(varies with model)"
        });
      const model = String(modelWidget.value).toLowerCase();
      if (model.includes("large")) {
        return formatCreditsLabel(0.065);
      } else if (model.includes("medium")) {
        return formatCreditsLabel(0.035);
      }
      return formatCreditsLabel(0.035);
    }, "displayPrice")
  },
  StabilityStableImageUltraNode: {
    displayPrice: formatCreditsLabel(0.08)
  },
  StabilityUpscaleConservativeNode: {
    displayPrice: formatCreditsLabel(0.25)
  },
  StabilityUpscaleCreativeNode: {
    displayPrice: formatCreditsLabel(0.25)
  },
  StabilityUpscaleFastNode: {
    displayPrice: formatCreditsLabel(0.01)
  },
  StabilityTextToAudio: {
    displayPrice: formatCreditsLabel(0.2)
  },
  StabilityAudioToAudio: {
    displayPrice: formatCreditsLabel(0.2)
  },
  StabilityAudioInpaint: {
    displayPrice: formatCreditsLabel(0.2)
  },
  VeoVideoGenerationNode: {
    displayPrice: /* @__PURE__ */ __name((node) => {
      const durationWidget = node.widgets?.find(
        (w) => w.name === "duration_seconds"
      );
      if (!durationWidget)
        return formatCreditsRangeLabel(2.5, 5, {
          note: "(varies with duration)"
        });
      const price = 0.5 * Number(durationWidget.value);
      return formatCreditsLabel(price);
    }, "displayPrice")
  },
  Veo3VideoGenerationNode: {
    displayPrice: /* @__PURE__ */ __name((node) => {
      const modelWidget = node.widgets?.find(
        (w) => w.name === "model"
      );
      const generateAudioWidget = node.widgets?.find(
        (w) => w.name === "generate_audio"
      );
      if (!modelWidget || !generateAudioWidget) {
        return formatCreditsRangeLabel(0.8, 3.2, {
          note: "(varies with model & audio generation)"
        });
      }
      const model = String(modelWidget.value);
      const generateAudio = String(generateAudioWidget.value).toLowerCase() === "true";
      if (model.includes("veo-3.0-fast-generate-001") || model.includes("veo-3.1-fast-generate")) {
        return generateAudio ? formatCreditsLabel(1.2) : formatCreditsLabel(0.8);
      } else if (model.includes("veo-3.0-generate-001") || model.includes("veo-3.1-generate")) {
        return generateAudio ? formatCreditsLabel(3.2) : formatCreditsLabel(1.6);
      }
      return formatCreditsRangeLabel(0.8, 3.2);
    }, "displayPrice")
  },
  Veo3FirstLastFrameNode: {
    displayPrice: /* @__PURE__ */ __name((node) => {
      const modelWidget = node.widgets?.find(
        (w) => w.name === "model"
      );
      const generateAudioWidget = node.widgets?.find(
        (w) => w.name === "generate_audio"
      );
      const durationWidget = node.widgets?.find(
        (w) => w.name === "duration"
      );
      if (!modelWidget || !generateAudioWidget || !durationWidget) {
        return formatCreditsRangeLabel(0.4, 3.2, {
          note: "(varies with model & audio generation)"
        });
      }
      const model = String(modelWidget.value);
      const generateAudio = String(generateAudioWidget.value).toLowerCase() === "true";
      const seconds = parseFloat(String(durationWidget.value));
      let pricePerSecond = null;
      if (model.includes("veo-3.1-fast-generate")) {
        pricePerSecond = generateAudio ? 0.15 : 0.1;
      } else if (model.includes("veo-3.1-generate")) {
        pricePerSecond = generateAudio ? 0.4 : 0.2;
      }
      if (pricePerSecond === null) {
        return formatCreditsRangeLabel(0.4, 3.2);
      }
      const cost = pricePerSecond * seconds;
      return formatCreditsLabel(cost);
    }, "displayPrice")
  },
  LumaImageNode: {
    displayPrice: /* @__PURE__ */ __name((node) => {
      const modelWidget = node.widgets?.find(
        (w) => w.name === "model"
      );
      const aspectRatioWidget = node.widgets?.find(
        (w) => w.name === "aspect_ratio"
      );
      if (!modelWidget || !aspectRatioWidget) {
        return formatCreditsRangeLabel(64e-4, 0.026, {
          note: "(varies with model & aspect ratio)"
        });
      }
      const model = String(modelWidget.value);
      if (model.includes("photon-flash-1")) {
        return formatCreditsLabel(27e-4);
      } else if (model.includes("photon-1")) {
        return formatCreditsLabel(0.0104);
      }
      return formatCreditsLabel(0.0246);
    }, "displayPrice")
  },
  LumaImageModifyNode: {
    displayPrice: /* @__PURE__ */ __name((node) => {
      const modelWidget = node.widgets?.find(
        (w) => w.name === "model"
      );
      if (!modelWidget) {
        return formatCreditsRangeLabel(27e-4, 0.0104, {
          note: "(varies with model)"
        });
      }
      const model = String(modelWidget.value);
      if (model.includes("photon-flash-1")) {
        return formatCreditsLabel(27e-4);
      } else if (model.includes("photon-1")) {
        return formatCreditsLabel(0.0104);
      }
      return formatCreditsLabel(0.0246);
    }, "displayPrice")
  },
  MoonvalleyTxt2VideoNode: {
    displayPrice: /* @__PURE__ */ __name((node) => {
      const lengthWidget = node.widgets?.find(
        (w) => w.name === "length"
      );
      if (!lengthWidget) return formatCreditsLabel(1.5);
      const length = String(lengthWidget.value);
      if (length === "5s") {
        return formatCreditsLabel(1.5);
      } else if (length === "10s") {
        return formatCreditsLabel(3);
      }
      return formatCreditsLabel(1.5);
    }, "displayPrice")
  },
  MoonvalleyImg2VideoNode: {
    displayPrice: /* @__PURE__ */ __name((node) => {
      const lengthWidget = node.widgets?.find(
        (w) => w.name === "length"
      );
      if (!lengthWidget) return formatCreditsLabel(1.5);
      const length = String(lengthWidget.value);
      if (length === "5s") {
        return formatCreditsLabel(1.5);
      } else if (length === "10s") {
        return formatCreditsLabel(3);
      }
      return formatCreditsLabel(1.5);
    }, "displayPrice")
  },
  MoonvalleyVideo2VideoNode: {
    displayPrice: /* @__PURE__ */ __name((node) => {
      const lengthWidget = node.widgets?.find(
        (w) => w.name === "length"
      );
      if (!lengthWidget) return formatCreditsLabel(2.25);
      const length = String(lengthWidget.value);
      if (length === "5s") {
        return formatCreditsLabel(2.25);
      } else if (length === "10s") {
        return formatCreditsLabel(4);
      }
      return formatCreditsLabel(2.25);
    }, "displayPrice")
  },
  // Runway nodes - using actual node names from ComfyUI
  RunwayTextToImageNode: {
    displayPrice: formatCreditsLabel(0.11)
  },
  RunwayImageToVideoNodeGen3a: {
    displayPrice: calculateRunwayDurationPrice
  },
  RunwayImageToVideoNodeGen4: {
    displayPrice: calculateRunwayDurationPrice
  },
  RunwayFirstLastFrameNode: {
    displayPrice: calculateRunwayDurationPrice
  },
  // Rodin nodes - all have the same pricing structure
  Rodin3D_Regular: {
    displayPrice: formatCreditsLabel(0.4)
  },
  Rodin3D_Detail: {
    displayPrice: formatCreditsLabel(0.4)
  },
  Rodin3D_Smooth: {
    displayPrice: formatCreditsLabel(0.4)
  },
  Rodin3D_Sketch: {
    displayPrice: formatCreditsLabel(0.4)
  },
  // Tripo nodes - using actual node names from ComfyUI
  TripoTextToModelNode: {
    displayPrice: /* @__PURE__ */ __name((node) => calculateTripo3DGenerationPrice(node, "text"), "displayPrice")
  },
  TripoImageToModelNode: {
    displayPrice: /* @__PURE__ */ __name((node) => calculateTripo3DGenerationPrice(node, "image"), "displayPrice")
  },
  TripoMultiviewToModelNode: {
    displayPrice: /* @__PURE__ */ __name((node) => calculateTripo3DGenerationPrice(node, "multiview"), "displayPrice")
  },
  TripoTextureNode: {
    displayPrice: /* @__PURE__ */ __name((node) => {
      const textureQualityWidget = node.widgets?.find(
        (w) => w.name === "texture_quality"
      );
      if (!textureQualityWidget)
        return formatCreditsRangeLabel(0.1, 0.2, {
          note: "(varies with quality)"
        });
      const textureQuality = String(textureQualityWidget.value);
      return textureQuality.includes("detailed") ? formatCreditsLabel(0.2) : formatCreditsLabel(0.1);
    }, "displayPrice")
  },
  TripoRigNode: {
    displayPrice: "$0.25/Run"
  },
  TripoConversionNode: {
    displayPrice: /* @__PURE__ */ __name((node) => {
      const getWidgetValue = /* @__PURE__ */ __name((name) => node.widgets?.find((w) => w.name === name)?.value, "getWidgetValue");
      const getNumber = /* @__PURE__ */ __name((name, defaultValue) => {
        const raw = getWidgetValue(name);
        if (raw === void 0 || raw === null || raw === "")
          return defaultValue;
        if (typeof raw === "number")
          return Number.isFinite(raw) ? raw : defaultValue;
        const n = Number(raw);
        return Number.isFinite(n) ? n : defaultValue;
      }, "getNumber");
      const getBool = /* @__PURE__ */ __name((name, defaultValue) => {
        const v = getWidgetValue(name);
        if (v === void 0 || v === null) return defaultValue;
        if (typeof v === "number") return v !== 0;
        const lower = String(v).toLowerCase();
        if (lower === "true") return true;
        if (lower === "false") return false;
        return defaultValue;
      }, "getBool");
      let hasAdvancedParam = false;
      if (getBool("quad", false)) hasAdvancedParam = true;
      if (getBool("force_symmetry", false)) hasAdvancedParam = true;
      if (getBool("flatten_bottom", false)) hasAdvancedParam = true;
      if (getBool("pivot_to_center_bottom", false)) hasAdvancedParam = true;
      if (getBool("with_animation", false)) hasAdvancedParam = true;
      if (getBool("pack_uv", false)) hasAdvancedParam = true;
      if (getBool("bake", false)) hasAdvancedParam = true;
      if (getBool("export_vertex_colors", false)) hasAdvancedParam = true;
      if (getBool("animate_in_place", false)) hasAdvancedParam = true;
      const faceLimit = getNumber("face_limit", -1);
      if (faceLimit !== -1) hasAdvancedParam = true;
      const textureSize = getNumber("texture_size", 4096);
      if (textureSize !== 4096) hasAdvancedParam = true;
      const flattenBottomThreshold = getNumber(
        "flatten_bottom_threshold",
        0
      );
      if (flattenBottomThreshold !== 0) hasAdvancedParam = true;
      const scaleFactor = getNumber("scale_factor", 1);
      if (scaleFactor !== 1) hasAdvancedParam = true;
      const textureFormatRaw = String(
        getWidgetValue("texture_format") ?? "JPEG"
      ).toUpperCase();
      if (textureFormatRaw !== "JPEG") hasAdvancedParam = true;
      const partNamesRaw = String(getWidgetValue("part_names") ?? "");
      if (partNamesRaw.trim().length > 0) hasAdvancedParam = true;
      const fbxPresetRaw = String(
        getWidgetValue("fbx_preset") ?? "blender"
      ).toLowerCase();
      if (fbxPresetRaw !== "blender") hasAdvancedParam = true;
      const exportOrientationRaw = String(
        getWidgetValue("export_orientation") ?? "default"
      ).toLowerCase();
      if (exportOrientationRaw !== "default") hasAdvancedParam = true;
      const credits = hasAdvancedParam ? 10 : 5;
      return formatCreditsLabel(credits * 0.01);
    }, "displayPrice")
  },
  TripoRetargetNode: {
    displayPrice: formatCreditsLabel(0.1)
  },
  TripoRefineNode: {
    displayPrice: formatCreditsLabel(0.3)
  },
  // Google/Gemini nodes
  GeminiNode: {
    displayPrice: /* @__PURE__ */ __name((node) => {
      const modelWidget = node.widgets?.find(
        (w) => w.name === "model"
      );
      if (!modelWidget) return "Token-based";
      const model = String(modelWidget.value);
      if (model.includes("veo-2.0")) {
        return formatCreditsLabel(0.5, { suffix: "/second" });
      } else if (model.includes("gemini-2.5-flash-preview-04-17")) {
        return formatCreditsListLabel([3e-4, 25e-4], {
          suffix: " per 1K tokens"
        });
      } else if (model.includes("gemini-2.5-flash")) {
        return formatCreditsListLabel([3e-4, 25e-4], {
          suffix: " per 1K tokens"
        });
      } else if (model.includes("gemini-2.5-pro-preview-05-06")) {
        return formatCreditsListLabel([125e-5, 0.01], {
          suffix: " per 1K tokens"
        });
      } else if (model.includes("gemini-2.5-pro")) {
        return formatCreditsListLabel([125e-5, 0.01], {
          suffix: " per 1K tokens"
        });
      } else if (model.includes("gemini-3-pro-preview")) {
        return formatCreditsListLabel([2e-3, 0.012], {
          suffix: " per 1K tokens"
        });
      }
      return "Token-based";
    }, "displayPrice")
  },
  GeminiImageNode: {
    displayPrice: formatCreditsLabel(0.039, {
      suffix: "/Image (1K)",
      approximate: true
    })
  },
  GeminiImage2Node: {
    displayPrice: /* @__PURE__ */ __name((node) => {
      const resolutionWidget = node.widgets?.find(
        (w) => w.name === "resolution"
      );
      if (!resolutionWidget) return "Token-based";
      const resolution = String(resolutionWidget.value);
      if (resolution.includes("1K")) {
        return formatCreditsLabel(0.134, {
          suffix: "/Image",
          approximate: true
        });
      } else if (resolution.includes("2K")) {
        return formatCreditsLabel(0.134, {
          suffix: "/Image",
          approximate: true
        });
      } else if (resolution.includes("4K")) {
        return formatCreditsLabel(0.24, {
          suffix: "/Image",
          approximate: true
        });
      }
      return "Token-based";
    }, "displayPrice")
  },
  // OpenAI nodes
  OpenAIChatNode: {
    displayPrice: /* @__PURE__ */ __name((node) => {
      const modelWidget = node.widgets?.find(
        (w) => w.name === "model"
      );
      if (!modelWidget) return "Token-based";
      const model = String(modelWidget.value);
      if (model.includes("o4-mini")) {
        return formatCreditsListLabel([11e-4, 44e-4], {
          suffix: " per 1K tokens"
        });
      } else if (model.includes("o1-pro")) {
        return formatCreditsListLabel([0.15, 0.6], {
          suffix: " per 1K tokens"
        });
      } else if (model.includes("o1")) {
        return formatCreditsListLabel([0.015, 0.06], {
          suffix: " per 1K tokens"
        });
      } else if (model.includes("o3-mini")) {
        return formatCreditsListLabel([11e-4, 44e-4], {
          suffix: " per 1K tokens"
        });
      } else if (model.includes("o3")) {
        return formatCreditsListLabel([0.01, 0.04], {
          suffix: " per 1K tokens"
        });
      } else if (model.includes("gpt-4o")) {
        return formatCreditsListLabel([25e-4, 0.01], {
          suffix: " per 1K tokens"
        });
      } else if (model.includes("gpt-4.1-nano")) {
        return formatCreditsListLabel([1e-4, 4e-4], {
          suffix: " per 1K tokens"
        });
      } else if (model.includes("gpt-4.1-mini")) {
        return formatCreditsListLabel([4e-4, 16e-4], {
          suffix: " per 1K tokens"
        });
      } else if (model.includes("gpt-4.1")) {
        return formatCreditsListLabel([2e-3, 8e-3], {
          suffix: " per 1K tokens"
        });
      } else if (model.includes("gpt-5-nano")) {
        return formatCreditsListLabel([5e-5, 4e-4], {
          suffix: " per 1K tokens"
        });
      } else if (model.includes("gpt-5-mini")) {
        return formatCreditsListLabel([25e-5, 2e-3], {
          suffix: " per 1K tokens"
        });
      } else if (model.includes("gpt-5")) {
        return formatCreditsListLabel([125e-5, 0.01], {
          suffix: " per 1K tokens"
        });
      }
      return "Token-based";
    }, "displayPrice")
  },
  ViduTextToVideoNode: {
    displayPrice: formatCreditsLabel(0.4)
  },
  ViduImageToVideoNode: {
    displayPrice: formatCreditsLabel(0.4)
  },
  ViduReferenceVideoNode: {
    displayPrice: formatCreditsLabel(0.4)
  },
  ViduStartEndToVideoNode: {
    displayPrice: formatCreditsLabel(0.4)
  },
  ByteDanceImageNode: {
    displayPrice: /* @__PURE__ */ __name((node) => {
      const modelWidget = node.widgets?.find(
        (w) => w.name === "model"
      );
      if (!modelWidget) return "Token-based";
      const model = String(modelWidget.value);
      if (model.includes("seedream-3-0-t2i")) {
        return formatCreditsLabel(0.03);
      }
      return "Token-based";
    }, "displayPrice")
  },
  ByteDanceImageEditNode: {
    displayPrice: /* @__PURE__ */ __name((node) => {
      const modelWidget = node.widgets?.find(
        (w) => w.name === "model"
      );
      if (!modelWidget) return "Token-based";
      const model = String(modelWidget.value);
      if (model.includes("seededit-3-0-i2i")) {
        return formatCreditsLabel(0.03);
      }
      return "Token-based";
    }, "displayPrice")
  },
  ByteDanceSeedreamNode: {
    displayPrice: /* @__PURE__ */ __name((node) => {
      const modelWidget = node.widgets?.find(
        (w) => w.name === "model"
      );
      const model = String(modelWidget?.value ?? "").toLowerCase();
      let pricePerImage = 0.03;
      if (model.includes("seedream-4-5-251128")) {
        pricePerImage = 0.04;
      } else if (model.includes("seedream-4-0-250828")) {
        pricePerImage = 0.03;
      }
      return formatCreditsLabel(pricePerImage, {
        suffix: " x images/Run",
        approximate: true
      });
    }, "displayPrice")
  },
  ByteDanceTextToVideoNode: {
    displayPrice: byteDanceVideoPricingCalculator
  },
  ByteDanceImageToVideoNode: {
    displayPrice: byteDanceVideoPricingCalculator
  },
  ByteDanceFirstLastFrameNode: {
    displayPrice: byteDanceVideoPricingCalculator
  },
  ByteDanceImageReferenceNode: {
    displayPrice: byteDanceVideoPricingCalculator
  },
  WanTextToVideoApi: {
    displayPrice: /* @__PURE__ */ __name((node) => {
      const durationWidget = node.widgets?.find(
        (w) => w.name === "duration"
      );
      const resolutionWidget = node.widgets?.find(
        (w) => w.name === "size"
      );
      if (!durationWidget || !resolutionWidget)
        return formatCreditsRangeLabel(0.05, 0.15, { suffix: "/second" });
      const seconds = parseFloat(String(durationWidget.value));
      const resolutionStr = String(resolutionWidget.value).toLowerCase();
      const resKey = resolutionStr.includes("1080") ? "1080p" : resolutionStr.includes("720") ? "720p" : resolutionStr.includes("480") ? "480p" : resolutionStr.match(/^\s*(\d{3,4}p)/)?.[1] ?? "";
      const pricePerSecond = {
        "480p": 0.05,
        "720p": 0.1,
        "1080p": 0.15
      };
      const pps = pricePerSecond[resKey];
      if (isNaN(seconds) || !pps)
        return formatCreditsRangeLabel(0.05, 0.15, { suffix: "/second" });
      const cost = Number((pps * seconds).toFixed(2));
      return formatCreditsLabel(cost);
    }, "displayPrice")
  },
  WanImageToVideoApi: {
    displayPrice: /* @__PURE__ */ __name((node) => {
      const durationWidget = node.widgets?.find(
        (w) => w.name === "duration"
      );
      const resolutionWidget = node.widgets?.find(
        (w) => w.name === "resolution"
      );
      if (!durationWidget || !resolutionWidget)
        return formatCreditsRangeLabel(0.05, 0.15, { suffix: "/second" });
      const seconds = parseFloat(String(durationWidget.value));
      const resolution = String(resolutionWidget.value).trim().toLowerCase();
      const pricePerSecond = {
        "480p": 0.05,
        "720p": 0.1,
        "1080p": 0.15
      };
      const pps = pricePerSecond[resolution];
      if (isNaN(seconds) || !pps)
        return formatCreditsRangeLabel(0.05, 0.15, { suffix: "/second" });
      const cost = Number((pps * seconds).toFixed(2));
      return formatCreditsLabel(cost);
    }, "displayPrice")
  },
  WanTextToImageApi: {
    displayPrice: formatCreditsLabel(0.03)
  },
  WanImageToImageApi: {
    displayPrice: formatCreditsLabel(0.03)
  },
  LtxvApiTextToVideo: {
    displayPrice: ltxvPricingCalculator
  },
  LtxvApiImageToVideo: {
    displayPrice: ltxvPricingCalculator
  }
};
const useNodePricing = /* @__PURE__ */ __name(() => {
  const getNodeDisplayPrice = /* @__PURE__ */ __name((node) => {
    if (!node.constructor?.nodeData?.api_node) return "";
    const nodeName = node.constructor.nodeData.name;
    const priceConfig = apiNodeCosts[nodeName];
    if (!priceConfig) return "";
    if (typeof priceConfig.displayPrice === "function") {
      return safePricingExecution(priceConfig.displayPrice, node, "");
    }
    return priceConfig.displayPrice;
  }, "getNodeDisplayPrice");
  const getNodePricingConfig = /* @__PURE__ */ __name((node) => apiNodeCosts[node.constructor.nodeData?.name ?? ""], "getNodePricingConfig");
  const getRelevantWidgetNames = /* @__PURE__ */ __name((nodeType) => {
    const widgetMap = {
      KlingTextToVideoNode: ["mode", "model_name", "duration"],
      KlingImage2VideoNode: ["mode", "model_name", "duration"],
      KlingImageGenerationNode: ["modality", "model_name", "n"],
      KlingDualCharacterVideoEffectNode: ["mode", "model_name", "duration"],
      KlingSingleImageVideoEffectNode: ["effect_scene"],
      KlingStartEndFrameNode: ["mode", "model_name", "duration"],
      KlingTextToVideoWithAudio: ["duration", "generate_audio"],
      KlingImageToVideoWithAudio: ["duration", "generate_audio"],
      KlingOmniProTextToVideoNode: ["duration"],
      KlingOmniProFirstLastFrameNode: ["duration"],
      KlingOmniProImageToVideoNode: ["duration"],
      KlingOmniProVideoToVideoNode: ["duration"],
      KlingMotionControl: ["mode"],
      MinimaxHailuoVideoNode: ["resolution", "duration"],
      OpenAIDalle3: ["size", "quality"],
      OpenAIDalle2: ["size", "n"],
      OpenAIVideoSora2: ["model", "size", "duration"],
      OpenAIGPTImage1: ["quality", "n"],
      IdeogramV1: ["num_images", "turbo"],
      IdeogramV2: ["num_images", "turbo"],
      IdeogramV3: ["rendering_speed", "num_images", "character_image"],
      FluxProKontextProNode: [],
      FluxProKontextMaxNode: [],
      Flux2ProImageNode: ["width", "height", "images"],
      Flux2MaxImageNode: ["width", "height", "images"],
      VeoVideoGenerationNode: ["duration_seconds"],
      Veo3VideoGenerationNode: ["model", "generate_audio"],
      Veo3FirstLastFrameNode: ["model", "generate_audio", "duration"],
      LumaVideoNode: ["model", "resolution", "duration"],
      LumaImageToVideoNode: ["model", "resolution", "duration"],
      LumaImageNode: ["model", "aspect_ratio"],
      LumaImageModifyNode: ["model", "aspect_ratio"],
      PixverseTextToVideoNode: ["duration_seconds", "quality", "motion_mode"],
      PixverseTransitionVideoNode: [
        "duration_seconds",
        "motion_mode",
        "quality"
      ],
      PixverseImageToVideoNode: ["duration_seconds", "quality", "motion_mode"],
      StabilityStableImageSD_3_5Node: ["model"],
      RecraftTextToImageNode: ["n"],
      RecraftImageToImageNode: ["n"],
      RecraftImageInpaintingNode: ["n"],
      RecraftTextToVectorNode: ["n"],
      RecraftVectorizeImageNode: ["n"],
      RecraftGenerateColorFromImageNode: ["n"],
      RecraftGenerateImageNode: ["n"],
      RecraftGenerateVectorImageNode: ["n"],
      MoonvalleyTxt2VideoNode: ["length"],
      MoonvalleyImg2VideoNode: ["length"],
      MoonvalleyVideo2VideoNode: ["length"],
      // Runway nodes
      RunwayImageToVideoNodeGen3a: ["duration"],
      RunwayImageToVideoNodeGen4: ["duration"],
      RunwayFirstLastFrameNode: ["duration"],
      // Tripo nodes
      TripoTextToModelNode: [
        "model_version",
        "quad",
        "style",
        "texture",
        "pbr",
        "texture_quality",
        "geometry_quality"
      ],
      TripoImageToModelNode: [
        "model_version",
        "quad",
        "style",
        "texture",
        "pbr",
        "texture_quality",
        "geometry_quality"
      ],
      TripoMultiviewToModelNode: [
        "model_version",
        "quad",
        "texture",
        "pbr",
        "texture_quality",
        "geometry_quality"
      ],
      TripoConversionNode: [
        "quad",
        "face_limit",
        "texture_size",
        "texture_format",
        "force_symmetry",
        "flatten_bottom",
        "flatten_bottom_threshold",
        "pivot_to_center_bottom",
        "scale_factor",
        "with_animation",
        "pack_uv",
        "bake",
        "part_names",
        "fbx_preset",
        "export_vertex_colors",
        "export_orientation",
        "animate_in_place"
      ],
      TripoTextureNode: ["texture_quality"],
      // Google/Gemini nodes
      GeminiNode: ["model"],
      GeminiImage2Node: ["resolution"],
      // OpenAI nodes
      OpenAIChatNode: ["model"],
      // ByteDance
      ByteDanceImageNode: ["model"],
      ByteDanceImageEditNode: ["model"],
      ByteDanceSeedreamNode: [
        "model",
        "sequential_image_generation",
        "max_images"
      ],
      ByteDanceTextToVideoNode: ["model", "duration", "resolution"],
      ByteDanceImageToVideoNode: ["model", "duration", "resolution"],
      ByteDanceFirstLastFrameNode: ["model", "duration", "resolution"],
      ByteDanceImageReferenceNode: ["model", "duration", "resolution"],
      WanTextToVideoApi: ["duration", "size"],
      WanImageToVideoApi: ["duration", "resolution"],
      LtxvApiTextToVideo: ["model", "duration", "resolution"],
      LtxvApiImageToVideo: ["model", "duration", "resolution"]
    };
    return widgetMap[nodeType] || [];
  }, "getRelevantWidgetNames");
  return {
    getNodeDisplayPrice,
    getNodePricingConfig,
    getRelevantWidgetNames
  };
}, "useNodePricing");
const componentIconSvg = new Image();
componentIconSvg.src = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='24' height='24' viewBox='0 0 24 24'%3E%3Cpath fill='none' stroke='oklch(83.01%25 0.163 83.16)' stroke-linecap='round' stroke-linejoin='round' stroke-width='2' d='M15.536 11.293a1 1 0 0 0 0 1.414l2.376 2.377a1 1 0 0 0 1.414 0l2.377-2.377a1 1 0 0 0 0-1.414l-2.377-2.377a1 1 0 0 0-1.414 0zm-13.239 0a1 1 0 0 0 0 1.414l2.377 2.377a1 1 0 0 0 1.414 0l2.377-2.377a1 1 0 0 0 0-1.414L6.088 8.916a1 1 0 0 0-1.414 0zm6.619 6.619a1 1 0 0 0 0 1.415l2.377 2.376a1 1 0 0 0 1.414 0l2.377-2.376a1 1 0 0 0 0-1.415l-2.377-2.376a1 1 0 0 0-1.414 0zm0-13.238a1 1 0 0 0 0 1.414l2.377 2.376a1 1 0 0 0 1.414 0l2.377-2.376a1 1 0 0 0 0-1.414l-2.377-2.377a1 1 0 0 0-1.414 0z'/%3E%3C/svg%3E";
const usePriceBadge = /* @__PURE__ */ __name(() => {
  function updateSubgraphCredits(node) {
    if (!node.isSubgraphNode()) return;
    node.badges = node.badges.filter((b) => !isCreditsBadge(b));
    const newBadges = collectCreditsBadges(node.subgraph);
    if (newBadges.length > 1) {
      node.badges.push(getCreditsBadge("Partner Nodes x " + newBadges.length));
    } else {
      node.badges.push(...newBadges);
    }
  }
  __name(updateSubgraphCredits, "updateSubgraphCredits");
  function collectCreditsBadges(graph, visited = /* @__PURE__ */ new Set()) {
    if (visited.has(graph.id)) return [];
    visited.add(graph.id);
    const badges = [];
    for (const node of graph.nodes) {
      badges.push(
        ...node.isSubgraphNode() ? collectCreditsBadges(node.subgraph, visited) : node.badges.filter((b) => isCreditsBadge(b))
      );
    }
    return badges;
  }
  __name(collectCreditsBadges, "collectCreditsBadges");
  function isCreditsBadge(badge) {
    const badgeInstance = typeof badge === "function" ? badge() : badge;
    return badgeInstance.icon?.image === componentIconSvg;
  }
  __name(isCreditsBadge, "isCreditsBadge");
  const colorPaletteStore = useColorPaletteStore();
  function getCreditsBadge(price) {
    const isLightTheme = colorPaletteStore.completedActivePalette.light_theme;
    return new LGraphBadge({
      text: price,
      iconOptions: {
        image: componentIconSvg,
        size: 8
      },
      fgColor: colorPaletteStore.completedActivePalette.colors.litegraph_base.BADGE_FG_COLOR,
      bgColor: isLightTheme ? adjustColor("#8D6932", { lightness: 0.5 }) : "#8D6932"
    });
  }
  __name(getCreditsBadge, "getCreditsBadge");
  return {
    getCreditsBadge,
    updateSubgraphCredits
  };
}, "usePriceBadge");
const useComputedWithWidgetWatch = /* @__PURE__ */ __name((node, options = {}) => {
  const { widgetNames, triggerCanvasRedraw = false } = options;
  const widgetValues = ref({});
  if (node.widgets) {
    const widgetsToObserve = widgetNames ? node.widgets.filter((widget) => widgetNames.includes(widget.name)) : node.widgets;
    const currentValues = {};
    widgetsToObserve.forEach((widget) => {
      currentValues[widget.name] = widget.value;
    });
    widgetValues.value = currentValues;
    widgetsToObserve.forEach((widget) => {
      widget.callback = useChainCallback(widget.callback, () => {
        widgetValues.value = {
          ...widgetValues.value,
          [widget.name]: widget.value
        };
        if (triggerCanvasRedraw) {
          node.graph?.setDirtyCanvas(true, true);
        }
      });
    });
    if (widgetNames && widgetNames.length > widgetsToObserve.length) {
      const indexesToObserve = widgetNames.map(
        (name) => widgetsToObserve.some((w) => w.name == name) ? -1 : node.inputs.findIndex((i) => i.name == name)
      ).filter((i) => i >= 0);
      node.onConnectionsChange = useChainCallback(
        node.onConnectionsChange,
        (_type, index, isConnected) => {
          if (!indexesToObserve.includes(index)) return;
          widgetValues.value = {
            ...widgetValues.value,
            [indexesToObserve[index]]: isConnected
          };
          if (triggerCanvasRedraw) {
            node.graph?.setDirtyCanvas(true, true);
          }
        }
      );
    }
  }
  return (computeFn) => {
    return computedWithControl(widgetValues, computeFn);
  };
}, "useComputedWithWidgetWatch");
const useNodeBadge = /* @__PURE__ */ __name(() => {
  const settingStore = useSettingStore();
  const extensionStore = useExtensionStore();
  const colorPaletteStore = useColorPaletteStore();
  const priceBadge = usePriceBadge();
  const nodeSourceBadgeMode = computed(
    () => settingStore.get("Comfy.NodeBadge.NodeSourceBadgeMode")
  );
  const nodeIdBadgeMode = computed(
    () => settingStore.get("Comfy.NodeBadge.NodeIdBadgeMode")
  );
  const nodeLifeCycleBadgeMode = computed(
    () => settingStore.get(
      "Comfy.NodeBadge.NodeLifeCycleBadgeMode"
    )
  );
  const showApiPricingBadge = computed(
    () => settingStore.get("Comfy.NodeBadge.ShowApiPricing")
  );
  watch(
    [
      nodeSourceBadgeMode,
      nodeIdBadgeMode,
      nodeLifeCycleBadgeMode,
      showApiPricingBadge
    ],
    () => {
      app.canvas?.setDirty(true, true);
    }
  );
  const nodeDefStore = useNodeDefStore();
  function badgeTextVisible(nodeDef, badgeMode) {
    return !(badgeMode === NodeBadgeMode.None || nodeDef?.isCoreNode && badgeMode === NodeBadgeMode.HideBuiltIn);
  }
  __name(badgeTextVisible, "badgeTextVisible");
  onMounted(() => {
    const nodePricing = useNodePricing();
    extensionStore.registerExtension({
      name: "Comfy.NodeBadge",
      nodeCreated(node) {
        node.badgePosition = BadgePosition.TopRight;
        const badge = computed(() => {
          const nodeDef = nodeDefStore.fromLGraphNode(node);
          return new LGraphBadge({
            text: toolkit.truncate(
              [
                badgeTextVisible(nodeDef, nodeIdBadgeMode.value) ? `#${node.id}` : "",
                badgeTextVisible(nodeDef, nodeLifeCycleBadgeMode.value) ? nodeDef?.nodeLifeCycleBadgeText ?? "" : "",
                badgeTextVisible(nodeDef, nodeSourceBadgeMode.value) ? nodeDef?.nodeSource?.badgeText ?? "" : ""
              ].filter((s) => s.length > 0).join(" "),
              {
                length: 31
              }
            ),
            fgColor: colorPaletteStore.completedActivePalette.colors.litegraph_base.BADGE_FG_COLOR,
            bgColor: colorPaletteStore.completedActivePalette.colors.litegraph_base.BADGE_BG_COLOR
          });
        });
        node.badges.push(() => badge.value);
        if (node.constructor.nodeData?.api_node && showApiPricingBadge.value) {
          const pricingConfig = nodePricing.getNodePricingConfig(node);
          const hasDynamicPricing = typeof pricingConfig?.displayPrice === "function";
          let creditsBadge;
          const createBadge = /* @__PURE__ */ __name(() => {
            const price = nodePricing.getNodeDisplayPrice(node);
            return priceBadge.getCreditsBadge(price);
          }, "createBadge");
          if (hasDynamicPricing) {
            const relevantWidgetNames = nodePricing.getRelevantWidgetNames(
              node.constructor.nodeData?.name
            );
            const computedWithWidgetWatch = useComputedWithWidgetWatch(node, {
              widgetNames: relevantWidgetNames,
              triggerCanvasRedraw: true
            });
            creditsBadge = computedWithWidgetWatch(createBadge);
          } else {
            creditsBadge = computed(createBadge);
          }
          node.badges.push(() => creditsBadge.value);
        }
      },
      init() {
        app.canvas.canvas.addEventListener(
          "litegraph:set-graph",
          () => {
            for (const node of app.canvas.graph?.nodes ?? [])
              priceBadge.updateSubgraphCredits(node);
          }
        );
        app.canvas.canvas.addEventListener(
          "subgraph-converted",
          (e) => priceBadge.updateSubgraphCredits(e.detail.subgraphNode)
        );
      },
      afterConfigureGraph() {
        for (const node of app.canvas.graph?.nodes ?? [])
          priceBadge.updateSubgraphCredits(node);
      }
    });
  });
}, "useNodeBadge");
const useCanvasDrop = /* @__PURE__ */ __name((canvasRef) => {
  const modelToNodeStore = useModelToNodeStore();
  const litegraphService = useLitegraphService();
  const workflowService = useWorkflowService();
  usePragmaticDroppable(() => canvasRef.value, {
    getDropEffect: /* @__PURE__ */ __name((args) => args.source.data.type === "tree-explorer-node" ? "copy" : "move", "getDropEffect"),
    onDrop: /* @__PURE__ */ __name(async (event) => {
      const loc = event.location.current.input;
      const dndData = event.source.data;
      if (dndData.type === "tree-explorer-node") {
        const node = dndData.data;
        const conv = useSharedCanvasPositionConversion();
        const basePos = conv.clientPosToCanvasPos([loc.clientX, loc.clientY]);
        if (node.data instanceof ComfyNodeDefImpl) {
          const nodeDef = node.data;
          const pos = [...basePos];
          pos[1] += LiteGraph.NODE_TITLE_HEIGHT;
          litegraphService.addNodeOnGraph(nodeDef, { pos });
        } else if (node.data instanceof ComfyModelDef) {
          const model = node.data;
          const pos = basePos;
          const nodeAtPos = app.canvas.graph?.getNodeOnPos(pos[0], pos[1]);
          let targetProvider = null;
          let targetGraphNode = null;
          if (nodeAtPos) {
            const providers = modelToNodeStore.getAllNodeProviders(
              model.directory
            );
            for (const provider of providers) {
              if (provider.nodeDef.name === nodeAtPos.comfyClass) {
                targetGraphNode = nodeAtPos;
                targetProvider = provider;
              }
            }
          }
          if (!targetGraphNode) {
            const provider = modelToNodeStore.getNodeProvider(model.directory);
            if (provider) {
              targetGraphNode = litegraphService.addNodeOnGraph(
                provider.nodeDef,
                {
                  pos
                }
              );
              targetProvider = provider;
            }
          }
          if (targetGraphNode) {
            const widget = targetGraphNode.widgets?.find(
              (widget2) => widget2.name === targetProvider?.key
            );
            if (widget) {
              widget.value = model.file_name;
            }
          }
        } else if (node.data instanceof ComfyWorkflow) {
          const workflow = node.data;
          await workflowService.insertWorkflow(workflow, { position: basePos });
        }
      }
    }, "onDrop")
  });
}, "useCanvasDrop");
const useContextMenuTranslation = /* @__PURE__ */ __name(() => {
  legacyMenuCompat.install(LGraphCanvas.prototype, "getCanvasMenuOptions");
  const { getCanvasMenuOptions } = LGraphCanvas.prototype;
  const getCanvasCenterMenuOptions = /* @__PURE__ */ __name(function(...args) {
    const res = getCanvasMenuOptions.apply(
      this,
      args
    );
    const newApiItems = app.collectCanvasMenuItems(this);
    for (const item of newApiItems) {
      res.push(item);
    }
    const legacyItems = legacyMenuCompat.extractLegacyItems(
      "getCanvasMenuOptions",
      this,
      ...args
    );
    for (const item of legacyItems) {
      res.push(item);
    }
    for (const item of res) {
      if (item?.content) {
        item.content = st(`contextMenu.${item.content}`, item.content);
      }
    }
    return res;
  }, "getCanvasCenterMenuOptions");
  LGraphCanvas.prototype.getCanvasMenuOptions = getCanvasCenterMenuOptions;
  legacyMenuCompat.registerWrapper(
    "getCanvasMenuOptions",
    getCanvasCenterMenuOptions,
    getCanvasMenuOptions,
    LGraphCanvas.prototype
  );
  legacyMenuCompat.install(LGraphCanvas.prototype, "getNodeMenuOptions");
  const nodeMenuFn = LGraphCanvas.prototype.getNodeMenuOptions;
  const getNodeMenuOptionsWithExtensions = /* @__PURE__ */ __name(function(...args) {
    const res = nodeMenuFn.apply(this, args);
    const node = args[0];
    const newApiItems = app.collectNodeMenuItems(node);
    for (const item of newApiItems) {
      res.push(item);
    }
    const legacyItems = legacyMenuCompat.extractLegacyItems(
      "getNodeMenuOptions",
      this,
      ...args
    );
    for (const item of legacyItems) {
      res.push(item);
    }
    return res;
  }, "getNodeMenuOptionsWithExtensions");
  LGraphCanvas.prototype.getNodeMenuOptions = getNodeMenuOptionsWithExtensions;
  legacyMenuCompat.registerWrapper(
    "getNodeMenuOptions",
    getNodeMenuOptionsWithExtensions,
    nodeMenuFn,
    LGraphCanvas.prototype
  );
  function translateMenus(values, options) {
    if (!values) return;
    const reInput = /Convert (.*) to input/;
    const reWidget = /Convert (.*) to widget/;
    const cvt = st("contextMenu.Convert ", "Convert ");
    const tinp = st("contextMenu. to input", " to input");
    const twgt = st("contextMenu. to widget", " to widget");
    for (const value of values) {
      if (typeof value === "string") continue;
      translateMenus(value?.submenu?.options, options);
      if (!value?.content) {
        continue;
      }
      if (te(`contextMenu.${value.content}`)) {
        value.content = st(`contextMenu.${value.content}`, value.content);
      }
      const extraInfo = options.extra || options.parentMenu?.options?.extra;
      const matchInput = value.content?.match(reInput);
      if (matchInput) {
        let match = matchInput[1];
        extraInfo?.inputs?.find((i) => {
          if (i.name != match) return false;
          match = i.label ? i.label : i.name;
        });
        extraInfo?.widgets?.find((i) => {
          if (i.name != match) return false;
          match = i.label ? i.label : i.name;
        });
        value.content = cvt + match + tinp;
        continue;
      }
      const matchWidget = value.content?.match(reWidget);
      if (matchWidget) {
        let match = matchWidget[1];
        extraInfo?.inputs?.find((i) => {
          if (i.name != match) return false;
          match = i.label ? i.label : i.name;
        });
        extraInfo?.widgets?.find((i) => {
          if (i.name != match) return false;
          match = i.label ? i.label : i.name;
        });
        value.content = cvt + match + twgt;
        continue;
      }
    }
  }
  __name(translateMenus, "translateMenus");
  const OriginalContextMenu = LiteGraph.ContextMenu;
  function ContextMenu2(values, options) {
    if (options.title) {
      options.title = st(
        `nodeDefs.${normalizeI18nKey(options.title)}.display_name`,
        options.title
      );
    }
    translateMenus(values, options);
    const ctx = new OriginalContextMenu(values, options);
    return ctx;
  }
  __name(ContextMenu2, "ContextMenu");
  LiteGraph.ContextMenu = ContextMenu2;
  LiteGraph.ContextMenu.prototype = OriginalContextMenu.prototype;
}, "useContextMenuTranslation");
function hasTextSelection() {
  const selection = window.getSelection();
  return selection !== null && selection.toString().trim().length > 0;
}
__name(hasTextSelection, "hasTextSelection");
function shouldIgnoreCopyPaste(target) {
  const isTextInput = target instanceof HTMLTextAreaElement || target instanceof HTMLInputElement && ![
    "button",
    "checkbox",
    "file",
    "hidden",
    "image",
    "radio",
    "range",
    "reset",
    "search",
    "submit"
  ].includes(target.type);
  return isTextInput || useCanvasStore().linearMode || hasTextSelection();
}
__name(shouldIgnoreCopyPaste, "shouldIgnoreCopyPaste");
const clipboardHTMLWrapper = [
  '<meta charset="utf-8"><div><span data-metadata="',
  '"></span></div><span style="white-space:pre-wrap;">Text</span>'
];
const useCopy = /* @__PURE__ */ __name(() => {
  const canvasStore = useCanvasStore();
  useEventListener(document, "copy", (e) => {
    if (shouldIgnoreCopyPaste(e.target)) {
      return;
    }
    const canvas = canvasStore.canvas;
    if (canvas?.selectedItems) {
      const serializedData = canvas.copyToClipboard();
      const base64Data = btoa(
        String.fromCharCode(
          ...Array.from(new TextEncoder().encode(serializedData))
        )
      );
      e.clipboardData?.setData(
        "text/html",
        clipboardHTMLWrapper.join(base64Data)
      );
      e.preventDefault();
      e.stopImmediatePropagation();
      return false;
    }
  });
}, "useCopy");
const useGlobalLitegraph = /* @__PURE__ */ __name(() => {
  window["LiteGraph"] = LiteGraph;
  window["LGraph"] = LGraph;
  window["LLink"] = LLink;
  window["LGraphNode"] = LGraphNode;
  window["LGraphGroup"] = LGraphGroup;
  window["DragAndScale"] = DragAndScale;
  window["LGraphCanvas"] = LGraphCanvas;
  window["ContextMenu"] = ContextMenu;
  window["LGraphBadge"] = LGraphBadge;
}, "useGlobalLitegraph");
function pasteClipboardItems(data) {
  const rawData = data.getData("text/html");
  const match = rawData.match(/data-metadata="([A-Za-z0-9+/=]+)"/)?.[1];
  if (!match) return false;
  try {
    const binaryString = atob(match);
    const bytes = Uint8Array.from(binaryString, (c) => c.charCodeAt(0));
    const decodedData = new TextDecoder().decode(bytes);
    useCanvasStore().getCanvas()._deserializeItems(JSON.parse(decodedData), {});
    return true;
  } catch (err) {
    console.error(err);
  }
  return false;
}
__name(pasteClipboardItems, "pasteClipboardItems");
const usePaste = /* @__PURE__ */ __name(() => {
  const workspaceStore = useWorkspaceStore();
  const canvasStore = useCanvasStore();
  const pasteItemsOnNode = /* @__PURE__ */ __name((items, node, contentType) => {
    if (!node) return;
    const filteredItems = Array.from(items).filter(
      (item) => item.type.startsWith(contentType)
    );
    const blob = filteredItems[0]?.getAsFile();
    if (!blob) return;
    node.pasteFile?.(blob);
    node.pasteFiles?.(
      Array.from(filteredItems).map((i) => i.getAsFile()).filter((f) => f !== null)
    );
  }, "pasteItemsOnNode");
  useEventListener(document, "paste", async (e) => {
    if (shouldIgnoreCopyPaste(e.target)) {
      return;
    }
    if (workspaceStore.shiftDown) return;
    const { canvas } = canvasStore;
    if (!canvas) return;
    const { graph } = canvas;
    let data = e.clipboardData;
    if (!data) throw new Error("No clipboard data on clipboard event");
    const { items } = data;
    const currentNode = canvas.current_node;
    const isNodeSelected = currentNode?.is_selected;
    const isImageNodeSelected = isNodeSelected && isImageNode(currentNode);
    const isVideoNodeSelected = isNodeSelected && isVideoNode(currentNode);
    const isAudioNodeSelected = isNodeSelected && isAudioNode(currentNode);
    let imageNode = isImageNodeSelected ? currentNode : null;
    let audioNode = isAudioNodeSelected ? currentNode : null;
    const videoNode = isVideoNodeSelected ? currentNode : null;
    for (const item of items) {
      if (item.type.startsWith("image/")) {
        if (!imageNode) {
          const newNode = LiteGraph.createNode("LoadImage");
          if (newNode) {
            newNode.pos = [canvas.graph_mouse[0], canvas.graph_mouse[1]];
            imageNode = graph?.add(newNode) ?? null;
          }
          graph?.change();
        }
        pasteItemsOnNode(items, imageNode, "image");
        return;
      } else if (item.type.startsWith("video/")) {
        if (!videoNode) ;
        else {
          pasteItemsOnNode(items, videoNode, "video");
          return;
        }
      } else if (item.type.startsWith("audio/")) {
        if (!audioNode) {
          const newNode = LiteGraph.createNode("LoadAudio");
          if (newNode) {
            newNode.pos = [canvas.graph_mouse[0], canvas.graph_mouse[1]];
            audioNode = graph?.add(newNode) ?? null;
          }
          graph?.change();
        }
        pasteItemsOnNode(items, audioNode, "audio");
        return;
      }
    }
    if (pasteClipboardItems(data)) return;
    data = data.getData("text/plain");
    let workflow = null;
    try {
      data = data.slice(data.indexOf("{"));
      workflow = JSON.parse(data);
    } catch (err) {
      try {
        data = data.slice(data.indexOf("workflow\n"));
        data = data.slice(data.indexOf("{"));
        workflow = JSON.parse(data);
      } catch (error) {
        workflow = null;
      }
    }
    if (workflow && workflow.version && workflow.nodes && workflow.extra) {
      await app.loadGraphData(workflow);
    } else {
      if (e.target instanceof HTMLTextAreaElement && e.target.type === "textarea" || e.target instanceof HTMLInputElement && e.target.type === "text") {
        return;
      }
      canvas.pasteFromClipboard();
    }
  });
}, "usePaste");
const useLitegraphSettings = /* @__PURE__ */ __name(() => {
  const settingStore = useSettingStore();
  const canvasStore = useCanvasStore();
  watchEffect(() => {
    const canvasInfoEnabled = settingStore.get("Comfy.Graph.CanvasInfo");
    if (canvasStore.canvas) {
      canvasStore.canvas.show_info = canvasInfoEnabled;
      canvasStore.canvas.draw(false, true);
    }
  });
  watchEffect(() => {
    const zoomSpeed = settingStore.get("Comfy.Graph.ZoomSpeed");
    if (canvasStore.canvas) {
      canvasStore.canvas.zoom_speed = zoomSpeed;
    }
  });
  watchEffect(() => {
    LiteGraph.snaps_for_comfy = settingStore.get(
      "Comfy.Node.AutoSnapLinkToSlot"
    );
  });
  watchEffect(() => {
    LiteGraph.snap_highlights_node = settingStore.get(
      "Comfy.Node.SnapHighlightsNode"
    );
  });
  watchEffect(() => {
    LGraphNode.keepAllLinksOnBypass = settingStore.get(
      "Comfy.Node.BypassAllLinksOnDelete"
    );
  });
  watchEffect(() => {
    LiteGraph.middle_click_slot_add_default_node = settingStore.get(
      "Comfy.Node.MiddleClickRerouteNode"
    );
  });
  watchEffect(() => {
    const linkRenderMode = settingStore.get("Comfy.LinkRenderMode");
    if (canvasStore.canvas) {
      canvasStore.canvas.links_render_mode = linkRenderMode;
      canvasStore.canvas.setDirty(
        /* fg */
        false,
        /* bg */
        true
      );
    }
  });
  watchEffect(() => {
    const minFontSizeForLOD = settingStore.get(
      "LiteGraph.Canvas.MinFontSizeForLOD"
    );
    if (canvasStore.canvas) {
      canvasStore.canvas.min_font_size_for_lod = minFontSizeForLOD;
      canvasStore.canvas.setDirty(
        /* fg */
        true,
        /* bg */
        true
      );
    }
  });
  watchEffect(() => {
    const linkMarkerShape = settingStore.get("Comfy.Graph.LinkMarkers");
    const { canvas } = canvasStore;
    if (canvas) {
      canvas.linkMarkerShape = linkMarkerShape;
      canvas.setDirty(false, true);
    }
  });
  watchEffect(() => {
    const maximumFps = settingStore.get("LiteGraph.Canvas.MaximumFps");
    const { canvas } = canvasStore;
    if (canvas) canvas.maximumFps = maximumFps;
  });
  watchEffect(() => {
    const dragZoomEnabled = settingStore.get("Comfy.Graph.CtrlShiftZoom");
    const { canvas } = canvasStore;
    if (canvas) canvas.dragZoomEnabled = dragZoomEnabled;
  });
  watchEffect(() => {
    const liveSelection = settingStore.get("Comfy.Graph.LiveSelection");
    const { canvas } = canvasStore;
    if (canvas) canvas.liveSelection = liveSelection;
  });
  watchEffect(() => {
    CanvasPointer.doubleClickTime = settingStore.get(
      "Comfy.Pointer.DoubleClickTime"
    );
  });
  watchEffect(() => {
    CanvasPointer.bufferTime = settingStore.get("Comfy.Pointer.ClickBufferTime");
  });
  watchEffect(() => {
    CanvasPointer.maxClickDrift = settingStore.get("Comfy.Pointer.ClickDrift");
  });
  watchEffect(() => {
    LiteGraph.CANVAS_GRID_SIZE = settingStore.get("Comfy.SnapToGrid.GridSize");
  });
  watchEffect(() => {
    LiteGraph.alwaysSnapToGrid = settingStore.get("pysssss.SnapToGrid");
  });
  watchEffect(() => {
    LiteGraph.context_menu_scaling = settingStore.get(
      "LiteGraph.ContextMenu.Scaling"
    );
  });
  watchEffect(() => {
    LiteGraph.Reroute.maxSplineOffset = settingStore.get(
      "LiteGraph.Reroute.SplineOffset"
    );
  });
  watchEffect(() => {
    const navigationMode = settingStore.get("Comfy.Canvas.NavigationMode");
    LiteGraph.canvasNavigationMode = navigationMode;
    LiteGraph.macTrackpadGestures = navigationMode === "standard";
  });
  watchEffect(() => {
    const leftMouseBehavior = settingStore.get(
      "Comfy.Canvas.LeftMouseClickBehavior"
    );
    LiteGraph.leftMouseClickBehavior = leftMouseBehavior;
  });
  watchEffect(() => {
    const mouseWheelScroll = settingStore.get(
      "Comfy.Canvas.MouseWheelScroll"
    );
    LiteGraph.mouseWheelScroll = mouseWheelScroll;
  });
  watchEffect(() => {
    LiteGraph.saveViewportWithGraph = settingStore.get(
      "Comfy.EnableWorkflowViewRestore"
    );
  });
}, "useLitegraphSettings");
const CORE_SETTINGS = [
  {
    id: "Comfy.Memory.AllowManualUnload",
    name: "Allow manual unload of models and execution cache via user command",
    type: "hidden",
    defaultValue: true,
    versionAdded: "1.18.0"
  },
  {
    id: "Comfy.Validation.Workflows",
    name: "Validate workflows",
    type: "boolean",
    defaultValue: false
  },
  {
    id: "Comfy.NodeSearchBoxImpl",
    category: ["Comfy", "Node Search Box", "Implementation"],
    experimental: true,
    name: "Node search box implementation",
    type: "combo",
    options: ["default", "litegraph (legacy)"],
    defaultValue: "default"
  },
  {
    id: "Comfy.LinkRelease.Action",
    category: ["LiteGraph", "LinkRelease", "Action"],
    name: "Action on link release (No modifier)",
    type: "combo",
    options: Object.values(LinkReleaseTriggerAction),
    defaultValue: LinkReleaseTriggerAction.CONTEXT_MENU,
    defaultsByInstallVersion: {
      "1.24.1": LinkReleaseTriggerAction.SEARCH_BOX
    }
  },
  {
    id: "Comfy.LinkRelease.ActionShift",
    category: ["LiteGraph", "LinkRelease", "ActionShift"],
    name: "Action on link release (Shift)",
    type: "combo",
    options: Object.values(LinkReleaseTriggerAction),
    defaultValue: LinkReleaseTriggerAction.SEARCH_BOX,
    defaultsByInstallVersion: {
      "1.24.1": LinkReleaseTriggerAction.CONTEXT_MENU
    }
  },
  {
    id: "Comfy.NodeSearchBoxImpl.NodePreview",
    category: ["Comfy", "Node Search Box", "NodePreview"],
    name: "Node preview",
    tooltip: "Only applies to the default implementation",
    type: "boolean",
    defaultValue: true
  },
  {
    id: "Comfy.NodeSearchBoxImpl.ShowCategory",
    category: ["Comfy", "Node Search Box", "ShowCategory"],
    name: "Show node category in search results",
    tooltip: "Only applies to the default implementation",
    type: "boolean",
    defaultValue: true
  },
  {
    id: "Comfy.NodeSearchBoxImpl.ShowIdName",
    category: ["Comfy", "Node Search Box", "ShowIdName"],
    name: "Show node id name in search results",
    tooltip: "Only applies to the default implementation",
    type: "boolean",
    defaultValue: false
  },
  {
    id: "Comfy.NodeSearchBoxImpl.ShowNodeFrequency",
    category: ["Comfy", "Node Search Box", "ShowNodeFrequency"],
    name: "Show node frequency in search results",
    tooltip: "Only applies to the default implementation",
    type: "boolean",
    defaultValue: false
  },
  {
    id: "Comfy.Sidebar.Location",
    category: ["Appearance", "Sidebar", "Location"],
    name: "Sidebar location",
    type: "combo",
    options: ["left", "right"],
    defaultValue: "left"
  },
  {
    id: "Comfy.Sidebar.Size",
    category: ["Appearance", "Sidebar", "Size"],
    name: "Sidebar size",
    type: "combo",
    options: ["normal", "small"],
    // Default to small if the window is less than 1536px(2xl) wide.
    defaultValue: /* @__PURE__ */ __name(() => window.innerWidth < 1536 ? "small" : "normal", "defaultValue")
  },
  {
    id: "Comfy.Sidebar.UnifiedWidth",
    category: ["Appearance", "Sidebar", "UnifiedWidth"],
    name: "Unified sidebar width",
    type: "boolean",
    defaultValue: true,
    versionAdded: "1.18.1"
  },
  {
    id: "Comfy.Sidebar.Style",
    category: ["Appearance", "Sidebar", "Style"],
    name: "Sidebar style",
    type: "combo",
    options: ["floating", "connected"],
    defaultValue: "connected"
  },
  {
    id: "Comfy.TextareaWidget.FontSize",
    category: ["Appearance", "Node Widget", "TextareaWidget", "FontSize"],
    name: "Textarea widget font size",
    type: "slider",
    defaultValue: 10,
    attrs: {
      min: 8,
      max: 24
    }
  },
  {
    id: "Comfy.TextareaWidget.Spellcheck",
    category: ["Comfy", "Node Widget", "TextareaWidget", "Spellcheck"],
    name: "Textarea widget spellcheck",
    type: "boolean",
    defaultValue: false
  },
  {
    id: "Comfy.Workflow.SortNodeIdOnSave",
    name: "Sort node IDs when saving workflow",
    type: "boolean",
    defaultValue: false
  },
  {
    id: "Comfy.Canvas.NavigationMode",
    category: ["LiteGraph", "Canvas Navigation", "NavigationMode"],
    name: "Navigation Mode",
    defaultValue: "legacy",
    type: "combo",
    sortOrder: 100,
    options: [
      { value: "standard", text: "Standard (New)" },
      { value: "legacy", text: "Drag Navigation" },
      { value: "custom", text: "Custom" }
    ],
    versionAdded: "1.25.0",
    defaultsByInstallVersion: {
      "1.25.0": "legacy"
    },
    onChange: /* @__PURE__ */ __name(async (newValue, oldValue) => {
      if (!oldValue) return;
      const settingStore = useSettingStore();
      if (newValue === "standard") {
        await settingStore.set("Comfy.Canvas.LeftMouseClickBehavior", "select");
        await settingStore.set("Comfy.Canvas.MouseWheelScroll", "panning");
      } else if (newValue === "legacy") {
        await settingStore.set("Comfy.Canvas.LeftMouseClickBehavior", "panning");
        await settingStore.set("Comfy.Canvas.MouseWheelScroll", "zoom");
      }
    }, "onChange")
  },
  {
    id: "Comfy.Canvas.LeftMouseClickBehavior",
    category: ["LiteGraph", "Canvas Navigation", "LeftMouseClickBehavior"],
    name: "Left Mouse Click Behavior",
    defaultValue: "panning",
    type: "radio",
    sortOrder: 50,
    options: [
      { value: "panning", text: "Panning" },
      { value: "select", text: "Select" }
    ],
    versionAdded: "1.27.4",
    onChange: /* @__PURE__ */ __name(async (newValue) => {
      const settingStore = useSettingStore();
      const navigationMode = settingStore.get("Comfy.Canvas.NavigationMode");
      if (navigationMode !== "custom") {
        if (newValue === "select" && navigationMode === "standard" || newValue === "panning" && navigationMode === "legacy") {
          return;
        }
        await settingStore.set("Comfy.Canvas.NavigationMode", "custom");
      }
    }, "onChange")
  },
  {
    id: "Comfy.Canvas.MouseWheelScroll",
    category: ["LiteGraph", "Canvas Navigation", "MouseWheelScroll"],
    name: "Mouse Wheel Scroll",
    defaultValue: "zoom",
    type: "radio",
    options: [
      { value: "panning", text: "Panning" },
      { value: "zoom", text: "Zoom in/out" }
    ],
    versionAdded: "1.27.4",
    onChange: /* @__PURE__ */ __name(async (newValue) => {
      const settingStore = useSettingStore();
      const navigationMode = settingStore.get("Comfy.Canvas.NavigationMode");
      if (navigationMode !== "custom") {
        if (newValue === "panning" && navigationMode === "standard" || newValue === "zoom" && navigationMode === "legacy") {
          return;
        }
        await settingStore.set("Comfy.Canvas.NavigationMode", "custom");
      }
    }, "onChange")
  },
  {
    id: "Comfy.Graph.CanvasInfo",
    category: ["LiteGraph", "Canvas", "CanvasInfo"],
    name: "Show canvas info on bottom left corner (fps, etc.)",
    type: "boolean",
    defaultValue: true
  },
  {
    id: "Comfy.Node.ShowDeprecated",
    name: "Show deprecated nodes in search",
    tooltip: "Deprecated nodes are hidden by default in the UI, but remain functional in existing workflows that use them.",
    type: "boolean",
    defaultValue: false
  },
  {
    id: "Comfy.Node.ShowExperimental",
    name: "Show experimental nodes in search",
    tooltip: "Experimental nodes are marked as such in the UI and may be subject to significant changes or removal in future versions. Use with caution in production workflows",
    type: "boolean",
    defaultValue: true
  },
  {
    id: "Comfy.Node.Opacity",
    category: ["Appearance", "Node", "Opacity"],
    name: "Node opacity",
    type: "slider",
    defaultValue: 1,
    attrs: {
      min: 0.01,
      max: 1,
      step: 0.01
    }
  },
  {
    id: "Comfy.Workflow.ShowMissingNodesWarning",
    name: "Show missing nodes warning",
    type: "boolean",
    defaultValue: true
  },
  {
    id: "Comfy.Workflow.ShowMissingModelsWarning",
    name: "Show missing models warning",
    type: "boolean",
    defaultValue: true,
    experimental: true
  },
  {
    id: "Comfy.Workflow.WarnBlueprintOverwrite",
    name: "Require confirmation to overwrite an existing subgraph blueprint",
    type: "boolean",
    defaultValue: true
  },
  {
    id: "Comfy.Graph.ZoomSpeed",
    category: ["LiteGraph", "Canvas", "ZoomSpeed"],
    name: "Canvas zoom speed",
    type: "slider",
    defaultValue: 1.1,
    attrs: {
      min: 1.01,
      max: 2.5,
      step: 0.01
    }
  },
  // Bookmarks are stored in the settings store.
  // Bookmarks are in format of category/display_name. e.g. "conditioning/CLIPTextEncode"
  {
    id: "Comfy.NodeLibrary.Bookmarks",
    name: "Node library bookmarks with display name (deprecated)",
    type: "hidden",
    defaultValue: [],
    deprecated: true
  },
  {
    id: "Comfy.NodeLibrary.Bookmarks.V2",
    name: "Node library bookmarks v2 with unique name",
    type: "hidden",
    defaultValue: []
  },
  // Stores mapping from bookmark folder name to its customization.
  {
    id: "Comfy.NodeLibrary.BookmarksCustomization",
    name: "Node library bookmarks customization",
    type: "hidden",
    defaultValue: {}
  },
  {
    id: "Comfy.GroupSelectedNodes.Padding",
    category: ["LiteGraph", "Group", "Padding"],
    name: "Group selected nodes padding",
    type: "slider",
    defaultValue: 10,
    attrs: {
      min: 0,
      max: 100
    }
  },
  {
    id: "Comfy.Node.DoubleClickTitleToEdit",
    category: ["LiteGraph", "Node", "DoubleClickTitleToEdit"],
    name: "Double click node title to edit",
    type: "boolean",
    defaultValue: true
  },
  {
    id: "Comfy.Node.AllowImageSizeDraw",
    category: ["LiteGraph", "Node Widget", "AllowImageSizeDraw"],
    name: "Show width × height below the image preview",
    type: "boolean",
    defaultValue: true
  },
  {
    id: "Comfy.Group.DoubleClickTitleToEdit",
    category: ["LiteGraph", "Group", "DoubleClickTitleToEdit"],
    name: "Double click group title to edit",
    type: "boolean",
    defaultValue: true
  },
  {
    id: "Comfy.Window.UnloadConfirmation",
    name: "Show confirmation when closing window",
    type: "boolean",
    defaultValue: true,
    versionModified: "1.7.12"
  },
  {
    id: "Comfy.TreeExplorer.ItemPadding",
    category: ["Appearance", "Tree Explorer", "ItemPadding"],
    name: "Tree explorer item padding",
    type: "slider",
    defaultValue: 2,
    attrs: {
      min: 0,
      max: 8,
      step: 1
    }
  },
  {
    id: "Comfy.ModelLibrary.AutoLoadAll",
    name: "Automatically load all model folders",
    tooltip: "If true, all folders will load as soon as you open the model library (this may cause delays while it loads). If false, root level model folders will only load once you click on them.",
    type: "boolean",
    defaultValue: false
  },
  {
    id: "Comfy.ModelLibrary.NameFormat",
    name: "What name to display in the model library tree view",
    tooltip: 'Select "filename" to render a simplified view of the raw filename (without directory or ".safetensors" extension) in the model list. Select "title" to display the configurable model metadata title.',
    type: "combo",
    options: ["filename", "title"],
    defaultValue: "title"
  },
  {
    id: "Comfy.Locale",
    name: "Language",
    type: "combo",
    options: [
      { value: "en", text: "English" },
      { value: "zh", text: "中文" },
      { value: "zh-TW", text: "繁體中文" },
      { value: "ru", text: "Русский" },
      { value: "ja", text: "日本語" },
      { value: "ko", text: "한국어" },
      { value: "fr", text: "Français" },
      { value: "es", text: "Español" },
      { value: "ar", text: "عربي" },
      { value: "tr", text: "Türkçe" },
      { value: "pt-BR", text: "Português (BR)" }
    ],
    defaultValue: /* @__PURE__ */ __name(() => navigator.language.split("-")[0] || "en", "defaultValue")
  },
  {
    id: "Comfy.NodeBadge.NodeSourceBadgeMode",
    category: ["LiteGraph", "Node", "NodeSourceBadgeMode"],
    name: "Node source badge mode",
    type: "combo",
    options: Object.values(NodeBadgeMode),
    defaultValue: NodeBadgeMode.HideBuiltIn
  },
  {
    id: "Comfy.NodeBadge.NodeIdBadgeMode",
    category: ["LiteGraph", "Node", "NodeIdBadgeMode"],
    name: "Node ID badge mode",
    type: "combo",
    options: [NodeBadgeMode.None, NodeBadgeMode.ShowAll],
    defaultValue: NodeBadgeMode.None
  },
  {
    id: "Comfy.NodeBadge.NodeLifeCycleBadgeMode",
    category: ["LiteGraph", "Node", "NodeLifeCycleBadgeMode"],
    name: "Node life cycle badge mode",
    type: "combo",
    options: [NodeBadgeMode.None, NodeBadgeMode.ShowAll],
    defaultValue: NodeBadgeMode.ShowAll
  },
  {
    id: "Comfy.NodeBadge.ShowApiPricing",
    category: ["Comfy", "API Nodes"],
    name: "Show API node pricing badge",
    type: "boolean",
    defaultValue: true,
    versionAdded: "1.20.3"
  },
  {
    id: "Comfy.Notification.ShowVersionUpdates",
    category: ["Comfy", "Notification Preferences"],
    name: "Show version updates",
    tooltip: "Show updates for new models, and major new features.",
    type: "boolean",
    defaultValue: true
  },
  {
    id: "Comfy.ConfirmClear",
    category: ["Comfy", "Workflow", "ConfirmClear"],
    name: "Require confirmation when clearing workflow",
    type: "boolean",
    defaultValue: true
  },
  {
    id: "Comfy.PromptFilename",
    category: ["Comfy", "Workflow", "PromptFilename"],
    name: "Prompt for filename when saving workflow",
    type: "boolean",
    defaultValue: true
  },
  /**
   * file format for preview
   *
   * format;quality
   *
   * ex)
   * webp;50 -> webp, quality 50
   * jpeg;80 -> rgb, jpeg, quality 80
   *
   * @type {string}
   */
  {
    id: "Comfy.PreviewFormat",
    category: ["LiteGraph", "Node Widget", "PreviewFormat"],
    name: "Preview image format",
    tooltip: "When displaying a preview in the image widget, convert it to a lightweight image, e.g. webp, jpeg, webp;50, etc.",
    type: "text",
    defaultValue: ""
  },
  {
    id: "Comfy.DisableSliders",
    category: ["LiteGraph", "Node Widget", "DisableSliders"],
    name: "Disable node widget sliders",
    type: "boolean",
    defaultValue: false
  },
  {
    id: "Comfy.DisableFloatRounding",
    category: ["LiteGraph", "Node Widget", "DisableFloatRounding"],
    name: "Disable default float widget rounding.",
    tooltip: "(requires page reload) Cannot disable round when round is set by the node in the backend.",
    type: "boolean",
    defaultValue: false
  },
  {
    id: "Comfy.FloatRoundingPrecision",
    category: ["LiteGraph", "Node Widget", "FloatRoundingPrecision"],
    name: "Float widget rounding decimal places [0 = auto].",
    tooltip: "(requires page reload)",
    type: "slider",
    attrs: {
      min: 0,
      max: 6,
      step: 1
    },
    defaultValue: 0
  },
  {
    id: "LiteGraph.Node.TooltipDelay",
    name: "Tooltip Delay",
    type: "number",
    attrs: {
      min: 100,
      max: 3e3,
      step: 50
    },
    defaultValue: 500,
    versionAdded: "1.9.0"
  },
  {
    id: "Comfy.EnableTooltips",
    category: ["LiteGraph", "Node", "EnableTooltips"],
    name: "Enable Tooltips",
    type: "boolean",
    defaultValue: true
  },
  {
    id: "Comfy.DevMode",
    name: "Enable dev mode options (API save, etc.)",
    type: "boolean",
    defaultValue: false,
    onChange: /* @__PURE__ */ __name((value) => {
      const element = document.getElementById("comfy-dev-save-api-button");
      if (element) {
        element.style.display = value ? "flex" : "none";
      }
    }, "onChange")
  },
  {
    id: "Comfy.UseNewMenu",
    category: ["Comfy", "Menu", "UseNewMenu"],
    defaultValue: "Top",
    name: "Use new menu",
    type: "combo",
    options: ["Disabled", "Top"],
    tooltip: "Enable the redesigned top menu bar.",
    migrateDeprecatedValue: /* @__PURE__ */ __name((value) => {
      if (value === "Floating") {
        return "Top";
      } else if (value === "Bottom") {
        return "Top";
      }
      return value;
    }, "migrateDeprecatedValue")
  },
  {
    id: "Comfy.Workflow.WorkflowTabsPosition",
    name: "Opened workflows position",
    type: "combo",
    options: ["Sidebar", "Topbar"],
    defaultValue: "Topbar",
    migrateDeprecatedValue: /* @__PURE__ */ __name((value) => {
      if (value === "Topbar (2nd-row)") {
        return "Topbar";
      }
      return value;
    }, "migrateDeprecatedValue")
  },
  {
    id: "Comfy.Graph.CanvasMenu",
    category: ["LiteGraph", "Canvas", "CanvasMenu"],
    name: "Show graph canvas menu",
    type: "boolean",
    defaultValue: true
  },
  {
    id: "Comfy.QueueButton.BatchCountLimit",
    name: "Batch count limit",
    tooltip: "The maximum number of tasks added to the queue at one button click",
    type: "number",
    defaultValue: 100,
    versionAdded: "1.3.5"
  },
  {
    id: "Comfy.Keybinding.UnsetBindings",
    name: "Keybindings unset by the user",
    type: "hidden",
    defaultValue: [],
    versionAdded: "1.3.7",
    versionModified: "1.7.3",
    migrateDeprecatedValue: /* @__PURE__ */ __name((value) => {
      return value.map((keybinding) => {
        if (keybinding.targetSelector === "#graph-canvas") {
          keybinding.targetElementId = "graph-canvas-container";
        }
        return keybinding;
      });
    }, "migrateDeprecatedValue")
  },
  {
    id: "Comfy.Keybinding.NewBindings",
    name: "Keybindings set by the user",
    type: "hidden",
    defaultValue: [],
    versionAdded: "1.3.7"
  },
  {
    id: "Comfy.Extension.Disabled",
    name: "Disabled extension names",
    type: "hidden",
    defaultValue: [],
    versionAdded: "1.3.11"
  },
  {
    id: "Comfy.LinkRenderMode",
    category: ["LiteGraph", "Graph", "LinkRenderMode"],
    name: "Link Render Mode",
    defaultValue: 2,
    type: "combo",
    options: [
      { value: LiteGraph.STRAIGHT_LINK, text: "Straight" },
      { value: LiteGraph.LINEAR_LINK, text: "Linear" },
      { value: LiteGraph.SPLINE_LINK, text: "Spline" },
      { value: LiteGraph.HIDDEN_LINK, text: "Hidden" }
    ]
  },
  {
    id: "Comfy.Node.AutoSnapLinkToSlot",
    category: ["LiteGraph", "Node", "AutoSnapLinkToSlot"],
    name: "Auto snap link to node slot",
    tooltip: "When dragging a link over a node, the link automatically snap to a viable input slot on the node",
    type: "boolean",
    defaultValue: true,
    versionAdded: "1.3.29"
  },
  {
    id: "Comfy.Node.SnapHighlightsNode",
    category: ["LiteGraph", "Node", "SnapHighlightsNode"],
    name: "Snap highlights node",
    tooltip: "When dragging a link over a node with viable input slot, highlight the node",
    type: "boolean",
    defaultValue: true,
    versionAdded: "1.3.29"
  },
  {
    id: "Comfy.Node.BypassAllLinksOnDelete",
    category: ["LiteGraph", "Node", "BypassAllLinksOnDelete"],
    name: "Keep all links when deleting nodes",
    tooltip: "When deleting a node, attempt to reconnect all of its input and output links (bypassing the deleted node)",
    type: "boolean",
    defaultValue: true,
    versionAdded: "1.3.40"
  },
  {
    id: "Comfy.Node.MiddleClickRerouteNode",
    category: ["LiteGraph", "Node", "MiddleClickRerouteNode"],
    name: "Middle-click creates a new Reroute node",
    type: "boolean",
    defaultValue: true,
    versionAdded: "1.3.42"
  },
  {
    id: "Comfy.Graph.LinkMarkers",
    category: ["LiteGraph", "Link", "LinkMarkers"],
    name: "Link midpoint markers",
    defaultValue: LinkMarkerShape.Circle,
    type: "combo",
    options: [
      { value: LinkMarkerShape.None, text: "None" },
      { value: LinkMarkerShape.Circle, text: "Circle" },
      { value: LinkMarkerShape.Arrow, text: "Arrow" }
    ],
    versionAdded: "1.3.42"
  },
  {
    id: "Comfy.DOMClippingEnabled",
    category: ["LiteGraph", "Node", "DOMClippingEnabled"],
    name: "Enable DOM element clipping (enabling may reduce performance)",
    type: "boolean",
    defaultValue: true
  },
  {
    id: "Comfy.Graph.CtrlShiftZoom",
    category: ["LiteGraph", "Canvas", "CtrlShiftZoom"],
    name: "Enable fast-zoom shortcut (Ctrl + Shift + Drag)",
    type: "boolean",
    defaultValue: true,
    versionAdded: "1.4.0"
  },
  {
    id: "Comfy.Graph.LiveSelection",
    category: ["LiteGraph", "Canvas", "LiveSelection"],
    name: "Live selection",
    tooltip: "When enabled, nodes are selected/deselected in real-time as you drag the selection rectangle, similar to other design tools.",
    type: "boolean",
    defaultValue: false,
    versionAdded: "1.36.1"
  },
  {
    id: "Comfy.Pointer.ClickDrift",
    category: ["LiteGraph", "Pointer", "ClickDrift"],
    name: "Pointer click drift (maximum distance)",
    tooltip: "If the pointer moves more than this distance while holding a button down, it is considered dragging (rather than clicking).\n\nHelps prevent objects from being unintentionally nudged if the pointer is moved whilst clicking.",
    experimental: true,
    type: "slider",
    attrs: {
      min: 0,
      max: 20,
      step: 1
    },
    defaultValue: 6,
    versionAdded: "1.4.3"
  },
  {
    id: "Comfy.Pointer.ClickBufferTime",
    category: ["LiteGraph", "Pointer", "ClickBufferTime"],
    name: "Pointer click drift delay",
    tooltip: "After pressing a pointer button down, this is the maximum time (in milliseconds) that pointer movement can be ignored for.\n\nHelps prevent objects from being unintentionally nudged if the pointer is moved whilst clicking.",
    experimental: true,
    type: "slider",
    attrs: {
      min: 0,
      max: 1e3,
      step: 25
    },
    defaultValue: 150,
    versionAdded: "1.4.3"
  },
  {
    id: "Comfy.Pointer.DoubleClickTime",
    category: ["LiteGraph", "Pointer", "DoubleClickTime"],
    name: "Double click interval (maximum)",
    tooltip: "The maximum time in milliseconds between the two clicks of a double-click.  Increasing this value may assist if double-clicks are sometimes not registered.",
    type: "slider",
    attrs: {
      min: 100,
      max: 1e3,
      step: 50
    },
    defaultValue: 300,
    versionAdded: "1.4.3"
  },
  {
    id: "Comfy.SnapToGrid.GridSize",
    category: ["LiteGraph", "Canvas", "GridSize"],
    name: "Snap to grid size",
    type: "slider",
    attrs: {
      min: 1,
      max: 500
    },
    tooltip: "When dragging and resizing nodes while holding shift they will be aligned to the grid, this controls the size of that grid.",
    defaultValue: LiteGraph.CANVAS_GRID_SIZE
  },
  // Keep the 'pysssss.SnapToGrid' setting id so we don't need to migrate setting values.
  // Using a new setting id can cause existing users to lose their existing settings.
  {
    id: "pysssss.SnapToGrid",
    category: ["LiteGraph", "Canvas", "AlwaysSnapToGrid"],
    name: "Always snap to grid",
    type: "boolean",
    defaultValue: false,
    versionAdded: "1.3.13"
  },
  {
    id: "Comfy.Server.ServerConfigValues",
    name: "Server config values for frontend display",
    tooltip: "Server config values used for frontend display only",
    type: "hidden",
    // Mapping from server config id to value.
    defaultValue: {},
    versionAdded: "1.4.8"
  },
  {
    id: "Comfy.Server.LaunchArgs",
    name: "Server launch arguments",
    tooltip: "These are the actual arguments that are passed to the server when it is launched.",
    type: "hidden",
    defaultValue: {},
    versionAdded: "1.4.8"
  },
  {
    id: "Comfy.Queue.MaxHistoryItems",
    name: "Queue history size",
    tooltip: "The maximum number of tasks that show in the queue history.",
    type: "slider",
    attrs: {
      min: 2,
      max: 256,
      step: 2
    },
    defaultValue: 64,
    versionAdded: "1.4.12"
  },
  {
    id: "Comfy.Execution.PreviewMethod",
    category: ["Comfy", "Execution", "PreviewMethod"],
    name: "Live preview method",
    tooltip: 'Live preview method during image generation. "default" uses the server CLI setting.',
    type: "combo",
    options: ["default", "none", "auto", "latent2rgb", "taesd"],
    defaultValue: "default",
    versionAdded: "1.36.0"
  },
  {
    id: "LiteGraph.Canvas.MaximumFps",
    name: "Maximum FPS",
    tooltip: "The maximum frames per second that the canvas is allowed to render. Caps GPU usage at the cost of smoothness. If 0, the screen refresh rate is used. Default: 0",
    type: "slider",
    attrs: {
      min: 0,
      max: 120
    },
    defaultValue: 0,
    versionAdded: "1.5.1"
  },
  {
    id: "Comfy.EnableWorkflowViewRestore",
    category: ["Comfy", "Workflow", "EnableWorkflowViewRestore"],
    name: "Save and restore canvas position and zoom level in workflows",
    type: "boolean",
    defaultValue: true,
    versionModified: "1.5.4"
  },
  {
    id: "Comfy.Workflow.ConfirmDelete",
    name: "Show confirmation when deleting workflows",
    type: "boolean",
    defaultValue: true,
    versionAdded: "1.5.6"
  },
  {
    id: "Comfy.ColorPalette",
    name: "The active color palette id",
    type: "hidden",
    defaultValue: "dark",
    versionModified: "1.6.7",
    migrateDeprecatedValue(value) {
      return value.startsWith("custom_") ? value.replace("custom_", "") : value;
    }
  },
  {
    id: "Comfy.CustomColorPalettes",
    name: "Custom color palettes",
    type: "hidden",
    defaultValue: {},
    versionModified: "1.6.7"
  },
  {
    id: "Comfy.WidgetControlMode",
    category: ["Comfy", "Node Widget", "WidgetControlMode"],
    name: "Widget control mode",
    tooltip: "Controls when widget values are updated (randomize/increment/decrement), either before the prompt is queued or after.",
    type: "combo",
    defaultValue: "after",
    options: ["before", "after"],
    versionModified: "1.6.10"
  },
  {
    id: "Comfy.TutorialCompleted",
    name: "Tutorial completed",
    type: "hidden",
    defaultValue: false,
    versionAdded: "1.8.7"
  },
  {
    id: "Comfy.InstalledVersion",
    name: "The frontend version that was running when the user first installed ComfyUI",
    type: "hidden",
    defaultValue: null,
    versionAdded: "1.24.0"
  },
  {
    id: "LiteGraph.ContextMenu.Scaling",
    name: "Scale node combo widget menus (lists) when zoomed in",
    defaultValue: false,
    type: "boolean",
    versionAdded: "1.8.8"
  },
  {
    id: "LiteGraph.Canvas.LowQualityRenderingZoomThreshold",
    type: "hidden",
    deprecated: true,
    name: "Low quality rendering zoom threshold (deprecated)",
    tooltip: "Zoom level threshold for performance mode. Lower values (0.1) = quality at all zoom levels. Higher values (1.0) = performance mode even when zoomed in. Performance mode simplifies rendering by hiding text labels, shadows, and details.",
    attrs: {
      min: 0.1,
      max: 1,
      step: 0.01
    },
    defaultValue: 0.6,
    versionAdded: "1.9.1",
    versionModified: "1.26.7"
  },
  {
    id: "LiteGraph.Canvas.MinFontSizeForLOD",
    name: "Zoom Node Level of Detail - font size threshold",
    tooltip: "Controls when the nodes switch to low quality LOD rendering. Uses font size in pixels to determine when to switch. Set to 0 to disable. Values 1-24 set the minimum font size threshold for LOD - higher values (24px) = switch nodes to simplified rendering sooner when zooming out, lower values (1px) = maintain full node quality longer.",
    type: "slider",
    attrs: {
      min: 0,
      max: 24,
      step: 1
    },
    defaultValue: 8,
    versionAdded: "1.26.7",
    hideInVueNodes: true
  },
  {
    id: "Comfy.Canvas.SelectionToolbox",
    category: ["LiteGraph", "Canvas", "SelectionToolbox"],
    name: "Show selection toolbox",
    type: "boolean",
    defaultValue: true,
    versionAdded: "1.10.5"
  },
  {
    id: "LiteGraph.Reroute.SplineOffset",
    name: "Reroute spline offset",
    tooltip: "The bezier control point offset from the reroute centre point",
    type: "slider",
    defaultValue: 20,
    attrs: {
      min: 0,
      max: 400
    },
    versionAdded: "1.15.7"
  },
  {
    id: "Comfy.Toast.DisableReconnectingToast",
    name: "Disable toasts when reconnecting or reconnected",
    type: "hidden",
    defaultValue: false,
    versionAdded: "1.15.12"
  },
  {
    id: "Comfy.Minimap.Visible",
    name: "Display minimap on canvas",
    type: "hidden",
    defaultValue: window.innerWidth >= breakpointsTailwind.lg,
    versionAdded: "1.25.0"
  },
  {
    id: "Comfy.Minimap.NodeColors",
    name: "Display node with its original color on minimap",
    type: "hidden",
    defaultValue: false,
    versionAdded: "1.26.0"
  },
  {
    id: "Comfy.Minimap.ShowLinks",
    name: "Display links on minimap",
    type: "hidden",
    defaultValue: true,
    versionAdded: "1.26.0"
  },
  {
    id: "Comfy.Minimap.ShowGroups",
    name: "Display node groups on minimap",
    type: "hidden",
    defaultValue: true,
    versionAdded: "1.26.0"
  },
  {
    id: "Comfy.Minimap.RenderBypassState",
    name: "Render bypass state on minimap",
    type: "hidden",
    defaultValue: true,
    versionAdded: "1.26.0"
  },
  {
    id: "Comfy.Minimap.RenderErrorState",
    name: "Render error state on minimap",
    type: "hidden",
    defaultValue: true,
    versionAdded: "1.26.0"
  },
  {
    id: "Comfy.Workflow.AutoSaveDelay",
    name: "Auto Save Delay (ms)",
    defaultValue: 1e3,
    type: "number",
    tooltip: 'Only applies if Auto Save is set to "after delay".',
    versionAdded: "1.16.0"
  },
  {
    id: "Comfy.Workflow.AutoSave",
    name: "Auto Save",
    type: "combo",
    options: ["off", "after delay"],
    // Room for other options like on focus change, tab change, window change
    defaultValue: "off",
    // Popular request by users (https://github.com/Comfy-Org/ComfyUI_frontend/issues/1584#issuecomment-2536610154)
    versionAdded: "1.16.0"
  },
  {
    id: "Comfy.Workflow.Persist",
    name: "Persist workflow state and restore on page (re)load",
    type: "boolean",
    defaultValue: true,
    versionAdded: "1.16.1"
  },
  {
    id: "LiteGraph.Node.DefaultPadding",
    name: "Always shrink new nodes",
    tooltip: "Resize nodes to the smallest possible size when created. When disabled, a newly added node will be widened slightly to show widget values.",
    type: "boolean",
    defaultValue: false,
    versionAdded: "1.18.0"
  },
  {
    id: "Comfy.Canvas.BackgroundImage",
    category: ["Appearance", "Canvas", "Background"],
    name: "Canvas background image",
    type: "backgroundImage",
    tooltip: 'Image URL for the canvas background. You can right-click an image in the outputs panel and select "Set as Background" to use it, or upload your own image using the upload button.',
    defaultValue: "",
    versionAdded: "1.20.4",
    versionModified: "1.20.5"
  },
  // Release data stored in settings
  {
    id: "Comfy.Release.Version",
    name: "Last seen release version",
    type: "hidden",
    defaultValue: ""
  },
  {
    id: "Comfy.Release.Status",
    name: "Release status",
    type: "hidden",
    defaultValue: "skipped"
  },
  {
    id: "Comfy.Release.Timestamp",
    name: "Release seen timestamp",
    type: "hidden",
    defaultValue: 0
  },
  /**
   * Template Library Filter Settings
   */
  {
    id: "Comfy.Templates.SelectedModels",
    name: "Template library - Selected model filters",
    type: "hidden",
    defaultValue: []
  },
  {
    id: "Comfy.Templates.SelectedUseCases",
    name: "Template library - Selected use case filters",
    type: "hidden",
    defaultValue: []
  },
  {
    id: "Comfy.Templates.SelectedRunsOn",
    name: "Template library - Selected runs on filters",
    type: "hidden",
    defaultValue: []
  },
  {
    id: "Comfy.Templates.SortBy",
    name: "Template library - Sort preference",
    type: "hidden",
    defaultValue: "newest"
  },
  /**
   * Nodes 2.0 Settings
   */
  {
    id: "Comfy.VueNodes.Enabled",
    category: ["Comfy", "Nodes 2.0", "VueNodesEnabled"],
    name: "Modern Node Design (Nodes 2.0)",
    type: "boolean",
    tooltip: "Modern: DOM-based rendering with enhanced interactivity, native browser features, and updated visual design. Classic: Traditional canvas rendering.",
    defaultValue: false,
    sortOrder: 100,
    experimental: true,
    versionAdded: "1.27.1"
  },
  {
    id: "Comfy.VueNodes.AutoScaleLayout",
    category: ["Comfy", "Nodes 2.0", "AutoScaleLayout"],
    name: "Auto-scale layout (Nodes 2.0)",
    tooltip: "Automatically scale node positions when switching to Nodes 2.0 rendering to prevent overlap",
    type: "boolean",
    sortOrder: 50,
    experimental: true,
    defaultValue: true,
    versionAdded: "1.30.3"
  },
  {
    id: "Comfy.Assets.UseAssetAPI",
    name: "Use Asset API for model library",
    type: "hidden",
    tooltip: "Use new Asset API for model browsing",
    defaultValue: false,
    experimental: true
  },
  {
    id: "Comfy.VersionCompatibility.DisableWarnings",
    name: "Disable version compatibility warnings",
    type: "hidden",
    defaultValue: false,
    versionAdded: "1.34.1"
  }
];
function useWorkflowAutoSave() {
  const workflowStore = useWorkflowStore();
  const settingStore = useSettingStore();
  const workflowService = useWorkflowService();
  const autoSaveSetting = computed(
    () => settingStore.get("Comfy.Workflow.AutoSave")
  );
  const autoSaveDelay = computed(
    () => settingStore.get("Comfy.Workflow.AutoSaveDelay")
  );
  let autoSaveTimeout = null;
  let isSaving = false;
  let needsAutoSave = false;
  const scheduleAutoSave = /* @__PURE__ */ __name(() => {
    if (autoSaveTimeout) {
      clearTimeout(autoSaveTimeout);
      autoSaveTimeout = null;
    }
    if (autoSaveSetting.value === "after delay") {
      if (isSaving) {
        needsAutoSave = true;
        return;
      }
      const delay = autoSaveDelay.value;
      autoSaveTimeout = setTimeout(async () => {
        const activeWorkflow = workflowStore.activeWorkflow;
        if (activeWorkflow?.isModified && activeWorkflow.isPersisted) {
          try {
            isSaving = true;
            await workflowService.saveWorkflow(activeWorkflow);
          } catch (err) {
            console.error("Auto save failed:", err);
          } finally {
            isSaving = false;
            if (needsAutoSave) {
              needsAutoSave = false;
              scheduleAutoSave();
            }
          }
        }
      }, delay);
    }
  }, "scheduleAutoSave");
  watch(
    autoSaveSetting,
    (newSetting) => {
      if (autoSaveTimeout) {
        clearTimeout(autoSaveTimeout);
        autoSaveTimeout = null;
      }
      if (newSetting === "after delay" && workflowStore.activeWorkflow?.isModified) {
        scheduleAutoSave();
      }
    },
    { immediate: true }
  );
  const onGraphChanged = /* @__PURE__ */ __name(() => {
    scheduleAutoSave();
  }, "onGraphChanged");
  api.addEventListener("graphChanged", onGraphChanged);
  onUnmounted(() => {
    if (autoSaveTimeout) {
      clearTimeout(autoSaveTimeout);
      autoSaveTimeout = null;
    }
    api.removeEventListener("graphChanged", onGraphChanged);
  });
}
__name(useWorkflowAutoSave, "useWorkflowAutoSave");
function useTemplateUrlLoader() {
  const route = useRoute();
  const router = useRouter();
  const { t: t2 } = useI18n();
  const toast = useToast();
  const templateWorkflows = useTemplateWorkflows();
  const canvasStore = useCanvasStore();
  const TEMPLATE_NAMESPACE = PRESERVED_QUERY_NAMESPACES.TEMPLATE;
  const SUPPORTED_MODES = ["linear"];
  const isValidParameter = /* @__PURE__ */ __name((param) => {
    return /^[a-zA-Z0-9_.-]+$/.test(param);
  }, "isValidParameter");
  const isSupportedMode = /* @__PURE__ */ __name((mode) => {
    return SUPPORTED_MODES.includes(mode);
  }, "isSupportedMode");
  const cleanupUrlParams = /* @__PURE__ */ __name(() => {
    const newQuery = { ...route.query };
    delete newQuery.template;
    delete newQuery.source;
    delete newQuery.mode;
    void router.replace({ query: newQuery });
  }, "cleanupUrlParams");
  const loadTemplateFromUrl = /* @__PURE__ */ __name(async () => {
    const templateParam = route.query.template;
    if (!templateParam || typeof templateParam !== "string") {
      return;
    }
    if (!isValidParameter(templateParam)) {
      console.warn(
        `[useTemplateUrlLoader] Invalid template parameter format: ${templateParam}`
      );
      return;
    }
    const sourceParam = route.query.source || "default";
    if (!isValidParameter(sourceParam)) {
      console.warn(
        `[useTemplateUrlLoader] Invalid source parameter format: ${sourceParam}`
      );
      return;
    }
    const modeParam = route.query.mode;
    if (modeParam && (typeof modeParam !== "string" || !isValidParameter(modeParam))) {
      console.warn(
        `[useTemplateUrlLoader] Invalid mode parameter format: ${modeParam}`
      );
      return;
    }
    if (modeParam && !isSupportedMode(modeParam)) {
      console.warn(
        `[useTemplateUrlLoader] Unsupported mode parameter: ${modeParam}. Supported modes: ${SUPPORTED_MODES.join(", ")}`
      );
    }
    try {
      await templateWorkflows.loadTemplates();
      const success = await templateWorkflows.loadWorkflowTemplate(
        templateParam,
        sourceParam
      );
      if (!success) {
        toast.add({
          severity: "error",
          summary: t2("g.error"),
          detail: t2("templateWorkflows.error.templateNotFound", {
            templateName: templateParam
          }),
          life: 3e3
        });
      } else if (modeParam === "linear") {
        canvasStore.linearMode = true;
      }
    } catch (error) {
      console.error(
        "[useTemplateUrlLoader] Failed to load template from URL:",
        error
      );
      toast.add({
        severity: "error",
        summary: t2("g.error"),
        detail: t2("g.errorLoadingTemplate"),
        life: 3e3
      });
    } finally {
      cleanupUrlParams();
      clearPreservedQuery(TEMPLATE_NAMESPACE);
    }
  }, "loadTemplateFromUrl");
  return {
    loadTemplateFromUrl
  };
}
__name(useTemplateUrlLoader, "useTemplateUrlLoader");
function useWorkflowPersistence() {
  const workflowStore = useWorkflowStore();
  const settingStore = useSettingStore();
  const route = useRoute();
  const router = useRouter();
  const templateUrlLoader = useTemplateUrlLoader();
  const TEMPLATE_NAMESPACE = PRESERVED_QUERY_NAMESPACES.TEMPLATE;
  const ensureTemplateQueryFromIntent = /* @__PURE__ */ __name(async () => {
    hydratePreservedQuery(TEMPLATE_NAMESPACE);
    const mergedQuery = mergePreservedQueryIntoQuery(
      TEMPLATE_NAMESPACE,
      route.query
    );
    if (mergedQuery) {
      await router.replace({ query: mergedQuery });
    }
    return mergedQuery ?? route.query;
  }, "ensureTemplateQueryFromIntent");
  const workflowPersistenceEnabled = computed(
    () => settingStore.get("Comfy.Workflow.Persist")
  );
  const persistCurrentWorkflow = /* @__PURE__ */ __name(() => {
    if (!workflowPersistenceEnabled.value) return;
    const workflow = JSON.stringify(app.rootGraph.serialize());
    try {
      localStorage.setItem("workflow", workflow);
      if (api.clientId) {
        sessionStorage.setItem(`workflow:${api.clientId}`, workflow);
      }
    } catch (error) {
      const ourKeys = Object.keys(sessionStorage).filter(
        (key) => key.startsWith("workflow:") || key === "workflow"
      );
      console.error("QuotaExceededError details:", {
        workflowSizeKB: Math.round(workflow.length / 1024),
        totalStorageItems: Object.keys(sessionStorage).length,
        ourWorkflowKeys: ourKeys.length,
        ourWorkflowSizes: ourKeys.map((key) => ({
          key,
          sizeKB: Math.round(sessionStorage[key].length / 1024)
        })),
        error: error instanceof Error ? error.message : String(error)
      });
      throw error;
    }
  }, "persistCurrentWorkflow");
  const loadWorkflowFromStorage = /* @__PURE__ */ __name(async (json, workflowName) => {
    if (!json) return false;
    const workflow = JSON.parse(json);
    await app.loadGraphData(workflow, true, true, workflowName);
    return true;
  }, "loadWorkflowFromStorage");
  const loadPreviousWorkflowFromStorage = /* @__PURE__ */ __name(async () => {
    const workflowName = getStorageValue("Comfy.PreviousWorkflow");
    const clientId = api.initialClientId ?? api.clientId;
    if (clientId) {
      const sessionWorkflow = sessionStorage.getItem(`workflow:${clientId}`);
      if (await loadWorkflowFromStorage(sessionWorkflow, workflowName)) {
        return true;
      }
    }
    const localWorkflow = localStorage.getItem("workflow");
    return await loadWorkflowFromStorage(localWorkflow, workflowName);
  }, "loadPreviousWorkflowFromStorage");
  const loadDefaultWorkflow = /* @__PURE__ */ __name(async () => {
    if (!settingStore.get("Comfy.TutorialCompleted")) {
      await settingStore.set("Comfy.TutorialCompleted", true);
      await useWorkflowService().loadBlankWorkflow();
      await useCommandStore().execute("Comfy.BrowseTemplates");
    } else {
      await app.loadGraphData();
    }
  }, "loadDefaultWorkflow");
  const initializeWorkflow = /* @__PURE__ */ __name(async () => {
    if (!workflowPersistenceEnabled.value) return;
    try {
      const restored = await loadPreviousWorkflowFromStorage();
      if (!restored) {
        await loadDefaultWorkflow();
      }
    } catch (err) {
      console.error("Error loading previous workflow", err);
      await loadDefaultWorkflow();
    }
  }, "initializeWorkflow");
  const loadTemplateFromUrlIfPresent = /* @__PURE__ */ __name(async () => {
    const query = await ensureTemplateQueryFromIntent();
    const hasTemplateUrl = query.template && typeof query.template === "string";
    if (hasTemplateUrl) {
      await templateUrlLoader.loadTemplateFromUrl();
    }
  }, "loadTemplateFromUrlIfPresent");
  watch(
    () => workflowStore.activeWorkflow?.key,
    (activeWorkflowKey) => {
      if (!activeWorkflowKey) return;
      setStorageValue("Comfy.PreviousWorkflow", activeWorkflowKey);
      persistCurrentWorkflow();
    }
  );
  api.addEventListener("graphChanged", persistCurrentWorkflow);
  tryOnScopeDispose(() => {
    api.removeEventListener("graphChanged", persistCurrentWorkflow);
  });
  const openWorkflows = computed(() => workflowStore.openWorkflows);
  const activeWorkflow = computed(() => workflowStore.activeWorkflow);
  const restoreState = computed(
    () => {
      if (!openWorkflows.value || !activeWorkflow.value) {
        return { paths: [], activeIndex: -1 };
      }
      const paths = openWorkflows.value.filter((workflow) => workflow?.isPersisted).map((workflow) => workflow.path);
      const activeIndex = openWorkflows.value.findIndex(
        (workflow) => workflow.path === activeWorkflow.value?.path
      );
      return { paths, activeIndex };
    }
  );
  const storedWorkflows = JSON.parse(
    getStorageValue("Comfy.OpenWorkflowsPaths") || "[]"
  );
  const storedActiveIndex = JSON.parse(
    getStorageValue("Comfy.ActiveWorkflowIndex") || "-1"
  );
  watch(restoreState, ({ paths, activeIndex }) => {
    if (workflowPersistenceEnabled.value) {
      setStorageValue("Comfy.OpenWorkflowsPaths", JSON.stringify(paths));
      setStorageValue("Comfy.ActiveWorkflowIndex", JSON.stringify(activeIndex));
    }
  });
  const restoreWorkflowTabsState = /* @__PURE__ */ __name(() => {
    if (!workflowPersistenceEnabled.value) return;
    const isRestorable = storedWorkflows?.length > 0 && storedActiveIndex >= 0;
    if (isRestorable) {
      workflowStore.openWorkflowsInBackground({
        left: storedWorkflows.slice(0, storedActiveIndex),
        right: storedWorkflows.slice(storedActiveIndex)
      });
    }
  }, "restoreWorkflowTabsState");
  return {
    initializeWorkflow,
    loadTemplateFromUrlIfPresent,
    restoreWorkflowTabsState
  };
}
__name(useWorkflowPersistence, "useWorkflowPersistence");
function useTransformSettling(target, options = {}) {
  const { settleDelay = 256, passive = true } = options;
  const isTransforming = ref(false);
  const markTransformActive = /* @__PURE__ */ __name(() => {
    isTransforming.value = true;
  }, "markTransformActive");
  const markTransformSettled = useDebounceFn(() => {
    isTransforming.value = false;
  }, settleDelay);
  const handleWheel = /* @__PURE__ */ __name(() => {
    markTransformActive();
    void markTransformSettled();
  }, "handleWheel");
  useEventListener(target, "wheel", handleWheel, {
    capture: true,
    passive
  });
  return {
    isTransforming
  };
}
__name(useTransformSettling, "useTransformSettling");
function useTransformStateIndividual() {
  const camera = reactive({
    x: 0,
    y: 0,
    z: 1
  });
  const transformStyle = computed(() => ({
    // Match LiteGraph DragAndScale.toCanvasContext():
    // ctx.scale(scale); ctx.translate(offset)
    // CSS applies right-to-left, so "scale() translate()" -> translate first, then scale
    // Effective mapping: screen = (canvas + offset) * scale
    transform: `scale(${camera.z}) translate(${camera.x}px, ${camera.y}px)`,
    transformOrigin: "0 0"
  }));
  function syncWithCanvas(canvas) {
    if (!canvas || !canvas.ds) return;
    camera.x = canvas.ds.offset[0];
    camera.y = canvas.ds.offset[1];
    camera.z = canvas.ds.scale || 1;
  }
  __name(syncWithCanvas, "syncWithCanvas");
  function canvasToScreen(point) {
    return {
      x: (point.x + camera.x) * camera.z,
      y: (point.y + camera.y) * camera.z
    };
  }
  __name(canvasToScreen, "canvasToScreen");
  const screenToCanvas = /* @__PURE__ */ __name((point) => {
    return {
      x: point.x / camera.z - camera.x,
      y: point.y / camera.z - camera.y
    };
  }, "screenToCanvas");
  function getNodeScreenBounds(pos, size) {
    const topLeft = canvasToScreen({ x: pos[0], y: pos[1] });
    const width = size[0] * camera.z;
    const height = size[1] * camera.z;
    return new DOMRect(topLeft.x, topLeft.y, width, height);
  }
  __name(getNodeScreenBounds, "getNodeScreenBounds");
  function calculateAdjustedMargin(baseMargin) {
    if (camera.z < 0.1) return Math.min(baseMargin * 5, 2);
    if (camera.z > 3) return Math.max(baseMargin * 0.5, 0.05);
    return baseMargin;
  }
  __name(calculateAdjustedMargin, "calculateAdjustedMargin");
  function isNodeTooSmall(nodeSize) {
    const nodeScreenSize = Math.max(nodeSize[0], nodeSize[1]) * camera.z;
    return nodeScreenSize < 4;
  }
  __name(isNodeTooSmall, "isNodeTooSmall");
  function getExpandedViewportBounds(viewport, margin) {
    const marginX = viewport.width * margin;
    const marginY = viewport.height * margin;
    return {
      left: -marginX,
      right: viewport.width + marginX,
      top: -marginY,
      bottom: viewport.height + marginY
    };
  }
  __name(getExpandedViewportBounds, "getExpandedViewportBounds");
  function testViewportIntersection(screenPos, nodeSize, bounds) {
    const nodeRight = screenPos.x + nodeSize[0] * camera.z;
    const nodeBottom = screenPos.y + nodeSize[1] * camera.z;
    return !(nodeRight < bounds.left || screenPos.x > bounds.right || nodeBottom < bounds.top || screenPos.y > bounds.bottom);
  }
  __name(testViewportIntersection, "testViewportIntersection");
  function isNodeInViewport(nodePos, nodeSize, viewport, margin = 0.2) {
    if (isNodeTooSmall(nodeSize)) return false;
    const screenPos = canvasToScreen({ x: nodePos[0], y: nodePos[1] });
    const adjustedMargin = calculateAdjustedMargin(margin);
    const bounds = getExpandedViewportBounds(viewport, adjustedMargin);
    return testViewportIntersection(screenPos, nodeSize, bounds);
  }
  __name(isNodeInViewport, "isNodeInViewport");
  function getViewportBounds(viewport, margin = 0.2) {
    const marginX = viewport.width * margin;
    const marginY = viewport.height * margin;
    const topLeft = screenToCanvas({ x: -marginX, y: -marginY });
    const bottomRight = screenToCanvas({
      x: viewport.width + marginX,
      y: viewport.height + marginY
    });
    return {
      x: topLeft.x,
      y: topLeft.y,
      width: bottomRight.x - topLeft.x,
      height: bottomRight.y - topLeft.y
    };
  }
  __name(getViewportBounds, "getViewportBounds");
  return {
    camera: readonly(camera),
    transformStyle,
    syncWithCanvas,
    canvasToScreen,
    screenToCanvas,
    getNodeScreenBounds,
    isNodeInViewport,
    getViewportBounds
  };
}
__name(useTransformStateIndividual, "useTransformStateIndividual");
const useTransformState = createSharedComposable(
  useTransformStateIndividual
);
const _sfc_main$e = /* @__PURE__ */ defineComponent({
  __name: "TransformPane",
  props: {
    canvas: {}
  },
  setup(__props) {
    const props = __props;
    const { transformStyle, syncWithCanvas } = useTransformState();
    const canvasElement = computed(() => props.canvas?.canvas);
    const { isTransforming: isInteracting } = useTransformSettling(canvasElement, {
      settleDelay: 16
    });
    useRafFn(
      () => {
        if (!props.canvas) {
          return;
        }
        syncWithCanvas(props.canvas);
      },
      { immediate: true }
    );
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        "data-testid": "transform-pane",
        class: normalizeClass(
          unref(cn)(
            "absolute inset-0 w-full h-full pointer-events-none",
            unref(isInteracting) ? "transform-pane--interacting" : "will-change-auto"
          )
        ),
        style: normalizeStyle(unref(transformStyle))
      }, [
        renderSlot(_ctx.$slots, "default", {}, void 0, true)
      ], 6);
    };
  }
});
const TransformPane = /* @__PURE__ */ _export_sfc(_sfc_main$e, [["__scopeId", "data-v-4d46eee6"]]);
const _hoisted_1$e = { class: "flex items-center gap-2" };
const _hoisted_2$a = { for: "node-colors" };
const _hoisted_3$8 = { class: "flex items-center gap-2" };
const _hoisted_4$6 = { for: "show-links" };
const _hoisted_5$5 = { class: "flex items-center gap-2" };
const _hoisted_6$5 = { for: "show-groups" };
const _hoisted_7$4 = { class: "flex items-center gap-2" };
const _hoisted_8$4 = { for: "render-bypass" };
const _hoisted_9$3 = { class: "flex items-center gap-2" };
const _hoisted_10$3 = { for: "render-error" };
const _sfc_main$d = /* @__PURE__ */ defineComponent({
  __name: "MiniMapPanel",
  props: {
    panelStyles: {},
    nodeColors: { type: Boolean },
    showLinks: { type: Boolean },
    showGroups: { type: Boolean },
    renderBypass: { type: Boolean },
    renderError: { type: Boolean }
  },
  emits: ["updateOption"],
  setup(__props) {
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: "minimap-panel mr-2 flex flex-col gap-2 bg-comfy-menu-bg p-3 text-sm shadow-interface",
        style: normalizeStyle(_ctx.panelStyles)
      }, [
        createBaseVNode("div", _hoisted_1$e, [
          createVNode(unref(script$r), {
            "input-id": "node-colors",
            name: "node-colors",
            "model-value": _ctx.nodeColors,
            binary: "",
            "onUpdate:modelValue": _cache[0] || (_cache[0] = (value) => _ctx.$emit("updateOption", "Comfy.Minimap.NodeColors", value))
          }, null, 8, ["model-value"]),
          _cache[5] || (_cache[5] = createBaseVNode("i", { class: "icon-[lucide--palette]" }, null, -1)),
          createBaseVNode("label", _hoisted_2$a, toDisplayString(_ctx.$t("minimap.nodeColors")), 1)
        ]),
        createBaseVNode("div", _hoisted_3$8, [
          createVNode(unref(script$r), {
            "input-id": "show-links",
            name: "show-links",
            "model-value": _ctx.showLinks,
            binary: "",
            "onUpdate:modelValue": _cache[1] || (_cache[1] = (value) => _ctx.$emit("updateOption", "Comfy.Minimap.ShowLinks", value))
          }, null, 8, ["model-value"]),
          _cache[6] || (_cache[6] = createBaseVNode("i", { class: "icon-[lucide--route]" }, null, -1)),
          createBaseVNode("label", _hoisted_4$6, toDisplayString(_ctx.$t("minimap.showLinks")), 1)
        ]),
        createBaseVNode("div", _hoisted_5$5, [
          createVNode(unref(script$r), {
            "input-id": "show-groups",
            name: "show-groups",
            "model-value": _ctx.showGroups,
            binary: "",
            "onUpdate:modelValue": _cache[2] || (_cache[2] = (value) => _ctx.$emit("updateOption", "Comfy.Minimap.ShowGroups", value))
          }, null, 8, ["model-value"]),
          _cache[7] || (_cache[7] = createBaseVNode("i", { class: "icon-[lucide--frame]" }, null, -1)),
          createBaseVNode("label", _hoisted_6$5, toDisplayString(_ctx.$t("minimap.showGroups")), 1)
        ]),
        createBaseVNode("div", _hoisted_7$4, [
          createVNode(unref(script$r), {
            "input-id": "render-bypass",
            name: "render-bypass",
            "model-value": _ctx.renderBypass,
            binary: "",
            "onUpdate:modelValue": _cache[3] || (_cache[3] = (value) => _ctx.$emit("updateOption", "Comfy.Minimap.RenderBypassState", value))
          }, null, 8, ["model-value"]),
          _cache[8] || (_cache[8] = createBaseVNode("i", { class: "icon-[lucide--circle-slash-2]" }, null, -1)),
          createBaseVNode("label", _hoisted_8$4, toDisplayString(_ctx.$t("minimap.renderBypassState")), 1)
        ]),
        createBaseVNode("div", _hoisted_9$3, [
          createVNode(unref(script$r), {
            "input-id": "render-error",
            name: "render-error",
            "model-value": _ctx.renderError,
            binary: "",
            "onUpdate:modelValue": _cache[4] || (_cache[4] = (value) => _ctx.$emit("updateOption", "Comfy.Minimap.RenderErrorState", value))
          }, null, 8, ["model-value"]),
          _cache[9] || (_cache[9] = createBaseVNode("i", { class: "icon-[lucide--message-circle-warning]" }, null, -1)),
          createBaseVNode("label", _hoisted_10$3, toDisplayString(_ctx.$t("minimap.renderErrorState")), 1)
        ])
      ], 4);
    };
  }
});
const _hoisted_1$d = ["width", "height"];
const _sfc_main$c = /* @__PURE__ */ defineComponent({
  __name: "MiniMap",
  setup(__props) {
    const commandStore = useCommandStore();
    const minimapRef = ref();
    const containerRef = useTemplateRef("containerRef");
    const canvasRef = useTemplateRef("canvasRef");
    const {
      initialized,
      visible,
      containerStyles,
      viewportStyles,
      width,
      height,
      panelStyles,
      nodeColors,
      showLinks,
      showGroups,
      renderBypass,
      renderError,
      updateOption,
      destroy,
      handlePointerDown,
      handlePointerMove,
      handlePointerUp,
      handlePointerCancel,
      handleWheel,
      setMinimapRef
    } = useMinimap({
      containerRefMaybe: containerRef,
      canvasRefMaybe: canvasRef
    });
    const showOptionsPanel = ref(false);
    const toggleOptionsPanel = /* @__PURE__ */ __name(() => {
      showOptionsPanel.value = !showOptionsPanel.value;
    }, "toggleOptionsPanel");
    onMounted(() => {
      if (minimapRef.value) {
        setMinimapRef(minimapRef.value);
      }
    });
    onUnmounted(() => {
      destroy();
    });
    return (_ctx, _cache) => {
      return unref(visible) && unref(initialized) ? (openBlock(), createElementBlock("div", {
        key: 0,
        ref_key: "minimapRef",
        ref: minimapRef,
        class: "minimap-main-container absolute right-0 bottom-[54px] z-1000 flex"
      }, [
        showOptionsPanel.value ? (openBlock(), createBlock(_sfc_main$d, {
          key: 0,
          "panel-styles": unref(panelStyles),
          "node-colors": unref(nodeColors),
          "show-links": unref(showLinks),
          "show-groups": unref(showGroups),
          "render-bypass": unref(renderBypass),
          "render-error": unref(renderError),
          onUpdateOption: unref(updateOption)
        }, null, 8, ["panel-styles", "node-colors", "show-links", "show-groups", "render-bypass", "render-error", "onUpdateOption"])) : createCommentVNode("", true),
        createBaseVNode("div", {
          ref_key: "containerRef",
          ref: containerRef,
          class: "litegraph-minimap relative border border-interface-stroke bg-comfy-menu-bg shadow-interface",
          style: normalizeStyle(unref(containerStyles))
        }, [
          createVNode(_sfc_main$1Y, {
            class: "absolute top-0 left-0 z-10",
            size: "icon",
            variant: "muted-textonly",
            "aria-label": _ctx.$t("g.settings"),
            onClick: withModifiers(toggleOptionsPanel, ["stop"])
          }, {
            default: withCtx(() => _cache[7] || (_cache[7] = [
              createBaseVNode("i", { class: "icon-[lucide--settings-2]" }, null, -1)
            ])),
            _: 1
          }, 8, ["aria-label"]),
          createVNode(_sfc_main$1Y, {
            class: "absolute top-0 right-0 z-10",
            size: "icon",
            variant: "muted-textonly",
            "aria-label": _ctx.$t("g.close"),
            "data-testid": "close-minmap-button",
            onClick: _cache[0] || (_cache[0] = withModifiers(() => unref(commandStore).execute("Comfy.Canvas.ToggleMinimap"), ["stop"]))
          }, {
            default: withCtx(() => _cache[8] || (_cache[8] = [
              createBaseVNode("i", { class: "icon-[lucide--x]" }, null, -1)
            ])),
            _: 1
          }, 8, ["aria-label"]),
          createBaseVNode("hr", {
            class: "absolute top-6 h-px border-0 bg-node-component-border",
            style: normalizeStyle({
              width: unref(containerStyles).width
            })
          }, null, 4),
          createBaseVNode("canvas", {
            ref_key: "canvasRef",
            ref: canvasRef,
            width: unref(width),
            height: unref(height),
            class: "minimap-canvas"
          }, null, 8, _hoisted_1$d),
          createBaseVNode("div", {
            class: "minimap-viewport",
            style: normalizeStyle(unref(viewportStyles))
          }, null, 4),
          createBaseVNode("div", {
            class: "absolute inset-0 touch-none",
            onPointerdown: _cache[1] || (_cache[1] = //@ts-ignore
            (...args) => unref(handlePointerDown) && unref(handlePointerDown)(...args)),
            onPointermove: _cache[2] || (_cache[2] = //@ts-ignore
            (...args) => unref(handlePointerMove) && unref(handlePointerMove)(...args)),
            onPointerup: _cache[3] || (_cache[3] = //@ts-ignore
            (...args) => unref(handlePointerUp) && unref(handlePointerUp)(...args)),
            onPointerleave: _cache[4] || (_cache[4] = //@ts-ignore
            (...args) => unref(handlePointerUp) && unref(handlePointerUp)(...args)),
            onPointercancel: _cache[5] || (_cache[5] = //@ts-ignore
            (...args) => unref(handlePointerCancel) && unref(handlePointerCancel)(...args)),
            onWheel: _cache[6] || (_cache[6] = //@ts-ignore
            (...args) => unref(handleWheel) && unref(handleWheel)(...args))
          }, null, 32)
        ], 4)
      ], 512)) : createCommentVNode("", true);
    };
  }
});
const MiniMap = /* @__PURE__ */ _export_sfc(_sfc_main$c, [["__scopeId", "data-v-66f11255"]]);
function isMultiSelectKey(event) {
  return event.ctrlKey || event.metaKey || event.shiftKey;
}
__name(isMultiSelectKey, "isMultiSelectKey");
function useNodeEventHandlersIndividual() {
  const canvasStore = useCanvasStore();
  const { nodeManager } = useVueNodeLifecycle();
  const { bringNodeToFront } = useNodeZIndex();
  const { shouldHandleNodePointerEvents } = useCanvasInteractions();
  function handleNodeSelect(event, nodeId) {
    if (!shouldHandleNodePointerEvents.value) return;
    if (!canvasStore.canvas || !nodeManager.value) return;
    const node = nodeManager.value.getNode(nodeId);
    if (!node) return;
    const multiSelect = isMultiSelectKey(event);
    const selectedItemsCount = canvasStore.selectedItems.length;
    const preserveExistingSelection = !multiSelect && node.selected && selectedItemsCount > 1;
    if (multiSelect) {
      if (!node.selected) {
        canvasStore.canvas.select(node);
      }
    } else if (!preserveExistingSelection) {
      canvasStore.canvas.deselectAll();
      canvasStore.canvas.select(node);
    }
    if (!node.flags?.pinned) {
      bringNodeToFront(nodeId);
    }
    canvasStore.updateSelectedItems();
  }
  __name(handleNodeSelect, "handleNodeSelect");
  function handleNodeCollapse(nodeId, collapsed) {
    if (!shouldHandleNodePointerEvents.value) return;
    if (!nodeManager.value) return;
    const node = nodeManager.value.getNode(nodeId);
    if (!node) return;
    const currentCollapsed = node.flags?.collapsed ?? false;
    if (currentCollapsed !== collapsed) {
      node.collapse();
    }
  }
  __name(handleNodeCollapse, "handleNodeCollapse");
  function handleNodeTitleUpdate(nodeId, newTitle) {
    if (!shouldHandleNodePointerEvents.value) return;
    if (!nodeManager.value) return;
    const node = nodeManager.value.getNode(nodeId);
    if (!node) return;
    node.title = newTitle;
  }
  __name(handleNodeTitleUpdate, "handleNodeTitleUpdate");
  function handleNodeRightClick(event, nodeId) {
    if (!shouldHandleNodePointerEvents.value) return;
    if (!canvasStore.canvas || !nodeManager.value) return;
    const node = nodeManager.value.getNode(nodeId);
    if (!node) return;
    event.preventDefault();
    if (!node.selected) {
      handleNodeSelect(event, nodeId);
    }
  }
  __name(handleNodeRightClick, "handleNodeRightClick");
  function toggleNodeSelectionAfterPointerUp(nodeId, multiSelect) {
    if (!shouldHandleNodePointerEvents.value) return;
    if (!canvasStore.canvas || !nodeManager.value) return;
    const node = nodeManager.value.getNode(nodeId);
    if (!node) return;
    if (!multiSelect) {
      canvasStore.canvas.deselectAll();
      canvasStore.canvas.select(node);
      canvasStore.updateSelectedItems();
      if (!node.flags?.pinned) {
        bringNodeToFront(nodeId);
      }
      return;
    }
    if (node.selected) {
      canvasStore.canvas.deselect(node);
    } else {
      canvasStore.canvas.select(node);
      if (!node.flags?.pinned) {
        bringNodeToFront(nodeId);
      }
    }
    canvasStore.updateSelectedItems();
  }
  __name(toggleNodeSelectionAfterPointerUp, "toggleNodeSelectionAfterPointerUp");
  return {
    // Core event handlers
    handleNodeSelect,
    handleNodeCollapse,
    handleNodeTitleUpdate,
    handleNodeRightClick,
    // Batch operations
    toggleNodeSelectionAfterPointerUp
  };
}
__name(useNodeEventHandlersIndividual, "useNodeEventHandlersIndividual");
const useNodeEventHandlers = createSharedComposable(
  useNodeEventHandlersIndividual
);
function useNodeSnap() {
  const settingStore = useSettingStore();
  const gridSize = computed(() => settingStore.get("Comfy.SnapToGrid.GridSize"));
  const alwaysSnap = computed(() => settingStore.get("pysssss.SnapToGrid"));
  function shouldSnap(event) {
    return event.shiftKey || alwaysSnap.value;
  }
  __name(shouldSnap, "shouldSnap");
  function applySnapToPosition(position) {
    const size = gridSize.value;
    if (!size) return { ...position };
    const posArray = [position.x, position.y];
    if (snapPoint(posArray, size)) {
      return { x: posArray[0], y: posArray[1] };
    }
    return { ...position };
  }
  __name(applySnapToPosition, "applySnapToPosition");
  function applySnapToSize(size) {
    const gridSizeValue = gridSize.value;
    if (!gridSizeValue) return { ...size };
    const sizeArray = [size.width, size.height];
    if (snapPoint(sizeArray, gridSizeValue)) {
      return { width: sizeArray[0], height: sizeArray[1] };
    }
    return { ...size };
  }
  __name(applySnapToSize, "applySnapToSize");
  return {
    gridSize,
    alwaysSnap,
    shouldSnap,
    applySnapToPosition,
    applySnapToSize
  };
}
__name(useNodeSnap, "useNodeSnap");
function useShiftKeySync() {
  const shiftKeyState = shallowRef(false);
  let canvasEl = null;
  function syncShiftState(isShiftPressed) {
    if (isShiftPressed === shiftKeyState.value) return;
    if (!canvasEl) {
      canvasEl = app.canvas?.canvas ?? null;
      if (!canvasEl) return;
    }
    shiftKeyState.value = isShiftPressed;
    canvasEl.dispatchEvent(
      new KeyboardEvent(isShiftPressed ? "keydown" : "keyup", {
        key: "Shift",
        shiftKey: isShiftPressed,
        bubbles: true
      })
    );
  }
  __name(syncShiftState, "syncShiftState");
  function trackShiftKey(initialEvent) {
    syncShiftState(initialEvent.shiftKey);
    const handleKeyEvent = /* @__PURE__ */ __name((e) => {
      if (e.key !== "Shift") return;
      syncShiftState(e.shiftKey);
    }, "handleKeyEvent");
    const stopKeydown = useEventListener(window, "keydown", handleKeyEvent, {
      passive: true
    });
    const stopKeyup = useEventListener(window, "keyup", handleKeyEvent, {
      passive: true
    });
    return () => {
      stopKeydown();
      stopKeyup();
    };
  }
  __name(trackShiftKey, "trackShiftKey");
  tryOnScopeDispose(() => {
    shiftKeyState.value = false;
    canvasEl = null;
  });
  return { trackShiftKey };
}
__name(useShiftKeySync, "useShiftKeySync");
const useNodeDrag = createSharedComposable(useNodeDragIndividual);
function useNodeDragIndividual() {
  const mutations = useLayoutMutations();
  const { selectedNodeIds, selectedItems } = storeToRefs(useCanvasStore());
  const transformState = useTransformState();
  const { shouldSnap, applySnapToPosition } = useNodeSnap();
  const { trackShiftKey } = useShiftKeySync();
  let dragStartPos = null;
  let dragStartMouse = null;
  let otherSelectedNodesStartPositions = null;
  let rafId = null;
  let stopShiftSync = null;
  let lastCanvasDelta = null;
  let selectedGroups = null;
  function startDrag(event, nodeId) {
    const layout = toValue(layoutStore.getNodeLayoutRef(nodeId));
    if (!layout) return;
    const position = layout.position ?? { x: 0, y: 0 };
    stopShiftSync = trackShiftKey(event);
    dragStartPos = { ...position };
    dragStartMouse = { x: event.clientX, y: event.clientY };
    const selectedNodes = toValue(selectedNodeIds);
    const isDraggedNodeInSelection = selectedNodes?.has(nodeId);
    if (isDraggedNodeInSelection && selectedNodes.size > 1) {
      otherSelectedNodesStartPositions = /* @__PURE__ */ new Map();
      for (const id of selectedNodes) {
        if (id === nodeId) continue;
        const nodeLayout = layoutStore.getNodeLayoutRef(id).value;
        if (nodeLayout) {
          otherSelectedNodesStartPositions.set(id, { ...nodeLayout.position });
        }
      }
    } else {
      otherSelectedNodesStartPositions = null;
    }
    if (isDraggedNodeInSelection) {
      selectedGroups = toValue(selectedItems).filter(isLGraphGroup);
      lastCanvasDelta = { x: 0, y: 0 };
    } else {
      selectedGroups = null;
      lastCanvasDelta = null;
    }
    mutations.setSource(LayoutSource.Vue);
  }
  __name(startDrag, "startDrag");
  function handleDrag(event, nodeId) {
    if (!dragStartPos || !dragStartMouse) {
      return;
    }
    if (rafId !== null) return;
    const { target, pointerId } = event;
    if (target instanceof HTMLElement && !target.hasPointerCapture(pointerId)) {
      target.setPointerCapture(pointerId);
    }
    rafId = requestAnimationFrame(() => {
      rafId = null;
      if (!dragStartPos || !dragStartMouse) return;
      const mouseDelta = {
        x: event.clientX - dragStartMouse.x,
        y: event.clientY - dragStartMouse.y
      };
      const canvasOrigin = transformState.screenToCanvas({ x: 0, y: 0 });
      const canvasWithDelta = transformState.screenToCanvas(mouseDelta);
      const canvasDelta = {
        x: canvasWithDelta.x - canvasOrigin.x,
        y: canvasWithDelta.y - canvasOrigin.y
      };
      const newPosition = {
        x: dragStartPos.x + canvasDelta.x,
        y: dragStartPos.y + canvasDelta.y
      };
      mutations.moveNode(nodeId, newPosition);
      if (otherSelectedNodesStartPositions && otherSelectedNodesStartPositions.size > 0) {
        for (const [
          otherNodeId,
          startPos
        ] of otherSelectedNodesStartPositions) {
          const newOtherPosition = {
            x: startPos.x + canvasDelta.x,
            y: startPos.y + canvasDelta.y
          };
          mutations.moveNode(otherNodeId, newOtherPosition);
        }
      }
      if (selectedGroups && selectedGroups.length > 0 && lastCanvasDelta) {
        const frameDelta = {
          x: canvasDelta.x - lastCanvasDelta.x,
          y: canvasDelta.y - lastCanvasDelta.y
        };
        for (const group of selectedGroups) {
          group.move(frameDelta.x, frameDelta.y, true);
        }
      }
      lastCanvasDelta = canvasDelta;
    });
  }
  __name(handleDrag, "handleDrag");
  function endDrag(event, nodeId) {
    if (shouldSnap(event) && nodeId) {
      const boundsUpdates = [];
      const currentLayout = toValue(layoutStore.getNodeLayoutRef(nodeId));
      if (currentLayout) {
        const currentPos = currentLayout.position;
        const snappedPos = applySnapToPosition({ ...currentPos });
        if (snappedPos.x !== currentPos.x || snappedPos.y !== currentPos.y) {
          boundsUpdates.push({
            nodeId,
            bounds: {
              x: snappedPos.x,
              y: snappedPos.y,
              width: currentLayout.size.width,
              height: currentLayout.size.height
            }
          });
        }
      }
      if (otherSelectedNodesStartPositions && otherSelectedNodesStartPositions.size > 0) {
        for (const otherNodeId of otherSelectedNodesStartPositions.keys()) {
          const nodeLayout = layoutStore.getNodeLayoutRef(otherNodeId).value;
          if (nodeLayout) {
            const currentPos = { ...nodeLayout.position };
            const snappedPos = applySnapToPosition(currentPos);
            if (snappedPos.x !== currentPos.x || snappedPos.y !== currentPos.y) {
              boundsUpdates.push({
                nodeId: otherNodeId,
                bounds: {
                  x: snappedPos.x,
                  y: snappedPos.y,
                  width: nodeLayout.size.width,
                  height: nodeLayout.size.height
                }
              });
            }
          }
        }
      }
      if (boundsUpdates.length > 0) {
        layoutStore.batchUpdateNodeBounds(boundsUpdates);
      }
    }
    dragStartPos = null;
    dragStartMouse = null;
    otherSelectedNodesStartPositions = null;
    selectedGroups = null;
    lastCanvasDelta = null;
    stopShiftSync?.();
    stopShiftSync = null;
    if (rafId !== null) {
      cancelAnimationFrame(rafId);
      rafId = null;
    }
  }
  __name(endDrag, "endDrag");
  return {
    startDrag,
    handleDrag,
    endDrag
  };
}
__name(useNodeDragIndividual, "useNodeDragIndividual");
function useNodePointerInteractions(nodeIdRef) {
  const { startDrag, endDrag, handleDrag } = useNodeDrag();
  const { forwardEventToCanvas, shouldHandleNodePointerEvents } = useCanvasInteractions();
  const { handleNodeSelect, toggleNodeSelectionAfterPointerUp } = useNodeEventHandlers();
  const { nodeManager } = useVueNodeLifecycle();
  const forwardMiddlePointerIfNeeded = /* @__PURE__ */ __name((event) => {
    if (!isMiddlePointerInput(event)) return false;
    forwardEventToCanvas(event);
    return true;
  }, "forwardMiddlePointerIfNeeded");
  let hasDraggingStarted = false;
  const startPosition = ref({ x: 0, y: 0 });
  const DRAG_THRESHOLD = 3;
  function onPointerdown(event) {
    if (forwardMiddlePointerIfNeeded(event)) return;
    if (event.button !== 0) return;
    if (!shouldHandleNodePointerEvents.value) {
      forwardEventToCanvas(event);
      return;
    }
    const nodeId = toValue(nodeIdRef);
    if (!nodeId) {
      console.warn(
        "LGraphNode: nodeData is null/undefined in handlePointerDown"
      );
      return;
    }
    if (nodeManager.value?.getNode(nodeId)?.flags?.pinned) {
      return;
    }
    startPosition.value = { x: event.clientX, y: event.clientY };
    safeDragStart(event, nodeId);
  }
  __name(onPointerdown, "onPointerdown");
  function onPointermove(event) {
    if (forwardMiddlePointerIfNeeded(event)) return;
    if (layoutStore.isResizingVueNodes.value) return;
    const nodeId = toValue(nodeIdRef);
    if (nodeManager.value?.getNode(nodeId)?.flags?.pinned) {
      return;
    }
    const multiSelect = isMultiSelectKey(event);
    const lmbDown = event.buttons & 1;
    if (lmbDown && multiSelect && !layoutStore.isDraggingVueNodes.value) {
      layoutStore.isDraggingVueNodes.value = true;
      handleNodeSelect(event, nodeId);
      safeDragStart(event, nodeId);
      return;
    }
    if (lmbDown && !layoutStore.isDraggingVueNodes.value) {
      const dx = event.clientX - startPosition.value.x;
      const dy = event.clientY - startPosition.value.y;
      const distance = Math.sqrt(dx * dx + dy * dy);
      if (distance > DRAG_THRESHOLD) {
        layoutStore.isDraggingVueNodes.value = true;
        handleNodeSelect(event, nodeId);
      }
    }
    if (layoutStore.isDraggingVueNodes.value) {
      handleDrag(event, nodeId);
    }
  }
  __name(onPointermove, "onPointermove");
  function cleanupDragState() {
    layoutStore.isDraggingVueNodes.value = false;
  }
  __name(cleanupDragState, "cleanupDragState");
  function safeDragStart(event, nodeId) {
    try {
      startDrag(event, nodeId);
    } finally {
      hasDraggingStarted = true;
    }
  }
  __name(safeDragStart, "safeDragStart");
  function safeDragEnd(event) {
    try {
      const nodeId = toValue(nodeIdRef);
      endDrag(event, nodeId);
    } catch (error) {
      console.error("Error during endDrag:", error);
    } finally {
      hasDraggingStarted = false;
      cleanupDragState();
    }
  }
  __name(safeDragEnd, "safeDragEnd");
  function onPointerup(event) {
    if (forwardMiddlePointerIfNeeded(event)) return;
    const canHandlePointer = shouldHandleNodePointerEvents.value;
    if (!canHandlePointer) {
      forwardEventToCanvas(event);
      return;
    }
    const wasDragging = layoutStore.isDraggingVueNodes.value;
    if (hasDraggingStarted || wasDragging) {
      safeDragEnd(event);
      if (wasDragging) {
        return;
      }
    }
    if (event.button === 2) return;
    const multiSelect = isMultiSelectKey(event);
    const nodeId = toValue(nodeIdRef);
    if (nodeId) {
      toggleNodeSelectionAfterPointerUp(nodeId, multiSelect);
    }
  }
  __name(onPointerup, "onPointerup");
  function onPointercancel(event) {
    if (!layoutStore.isDraggingVueNodes.value) return;
    safeDragEnd(event);
  }
  __name(onPointercancel, "onPointercancel");
  function onContextmenu(event) {
    if (!layoutStore.isDraggingVueNodes.value) return;
    event.preventDefault();
    cleanupDragState();
  }
  __name(onContextmenu, "onContextmenu");
  onScopeDispose(() => {
    cleanupDragState();
  });
  const pointerHandlers = {
    onPointerdown,
    onPointermove,
    onPointerup,
    onPointercancel,
    onContextmenu
  };
  return {
    pointerHandlers
  };
}
__name(useNodePointerInteractions, "useNodePointerInteractions");
const trackingConfigs = /* @__PURE__ */ new Map([
  [
    "node",
    {
      dataAttribute: "nodeId",
      updateHandler: /* @__PURE__ */ __name((updates) => {
        const nodeUpdates = updates.map(({ id, bounds }) => ({
          nodeId: id,
          bounds
        }));
        layoutStore.batchUpdateNodeBounds(nodeUpdates);
      }, "updateHandler")
    }
  ]
]);
const resizeObserver = new ResizeObserver((entries) => {
  if (useCanvasStore().linearMode) return;
  const conv = useSharedCanvasPositionConversion();
  const updatesByType = /* @__PURE__ */ new Map();
  const nodesNeedingSlotResync = /* @__PURE__ */ new Set();
  for (const entry of entries) {
    if (!(entry.target instanceof HTMLElement)) continue;
    const element = entry.target;
    let elementType;
    let elementId;
    for (const [type, config2] of trackingConfigs) {
      const id = element.dataset[config2.dataAttribute];
      if (id) {
        elementType = type;
        elementId = id;
        break;
      }
    }
    if (!elementType || !elementId) continue;
    const borderBox = Array.isArray(entry.borderBoxSize) ? entry.borderBoxSize[0] : {
      inlineSize: entry.contentRect.width,
      blockSize: entry.contentRect.height
    };
    const width = borderBox.inlineSize;
    const height = borderBox.blockSize;
    const rect = element.getBoundingClientRect();
    const [cx, cy] = conv.clientPosToCanvasPos([rect.left, rect.top]);
    const topLeftCanvas = { x: cx, y: cy };
    const bounds = {
      x: topLeftCanvas.x,
      y: topLeftCanvas.y + LiteGraph.NODE_TITLE_HEIGHT,
      width: Math.max(0, width),
      height: Math.max(0, height)
    };
    let updates = updatesByType.get(elementType);
    if (!updates) {
      updates = [];
      updatesByType.set(elementType, updates);
    }
    updates.push({ id: elementId, bounds });
    if (elementType === "node" && elementId) {
      nodesNeedingSlotResync.add(elementId);
    }
  }
  layoutStore.setSource(LayoutSource.DOM);
  for (const [type, updates] of updatesByType) {
    const config2 = trackingConfigs.get(type);
    if (config2 && updates.length) config2.updateHandler(updates);
  }
  if (nodesNeedingSlotResync.size > 0) {
    for (const nodeId of nodesNeedingSlotResync) {
      syncNodeSlotLayoutsFromDOM(nodeId);
    }
  }
});
function useVueElementTracking(appIdentifierMaybe, trackingType) {
  const appIdentifier = toValue(appIdentifierMaybe);
  onMounted(() => {
    const element = getCurrentInstance()?.proxy?.$el;
    if (!(element instanceof HTMLElement) || !appIdentifier) return;
    const config2 = trackingConfigs.get(trackingType);
    if (!config2) return;
    element.dataset[config2.dataAttribute] = appIdentifier;
    resizeObserver.observe(element);
  });
  onUnmounted(() => {
    const element = getCurrentInstance()?.proxy?.$el;
    if (!(element instanceof HTMLElement)) return;
    const config2 = trackingConfigs.get(trackingType);
    if (!config2) return;
    delete element.dataset[config2.dataAttribute];
    resizeObserver.unobserve(element);
  });
}
__name(useVueElementTracking, "useVueElementTracking");
const useNodeExecutionState = /* @__PURE__ */ __name((nodeLocatorIdMaybe) => {
  const locatorId = computed(() => toValue(nodeLocatorIdMaybe) ?? "");
  const { nodeLocationProgressStates, isIdle } = storeToRefs(useExecutionStore());
  const progressState = computed(() => {
    const id = locatorId.value;
    return id ? nodeLocationProgressStates.value[id] : void 0;
  });
  const executing = computed(
    () => !isIdle.value && progressState.value?.state === "running"
  );
  const progress = computed(() => {
    const state = progressState.value;
    return state && state.max > 0 ? state.value / state.max : void 0;
  });
  const progressPercentage = computed(() => {
    const prog = progress.value;
    return prog !== void 0 ? Math.round(prog * 100) : void 0;
  });
  const executionState = computed(() => {
    const state = progressState.value;
    if (!state) return "idle";
    return state.state;
  });
  return {
    executing,
    progress,
    progressPercentage,
    progressState,
    executionState
  };
}, "useNodeExecutionState");
function useNodeLayout(nodeIdMaybe) {
  const nodeId = toValue(nodeIdMaybe);
  const mutations = useLayoutMutations();
  const layoutRef = layoutStore.getNodeLayoutRef(nodeId);
  onUnmounted(() => {
    layoutStore.cleanupNodeRef(nodeId);
  });
  const position = computed(() => {
    const layout = layoutRef.value;
    const pos = layout?.position ?? { x: 0, y: 0 };
    return pos;
  });
  const size = computed(
    () => layoutRef.value?.size ?? { width: 200, height: 100 }
  );
  const zIndex = computed(() => layoutRef.value?.zIndex ?? 0);
  function moveNodeTo(position2) {
    mutations.setSource(LayoutSource.Vue);
    mutations.moveNode(nodeId, position2);
  }
  __name(moveNodeTo, "moveNodeTo");
  return {
    // Reactive state (via customRef)
    position,
    size,
    zIndex,
    // Mutations
    moveNodeTo
  };
}
__name(useNodeLayout, "useNodeLayout");
const useNodePreviewState = /* @__PURE__ */ __name((nodeIdMaybe, options) => {
  const nodeId = toValue(nodeIdMaybe);
  const workflowStore = useWorkflowStore();
  const { nodePreviewImages } = storeToRefs(useNodeOutputStore());
  const locatorId = computed(() => workflowStore.nodeIdToNodeLocatorId(nodeId));
  const previewUrls = computed(() => {
    const key = locatorId.value;
    if (!key) return void 0;
    const urls = nodePreviewImages.value[key];
    return urls?.length ? urls : void 0;
  });
  const hasPreview = computed(() => !!previewUrls.value?.length);
  const latestPreviewUrl = computed(() => {
    const urls = previewUrls.value;
    return urls?.length ? urls.at(-1) : "";
  });
  const shouldShowPreviewImg = computed(() => {
    if (!options?.isCollapsed) {
      return hasPreview.value;
    }
    return !options.isCollapsed.value && hasPreview.value;
  });
  return {
    locatorId,
    previewUrls,
    hasPreview,
    latestPreviewUrl,
    shouldShowPreviewImg
  };
}, "useNodePreviewState");
function useNodeResize(resizeCallback) {
  const transformState = useTransformState();
  const isResizing = ref(false);
  const resizeStartPointer = ref(null);
  const resizeStartSize = ref(null);
  const { shouldSnap, applySnapToSize } = useNodeSnap();
  const { trackShiftKey } = useShiftKeySync();
  const startResize = /* @__PURE__ */ __name((event) => {
    event.preventDefault();
    event.stopPropagation();
    const target = event.currentTarget;
    if (!(target instanceof HTMLElement)) return;
    const nodeElement = target.closest("[data-node-id]");
    if (!(nodeElement instanceof HTMLElement)) return;
    const rect = nodeElement.getBoundingClientRect();
    const scale = transformState.camera.z;
    const startSize = {
      width: rect.width / scale,
      height: rect.height / scale
    };
    const stopShiftSync = trackShiftKey(event);
    target.setPointerCapture(event.pointerId);
    layoutStore.isResizingVueNodes.value = true;
    isResizing.value = true;
    resizeStartPointer.value = { x: event.clientX, y: event.clientY };
    resizeStartSize.value = startSize;
    const handlePointerMove = /* @__PURE__ */ __name((moveEvent) => {
      if (!isResizing.value || !resizeStartPointer.value || !resizeStartSize.value) {
        return;
      }
      const scale2 = transformState.camera.z;
      const deltaX = (moveEvent.clientX - resizeStartPointer.value.x) / (scale2 || 1);
      const deltaY = (moveEvent.clientY - resizeStartPointer.value.y) / (scale2 || 1);
      let newSize = {
        width: resizeStartSize.value.width + deltaX,
        height: resizeStartSize.value.height + deltaY
      };
      if (shouldSnap(moveEvent)) {
        newSize = applySnapToSize(newSize);
      }
      const nodeElement2 = target.closest("[data-node-id]");
      if (nodeElement2 instanceof HTMLElement) {
        resizeCallback({ size: newSize }, nodeElement2);
      }
    }, "handlePointerMove");
    const handlePointerUp = /* @__PURE__ */ __name((upEvent) => {
      if (isResizing.value) {
        isResizing.value = false;
        layoutStore.isResizingVueNodes.value = false;
        resizeStartPointer.value = null;
        resizeStartSize.value = null;
        stopShiftSync();
        target.releasePointerCapture(upEvent.pointerId);
        stopMoveListen();
        stopUpListen();
      }
    }, "handlePointerUp");
    const stopMoveListen = useEventListener("pointermove", handlePointerMove);
    const stopUpListen = useEventListener("pointerup", handlePointerUp);
  }, "startResize");
  return {
    startResize,
    isResizing
  };
}
__name(useNodeResize, "useNodeResize");
const _hoisted_1$c = {
  viewBox: "0 0 24 24",
  width: "1.2em",
  height: "1.2em"
};
function render$1(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1$c, [..._cache[0] || (_cache[0] = [
    createBaseVNode("g", {
      fill: "none",
      stroke: "currentColor",
      "stroke-linecap": "round",
      "stroke-linejoin": "round",
      "stroke-width": "2"
    }, [
      createBaseVNode("path", { d: "m2 2l20 20M10.41 10.41a2 2 0 1 1-2.83-2.83m5.92 5.92L6 21m12-9l3 3" }),
      createBaseVNode("path", { d: "M3.59 3.59A2 2 0 0 0 3 5v14a2 2 0 0 0 2 2h14c.55 0 1.052-.22 1.41-.59M21 15V5a2 2 0 0 0-2-2H9" })
    ], -1)
  ])]);
}
__name(render$1, "render$1");
const __unplugin_components_0$1 = markRaw({ name: "lucide-image-off", render: render$1 });
const _hoisted_1$b = {
  key: 0,
  class: "flex h-full min-h-16 w-full min-w-16 flex-col"
};
const _hoisted_2$9 = { class: "relative h-88 w-full grow overflow-hidden rounded-[5px] bg-node-component-surface" };
const _hoisted_3$7 = {
  key: 0,
  class: "text-pure-white flex h-full w-full flex-col items-center justify-center text-center"
};
const _hoisted_4$5 = { class: "text-xs text-smoke-400" };
const _hoisted_5$4 = ["src", "alt"];
const _hoisted_6$4 = { class: "text-node-component-header-text mt-1 text-center text-xs" };
const _sfc_main$b = /* @__PURE__ */ defineComponent({
  __name: "LivePreview",
  props: {
    imageUrl: {}
  },
  setup(__props) {
    const props = __props;
    const actualDimensions = ref(null);
    const imageError = ref(false);
    watch(
      () => props.imageUrl,
      () => {
        actualDimensions.value = null;
        imageError.value = false;
      }
    );
    const handleImageLoad = /* @__PURE__ */ __name((event) => {
      if (!event.target || !(event.target instanceof HTMLImageElement)) return;
      const img = event.target;
      imageError.value = false;
      if (img.naturalWidth && img.naturalHeight) {
        actualDimensions.value = `${img.naturalWidth} x ${img.naturalHeight}`;
      }
    }, "handleImageLoad");
    const handleImageError = /* @__PURE__ */ __name(() => {
      imageError.value = true;
      actualDimensions.value = null;
    }, "handleImageError");
    return (_ctx, _cache) => {
      const _component_i_lucide58image_off = __unplugin_components_0$1;
      return _ctx.imageUrl ? (openBlock(), createElementBlock("div", _hoisted_1$b, [
        createBaseVNode("div", _hoisted_2$9, [
          imageError.value ? (openBlock(), createElementBlock("div", _hoisted_3$7, [
            createVNode(_component_i_lucide58image_off, { class: "mb-1 size-8 text-smoke-500" }),
            createBaseVNode("p", _hoisted_4$5, toDisplayString(_ctx.$t("g.imageFailedToLoad")), 1)
          ])) : (openBlock(), createElementBlock("img", {
            key: 1,
            src: _ctx.imageUrl,
            alt: _ctx.$t("g.liveSamplingPreview"),
            class: "pointer-events-none h-full w-full object-contain object-center",
            onLoad: handleImageLoad,
            onError: handleImageError
          }, null, 40, _hoisted_5$4))
        ]),
        createBaseVNode("div", _hoisted_6$4, toDisplayString(imageError.value ? _ctx.$t("g.errorLoadingImage") : actualDimensions.value || _ctx.$t("g.calculatingDimensions")), 1)
      ])) : createCommentVNode("", true);
    };
  }
});
const _hoisted_1$a = ["aria-label", "aria-busy"];
const _hoisted_2$8 = {
  key: 0,
  class: "flex size-full flex-col items-center justify-center bg-smoke-800/50 text-center text-white py-8"
};
const _hoisted_3$6 = { class: "text-sm text-smoke-300" };
const _hoisted_4$4 = { class: "mt-1 text-xs text-smoke-400" };
const _hoisted_5$3 = ["src"];
const _hoisted_6$3 = {
  key: 3,
  class: "actions absolute top-2 right-2 flex gap-2.5"
};
const _hoisted_7$3 = ["title", "aria-label"];
const _hoisted_8$3 = ["title", "aria-label"];
const _hoisted_9$2 = {
  key: 4,
  class: "absolute right-2 bottom-2 left-2 flex justify-center gap-1"
};
const _hoisted_10$2 = ["aria-label", "onClick"];
const _hoisted_11$1 = { class: "mt-2 text-center text-xs text-muted-foreground" };
const _hoisted_12$1 = {
  key: 0,
  class: "text-red-400"
};
const _hoisted_13$1 = {
  key: 1,
  class: "text-smoke-400"
};
const _hoisted_14$1 = { key: 2 };
const actionButtonClass$1 = "flex h-8 min-h-8 items-center justify-center gap-2.5 rounded-lg border-0 bg-button-surface px-2 py-2 text-button-surface-contrast shadow-sm transition-colors duration-200 hover:bg-button-hover-surface focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-button-surface-contrast focus-visible:ring-offset-2 focus-visible:ring-offset-transparent cursor-pointer";
const _sfc_main$a = /* @__PURE__ */ defineComponent({
  __name: "VideoPreview",
  props: {
    imageUrls: {},
    nodeId: {}
  },
  setup(__props) {
    const props = __props;
    const { t: t2 } = useI18n();
    const nodeOutputStore = useNodeOutputStore();
    const currentIndex = ref(0);
    const isHovered = ref(false);
    const isFocused = ref(false);
    const actualDimensions = ref(null);
    const videoError = ref(false);
    const showLoader = ref(false);
    const videoWrapperEl = ref();
    const currentVideoUrl = computed(() => props.imageUrls[currentIndex.value]);
    const hasMultipleVideos = computed(() => props.imageUrls.length > 1);
    watch(
      () => props.imageUrls,
      (newUrls) => {
        if (currentIndex.value >= newUrls.length) {
          currentIndex.value = 0;
        }
        actualDimensions.value = null;
        videoError.value = false;
        showLoader.value = newUrls.length > 0;
      },
      { deep: true, immediate: true }
    );
    const handleVideoLoad = /* @__PURE__ */ __name((event) => {
      if (!event.target || !(event.target instanceof HTMLVideoElement)) return;
      const video = event.target;
      showLoader.value = false;
      videoError.value = false;
      if (video.videoWidth && video.videoHeight) {
        actualDimensions.value = `${video.videoWidth} x ${video.videoHeight}`;
      }
    }, "handleVideoLoad");
    const handleVideoError = /* @__PURE__ */ __name(() => {
      showLoader.value = false;
      videoError.value = true;
      actualDimensions.value = null;
    }, "handleVideoError");
    const handleDownload = /* @__PURE__ */ __name(() => {
      try {
        downloadFile(currentVideoUrl.value);
      } catch (error) {
        useToast().add({
          severity: "error",
          summary: "Error",
          detail: t2("g.failedToDownloadVideo"),
          life: 3e3,
          group: "video-preview"
        });
      }
    }, "handleDownload");
    const handleRemove = /* @__PURE__ */ __name(() => {
      if (!props.nodeId) return;
      nodeOutputStore.removeNodeOutputs(props.nodeId);
    }, "handleRemove");
    const setCurrentIndex = /* @__PURE__ */ __name((index) => {
      if (index >= 0 && index < props.imageUrls.length) {
        currentIndex.value = index;
        actualDimensions.value = null;
        showLoader.value = true;
        videoError.value = false;
      }
    }, "setCurrentIndex");
    const handleMouseEnter = /* @__PURE__ */ __name(() => {
      isHovered.value = true;
    }, "handleMouseEnter");
    const handleMouseLeave = /* @__PURE__ */ __name(() => {
      isHovered.value = false;
    }, "handleMouseLeave");
    const handleFocusIn = /* @__PURE__ */ __name(() => {
      isFocused.value = true;
    }, "handleFocusIn");
    const handleFocusOut = /* @__PURE__ */ __name((event) => {
      if (!videoWrapperEl.value?.contains(event.relatedTarget)) {
        isFocused.value = false;
      }
    }, "handleFocusOut");
    const getNavigationDotClass = /* @__PURE__ */ __name((index) => {
      return [
        "w-2 h-2 rounded-full transition-all duration-200 border-0 cursor-pointer",
        index === currentIndex.value ? "bg-white" : "bg-white/50 hover:bg-white/80"
      ];
    }, "getNavigationDotClass");
    const handleKeyDown = /* @__PURE__ */ __name((event) => {
      if (props.imageUrls.length <= 1) return;
      switch (event.key) {
        case "ArrowLeft":
          event.preventDefault();
          setCurrentIndex(
            currentIndex.value > 0 ? currentIndex.value - 1 : props.imageUrls.length - 1
          );
          break;
        case "ArrowRight":
          event.preventDefault();
          setCurrentIndex(
            currentIndex.value < props.imageUrls.length - 1 ? currentIndex.value + 1 : 0
          );
          break;
        case "Home":
          event.preventDefault();
          setCurrentIndex(0);
          break;
        case "End":
          event.preventDefault();
          setCurrentIndex(props.imageUrls.length - 1);
          break;
      }
    }, "handleKeyDown");
    const getVideoFilename = /* @__PURE__ */ __name((url) => {
      try {
        return new URL(url).searchParams.get("filename") || "Unknown file";
      } catch {
        return "Invalid URL";
      }
    }, "getVideoFilename");
    return (_ctx, _cache) => {
      return _ctx.imageUrls.length > 0 ? (openBlock(), createElementBlock("div", {
        key: 0,
        class: "video-preview group relative flex size-full min-h-16 min-w-16 flex-col px-2",
        onKeydown: handleKeyDown
      }, [
        createBaseVNode("div", {
          ref_key: "videoWrapperEl",
          ref: videoWrapperEl,
          class: "relative h-full w-full grow overflow-hidden rounded-[5px] bg-node-component-surface",
          tabindex: "0",
          role: "region",
          "aria-label": _ctx.$t("g.videoPreview"),
          "aria-busy": showLoader.value,
          onMouseenter: handleMouseEnter,
          onMouseleave: handleMouseLeave,
          onFocusin: handleFocusIn,
          onFocusout: handleFocusOut
        }, [
          videoError.value ? (openBlock(), createElementBlock("div", _hoisted_2$8, [
            _cache[0] || (_cache[0] = createBaseVNode("i", { class: "mb-2 icon-[lucide--video-off] h-12 w-12 text-smoke-400" }, null, -1)),
            createBaseVNode("p", _hoisted_3$6, toDisplayString(_ctx.$t("g.videoFailedToLoad")), 1),
            createBaseVNode("p", _hoisted_4$4, toDisplayString(getVideoFilename(currentVideoUrl.value)), 1)
          ])) : createCommentVNode("", true),
          showLoader.value && !videoError.value ? (openBlock(), createBlock(unref(script$a), {
            key: 1,
            class: "absolute inset-0 size-full",
            "border-radius": "5px",
            width: "100%",
            height: "100%"
          })) : createCommentVNode("", true),
          !videoError.value ? (openBlock(), createElementBlock("video", {
            key: 2,
            src: currentVideoUrl.value,
            class: normalizeClass(unref(cn)("block size-full object-contain", showLoader.value && "invisible")),
            controls: "",
            loop: "",
            playsinline: "",
            onLoadeddata: handleVideoLoad,
            onError: handleVideoError
          }, null, 42, _hoisted_5$3)) : createCommentVNode("", true),
          isHovered.value || isFocused.value ? (openBlock(), createElementBlock("div", _hoisted_6$3, [
            createBaseVNode("button", {
              class: normalizeClass(actionButtonClass$1),
              title: _ctx.$t("g.downloadVideo"),
              "aria-label": _ctx.$t("g.downloadVideo"),
              onClick: handleDownload
            }, _cache[1] || (_cache[1] = [
              createBaseVNode("i", { class: "icon-[lucide--download] h-4 w-4" }, null, -1)
            ]), 8, _hoisted_7$3),
            createBaseVNode("button", {
              class: normalizeClass(actionButtonClass$1),
              title: _ctx.$t("g.removeVideo"),
              "aria-label": _ctx.$t("g.removeVideo"),
              onClick: handleRemove
            }, _cache[2] || (_cache[2] = [
              createBaseVNode("i", { class: "icon-[lucide--x] h-4 w-4" }, null, -1)
            ]), 8, _hoisted_8$3)
          ])) : createCommentVNode("", true),
          hasMultipleVideos.value ? (openBlock(), createElementBlock("div", _hoisted_9$2, [
            (openBlock(true), createElementBlock(Fragment, null, renderList(_ctx.imageUrls, (_, index) => {
              return openBlock(), createElementBlock("button", {
                key: index,
                class: normalizeClass(getNavigationDotClass(index)),
                "aria-label": _ctx.$t("g.viewVideoOfTotal", {
                  index: index + 1,
                  total: _ctx.imageUrls.length
                }),
                onClick: /* @__PURE__ */ __name(($event) => setCurrentIndex(index), "onClick")
              }, null, 10, _hoisted_10$2);
            }), 128))
          ])) : createCommentVNode("", true)
        ], 40, _hoisted_1$a),
        createBaseVNode("div", _hoisted_11$1, [
          videoError.value ? (openBlock(), createElementBlock("span", _hoisted_12$1, toDisplayString(_ctx.$t("g.errorLoadingVideo")), 1)) : showLoader.value ? (openBlock(), createElementBlock("span", _hoisted_13$1, toDisplayString(_ctx.$t("g.loading")) + "... ", 1)) : (openBlock(), createElementBlock("span", _hoisted_14$1, toDisplayString(actualDimensions.value || _ctx.$t("g.calculatingDimensions")), 1))
        ])
      ], 32)) : createCommentVNode("", true);
    };
  }
});
const _hoisted_1$9 = {
  width: "1.2em",
  height: "1.2em",
  xmlns: "http://www.w3.org/2000/svg",
  class: "",
  viewBox: "0 0 16 16",
  fill: "none"
};
const _hoisted_2$7 = ["clip-path"];
const _hoisted_3$5 = ["id"];
function render(_ctx, _cache) {
  return openBlock(), createElementBlock("svg", _hoisted_1$9, [
    createBaseVNode("g", {
      "clip-path": "url(#" + _ctx.idMap["clip0_704_2695"] + ")"
    }, [..._cache[0] || (_cache[0] = [
      createStaticVNode('<path d="M6.05048 2C5.52055 7.29512 9.23033 10.4722 14 9.94267" stroke="currentColor" stroke-width="1.3"></path><path d="M6.5 5.5L10 2" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"></path><path d="M8 8L12.5 3.5" stroke="currentColor" stroke-width="1.3" stroke-linecap="square"></path><path d="M10.5 9.5L14 6" stroke="currentColor" stroke-width="1.3" stroke-linecap="round"></path><path d="M7.99992 14.6667C11.6818 14.6667 14.6666 11.6819 14.6666 8.00004C14.6666 4.31814 11.6818 1.33337 7.99992 1.33337C4.31802 1.33337 1.33325 4.31814 1.33325 8.00004C1.33325 11.6819 4.31802 14.6667 7.99992 14.6667Z" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"></path>', 5)
    ])], 8, _hoisted_2$7),
    createBaseVNode("defs", null, [
      createBaseVNode("clipPath", {
        id: _ctx.idMap["clip0_704_2695"]
      }, [..._cache[1] || (_cache[1] = [
        createBaseVNode("rect", {
          width: "16",
          height: "16",
          fill: "white"
        }, null, -1)
      ])], 8, _hoisted_3$5)
    ])
  ]);
}
__name(render, "render");
const __unplugin_components_0 = markRaw({ name: "comfy-mask", render, setup() {
  const __randId = /* @__PURE__ */ __name(() => Math.random().toString(36).substr(2, 10), "__randId");
  const idMap = { "clip0_704_2695": "uicons-" + __randId() };
  return { idMap };
} });
const _hoisted_1$8 = ["aria-label", "aria-busy"];
const _hoisted_2$6 = {
  key: 0,
  role: "alert",
  class: "flex size-full flex-col items-center justify-center bg-muted-background text-center text-base-foreground py-8"
};
const _hoisted_3$4 = { class: "text-sm text-base-foreground" };
const _hoisted_4$3 = { class: "mt-1 text-xs text-base-foreground" };
const _hoisted_5$2 = {
  key: 1,
  class: "size-full"
};
const _hoisted_6$2 = ["src", "alt"];
const _hoisted_7$2 = {
  key: 3,
  class: "actions absolute top-2 right-2 flex gap-2.5"
};
const _hoisted_8$2 = ["title", "aria-label"];
const _hoisted_9$1 = ["title", "aria-label"];
const _hoisted_10$1 = ["title", "aria-label"];
const _hoisted_11 = { class: "pt-2 text-center text-xs text-base-foreground" };
const _hoisted_12 = {
  key: 0,
  class: "text-red-400"
};
const _hoisted_13 = {
  key: 1,
  class: "text-base-foreground"
};
const _hoisted_14 = { key: 2 };
const _hoisted_15 = {
  key: 0,
  class: "flex justify-center gap-1 pt-4"
};
const _hoisted_16 = ["aria-current", "aria-label", "onClick"];
const actionButtonClass = "flex h-8 min-h-8 items-center justify-center gap-2.5 rounded-lg border-0 bg-button-surface px-2 py-2 text-button-surface-contrast shadow-sm transition-colors duration-200 hover:bg-button-hover-surface focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-button-surface-contrast focus-visible:ring-offset-2 focus-visible:ring-offset-transparent cursor-pointer";
const _sfc_main$9 = /* @__PURE__ */ defineComponent({
  __name: "ImagePreview",
  props: {
    imageUrls: {},
    nodeId: {}
  },
  setup(__props) {
    const props = __props;
    const { t: t2 } = useI18n();
    const commandStore = useCommandStore();
    const nodeOutputStore = useNodeOutputStore();
    const currentIndex = ref(0);
    const isHovered = ref(false);
    const isFocused = ref(false);
    const actualDimensions = ref(null);
    const imageError = ref(false);
    const showLoader = ref(false);
    const currentImageEl = ref();
    const imageWrapperEl = ref();
    const { start: startDelayedLoader, stop: stopDelayedLoader } = useTimeoutFn(
      () => {
        showLoader.value = true;
      },
      250,
      // Make sure it doesnt run on component mount
      { immediate: false }
    );
    const currentImageUrl = computed(() => props.imageUrls[currentIndex.value]);
    const hasMultipleImages = computed(() => props.imageUrls.length > 1);
    const imageAltText = computed(() => `Node output ${currentIndex.value + 1}`);
    watch(
      () => props.imageUrls,
      (newUrls) => {
        if (currentIndex.value >= newUrls.length) {
          currentIndex.value = 0;
        }
        actualDimensions.value = null;
        imageError.value = false;
        if (newUrls.length > 0) startDelayedLoader();
      },
      { deep: true, immediate: true }
    );
    const handleImageLoad = /* @__PURE__ */ __name((event) => {
      if (!event.target || !(event.target instanceof HTMLImageElement)) return;
      const img = event.target;
      stopDelayedLoader();
      showLoader.value = false;
      imageError.value = false;
      if (img.naturalWidth && img.naturalHeight) {
        actualDimensions.value = `${img.naturalWidth} x ${img.naturalHeight}`;
      }
    }, "handleImageLoad");
    const handleImageError = /* @__PURE__ */ __name(() => {
      stopDelayedLoader();
      showLoader.value = false;
      imageError.value = true;
      actualDimensions.value = null;
    }, "handleImageError");
    const setupNodeForMaskEditor = /* @__PURE__ */ __name(() => {
      if (!props.nodeId || !currentImageEl.value) return;
      const node = app.rootGraph?.getNodeById(props.nodeId);
      if (!node) return;
      node.imageIndex = currentIndex.value;
      node.imgs = [currentImageEl.value];
      app.canvas?.select(node);
    }, "setupNodeForMaskEditor");
    const handleEditMask = /* @__PURE__ */ __name(() => {
      setupNodeForMaskEditor();
      void commandStore.execute("Comfy.MaskEditor.OpenMaskEditor");
    }, "handleEditMask");
    const handleDownload = /* @__PURE__ */ __name(() => {
      try {
        downloadFile(currentImageUrl.value);
      } catch (error) {
        useToast().add({
          severity: "error",
          summary: "Error",
          detail: t2("g.failedToDownloadImage"),
          life: 3e3,
          group: "image-preview"
        });
      }
    }, "handleDownload");
    const handleRemove = /* @__PURE__ */ __name(() => {
      if (!props.nodeId) return;
      nodeOutputStore.removeNodeOutputs(props.nodeId);
    }, "handleRemove");
    const setCurrentIndex = /* @__PURE__ */ __name((index) => {
      if (currentIndex.value === index) return;
      if (index >= 0 && index < props.imageUrls.length) {
        currentIndex.value = index;
        startDelayedLoader();
        imageError.value = false;
      }
    }, "setCurrentIndex");
    const handleMouseEnter = /* @__PURE__ */ __name(() => {
      isHovered.value = true;
    }, "handleMouseEnter");
    const handleMouseLeave = /* @__PURE__ */ __name(() => {
      isHovered.value = false;
    }, "handleMouseLeave");
    const handleFocusIn = /* @__PURE__ */ __name(() => {
      isFocused.value = true;
    }, "handleFocusIn");
    const handleFocusOut = /* @__PURE__ */ __name((event) => {
      if (!imageWrapperEl.value?.contains(event.relatedTarget)) {
        isFocused.value = false;
      }
    }, "handleFocusOut");
    const getNavigationDotClass = /* @__PURE__ */ __name((index) => {
      return [
        "w-2 h-2 rounded-full transition-all duration-200 border-0 cursor-pointer p-0",
        index === currentIndex.value ? "bg-base-foreground" : "bg-base-foreground/50 hover:bg-base-foreground/80"
      ];
    }, "getNavigationDotClass");
    const handleKeyDown = /* @__PURE__ */ __name((event) => {
      if (props.imageUrls.length <= 1) return;
      switch (event.key) {
        case "ArrowLeft":
          event.preventDefault();
          setCurrentIndex(
            currentIndex.value > 0 ? currentIndex.value - 1 : props.imageUrls.length - 1
          );
          break;
        case "ArrowRight":
          event.preventDefault();
          setCurrentIndex(
            currentIndex.value < props.imageUrls.length - 1 ? currentIndex.value + 1 : 0
          );
          break;
        case "Home":
          event.preventDefault();
          setCurrentIndex(0);
          break;
        case "End":
          event.preventDefault();
          setCurrentIndex(props.imageUrls.length - 1);
          break;
      }
    }, "handleKeyDown");
    const getImageFilename = /* @__PURE__ */ __name((url) => {
      try {
        return new URL(url).searchParams.get("filename") || "Unknown file";
      } catch {
        return "Invalid URL";
      }
    }, "getImageFilename");
    return (_ctx, _cache) => {
      const _component_i_comfy58mask = __unplugin_components_0;
      return _ctx.imageUrls.length > 0 ? (openBlock(), createElementBlock("div", {
        key: 0,
        class: "image-preview group relative flex size-full min-h-16 min-w-16 flex-col px-2 justify-center",
        onKeydown: handleKeyDown
      }, [
        createBaseVNode("div", {
          ref_key: "imageWrapperEl",
          ref: imageWrapperEl,
          class: "h-full w-full overflow-hidden rounded-[5px] bg-muted-background relative",
          tabindex: "0",
          role: "img",
          "aria-label": _ctx.$t("g.imagePreview"),
          "aria-busy": showLoader.value,
          onMouseenter: handleMouseEnter,
          onMouseleave: handleMouseLeave,
          onFocusin: handleFocusIn,
          onFocusout: handleFocusOut
        }, [
          imageError.value ? (openBlock(), createElementBlock("div", _hoisted_2$6, [
            _cache[0] || (_cache[0] = createBaseVNode("i", { class: "mb-2 icon-[lucide--image-off] h-12 w-12 text-base-foreground" }, null, -1)),
            createBaseVNode("p", _hoisted_3$4, toDisplayString(_ctx.$t("g.imageFailedToLoad")), 1),
            createBaseVNode("p", _hoisted_4$3, toDisplayString(getImageFilename(currentImageUrl.value)), 1)
          ])) : createCommentVNode("", true),
          showLoader.value && !imageError.value ? (openBlock(), createElementBlock("div", _hoisted_5$2, [
            createVNode(unref(script$a), {
              "border-radius": "5px",
              width: "100%",
              height: "100%"
            })
          ])) : createCommentVNode("", true),
          !imageError.value ? (openBlock(), createElementBlock("img", {
            key: 2,
            ref_key: "currentImageEl",
            ref: currentImageEl,
            src: currentImageUrl.value,
            alt: imageAltText.value,
            class: "block size-full object-contain pointer-events-none",
            onLoad: handleImageLoad,
            onError: handleImageError
          }, null, 40, _hoisted_6$2)) : createCommentVNode("", true),
          isHovered.value || isFocused.value ? (openBlock(), createElementBlock("div", _hoisted_7$2, [
            !hasMultipleImages.value ? (openBlock(), createElementBlock("button", {
              key: 0,
              class: normalizeClass(actionButtonClass),
              title: _ctx.$t("g.editOrMaskImage"),
              "aria-label": _ctx.$t("g.editOrMaskImage"),
              onClick: handleEditMask
            }, [
              createVNode(_component_i_comfy58mask, { class: "h-4 w-4" })
            ], 8, _hoisted_8$2)) : createCommentVNode("", true),
            createBaseVNode("button", {
              class: normalizeClass(actionButtonClass),
              title: _ctx.$t("g.downloadImage"),
              "aria-label": _ctx.$t("g.downloadImage"),
              onClick: handleDownload
            }, _cache[1] || (_cache[1] = [
              createBaseVNode("i", { class: "icon-[lucide--download] h-4 w-4" }, null, -1)
            ]), 8, _hoisted_9$1),
            createBaseVNode("button", {
              class: normalizeClass(actionButtonClass),
              title: _ctx.$t("g.removeImage"),
              "aria-label": _ctx.$t("g.removeImage"),
              onClick: handleRemove
            }, _cache[2] || (_cache[2] = [
              createBaseVNode("i", { class: "icon-[lucide--x] h-4 w-4" }, null, -1)
            ]), 8, _hoisted_10$1)
          ])) : createCommentVNode("", true)
        ], 40, _hoisted_1$8),
        createBaseVNode("div", _hoisted_11, [
          imageError.value ? (openBlock(), createElementBlock("span", _hoisted_12, toDisplayString(_ctx.$t("g.errorLoadingImage")), 1)) : showLoader.value ? (openBlock(), createElementBlock("span", _hoisted_13, toDisplayString(_ctx.$t("g.loading")) + "... ", 1)) : (openBlock(), createElementBlock("span", _hoisted_14, toDisplayString(actualDimensions.value || _ctx.$t("g.calculatingDimensions")), 1))
        ]),
        hasMultipleImages.value ? (openBlock(), createElementBlock("div", _hoisted_15, [
          (openBlock(true), createElementBlock(Fragment, null, renderList(_ctx.imageUrls, (_, index) => {
            return openBlock(), createElementBlock("button", {
              key: index,
              class: normalizeClass(getNavigationDotClass(index)),
              "aria-current": index === currentIndex.value ? "true" : void 0,
              "aria-label": _ctx.$t("g.viewImageOfTotal", {
                index: index + 1,
                total: _ctx.imageUrls.length
              }),
              onClick: /* @__PURE__ */ __name(($event) => setCurrentIndex(index), "onClick")
            }, null, 10, _hoisted_16);
          }), 128))
        ])) : createCommentVNode("", true)
      ], 32)) : createCommentVNode("", true);
    };
  }
});
const _hoisted_1$7 = {
  key: 0,
  class: "node-error p-2 text-sm text-red-500"
};
const _hoisted_2$5 = {
  key: 1,
  class: "lg-node-content flex grow flex-col"
};
const _sfc_main$8 = /* @__PURE__ */ defineComponent({
  __name: "NodeContent",
  props: {
    nodeData: {},
    media: {}
  },
  setup(__props) {
    const props = __props;
    const hasMedia = computed(() => props.media && props.media.urls.length > 0);
    const nodeId = computed(() => props.nodeData?.id?.toString());
    const renderError = ref(null);
    const { toastErrorHandler } = useErrorHandling();
    onErrorCaptured((error) => {
      renderError.value = error.message;
      toastErrorHandler(error);
      return false;
    });
    return (_ctx, _cache) => {
      return renderError.value ? (openBlock(), createElementBlock("div", _hoisted_1$7, toDisplayString(unref(st)("nodeErrors.content", "Node Content Error")), 1)) : (openBlock(), createElementBlock("div", _hoisted_2$5, [
        renderSlot(_ctx.$slots, "default", {}, () => [
          hasMedia.value && _ctx.media?.type === "video" ? (openBlock(), createBlock(_sfc_main$a, {
            key: 0,
            "image-urls": _ctx.media.urls,
            "node-id": nodeId.value,
            class: "mt-2"
          }, null, 8, ["image-urls", "node-id"])) : hasMedia.value && _ctx.media?.type === "image" ? (openBlock(), createBlock(_sfc_main$9, {
            key: 1,
            "image-urls": _ctx.media.urls,
            "node-id": nodeId.value,
            class: "mt-2"
          }, null, 8, ["image-urls", "node-id"])) : createCommentVNode("", true)
        ])
      ]));
    };
  }
});
const _hoisted_1$6 = {
  key: 0,
  class: "node-error p-2 text-sm text-red-500"
};
const _hoisted_2$4 = ["data-node-id"];
const _hoisted_3$3 = {
  key: 0,
  class: "flex flex-col justify-center items-center relative"
};
const _hoisted_4$2 = { class: "relative mb-1" };
const _hoisted_5$1 = ["data-testid"];
const _hoisted_6$1 = {
  key: 1,
  class: "min-h-0 flex-1 flex"
};
const _hoisted_7$1 = {
  key: 2,
  class: "min-h-0 flex-1 px-4"
};
const _hoisted_8$1 = ["aria-label"];
const baseResizeHandleClasses = "absolute h-3 w-3 opacity-0 pointer-events-auto focus-visible:outline focus-visible:outline-2 focus-visible:outline-white/40";
const MIN_NODE_WIDTH = 225;
const progressClasses = "h-2 bg-primary-500 transition-all duration-300";
const _sfc_main$7 = /* @__PURE__ */ defineComponent({
  __name: "LGraphNode",
  props: {
    nodeData: {},
    error: { default: null }
  },
  setup(__props) {
    const { t: t2 } = useI18n();
    const { handleNodeCollapse, handleNodeTitleUpdate, handleNodeRightClick } = useNodeEventHandlers();
    const { bringNodeToFront } = useNodeZIndex();
    useVueElementTracking(() => __props.nodeData.id, "node");
    const { selectedNodeIds } = storeToRefs(useCanvasStore());
    const isSelected = computed(() => {
      return selectedNodeIds.value.has(__props.nodeData.id);
    });
    const nodeLocatorId = computed(() => getLocatorIdFromNodeData(__props.nodeData));
    const { executing, progress } = useNodeExecutionState(nodeLocatorId);
    const executionStore = useExecutionStore();
    const hasExecutionError = computed(
      () => executionStore.lastExecutionErrorNodeId === __props.nodeData.id
    );
    const hasAnyError = computed(() => {
      return !!(hasExecutionError.value || __props.nodeData.hasErrors || __props.error || (executionStore.lastNodeErrors?.[__props.nodeData.id]?.errors.length ?? 0) > 0);
    });
    const displayHeader = computed(() => __props.nodeData.titleMode !== TitleMode.NO_TITLE);
    const isCollapsed = computed(() => __props.nodeData.flags?.collapsed ?? false);
    const bypassed = computed(
      () => __props.nodeData.mode === LGraphEventMode.BYPASS
    );
    const muted = computed(() => __props.nodeData.mode === LGraphEventMode.NEVER);
    const nodeBodyBackgroundColor = computed(() => {
      const colorPaletteStore = useColorPaletteStore();
      if (!__props.nodeData.bgcolor) {
        return "";
      }
      return applyLightThemeColor(
        __props.nodeData.bgcolor,
        Boolean(colorPaletteStore.completedActivePalette.light_theme)
      );
    });
    const nodeOpacity = computed(() => {
      const globalOpacity = useSettingStore().get("Comfy.Node.Opacity") ?? 1;
      if (bypassed.value || muted.value) {
        return globalOpacity * 0.5;
      }
      return globalOpacity;
    });
    const hasInputs = computed(() => nonWidgetedInputs(__props.nodeData).length > 0);
    const hasOutputs = computed(() => !!__props.nodeData.outputs?.length);
    const { handleWheel, shouldHandleNodePointerEvents } = useCanvasInteractions();
    const renderError = ref(null);
    const { toastErrorHandler } = useErrorHandling();
    onErrorCaptured((error) => {
      renderError.value = error.message;
      toastErrorHandler(error);
      return false;
    });
    const { position, size, zIndex } = useNodeLayout(() => __props.nodeData.id);
    const { pointerHandlers } = useNodePointerInteractions(() => __props.nodeData.id);
    const { onPointerdown, ...remainingPointerHandlers } = pointerHandlers;
    const { startDrag } = useNodeDrag();
    async function nodeOnPointerdown(event) {
      if (event.altKey && lgraphNode.value) {
        const result = LGraphCanvas.cloneNodes([lgraphNode.value]);
        if (result?.created?.length) {
          const [newNode] = result.created;
          startDrag(event, `${newNode.id}`);
          layoutStore.isDraggingVueNodes.value = true;
          await nextTick();
          bringNodeToFront(`${newNode.id}`);
          return;
        }
      }
      onPointerdown(event);
    }
    __name(nodeOnPointerdown, "nodeOnPointerdown");
    const handleContextMenu = /* @__PURE__ */ __name((event) => {
      event.preventDefault();
      event.stopPropagation();
      handleNodeRightClick(event, __props.nodeData.id);
      showNodeOptions(event);
    }, "handleContextMenu");
    onMounted(() => {
      initSizeStyles();
    });
    function initSizeStyles() {
      const el = nodeContainerRef.value;
      const { width, height } = size.value;
      if (!el) return;
      const suffix = isCollapsed.value ? "-x" : "";
      el.style.setProperty(`--node-width${suffix}`, `${width}px`);
      el.style.setProperty(`--node-height${suffix}`, `${height}px`);
    }
    __name(initSizeStyles, "initSizeStyles");
    const { startResize } = useNodeResize((result, element) => {
      if (isCollapsed.value) return;
      const clampedWidth = Math.max(result.size.width, MIN_NODE_WIDTH);
      element.style.setProperty("--node-width", `${clampedWidth}px`);
      element.style.setProperty("--node-height", `${result.size.height}px`);
    });
    const handleResizePointerDown = /* @__PURE__ */ __name((event) => {
      if (event.button !== 0) return;
      if (!shouldHandleNodePointerEvents.value) return;
      if (__props.nodeData.flags?.pinned) return;
      startResize(event);
    }, "handleResizePointerDown");
    watch(isCollapsed, (collapsed) => {
      const element = nodeContainerRef.value;
      if (!element) return;
      const [from, to] = collapsed ? ["", "-x"] : ["-x", ""];
      const currentWidth = element.style.getPropertyValue(`--node-width${from}`);
      element.style.setProperty(`--node-width${to}`, currentWidth);
      element.style.setProperty(`--node-width${from}`, "");
      const currentHeight = element.style.getPropertyValue(`--node-height${from}`);
      element.style.setProperty(`--node-height${to}`, currentHeight);
      element.style.setProperty(`--node-height${from}`, "");
    });
    const hasCustomContent = computed(() => {
      return !!nodeMedia.value && nodeMedia.value.urls.length > 0;
    });
    const { latestPreviewUrl, shouldShowPreviewImg } = useNodePreviewState(
      () => __props.nodeData.id,
      {
        isCollapsed
      }
    );
    const borderClass = computed(() => {
      if (hasAnyError.value) return "border-node-stroke-error";
      if (!displayHeader.value && __props.nodeData.bgcolor && isTransparent(__props.nodeData.bgcolor))
        return "border-0";
      return "";
    });
    const outlineClass = computed(() => {
      return cn(
        isSelected.value && "outline-node-component-outline",
        hasAnyError.value && "outline-node-stroke-error",
        executing.value && "outline-node-stroke-executing"
      );
    });
    const cursorClass = computed(() => {
      return cn(
        __props.nodeData.flags?.pinned ? "cursor-default" : layoutStore.isDraggingVueNodes.value ? "cursor-grabbing" : "cursor-grab"
      );
    });
    const shapeClass = computed(() => {
      switch (__props.nodeData.shape) {
        case RenderShape.BOX:
          return "rounded-none";
        case RenderShape.CARD:
          return "rounded-tl-2xl rounded-br-2xl rounded-tr-none rounded-bl-none";
        default:
          return "rounded-2xl";
      }
    });
    const beforeShapeClass = computed(() => {
      switch (__props.nodeData.shape) {
        case RenderShape.BOX:
          return "before:rounded-none";
        case RenderShape.CARD:
          return "before:rounded-tl-2xl before:rounded-br-2xl before:rounded-tr-none before:rounded-bl-none";
        default:
          return "before:rounded-2xl";
      }
    });
    const handleCollapse = /* @__PURE__ */ __name(() => {
      handleNodeCollapse(__props.nodeData.id, !isCollapsed.value);
    }, "handleCollapse");
    const handleHeaderTitleUpdate = /* @__PURE__ */ __name((newTitle) => {
      handleNodeTitleUpdate(__props.nodeData.id, newTitle);
    }, "handleHeaderTitleUpdate");
    const handleEnterSubgraph = /* @__PURE__ */ __name(() => {
      const graph = app.rootGraph;
      if (!graph) {
        console.warn("LGraphNode: No graph available for subgraph navigation");
        return;
      }
      const locatorId = getLocatorIdFromNodeData(__props.nodeData);
      const litegraphNode = getNodeByLocatorId(graph, locatorId);
      if (!litegraphNode?.isSubgraphNode() || !("subgraph" in litegraphNode)) {
        console.warn("LGraphNode: Node is not a valid subgraph node", litegraphNode);
        return;
      }
      const canvas = app.canvas;
      if (!canvas || typeof canvas.openSubgraph !== "function") {
        console.warn("LGraphNode: Canvas or openSubgraph method not available");
        return;
      }
      canvas.openSubgraph(litegraphNode.subgraph, litegraphNode);
    }, "handleEnterSubgraph");
    const nodeOutputs = useNodeOutputStore();
    const nodeOutputLocatorId = computed(
      () => __props.nodeData.subgraphId ? `${__props.nodeData.subgraphId}:${__props.nodeData.id}` : __props.nodeData.id
    );
    const lgraphNode = computed(() => {
      const locatorId = getLocatorIdFromNodeData(__props.nodeData);
      return getNodeByLocatorId(app.rootGraph, locatorId);
    });
    const nodeMedia = computed(() => {
      const newOutputs = nodeOutputs.nodeOutputs[nodeOutputLocatorId.value];
      const node = lgraphNode.value;
      if (!node || !newOutputs?.images?.length) return void 0;
      const urls = nodeOutputs.getNodeImageUrls(node);
      if (!urls?.length) return void 0;
      const hasVideoInput = node.inputs?.some((input) => input.type === "VIDEO");
      const type = node.previewMediaType === "video" || !node.previewMediaType && hasVideoInput ? "video" : "image";
      return { type, urls };
    });
    const nodeContainerRef = ref();
    const isDraggingOver = ref(false);
    function handleDragOver(event) {
      const node = lgraphNode.value;
      if (!node || !node.onDragOver) {
        isDraggingOver.value = false;
        return;
      }
      const canDrop = node.onDragOver(event);
      isDraggingOver.value = canDrop;
    }
    __name(handleDragOver, "handleDragOver");
    function handleDragLeave() {
      isDraggingOver.value = false;
    }
    __name(handleDragLeave, "handleDragLeave");
    async function handleDrop(event) {
      isDraggingOver.value = false;
      const node = lgraphNode.value;
      if (!node || !node.onDragDrop) {
        return;
      }
      await node.onDragDrop(event);
    }
    __name(handleDrop, "handleDrop");
    return (_ctx, _cache) => {
      return renderError.value ? (openBlock(), createElementBlock("div", _hoisted_1$6, toDisplayString(unref(st)("nodeErrors.render", "Node Render Error")), 1)) : (openBlock(), createElementBlock("div", mergeProps({
        key: 1,
        ref_key: "nodeContainerRef",
        ref: nodeContainerRef,
        tabindex: "0",
        "data-node-id": _ctx.nodeData.id,
        class: unref(cn)(
          "bg-component-node-background lg-node absolute text-sm",
          "contain-style contain-layout min-w-[225px] min-h-(--node-height) w-(--node-width)",
          shapeClass.value,
          "touch-none flex flex-col",
          "border-1 border-solid border-component-node-border",
          // hover (only when node should handle events)
          unref(shouldHandleNodePointerEvents) && "hover:ring-7 ring-node-component-ring",
          "outline-transparent outline-2 focus-visible:outline-node-component-outline",
          borderClass.value,
          outlineClass.value,
          cursorClass.value,
          {
            [`${beforeShapeClass.value} before:pointer-events-none before:absolute before:bg-bypass/60 before:inset-0`]: bypassed.value,
            [`${beforeShapeClass.value} before:pointer-events-none before:absolute before:inset-0`]: muted.value,
            "ring-4 ring-primary-500 bg-primary-500/10": isDraggingOver.value
          },
          unref(shouldHandleNodePointerEvents) ? "pointer-events-auto" : "pointer-events-none",
          !isCollapsed.value && " pb-1"
        ),
        style: [
          {
            transform: `translate(${unref(position).x ?? 0}px, ${(unref(position).y ?? 0) - unref(LiteGraph).NODE_TITLE_HEIGHT}px)`,
            zIndex: unref(zIndex),
            opacity: nodeOpacity.value,
            "--component-node-background": nodeBodyBackgroundColor.value
          }
        ]
      }, remainingPointerHandlers, {
        onPointerdown: nodeOnPointerdown,
        onWheel: _cache[0] || (_cache[0] = //@ts-ignore
        (...args) => unref(handleWheel) && unref(handleWheel)(...args)),
        onContextmenu: handleContextMenu,
        onDragover: withModifiers(handleDragOver, ["prevent"]),
        onDragleave: handleDragLeave,
        onDrop: withModifiers(handleDrop, ["stop", "prevent"])
      }), [
        displayHeader.value ? (openBlock(), createElementBlock("div", _hoisted_3$3, [
          isCollapsed.value ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [
            hasInputs.value ? (openBlock(), createBlock(_sfc_main$29, {
              key: 0,
              multi: "",
              class: "absolute left-0 -translate-x-1/2"
            })) : createCommentVNode("", true),
            hasOutputs.value ? (openBlock(), createBlock(_sfc_main$29, {
              key: 1,
              multi: "",
              class: "absolute right-0 translate-x-1/2"
            })) : createCommentVNode("", true),
            createVNode(_sfc_main$2a, {
              "node-data": _ctx.nodeData,
              unified: ""
            }, null, 8, ["node-data"])
          ], 64)) : createCommentVNode("", true),
          createVNode(_sfc_main$2b, {
            "node-data": _ctx.nodeData,
            collapsed: isCollapsed.value,
            onCollapse: handleCollapse,
            "onUpdate:title": handleHeaderTitleUpdate,
            onEnterSubgraph: handleEnterSubgraph
          }, null, 8, ["node-data", "collapsed"])
        ])) : createCommentVNode("", true),
        isCollapsed.value && unref(executing) && unref(progress) !== void 0 ? (openBlock(), createElementBlock("div", {
          key: 1,
          class: normalizeClass(
            unref(cn)(
              "absolute inset-x-4 -bottom-[1px] translate-y-1/2 rounded-full",
              progressClasses
            )
          ),
          style: normalizeStyle({ width: `${Math.min(unref(progress) * 100, 100)}%` })
        }, null, 6)) : createCommentVNode("", true),
        !isCollapsed.value ? (openBlock(), createElementBlock(Fragment, { key: 2 }, [
          createBaseVNode("div", _hoisted_4$2, [
            unref(executing) && unref(progress) !== void 0 ? (openBlock(), createElementBlock("div", {
              key: 0,
              class: normalizeClass(
                unref(cn)(
                  "absolute inset-x-0 top-1/2 -translate-y-1/2",
                  !!(unref(progress) < 1) && "rounded-r-full",
                  progressClasses
                )
              ),
              style: normalizeStyle({ width: `${Math.min(unref(progress) * 100, 100)}%` })
            }, null, 6)) : createCommentVNode("", true)
          ]),
          createBaseVNode("div", {
            class: "flex flex-1 flex-col gap-1 pb-2",
            "data-testid": `node-body-${_ctx.nodeData.id}`
          }, [
            createVNode(_sfc_main$2a, { "node-data": _ctx.nodeData }, null, 8, ["node-data"]),
            _ctx.nodeData.widgets?.length ? (openBlock(), createBlock(_sfc_main$2c, {
              key: 0,
              "node-data": _ctx.nodeData
            }, null, 8, ["node-data"])) : createCommentVNode("", true),
            hasCustomContent.value ? (openBlock(), createElementBlock("div", _hoisted_6$1, [
              createVNode(_sfc_main$8, {
                "node-data": _ctx.nodeData,
                media: nodeMedia.value
              }, null, 8, ["node-data", "media"])
            ])) : createCommentVNode("", true),
            unref(shouldShowPreviewImg) ? (openBlock(), createElementBlock("div", _hoisted_7$1, [
              createVNode(_sfc_main$b, {
                "image-url": unref(latestPreviewUrl) || null
              }, null, 8, ["image-url"])
            ])) : createCommentVNode("", true)
          ], 8, _hoisted_5$1)
        ], 64)) : createCommentVNode("", true),
        !isCollapsed.value ? (openBlock(), createElementBlock("div", {
          key: 3,
          role: "button",
          "aria-label": unref(t2)("g.resizeFromBottomRight"),
          class: normalizeClass(unref(cn)(baseResizeHandleClasses, "right-0 bottom-0 cursor-se-resize")),
          onPointerdown: withModifiers(handleResizePointerDown, ["stop"])
        }, null, 42, _hoisted_8$1)) : createCommentVNode("", true)
      ], 16, _hoisted_2$4));
    };
  }
});
let pendingCallbacks = [];
let isNewUserDetermined = false;
let isNewUserCached = null;
const newUserService = /* @__PURE__ */ __name(() => {
  function checkIsNewUser(settingStore) {
    const isNewUserSettings = Object.keys(settingStore.settingValues).length === 0 || !settingStore.get("Comfy.TutorialCompleted");
    const hasNoWorkflow = !localStorage.getItem("workflow");
    const hasNoPreviousWorkflow = !localStorage.getItem(
      "Comfy.PreviousWorkflow"
    );
    return isNewUserSettings && hasNoWorkflow && hasNoPreviousWorkflow;
  }
  __name(checkIsNewUser, "checkIsNewUser");
  async function registerInitCallback(callback) {
    if (isNewUserDetermined) {
      if (isNewUserCached) {
        try {
          await callback();
        } catch (error) {
          console.error("New user initialization callback failed:", error);
        }
      }
    } else {
      pendingCallbacks.push(callback);
    }
  }
  __name(registerInitCallback, "registerInitCallback");
  async function initializeIfNewUser(settingStore) {
    if (isNewUserDetermined) return;
    isNewUserCached = checkIsNewUser(settingStore);
    isNewUserDetermined = true;
    if (!isNewUserCached) {
      pendingCallbacks = [];
      return;
    }
    await settingStore.set(
      "Comfy.InstalledVersion",
      void 0
    );
    for (const callback of pendingCallbacks) {
      try {
        await callback();
      } catch (error) {
        console.error("New user initialization callback failed:", error);
      }
    }
    pendingCallbacks = [];
  }
  __name(initializeIfNewUser, "initializeIfNewUser");
  function isNewUser() {
    return isNewUserDetermined ? isNewUserCached : null;
  }
  __name(isNewUser, "isNewUser");
  return {
    registerInitCallback,
    initializeIfNewUser,
    isNewUser
  };
}, "newUserService");
const _sfc_main$6 = /* @__PURE__ */ defineComponent({
  __name: "SelectionRectangle",
  setup(__props) {
    const canvasStore = useCanvasStore();
    const selectionRect = ref(null);
    useRafFn(() => {
      const canvas = canvasStore.canvas;
      if (!canvas) {
        selectionRect.value = null;
        return;
      }
      const { pointer, dragging_rectangle } = canvas;
      if (dragging_rectangle && pointer.eDown && pointer.eMove) {
        const x = pointer.eDown.safeOffsetX;
        const y = pointer.eDown.safeOffsetY;
        const w = pointer.eMove.safeOffsetX - x;
        const h = pointer.eMove.safeOffsetY - y;
        selectionRect.value = { x, y, w, h };
      } else {
        selectionRect.value = null;
      }
    });
    const isVisible = computed(() => selectionRect.value !== null);
    const rectangleStyle = computed(() => {
      const rect = selectionRect.value;
      if (!rect) return {};
      const left = rect.w >= 0 ? rect.x : rect.x + rect.w;
      const top = rect.h >= 0 ? rect.y : rect.y + rect.h;
      const width = Math.abs(rect.w);
      const height = Math.abs(rect.h);
      return {
        left: `${left}px`,
        top: `${top}px`,
        width: `${width}px`,
        height: `${height}px`
      };
    });
    return (_ctx, _cache) => {
      return isVisible.value ? (openBlock(), createElementBlock("div", {
        key: 0,
        class: "pointer-events-none absolute z-9999 border border-blue-400 bg-blue-500/20",
        style: normalizeStyle(rectangleStyle.value)
      }, null, 4)) : createCommentVNode("", true);
    };
  }
});
const _hoisted_1$5 = {
  key: 0,
  class: "workflow-tabs-container pointer-events-auto relative h-9.5 w-full"
};
const _hoisted_2$3 = {
  key: 0,
  class: "app-drag fixed top-0 left-0 z-10 h-[var(--comfy-topbar-height)] w-full"
};
const _hoisted_3$2 = { class: "flex h-full items-center border-b border-interface-stroke bg-comfy-menu-bg shadow-interface" };
const _hoisted_4$1 = { class: "sidebar-content-container h-full w-full overflow-x-hidden overflow-y-auto" };
const _sfc_main$5 = /* @__PURE__ */ defineComponent({
  __name: "GraphCanvas",
  emits: ["ready"],
  setup(__props, { emit: __emit }) {
    const emit = __emit;
    const canvasRef = ref(null);
    const nodeSearchboxPopoverRef = shallowRef(null);
    const settingStore = useSettingStore();
    const nodeDefStore = useNodeDefStore();
    const workspaceStore = useWorkspaceStore();
    const canvasStore = useCanvasStore();
    const executionStore = useExecutionStore();
    const toastStore = useToastStore();
    const colorPaletteStore = useColorPaletteStore();
    const colorPaletteService = useColorPaletteService();
    const canvasInteractions = useCanvasInteractions();
    const betaMenuEnabled = computed(
      () => settingStore.get("Comfy.UseNewMenu") !== "Disabled"
    );
    const workflowTabsPosition = computed(
      () => settingStore.get("Comfy.Workflow.WorkflowTabsPosition")
    );
    const canvasMenuEnabled = computed(
      () => settingStore.get("Comfy.Graph.CanvasMenu")
    );
    const tooltipEnabled = computed(() => settingStore.get("Comfy.EnableTooltips"));
    const selectionToolboxEnabled = computed(
      () => settingStore.get("Comfy.Canvas.SelectionToolbox")
    );
    const activeSidebarTab = computed(() => {
      return workspaceStore.sidebarTab.activeSidebarTab;
    });
    const showUI = computed(
      () => !workspaceStore.focusMode && betaMenuEnabled.value
    );
    const minimapEnabled = computed(() => settingStore.get("Comfy.Minimap.Visible"));
    const { shouldRenderVueNodes } = useVueFeatureFlags();
    const vueNodeLifecycle = useVueNodeLifecycle();
    const handleVueNodeLifecycleReset = /* @__PURE__ */ __name(async () => {
      if (shouldRenderVueNodes.value) {
        vueNodeLifecycle.disposeNodeManagerAndSyncs();
        await nextTick();
        vueNodeLifecycle.initializeNodeManager();
      }
    }, "handleVueNodeLifecycleReset");
    watch(() => canvasStore.currentGraph, handleVueNodeLifecycleReset);
    watch(
      () => canvasStore.isInSubgraph,
      async (newValue, oldValue) => {
        if (oldValue && !newValue) {
          useWorkflowStore().updateActiveGraph();
        }
        await handleVueNodeLifecycleReset();
      }
    );
    const allNodes = computed(
      () => Array.from(vueNodeLifecycle.nodeManager.value?.vueNodeData?.values() ?? [])
    );
    watchEffect(() => {
      LiteGraph.nodeOpacity = settingStore.get("Comfy.Node.Opacity");
    });
    watchEffect(() => {
      LiteGraph.nodeLightness = colorPaletteStore.completedActivePalette.light_theme ? 0.5 : void 0;
    });
    watchEffect(() => {
      nodeDefStore.showDeprecated = settingStore.get("Comfy.Node.ShowDeprecated");
    });
    watchEffect(() => {
      nodeDefStore.showExperimental = settingStore.get(
        "Comfy.Node.ShowExperimental"
      );
    });
    watchEffect(() => {
      const spellcheckEnabled = settingStore.get("Comfy.TextareaWidget.Spellcheck");
      const textareas = document.querySelectorAll(
        "textarea.comfy-multiline-input"
      );
      textareas.forEach((textarea) => {
        textarea.spellcheck = spellcheckEnabled;
        textarea.focus();
        textarea.blur();
      });
    });
    watch(
      () => settingStore.get("Comfy.WidgetControlMode"),
      () => {
        if (!canvasStore.canvas) return;
        forEachNode(app.rootGraph, (n) => {
          if (!n.widgets) return;
          for (const w of n.widgets) {
            if (!w[IS_CONTROL_WIDGET]) continue;
            updateControlWidgetLabel(w);
            if (!w.linkedWidgets) continue;
            for (const l of w.linkedWidgets) {
              updateControlWidgetLabel(l);
            }
          }
        });
        canvasStore.canvas.setDirty(true);
      }
    );
    watch(
      [() => canvasStore.canvas, () => settingStore.get("Comfy.ColorPalette")],
      async ([canvas, currentPaletteId]) => {
        if (!canvas) return;
        await colorPaletteService.loadColorPalette(currentPaletteId);
      }
    );
    watch(
      () => settingStore.get("Comfy.Canvas.BackgroundImage"),
      async () => {
        if (!canvasStore.canvas) return;
        const currentPaletteId = colorPaletteStore.activePaletteId;
        if (!currentPaletteId) return;
        await colorPaletteService.loadColorPalette(currentPaletteId);
        canvasStore.canvas.setDirty(false, true);
      }
    );
    watch(
      () => colorPaletteStore.activePaletteId,
      async (newValue) => {
        await settingStore.set("Comfy.ColorPalette", newValue);
      }
    );
    watch(
      () => [executionStore.nodeLocationProgressStates, canvasStore.canvas],
      ([nodeLocationProgressStates, canvas]) => {
        if (!canvas?.graph) return;
        for (const node of canvas.graph.nodes) {
          const nodeLocatorId = useWorkflowStore().nodeIdToNodeLocatorId(node.id);
          const progressState = nodeLocationProgressStates[nodeLocatorId];
          if (progressState && progressState.state === "running") {
            node.progress = progressState.value / progressState.max;
          } else {
            node.progress = void 0;
          }
        }
        canvas.setDirty(true, false);
      },
      { deep: true }
    );
    watch(
      () => executionStore.lastNodeErrors,
      (lastNodeErrors) => {
        if (!app.graph) return;
        forEachNode(app.rootGraph, (node) => {
          for (const slot of node.inputs) {
            delete slot.hasErrors;
          }
          for (const slot of node.outputs) {
            delete slot.hasErrors;
          }
          const nodeErrors = lastNodeErrors?.[node.id];
          if (!nodeErrors) return;
          const validErrors = nodeErrors.errors.filter(
            (error) => error.extra_info?.input_name !== void 0
          );
          validErrors.forEach((error) => {
            const inputName = error.extra_info.input_name;
            const inputIndex = node.findInputSlot(inputName);
            if (inputIndex !== -1) {
              node.inputs[inputIndex].hasErrors = true;
            }
          });
        });
        app.canvas.setDirty(true, true);
      }
    );
    useEventListener(
      canvasRef,
      "litegraph:no-items-selected",
      () => {
        toastStore.add({
          severity: "warn",
          summary: t("toastMessages.nothingSelected"),
          life: 2e3
        });
      },
      { passive: true }
    );
    const loadCustomNodesI18n = /* @__PURE__ */ __name(async () => {
      try {
        const i18nData = await api.getCustomNodesI18n();
        mergeCustomNodesI18n(i18nData);
      } catch (error) {
        console.error("Failed to load custom nodes i18n", error);
      }
    }, "loadCustomNodesI18n");
    const comfyAppReady = ref(false);
    const workflowPersistence = useWorkflowPersistence();
    useCanvasDrop(canvasRef);
    useLitegraphSettings();
    useNodeBadge();
    onMounted(async () => {
      useGlobalLitegraph();
      useContextMenuTranslation();
      useCopy();
      usePaste();
      useWorkflowAutoSave();
      useVueFeatureFlags();
      app.vueAppReady = true;
      workspaceStore.spinner = true;
      ChangeTracker.init();
      await loadCustomNodesI18n();
      try {
        await settingStore.loadSettingValues();
      } catch (error) {
        if (error instanceof UnauthorizedError) {
          localStorage.removeItem("Comfy.userId");
          localStorage.removeItem("Comfy.userName");
          window.location.reload();
        } else {
          throw error;
        }
      }
      CORE_SETTINGS.forEach(settingStore.addSetting);
      await newUserService().initializeIfNewUser(settingStore);
      await app.setup(canvasRef.value);
      canvasStore.canvas = app.canvas;
      canvasStore.canvas.render_canvas_border = false;
      workspaceStore.spinner = false;
      useSearchBoxStore().setPopoverRef(nodeSearchboxPopoverRef.value);
      window.app = app;
      window.graph = app.graph;
      comfyAppReady.value = true;
      vueNodeLifecycle.setupEmptyGraphListener();
      app.canvas.onSelectionChange = useChainCallback(
        app.canvas.onSelectionChange,
        () => canvasStore.updateSelectedItems()
      );
      colorPaletteStore.customPalettes = settingStore.get(
        "Comfy.CustomColorPalettes"
      );
      await workflowPersistence.initializeWorkflow();
      workflowPersistence.restoreWorkflowTabsState();
      await workflowPersistence.loadTemplateFromUrlIfPresent();
      const { useReleaseStore: useReleaseStore2 } = await __vitePreload(async () => {
        const { useReleaseStore: useReleaseStore3 } = await Promise.resolve().then(() => releaseStore);
        return { useReleaseStore: useReleaseStore3 };
      }, true ? void 0 : void 0, import.meta.url);
      const releaseStore$1 = useReleaseStore2();
      void releaseStore$1.initialize();
      watch(
        () => settingStore.get("Comfy.Locale"),
        async () => {
          await useCommandStore().execute("Comfy.RefreshNodeDefinitions");
          await useWorkflowService().reloadCurrentWorkflow();
        }
      );
      whenever(
        () => useCanvasStore().canvas,
        (canvas) => {
          useEventListener(canvas.canvas, "litegraph:set-graph", () => {
            useWorkflowStore().updateActiveGraph();
          });
        },
        { immediate: true }
      );
      emit("ready");
    });
    onUnmounted(() => {
      vueNodeLifecycle.cleanup();
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        comfyAppReady.value ? (openBlock(), createBlock(LiteGraphCanvasSplitterOverlay, { key: 0 }, createSlots({
          "graph-canvas-panel": withCtx(() => [
            canvasMenuEnabled.value ? (openBlock(), createBlock(_sfc_main$1a, {
              key: 0,
              class: "pointer-events-auto"
            })) : createCommentVNode("", true),
            comfyAppReady.value && minimapEnabled.value && betaMenuEnabled.value ? (openBlock(), createBlock(MiniMap, {
              key: 1,
              class: "pointer-events-auto"
            })) : createCommentVNode("", true)
          ]),
          _: 2
        }, [
          showUI.value ? {
            name: "workflow-tabs",
            fn: withCtx(() => [
              workflowTabsPosition.value === "Topbar" ? (openBlock(), createElementBlock("div", _hoisted_1$5, [
                unref(isNativeWindow)() && workflowTabsPosition.value !== "Topbar" ? (openBlock(), createElementBlock("div", _hoisted_2$3)) : createCommentVNode("", true),
                createBaseVNode("div", _hoisted_3$2, [
                  createVNode(WorkflowTabs),
                  createVNode(_sfc_main$j)
                ])
              ])) : createCommentVNode("", true)
            ]),
            key: "0"
          } : void 0,
          showUI.value ? {
            name: "side-toolbar",
            fn: withCtx(() => [
              createVNode(SideToolbar)
            ]),
            key: "1"
          } : void 0,
          showUI.value ? {
            name: "side-bar-panel",
            fn: withCtx(() => [
              createBaseVNode("div", _hoisted_4$1, [
                activeSidebarTab.value ? (openBlock(), createBlock(_sfc_main$1g, {
                  key: 0,
                  extension: activeSidebarTab.value
                }, null, 8, ["extension"])) : createCommentVNode("", true)
              ])
            ]),
            key: "2"
          } : void 0,
          showUI.value ? {
            name: "topmenu",
            fn: withCtx(() => [
              createVNode(_sfc_main$1h)
            ]),
            key: "3"
          } : void 0,
          showUI.value ? {
            name: "bottom-panel",
            fn: withCtx(() => [
              createVNode(BottomPanel)
            ]),
            key: "4"
          } : void 0,
          showUI.value ? {
            name: "right-side-panel",
            fn: withCtx(() => [
              createVNode(_sfc_main$I)
            ]),
            key: "5"
          } : void 0
        ]), 1024)) : createCommentVNode("", true),
        createBaseVNode("canvas", {
          id: "graph-canvas",
          ref_key: "canvasRef",
          ref: canvasRef,
          tabindex: "1",
          class: "absolute inset-0 size-full touch-none"
        }, null, 512),
        unref(shouldRenderVueNodes) && unref(app).canvas && comfyAppReady.value ? (openBlock(), createBlock(TransformPane, {
          key: 1,
          canvas: unref(app).canvas,
          onWheelCapture: unref(canvasInteractions).forwardEventToCanvas
        }, {
          default: withCtx(() => [
            (openBlock(true), createElementBlock(Fragment, null, renderList(allNodes.value, (nodeData) => {
              return openBlock(), createBlock(_sfc_main$7, {
                key: nodeData.id,
                "node-data": nodeData,
                error: unref(executionStore).lastExecutionError?.node_id === nodeData.id ? "Execution error" : null,
                "zoom-level": unref(canvasStore).canvas?.ds?.scale || 1,
                "data-node-id": nodeData.id
              }, null, 8, ["node-data", "error", "zoom-level", "data-node-id"]);
            }), 128))
          ]),
          _: 1
        }, 8, ["canvas", "onWheelCapture"])) : createCommentVNode("", true),
        comfyAppReady.value ? (openBlock(), createBlock(_sfc_main$6, { key: 2 })) : createCommentVNode("", true),
        tooltipEnabled.value ? (openBlock(), createBlock(NodeTooltip, { key: 3 })) : createCommentVNode("", true),
        createVNode(_sfc_main$E, {
          ref_key: "nodeSearchboxPopoverRef",
          ref: nodeSearchboxPopoverRef
        }, null, 512),
        comfyAppReady.value ? (openBlock(), createElementBlock(Fragment, { key: 4 }, [
          createVNode(TitleEditor),
          selectionToolboxEnabled.value ? (openBlock(), createBlock(SelectionToolbox, { key: 0 })) : createCommentVNode("", true),
          !unref(shouldRenderVueNodes) ? (openBlock(), createBlock(_sfc_main$1d, { key: 1 })) : createCommentVNode("", true)
        ], 64)) : createCommentVNode("", true)
      ], 64);
    };
  }
});
const _hoisted_1$4 = { class: "flex flex-auto flex-col items-start" };
const _hoisted_2$2 = { class: "my-4 text-lg font-medium" };
const _sfc_main$4 = /* @__PURE__ */ defineComponent({
  __name: "RerouteMigrationToast",
  setup(__props) {
    const { t: t2 } = useI18n();
    const toast = useToast();
    const workflowStore = useWorkflowStore();
    const migrateToLitegraphReroute = /* @__PURE__ */ __name(async () => {
      const workflowJSON = app.rootGraph.serialize();
      const migratedWorkflowJSON = migrateLegacyRerouteNodes(workflowJSON);
      await app.loadGraphData(
        migratedWorkflowJSON,
        false,
        false,
        workflowStore.activeWorkflow
      );
      toast.removeGroup("reroute-migration");
    }, "migrateToLitegraphReroute");
    return (_ctx, _cache) => {
      return openBlock(), createBlock(unref(script$2), { group: "reroute-migration" }, {
        message: withCtx(() => [
          createBaseVNode("div", _hoisted_1$4, [
            createBaseVNode("div", _hoisted_2$2, toDisplayString(unref(t2)("toastMessages.migrateToLitegraphReroute")), 1),
            createVNode(_sfc_main$1Y, {
              class: "self-end",
              size: "sm",
              onClick: migrateToLitegraphReroute
            }, {
              default: withCtx(() => [
                createTextVNode(toDisplayString(unref(t2)("g.migrate")), 1)
              ]),
              _: 1
            })
          ])
        ]),
        _: 1
      });
    };
  }
});
const DEFAULT_TITLE = "ComfyUI";
const TITLE_SUFFIX = " - ComfyUI";
const useBrowserTabTitle = /* @__PURE__ */ __name(() => {
  const executionStore = useExecutionStore();
  const settingStore = useSettingStore();
  const workflowStore = useWorkflowStore();
  const workspaceStore = useWorkspaceStore();
  const executionText = computed(
    () => executionStore.isIdle ? "" : `[${Math.round(executionStore.executionProgress * 100)}%]`
  );
  const newMenuEnabled = computed(
    () => settingStore.get("Comfy.UseNewMenu") !== "Disabled"
  );
  const isAutoSaveEnabled = computed(
    () => settingStore.get("Comfy.Workflow.AutoSave") === "after delay"
  );
  const isActiveWorkflowModified = computed(
    () => !!workflowStore.activeWorkflow?.isModified
  );
  const isActiveWorkflowPersisted = computed(
    () => !!workflowStore.activeWorkflow?.isPersisted
  );
  const shouldShowUnsavedIndicator = computed(() => {
    if (workspaceStore.shiftDown) return false;
    if (isAutoSaveEnabled.value) return false;
    if (!isActiveWorkflowPersisted.value) return true;
    if (isActiveWorkflowModified.value) return true;
    return false;
  });
  const isUnsavedText = computed(
    () => shouldShowUnsavedIndicator.value ? " *" : ""
  );
  const workflowNameText = computed(() => {
    const workflowName = workflowStore.activeWorkflow?.filename;
    return workflowName ? isUnsavedText.value + workflowName + TITLE_SUFFIX : DEFAULT_TITLE;
  });
  const nodeExecutionTitle = computed(() => {
    const nodeProgressEntries = Object.entries(
      executionStore.nodeProgressStates
    );
    const runningNodes = nodeProgressEntries.filter(
      ([_, state2]) => state2.state === "running"
    );
    if (runningNodes.length === 0) {
      return "";
    }
    if (runningNodes.length > 1) {
      return `${executionText.value}[${runningNodes.length} ${t("g.nodesRunning", "nodes running")}]`;
    }
    const [nodeId, state] = runningNodes[0];
    const progress = Math.round(state.value / state.max * 100);
    const nodeType = executionStore.activePrompt?.workflow?.changeTracker?.activeState.nodes.find(
      (n) => String(n.id) === nodeId
    )?.type || "Node";
    return `${executionText.value}[${progress}%] ${nodeType}`;
  });
  const workflowTitle = computed(
    () => executionText.value + (newMenuEnabled.value ? workflowNameText.value : DEFAULT_TITLE)
  );
  const title = computed(() => nodeExecutionTitle.value || workflowTitle.value);
  useTitle(title);
}, "useBrowserTabTitle");
const _sfc_main$3 = {};
const _hoisted_1$3 = { class: "size-full bg-modal-panel-background pr-6 pb-8 pl-4" };
function _sfc_render(_ctx, _cache) {
  return openBlock(), createElementBlock("div", _hoisted_1$3, [
    renderSlot(_ctx.$slots, "default")
  ]);
}
__name(_sfc_render, "_sfc_render");
const RightSidePanel = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["render", _sfc_render]]);
const _hoisted_1$2 = { class: "text-neutral text-base" };
const _hoisted_2$1 = { class: "flex gap-2" };
const _hoisted_3$1 = { class: "relative flex gap-2 px-6 pb-4" };
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "SampleModelSelector",
  props: {
    onClose: { type: Function }
  },
  setup(__props) {
    const frameworkOptions = ref([
      { name: "Vue", value: "vue" },
      { name: "React", value: "react" },
      { name: "Angular", value: "angular" },
      { name: "Svelte", value: "svelte" }
    ]);
    const projectOptions = ref([
      { name: "Project A", value: "proj-a" },
      { name: "Project B", value: "proj-b" },
      { name: "Project C", value: "proj-c" }
    ]);
    const sortOptions = ref([
      { name: "Popular", value: "popular" },
      { name: "Latest", value: "latest" },
      { name: "A → Z", value: "az" }
    ]);
    const tempNavigation = ref([
      { id: "installed", label: "Installed", icon: "icon-[lucide--download]" },
      {
        title: "TAGS",
        items: [
          { id: "tag-sd15", label: "SD 1.5", icon: "icon-[lucide--tag]" },
          { id: "tag-sdxl", label: "SDXL", icon: "icon-[lucide--tag]" },
          { id: "tag-utility", label: "Utility", icon: "icon-[lucide--tag]" }
        ]
      },
      {
        title: "CATEGORIES",
        items: [
          { id: "cat-models", label: "Models", icon: "icon-[lucide--layers]" },
          { id: "cat-nodes", label: "Nodes", icon: "icon-[lucide--grid-3x3]" }
        ]
      }
    ]);
    provide(OnCloseKey, __props.onClose);
    const searchQuery = ref("");
    const searchText = ref("");
    const selectedFrameworks = ref([]);
    const selectedProjects = ref([]);
    const selectedSort = ref("popular");
    const selectedNavItem = ref("installed");
    const gridStyle = computed(() => createGridStyle());
    return (_ctx, _cache) => {
      return openBlock(), createBlock(BaseModalLayout, {
        "content-title": _ctx.$t("assetBrowser.checkpoints")
      }, {
        leftPanel: withCtx(() => [
          createVNode(_sfc_main$1S, {
            modelValue: selectedNavItem.value,
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => selectedNavItem.value = $event),
            "nav-items": tempNavigation.value
          }, {
            "header-icon": withCtx(() => _cache[6] || (_cache[6] = [
              createBaseVNode("i", { class: "text-neutral icon-[lucide--puzzle]" }, null, -1)
            ])),
            "header-title": withCtx(() => [
              createBaseVNode("span", _hoisted_1$2, toDisplayString(_ctx.$t("g.title")), 1)
            ]),
            _: 1
          }, 8, ["modelValue", "nav-items"])
        ]),
        header: withCtx(() => [
          createVNode(SearchBox, {
            modelValue: searchQuery.value,
            "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => searchQuery.value = $event),
            size: "lg",
            class: "max-w-[384px]"
          }, null, 8, ["modelValue"])
        ]),
        "header-right-area": withCtx(() => [
          createBaseVNode("div", _hoisted_2$1, [
            createVNode(_sfc_main$1Y, {
              variant: "primary",
              onClick: /* @__PURE__ */ __name(() => {
              }, "onClick")
            }, {
              default: withCtx(() => [
                _cache[7] || (_cache[7] = createBaseVNode("i", { class: "icon-[lucide--upload]" }, null, -1)),
                createBaseVNode("span", null, toDisplayString(_ctx.$t("g.upload")), 1)
              ]),
              _: 1
            }),
            createVNode(_sfc_main$1P, null, {
              default: withCtx(({ close }) => [
                createVNode(_sfc_main$1Y, {
                  variant: "secondary",
                  onClick: /* @__PURE__ */ __name(() => {
                    close();
                  }, "onClick")
                }, {
                  default: withCtx(() => [
                    _cache[8] || (_cache[8] = createBaseVNode("i", { class: "icon-[lucide--download]" }, null, -1)),
                    createBaseVNode("span", null, toDisplayString(_ctx.$t("g.settings")), 1)
                  ]),
                  _: 2
                }, 1032, ["onClick"]),
                createVNode(_sfc_main$1Y, {
                  variant: "primary",
                  onClick: /* @__PURE__ */ __name(() => {
                    close();
                  }, "onClick")
                }, {
                  default: withCtx(() => [
                    _cache[9] || (_cache[9] = createBaseVNode("i", { class: "icon-[lucide--scroll]" }, null, -1)),
                    createBaseVNode("span", null, toDisplayString(_ctx.$t("g.profile")), 1)
                  ]),
                  _: 2
                }, 1032, ["onClick"])
              ]),
              _: 1
            })
          ])
        ]),
        contentFilter: withCtx(() => [
          createBaseVNode("div", _hoisted_3$1, [
            createVNode(_sfc_main$1R, {
              modelValue: selectedFrameworks.value,
              "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => selectedFrameworks.value = $event),
              "search-query": searchText.value,
              "onUpdate:searchQuery": _cache[3] || (_cache[3] = ($event) => searchText.value = $event),
              class: "w-[250px]",
              label: _ctx.$t("assetBrowser.selectFrameworks"),
              options: frameworkOptions.value,
              "show-search-box": true,
              "show-selected-count": true,
              "show-clear-button": true
            }, null, 8, ["modelValue", "search-query", "label", "options"]),
            createVNode(_sfc_main$1R, {
              modelValue: selectedProjects.value,
              "onUpdate:modelValue": _cache[4] || (_cache[4] = ($event) => selectedProjects.value = $event),
              label: _ctx.$t("assetBrowser.selectProjects"),
              options: projectOptions.value
            }, null, 8, ["modelValue", "label", "options"]),
            createVNode(_sfc_main$1Z, {
              modelValue: selectedSort.value,
              "onUpdate:modelValue": _cache[5] || (_cache[5] = ($event) => selectedSort.value = $event),
              label: _ctx.$t("assetBrowser.sortingType"),
              options: sortOptions.value,
              class: "w-[135px]"
            }, {
              icon: withCtx(() => _cache[10] || (_cache[10] = [
                createBaseVNode("i", { class: "icon-[lucide--filter]" }, null, -1)
              ])),
              _: 1
            }, 8, ["modelValue", "label", "options"])
          ])
        ]),
        content: withCtx(() => [
          createBaseVNode("div", {
            style: normalizeStyle(gridStyle.value)
          }, [
            (openBlock(), createElementBlock(Fragment, null, renderList(100, (i) => {
              return createVNode(_sfc_main$25, {
                key: i,
                size: "regular"
              }, {
                top: withCtx(() => [
                  createVNode(_sfc_main$27, { ratio: "landscape" }, {
                    default: withCtx(() => _cache[11] || (_cache[11] = [
                      createBaseVNode("div", { class: "h-full w-full bg-blue-500" }, null, -1)
                    ])),
                    "top-right": withCtx(() => [
                      createVNode(_sfc_main$1Y, {
                        size: "icon",
                        class: "!bg-white !text-neutral-900",
                        onClick: /* @__PURE__ */ __name(() => {
                        }, "onClick")
                      }, {
                        default: withCtx(() => _cache[12] || (_cache[12] = [
                          createBaseVNode("i", { class: "icon-[lucide--info]" }, null, -1)
                        ])),
                        _: 1
                      })
                    ]),
                    "bottom-right": withCtx(() => [
                      createVNode(_sfc_main$28, { label: "png" }),
                      createVNode(_sfc_main$28, { label: "1.2 MB" }),
                      createVNode(_sfc_main$28, { label: "LoRA" }, {
                        icon: withCtx(() => _cache[13] || (_cache[13] = [
                          createBaseVNode("i", { class: "icon-[lucide--folder]" }, null, -1)
                        ])),
                        _: 1
                      })
                    ]),
                    _: 1
                  })
                ]),
                bottom: withCtx(() => [
                  createVNode(_sfc_main$26)
                ]),
                _: 2
              }, 1024);
            }), 64))
          ], 4)
        ]),
        rightPanel: withCtx(() => [
          createVNode(RightSidePanel)
        ]),
        _: 1
      }, 8, ["content-title"]);
    };
  }
});
const DIALOG_KEY = "global-model-selector";
const useModelSelectorDialog = /* @__PURE__ */ __name(() => {
  const dialogService = useDialogService();
  const dialogStore = useDialogStore();
  function hide() {
    dialogStore.closeDialog({ key: DIALOG_KEY });
  }
  __name(hide, "hide");
  function show() {
    dialogService.showLayoutDialog({
      key: DIALOG_KEY,
      component: _sfc_main$2,
      props: {
        onClose: hide
      }
    });
  }
  __name(show, "show");
  return {
    show,
    hide
  };
}, "useModelSelectorDialog");
function createModelNodeFromAsset(asset, options) {
  const validatedAsset = assetItemSchema.safeParse(asset);
  if (!validatedAsset.success) {
    const errorMessage = validatedAsset.error.errors.map((e) => `${e.path.join(".")}: ${e.message}`).join(", ");
    console.error("Invalid asset item:", errorMessage);
    return {
      success: false,
      error: {
        code: "INVALID_ASSET",
        message: "Asset schema validation failed",
        assetId: asset.id,
        details: { validationErrors: errorMessage }
      }
    };
  }
  const validAsset = validatedAsset.data;
  const userMetadata = validAsset.user_metadata;
  if (!userMetadata) {
    console.error(`Asset ${validAsset.id} missing required user_metadata`);
    return {
      success: false,
      error: {
        code: "INVALID_ASSET",
        message: "Asset missing required user_metadata",
        assetId: validAsset.id
      }
    };
  }
  const filename = userMetadata.filename;
  if (typeof filename !== "string" || filename.length === 0) {
    console.error(
      `Asset ${validAsset.id} has invalid user_metadata.filename (expected non-empty string, got ${typeof filename})`
    );
    return {
      success: false,
      error: {
        code: "INVALID_ASSET",
        message: `Invalid filename (expected non-empty string, got ${typeof filename})`,
        assetId: validAsset.id
      }
    };
  }
  if (validAsset.tags.length === 0) {
    console.error(
      `Asset ${validAsset.id} has no tags defined (expected at least one category tag)`
    );
    return {
      success: false,
      error: {
        code: "INVALID_ASSET",
        message: "Asset has no tags defined",
        assetId: validAsset.id
      }
    };
  }
  const category = validAsset.tags.find(
    (tag) => tag !== MODELS_TAG && tag !== MISSING_TAG
  );
  if (!category) {
    console.error(
      `Asset ${validAsset.id} has no valid category tag. Available tags: ${validAsset.tags.join(", ")} (expected tag other than '${MODELS_TAG}' or '${MISSING_TAG}')`
    );
    return {
      success: false,
      error: {
        code: "INVALID_ASSET",
        message: "Asset has no valid category tag",
        assetId: validAsset.id,
        details: { availableTags: validAsset.tags }
      }
    };
  }
  const modelToNodeStore = useModelToNodeStore();
  const provider = modelToNodeStore.getNodeProvider(category);
  if (!provider) {
    console.error(`No node provider registered for category: ${category}`);
    return {
      success: false,
      error: {
        code: "NO_PROVIDER",
        message: `No node provider registered for category: ${category}`,
        assetId: validAsset.id,
        details: { category }
      }
    };
  }
  const litegraphService = useLitegraphService();
  const pos = litegraphService.getCanvasCenter();
  const node = LiteGraph.createNode(
    provider.nodeDef.name,
    provider.nodeDef.display_name,
    { pos }
  );
  if (!node) {
    console.error(`Failed to create node for type: ${provider.nodeDef.name}`);
    return {
      success: false,
      error: {
        code: "NODE_CREATION_FAILED",
        message: `Failed to create node for type: ${provider.nodeDef.name}`,
        assetId: validAsset.id,
        details: { nodeType: provider.nodeDef.name }
      }
    };
  }
  const workflowStore = useWorkflowStore();
  const targetGraph = workflowStore.isSubgraphActive ? workflowStore.activeSubgraph : app.canvas.graph;
  if (!targetGraph) {
    console.error("No active graph available");
    return {
      success: false,
      error: {
        code: "NO_GRAPH",
        message: "No active graph available",
        assetId: validAsset.id
      }
    };
  }
  const widget = node.widgets?.find((w) => w.name === provider.key);
  if (!widget) {
    console.error(
      `Widget ${provider.key} not found on node ${provider.nodeDef.name}`
    );
    return {
      success: false,
      error: {
        code: "MISSING_WIDGET",
        message: `Widget ${provider.key} not found on node ${provider.nodeDef.name}`,
        assetId: validAsset.id,
        details: { widgetName: provider.key, nodeType: provider.nodeDef.name }
      }
    };
  }
  widget.value = filename;
  targetGraph.add(node);
  return { success: true, value: node };
}
__name(createModelNodeFromAsset, "createModelNodeFromAsset");
const ZENDESK_FIELDS = {
  /** Distribution tag (cloud vs OSS) */
  DISTRIBUTION: "tf_42243568391700",
  /** User email (anonymous requester) */
  ANONYMOUS_EMAIL: "tf_anonymous_requester_email",
  /** User email (authenticated) */
  EMAIL: "tf_40029135130388",
  /** User ID */
  USER_ID: "tf_42515251051412"
};
const SUPPORT_BASE_URL = "https://support.comfy.org/hc/en-us/requests/new";
function buildSupportUrl(params) {
  const searchParams = new URLSearchParams({
    [ZENDESK_FIELDS.DISTRIBUTION]: "oss"
  });
  if (params?.userEmail) {
    searchParams.append(ZENDESK_FIELDS.ANONYMOUS_EMAIL, params.userEmail);
    searchParams.append(ZENDESK_FIELDS.EMAIL, params.userEmail);
  }
  if (params?.userId) {
    searchParams.append(ZENDESK_FIELDS.USER_ID, params.userId);
  }
  return `${SUPPORT_BASE_URL}?${searchParams.toString()}`;
}
__name(buildSupportUrl, "buildSupportUrl");
const { isActiveSubscription, showSubscriptionDialog } = useSubscription();
const moveSelectedNodesVersionAdded = "1.22.2";
function useCoreCommands() {
  const workflowService = useWorkflowService();
  const workflowStore = useWorkflowStore();
  const dialogService = useDialogService();
  const colorPaletteStore = useColorPaletteStore();
  const firebaseAuthActions = useFirebaseAuthActions();
  const toastStore = useToastStore();
  const canvasStore = useCanvasStore();
  const executionStore = useExecutionStore();
  const { staticUrls, buildDocsUrl } = useExternalLink();
  const bottomPanelStore = useBottomPanelStore();
  const { getSelectedNodes, toggleSelectedNodesMode } = useSelectedLiteGraphItems();
  const getTracker = /* @__PURE__ */ __name(() => workflowStore.activeWorkflow?.changeTracker, "getTracker");
  const moveSelectedNodes = /* @__PURE__ */ __name((positionUpdater) => {
    const selectedNodes = getSelectedNodes();
    if (selectedNodes.length === 0) return;
    const gridSize = useSettingStore().get("Comfy.SnapToGrid.GridSize");
    selectedNodes.forEach((node) => {
      node.pos = positionUpdater(node.pos, gridSize);
    });
    app.canvas.state.selectionChanged = true;
    app.canvas.setDirty(true, true);
  }, "moveSelectedNodes");
  const commands = [
    {
      id: "Comfy.NewBlankWorkflow",
      icon: "pi pi-plus",
      label: "New Blank Workflow",
      menubarLabel: "New",
      category: "essentials",
      function: /* @__PURE__ */ __name(async () => {
        app.rootGraph._nodes.length > 0;
        await workflowService.loadBlankWorkflow();
      }, "function")
    },
    {
      id: "Comfy.OpenWorkflow",
      icon: "pi pi-folder-open",
      label: "Open Workflow",
      menubarLabel: "Open",
      category: "essentials",
      function: /* @__PURE__ */ __name(() => {
        app.ui.loadFile();
      }, "function")
    },
    {
      id: "Comfy.LoadDefaultWorkflow",
      icon: "pi pi-code",
      label: "Load Default Workflow",
      function: /* @__PURE__ */ __name(async () => {
        app.rootGraph._nodes.length > 0;
        await workflowService.loadDefaultWorkflow();
      }, "function")
    },
    {
      id: "Comfy.SaveWorkflow",
      icon: "pi pi-save",
      label: "Save Workflow",
      menubarLabel: "Save",
      category: "essentials",
      function: /* @__PURE__ */ __name(async () => {
        const workflow = useWorkflowStore().activeWorkflow;
        if (!workflow) return;
        await workflowService.saveWorkflow(workflow);
      }, "function")
    },
    {
      id: "Comfy.PublishSubgraph",
      icon: "pi pi-save",
      label: "Publish Subgraph",
      menubarLabel: "Publish",
      function: /* @__PURE__ */ __name(async () => {
        await useSubgraphStore().publishSubgraph();
      }, "function")
    },
    {
      id: "Comfy.SaveWorkflowAs",
      icon: "pi pi-save",
      label: "Save Workflow As",
      menubarLabel: "Save As",
      category: "essentials",
      function: /* @__PURE__ */ __name(async () => {
        const workflow = useWorkflowStore().activeWorkflow;
        if (!workflow) return;
        await workflowService.saveWorkflowAs(workflow);
      }, "function")
    },
    {
      id: "Comfy.ExportWorkflow",
      icon: "pi pi-download",
      label: "Export Workflow",
      menubarLabel: "Export",
      category: "essentials",
      function: /* @__PURE__ */ __name(async () => {
        await workflowService.exportWorkflow("workflow", "workflow");
      }, "function")
    },
    {
      id: "Comfy.ExportWorkflowAPI",
      icon: "pi pi-download",
      label: "Export Workflow (API Format)",
      menubarLabel: "Export (API)",
      function: /* @__PURE__ */ __name(async () => {
        await workflowService.exportWorkflow("workflow_api", "output");
      }, "function")
    },
    {
      id: "Comfy.Undo",
      icon: "pi pi-undo",
      label: "Undo",
      category: "essentials",
      function: /* @__PURE__ */ __name(async () => {
        await getTracker()?.undo?.();
      }, "function")
    },
    {
      id: "Comfy.Redo",
      icon: "pi pi-refresh",
      label: "Redo",
      category: "essentials",
      function: /* @__PURE__ */ __name(async () => {
        await getTracker()?.redo?.();
      }, "function")
    },
    {
      id: "Comfy.ClearWorkflow",
      icon: "pi pi-trash",
      label: "Clear Workflow",
      category: "essentials",
      function: /* @__PURE__ */ __name(() => {
        const settingStore = useSettingStore();
        if (!settingStore.get("Comfy.ConfirmClear") || confirm("Clear workflow?")) {
          app.clean();
          if (app.canvas.subgraph) {
            const subgraph = app.canvas.subgraph;
            const nonIoNodes = getAllNonIoNodesInSubgraph(subgraph);
            nonIoNodes.forEach((node) => subgraph.remove(node));
          }
          api.dispatchCustomEvent("graphCleared");
        }
      }, "function")
    },
    {
      id: "Comfy.Canvas.ResetView",
      icon: "pi pi-expand",
      label: "Reset View",
      function: /* @__PURE__ */ __name(() => {
        useLitegraphService().resetView();
      }, "function")
    },
    {
      id: "Comfy.OpenClipspace",
      icon: "pi pi-clipboard",
      label: "Clipspace",
      function: /* @__PURE__ */ __name(() => {
        app.openClipspace();
      }, "function")
    },
    {
      id: "Comfy.RefreshNodeDefinitions",
      icon: "pi pi-refresh",
      label: "Refresh Node Definitions",
      category: "essentials",
      function: /* @__PURE__ */ __name(async () => {
        await app.refreshComboInNodes();
      }, "function")
    },
    {
      id: "Comfy.Interrupt",
      icon: "pi pi-stop",
      label: "Interrupt",
      category: "essentials",
      function: /* @__PURE__ */ __name(async () => {
        await api.interrupt(executionStore.activePromptId);
        toastStore.add({
          severity: "info",
          summary: t("g.interrupted"),
          detail: t("toastMessages.interrupted"),
          life: 1e3
        });
      }, "function")
    },
    {
      id: "Comfy.ClearPendingTasks",
      icon: "pi pi-stop",
      label: "Clear Pending Tasks",
      category: "essentials",
      function: /* @__PURE__ */ __name(async () => {
        await useQueueStore().clear(["queue"]);
        toastStore.add({
          severity: "info",
          summary: t("g.confirmed"),
          detail: t("toastMessages.pendingTasksDeleted"),
          life: 3e3
        });
      }, "function")
    },
    {
      id: "Comfy.BrowseTemplates",
      icon: "pi pi-folder-open",
      label: "Browse Templates",
      function: /* @__PURE__ */ __name(() => {
        useWorkflowTemplateSelectorDialog().show();
      }, "function")
    },
    {
      id: "Comfy.Canvas.ZoomIn",
      icon: "pi pi-plus",
      label: "Zoom In",
      category: "view-controls",
      function: /* @__PURE__ */ __name(() => {
        const ds = app.canvas.ds;
        ds.changeScale(
          ds.scale * 1.1,
          ds.element ? [ds.element.width / 2, ds.element.height / 2] : void 0
        );
        app.canvas.setDirty(true, true);
      }, "function")
    },
    {
      id: "Comfy.Canvas.ZoomOut",
      icon: "pi pi-minus",
      label: "Zoom Out",
      category: "view-controls",
      function: /* @__PURE__ */ __name(() => {
        const ds = app.canvas.ds;
        ds.changeScale(
          ds.scale / 1.1,
          ds.element ? [ds.element.width / 2, ds.element.height / 2] : void 0
        );
        app.canvas.setDirty(true, true);
      }, "function")
    },
    {
      id: "Experimental.ToggleVueNodes",
      label: /* @__PURE__ */ __name(() => `Experimental: ${useSettingStore().get("Comfy.VueNodes.Enabled") ? "Disable" : "Enable"} Nodes 2.0`, "label"),
      function: /* @__PURE__ */ __name(async () => {
        const settingStore = useSettingStore();
        const current = settingStore.get("Comfy.VueNodes.Enabled") ?? false;
        await settingStore.set("Comfy.VueNodes.Enabled", !current);
      }, "function")
    },
    {
      id: "Comfy.Canvas.FitView",
      icon: "pi pi-expand",
      label: "Fit view to selected nodes",
      menubarLabel: "Zoom to fit",
      category: "view-controls",
      function: /* @__PURE__ */ __name(() => {
        if (app.canvas.empty) {
          toastStore.add({
            severity: "error",
            summary: t("toastMessages.emptyCanvas"),
            life: 3e3
          });
          return;
        }
        app.canvas.fitViewToSelectionAnimated();
      }, "function")
    },
    {
      id: "Comfy.Canvas.ToggleLock",
      icon: "pi pi-lock",
      label: "Canvas Toggle Lock",
      category: "view-controls",
      function: /* @__PURE__ */ __name(() => {
        app.canvas.state.readOnly = !app.canvas.state.readOnly;
      }, "function")
    },
    {
      id: "Comfy.Canvas.Lock",
      icon: "pi pi-lock",
      label: "Lock Canvas",
      category: "view-controls",
      function: /* @__PURE__ */ __name(() => {
        app.canvas.state.readOnly = true;
      }, "function")
    },
    {
      id: "Comfy.Canvas.Unlock",
      icon: "pi pi-lock-open",
      label: "Unlock Canvas",
      function: /* @__PURE__ */ __name(() => {
        app.canvas.state.readOnly = false;
      }, "function")
    },
    {
      id: "Comfy.Canvas.ToggleLinkVisibility",
      icon: "pi pi-eye",
      label: "Canvas Toggle Link Visibility",
      menubarLabel: "Node Links",
      versionAdded: "1.3.6",
      function: (() => {
        const settingStore = useSettingStore();
        let lastLinksRenderMode = LiteGraph.SPLINE_LINK;
        return async () => {
          const currentMode = settingStore.get("Comfy.LinkRenderMode");
          if (currentMode === LiteGraph.HIDDEN_LINK) {
            await settingStore.set("Comfy.LinkRenderMode", lastLinksRenderMode);
          } else {
            lastLinksRenderMode = currentMode;
            await settingStore.set(
              "Comfy.LinkRenderMode",
              LiteGraph.HIDDEN_LINK
            );
          }
        };
      })(),
      active: /* @__PURE__ */ __name(() => useSettingStore().get("Comfy.LinkRenderMode") !== LiteGraph.HIDDEN_LINK, "active")
    },
    {
      id: "Comfy.Canvas.ToggleMinimap",
      icon: "pi pi-map",
      label: "Canvas Toggle Minimap",
      menubarLabel: "Minimap",
      versionAdded: "1.24.1",
      function: /* @__PURE__ */ __name(async () => {
        const settingStore = useSettingStore();
        await settingStore.set(
          "Comfy.Minimap.Visible",
          !settingStore.get("Comfy.Minimap.Visible")
        );
      }, "function"),
      active: /* @__PURE__ */ __name(() => useSettingStore().get("Comfy.Minimap.Visible"), "active")
    },
    {
      id: "Comfy.QueuePrompt",
      icon: "pi pi-play",
      label: "Queue Prompt",
      versionAdded: "1.3.7",
      category: "essentials",
      function: /* @__PURE__ */ __name(async (metadata) => {
        if (!isActiveSubscription.value) {
          showSubscriptionDialog();
          return;
        }
        const batchCount = useQueueSettingsStore().batchCount;
        await app.queuePrompt(0, batchCount);
      }, "function")
    },
    {
      id: "Comfy.QueuePromptFront",
      icon: "pi pi-play",
      label: "Queue Prompt (Front)",
      versionAdded: "1.3.7",
      category: "essentials",
      function: /* @__PURE__ */ __name(async (metadata) => {
        if (!isActiveSubscription.value) {
          showSubscriptionDialog();
          return;
        }
        const batchCount = useQueueSettingsStore().batchCount;
        await app.queuePrompt(-1, batchCount);
      }, "function")
    },
    {
      id: "Comfy.QueueSelectedOutputNodes",
      icon: "pi pi-play",
      label: "Queue Selected Output Nodes",
      versionAdded: "1.19.6",
      function: /* @__PURE__ */ __name(async (metadata) => {
        if (!isActiveSubscription.value) {
          showSubscriptionDialog();
          return;
        }
        const batchCount = useQueueSettingsStore().batchCount;
        const selectedNodes = getSelectedNodes();
        const selectedOutputNodes = filterOutputNodes(selectedNodes);
        if (selectedOutputNodes.length === 0) {
          toastStore.add({
            severity: "error",
            summary: t("toastMessages.nothingToQueue"),
            detail: t("toastMessages.pleaseSelectOutputNodes"),
            life: 3e3
          });
          return;
        }
        const executionIds = getExecutionIdsForSelectedNodes(selectedOutputNodes);
        if (executionIds.length === 0) {
          toastStore.add({
            severity: "error",
            summary: t("toastMessages.failedToQueue"),
            detail: t("toastMessages.failedExecutionPathResolution"),
            life: 3e3
          });
          return;
        }
        await app.queuePrompt(0, batchCount, executionIds);
      }, "function")
    },
    {
      id: "Comfy.ShowSettingsDialog",
      icon: "pi pi-cog",
      label: "Show Settings Dialog",
      versionAdded: "1.3.7",
      category: "view-controls",
      function: /* @__PURE__ */ __name(() => {
        dialogService.showSettingsDialog();
      }, "function")
    },
    {
      id: "Comfy.Graph.GroupSelectedNodes",
      icon: "pi pi-sitemap",
      label: "Group Selected Nodes",
      versionAdded: "1.3.7",
      category: "essentials",
      function: /* @__PURE__ */ __name(() => {
        const { canvas } = app;
        if (!canvas.selectedItems?.size) {
          toastStore.add({
            severity: "error",
            summary: t("toastMessages.nothingToGroup"),
            detail: t("toastMessages.pleaseSelectNodesToGroup"),
            life: 3e3
          });
          return;
        }
        const group = new LGraphGroup();
        const padding = useSettingStore().get(
          "Comfy.GroupSelectedNodes.Padding"
        );
        group.resizeTo(canvas.selectedItems, padding);
        canvas.graph?.add(group);
        group.recomputeInsideNodes();
        useTitleEditorStore().titleEditorTarget = group;
      }, "function")
    },
    {
      id: "Workspace.NextOpenedWorkflow",
      icon: "pi pi-step-forward",
      label: "Next Opened Workflow",
      versionAdded: "1.3.9",
      function: /* @__PURE__ */ __name(async () => {
        await workflowService.loadNextOpenedWorkflow();
      }, "function")
    },
    {
      id: "Workspace.PreviousOpenedWorkflow",
      icon: "pi pi-step-backward",
      label: "Previous Opened Workflow",
      versionAdded: "1.3.9",
      function: /* @__PURE__ */ __name(async () => {
        await workflowService.loadPreviousOpenedWorkflow();
      }, "function")
    },
    {
      id: "Comfy.Canvas.ToggleSelectedNodes.Mute",
      icon: "pi pi-volume-off",
      label: "Mute/Unmute Selected Nodes",
      versionAdded: "1.3.11",
      category: "essentials",
      function: /* @__PURE__ */ __name(() => {
        toggleSelectedNodesMode(LGraphEventMode.NEVER);
        app.canvas.setDirty(true, true);
      }, "function")
    },
    {
      id: "Comfy.Canvas.ToggleSelectedNodes.Bypass",
      icon: "pi pi-shield",
      label: "Bypass/Unbypass Selected Nodes",
      versionAdded: "1.3.11",
      category: "essentials",
      function: /* @__PURE__ */ __name(() => {
        toggleSelectedNodesMode(LGraphEventMode.BYPASS);
        app.canvas.setDirty(true, true);
      }, "function")
    },
    {
      id: "Comfy.Canvas.ToggleSelectedNodes.Pin",
      icon: "pi pi-pin",
      label: "Pin/Unpin Selected Nodes",
      versionAdded: "1.3.11",
      category: "essentials",
      function: /* @__PURE__ */ __name(() => {
        getSelectedNodes().forEach((node) => {
          node.pin(!node.pinned);
        });
        app.canvas.setDirty(true, true);
      }, "function")
    },
    {
      id: "Comfy.Canvas.ToggleSelected.Pin",
      icon: "pi pi-pin",
      label: "Pin/Unpin Selected Items",
      versionAdded: "1.3.33",
      function: /* @__PURE__ */ __name(() => {
        for (const item of app.canvas.selectedItems) {
          if (item instanceof LGraphNode || item instanceof LGraphGroup) {
            item.pin(!item.pinned);
          }
        }
        app.canvas.setDirty(true, true);
      }, "function")
    },
    {
      id: "Comfy.Canvas.Resize",
      icon: "pi pi-minus",
      label: "Resize Selected Nodes",
      versionAdded: "",
      function: /* @__PURE__ */ __name(() => {
        getSelectedNodes().forEach((node) => {
          const optimalSize = node.computeSize();
          node.setSize([optimalSize[0], optimalSize[1]]);
        });
        app.canvas.setDirty(true, true);
      }, "function")
    },
    {
      id: "Comfy.Canvas.ToggleSelectedNodes.Collapse",
      icon: "pi pi-minus",
      label: "Collapse/Expand Selected Nodes",
      versionAdded: "1.3.11",
      function: /* @__PURE__ */ __name(() => {
        getSelectedNodes().forEach((node) => {
          node.collapse();
        });
        app.canvas.setDirty(true, true);
      }, "function")
    },
    {
      id: "Comfy.ToggleTheme",
      icon: "pi pi-moon",
      label: "Toggle Theme (Dark/Light)",
      versionAdded: "1.3.12",
      function: (() => {
        let previousDarkTheme = DEFAULT_DARK_COLOR_PALETTE.id;
        let previousLightTheme = DEFAULT_LIGHT_COLOR_PALETTE.id;
        return async () => {
          const settingStore = useSettingStore();
          const theme = colorPaletteStore.completedActivePalette;
          if (theme.light_theme) {
            previousLightTheme = theme.id;
            await settingStore.set("Comfy.ColorPalette", previousDarkTheme);
          } else {
            previousDarkTheme = theme.id;
            await settingStore.set("Comfy.ColorPalette", previousLightTheme);
          }
        };
      })()
    },
    {
      id: "Workspace.ToggleBottomPanel",
      icon: "pi pi-list",
      label: "Toggle Bottom Panel",
      menubarLabel: "Bottom Panel",
      versionAdded: "1.3.22",
      category: "view-controls",
      function: /* @__PURE__ */ __name(() => {
        bottomPanelStore.toggleBottomPanel();
      }, "function"),
      active: /* @__PURE__ */ __name(() => bottomPanelStore.bottomPanelVisible, "active")
    },
    {
      id: "Workspace.ToggleFocusMode",
      icon: "pi pi-eye",
      label: "Toggle Focus Mode",
      menubarLabel: "Focus Mode",
      versionAdded: "1.3.27",
      category: "view-controls",
      function: /* @__PURE__ */ __name(() => {
        useWorkspaceStore().toggleFocusMode();
      }, "function"),
      active: /* @__PURE__ */ __name(() => useWorkspaceStore().focusMode, "active")
    },
    {
      id: "Comfy.Graph.FitGroupToContents",
      icon: "pi pi-expand",
      label: "Fit Group To Contents",
      versionAdded: "1.4.9",
      function: /* @__PURE__ */ __name(() => {
        for (const group of app.canvas.selectedItems) {
          if (group instanceof LGraphGroup) {
            group.recomputeInsideNodes();
            const padding = useSettingStore().get(
              "Comfy.GroupSelectedNodes.Padding"
            );
            group.resizeTo(group.children, padding);
            app.canvas.setDirty(false, true);
          }
        }
      }, "function")
    },
    {
      id: "Comfy.Help.OpenComfyUIIssues",
      icon: "pi pi-github",
      label: "Open ComfyUI Issues",
      menubarLabel: "ComfyUI Issues",
      versionAdded: "1.5.5",
      function: /* @__PURE__ */ __name(() => {
        window.open(staticUrls.githubIssues, "_blank");
      }, "function")
    },
    {
      id: "Comfy.Help.OpenComfyUIDocs",
      icon: "pi pi-info-circle",
      label: "Open ComfyUI Docs",
      menubarLabel: "ComfyUI Docs",
      versionAdded: "1.5.5",
      function: /* @__PURE__ */ __name(() => {
        window.open(buildDocsUrl("/", { includeLocale: true }), "_blank");
      }, "function")
    },
    {
      id: "Comfy.Help.OpenComfyOrgDiscord",
      icon: "pi pi-discord",
      label: "Open Comfy-Org Discord",
      menubarLabel: "Comfy-Org Discord",
      versionAdded: "1.5.5",
      function: /* @__PURE__ */ __name(() => {
        window.open(staticUrls.discord, "_blank");
      }, "function")
    },
    {
      id: "Workspace.SearchBox.Toggle",
      icon: "pi pi-search",
      label: "Toggle Search Box",
      versionAdded: "1.5.7",
      function: /* @__PURE__ */ __name(() => {
        useSearchBoxStore().toggleVisible();
      }, "function")
    },
    {
      id: "Comfy.Help.AboutComfyUI",
      icon: "pi pi-info-circle",
      label: "Open About ComfyUI",
      menubarLabel: "About ComfyUI",
      versionAdded: "1.6.4",
      function: /* @__PURE__ */ __name(() => {
        dialogService.showSettingsDialog("about");
      }, "function")
    },
    {
      id: "Comfy.DuplicateWorkflow",
      icon: "pi pi-clone",
      label: "Duplicate Current Workflow",
      versionAdded: "1.6.15",
      function: /* @__PURE__ */ __name(async () => {
        await workflowService.duplicateWorkflow(workflowStore.activeWorkflow);
      }, "function")
    },
    {
      id: "Workspace.CloseWorkflow",
      icon: "pi pi-times",
      label: "Close Current Workflow",
      versionAdded: "1.7.3",
      function: /* @__PURE__ */ __name(async () => {
        if (workflowStore.activeWorkflow)
          await workflowService.closeWorkflow(workflowStore.activeWorkflow);
      }, "function")
    },
    {
      id: "Comfy.ContactSupport",
      icon: "pi pi-question",
      label: "Contact Support",
      versionAdded: "1.17.8",
      function: /* @__PURE__ */ __name(() => {
        const { userEmail, resolvedUserInfo } = useCurrentUser();
        const supportUrl = buildSupportUrl({
          userEmail: userEmail.value,
          userId: resolvedUserInfo.value?.id
        });
        window.open(supportUrl, "_blank");
      }, "function")
    },
    {
      id: "Comfy.Help.OpenComfyUIForum",
      icon: "pi pi-comments",
      label: "Open ComfyUI Forum",
      menubarLabel: "ComfyUI Forum",
      versionAdded: "1.8.2",
      function: /* @__PURE__ */ __name(() => {
        window.open(staticUrls.forum, "_blank");
      }, "function")
    },
    {
      id: "Comfy.Canvas.DeleteSelectedItems",
      icon: "pi pi-trash",
      label: "Delete Selected Items",
      versionAdded: "1.10.5",
      function: /* @__PURE__ */ __name(() => {
        app.canvas.deleteSelected();
        app.canvas.setDirty(true, true);
      }, "function")
    },
    {
      id: "Comfy.Manager.CustomNodesManager.ShowCustomNodesMenu",
      icon: "pi pi-puzzle",
      label: "Custom Nodes Manager",
      versionAdded: "1.12.10",
      function: /* @__PURE__ */ __name(async () => {
        await useManagerState().openManager({
          showToastOnLegacyError: true
        });
      }, "function")
    },
    {
      id: "Comfy.Manager.ShowUpdateAvailablePacks",
      icon: "pi pi-sync",
      label: "Check for Custom Node Updates",
      versionAdded: "1.17.0",
      function: /* @__PURE__ */ __name(async () => {
        const managerState = useManagerState();
        const state = managerState.managerUIState.value;
        if (state === ManagerUIState.DISABLED) {
          toastStore.add({
            severity: "error",
            summary: t("g.error"),
            detail: t("manager.notAvailable"),
            life: 3e3
          });
          return;
        }
        await managerState.openManager({
          initialTab: ManagerTab.UpdateAvailable,
          showToastOnLegacyError: false
        });
      }, "function")
    },
    {
      id: "Comfy.Manager.ShowMissingPacks",
      icon: "pi pi-exclamation-circle",
      label: "Install Missing Custom Nodes",
      versionAdded: "1.17.0",
      function: /* @__PURE__ */ __name(async () => {
        await useManagerState().openManager({
          initialTab: ManagerTab.Missing,
          showToastOnLegacyError: false
        });
      }, "function")
    },
    {
      id: "Comfy.Manager.ToggleManagerProgressDialog",
      icon: "pi pi-spinner",
      label: "Toggle the Custom Nodes Manager Progress Bar",
      versionAdded: "1.13.9",
      function: /* @__PURE__ */ __name(() => {
        dialogService.toggleManagerProgressDialog();
      }, "function")
    },
    {
      id: "Comfy.User.OpenSignInDialog",
      icon: "pi pi-user",
      label: "Open Sign In Dialog",
      versionAdded: "1.17.6",
      function: /* @__PURE__ */ __name(async () => {
        await dialogService.showSignInDialog();
      }, "function")
    },
    {
      id: "Comfy.User.SignOut",
      icon: "pi pi-sign-out",
      label: "Sign Out",
      versionAdded: "1.18.1",
      function: /* @__PURE__ */ __name(async () => {
        await firebaseAuthActions.logout();
      }, "function")
    },
    {
      id: "Comfy.Canvas.MoveSelectedNodes.Up",
      icon: "pi pi-arrow-up",
      label: "Move Selected Nodes Up",
      versionAdded: moveSelectedNodesVersionAdded,
      function: /* @__PURE__ */ __name(() => moveSelectedNodes(([x, y], gridSize) => [x, y - gridSize]), "function")
    },
    {
      id: "Comfy.Canvas.MoveSelectedNodes.Down",
      icon: "pi pi-arrow-down",
      label: "Move Selected Nodes Down",
      versionAdded: moveSelectedNodesVersionAdded,
      function: /* @__PURE__ */ __name(() => moveSelectedNodes(([x, y], gridSize) => [x, y + gridSize]), "function")
    },
    {
      id: "Comfy.Canvas.MoveSelectedNodes.Left",
      icon: "pi pi-arrow-left",
      label: "Move Selected Nodes Left",
      versionAdded: moveSelectedNodesVersionAdded,
      function: /* @__PURE__ */ __name(() => moveSelectedNodes(([x, y], gridSize) => [x - gridSize, y]), "function")
    },
    {
      id: "Comfy.Canvas.MoveSelectedNodes.Right",
      icon: "pi pi-arrow-right",
      label: "Move Selected Nodes Right",
      versionAdded: moveSelectedNodesVersionAdded,
      function: /* @__PURE__ */ __name(() => moveSelectedNodes(([x, y], gridSize) => [x + gridSize, y]), "function")
    },
    {
      id: "Comfy.Graph.ConvertToSubgraph",
      icon: "icon-[lucide--shrink]",
      label: "Convert Selection to Subgraph",
      versionAdded: "1.20.1",
      category: "essentials",
      function: /* @__PURE__ */ __name(() => {
        const canvas = canvasStore.getCanvas();
        const graph = canvas.subgraph ?? canvas.graph;
        if (!graph) throw new TypeError("Canvas has no graph or subgraph set.");
        const res = graph.convertToSubgraph(canvas.selectedItems);
        if (!res) {
          toastStore.add({
            severity: "error",
            summary: t("toastMessages.cannotCreateSubgraph"),
            detail: t("toastMessages.failedToConvertToSubgraph"),
            life: 3e3
          });
          return;
        }
        const { node } = res;
        canvas.select(node);
        canvasStore.updateSelectedItems();
      }, "function")
    },
    {
      id: "Comfy.Graph.UnpackSubgraph",
      icon: "icon-[lucide--expand]",
      label: "Unpack the selected Subgraph",
      versionAdded: "1.26.3",
      function: /* @__PURE__ */ __name(() => {
        const { unpackSubgraph } = useSubgraphOperations();
        unpackSubgraph();
      }, "function")
    },
    {
      id: "Comfy.Graph.EditSubgraphWidgets",
      label: "Edit Subgraph Widgets",
      icon: "icon-[lucide--settings-2]",
      versionAdded: "1.28.5",
      function: /* @__PURE__ */ __name(() => {
        useRightSidePanelStore().openPanel("subgraph");
      }, "function")
    },
    {
      id: "Comfy.Graph.ToggleWidgetPromotion",
      icon: "icon-[lucide--arrow-left-right]",
      label: "Toggle promotion of hovered widget",
      versionAdded: "1.30.1",
      function: tryToggleWidgetPromotion
    },
    {
      id: "Comfy.OpenManagerDialog",
      icon: "mdi mdi-puzzle-outline",
      label: "Manager",
      function: /* @__PURE__ */ __name(async () => {
        await useManagerState().openManager({
          initialTab: ManagerTab.All,
          showToastOnLegacyError: false
        });
      }, "function")
    },
    {
      id: "Comfy.ToggleHelpCenter",
      icon: "pi pi-question-circle",
      label: "Help Center",
      function: /* @__PURE__ */ __name(() => {
        useHelpCenterStore().toggle();
      }, "function"),
      active: /* @__PURE__ */ __name(() => useHelpCenterStore().isVisible, "active")
    },
    {
      id: "Comfy.ToggleCanvasInfo",
      icon: "pi pi-info-circle",
      label: "Canvas Performance",
      function: /* @__PURE__ */ __name(async () => {
        const settingStore = useSettingStore();
        const currentValue = settingStore.get("Comfy.Graph.CanvasInfo");
        await settingStore.set("Comfy.Graph.CanvasInfo", !currentValue);
      }, "function"),
      active: /* @__PURE__ */ __name(() => useSettingStore().get("Comfy.Graph.CanvasInfo"), "active")
    },
    {
      id: "Workspace.ToggleBottomPanel.Shortcuts",
      icon: "pi pi-key",
      label: "Show Keybindings Dialog",
      versionAdded: "1.24.1",
      category: "view-controls",
      function: /* @__PURE__ */ __name(() => {
        bottomPanelStore.togglePanel("shortcuts");
      }, "function")
    },
    {
      id: "Comfy.Graph.ExitSubgraph",
      icon: "pi pi-arrow-up",
      label: "Exit Subgraph",
      versionAdded: "1.20.1",
      function: /* @__PURE__ */ __name(() => {
        const canvas = useCanvasStore().getCanvas();
        const navigationStore = useSubgraphNavigationStore();
        if (!canvas.graph) return;
        canvas.setGraph(
          navigationStore.navigationStack.at(-2) ?? canvas.graph.rootGraph
        );
      }, "function")
    },
    {
      id: "Comfy.Dev.ShowModelSelector",
      icon: "pi pi-box",
      label: "Show Model Selector (Dev)",
      versionAdded: "1.26.2",
      category: "view-controls",
      function: /* @__PURE__ */ __name(() => {
        const modelSelectorDialog = useModelSelectorDialog();
        modelSelectorDialog.show();
      }, "function")
    },
    {
      id: "Comfy.Manager.CustomNodesManager.ShowLegacyCustomNodesMenu",
      icon: "pi pi-bars",
      label: "Custom Nodes (Legacy)",
      versionAdded: "1.16.4",
      function: /* @__PURE__ */ __name(async () => {
        await useManagerState().openManager({
          legacyCommand: "Comfy.Manager.CustomNodesManager.ToggleVisibility",
          showToastOnLegacyError: true,
          isLegacyOnly: true
        });
      }, "function")
    },
    {
      id: "Comfy.Manager.ShowLegacyManagerMenu",
      icon: "mdi mdi-puzzle",
      label: "Manager Menu (Legacy)",
      versionAdded: "1.16.4",
      function: /* @__PURE__ */ __name(async () => {
        await useManagerState().openManager({
          showToastOnLegacyError: true,
          isLegacyOnly: true
        });
      }, "function")
    },
    {
      id: "Comfy.Memory.UnloadModels",
      icon: "mdi mdi-vacuum-outline",
      label: "Unload Models",
      versionAdded: "1.16.4",
      function: /* @__PURE__ */ __name(async () => {
        if (!useSettingStore().get("Comfy.Memory.AllowManualUnload")) {
          useToastStore().add({
            severity: "error",
            summary: t("g.error"),
            detail: t("g.commandProhibited", {
              command: "Comfy.Memory.UnloadModels"
            }),
            life: 3e3
          });
          return;
        }
        await api.freeMemory({ freeExecutionCache: false });
      }, "function")
    },
    {
      id: "Comfy.Memory.UnloadModelsAndExecutionCache",
      icon: "mdi mdi-vacuum-outline",
      label: "Unload Models and Execution Cache",
      versionAdded: "1.16.4",
      function: /* @__PURE__ */ __name(async () => {
        if (!useSettingStore().get("Comfy.Memory.AllowManualUnload")) {
          useToastStore().add({
            severity: "error",
            summary: t("g.error"),
            detail: t("g.commandProhibited", {
              command: "Comfy.Memory.UnloadModelsAndExecutionCache"
            }),
            life: 3e3
          });
          return;
        }
        await api.freeMemory({ freeExecutionCache: true });
      }, "function")
    },
    {
      id: "Comfy.BrowseModelAssets",
      icon: "pi pi-folder-open",
      label: "Experimental: Browse Model Assets",
      versionAdded: "1.28.3",
      function: /* @__PURE__ */ __name(async () => {
        if (!useSettingStore().get("Comfy.Assets.UseAssetAPI")) {
          const confirmed = await dialogService.confirm({
            title: "Enable Asset API",
            message: "The Asset API is currently disabled. Would you like to enable it?",
            type: "default"
          });
          if (!confirmed) return;
          const settingStore = useSettingStore();
          await settingStore.set("Comfy.Assets.UseAssetAPI", true);
          await workflowService.reloadCurrentWorkflow();
        }
        const assetBrowserDialog = useAssetBrowserDialog();
        await assetBrowserDialog.browse({
          assetType: "models",
          title: t("sideToolbar.modelLibrary"),
          onAssetSelected: /* @__PURE__ */ __name((asset) => {
            const result = createModelNodeFromAsset(asset);
            if (!result.success) {
              toastStore.add({
                severity: "error",
                summary: t("g.error"),
                detail: t("assetBrowser.failedToCreateNode")
              });
              console.error("Node creation failed:", result.error);
            }
          }, "onAssetSelected")
        });
      }, "function")
    },
    {
      id: "Comfy.ToggleAssetAPI",
      icon: "pi pi-database",
      label: /* @__PURE__ */ __name(() => `Experimental: ${useSettingStore().get("Comfy.Assets.UseAssetAPI") ? "Disable" : "Enable"} AssetAPI`, "label"),
      function: /* @__PURE__ */ __name(async () => {
        const settingStore = useSettingStore();
        const current = settingStore.get("Comfy.Assets.UseAssetAPI") ?? false;
        await settingStore.set("Comfy.Assets.UseAssetAPI", !current);
        await useWorkflowService().reloadCurrentWorkflow();
      }, "function")
    },
    {
      id: "Comfy.ToggleLinear",
      icon: "pi pi-database",
      label: "toggle linear mode",
      function: /* @__PURE__ */ __name(() => canvasStore.linearMode = !canvasStore.linearMode, "function")
    }
  ];
  return commands.map((command) => ({ ...command, source: "System" }));
}
__name(useCoreCommands, "useCoreCommands");
const useProgressFavicon = /* @__PURE__ */ __name(() => {
  const defaultFavicon = "/assets/images/favicon_progress_16x16/frame_9.png";
  const favicon = useFavicon(defaultFavicon);
  const executionStore = useExecutionStore();
  const totalFrames = 10;
  watch(
    [() => executionStore.executionProgress, () => executionStore.isIdle],
    ([progress, isIdle]) => {
      if (isIdle) {
        favicon.value = defaultFavicon;
      } else {
        const frame = Math.min(
          Math.max(0, Math.floor(progress * totalFrames)),
          totalFrames - 1
        );
        favicon.value = `/assets/images/favicon_progress_16x16/frame_${frame}.png`;
      }
    }
  );
}, "useProgressFavicon");
var LatentPreviewMethod = /* @__PURE__ */ ((LatentPreviewMethod2) => {
  LatentPreviewMethod2["NoPreviews"] = "none";
  LatentPreviewMethod2["Auto"] = "auto";
  LatentPreviewMethod2["Latent2RGB"] = "latent2rgb";
  LatentPreviewMethod2["TAESD"] = "taesd";
  return LatentPreviewMethod2;
})(LatentPreviewMethod || {});
var LogLevel = /* @__PURE__ */ ((LogLevel2) => {
  LogLevel2["DEBUG"] = "DEBUG";
  LogLevel2["INFO"] = "INFO";
  LogLevel2["WARNING"] = "WARNING";
  LogLevel2["ERROR"] = "ERROR";
  LogLevel2["CRITICAL"] = "CRITICAL";
  return LogLevel2;
})(LogLevel || {});
var HashFunction = /* @__PURE__ */ ((HashFunction2) => {
  HashFunction2["MD5"] = "md5";
  HashFunction2["SHA1"] = "sha1";
  HashFunction2["SHA256"] = "sha256";
  HashFunction2["SHA512"] = "sha512";
  return HashFunction2;
})(HashFunction || {});
var CudaMalloc = /* @__PURE__ */ ((CudaMalloc2) => {
  CudaMalloc2["Auto"] = "auto";
  CudaMalloc2["Disable"] = "disable";
  CudaMalloc2["Enable"] = "enable";
  return CudaMalloc2;
})(CudaMalloc || {});
var FloatingPointPrecision = /* @__PURE__ */ ((FloatingPointPrecision2) => {
  FloatingPointPrecision2["AUTO"] = "auto";
  FloatingPointPrecision2["FP64"] = "fp64";
  FloatingPointPrecision2["FP32"] = "fp32";
  FloatingPointPrecision2["FP16"] = "fp16";
  FloatingPointPrecision2["BF16"] = "bf16";
  FloatingPointPrecision2["FP8E4M3FN"] = "fp8_e4m3fn";
  FloatingPointPrecision2["FP8E5M2"] = "fp8_e5m2";
  return FloatingPointPrecision2;
})(FloatingPointPrecision || {});
var CrossAttentionMethod = /* @__PURE__ */ ((CrossAttentionMethod2) => {
  CrossAttentionMethod2["Auto"] = "auto";
  CrossAttentionMethod2["Split"] = "split";
  CrossAttentionMethod2["Quad"] = "quad";
  CrossAttentionMethod2["Pytorch"] = "pytorch";
  return CrossAttentionMethod2;
})(CrossAttentionMethod || {});
var VramManagement = /* @__PURE__ */ ((VramManagement2) => {
  VramManagement2["Auto"] = "auto";
  VramManagement2["GPUOnly"] = "gpu-only";
  VramManagement2["HighVram"] = "highvram";
  VramManagement2["NormalVram"] = "normalvram";
  VramManagement2["LowVram"] = "lowvram";
  VramManagement2["NoVram"] = "novram";
  VramManagement2["CPU"] = "cpu";
  return VramManagement2;
})(VramManagement || {});
const SERVER_CONFIG_ITEMS = [
  // Network settings
  {
    id: "listen",
    name: "Host: The IP address to listen on",
    category: ["Network"],
    type: "text",
    defaultValue: "127.0.0.1"
  },
  {
    id: "port",
    name: "Port: The port to listen on",
    category: ["Network"],
    type: "number",
    // The default launch port for desktop app is 8000 instead of 8188.
    defaultValue: 8e3
  },
  {
    id: "tls-keyfile",
    name: "TLS Key File: Path to TLS key file for HTTPS",
    category: ["Network"],
    type: "text",
    defaultValue: ""
  },
  {
    id: "tls-certfile",
    name: "TLS Certificate File: Path to TLS certificate file for HTTPS",
    category: ["Network"],
    type: "text",
    defaultValue: ""
  },
  {
    id: "enable-cors-header",
    name: 'Enable CORS header: Use "*" for all origins or specify domain',
    category: ["Network"],
    type: "text",
    defaultValue: ""
  },
  {
    id: "max-upload-size",
    name: "Maximum upload size (MB)",
    category: ["Network"],
    type: "number",
    defaultValue: 100
  },
  // CUDA settings
  {
    id: "cuda-device",
    name: "CUDA device index to use",
    category: ["CUDA"],
    type: "number",
    defaultValue: null
  },
  {
    id: "cuda-malloc",
    name: "Use CUDA malloc for memory allocation",
    category: ["CUDA"],
    type: "combo",
    options: Object.values(CudaMalloc),
    defaultValue: CudaMalloc.Auto,
    getValue: /* @__PURE__ */ __name((value) => {
      switch (value) {
        case CudaMalloc.Auto:
          return {};
        case CudaMalloc.Enable:
          return {
            ["cuda-malloc"]: true
          };
        case CudaMalloc.Disable:
          return {
            ["disable-cuda-malloc"]: true
          };
      }
    }, "getValue")
  },
  // Precision settings
  {
    id: "global-precision",
    name: "Global floating point precision",
    category: ["Inference"],
    type: "combo",
    options: [
      FloatingPointPrecision.AUTO,
      FloatingPointPrecision.FP32,
      FloatingPointPrecision.FP16
    ],
    defaultValue: FloatingPointPrecision.AUTO,
    tooltip: "Global floating point precision",
    getValue: /* @__PURE__ */ __name((value) => {
      switch (value) {
        case FloatingPointPrecision.AUTO:
          return {};
        case FloatingPointPrecision.FP32:
          return {
            ["force-fp32"]: true
          };
        case FloatingPointPrecision.FP16:
          return {
            ["force-fp16"]: true
          };
        default:
          return {};
      }
    }, "getValue")
  },
  // UNET precision
  {
    id: "unet-precision",
    name: "UNET precision",
    category: ["Inference"],
    type: "combo",
    options: [
      FloatingPointPrecision.AUTO,
      FloatingPointPrecision.FP64,
      FloatingPointPrecision.FP32,
      FloatingPointPrecision.FP16,
      FloatingPointPrecision.BF16,
      FloatingPointPrecision.FP8E4M3FN,
      FloatingPointPrecision.FP8E5M2
    ],
    defaultValue: FloatingPointPrecision.AUTO,
    tooltip: "UNET precision",
    getValue: /* @__PURE__ */ __name((value) => {
      switch (value) {
        case FloatingPointPrecision.AUTO:
          return {};
        default:
          return {
            [`${value.toLowerCase()}-unet`]: true
          };
      }
    }, "getValue")
  },
  // VAE settings
  {
    id: "vae-precision",
    name: "VAE precision",
    category: ["Inference"],
    type: "combo",
    options: [
      FloatingPointPrecision.AUTO,
      FloatingPointPrecision.FP16,
      FloatingPointPrecision.FP32,
      FloatingPointPrecision.BF16
    ],
    defaultValue: FloatingPointPrecision.AUTO,
    tooltip: "VAE precision",
    getValue: /* @__PURE__ */ __name((value) => {
      switch (value) {
        case FloatingPointPrecision.AUTO:
          return {};
        default:
          return {
            [`${value.toLowerCase()}-vae`]: true
          };
      }
    }, "getValue")
  },
  {
    id: "cpu-vae",
    name: "Run VAE on CPU",
    category: ["Inference"],
    type: "boolean",
    defaultValue: false
  },
  // Text Encoder settings
  {
    id: "text-encoder-precision",
    name: "Text Encoder precision",
    category: ["Inference"],
    type: "combo",
    options: [
      FloatingPointPrecision.AUTO,
      FloatingPointPrecision.FP8E4M3FN,
      FloatingPointPrecision.FP8E5M2,
      FloatingPointPrecision.FP16,
      FloatingPointPrecision.FP32
    ],
    defaultValue: FloatingPointPrecision.AUTO,
    tooltip: "Text Encoder precision",
    getValue: /* @__PURE__ */ __name((value) => {
      switch (value) {
        case FloatingPointPrecision.AUTO:
          return {};
        default:
          return {
            [`${value.toLowerCase()}-text-enc`]: true
          };
      }
    }, "getValue")
  },
  // Memory and performance settings
  {
    id: "force-channels-last",
    name: "Force channels-last memory format",
    category: ["Memory"],
    type: "boolean",
    defaultValue: false
  },
  {
    id: "directml",
    name: "DirectML device index",
    category: ["Memory"],
    type: "number",
    defaultValue: null
  },
  {
    id: "disable-ipex-optimize",
    name: "Disable IPEX optimization",
    category: ["Memory"],
    type: "boolean",
    defaultValue: false
  },
  // Preview settings
  {
    id: "preview-method",
    name: "Method used for latent previews",
    category: ["Preview"],
    type: "combo",
    options: Object.values(LatentPreviewMethod),
    defaultValue: LatentPreviewMethod.NoPreviews
  },
  {
    id: "preview-size",
    name: "Size of preview images",
    category: ["Preview"],
    type: "slider",
    defaultValue: 512,
    attrs: {
      min: 128,
      max: 2048,
      step: 128
    }
  },
  // Cache settings
  {
    id: "cache-classic",
    name: "Use classic cache system",
    category: ["Cache"],
    type: "boolean",
    defaultValue: false
  },
  {
    id: "cache-lru",
    name: "Use LRU caching with a maximum of N node results cached.",
    category: ["Cache"],
    type: "number",
    defaultValue: null,
    tooltip: "May use more RAM/VRAM."
  },
  // Attention settings
  {
    id: "cross-attention-method",
    name: "Cross attention method",
    category: ["Attention"],
    type: "combo",
    options: Object.values(CrossAttentionMethod),
    defaultValue: CrossAttentionMethod.Auto,
    getValue: /* @__PURE__ */ __name((value) => {
      switch (value) {
        case CrossAttentionMethod.Auto:
          return {};
        default:
          return {
            [`use-${value.toLowerCase()}-cross-attention`]: true
          };
      }
    }, "getValue")
  },
  {
    id: "disable-xformers",
    name: "Disable xFormers optimization",
    type: "boolean",
    defaultValue: false
  },
  {
    id: "force-upcast-attention",
    name: "Force attention upcast",
    category: ["Attention"],
    type: "boolean",
    defaultValue: false
  },
  {
    id: "dont-upcast-attention",
    name: "Prevent attention upcast",
    category: ["Attention"],
    type: "boolean",
    defaultValue: false
  },
  // VRAM management
  {
    id: "vram-management",
    name: "VRAM management mode",
    category: ["Memory"],
    type: "combo",
    options: Object.values(VramManagement),
    defaultValue: VramManagement.Auto,
    getValue: /* @__PURE__ */ __name((value) => {
      switch (value) {
        case VramManagement.Auto:
          return {};
        default:
          return {
            [value]: true
          };
      }
    }, "getValue")
  },
  {
    id: "reserve-vram",
    name: "Reserved VRAM (GB)",
    category: ["Memory"],
    type: "number",
    defaultValue: null,
    tooltip: "Set the amount of vram in GB you want to reserve for use by your OS/other software. By default some amount is reserved depending on your OS."
  },
  // Misc settings
  {
    id: "default-hashing-function",
    name: "Default hashing function for model files",
    type: "combo",
    options: Object.values(HashFunction),
    defaultValue: HashFunction.SHA256
  },
  {
    id: "disable-smart-memory",
    name: "Disable smart memory management",
    tooltip: "Force ComfyUI to aggressively offload to regular ram instead of keeping models in vram when it can.",
    category: ["Memory"],
    type: "boolean",
    defaultValue: false
  },
  {
    id: "deterministic",
    name: "Make pytorch use slower deterministic algorithms when it can.",
    type: "boolean",
    defaultValue: false,
    tooltip: "Note that this might not make images deterministic in all cases."
  },
  {
    id: "fast",
    name: "Enable some untested and potentially quality deteriorating optimizations.",
    type: "boolean",
    defaultValue: false
  },
  {
    id: "dont-print-server",
    name: "Don't print server output to console.",
    type: "boolean",
    defaultValue: false
  },
  {
    id: "disable-metadata",
    name: "Disable saving prompt metadata in files.",
    type: "boolean",
    defaultValue: false
  },
  {
    id: "enable-manager-legacy-ui",
    name: "Use legacy Manager UI",
    tooltip: "Uses the legacy ComfyUI-Manager UI instead of the new UI.",
    type: "boolean",
    defaultValue: false
  },
  {
    id: "disable-all-custom-nodes",
    name: "Disable loading all custom nodes.",
    type: "boolean",
    defaultValue: false
  },
  {
    id: "log-level",
    name: "Logging verbosity level",
    type: "combo",
    options: Object.values(LogLevel),
    defaultValue: LogLevel.INFO,
    getValue: /* @__PURE__ */ __name((value) => {
      return {
        verbose: value
      };
    }, "getValue")
  },
  // Directories
  {
    id: "input-directory",
    name: "Input directory",
    category: ["Directories"],
    type: "text",
    defaultValue: ""
  },
  {
    id: "output-directory",
    name: "Output directory",
    category: ["Directories"],
    type: "text",
    defaultValue: ""
  }
];
const DISMISSAL_DURATION_MS = 7 * 24 * 60 * 60 * 1e3;
const useVersionCompatibilityStore = defineStore(
  "versionCompatibility",
  () => {
    const systemStatsStore = useSystemStatsStore();
    const settingStore = useSettingStore();
    const frontendVersion = computed(() => config.app_version);
    const backendVersion = computed(
      () => systemStatsStore.systemStats?.system?.comfyui_version ?? ""
    );
    const requiredFrontendVersion = computed(
      () => systemStatsStore.systemStats?.system?.required_frontend_version ?? ""
    );
    const isFrontendOutdated = computed(() => {
      if (!frontendVersion.value || !requiredFrontendVersion.value || !semverExports.valid(frontendVersion.value) || !semverExports.valid(requiredFrontendVersion.value)) {
        return false;
      }
      return semverExports.gt(requiredFrontendVersion.value, frontendVersion.value);
    });
    const isFrontendNewer = computed(() => {
      return false;
    });
    const hasVersionMismatch = computed(() => {
      return isFrontendOutdated.value;
    });
    const versionKey = computed(() => {
      if (!frontendVersion.value || !backendVersion.value || !requiredFrontendVersion.value) {
        return null;
      }
      return `${frontendVersion.value}-${backendVersion.value}-${requiredFrontendVersion.value}`;
    });
    const dismissalStorage = useStorage(
      "comfy.versionMismatch.dismissals",
      {},
      localStorage,
      {
        serializer: {
          read: /* @__PURE__ */ __name((value) => {
            try {
              return JSON.parse(value);
            } catch {
              return {};
            }
          }, "read"),
          write: /* @__PURE__ */ __name((value) => JSON.stringify(value), "write")
        }
      }
    );
    const isDismissed = computed(() => {
      if (!versionKey.value) return false;
      const dismissedUntil = dismissalStorage.value[versionKey.value];
      if (!dismissedUntil) return false;
      return Date.now() < dismissedUntil;
    });
    const shouldShowWarning = computed(() => {
      const warningsDisabled = settingStore.get(
        "Comfy.VersionCompatibility.DisableWarnings"
      );
      return hasVersionMismatch.value && !isDismissed.value && !warningsDisabled;
    });
    const warningMessage = computed(() => {
      if (isFrontendOutdated.value) {
        return {
          type: "outdated",
          frontendVersion: frontendVersion.value,
          requiredVersion: requiredFrontendVersion.value
        };
      }
      return null;
    });
    async function checkVersionCompatibility() {
      if (!systemStatsStore.systemStats) {
        await until(systemStatsStore.isInitialized);
      }
    }
    __name(checkVersionCompatibility, "checkVersionCompatibility");
    function dismissWarning() {
      if (!versionKey.value) return;
      const dismissUntil = Date.now() + DISMISSAL_DURATION_MS;
      dismissalStorage.value = {
        ...dismissalStorage.value,
        [versionKey.value]: dismissUntil
      };
    }
    __name(dismissWarning, "dismissWarning");
    async function initialize() {
      await checkVersionCompatibility();
    }
    __name(initialize, "initialize");
    return {
      frontendVersion,
      backendVersion,
      requiredFrontendVersion,
      hasVersionMismatch,
      shouldShowWarning,
      warningMessage,
      isFrontendOutdated,
      isFrontendNewer,
      checkVersionCompatibility,
      dismissWarning,
      initialize
    };
  }
);
function useFrontendVersionMismatchWarning(options = {}) {
  const { immediate = false } = options;
  const { t: t2 } = useI18n();
  const toastStore = useToastStore();
  const versionCompatibilityStore = useVersionCompatibilityStore();
  let hasShownWarning = false;
  const showWarning = /* @__PURE__ */ __name(() => {
    if (hasShownWarning) return;
    const message = versionCompatibilityStore.warningMessage;
    if (!message) return;
    const detailMessage = t2("g.frontendOutdated", {
      frontendVersion: message.frontendVersion,
      requiredVersion: message.requiredVersion
    });
    const fullMessage = t2("g.versionMismatchWarningMessage", {
      warning: t2("g.versionMismatchWarning"),
      detail: detailMessage
    });
    toastStore.addAlert(fullMessage);
    hasShownWarning = true;
    versionCompatibilityStore.dismissWarning();
  }, "showWarning");
  onMounted(() => {
    if (immediate) {
      whenever(
        () => versionCompatibilityStore.shouldShowWarning,
        () => {
          showWarning();
        },
        {
          immediate: true,
          once: true
        }
      );
    }
  });
  return {
    showWarning,
    shouldShowWarning: computed(
      () => versionCompatibilityStore.shouldShowWarning
    ),
    dismissWarning: versionCompatibilityStore.dismissWarning,
    hasVersionMismatch: computed(
      () => versionCompatibilityStore.hasVersionMismatch
    )
  };
}
__name(useFrontendVersionMismatchWarning, "useFrontendVersionMismatchWarning");
function setupAutoQueueHandler() {
  const queueCountStore = useQueuePendingTaskCountStore();
  const queueSettingsStore = useQueueSettingsStore();
  let graphHasChanged = false;
  let internalCount = 0;
  api.addEventListener("graphChanged", () => {
    if (queueSettingsStore.mode === "change") {
      if (internalCount) {
        graphHasChanged = true;
      } else {
        graphHasChanged = false;
        void app.queuePrompt(0, queueSettingsStore.batchCount);
        internalCount++;
      }
    }
  });
  queueCountStore.$subscribe(
    async () => {
      internalCount = queueCountStore.count;
      if (!internalCount && !app.lastExecutionError) {
        if (queueSettingsStore.mode === "instant" || queueSettingsStore.mode === "change" && graphHasChanged) {
          graphHasChanged = false;
          await app.queuePrompt(0, queueSettingsStore.batchCount);
        }
      }
    },
    { detached: true }
  );
}
__name(setupAutoQueueHandler, "setupAutoQueueHandler");
const _hoisted_1$1 = { class: "absolute w-full h-full" };
const _hoisted_2 = { class: "workflow-tabs-container pointer-events-auto h-9.5 w-full" };
const _hoisted_3 = { class: "flex h-full items-center" };
const _hoisted_4 = { class: "sidebar-content-container h-full w-full overflow-x-hidden overflow-y-auto border-r-1 border-node-component-border" };
const _hoisted_5 = ["src"];
const _hoisted_6 = {
  key: 0,
  class: "pointer-events-none object-contain flex-1 max-h-full brightness-50 opacity-10",
  src: _imports_0$1
};
const _hoisted_7 = { class: "actionbar-container flex h-12 items-center rounded-lg border border-[var(--interface-stroke)] p-2 gap-2 bg-comfy-menu-bg justify-end" };
const _hoisted_8 = { class: "rounded-lg border p-2 gap-2 h-full border-[var(--interface-stroke)] bg-comfy-menu-bg flex flex-col" };
const _hoisted_9 = { class: "grow-1 flex justify-start flex-col overflow-y-auto contain-size *:max-h-100" };
const _hoisted_10 = { class: "p-4 pb-0 border-t border-node-component-border" };
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "LinearView",
  setup(__props) {
    const nodeOutputStore = useNodeOutputStore();
    const commandStore = useCommandStore();
    const nodeDatas = computed(() => {
      function nodeToNodeData(node) {
        const mapper = safeWidgetMapper(node, /* @__PURE__ */ new Map());
        const widgets = node.widgets?.map((widget) => {
          const safeWidget = mapper(widget);
          safeWidget.callback = function(value) {
            if (!isValidWidgetValue(value)) return;
            widget.value = value ?? void 0;
            return widget.callback?.(widget.value);
          };
          return safeWidget;
        }) ?? [];
        return {
          id: `${node.id}`,
          title: node.title,
          type: node.type,
          mode: 0,
          selected: false,
          executing: false,
          widgets
        };
      }
      __name(nodeToNodeData, "nodeToNodeData");
      return app.rootGraph.nodes.filter((node) => node.mode === 0 && node.widgets?.length).map(nodeToNodeData);
    });
    const { isLoggedIn } = useCurrentUser();
    const isDesktop = isElectron();
    const batchCountWidget = {
      options: { step2: 1, precision: 1, min: 1, max: 100 },
      value: 1,
      name: t("Number of generations"),
      type: "number"
    };
    const { batchCount } = storeToRefs(useQueueSettingsStore());
    async function runButtonClick(e) {
      const isShiftPressed = "shiftKey" in e && e.shiftKey;
      const commandId = isShiftPressed ? "Comfy.QueuePromptFront" : "Comfy.QueuePrompt";
      if (batchCount.value > 1) ;
      await commandStore.execute(commandId, {
        metadata: {
          subscribe_to_run: false,
          trigger_source: "button"
        }
      });
    }
    __name(runButtonClick, "runButtonClick");
    function openFeedback() {
      window.open(
        "https://support.comfy.org/hc/en-us/requests/new?ticket_form_id=40026345549204",
        "_blank",
        "noopener,noreferrer"
      );
    }
    __name(openFeedback, "openFeedback");
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$1, [
        createBaseVNode("div", _hoisted_2, [
          createBaseVNode("div", _hoisted_3, [
            createVNode(WorkflowTabs),
            createVNode(_sfc_main$j)
          ])
        ]),
        createVNode(unref(script$3), {
          class: "h-[calc(100%-38px)] w-full bg-comfy-menu-secondary-bg",
          pt: { gutter: { class: "bg-transparent w-4 -mx-3" } }
        }, {
          default: withCtx(() => [
            createVNode(unref(script$4), {
              size: 1,
              class: "min-w-min bg-comfy-menu-bg"
            }, {
              default: withCtx(() => [
                createBaseVNode("div", _hoisted_4, [
                  createVNode(_sfc_main$1g, {
                    extension: unref(useAssetsSidebarTab)()
                  }, null, 8, ["extension"])
                ])
              ]),
              _: 1
            }),
            createVNode(unref(script$4), {
              size: 98,
              class: "flex flex-row overflow-y-auto flex-wrap min-w-min gap-4 m-4"
            }, {
              default: withCtx(() => [
                (openBlock(true), createElementBlock(Fragment, null, renderList(unref(nodeOutputStore).latestOutput, (previewUrl) => {
                  return openBlock(), createElementBlock("img", {
                    key: previewUrl,
                    class: "pointer-events-none object-contain flex-1 max-h-full",
                    src: previewUrl
                  }, null, 8, _hoisted_5);
                }), 128)),
                unref(nodeOutputStore).latestOutput.length === 0 ? (openBlock(), createElementBlock("img", _hoisted_6)) : createCommentVNode("", true)
              ]),
              _: 1
            }),
            createVNode(unref(script$4), {
              size: 1,
              class: "flex flex-col gap-1 p-1 min-w-min"
            }, {
              default: withCtx(() => [
                createBaseVNode("div", _hoisted_7, [
                  createVNode(_sfc_main$1Y, {
                    variant: "secondary",
                    onClick: openFeedback
                  }, {
                    default: withCtx(() => [
                      createTextVNode(toDisplayString(unref(t)("g.feedback")), 1)
                    ]),
                    _: 1
                  }),
                  createVNode(_sfc_main$1Y, {
                    variant: "secondary",
                    class: "min-w-max",
                    onClick: _cache[0] || (_cache[0] = ($event) => unref(useCanvasStore)().linearMode = false)
                  }, {
                    default: withCtx(() => [
                      createTextVNode(toDisplayString(unref(t)("linearMode.openWorkflow")) + " ", 1),
                      _cache[3] || (_cache[3] = createBaseVNode("i", { class: "icon-[comfy--workflow]" }, null, -1))
                    ]),
                    _: 1
                  }),
                  createVNode(_sfc_main$1Y, {
                    variant: "inverted",
                    onClick: _cache[1] || (_cache[1] = ($event) => unref(useWorkflowService)().exportWorkflow("workflow", "workflow"))
                  }, {
                    default: withCtx(() => [
                      createTextVNode(toDisplayString(unref(t)("linearMode.share")), 1)
                    ]),
                    _: 1
                  }),
                  unref(isLoggedIn) ? (openBlock(), createBlock(_sfc_main$1j, { key: 0 })) : unref(isDesktop) ? (openBlock(), createBlock(_sfc_main$1i, { key: 1 })) : createCommentVNode("", true)
                ]),
                createBaseVNode("div", _hoisted_8, [
                  createBaseVNode("div", _hoisted_9, [
                    (openBlock(true), createElementBlock(Fragment, null, renderList(nodeDatas.value, (nodeData) => {
                      return openBlock(), createBlock(_sfc_main$2c, {
                        key: nodeData.id,
                        "node-data": nodeData,
                        class: "border-b-1 border-node-component-border pt-1 pb-2 last:border-none"
                      }, null, 8, ["node-data"]);
                    }), 128))
                  ]),
                  createBaseVNode("div", _hoisted_10, [
                    createVNode(_sfc_main$2d, {
                      modelValue: unref(batchCount),
                      "onUpdate:modelValue": _cache[2] || (_cache[2] = ($event) => isRef(batchCount) ? batchCount.value = $event : null),
                      widget: batchCountWidget,
                      class: "*:[.min-w-56]:basis-0"
                    }, null, 8, ["modelValue"]),
                    createVNode(_sfc_main$1Y, {
                      class: "w-full mt-4",
                      onClick: runButtonClick
                    }, {
                      default: withCtx(() => [
                        _cache[4] || (_cache[4] = createBaseVNode("i", { class: "icon-[lucide--play]" }, null, -1)),
                        createTextVNode(" " + toDisplayString(unref(t)("menu.run")), 1)
                      ]),
                      _: 1
                    })
                  ])
                ])
              ]),
              _: 1
            })
          ]),
          _: 1
        })
      ]);
    };
  }
});
const _hoisted_1 = { class: "comfyui-body grid h-full w-full overflow-hidden" };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "GraphView",
  setup(__props) {
    setupAutoQueueHandler();
    useProgressFavicon();
    useBrowserTabTitle();
    const { t: t2 } = useI18n();
    const toast = useToast();
    const settingStore = useSettingStore();
    const executionStore = useExecutionStore();
    const colorPaletteStore = useColorPaletteStore();
    const queueStore = useQueueStore();
    const assetsStore = useAssetsStore();
    const versionCompatibilityStore = useVersionCompatibilityStore();
    const graphCanvasContainerRef = ref(null);
    const { linearMode } = storeToRefs(useCanvasStore());
    useFirebaseAuthStore();
    watch(
      () => colorPaletteStore.completedActivePalette,
      (newTheme) => {
        const DARK_THEME_CLASS = "dark-theme";
        if (newTheme.light_theme) {
          document.body.classList.remove(DARK_THEME_CLASS);
        } else {
          document.body.classList.add(DARK_THEME_CLASS);
        }
        if (isElectron()) {
          electronAPI().changeTheme({
            color: "rgba(0, 0, 0, 0)",
            symbolColor: newTheme.colors.comfy_base["input-text"]
          });
        }
      },
      { immediate: true }
    );
    if (isElectron()) {
      watch(
        () => queueStore.tasks,
        (newTasks, oldTasks) => {
          const oldRunningTaskIds = new Set(
            oldTasks.filter((task) => task.isRunning).map((task) => task.promptId)
          );
          newTasks.filter(
            (task) => oldRunningTaskIds.has(task.promptId) && task.isHistory
          ).forEach((task) => {
            electronAPI().Events.incrementUserProperty(
              `execution:${task.displayStatus.toLowerCase()}`,
              1
            );
            electronAPI().Events.trackEvent("execution", {
              status: task.displayStatus.toLowerCase()
            });
          });
        },
        { deep: true }
      );
    }
    watchEffect(() => {
      const fontSize = settingStore.get("Comfy.TextareaWidget.FontSize");
      document.documentElement.style.setProperty(
        "--comfy-textarea-font-size",
        `${fontSize}px`
      );
    });
    watchEffect(() => {
      const padding = settingStore.get("Comfy.TreeExplorer.ItemPadding");
      document.documentElement.style.setProperty(
        "--comfy-tree-explorer-item-padding",
        `${padding}px`
      );
    });
    watchEffect(async () => {
      const locale = settingStore.get("Comfy.Locale");
      if (locale) {
        try {
          await loadLocale(locale);
          i18n.global.locale.value = locale;
        } catch (error) {
          console.error(`Failed to switch to locale "${locale}":`, error);
        }
      }
    });
    const useNewMenu = computed(() => {
      return settingStore.get("Comfy.UseNewMenu");
    });
    watchEffect(() => {
      if (useNewMenu.value === "Disabled") {
        app.ui.menuContainer.style.setProperty("display", "block");
        app.ui.restoreMenuPosition();
      } else {
        app.ui.menuContainer.style.setProperty("display", "none");
      }
    });
    watchEffect(() => {
      queueStore.maxHistoryItems = settingStore.get("Comfy.Queue.MaxHistoryItems");
    });
    const init = /* @__PURE__ */ __name(() => {
      const coreCommands = useCoreCommands();
      useCommandStore().registerCommands(coreCommands);
      useMenuItemStore().registerCoreMenuCommands();
      useKeybindingService().registerCoreKeybindings();
      useSidebarTabStore().registerCoreSidebarTabs();
      useBottomPanelStore().registerCoreBottomPanelTabs();
      app.extensionManager = useWorkspaceStore();
    }, "init");
    const queuePendingTaskCountStore = useQueuePendingTaskCountStore();
    const sidebarTabStore = useSidebarTabStore();
    const onStatus = /* @__PURE__ */ __name(async (e) => {
      queuePendingTaskCountStore.update(e);
      await queueStore.update();
      if (sidebarTabStore.activeSidebarTabId === "assets") {
        await assetsStore.updateHistory();
      }
    }, "onStatus");
    const onExecutionSuccess = /* @__PURE__ */ __name(async () => {
      await queueStore.update();
      if (sidebarTabStore.activeSidebarTabId === "assets") {
        await assetsStore.updateHistory();
      }
    }, "onExecutionSuccess");
    const reconnectingMessage = {
      severity: "error",
      summary: t2("g.reconnecting")
    };
    const onReconnecting = /* @__PURE__ */ __name(() => {
      if (!settingStore.get("Comfy.Toast.DisableReconnectingToast")) {
        toast.remove(reconnectingMessage);
        toast.add(reconnectingMessage);
      }
    }, "onReconnecting");
    const onReconnected = /* @__PURE__ */ __name(() => {
      if (!settingStore.get("Comfy.Toast.DisableReconnectingToast")) {
        toast.remove(reconnectingMessage);
        toast.add({
          severity: "success",
          summary: t2("g.reconnected"),
          life: 2e3
        });
      }
    }, "onReconnected");
    onMounted(() => {
      api.addEventListener("status", onStatus);
      api.addEventListener("execution_success", onExecutionSuccess);
      api.addEventListener("reconnecting", onReconnecting);
      api.addEventListener("reconnected", onReconnected);
      executionStore.bindExecutionEvents();
      try {
        init();
        graphCanvasContainerRef.value?.prepend(app.ui.menuContainer);
      } catch (e) {
        console.error("Failed to init ComfyUI frontend", e);
      }
    });
    onBeforeUnmount(() => {
      api.removeEventListener("status", onStatus);
      api.removeEventListener("execution_success", onExecutionSuccess);
      api.removeEventListener("reconnecting", onReconnecting);
      api.removeEventListener("reconnected", onReconnected);
      executionStore.unbindExecutionEvents();
    });
    useEventListener(window, "keydown", useKeybindingService().keybindHandler);
    const { wrapWithErrorHandling, wrapWithErrorHandlingAsync } = useErrorHandling();
    useFrontendVersionMismatchWarning({ immediate: true });
    void nextTick(() => {
      versionCompatibilityStore.initialize().catch((error) => {
        console.warn("Version compatibility check failed:", error);
      });
    });
    const onGraphReady = /* @__PURE__ */ __name(() => {
      runWhenGlobalIdle(() => {
        wrapWithErrorHandling(useKeybindingService().registerUserKeybindings)();
        wrapWithErrorHandling(useServerConfigStore().loadServerConfig)(
          SERVER_CONFIG_ITEMS,
          settingStore.get("Comfy.Server.ServerConfigValues")
        );
        void wrapWithErrorHandlingAsync(useModelStore().loadModelFolders)();
        void wrapWithErrorHandlingAsync(
          useNodeFrequencyStore().loadNodeFrequencies
        )();
        useNodeDefStore().nodeSearchService.searchNode("");
      }, 1e3);
    }, "onGraphReady");
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock(Fragment, null, [
        createBaseVNode("div", _hoisted_1, [
          _cache[0] || (_cache[0] = createBaseVNode("div", {
            id: "comfyui-body-top",
            class: "comfyui-body-top"
          }, null, -1)),
          _cache[1] || (_cache[1] = createBaseVNode("div", {
            id: "comfyui-body-bottom",
            class: "comfyui-body-bottom"
          }, null, -1)),
          _cache[2] || (_cache[2] = createBaseVNode("div", {
            id: "comfyui-body-left",
            class: "comfyui-body-left"
          }, null, -1)),
          _cache[3] || (_cache[3] = createBaseVNode("div", {
            id: "comfyui-body-right",
            class: "comfyui-body-right"
          }, null, -1)),
          withDirectives(createBaseVNode("div", {
            id: "graph-canvas-container",
            ref_key: "graphCanvasContainerRef",
            ref: graphCanvasContainerRef,
            class: "graph-canvas-container"
          }, [
            createVNode(_sfc_main$5, { onReady: onGraphReady })
          ], 512), [
            [vShow, !unref(linearMode)]
          ]),
          unref(linearMode) ? (openBlock(), createBlock(_sfc_main$1, { key: 0 })) : createCommentVNode("", true)
        ]),
        createVNode(_sfc_main$1F),
        createVNode(_sfc_main$4),
        !unref(isElectron)() ? (openBlock(), createBlock(_sfc_main$1D, { key: 0 })) : createCommentVNode("", true),
        createVNode(_sfc_main$1E)
      ], 64);
    };
  }
});
const GraphView = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-f93a6874"]]);
const GraphView$1 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: GraphView
}, Symbol.toStringTag, { value: "Module" }));
export {
  GraphView$1 as G,
  _sfc_main$1H as _,
  _sfc_main$1G as a,
  graphHasMissingNodes as g
};
//# sourceMappingURL=GraphView-BygZ6y9k.js.map
