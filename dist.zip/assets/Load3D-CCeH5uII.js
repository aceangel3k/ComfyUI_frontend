import { _ as _sfc_main } from "./Load3D.vue_vue_type_script_setup_true_lang-Cyd9_MSi.js";
import "./vendor-other-CzYzbUcM.js";
import "./vendor-primevue-Ch6rhmJJ.js";
import "./index-CCPcyh0b.js";
import "./vendor-vue-DLbRHZS7.js";
import "./vendor-xterm-BF8peZ5_.js";
import "./vendor-three-DYL0ZbEr.js";
import "./vendor-tiptap-XfQ74oRB.js";
export {
  _sfc_main as default
};
//# sourceMappingURL=Load3D-CCeH5uII.js.map
