var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
import { bq as defineComponent, cF as mergeModels, cG as useModel, r as ref, o as onMounted, c6 as onUnmounted, h as resolveDirective, c as createElementBlock, d as openBlock, l as withDirectives, j as createBlock, k as withCtx, e as createBaseVNode, s as normalizeClass, z as createVNode, br as unref, v as vShow, E as computed, q as createCommentVNode, F as Fragment, y as renderList, A as createTextVNode, u as toDisplayString, I as withModifiers, T as Transition, b9 as isRef } from "./vendor-other-CzYzbUcM.js";
import { j as script, i as script$1 } from "./vendor-primevue-Ch6rhmJJ.js";
import { _ as _sfc_main$d, e as useSettingStore, t, c as cn, d as _export_sfc, cE as useLoad3dDrag, u as useDialogStore, cF as Load3DViewerContent, cG as useLoad3dService, q as app, cH as useLoad3d } from "./index-45IpBQOM.js";
const _hoisted_1$c = { class: "relative show-slider" };
const _hoisted_2$a = { class: "absolute top-0 left-12 rounded-lg bg-black/50 p-4 shadow-lg w-[150px]" };
const _sfc_main$c = /* @__PURE__ */ defineComponent({
  __name: "PopupSlider",
  props: /* @__PURE__ */ mergeModels({
    icon: { default: "pi-expand" },
    tooltipText: {},
    min: { default: 10 },
    max: { default: 150 },
    step: { default: 1 }
  }, {
    "modelValue": {},
    "modelModifiers": {}
  }),
  emits: ["update:modelValue"],
  setup(__props) {
    const value = useModel(__props, "modelValue");
    const showSlider = ref(false);
    const toggleSlider = /* @__PURE__ */ __name(() => {
      showSlider.value = !showSlider.value;
    }, "toggleSlider");
    const closeSlider = /* @__PURE__ */ __name((e) => {
      const target = e.target;
      if (!target.closest(".show-slider")) {
        showSlider.value = false;
      }
    }, "closeSlider");
    onMounted(() => {
      document.addEventListener("click", closeSlider);
    });
    onUnmounted(() => {
      document.removeEventListener("click", closeSlider);
    });
    return (_ctx, _cache) => {
      const _directive_tooltip = resolveDirective("tooltip");
      return openBlock(), createElementBlock("div", _hoisted_1$c, [
        withDirectives((openBlock(), createBlock(_sfc_main$d, {
          size: "icon",
          variant: "textonly",
          class: "rounded-full",
          "aria-label": _ctx.tooltipText,
          onClick: toggleSlider
        }, {
          default: withCtx(() => [
            createBaseVNode("i", {
              class: normalizeClass(["pi", _ctx.icon, "text-lg text-white"])
            }, null, 2)
          ]),
          _: 1
        }, 8, ["aria-label"])), [
          [
            _directive_tooltip,
            { value: _ctx.tooltipText, showDelay: 300 },
            void 0,
            { right: true }
          ]
        ]),
        withDirectives(createBaseVNode("div", _hoisted_2$a, [
          createVNode(unref(script), {
            modelValue: value.value,
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => value.value = $event),
            class: "w-full",
            min: _ctx.min,
            max: _ctx.max,
            step: _ctx.step
          }, null, 8, ["modelValue", "min", "max", "step"])
        ], 512), [
          [vShow, showSlider.value]
        ])
      ]);
    };
  }
});
const _hoisted_1$b = { class: "flex flex-col" };
const _sfc_main$b = /* @__PURE__ */ defineComponent({
  __name: "CameraControls",
  props: {
    "cameraType": {},
    "cameraTypeModifiers": {},
    "fov": {},
    "fovModifiers": {}
  },
  emits: ["update:cameraType", "update:fov"],
  setup(__props) {
    const cameraType = useModel(__props, "cameraType");
    const fov = useModel(__props, "fov");
    const showFOVButton = computed(() => cameraType.value === "perspective");
    const switchCamera = /* @__PURE__ */ __name(() => {
      cameraType.value = cameraType.value === "perspective" ? "orthographic" : "perspective";
    }, "switchCamera");
    return (_ctx, _cache) => {
      const _directive_tooltip = resolveDirective("tooltip");
      return openBlock(), createElementBlock("div", _hoisted_1$b, [
        withDirectives((openBlock(), createBlock(_sfc_main$d, {
          size: "icon",
          variant: "textonly",
          class: "rounded-full",
          "aria-label": _ctx.$t("load3d.switchCamera"),
          onClick: switchCamera
        }, {
          default: withCtx(() => _cache[1] || (_cache[1] = [
            createBaseVNode("i", {
              class: normalizeClass(["pi", "pi-camera", "text-lg text-white"])
            }, null, -1)
          ])),
          _: 1
        }, 8, ["aria-label"])), [
          [
            _directive_tooltip,
            {
              value: _ctx.$t("load3d.switchCamera"),
              showDelay: 300
            },
            void 0,
            { right: true }
          ]
        ]),
        showFOVButton.value ? (openBlock(), createBlock(_sfc_main$c, {
          key: 0,
          modelValue: fov.value,
          "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => fov.value = $event),
          "tooltip-text": _ctx.$t("load3d.fov")
        }, null, 8, ["modelValue", "tooltip-text"])) : createCommentVNode("", true)
      ]);
    };
  }
});
const _hoisted_1$a = { class: "flex flex-col" };
const _hoisted_2$9 = { class: "show-export-formats relative" };
const _hoisted_3$6 = { class: "absolute top-0 left-12 rounded-lg bg-black/50 shadow-lg" };
const _hoisted_4$3 = { class: "flex flex-col" };
const _sfc_main$a = /* @__PURE__ */ defineComponent({
  __name: "ExportControls",
  emits: ["exportModel"],
  setup(__props, { emit: __emit }) {
    const emit = __emit;
    const showExportFormats = ref(false);
    const exportFormats = [
      { label: "GLB", value: "glb" },
      { label: "OBJ", value: "obj" },
      { label: "STL", value: "stl" }
    ];
    function toggleExportFormats() {
      showExportFormats.value = !showExportFormats.value;
    }
    __name(toggleExportFormats, "toggleExportFormats");
    function exportModel(format) {
      emit("exportModel", format);
      showExportFormats.value = false;
    }
    __name(exportModel, "exportModel");
    function closeExportFormatsList(e) {
      const target = e.target;
      if (!target.closest(".show-export-formats")) {
        showExportFormats.value = false;
      }
    }
    __name(closeExportFormatsList, "closeExportFormatsList");
    onMounted(() => {
      document.addEventListener("click", closeExportFormatsList);
    });
    onUnmounted(() => {
      document.removeEventListener("click", closeExportFormatsList);
    });
    return (_ctx, _cache) => {
      const _directive_tooltip = resolveDirective("tooltip");
      return openBlock(), createElementBlock("div", _hoisted_1$a, [
        createBaseVNode("div", _hoisted_2$9, [
          withDirectives((openBlock(), createBlock(_sfc_main$d, {
            size: "icon",
            variant: "textonly",
            class: "rounded-full",
            "aria-label": _ctx.$t("load3d.exportModel"),
            onClick: toggleExportFormats
          }, {
            default: withCtx(() => _cache[0] || (_cache[0] = [
              createBaseVNode("i", { class: "pi pi-download text-lg text-white" }, null, -1)
            ])),
            _: 1
          }, 8, ["aria-label"])), [
            [
              _directive_tooltip,
              {
                value: _ctx.$t("load3d.exportModel"),
                showDelay: 300
              },
              void 0,
              { right: true }
            ]
          ]),
          withDirectives(createBaseVNode("div", _hoisted_3$6, [
            createBaseVNode("div", _hoisted_4$3, [
              (openBlock(), createElementBlock(Fragment, null, renderList(exportFormats, (format) => {
                return createVNode(_sfc_main$d, {
                  key: format.value,
                  variant: "textonly",
                  class: "text-white",
                  onClick: /* @__PURE__ */ __name(($event) => exportModel(format.value), "onClick")
                }, {
                  default: withCtx(() => [
                    createTextVNode(toDisplayString(format.label), 1)
                  ]),
                  _: 2
                }, 1032, ["onClick"]);
              }), 64))
            ])
          ], 512), [
            [vShow, showExportFormats.value]
          ])
        ])
      ]);
    };
  }
});
const _hoisted_1$9 = { class: "flex flex-col" };
const _hoisted_2$8 = {
  key: 0,
  class: "show-light-intensity relative"
};
const _hoisted_3$5 = {
  class: "absolute top-0 left-12 rounded-lg bg-black/50 p-4 shadow-lg",
  style: { "width": "150px" }
};
const _sfc_main$9 = /* @__PURE__ */ defineComponent({
  __name: "LightControls",
  props: {
    "lightIntensity": {},
    "lightIntensityModifiers": {},
    "materialMode": {},
    "materialModeModifiers": {}
  },
  emits: ["update:lightIntensity", "update:materialMode"],
  setup(__props) {
    const lightIntensity = useModel(__props, "lightIntensity");
    const materialMode = useModel(__props, "materialMode");
    const showLightIntensityButton = computed(
      () => materialMode.value === "original"
    );
    const showLightIntensity = ref(false);
    const lightIntensityMaximum = useSettingStore().get(
      "Comfy.Load3D.LightIntensityMaximum"
    );
    const lightIntensityMinimum = useSettingStore().get(
      "Comfy.Load3D.LightIntensityMinimum"
    );
    const lightAdjustmentIncrement = useSettingStore().get(
      "Comfy.Load3D.LightAdjustmentIncrement"
    );
    function toggleLightIntensity() {
      showLightIntensity.value = !showLightIntensity.value;
    }
    __name(toggleLightIntensity, "toggleLightIntensity");
    function closeLightSlider(e) {
      const target = e.target;
      if (!target.closest(".show-light-intensity")) {
        showLightIntensity.value = false;
      }
    }
    __name(closeLightSlider, "closeLightSlider");
    onMounted(() => {
      document.addEventListener("click", closeLightSlider);
    });
    onUnmounted(() => {
      document.removeEventListener("click", closeLightSlider);
    });
    return (_ctx, _cache) => {
      const _directive_tooltip = resolveDirective("tooltip");
      return openBlock(), createElementBlock("div", _hoisted_1$9, [
        showLightIntensityButton.value ? (openBlock(), createElementBlock("div", _hoisted_2$8, [
          withDirectives((openBlock(), createBlock(_sfc_main$d, {
            size: "icon",
            variant: "textonly",
            class: "rounded-full",
            "aria-label": _ctx.$t("load3d.lightIntensity"),
            onClick: toggleLightIntensity
          }, {
            default: withCtx(() => _cache[1] || (_cache[1] = [
              createBaseVNode("i", { class: "pi pi-sun text-lg text-white" }, null, -1)
            ])),
            _: 1
          }, 8, ["aria-label"])), [
            [
              _directive_tooltip,
              {
                value: _ctx.$t("load3d.lightIntensity"),
                showDelay: 300
              },
              void 0,
              { right: true }
            ]
          ]),
          withDirectives(createBaseVNode("div", _hoisted_3$5, [
            createVNode(unref(script), {
              modelValue: lightIntensity.value,
              "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => lightIntensity.value = $event),
              class: "w-full",
              min: unref(lightIntensityMinimum),
              max: unref(lightIntensityMaximum),
              step: unref(lightAdjustmentIncrement)
            }, null, 8, ["modelValue", "min", "max", "step"])
          ], 512), [
            [vShow, showLightIntensity.value]
          ])
        ])) : createCommentVNode("", true)
      ]);
    };
  }
});
const _hoisted_1$8 = { class: "flex flex-col" };
const _hoisted_2$7 = { class: "show-up-direction relative" };
const _hoisted_3$4 = { class: "absolute top-0 left-12 rounded-lg bg-black/50 shadow-lg" };
const _hoisted_4$2 = { class: "flex flex-col" };
const _hoisted_5$2 = {
  key: 0,
  class: "show-material-mode relative"
};
const _hoisted_6$1 = { class: "absolute top-0 left-12 rounded-lg bg-black/50 shadow-lg" };
const _hoisted_7 = { class: "flex flex-col" };
const _sfc_main$8 = /* @__PURE__ */ defineComponent({
  __name: "ModelControls",
  props: /* @__PURE__ */ mergeModels({
    hideMaterialMode: { type: Boolean, default: false },
    isPlyModel: { type: Boolean, default: false }
  }, {
    "materialMode": {},
    "materialModeModifiers": {},
    "upDirection": {},
    "upDirectionModifiers": {}
  }),
  emits: ["update:materialMode", "update:upDirection"],
  setup(__props) {
    const materialMode = useModel(__props, "materialMode");
    const upDirection = useModel(__props, "upDirection");
    const showUpDirection = ref(false);
    const showMaterialMode = ref(false);
    const upDirections = [
      "original",
      "-x",
      "+x",
      "-y",
      "+y",
      "-z",
      "+z"
    ];
    const materialModes = computed(() => {
      const modes = [
        "original",
        "normal",
        "wireframe"
        //'depth' disable for now
      ];
      if (__props.isPlyModel) {
        modes.splice(1, 0, "pointCloud");
      }
      return modes;
    });
    function toggleUpDirection() {
      showUpDirection.value = !showUpDirection.value;
      showMaterialMode.value = false;
    }
    __name(toggleUpDirection, "toggleUpDirection");
    function selectUpDirection(direction) {
      upDirection.value = direction;
      showUpDirection.value = false;
    }
    __name(selectUpDirection, "selectUpDirection");
    function toggleMaterialMode() {
      showMaterialMode.value = !showMaterialMode.value;
      showUpDirection.value = false;
    }
    __name(toggleMaterialMode, "toggleMaterialMode");
    function selectMaterialMode(mode) {
      materialMode.value = mode;
      showMaterialMode.value = false;
    }
    __name(selectMaterialMode, "selectMaterialMode");
    function formatMaterialMode(mode) {
      return t(`load3d.materialModes.${mode}`);
    }
    __name(formatMaterialMode, "formatMaterialMode");
    function closeSceneSlider(e) {
      const target = e.target;
      if (!target.closest(".show-up-direction")) {
        showUpDirection.value = false;
      }
      if (!target.closest(".show-material-mode")) {
        showMaterialMode.value = false;
      }
    }
    __name(closeSceneSlider, "closeSceneSlider");
    onMounted(() => {
      document.addEventListener("click", closeSceneSlider);
    });
    onUnmounted(() => {
      document.removeEventListener("click", closeSceneSlider);
    });
    return (_ctx, _cache) => {
      const _directive_tooltip = resolveDirective("tooltip");
      return openBlock(), createElementBlock("div", _hoisted_1$8, [
        createBaseVNode("div", _hoisted_2$7, [
          withDirectives((openBlock(), createBlock(_sfc_main$d, {
            size: "icon",
            variant: "textonly",
            class: "rounded-full",
            "aria-label": unref(t)("load3d.upDirection"),
            onClick: toggleUpDirection
          }, {
            default: withCtx(() => _cache[0] || (_cache[0] = [
              createBaseVNode("i", { class: "pi pi-arrow-up text-lg text-white" }, null, -1)
            ])),
            _: 1
          }, 8, ["aria-label"])), [
            [
              _directive_tooltip,
              {
                value: unref(t)("load3d.upDirection"),
                showDelay: 300
              },
              void 0,
              { right: true }
            ]
          ]),
          withDirectives(createBaseVNode("div", _hoisted_3$4, [
            createBaseVNode("div", _hoisted_4$2, [
              (openBlock(), createElementBlock(Fragment, null, renderList(upDirections, (direction) => {
                return createVNode(_sfc_main$d, {
                  key: direction,
                  variant: "textonly",
                  class: normalizeClass(
                    unref(cn)("text-white", upDirection.value === direction && "bg-blue-500")
                  ),
                  onClick: /* @__PURE__ */ __name(($event) => selectUpDirection(direction), "onClick")
                }, {
                  default: withCtx(() => [
                    createTextVNode(toDisplayString(direction.toUpperCase()), 1)
                  ]),
                  _: 2
                }, 1032, ["class", "onClick"]);
              }), 64))
            ])
          ], 512), [
            [vShow, showUpDirection.value]
          ])
        ]),
        !_ctx.hideMaterialMode ? (openBlock(), createElementBlock("div", _hoisted_5$2, [
          withDirectives((openBlock(), createBlock(_sfc_main$d, {
            size: "icon",
            variant: "textonly",
            class: "rounded-full",
            "aria-label": unref(t)("load3d.materialMode"),
            onClick: toggleMaterialMode
          }, {
            default: withCtx(() => _cache[1] || (_cache[1] = [
              createBaseVNode("i", { class: "pi pi-box text-lg text-white" }, null, -1)
            ])),
            _: 1
          }, 8, ["aria-label"])), [
            [
              _directive_tooltip,
              {
                value: unref(t)("load3d.materialMode"),
                showDelay: 300
              },
              void 0,
              { right: true }
            ]
          ]),
          withDirectives(createBaseVNode("div", _hoisted_6$1, [
            createBaseVNode("div", _hoisted_7, [
              (openBlock(true), createElementBlock(Fragment, null, renderList(materialModes.value, (mode) => {
                return openBlock(), createBlock(_sfc_main$d, {
                  key: mode,
                  variant: "textonly",
                  class: normalizeClass(
                    unref(cn)(
                      "whitespace-nowrap text-white",
                      materialMode.value === mode && "bg-blue-500"
                    )
                  ),
                  onClick: /* @__PURE__ */ __name(($event) => selectMaterialMode(mode), "onClick")
                }, {
                  default: withCtx(() => [
                    createTextVNode(toDisplayString(formatMaterialMode(mode)), 1)
                  ]),
                  _: 2
                }, 1032, ["class", "onClick"]);
              }), 128))
            ])
          ], 512), [
            [vShow, showMaterialMode.value]
          ])
        ])) : createCommentVNode("", true)
      ]);
    };
  }
});
const _hoisted_1$7 = { class: "flex flex-col" };
const _hoisted_2$6 = { key: 0 };
const _hoisted_3$3 = ["value"];
const _hoisted_4$1 = { key: 1 };
const _hoisted_5$1 = { key: 2 };
const _hoisted_6 = { key: 4 };
const _sfc_main$7 = /* @__PURE__ */ defineComponent({
  __name: "SceneControls",
  props: {
    "showGrid": { type: Boolean },
    "showGridModifiers": {},
    "backgroundColor": {},
    "backgroundColorModifiers": {},
    "backgroundImage": {},
    "backgroundImageModifiers": {},
    "backgroundRenderMode": { default: "tiled" },
    "backgroundRenderModeModifiers": {},
    "fov": {},
    "fovModifiers": {}
  },
  emits: /* @__PURE__ */ mergeModels(["updateBackgroundImage"], ["update:showGrid", "update:backgroundColor", "update:backgroundImage", "update:backgroundRenderMode", "update:fov"]),
  setup(__props, { emit: __emit }) {
    const emit = __emit;
    const showGrid = useModel(__props, "showGrid");
    const backgroundColor = useModel(__props, "backgroundColor");
    const backgroundImage = useModel(__props, "backgroundImage");
    const backgroundRenderMode = useModel(
      __props,
      "backgroundRenderMode"
    );
    const fov = useModel(__props, "fov");
    const hasBackgroundImage = computed(
      () => backgroundImage.value && backgroundImage.value !== ""
    );
    const colorPickerRef = ref(null);
    const imagePickerRef = ref(null);
    const toggleGrid = /* @__PURE__ */ __name(() => {
      showGrid.value = !showGrid.value;
    }, "toggleGrid");
    const updateBackgroundColor = /* @__PURE__ */ __name((color) => {
      backgroundColor.value = color;
    }, "updateBackgroundColor");
    const openColorPicker = /* @__PURE__ */ __name(() => {
      colorPickerRef.value?.click();
    }, "openColorPicker");
    const openImagePicker = /* @__PURE__ */ __name(() => {
      imagePickerRef.value?.click();
    }, "openImagePicker");
    const uploadBackgroundImage = /* @__PURE__ */ __name((event) => {
      const input = event.target;
      if (input.files && input.files[0]) {
        emit("updateBackgroundImage", input.files[0]);
      }
    }, "uploadBackgroundImage");
    const removeBackgroundImage = /* @__PURE__ */ __name(() => {
      emit("updateBackgroundImage", null);
    }, "removeBackgroundImage");
    const toggleBackgroundRenderMode = /* @__PURE__ */ __name(() => {
      backgroundRenderMode.value = backgroundRenderMode.value === "panorama" ? "tiled" : "panorama";
    }, "toggleBackgroundRenderMode");
    return (_ctx, _cache) => {
      const _directive_tooltip = resolveDirective("tooltip");
      return openBlock(), createElementBlock("div", _hoisted_1$7, [
        withDirectives((openBlock(), createBlock(_sfc_main$d, {
          variant: "textonly",
          size: "icon",
          class: normalizeClass(unref(cn)("rounded-full", showGrid.value && "ring-2 ring-white/50")),
          "aria-label": _ctx.$t("load3d.showGrid"),
          onClick: toggleGrid
        }, {
          default: withCtx(() => _cache[2] || (_cache[2] = [
            createBaseVNode("i", { class: "pi pi-table text-lg text-white" }, null, -1)
          ])),
          _: 1
        }, 8, ["class", "aria-label"])), [
          [
            _directive_tooltip,
            { value: _ctx.$t("load3d.showGrid"), showDelay: 300 },
            void 0,
            { right: true }
          ]
        ]),
        !hasBackgroundImage.value ? (openBlock(), createElementBlock("div", _hoisted_2$6, [
          withDirectives((openBlock(), createBlock(_sfc_main$d, {
            variant: "textonly",
            size: "icon",
            class: "rounded-full",
            "aria-label": _ctx.$t("load3d.backgroundColor"),
            onClick: openColorPicker
          }, {
            default: withCtx(() => [
              _cache[3] || (_cache[3] = createBaseVNode("i", { class: "pi pi-palette text-lg text-white" }, null, -1)),
              createBaseVNode("input", {
                ref_key: "colorPickerRef",
                ref: colorPickerRef,
                type: "color",
                value: backgroundColor.value,
                class: "pointer-events-none absolute m-0 h-0 w-0 p-0 opacity-0",
                onInput: _cache[0] || (_cache[0] = ($event) => updateBackgroundColor($event.target.value))
              }, null, 40, _hoisted_3$3)
            ]),
            _: 1
          }, 8, ["aria-label"])), [
            [
              _directive_tooltip,
              {
                value: _ctx.$t("load3d.backgroundColor"),
                showDelay: 300
              },
              void 0,
              { right: true }
            ]
          ])
        ])) : createCommentVNode("", true),
        !hasBackgroundImage.value ? (openBlock(), createElementBlock("div", _hoisted_4$1, [
          withDirectives((openBlock(), createBlock(_sfc_main$d, {
            variant: "textonly",
            size: "icon",
            class: "rounded-full",
            "aria-label": _ctx.$t("load3d.uploadBackgroundImage"),
            onClick: openImagePicker
          }, {
            default: withCtx(() => [
              _cache[4] || (_cache[4] = createBaseVNode("i", { class: "pi pi-image text-lg text-white" }, null, -1)),
              createBaseVNode("input", {
                ref_key: "imagePickerRef",
                ref: imagePickerRef,
                type: "file",
                accept: "image/*",
                class: "pointer-events-none absolute m-0 h-0 w-0 p-0 opacity-0",
                onChange: uploadBackgroundImage
              }, null, 544)
            ]),
            _: 1
          }, 8, ["aria-label"])), [
            [
              _directive_tooltip,
              {
                value: _ctx.$t("load3d.uploadBackgroundImage"),
                showDelay: 300
              },
              void 0,
              { right: true }
            ]
          ])
        ])) : createCommentVNode("", true),
        hasBackgroundImage.value ? (openBlock(), createElementBlock("div", _hoisted_5$1, [
          withDirectives((openBlock(), createBlock(_sfc_main$d, {
            variant: "textonly",
            size: "icon",
            class: normalizeClass(
              unref(cn)(
                "rounded-full",
                backgroundRenderMode.value === "panorama" && "ring-2 ring-white/50"
              )
            ),
            "aria-label": _ctx.$t("load3d.panoramaMode"),
            onClick: toggleBackgroundRenderMode
          }, {
            default: withCtx(() => _cache[5] || (_cache[5] = [
              createBaseVNode("i", { class: "pi pi-globe text-lg text-white" }, null, -1)
            ])),
            _: 1
          }, 8, ["class", "aria-label"])), [
            [
              _directive_tooltip,
              {
                value: _ctx.$t("load3d.panoramaMode"),
                showDelay: 300
              },
              void 0,
              { right: true }
            ]
          ])
        ])) : createCommentVNode("", true),
        hasBackgroundImage.value && backgroundRenderMode.value === "panorama" ? (openBlock(), createBlock(_sfc_main$c, {
          key: 3,
          modelValue: fov.value,
          "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => fov.value = $event),
          "tooltip-text": _ctx.$t("load3d.fov")
        }, null, 8, ["modelValue", "tooltip-text"])) : createCommentVNode("", true),
        hasBackgroundImage.value ? (openBlock(), createElementBlock("div", _hoisted_6, [
          withDirectives((openBlock(), createBlock(_sfc_main$d, {
            variant: "textonly",
            size: "icon",
            class: "rounded-full",
            "aria-label": _ctx.$t("load3d.removeBackgroundImage"),
            onClick: removeBackgroundImage
          }, {
            default: withCtx(() => _cache[6] || (_cache[6] = [
              createBaseVNode("i", { class: "pi pi-times text-lg text-white" }, null, -1)
            ])),
            _: 1
          }, 8, ["aria-label"])), [
            [
              _directive_tooltip,
              {
                value: _ctx.$t("load3d.removeBackgroundImage"),
                showDelay: 300
              },
              void 0,
              { right: true }
            ]
          ])
        ])) : createCommentVNode("", true)
      ]);
    };
  }
});
const _hoisted_1$6 = { class: "show-menu relative" };
const _hoisted_2$5 = { class: "absolute top-0 left-12 rounded-lg bg-black/50 shadow-lg" };
const _hoisted_3$2 = { class: "flex flex-col" };
const _hoisted_4 = { class: "whitespace-nowrap text-white" };
const _hoisted_5 = { class: "rounded-lg bg-smoke-700/30" };
const _sfc_main$6 = /* @__PURE__ */ defineComponent({
  __name: "Load3DControls",
  props: /* @__PURE__ */ mergeModels({
    isSplatModel: { type: Boolean, default: false },
    isPlyModel: { type: Boolean, default: false }
  }, {
    "sceneConfig": {},
    "sceneConfigModifiers": {},
    "modelConfig": {},
    "modelConfigModifiers": {},
    "cameraConfig": {},
    "cameraConfigModifiers": {},
    "lightConfig": {},
    "lightConfigModifiers": {}
  }),
  emits: /* @__PURE__ */ mergeModels(["updateBackgroundImage", "exportModel"], ["update:sceneConfig", "update:modelConfig", "update:cameraConfig", "update:lightConfig"]),
  setup(__props, { emit: __emit }) {
    const sceneConfig = useModel(__props, "sceneConfig");
    const modelConfig = useModel(__props, "modelConfig");
    const cameraConfig = useModel(__props, "cameraConfig");
    const lightConfig = useModel(__props, "lightConfig");
    const isMenuOpen = ref(false);
    const activeCategory = ref("scene");
    const categoryLabels = {
      scene: "load3d.scene",
      model: "load3d.model",
      camera: "load3d.camera",
      light: "load3d.light",
      export: "load3d.export"
    };
    const availableCategories = computed(() => {
      if (__props.isSplatModel) {
        return ["scene", "model", "camera"];
      }
      return ["scene", "model", "camera", "light", "export"];
    });
    const showSceneControls = computed(
      () => activeCategory.value === "scene" && !!sceneConfig.value
    );
    const showModelControls = computed(
      () => activeCategory.value === "model" && !!modelConfig.value
    );
    const showCameraControls = computed(
      () => activeCategory.value === "camera" && !!cameraConfig.value
    );
    const showLightControls = computed(
      () => activeCategory.value === "light" && !!lightConfig.value && !!modelConfig.value
    );
    const showExportControls = computed(() => activeCategory.value === "export");
    const toggleMenu = /* @__PURE__ */ __name(() => {
      isMenuOpen.value = !isMenuOpen.value;
    }, "toggleMenu");
    const selectCategory = /* @__PURE__ */ __name((category) => {
      activeCategory.value = category;
      isMenuOpen.value = false;
    }, "selectCategory");
    const getCategoryIcon = /* @__PURE__ */ __name((category) => {
      const icons = {
        scene: "pi pi-image",
        model: "pi pi-box",
        camera: "pi pi-camera",
        light: "pi pi-sun",
        export: "pi pi-download"
      };
      return `${icons[category]} text-white text-lg`;
    }, "getCategoryIcon");
    const emit = __emit;
    const handleBackgroundImageUpdate = /* @__PURE__ */ __name((file) => {
      emit("updateBackgroundImage", file);
    }, "handleBackgroundImageUpdate");
    const handleExportModel = /* @__PURE__ */ __name((format) => {
      emit("exportModel", format);
    }, "handleExportModel");
    const closeSlider = /* @__PURE__ */ __name((e) => {
      const target = e.target;
      if (!target.closest(".show-menu")) {
        isMenuOpen.value = false;
      }
    }, "closeSlider");
    onMounted(() => {
      document.addEventListener("click", closeSlider);
    });
    onUnmounted(() => {
      document.removeEventListener("click", closeSlider);
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: "pointer-events-auto absolute top-12 left-2 z-20 flex flex-col rounded-lg bg-smoke-700/30",
        onPointerdown: _cache[11] || (_cache[11] = withModifiers(() => {
        }, ["stop"])),
        onPointermove: _cache[12] || (_cache[12] = withModifiers(() => {
        }, ["stop"])),
        onPointerup: _cache[13] || (_cache[13] = withModifiers(() => {
        }, ["stop"])),
        onWheel: _cache[14] || (_cache[14] = withModifiers(() => {
        }, ["stop"]))
      }, [
        createBaseVNode("div", _hoisted_1$6, [
          createVNode(_sfc_main$d, {
            variant: "textonly",
            size: "icon",
            "aria-label": _ctx.$t("menu.showMenu"),
            class: "rounded-full",
            onClick: toggleMenu
          }, {
            default: withCtx(() => _cache[15] || (_cache[15] = [
              createBaseVNode("i", { class: "pi pi-bars text-lg text-white" }, null, -1)
            ])),
            _: 1
          }, 8, ["aria-label"]),
          withDirectives(createBaseVNode("div", _hoisted_2$5, [
            createBaseVNode("div", _hoisted_3$2, [
              (openBlock(true), createElementBlock(Fragment, null, renderList(availableCategories.value, (category) => {
                return openBlock(), createBlock(_sfc_main$d, {
                  key: category,
                  variant: "textonly",
                  class: normalizeClass(
                    unref(cn)(
                      "flex w-full items-center justify-start",
                      activeCategory.value === category && "bg-smoke-600"
                    )
                  ),
                  onClick: /* @__PURE__ */ __name(($event) => selectCategory(category), "onClick")
                }, {
                  default: withCtx(() => [
                    createBaseVNode("i", {
                      class: normalizeClass(getCategoryIcon(category))
                    }, null, 2),
                    createBaseVNode("span", _hoisted_4, toDisplayString(_ctx.$t(categoryLabels[category])), 1)
                  ]),
                  _: 2
                }, 1032, ["class", "onClick"]);
              }), 128))
            ])
          ], 512), [
            [vShow, isMenuOpen.value]
          ])
        ]),
        withDirectives(createBaseVNode("div", _hoisted_5, [
          showSceneControls.value ? (openBlock(), createBlock(_sfc_main$7, {
            key: 0,
            "show-grid": sceneConfig.value.showGrid,
            "onUpdate:showGrid": _cache[0] || (_cache[0] = ($event) => sceneConfig.value.showGrid = $event),
            "background-color": sceneConfig.value.backgroundColor,
            "onUpdate:backgroundColor": _cache[1] || (_cache[1] = ($event) => sceneConfig.value.backgroundColor = $event),
            "background-image": sceneConfig.value.backgroundImage,
            "onUpdate:backgroundImage": _cache[2] || (_cache[2] = ($event) => sceneConfig.value.backgroundImage = $event),
            "background-render-mode": sceneConfig.value.backgroundRenderMode,
            "onUpdate:backgroundRenderMode": _cache[3] || (_cache[3] = ($event) => sceneConfig.value.backgroundRenderMode = $event),
            fov: cameraConfig.value.fov,
            "onUpdate:fov": _cache[4] || (_cache[4] = ($event) => cameraConfig.value.fov = $event),
            onUpdateBackgroundImage: handleBackgroundImageUpdate
          }, null, 8, ["show-grid", "background-color", "background-image", "background-render-mode", "fov"])) : createCommentVNode("", true),
          showModelControls.value ? (openBlock(), createBlock(_sfc_main$8, {
            key: 1,
            "material-mode": modelConfig.value.materialMode,
            "onUpdate:materialMode": _cache[5] || (_cache[5] = ($event) => modelConfig.value.materialMode = $event),
            "up-direction": modelConfig.value.upDirection,
            "onUpdate:upDirection": _cache[6] || (_cache[6] = ($event) => modelConfig.value.upDirection = $event),
            "hide-material-mode": _ctx.isSplatModel,
            "is-ply-model": _ctx.isPlyModel
          }, null, 8, ["material-mode", "up-direction", "hide-material-mode", "is-ply-model"])) : createCommentVNode("", true),
          showCameraControls.value ? (openBlock(), createBlock(_sfc_main$b, {
            key: 2,
            "camera-type": cameraConfig.value.cameraType,
            "onUpdate:cameraType": _cache[7] || (_cache[7] = ($event) => cameraConfig.value.cameraType = $event),
            fov: cameraConfig.value.fov,
            "onUpdate:fov": _cache[8] || (_cache[8] = ($event) => cameraConfig.value.fov = $event)
          }, null, 8, ["camera-type", "fov"])) : createCommentVNode("", true),
          showLightControls.value ? (openBlock(), createBlock(_sfc_main$9, {
            key: 3,
            "light-intensity": lightConfig.value.intensity,
            "onUpdate:lightIntensity": _cache[9] || (_cache[9] = ($event) => lightConfig.value.intensity = $event),
            "material-mode": modelConfig.value.materialMode,
            "onUpdate:materialMode": _cache[10] || (_cache[10] = ($event) => modelConfig.value.materialMode = $event)
          }, null, 8, ["light-intensity", "material-mode"])) : createCommentVNode("", true),
          showExportControls.value ? (openBlock(), createBlock(_sfc_main$a, {
            key: 4,
            onExportModel: handleExportModel
          })) : createCommentVNode("", true)
        ], 512), [
          [vShow, activeCategory.value]
        ])
      ], 32);
    };
  }
});
const _hoisted_1$5 = {
  key: 0,
  class: "bg-opacity-50 absolute inset-0 z-50 flex items-center justify-center bg-black"
};
const _hoisted_2$4 = { class: "flex flex-col items-center" };
const _hoisted_3$1 = { class: "mt-4 text-lg text-white" };
const _sfc_main$5 = /* @__PURE__ */ defineComponent({
  __name: "LoadingOverlay",
  props: {
    loading: { type: Boolean },
    loadingMessage: {}
  },
  setup(__props) {
    return (_ctx, _cache) => {
      return openBlock(), createBlock(Transition, { name: "fade" }, {
        default: withCtx(() => [
          _ctx.loading ? (openBlock(), createElementBlock("div", _hoisted_1$5, [
            createBaseVNode("div", _hoisted_2$4, [
              _cache[0] || (_cache[0] = createBaseVNode("div", { class: "spinner" }, null, -1)),
              createBaseVNode("div", _hoisted_3$1, toDisplayString(_ctx.loadingMessage), 1)
            ])
          ])) : createCommentVNode("", true)
        ]),
        _: 1
      });
    };
  }
});
const LoadingOverlay = /* @__PURE__ */ _export_sfc(_sfc_main$5, [["__scopeId", "data-v-b13965f5"]]);
const _hoisted_1$4 = {
  key: 0,
  class: "pointer-events-none absolute inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm"
};
const _hoisted_2$3 = { class: "rounded-lg border-2 border-dashed border-blue-400 bg-blue-500/20 px-6 py-4 text-lg font-medium text-blue-100" };
const _sfc_main$4 = /* @__PURE__ */ defineComponent({
  __name: "Load3DScene",
  props: {
    initializeLoad3d: { type: Function },
    cleanup: { type: Function },
    loading: { type: Boolean },
    loadingMessage: {},
    onModelDrop: { type: Function },
    isPreview: { type: Boolean }
  },
  setup(__props) {
    const props = __props;
    const container = ref(null);
    const { isDragging, dragMessage, handleDragOver, handleDragLeave, handleDrop } = useLoad3dDrag({
      onModelDrop: /* @__PURE__ */ __name(async (file) => {
        if (props.onModelDrop) {
          await props.onModelDrop(file);
        }
      }, "onModelDrop"),
      disabled: computed(() => props.isPreview)
    });
    onMounted(() => {
      if (container.value) {
        void props.initializeLoad3d(container.value);
      }
    });
    onUnmounted(() => {
      props.cleanup();
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        ref_key: "container",
        ref: container,
        class: "relative h-full w-full",
        "data-capture-wheel": "true",
        onPointerdown: _cache[0] || (_cache[0] = withModifiers(() => {
        }, ["stop"])),
        onPointermove: _cache[1] || (_cache[1] = withModifiers(() => {
        }, ["stop"])),
        onPointerup: _cache[2] || (_cache[2] = withModifiers(() => {
        }, ["stop"])),
        onMousedown: _cache[3] || (_cache[3] = withModifiers(() => {
        }, ["stop"])),
        onMousemove: _cache[4] || (_cache[4] = withModifiers(() => {
        }, ["stop"])),
        onMouseup: _cache[5] || (_cache[5] = withModifiers(() => {
        }, ["stop"])),
        onContextmenu: _cache[6] || (_cache[6] = withModifiers(() => {
        }, ["stop", "prevent"])),
        onDragover: _cache[7] || (_cache[7] = withModifiers(
          //@ts-ignore
          (...args) => unref(handleDragOver) && unref(handleDragOver)(...args),
          ["prevent", "stop"]
        )),
        onDragleave: _cache[8] || (_cache[8] = withModifiers(
          //@ts-ignore
          (...args) => unref(handleDragLeave) && unref(handleDragLeave)(...args),
          ["stop"]
        )),
        onDrop: _cache[9] || (_cache[9] = withModifiers(
          //@ts-ignore
          (...args) => unref(handleDrop) && unref(handleDrop)(...args),
          ["prevent", "stop"]
        ))
      }, [
        createVNode(LoadingOverlay, {
          loading: _ctx.loading,
          "loading-message": _ctx.loadingMessage
        }, null, 8, ["loading", "loading-message"]),
        !_ctx.isPreview && unref(isDragging) ? (openBlock(), createElementBlock("div", _hoisted_1$4, [
          createBaseVNode("div", _hoisted_2$3, toDisplayString(unref(dragMessage)), 1)
        ])) : createCommentVNode("", true)
      ], 544);
    };
  }
});
const _hoisted_1$3 = {
  key: 0,
  class: "pointer-events-auto absolute top-0 left-0 z-10 flex w-full items-center justify-center gap-2 pt-2"
};
const _sfc_main$3 = /* @__PURE__ */ defineComponent({
  __name: "AnimationControls",
  props: {
    "animations": {},
    "animationsModifiers": {},
    "playing": { type: Boolean },
    "playingModifiers": {},
    "selectedSpeed": {},
    "selectedSpeedModifiers": {},
    "selectedAnimation": {},
    "selectedAnimationModifiers": {}
  },
  emits: ["update:animations", "update:playing", "update:selectedSpeed", "update:selectedAnimation"],
  setup(__props) {
    const animations = useModel(__props, "animations");
    const playing = useModel(__props, "playing");
    const selectedSpeed = useModel(__props, "selectedSpeed");
    const selectedAnimation = useModel(__props, "selectedAnimation");
    const speedOptions = [
      { name: "0.1x", value: 0.1 },
      { name: "0.5x", value: 0.5 },
      { name: "1x", value: 1 },
      { name: "1.5x", value: 1.5 },
      { name: "2x", value: 2 }
    ];
    const togglePlay = /* @__PURE__ */ __name(() => {
      playing.value = !playing.value;
    }, "togglePlay");
    return (_ctx, _cache) => {
      return animations.value && animations.value.length > 0 ? (openBlock(), createElementBlock("div", _hoisted_1$3, [
        createVNode(_sfc_main$d, {
          size: "icon",
          variant: "textonly",
          class: "rounded-full",
          "aria-label": _ctx.$t("g.playPause"),
          onClick: togglePlay
        }, {
          default: withCtx(() => [
            createBaseVNode("i", {
              class: normalizeClass(["pi", playing.value ? "pi-pause" : "pi-play", "text-lg text-white"])
            }, null, 2)
          ]),
          _: 1
        }, 8, ["aria-label"]),
        createVNode(unref(script$1), {
          modelValue: selectedSpeed.value,
          "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => selectedSpeed.value = $event),
          options: speedOptions,
          "option-label": "name",
          "option-value": "value",
          class: "w-24"
        }, null, 8, ["modelValue"]),
        createVNode(unref(script$1), {
          modelValue: selectedAnimation.value,
          "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => selectedAnimation.value = $event),
          options: animations.value,
          "option-label": "name",
          "option-value": "index",
          class: "w-32"
        }, null, 8, ["modelValue", "options"])
      ])) : createCommentVNode("", true);
    };
  }
});
const _hoisted_1$2 = { class: "relative rounded-lg bg-smoke-700/30" };
const _hoisted_2$2 = { class: "flex flex-col gap-2" };
const _hoisted_3 = {
  key: 2,
  class: "mt-1 text-center text-xs text-white"
};
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "RecordingControls",
  props: {
    "hasRecording": { type: Boolean },
    "hasRecordingModifiers": {},
    "isRecording": { type: Boolean },
    "isRecordingModifiers": {},
    "recordingDuration": {},
    "recordingDurationModifiers": {}
  },
  emits: /* @__PURE__ */ mergeModels(["startRecording", "stopRecording", "exportRecording", "clearRecording"], ["update:hasRecording", "update:isRecording", "update:recordingDuration"]),
  setup(__props, { emit: __emit }) {
    const hasRecording = useModel(__props, "hasRecording");
    const isRecording = useModel(__props, "isRecording");
    const recordingDuration = useModel(__props, "recordingDuration");
    const emit = __emit;
    function toggleRecording() {
      if (isRecording.value) {
        emit("stopRecording");
      } else {
        emit("startRecording");
      }
    }
    __name(toggleRecording, "toggleRecording");
    function handleExportRecording() {
      emit("exportRecording");
    }
    __name(handleExportRecording, "handleExportRecording");
    function handleClearRecording() {
      emit("clearRecording");
    }
    __name(handleClearRecording, "handleClearRecording");
    function formatDuration(seconds) {
      const minutes = Math.floor(seconds / 60);
      const remainingSeconds = Math.floor(seconds % 60);
      return `${minutes.toString().padStart(2, "0")}:${remainingSeconds.toString().padStart(2, "0")}`;
    }
    __name(formatDuration, "formatDuration");
    return (_ctx, _cache) => {
      const _directive_tooltip = resolveDirective("tooltip");
      return openBlock(), createElementBlock("div", _hoisted_1$2, [
        createBaseVNode("div", _hoisted_2$2, [
          withDirectives((openBlock(), createBlock(_sfc_main$d, {
            size: "icon",
            variant: "textonly",
            class: normalizeClass(
              unref(cn)(
                "rounded-full",
                isRecording.value && "text-red-500 recording-button-blink"
              )
            ),
            "aria-label": isRecording.value ? _ctx.$t("load3d.stopRecording") : _ctx.$t("load3d.startRecording"),
            onClick: toggleRecording
          }, {
            default: withCtx(() => [
              createBaseVNode("i", {
                class: normalizeClass([
                  "pi",
                  isRecording.value ? "pi-circle-fill" : "pi-video",
                  "text-lg text-white"
                ])
              }, null, 2)
            ]),
            _: 1
          }, 8, ["class", "aria-label"])), [
            [
              _directive_tooltip,
              {
                value: isRecording.value ? _ctx.$t("load3d.stopRecording") : _ctx.$t("load3d.startRecording"),
                showDelay: 300
              },
              void 0,
              { right: true }
            ]
          ]),
          hasRecording.value && !isRecording.value ? withDirectives((openBlock(), createBlock(_sfc_main$d, {
            key: 0,
            size: "icon",
            variant: "textonly",
            class: "rounded-full",
            "aria-label": _ctx.$t("load3d.exportRecording"),
            onClick: handleExportRecording
          }, {
            default: withCtx(() => _cache[0] || (_cache[0] = [
              createBaseVNode("i", { class: "pi pi-download text-lg text-white" }, null, -1)
            ])),
            _: 1
          }, 8, ["aria-label"])), [
            [
              _directive_tooltip,
              {
                value: _ctx.$t("load3d.exportRecording"),
                showDelay: 300
              },
              void 0,
              { right: true }
            ]
          ]) : createCommentVNode("", true),
          hasRecording.value && !isRecording.value ? withDirectives((openBlock(), createBlock(_sfc_main$d, {
            key: 1,
            size: "icon",
            variant: "textonly",
            class: "rounded-full",
            "aria-label": _ctx.$t("load3d.clearRecording"),
            onClick: handleClearRecording
          }, {
            default: withCtx(() => _cache[1] || (_cache[1] = [
              createBaseVNode("i", { class: "pi pi-trash text-lg text-white" }, null, -1)
            ])),
            _: 1
          }, 8, ["aria-label"])), [
            [
              _directive_tooltip,
              {
                value: _ctx.$t("load3d.clearRecording"),
                showDelay: 300
              },
              void 0,
              { right: true }
            ]
          ]) : createCommentVNode("", true),
          recordingDuration.value && recordingDuration.value > 0 && !isRecording.value ? (openBlock(), createElementBlock("div", _hoisted_3, toDisplayString(formatDuration(recordingDuration.value)), 1)) : createCommentVNode("", true)
        ])
      ]);
    };
  }
});
const RecordingControls = /* @__PURE__ */ _export_sfc(_sfc_main$2, [["__scopeId", "data-v-a74d27e9"]]);
const _hoisted_1$1 = { class: "relative rounded-lg bg-smoke-700/30" };
const _hoisted_2$1 = { class: "flex flex-col gap-2" };
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "ViewerControls",
  props: {
    node: {}
  },
  setup(__props) {
    const openIn3DViewer = /* @__PURE__ */ __name(() => {
      const props = { node: __props.node };
      useDialogStore().showDialog({
        key: "global-load3d-viewer",
        title: t("load3d.viewer.title"),
        component: Load3DViewerContent,
        props,
        dialogComponentProps: {
          style: "width: 80vw; height: 80vh;",
          maximizable: true,
          onClose: /* @__PURE__ */ __name(async () => {
            await useLoad3dService().handleViewerClose(props.node);
          }, "onClose")
        }
      });
    }, "openIn3DViewer");
    return (_ctx, _cache) => {
      const _directive_tooltip = resolveDirective("tooltip");
      return openBlock(), createElementBlock("div", _hoisted_1$1, [
        createBaseVNode("div", _hoisted_2$1, [
          withDirectives((openBlock(), createBlock(_sfc_main$d, {
            size: "icon",
            variant: "textonly",
            class: "rounded-full",
            "aria-label": unref(t)("load3d.openIn3DViewer"),
            onClick: openIn3DViewer
          }, {
            default: withCtx(() => _cache[0] || (_cache[0] = [
              createBaseVNode("i", { class: "pi pi-expand text-lg text-white" }, null, -1)
            ])),
            _: 1
          }, 8, ["aria-label"])), [
            [
              _directive_tooltip,
              {
                value: unref(t)("load3d.openIn3DViewer"),
                showDelay: 300
              },
              void 0,
              { right: true }
            ]
          ])
        ])
      ]);
    };
  }
});
const _hoisted_1 = { class: "pointer-events-none absolute top-0 left-0 size-full" };
const _hoisted_2 = {
  key: 1,
  class: "pointer-events-auto absolute top-12 right-2 z-20"
};
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "Load3D",
  props: {
    widget: {},
    nodeId: {}
  },
  setup(__props) {
    const props = __props;
    function isComponentWidget(widget) {
      return "node" in widget && widget.node !== void 0;
    }
    __name(isComponentWidget, "isComponentWidget");
    const node = ref(null);
    if (isComponentWidget(props.widget)) {
      node.value = props.widget.node;
    } else if (props.nodeId) {
      onMounted(() => {
        node.value = app.rootGraph?.getNodeById(props.nodeId) || null;
      });
    }
    const {
      // configs
      sceneConfig,
      modelConfig,
      cameraConfig,
      lightConfig,
      // other state
      isRecording,
      isPreview,
      isSplatModel,
      isPlyModel,
      hasRecording,
      recordingDuration,
      animations,
      playing,
      selectedSpeed,
      selectedAnimation,
      loading,
      loadingMessage,
      // Methods
      initializeLoad3d,
      handleMouseEnter,
      handleMouseLeave,
      handleStartRecording,
      handleStopRecording,
      handleExportRecording,
      handleClearRecording,
      handleBackgroundImageUpdate,
      handleExportModel,
      handleModelDrop,
      cleanup
    } = useLoad3d(node);
    const enable3DViewer = computed(
      () => useSettingStore().get("Comfy.Load3D.3DViewerEnable")
    );
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: "relative size-full",
        onMouseenter: _cache[11] || (_cache[11] = //@ts-ignore
        (...args) => unref(handleMouseEnter) && unref(handleMouseEnter)(...args)),
        onMouseleave: _cache[12] || (_cache[12] = //@ts-ignore
        (...args) => unref(handleMouseLeave) && unref(handleMouseLeave)(...args)),
        onPointerdown: _cache[13] || (_cache[13] = withModifiers(() => {
        }, ["stop"])),
        onPointermove: _cache[14] || (_cache[14] = withModifiers(() => {
        }, ["stop"])),
        onPointerup: _cache[15] || (_cache[15] = withModifiers(() => {
        }, ["stop"]))
      }, [
        node.value ? (openBlock(), createBlock(_sfc_main$4, {
          key: 0,
          "initialize-load3d": unref(initializeLoad3d),
          cleanup: unref(cleanup),
          loading: unref(loading),
          "loading-message": unref(loadingMessage),
          "on-model-drop": unref(isPreview) ? void 0 : unref(handleModelDrop),
          "is-preview": unref(isPreview)
        }, null, 8, ["initialize-load3d", "cleanup", "loading", "loading-message", "on-model-drop", "is-preview"])) : createCommentVNode("", true),
        createBaseVNode("div", _hoisted_1, [
          createVNode(_sfc_main$6, {
            "scene-config": unref(sceneConfig),
            "onUpdate:sceneConfig": _cache[0] || (_cache[0] = ($event) => isRef(sceneConfig) ? sceneConfig.value = $event : null),
            "model-config": unref(modelConfig),
            "onUpdate:modelConfig": _cache[1] || (_cache[1] = ($event) => isRef(modelConfig) ? modelConfig.value = $event : null),
            "camera-config": unref(cameraConfig),
            "onUpdate:cameraConfig": _cache[2] || (_cache[2] = ($event) => isRef(cameraConfig) ? cameraConfig.value = $event : null),
            "light-config": unref(lightConfig),
            "onUpdate:lightConfig": _cache[3] || (_cache[3] = ($event) => isRef(lightConfig) ? lightConfig.value = $event : null),
            "is-splat-model": unref(isSplatModel),
            "is-ply-model": unref(isPlyModel),
            onUpdateBackgroundImage: unref(handleBackgroundImageUpdate),
            onExportModel: unref(handleExportModel)
          }, null, 8, ["scene-config", "model-config", "camera-config", "light-config", "is-splat-model", "is-ply-model", "onUpdateBackgroundImage", "onExportModel"]),
          unref(animations) && unref(animations).length > 0 ? (openBlock(), createBlock(_sfc_main$3, {
            key: 0,
            animations: unref(animations),
            "onUpdate:animations": _cache[4] || (_cache[4] = ($event) => isRef(animations) ? animations.value = $event : null),
            playing: unref(playing),
            "onUpdate:playing": _cache[5] || (_cache[5] = ($event) => isRef(playing) ? playing.value = $event : null),
            "selected-speed": unref(selectedSpeed),
            "onUpdate:selectedSpeed": _cache[6] || (_cache[6] = ($event) => isRef(selectedSpeed) ? selectedSpeed.value = $event : null),
            "selected-animation": unref(selectedAnimation),
            "onUpdate:selectedAnimation": _cache[7] || (_cache[7] = ($event) => isRef(selectedAnimation) ? selectedAnimation.value = $event : null)
          }, null, 8, ["animations", "playing", "selected-speed", "selected-animation"])) : createCommentVNode("", true)
        ]),
        enable3DViewer.value && node.value ? (openBlock(), createElementBlock("div", _hoisted_2, [
          createVNode(_sfc_main$1, {
            node: node.value
          }, null, 8, ["node"])
        ])) : createCommentVNode("", true),
        !unref(isPreview) ? (openBlock(), createElementBlock("div", {
          key: 2,
          class: normalizeClass(["pointer-events-auto absolute right-2 z-20", {
            "top-12": !enable3DViewer.value,
            "top-24": enable3DViewer.value
          }])
        }, [
          createVNode(RecordingControls, {
            "is-recording": unref(isRecording),
            "onUpdate:isRecording": _cache[8] || (_cache[8] = ($event) => isRef(isRecording) ? isRecording.value = $event : null),
            "has-recording": unref(hasRecording),
            "onUpdate:hasRecording": _cache[9] || (_cache[9] = ($event) => isRef(hasRecording) ? hasRecording.value = $event : null),
            "recording-duration": unref(recordingDuration),
            "onUpdate:recordingDuration": _cache[10] || (_cache[10] = ($event) => isRef(recordingDuration) ? recordingDuration.value = $event : null),
            onStartRecording: unref(handleStartRecording),
            onStopRecording: unref(handleStopRecording),
            onExportRecording: unref(handleExportRecording),
            onClearRecording: unref(handleClearRecording)
          }, null, 8, ["is-recording", "has-recording", "recording-duration", "onStartRecording", "onStopRecording", "onExportRecording", "onClearRecording"])
        ], 2)) : createCommentVNode("", true)
      ], 32);
    };
  }
});
export {
  _sfc_main as _
};
//# sourceMappingURL=Load3D.vue_vue_type_script_setup_true_lang-Bxq2N41Q.js.map
