var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
import { d as _export_sfc } from "./index-Olrb7AGO.js";
import { c as createElementBlock, d as openBlock, e as createBaseVNode, u as toDisplayString } from "./vendor-other-CzYzbUcM.js";
import "./vendor-primevue-Ch6rhmJJ.js";
import "./vendor-vue-DLbRHZS7.js";
import "./vendor-xterm-BF8peZ5_.js";
import "./vendor-three-DYL0ZbEr.js";
import "./vendor-tiptap-XfQ74oRB.js";
const _sfc_main = {};
const _hoisted_1 = { class: "relative size-full overflow-hidden rounded" };
const _hoisted_2 = { class: "flex size-full flex-col items-center justify-center gap-2 bg-modal-card-placeholder-background transition-transform duration-300 group-hover:scale-105 group-data-[selected=true]:scale-105" };
const _hoisted_3 = { class: "text-sm text-base-foreground" };
function _sfc_render(_ctx, _cache) {
  return openBlock(), createElementBlock("div", _hoisted_1, [
    createBaseVNode("div", _hoisted_2, [
      _cache[0] || (_cache[0] = createBaseVNode("i", { class: "icon-[lucide--box] text-3xl text-muted-foreground" }, null, -1)),
      createBaseVNode("span", _hoisted_3, toDisplayString(_ctx.$t("assetBrowser.media.threeDModelPlaceholder")), 1)
    ])
  ]);
}
__name(_sfc_render, "_sfc_render");
const Media3DTop = /* @__PURE__ */ _export_sfc(_sfc_main, [["render", _sfc_render]]);
export {
  Media3DTop as default
};
//# sourceMappingURL=Media3DTop-4FC2Vskx.js.map
