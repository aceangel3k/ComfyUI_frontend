import { dq as getFilenameDetails, dj as formatSize } from "./index-Olrb7AGO.js";
import { _ as _sfc_main$1 } from "./MediaTitle.vue_vue_type_script_setup_true_lang-BmPrdT_Z.js";
import { bq as defineComponent, E as computed, c as createElementBlock, d as openBlock, z as createVNode, q as createCommentVNode, e as createBaseVNode, u as toDisplayString, br as unref } from "./vendor-other-CzYzbUcM.js";
import "./vendor-primevue-Ch6rhmJJ.js";
import "./vendor-vue-DLbRHZS7.js";
import "./vendor-xterm-BF8peZ5_.js";
import "./vendor-three-DYL0ZbEr.js";
import "./vendor-tiptap-XfQ74oRB.js";
const _hoisted_1 = { class: "flex flex-col items-center gap-1" };
const _hoisted_2 = {
  key: 0,
  class: "flex items-center gap-2 text-xs text-zinc-400"
};
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "MediaAudioBottom",
  props: {
    asset: {}
  },
  setup(__props) {
    const fileName = computed(() => {
      return getFilenameDetails(__props.asset.name).filename;
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1, [
        createVNode(_sfc_main$1, { "file-name": fileName.value }, null, 8, ["file-name"]),
        _ctx.asset.size ? (openBlock(), createElementBlock("div", _hoisted_2, [
          createBaseVNode("span", null, toDisplayString(unref(formatSize)(_ctx.asset.size)), 1)
        ])) : createCommentVNode("", true)
      ]);
    };
  }
});
export {
  _sfc_main as default
};
//# sourceMappingURL=MediaAudioBottom-ruMbeFI4.js.map
