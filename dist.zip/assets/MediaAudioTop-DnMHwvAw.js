import { bq as defineComponent, c as createElementBlock, d as openBlock, e as createBaseVNode, u as toDisplayString, I as withModifiers } from "./vendor-other-CzYzbUcM.js";
const _hoisted_1 = { class: "relative size-full overflow-hidden rounded" };
const _hoisted_2 = { class: "flex size-full flex-col items-center justify-center gap-2 bg-modal-card-placeholder-background transition-transform duration-300 group-hover:scale-105 group-data-[selected=true]:scale-105" };
const _hoisted_3 = { class: "text-base-foreground" };
const _hoisted_4 = ["src"];
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "MediaAudioTop",
  props: {
    asset: {}
  },
  setup(__props) {
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1, [
        createBaseVNode("div", _hoisted_2, [
          _cache[1] || (_cache[1] = createBaseVNode("i", { class: "icon-[lucide--music] text-3xl text-base-foreground" }, null, -1)),
          createBaseVNode("span", _hoisted_3, toDisplayString(_ctx.$t("assetBrowser.media.audioPlaceholder")), 1)
        ]),
        createBaseVNode("audio", {
          controls: "",
          class: "absolute bottom-0 left-0 w-full p-2",
          src: _ctx.asset.src,
          onClick: _cache[0] || (_cache[0] = withModifiers(() => {
          }, ["stop"]))
        }, null, 8, _hoisted_4)
      ]);
    };
  }
});
export {
  _sfc_main as default
};
//# sourceMappingURL=MediaAudioTop-DnMHwvAw.js.map
