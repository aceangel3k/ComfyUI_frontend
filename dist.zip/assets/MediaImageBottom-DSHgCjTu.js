import { dq as getFilenameDetails } from "./index-CiA0eywX.js";
import { _ as _sfc_main$1 } from "./MediaTitle.vue_vue_type_script_setup_true_lang-gUyhBvBE.js";
import { bq as defineComponent, E as computed, c as createElementBlock, d as openBlock, z as createVNode, e as createBaseVNode, q as createCommentVNode, u as toDisplayString } from "./vendor-other-CzYzbUcM.js";
import "./vendor-primevue-Ch6rhmJJ.js";
import "./vendor-vue-DLbRHZS7.js";
import "./vendor-xterm-BF8peZ5_.js";
import "./vendor-three-DYL0ZbEr.js";
import "./vendor-tiptap-XfQ74oRB.js";
const _hoisted_1 = { class: "flex flex-col items-center gap-1" };
const _hoisted_2 = { class: "flex items-center text-xs text-zinc-400" };
const _hoisted_3 = { key: 0 };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "MediaImageBottom",
  props: {
    asset: {}
  },
  setup(__props) {
    const fileName = computed(() => {
      return getFilenameDetails(__props.asset.name).filename;
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1, [
        createVNode(_sfc_main$1, { "file-name": fileName.value }, null, 8, ["file-name"]),
        createBaseVNode("div", _hoisted_2, [
          _ctx.asset.dimensions ? (openBlock(), createElementBlock("span", _hoisted_3, toDisplayString(_ctx.asset.dimensions?.width) + "x" + toDisplayString(_ctx.asset.dimensions?.height), 1)) : createCommentVNode("", true)
        ])
      ]);
    };
  }
});
export {
  _sfc_main as default
};
//# sourceMappingURL=MediaImageBottom-DSHgCjTu.js.map
