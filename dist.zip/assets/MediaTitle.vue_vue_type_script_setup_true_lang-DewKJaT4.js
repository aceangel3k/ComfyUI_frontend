import { dr as truncateFilename } from "./index-CCPcyh0b.js";
import { bq as defineComponent, E as computed, c as createElementBlock, d as openBlock, u as toDisplayString } from "./vendor-other-CzYzbUcM.js";
const _hoisted_1 = ["title"];
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "MediaTitle",
  props: {
    fileName: {}
  },
  setup(__props) {
    const props = __props;
    const fullName = computed(() => props.fileName);
    const displayName = computed(() => truncateFilename(props.fileName));
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("h3", {
        class: "m-0 line-clamp-1 text-sm font-bold text-base-foreground",
        title: fullName.value
      }, toDisplayString(displayName.value), 9, _hoisted_1);
    };
  }
});
export {
  _sfc_main as _
};
//# sourceMappingURL=MediaTitle.vue_vue_type_script_setup_true_lang-DewKJaT4.js.map
