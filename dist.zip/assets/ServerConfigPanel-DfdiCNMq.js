var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
import { s as storeToRefs, u as useI18n } from "./vendor-vue-DLbRHZS7.js";
import { q as script, s as script$1 } from "./vendor-primevue-Ch6rhmJJ.js";
import { e as useSettingStore, f as useToastStore, M as useCopyToClipboard, dp as FormItem, _ as _sfc_main$1, dl as _sfc_main$2, bm as electronAPI } from "./index-CCPcyh0b.js";
import { u as useServerConfigStore } from "./serverConfigStore-CulKZi3K.js";
import { bq as defineComponent, w as watch, d8 as onBeforeUnmount, j as createBlock, d as openBlock, k as withCtx, c as createElementBlock, F as Fragment, y as renderList, br as unref, q as createCommentVNode, e as createBaseVNode, u as toDisplayString, z as createVNode, A as createTextVNode } from "./vendor-other-CzYzbUcM.js";
import "./vendor-xterm-BF8peZ5_.js";
import "./vendor-three-DYL0ZbEr.js";
import "./vendor-tiptap-XfQ74oRB.js";
const _hoisted_1 = { class: "flex flex-col gap-2" };
const _hoisted_2 = { class: "flex justify-end gap-2" };
const _hoisted_3 = { class: "flex items-center justify-between" };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "ServerConfigPanel",
  setup(__props) {
    const settingStore = useSettingStore();
    const serverConfigStore = useServerConfigStore();
    const toastStore = useToastStore();
    const {
      serverConfigsByCategory,
      serverConfigValues,
      launchArgs,
      commandLineArgs,
      modifiedConfigs
    } = storeToRefs(serverConfigStore);
    let restartTriggered = false;
    const revertChanges = /* @__PURE__ */ __name(() => {
      serverConfigStore.revertChanges();
    }, "revertChanges");
    const restartApp = /* @__PURE__ */ __name(async () => {
      restartTriggered = true;
      await electronAPI().restartApp();
    }, "restartApp");
    watch(launchArgs, async (newVal) => {
      await settingStore.set("Comfy.Server.LaunchArgs", newVal);
    });
    watch(serverConfigValues, async (newVal) => {
      await settingStore.set("Comfy.Server.ServerConfigValues", newVal);
    });
    const { copyToClipboard } = useCopyToClipboard();
    const copyCommandLineArgs = /* @__PURE__ */ __name(async () => {
      await copyToClipboard(commandLineArgs.value);
    }, "copyCommandLineArgs");
    const { t } = useI18n();
    onBeforeUnmount(() => {
      if (restartTriggered) {
        return;
      }
      if (modifiedConfigs.value.length === 0) {
        return;
      }
      toastStore.add({
        severity: "warn",
        summary: t("serverConfig.restartRequiredToastSummary"),
        detail: t("serverConfig.restartRequiredToastDetail"),
        life: 1e4
      });
    });
    const translateItem = /* @__PURE__ */ __name((item) => {
      return {
        ...item,
        name: t(`serverConfigItems.${item.id}.name`, item.name),
        tooltip: item.tooltip ? t(`serverConfigItems.${item.id}.tooltip`, item.tooltip) : void 0
      };
    }, "translateItem");
    return (_ctx, _cache) => {
      return openBlock(), createBlock(_sfc_main$2, {
        value: "Server-Config",
        class: "server-config-panel"
      }, {
        header: withCtx(() => [
          createBaseVNode("div", _hoisted_1, [
            unref(modifiedConfigs).length > 0 ? (openBlock(), createBlock(unref(script$1), {
              key: 0,
              severity: "info",
              "pt:text": "w-full"
            }, {
              default: withCtx(() => [
                createBaseVNode("p", null, toDisplayString(_ctx.$t("serverConfig.modifiedConfigs")), 1),
                createBaseVNode("ul", null, [
                  (openBlock(true), createElementBlock(Fragment, null, renderList(unref(modifiedConfigs), (config) => {
                    return openBlock(), createElementBlock("li", {
                      key: config.id
                    }, toDisplayString(config.name) + ": " + toDisplayString(config.initialValue) + " → " + toDisplayString(config.value), 1);
                  }), 128))
                ]),
                createBaseVNode("div", _hoisted_2, [
                  createVNode(_sfc_main$1, {
                    variant: "secondary",
                    onClick: revertChanges
                  }, {
                    default: withCtx(() => [
                      createTextVNode(toDisplayString(_ctx.$t("serverConfig.revertChanges")), 1)
                    ]),
                    _: 1
                  }),
                  createVNode(_sfc_main$1, {
                    variant: "destructive",
                    onClick: restartApp
                  }, {
                    default: withCtx(() => [
                      createTextVNode(toDisplayString(_ctx.$t("serverConfig.restart")), 1)
                    ]),
                    _: 1
                  })
                ])
              ]),
              _: 1
            })) : createCommentVNode("", true),
            unref(commandLineArgs) ? (openBlock(), createBlock(unref(script$1), {
              key: 1,
              severity: "secondary",
              "pt:text": "w-full"
            }, {
              icon: withCtx(() => _cache[0] || (_cache[0] = [
                createBaseVNode("i", { class: "icon-[lucide--terminal] text-xl font-bold" }, null, -1)
              ])),
              default: withCtx(() => [
                createBaseVNode("div", _hoisted_3, [
                  createBaseVNode("p", null, toDisplayString(unref(commandLineArgs)), 1),
                  createVNode(_sfc_main$1, {
                    size: "icon",
                    variant: "muted-textonly",
                    onClick: copyCommandLineArgs
                  }, {
                    default: withCtx(() => _cache[1] || (_cache[1] = [
                      createBaseVNode("i", { class: "pi pi-clipboard" }, null, -1)
                    ])),
                    _: 1
                  })
                ])
              ]),
              _: 1
            })) : createCommentVNode("", true)
          ])
        ]),
        default: withCtx(() => [
          (openBlock(true), createElementBlock(Fragment, null, renderList(Object.entries(unref(serverConfigsByCategory)), ([label, items], i) => {
            return openBlock(), createElementBlock("div", { key: label }, [
              i > 0 ? (openBlock(), createBlock(unref(script), { key: 0 })) : createCommentVNode("", true),
              createBaseVNode("h3", null, toDisplayString(_ctx.$t(`serverConfigCategories.${label}`, label)), 1),
              (openBlock(true), createElementBlock(Fragment, null, renderList(items, (item) => {
                return openBlock(), createElementBlock("div", {
                  key: item.name,
                  class: "mb-4"
                }, [
                  createVNode(FormItem, {
                    id: item.id,
                    "form-value": item.value,
                    "onUpdate:formValue": /* @__PURE__ */ __name(($event) => item.value = $event, "onUpdate:formValue"),
                    item: translateItem(item),
                    "label-class": {
                      "text-highlight": item.initialValue !== item.value
                    }
                  }, null, 8, ["id", "form-value", "onUpdate:formValue", "item", "label-class"])
                ]);
              }), 128))
            ]);
          }), 128))
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default
};
//# sourceMappingURL=ServerConfigPanel-DfdiCNMq.js.map
