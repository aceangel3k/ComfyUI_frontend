var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
import { t, ds as TIER_PRICING, a2 as useFirebaseAuthStore, l as useSubscription, a1 as useFirebaseAuthActions, V as useErrorHandling, dt as TIER_TO_KEY, c as cn, _ as _sfc_main$5, d as _export_sfc, z as useCommandStore, b as isCloud } from "./index-45IpBQOM.js";
import { _ as _sfc_main$4, a as _sfc_main$6 } from "./GraphView-Cl43d-qi.js";
import { bq as defineComponent, E as computed, j as createBlock, d as openBlock, r as ref, c as createElementBlock, e as createBaseVNode, z as createVNode, br as unref, k as withCtx, q as createCommentVNode, u as toDisplayString, F as Fragment, y as renderList, s as normalizeClass, l as withDirectives, A as createTextVNode, v as vShow, w as watch, d8 as onBeforeUnmount } from "./vendor-other-CzYzbUcM.js";
import { v as script, p as script$1 } from "./vendor-primevue-Ch6rhmJJ.js";
import { u as useI18n } from "./vendor-vue-DLbRHZS7.js";
import "./vendor-xterm-BF8peZ5_.js";
import "./vendor-three-DYL0ZbEr.js";
import "./vendor-tiptap-XfQ74oRB.js";
import "./UserAvatar.vue_vue_type_script_setup_true_lang-DV-9JnFV.js";
import "./index-DVL01i4N.js";
import "./LazyImage.vue_vue_type_script_setup_true_lang-CCyDZRZD.js";
import "./keybindingService-BNRPWX4A.js";
import "./serverConfigStore-CulKZi3K.js";
import "./WidgetInputNumber.vue_vue_type_script_setup_true_lang-C6ocXsYL.js";
import "./widgetPropFilter-BIbGSUAt.js";
import "./WidgetLayoutField.vue_vue_type_script_setup_true_lang-BI0qfN_B.js";
import "./WidgetWithControl.vue_vue_type_script_setup_true_lang-Cc-xtDRw.js";
const _sfc_main$3 = /* @__PURE__ */ defineComponent({
  __name: "CloudBadge",
  props: {
    displayMode: { default: "full" },
    reverseOrder: { type: Boolean, default: false },
    noPadding: { type: Boolean, default: false },
    backgroundColor: { default: "var(--comfy-menu-bg)" }
  },
  setup(__props) {
    const cloudBadge = computed(() => ({
      label: t("g.beta"),
      text: "Comfy Cloud"
    }));
    return (_ctx, _cache) => {
      return openBlock(), createBlock(_sfc_main$4, {
        badge: cloudBadge.value,
        "display-mode": _ctx.displayMode,
        "reverse-order": _ctx.reverseOrder,
        "no-padding": _ctx.noPadding,
        "background-color": _ctx.backgroundColor
      }, null, 8, ["badge", "display-mode", "reverse-order", "no-padding", "background-color"]);
    };
  }
});
const _imports_0 = "" + new URL("images/cloud-subscription.webm", import.meta.url).href;
const MONTHLY_SUBSCRIPTION_PRICE = 20;
const PLAN_ORDER = [
  "yearly-pro",
  "yearly-creator",
  "yearly-standard",
  "monthly-pro",
  "monthly-creator",
  "monthly-standard"
];
PLAN_ORDER.reduce(
  (acc, plan, index) => acc.set(plan, index),
  /* @__PURE__ */ new Map()
);
const _hoisted_1$2 = { class: "flex flex-col gap-8" };
const _hoisted_2$2 = { class: "flex justify-center" };
const _hoisted_3$2 = { class: "flex items-center gap-2" };
const _hoisted_4$2 = {
  key: 0,
  class: "bg-primary-background text-white text-[11px] px-1 py-0.5 rounded-full flex items-center font-bold"
};
const _hoisted_5$2 = { class: "flex flex-col xl:flex-row items-stretch gap-6" };
const _hoisted_6$1 = { class: "p-8 pb-0 flex flex-col gap-8" };
const _hoisted_7$1 = { class: "flex flex-row items-center gap-2 justify-between" };
const _hoisted_8$1 = { class: "font-inter text-base font-bold leading-normal text-base-foreground" };
const _hoisted_9$1 = {
  key: 0,
  class: "rounded-full bg-base-foreground px-1.5 text-[11px] font-bold uppercase text-base-background h-5 tracking-tight flex items-center"
};
const _hoisted_10$1 = { class: "flex flex-col" };
const _hoisted_11$1 = { class: "flex flex-col gap-2" };
const _hoisted_12$1 = { class: "flex flex-row items-baseline gap-2" };
const _hoisted_13$1 = { class: "font-inter text-[32px] font-semibold leading-normal text-base-foreground" };
const _hoisted_14$1 = { class: "font-inter text-xl leading-normal text-base-foreground" };
const _hoisted_15$1 = { class: "flex items-center gap-2" };
const _hoisted_16$1 = { class: "text-sm text-muted-foreground" };
const _hoisted_17 = { class: "flex flex-col gap-4 pb-0 flex-1" };
const _hoisted_18 = { class: "flex flex-row items-center justify-between" };
const _hoisted_19 = { class: "font-inter text-sm font-normal leading-normal text-foreground" };
const _hoisted_20 = { class: "flex flex-row items-center gap-1" };
const _hoisted_21 = { class: "font-inter text-sm font-bold leading-normal text-base-foreground" };
const _hoisted_22 = { class: "flex flex-row items-center justify-between" };
const _hoisted_23 = { class: "text-sm font-normal text-foreground" };
const _hoisted_24 = { class: "font-inter text-sm font-bold leading-normal text-base-foreground" };
const _hoisted_25 = { class: "flex flex-row items-center justify-between" };
const _hoisted_26 = { class: "text-sm font-normal text-foreground" };
const _hoisted_27 = { class: "flex flex-row items-center justify-between" };
const _hoisted_28 = { class: "text-sm font-normal text-foreground" };
const _hoisted_29 = { class: "flex flex-row items-center justify-between" };
const _hoisted_30 = { class: "text-sm font-normal text-foreground" };
const _hoisted_31 = {
  key: 0,
  class: "pi pi-check text-xs text-success-foreground"
};
const _hoisted_32 = {
  key: 1,
  class: "pi pi-times text-xs text-foreground"
};
const _hoisted_33 = { class: "flex flex-col gap-2" };
const _hoisted_34 = { class: "flex flex-row items-start justify-between" };
const _hoisted_35 = { class: "flex flex-col gap-2" };
const _hoisted_36 = { class: "text-sm font-normal text-foreground" };
const _hoisted_37 = { class: "flex flex-row items-center gap-2 group pt-2" };
const _hoisted_38 = { class: "font-inter text-sm font-bold leading-normal text-base-foreground" };
const _hoisted_39 = { class: "flex flex-col p-8" };
const _hoisted_40 = { class: "flex flex-col gap-2" };
const _hoisted_41 = { class: "text-sm text-base-foreground" };
const _hoisted_42 = {
  href: "https://cloud.comfy.org/?template=video_wan2_2_14B_fun_camera",
  target: "_blank",
  rel: "noopener noreferrer",
  class: "text-sm text-azure-600 hover:text-azure-400 underline"
};
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "PricingTable",
  setup(__props) {
    const billingCycleOptions = [
      { label: t("subscription.yearly"), value: "yearly" },
      { label: t("subscription.monthly"), value: "monthly" }
    ];
    const tiers = [
      {
        id: "STANDARD",
        key: "standard",
        name: t("subscription.tiers.standard.name"),
        pricing: TIER_PRICING.standard,
        maxDuration: t("subscription.maxDuration.standard"),
        customLoRAs: false,
        isPopular: false
      },
      {
        id: "CREATOR",
        key: "creator",
        name: t("subscription.tiers.creator.name"),
        pricing: TIER_PRICING.creator,
        maxDuration: t("subscription.maxDuration.creator"),
        customLoRAs: true,
        isPopular: true
      },
      {
        id: "PRO",
        key: "pro",
        name: t("subscription.tiers.pro.name"),
        pricing: TIER_PRICING.pro,
        maxDuration: t("subscription.maxDuration.pro"),
        customLoRAs: true,
        isPopular: false
      }
    ];
    const { n } = useI18n();
    const { getAuthHeader } = useFirebaseAuthStore();
    const { isActiveSubscription, subscriptionTier, isYearlySubscription } = useSubscription();
    const { accessBillingPortal, reportError } = useFirebaseAuthActions();
    const { wrapWithErrorHandlingAsync } = useErrorHandling();
    const isLoading = ref(false);
    const loadingTier = ref(null);
    const popover = ref();
    const currentBillingCycle = ref("yearly");
    const currentTierKey = computed(
      () => subscriptionTier.value ? TIER_TO_KEY[subscriptionTier.value] : null
    );
    computed(() => {
      if (!currentTierKey.value) return null;
      return {
        tierKey: currentTierKey.value,
        billingCycle: isYearlySubscription.value ? "yearly" : "monthly"
      };
    });
    const isCurrentPlan = /* @__PURE__ */ __name((tierKey) => {
      if (!currentTierKey.value) return false;
      const selectedIsYearly = currentBillingCycle.value === "yearly";
      return currentTierKey.value === tierKey && isYearlySubscription.value === selectedIsYearly;
    }, "isCurrentPlan");
    const togglePopover = /* @__PURE__ */ __name((event) => {
      popover.value.toggle(event);
    }, "togglePopover");
    const getButtonLabel = /* @__PURE__ */ __name((tier) => {
      if (isCurrentPlan(tier.key)) return t("subscription.currentPlan");
      const planName = currentBillingCycle.value === "yearly" ? t("subscription.tierNameYearly", { name: tier.name }) : tier.name;
      return isActiveSubscription.value ? t("subscription.changeTo", { plan: planName }) : t("subscription.subscribeTo", { plan: planName });
    }, "getButtonLabel");
    const getButtonSeverity = /* @__PURE__ */ __name((tier) => isCurrentPlan(tier.key) ? "secondary" : tier.key === "creator" ? "primary" : "secondary", "getButtonSeverity");
    const getButtonTextClass = /* @__PURE__ */ __name((tier) => tier.key === "creator" ? "font-inter text-sm font-bold leading-normal text-base-background" : "font-inter text-sm font-bold leading-normal text-primary-foreground", "getButtonTextClass");
    const getPrice = /* @__PURE__ */ __name((tier) => tier.pricing[currentBillingCycle.value], "getPrice");
    const getAnnualTotal = /* @__PURE__ */ __name((tier) => tier.pricing.yearly * 12, "getAnnualTotal");
    const getCreditsDisplay = /* @__PURE__ */ __name((tier) => tier.pricing.credits * (currentBillingCycle.value === "yearly" ? 12 : 1), "getCreditsDisplay");
    const handleSubscribe = wrapWithErrorHandlingAsync(
      async (tierKey) => {
        return;
      },
      reportError
    );
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1$2, [
        createBaseVNode("div", _hoisted_2$2, [
          createVNode(unref(script), {
            modelValue: currentBillingCycle.value,
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => currentBillingCycle.value = $event),
            options: billingCycleOptions,
            "option-label": "label",
            "option-value": "value",
            "allow-empty": false,
            unstyled: "",
            pt: {
              root: {
                class: "flex gap-1 bg-secondary-background rounded-lg p-1.5"
              },
              pcToggleButton: {
                root: /* @__PURE__ */ __name(({ context }) => ({
                  class: [
                    "w-36  h-8 rounded-md transition-colors cursor-pointer border-none outline-none ring-0 text-sm font-medium flex items-center justify-center",
                    context.active ? "bg-base-foreground text-base-background" : "bg-transparent text-muted-foreground hover:bg-secondary-background-hover"
                  ]
                }), "root"),
                label: { class: "flex items-center gap-2 " }
              }
            }
          }, {
            option: withCtx(({ option }) => [
              createBaseVNode("div", _hoisted_3$2, [
                createBaseVNode("span", null, toDisplayString(option.label), 1),
                option.value === "yearly" ? (openBlock(), createElementBlock("div", _hoisted_4$2, " -20% ")) : createCommentVNode("", true)
              ])
            ]),
            _: 1
          }, 8, ["modelValue", "pt"])
        ]),
        createBaseVNode("div", _hoisted_5$2, [
          (openBlock(), createElementBlock(Fragment, null, renderList(tiers, (tier) => {
            return createBaseVNode("div", {
              key: tier.id,
              class: normalizeClass(
                unref(cn)(
                  "flex-1 flex flex-col rounded-2xl border border-border-default bg-base-background shadow-[0_0_12px_rgba(0,0,0,0.1)]",
                  tier.isPopular ? "border-muted-foreground" : ""
                )
              )
            }, [
              createBaseVNode("div", _hoisted_6$1, [
                createBaseVNode("div", _hoisted_7$1, [
                  createBaseVNode("span", _hoisted_8$1, toDisplayString(tier.name), 1),
                  tier.isPopular ? (openBlock(), createElementBlock("div", _hoisted_9$1, toDisplayString(unref(t)("subscription.mostPopular")), 1)) : createCommentVNode("", true)
                ]),
                createBaseVNode("div", _hoisted_10$1, [
                  createBaseVNode("div", _hoisted_11$1, [
                    createBaseVNode("div", _hoisted_12$1, [
                      createBaseVNode("span", _hoisted_13$1, [
                        withDirectives(createBaseVNode("span", { class: "line-through text-2xl text-muted-foreground" }, " $" + toDisplayString(tier.pricing.monthly), 513), [
                          [vShow, currentBillingCycle.value === "yearly"]
                        ]),
                        createTextVNode(" $" + toDisplayString(getPrice(tier)), 1)
                      ]),
                      createBaseVNode("span", _hoisted_14$1, toDisplayString(unref(t)("subscription.usdPerMonth")), 1)
                    ]),
                    createBaseVNode("div", _hoisted_15$1, [
                      createBaseVNode("span", _hoisted_16$1, toDisplayString(currentBillingCycle.value === "yearly" ? unref(t)("subscription.billedYearly", {
                        total: `$${getAnnualTotal(tier)}`
                      }) : unref(t)("subscription.billedMonthly")), 1)
                    ])
                  ])
                ]),
                createBaseVNode("div", _hoisted_17, [
                  createBaseVNode("div", _hoisted_18, [
                    createBaseVNode("span", _hoisted_19, toDisplayString(currentBillingCycle.value === "yearly" ? unref(t)("subscription.yearlyCreditsLabel") : unref(t)("subscription.monthlyCreditsLabel")), 1),
                    createBaseVNode("div", _hoisted_20, [
                      _cache[1] || (_cache[1] = createBaseVNode("i", { class: "icon-[lucide--component] text-amber-400 text-sm" }, null, -1)),
                      createBaseVNode("span", _hoisted_21, toDisplayString(unref(n)(getCreditsDisplay(tier))), 1)
                    ])
                  ]),
                  createBaseVNode("div", _hoisted_22, [
                    createBaseVNode("span", _hoisted_23, toDisplayString(unref(t)("subscription.maxDurationLabel")), 1),
                    createBaseVNode("span", _hoisted_24, toDisplayString(tier.maxDuration), 1)
                  ]),
                  createBaseVNode("div", _hoisted_25, [
                    createBaseVNode("span", _hoisted_26, toDisplayString(unref(t)("subscription.gpuLabel")), 1),
                    _cache[2] || (_cache[2] = createBaseVNode("i", { class: "pi pi-check text-xs text-success-foreground" }, null, -1))
                  ]),
                  createBaseVNode("div", _hoisted_27, [
                    createBaseVNode("span", _hoisted_28, toDisplayString(unref(t)("subscription.addCreditsLabel")), 1),
                    _cache[3] || (_cache[3] = createBaseVNode("i", { class: "pi pi-check text-xs text-success-foreground" }, null, -1))
                  ]),
                  createBaseVNode("div", _hoisted_29, [
                    createBaseVNode("span", _hoisted_30, toDisplayString(unref(t)("subscription.customLoRAsLabel")), 1),
                    tier.customLoRAs ? (openBlock(), createElementBlock("i", _hoisted_31)) : (openBlock(), createElementBlock("i", _hoisted_32))
                  ]),
                  createBaseVNode("div", _hoisted_33, [
                    createBaseVNode("div", _hoisted_34, [
                      createBaseVNode("div", _hoisted_35, [
                        createBaseVNode("span", _hoisted_36, toDisplayString(unref(t)("subscription.videoEstimateLabel")), 1),
                        createBaseVNode("div", _hoisted_37, [
                          _cache[4] || (_cache[4] = createBaseVNode("i", { class: "pi pi-question-circle text-xs text-muted-foreground group-hover:text-base-foreground" }, null, -1)),
                          createBaseVNode("span", {
                            class: "text-sm font-normal text-muted-foreground cursor-pointer group-hover:text-base-foreground",
                            onClick: togglePopover
                          }, toDisplayString(unref(t)("subscription.videoEstimateHelp")), 1)
                        ])
                      ]),
                      createBaseVNode("span", _hoisted_38, " ~" + toDisplayString(unref(n)(tier.pricing.videoEstimate)), 1)
                    ])
                  ])
                ])
              ]),
              createBaseVNode("div", _hoisted_39, [
                createVNode(_sfc_main$5, {
                  variant: getButtonSeverity(tier),
                  disabled: isLoading.value || isCurrentPlan(tier.key),
                  loading: loadingTier.value === tier.key,
                  class: normalizeClass(
                    unref(cn)(
                      "h-10 w-full",
                      getButtonTextClass(tier),
                      tier.key === "creator" ? "bg-base-foreground border-transparent hover:bg-inverted-background-hover" : "bg-secondary-background border-transparent hover:bg-secondary-background-hover focus:bg-secondary-background-selected"
                    )
                  ),
                  onClick: /* @__PURE__ */ __name(() => unref(handleSubscribe)(tier.key), "onClick")
                }, {
                  default: withCtx(() => [
                    createTextVNode(toDisplayString(getButtonLabel(tier)), 1)
                  ]),
                  _: 2
                }, 1032, ["variant", "disabled", "loading", "class", "onClick"])
              ])
            ], 2);
          }), 64))
        ]),
        createVNode(unref(script$1), {
          ref_key: "popover",
          ref: popover,
          "append-to": "body",
          "auto-z-index": true,
          "base-z-index": 1e3,
          dismissable: true,
          "close-on-escape": true,
          unstyled: "",
          pt: {
            root: {
              class: "rounded-lg border border-interface-stroke bg-interface-panel-surface shadow-lg p-4 max-w-xs"
            }
          }
        }, {
          default: withCtx(() => [
            createBaseVNode("div", _hoisted_40, [
              createBaseVNode("p", _hoisted_41, toDisplayString(unref(t)("subscription.videoEstimateExplanation")), 1),
              createBaseVNode("a", _hoisted_42, toDisplayString(unref(t)("subscription.videoEstimateTryTemplate")), 1)
            ])
          ]),
          _: 1
        }, 512)
      ]);
    };
  }
});
const _sfc_main$1 = {};
const _hoisted_1$1 = { class: "flex flex-col items-start gap-0 self-stretch" };
const _hoisted_2$1 = { class: "flex items-center gap-2 py-2" };
const _hoisted_3$1 = { class: "text-sm text-text-primary" };
const _hoisted_4$1 = { class: "flex items-center gap-2 py-2" };
const _hoisted_5$1 = { class: "text-sm text-text-primary" };
function _sfc_render(_ctx, _cache) {
  return openBlock(), createElementBlock("div", _hoisted_1$1, [
    createBaseVNode("div", _hoisted_2$1, [
      _cache[0] || (_cache[0] = createBaseVNode("i", { class: "pi pi-check text-xs text-text-primary" }, null, -1)),
      createBaseVNode("span", _hoisted_3$1, toDisplayString(_ctx.$t("subscription.benefits.benefit1")), 1)
    ]),
    createBaseVNode("div", _hoisted_4$1, [
      _cache[1] || (_cache[1] = createBaseVNode("i", { class: "pi pi-check text-xs text-text-primary" }, null, -1)),
      createBaseVNode("span", _hoisted_5$1, toDisplayString(_ctx.$t("subscription.benefits.benefit2")), 1)
    ])
  ]);
}
__name(_sfc_render, "_sfc_render");
const SubscriptionBenefits = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["render", _sfc_render]]);
const _hoisted_1 = {
  key: 0,
  class: "relative flex flex-col p-4 pt-8 md:p-16 !overflow-y-auto h-full gap-8"
};
const _hoisted_2 = { class: "text-center" };
const _hoisted_3 = { class: "text-xl lg:text-2xl text-muted-foreground m-0" };
const _hoisted_4 = { class: "flex flex-col items-center gap-2" };
const _hoisted_5 = { class: "text-sm text-text-secondary m-0" };
const _hoisted_6 = { class: "flex items-center gap-1.5" };
const _hoisted_7 = { class: "text-sm text-text-secondary" };
const _hoisted_8 = {
  key: 1,
  class: "legacy-dialog relative grid h-full grid-cols-5"
};
const _hoisted_9 = { class: "col-span-3 flex flex-col justify-between p-8" };
const _hoisted_10 = { class: "flex flex-col gap-6" };
const _hoisted_11 = { class: "inline-flex items-center gap-2" };
const _hoisted_12 = { class: "text-sm text-text-primary" };
const _hoisted_13 = { class: "flex items-baseline gap-2" };
const _hoisted_14 = { class: "text-4xl font-bold" };
const _hoisted_15 = { class: "text-xl" };
const _hoisted_16 = { class: "flex flex-col pt-8" };
const POLL_INTERVAL_MS = 3e3;
const MAX_POLL_ATTEMPTS = 3;
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "SubscriptionRequiredDialogContent",
  props: {
    onClose: { type: Function }
  },
  emits: ["close"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const emit = __emit;
    const { fetchStatus, isActiveSubscription } = useSubscription();
    const formattedMonthlyPrice = new Intl.NumberFormat(
      navigator.language || "en-US",
      {
        style: "currency",
        currency: "USD",
        minimumFractionDigits: 0,
        maximumFractionDigits: 0
      }
    ).format(MONTHLY_SUBSCRIPTION_PRICE);
    const commandStore = useCommandStore();
    const showCustomPricingTable = computed(
      () => isCloud
    );
    let pollInterval = null;
    let pollAttempts = 0;
    const stopPolling = /* @__PURE__ */ __name(() => {
      if (pollInterval) {
        clearInterval(pollInterval);
        pollInterval = null;
      }
    }, "stopPolling");
    const startPolling = /* @__PURE__ */ __name(() => {
      stopPolling();
      pollAttempts = 0;
      const poll = /* @__PURE__ */ __name(async () => {
        try {
          await fetchStatus();
          pollAttempts++;
          if (pollAttempts >= MAX_POLL_ATTEMPTS) {
            stopPolling();
          }
        } catch (error) {
          console.error(
            "[SubscriptionDialog] Failed to poll subscription status",
            error
          );
          stopPolling();
        }
      }, "poll");
      void poll();
      pollInterval = window.setInterval(() => {
        void poll();
      }, POLL_INTERVAL_MS);
    }, "startPolling");
    const handleWindowFocus = /* @__PURE__ */ __name(() => {
      if (showCustomPricingTable.value) {
        startPolling();
      }
    }, "handleWindowFocus");
    watch(
      showCustomPricingTable,
      (enabled) => {
        if (enabled) {
          window.addEventListener("focus", handleWindowFocus);
        } else {
          window.removeEventListener("focus", handleWindowFocus);
          stopPolling();
        }
      },
      { immediate: true }
    );
    watch(
      () => isActiveSubscription.value,
      (isActive) => {
        if (isActive && showCustomPricingTable.value) {
          emit("close", true);
        }
      }
    );
    const handleSubscribed = /* @__PURE__ */ __name(() => {
      emit("close", true);
    }, "handleSubscribed");
    const handleClose = /* @__PURE__ */ __name(() => {
      stopPolling();
      props.onClose();
    }, "handleClose");
    const handleContactUs = /* @__PURE__ */ __name(async () => {
      await commandStore.execute("Comfy.ContactSupport");
    }, "handleContactUs");
    const handleViewEnterprise = /* @__PURE__ */ __name(() => {
      window.open("https://www.comfy.org/cloud/enterprise", "_blank");
    }, "handleViewEnterprise");
    onBeforeUnmount(() => {
      stopPolling();
      window.removeEventListener("focus", handleWindowFocus);
    });
    return (_ctx, _cache) => {
      return showCustomPricingTable.value ? (openBlock(), createElementBlock("div", _hoisted_1, [
        createVNode(_sfc_main$5, {
          size: "icon",
          variant: "muted-textonly",
          class: "rounded-full shrink-0 text-text-secondary hover:bg-white/10 absolute right-2.5 top-2.5",
          "aria-label": _ctx.$t("g.close"),
          onClick: handleClose
        }, {
          default: withCtx(() => _cache[0] || (_cache[0] = [
            createBaseVNode("i", { class: "pi pi-times text-xl" }, null, -1)
          ])),
          _: 1
        }, 8, ["aria-label"]),
        createBaseVNode("div", _hoisted_2, [
          createBaseVNode("h2", _hoisted_3, toDisplayString(_ctx.$t("subscription.description")), 1)
        ]),
        createVNode(_sfc_main$2, { class: "flex-1" }),
        createBaseVNode("div", _hoisted_4, [
          createBaseVNode("p", _hoisted_5, toDisplayString(_ctx.$t("subscription.haveQuestions")), 1),
          createBaseVNode("div", _hoisted_6, [
            createVNode(_sfc_main$5, {
              variant: "muted-textonly",
              class: "h-6 p-1 text-sm text-text-secondary hover:text-base-foreground",
              onClick: handleContactUs
            }, {
              default: withCtx(() => [
                createTextVNode(toDisplayString(_ctx.$t("subscription.contactUs")) + " ", 1),
                _cache[1] || (_cache[1] = createBaseVNode("i", { class: "pi pi-comments" }, null, -1))
              ]),
              _: 1
            }),
            createBaseVNode("span", _hoisted_7, toDisplayString(_ctx.$t("g.or")), 1),
            createVNode(_sfc_main$5, {
              variant: "muted-textonly",
              class: "h-6 p-1 text-sm text-text-secondary hover:text-base-foreground",
              onClick: handleViewEnterprise
            }, {
              default: withCtx(() => [
                createTextVNode(toDisplayString(_ctx.$t("subscription.viewEnterprise")) + " ", 1),
                _cache[2] || (_cache[2] = createBaseVNode("i", { class: "pi pi-external-link" }, null, -1))
              ]),
              _: 1
            })
          ])
        ])
      ])) : (openBlock(), createElementBlock("div", _hoisted_8, [
        createVNode(_sfc_main$5, {
          size: "icon",
          variant: "muted-textonly",
          class: "rounded-full absolute top-2.5 right-2.5 z-10 h-8 w-8 p-0 text-white hover:bg-white/20",
          "aria-label": _ctx.$t("g.close"),
          onClick: handleClose
        }, {
          default: withCtx(() => _cache[3] || (_cache[3] = [
            createBaseVNode("i", { class: "pi pi-times" }, null, -1)
          ])),
          _: 1
        }, 8, ["aria-label"]),
        _cache[4] || (_cache[4] = createBaseVNode("div", { class: "relative col-span-2 flex items-center justify-center overflow-hidden rounded-sm" }, [
          createBaseVNode("video", {
            autoplay: "",
            loop: "",
            muted: "",
            playsinline: "",
            class: "h-full min-w-[125%] object-cover p-0",
            style: { "margin-left": "-20%" }
          }, [
            createBaseVNode("source", {
              src: _imports_0,
              type: "video/webm"
            })
          ])
        ], -1)),
        createBaseVNode("div", _hoisted_9, [
          createBaseVNode("div", null, [
            createBaseVNode("div", _hoisted_10, [
              createBaseVNode("div", _hoisted_11, [
                createBaseVNode("div", _hoisted_12, toDisplayString(_ctx.$t("subscription.required.title")), 1),
                createVNode(_sfc_main$3, {
                  "reverse-order": "",
                  "no-padding": "",
                  "background-color": "var(--p-dialog-background)",
                  "use-subscription": ""
                })
              ]),
              createBaseVNode("div", _hoisted_13, [
                createBaseVNode("span", _hoisted_14, toDisplayString(unref(formattedMonthlyPrice)), 1),
                createBaseVNode("span", _hoisted_15, toDisplayString(_ctx.$t("subscription.perMonth")), 1)
              ])
            ]),
            createVNode(SubscriptionBenefits, { class: "mt-6 text-muted" })
          ]),
          createBaseVNode("div", _hoisted_16, [
            createVNode(_sfc_main$6, {
              class: "py-2 px-4 rounded-lg",
              pt: {
                root: {
                  style: "background: var(--color-accent-blue, #0B8CE9);"
                },
                label: {
                  class: "font-inter font-[700] text-sm"
                }
              },
              onSubscribed: handleSubscribed
            })
          ])
        ])
      ]));
    };
  }
});
const SubscriptionRequiredDialogContent = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-44074ee0"]]);
export {
  SubscriptionRequiredDialogContent as default
};
//# sourceMappingURL=SubscriptionRequiredDialogContent-DAhSGgqT.js.map
