import { q as script, g as script$1, G as script$2 } from "./vendor-primevue-Ch6rhmJJ.js";
import { _ as _sfc_main$1 } from "./UserAvatar.vue_vue_type_script_setup_true_lang-DV-9JnFV.js";
import { o as useDialogService, a0 as useCurrentUser, _ as _sfc_main$2 } from "./index-45IpBQOM.js";
import { bq as defineComponent, h as resolveDirective, j as createBlock, d as openBlock, k as withCtx, e as createBaseVNode, z as createVNode, c as createElementBlock, u as toDisplayString, br as unref, q as createCommentVNode, A as createTextVNode, l as withDirectives, s as normalizeClass } from "./vendor-other-CzYzbUcM.js";
import "./vendor-vue-DLbRHZS7.js";
import "./vendor-xterm-BF8peZ5_.js";
import "./vendor-three-DYL0ZbEr.js";
import "./vendor-tiptap-XfQ74oRB.js";
const _hoisted_1 = { class: "flex h-full flex-col" };
const _hoisted_2 = { class: "mb-2 text-2xl font-bold" };
const _hoisted_3 = {
  key: 0,
  class: "flex flex-col gap-2"
};
const _hoisted_4 = { class: "flex flex-col gap-0.5" };
const _hoisted_5 = { class: "font-medium" };
const _hoisted_6 = { class: "text-muted" };
const _hoisted_7 = { class: "flex flex-col gap-0.5" };
const _hoisted_8 = { class: "font-medium" };
const _hoisted_9 = { class: "text-muted" };
const _hoisted_10 = { class: "flex flex-col gap-0.5" };
const _hoisted_11 = { class: "font-medium" };
const _hoisted_12 = { class: "flex items-center gap-1 text-muted" };
const _hoisted_13 = {
  key: 2,
  class: "mt-4 flex flex-col gap-2"
};
const _hoisted_14 = {
  key: 1,
  class: "flex flex-col gap-4"
};
const _hoisted_15 = { class: "text-smoke-600" };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "UserPanel",
  setup(__props) {
    const dialogService = useDialogService();
    const {
      loading,
      isLoggedIn,
      isApiKeyLogin,
      isEmailProvider,
      userDisplayName,
      userEmail,
      userPhotoUrl,
      providerName,
      providerIcon,
      handleSignOut,
      handleSignIn,
      handleDeleteAccount
    } = useCurrentUser();
    return (_ctx, _cache) => {
      const _directive_tooltip = resolveDirective("tooltip");
      return openBlock(), createBlock(unref(script$2), {
        value: "User",
        class: "user-settings-container h-full"
      }, {
        default: withCtx(() => [
          createBaseVNode("div", _hoisted_1, [
            createBaseVNode("h2", _hoisted_2, toDisplayString(_ctx.$t("userSettings.title")), 1),
            createVNode(unref(script), { class: "mb-3" }),
            unref(isLoggedIn) ? (openBlock(), createElementBlock("div", _hoisted_3, [
              unref(userPhotoUrl) ? (openBlock(), createBlock(_sfc_main$1, {
                key: 0,
                "photo-url": unref(userPhotoUrl),
                shape: "circle",
                size: "large"
              }, null, 8, ["photo-url"])) : createCommentVNode("", true),
              createBaseVNode("div", _hoisted_4, [
                createBaseVNode("h3", _hoisted_5, toDisplayString(_ctx.$t("userSettings.name")), 1),
                createBaseVNode("div", _hoisted_6, toDisplayString(unref(userDisplayName) || _ctx.$t("userSettings.notSet")), 1)
              ]),
              createBaseVNode("div", _hoisted_7, [
                createBaseVNode("h3", _hoisted_8, toDisplayString(_ctx.$t("userSettings.email")), 1),
                createBaseVNode("span", _hoisted_9, toDisplayString(unref(userEmail)), 1)
              ]),
              createBaseVNode("div", _hoisted_10, [
                createBaseVNode("h3", _hoisted_11, toDisplayString(_ctx.$t("userSettings.provider")), 1),
                createBaseVNode("div", _hoisted_12, [
                  createBaseVNode("i", {
                    class: normalizeClass(unref(providerIcon))
                  }, null, 2),
                  createTextVNode(" " + toDisplayString(unref(providerName)) + " ", 1),
                  unref(isEmailProvider) ? withDirectives((openBlock(), createBlock(_sfc_main$2, {
                    key: 0,
                    variant: "muted-textonly",
                    size: "icon-sm",
                    onClick: _cache[0] || (_cache[0] = ($event) => unref(dialogService).showUpdatePasswordDialog())
                  }, {
                    default: withCtx(() => _cache[1] || (_cache[1] = [
                      createBaseVNode("i", { class: "pi pi-pen-to-square" }, null, -1)
                    ])),
                    _: 1
                  })), [
                    [_directive_tooltip, {
                      value: _ctx.$t("userSettings.updatePassword"),
                      showDelay: 300
                    }]
                  ]) : createCommentVNode("", true)
                ])
              ]),
              unref(loading) ? (openBlock(), createBlock(unref(script$1), {
                key: 1,
                class: "mt-4 h-8 w-8",
                style: { "--pc-spinner-color": "#000" }
              })) : (openBlock(), createElementBlock("div", _hoisted_13, [
                createVNode(_sfc_main$2, {
                  class: "w-32",
                  variant: "secondary",
                  onClick: unref(handleSignOut)
                }, {
                  default: withCtx(() => [
                    _cache[2] || (_cache[2] = createBaseVNode("i", { class: "pi pi-sign-out" }, null, -1)),
                    createTextVNode(" " + toDisplayString(_ctx.$t("auth.signOut.signOut")), 1)
                  ]),
                  _: 1
                }, 8, ["onClick"]),
                !unref(isApiKeyLogin) ? (openBlock(), createBlock(_sfc_main$2, {
                  key: 0,
                  class: "w-fit",
                  variant: "destructive-textonly",
                  onClick: unref(handleDeleteAccount)
                }, {
                  default: withCtx(() => [
                    createTextVNode(toDisplayString(_ctx.$t("auth.deleteAccount.deleteAccount")), 1)
                  ]),
                  _: 1
                }, 8, ["onClick"])) : createCommentVNode("", true)
              ]))
            ])) : (openBlock(), createElementBlock("div", _hoisted_14, [
              createBaseVNode("p", _hoisted_15, toDisplayString(_ctx.$t("auth.login.title")), 1),
              createVNode(_sfc_main$2, {
                class: "w-52",
                variant: "primary",
                loading: unref(loading),
                onClick: unref(handleSignIn)
              }, {
                default: withCtx(() => [
                  _cache[3] || (_cache[3] = createBaseVNode("i", { class: "pi pi-user" }, null, -1)),
                  createTextVNode(" " + toDisplayString(_ctx.$t("auth.login.signInOrSignUp")), 1)
                ]),
                _: 1
              }, 8, ["loading", "onClick"])
            ]))
          ])
        ]),
        _: 1
      });
    };
  }
});
export {
  _sfc_main as default
};
//# sourceMappingURL=UserPanel-DNtl2iPk.js.map
