var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
import { H as script, p as script$1 } from "./vendor-primevue-Ch6rhmJJ.js";
import { e as useSettingStore } from "./index-CiA0eywX.js";
import { bq as defineComponent, r as ref, E as computed, cG as useModel, j as createBlock, d as openBlock, k as withCtx, e as createBaseVNode, A as createTextVNode, u as toDisplayString, c as createElementBlock, F as Fragment, y as renderList, z as createVNode, q as createCommentVNode, s as normalizeClass, br as unref } from "./vendor-other-CzYzbUcM.js";
import "./vendor-vue-DLbRHZS7.js";
import "./vendor-xterm-BF8peZ5_.js";
import "./vendor-three-DYL0ZbEr.js";
import "./vendor-tiptap-XfQ74oRB.js";
const _hoisted_1 = { class: "w-113 max-w-md p-4 space-y-4" };
const _hoisted_2 = { class: "text-sm text-muted-foreground leading-tight" };
const _hoisted_3 = { class: "text-base-foreground font-medium" };
const _hoisted_4 = { class: "space-y-2" };
const _hoisted_5 = { class: "flex items-center gap-2 flex-1 min-w-0" };
const _hoisted_6 = { class: "flex items-center justify-center w-8 h-8 rounded-lg flex-shrink-0 bg-secondary-background border border-border-subtle" };
const _hoisted_7 = {
  key: 1,
  class: "text-xs font-normal text-base-foreground"
};
const _hoisted_8 = { class: "flex flex-col gap-0.5 min-w-0 flex-1" };
const _hoisted_9 = { class: "text-sm font-normal text-base-foreground leading-tight" };
const _hoisted_10 = { class: "text-sm font-normal text-muted-foreground leading-tight" };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "ValueControlPopover",
  props: {
    "modelValue": {},
    "modelModifiers": {}
  },
  emits: ["update:modelValue"],
  setup(__props, { expose: __expose }) {
    const popover = ref();
    const settingStore = useSettingStore();
    const toggle = /* @__PURE__ */ __name((event) => {
      popover.value.toggle(event);
    }, "toggle");
    __expose({ toggle });
    const controlOptions = [
      {
        mode: "fixed",
        icon: "icon-[lucide--pencil-off]",
        title: "fixed",
        description: "fixedDesc"
      },
      {
        mode: "increment",
        text: "+1",
        title: "increment",
        description: "incrementDesc"
      },
      {
        mode: "decrement",
        text: "-1",
        title: "decrement",
        description: "decrementDesc"
      },
      {
        mode: "randomize",
        icon: "icon-[lucide--shuffle]",
        title: "randomize",
        description: "randomizeDesc"
      }
    ];
    const widgetControlMode = computed(
      () => settingStore.get("Comfy.WidgetControlMode")
    );
    const controlMode = useModel(__props, "modelValue");
    return (_ctx, _cache) => {
      return openBlock(), createBlock(unref(script$1), {
        ref_key: "popover",
        ref: popover,
        class: "bg-interface-panel-surface border border-interface-stroke rounded-lg"
      }, {
        default: withCtx(() => [
          createBaseVNode("div", _hoisted_1, [
            createBaseVNode("div", _hoisted_2, [
              createTextVNode(toDisplayString(_ctx.$t("widgets.valueControl.header.prefix")) + " ", 1),
              createBaseVNode("span", _hoisted_3, toDisplayString(widgetControlMode.value === "before" ? _ctx.$t("widgets.valueControl.header.before") : _ctx.$t("widgets.valueControl.header.after")), 1),
              createTextVNode(" " + toDisplayString(_ctx.$t("widgets.valueControl.header.postfix")), 1)
            ]),
            createBaseVNode("div", _hoisted_4, [
              (openBlock(), createElementBlock(Fragment, null, renderList(controlOptions, (option) => {
                return createBaseVNode("div", {
                  key: option.mode,
                  class: "flex items-center justify-between py-2 gap-7"
                }, [
                  createBaseVNode("div", _hoisted_5, [
                    createBaseVNode("div", _hoisted_6, [
                      option.icon ? (openBlock(), createElementBlock("i", {
                        key: 0,
                        class: normalizeClass([option.icon, "text-base text-base-foreground"])
                      }, null, 2)) : createCommentVNode("", true),
                      option.text ? (openBlock(), createElementBlock("span", _hoisted_7, toDisplayString(option.text), 1)) : createCommentVNode("", true)
                    ]),
                    createBaseVNode("div", _hoisted_8, [
                      createBaseVNode("div", _hoisted_9, [
                        createBaseVNode("span", null, toDisplayString(_ctx.$t(`widgets.valueControl.${option.title}`)), 1)
                      ]),
                      createBaseVNode("div", _hoisted_10, toDisplayString(_ctx.$t(`widgets.valueControl.${option.description}`)), 1)
                    ])
                  ]),
                  createVNode(unref(script), {
                    modelValue: controlMode.value,
                    "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => controlMode.value = $event),
                    class: "flex-shrink-0",
                    "input-id": option.mode,
                    value: option.mode
                  }, null, 8, ["modelValue", "input-id", "value"])
                ]);
              }), 64))
            ])
          ])
        ]),
        _: 1
      }, 512);
    };
  }
});
export {
  _sfc_main as default
};
//# sourceMappingURL=ValueControlPopover-DFZdyvGX.js.map
