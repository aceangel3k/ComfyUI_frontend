import { q as app, as as isOutputNode } from "./index-c_wVuoti.js";
import { a as getAudioUrlFromPath } from "./audioUtils-B_U9v-k7.js";
import { _ as _sfc_main$1 } from "./WidgetSelect.vue_vue_type_script_setup_true_lang-CbAk7URi.js";
import AudioPreviewPlayer from "./AudioPreviewPlayer-DiMlu1G5.js";
import { bq as defineComponent, cF as mergeModels, cG as useModel, E as computed, c as createElementBlock, d as openBlock, z as createVNode } from "./vendor-other-CzYzbUcM.js";
import "./vendor-primevue-Ch6rhmJJ.js";
import "./vendor-vue-DLbRHZS7.js";
import "./vendor-xterm-BF8peZ5_.js";
import "./vendor-three-DYL0ZbEr.js";
import "./vendor-tiptap-XfQ74oRB.js";
import "./widgetPropFilter-BIbGSUAt.js";
import "./index-CaAGXb7g.js";
import "./WidgetLayoutField.vue_vue_type_script_setup_true_lang-Byos1Etx.js";
import "./LazyImage.vue_vue_type_script_setup_true_lang-CWYH5qfm.js";
import "./WidgetWithControl.vue_vue_type_script_setup_true_lang-D89FELJf.js";
const _hoisted_1 = { class: "w-full col-span-2 widget-expands grid grid-cols-[minmax(80px,max-content)_minmax(125px,auto)] gap-y-3 p-3" };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "WidgetAudioUI",
  props: /* @__PURE__ */ mergeModels({
    widget: {},
    readonly: { type: Boolean },
    nodeId: {}
  }, {
    "modelValue": {},
    "modelModifiers": {}
  }),
  emits: /* @__PURE__ */ mergeModels(["update:modelValue"], ["update:modelValue"]),
  setup(__props) {
    const props = __props;
    const modelValue = useModel(__props, "modelValue");
    const litegraphNode = computed(() => {
      if (!props.nodeId || !app.canvas.graph) return null;
      return app.canvas.graph.getNodeById(props.nodeId);
    });
    const isOutputNodeRef = computed(() => {
      const node = litegraphNode.value;
      if (!node) return false;
      return isOutputNode(node);
    });
    const audioFilePath = computed(() => props.widget.value);
    const audioUrlFromWidget = computed(() => {
      const path = audioFilePath.value;
      if (!path) return "";
      return getAudioUrlFromPath(path, "input");
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1, [
        createVNode(_sfc_main$1, {
          modelValue: modelValue.value,
          "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => modelValue.value = $event),
          widget: _ctx.widget,
          class: "col-span-2"
        }, null, 8, ["modelValue", "widget"]),
        createVNode(AudioPreviewPlayer, {
          class: "col-span-2",
          "audio-url": audioUrlFromWidget.value,
          readonly: _ctx.readonly,
          "hide-when-empty": isOutputNodeRef.value,
          "show-options-button": true
        }, null, 8, ["audio-url", "readonly", "hide-when-empty"])
      ]);
    };
  }
});
export {
  _sfc_main as default
};
//# sourceMappingURL=WidgetAudioUI-DCVU75Np.js.map
