var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
import { _ as _sfc_main$1 } from "./index-C4ZdIbOw.js";
import { f as filterWidgetProps, B as BADGE_EXCLUDED_PROPS } from "./widgetPropFilter-BIbGSUAt.js";
import { bq as defineComponent, E as computed, c as createElementBlock, d as openBlock, z as createVNode, k as withCtx, A as createTextVNode, q as createCommentVNode, u as toDisplayString, s as normalizeClass, m as mergeProps } from "./vendor-other-CzYzbUcM.js";
import "./vendor-primevue-Ch6rhmJJ.js";
import "./vendor-vue-DLbRHZS7.js";
import "./vendor-xterm-BF8peZ5_.js";
import "./vendor-three-DYL0ZbEr.js";
import "./vendor-tiptap-XfQ74oRB.js";
const _hoisted_1 = { class: "flex flex-col gap-1" };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "WidgetButton",
  props: {
    widget: {}
  },
  setup(__props) {
    const props = __props;
    const BUTTON_EXCLUDED_PROPS = [...BADGE_EXCLUDED_PROPS, "iconClass"];
    const filteredProps = computed(
      () => filterWidgetProps(props.widget.options, BUTTON_EXCLUDED_PROPS)
    );
    const handleClick = /* @__PURE__ */ __name(() => {
      if (props.widget.callback) {
        props.widget.callback();
      }
    }, "handleClick");
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1, [
        createVNode(_sfc_main$1, mergeProps({
          class: "text-base-foreground w-full border-0 bg-component-node-widget-background p-2",
          "aria-label": _ctx.widget.label,
          size: "sm",
          variant: "textonly"
        }, filteredProps.value, { onClick: handleClick }), {
          default: withCtx(() => [
            createTextVNode(toDisplayString(_ctx.widget.label ?? _ctx.widget.name) + " ", 1),
            _ctx.widget.options?.iconClass ? (openBlock(), createElementBlock("i", {
              key: 0,
              class: normalizeClass(_ctx.widget.options.iconClass)
            }, null, 2)) : createCommentVNode("", true)
          ]),
          _: 1
        }, 16, ["aria-label"])
      ]);
    };
  }
});
export {
  _sfc_main as default
};
//# sourceMappingURL=WidgetButton-DT9ANL6B.js.map
