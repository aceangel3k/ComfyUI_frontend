import { aa as script } from "./vendor-primevue-Ch6rhmJJ.js";
import { bq as defineComponent, cF as mergeModels, cG as useModel, E as computed, c as createElementBlock, d as openBlock, e as createBaseVNode, z as createVNode, br as unref } from "./vendor-other-CzYzbUcM.js";
const _hoisted_1 = { class: "flex flex-col gap-1" };
const _hoisted_2 = { class: "max-h-[48rem] rounded border p-4" };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "WidgetChart",
  props: /* @__PURE__ */ mergeModels({
    widget: {}
  }, {
    "modelValue": { required: true },
    "modelModifiers": {}
  }),
  emits: ["update:modelValue"],
  setup(__props) {
    const value = useModel(__props, "modelValue");
    const props = __props;
    const chartType = computed(() => props.widget.options?.type ?? "line");
    const chartData = computed(() => value.value || { labels: [], datasets: [] });
    const chartOptions = computed(() => ({
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          labels: {
            color: "#FFF",
            usePointStyle: true,
            pointStyle: "circle"
          }
        }
      },
      scales: {
        x: {
          ticks: {
            color: "#9FA2BD"
          },
          grid: {
            display: true,
            color: "#9FA2BD",
            drawTicks: false,
            drawOnChartArea: true,
            drawBorder: false
          },
          border: {
            display: true,
            color: "#9FA2BD"
          }
        },
        y: {
          ticks: {
            color: "#9FA2BD"
          },
          grid: {
            display: false,
            drawTicks: false,
            drawOnChartArea: false,
            drawBorder: false
          },
          border: {
            display: true,
            color: "#9FA2BD"
          }
        }
      }
    }));
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1, [
        createBaseVNode("div", _hoisted_2, [
          createVNode(unref(script), {
            type: chartType.value,
            data: chartData.value,
            options: chartOptions.value,
            "aria-label": `${_ctx.widget.name || _ctx.$t("g.chart")} - ${chartType.value} ${_ctx.$t("g.chartLowercase")}`
          }, null, 8, ["type", "data", "options", "aria-label"])
        ])
      ]);
    };
  }
});
export {
  _sfc_main as default
};
//# sourceMappingURL=WidgetChart-CXIOBBuD.js.map
