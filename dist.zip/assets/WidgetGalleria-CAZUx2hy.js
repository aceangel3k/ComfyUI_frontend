import { n as script } from "./vendor-primevue-Ch6rhmJJ.js";
import { u as useI18n } from "./vendor-vue-DLbRHZS7.js";
import { f as filterWidgetProps, G as GALLERIA_EXCLUDED_PROPS } from "./widgetPropFilter-BIbGSUAt.js";
import { bq as defineComponent, cF as mergeModels, cG as useModel, r as ref, E as computed, c as createElementBlock, d as openBlock, z as createVNode, k as withCtx, e as createBaseVNode, br as unref, m as mergeProps } from "./vendor-other-CzYzbUcM.js";
import { d as _export_sfc } from "./index-C4ZdIbOw.js";
import "./vendor-xterm-BF8peZ5_.js";
import "./vendor-three-DYL0ZbEr.js";
import "./vendor-tiptap-XfQ74oRB.js";
const _hoisted_1 = { class: "flex flex-col gap-1" };
const _hoisted_2 = ["src", "alt"];
const _hoisted_3 = { class: "h-full w-full p-1" };
const _hoisted_4 = ["src", "alt"];
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "WidgetGalleria",
  props: /* @__PURE__ */ mergeModels({
    widget: {}
  }, {
    "modelValue": { required: true },
    "modelModifiers": {}
  }),
  emits: ["update:modelValue"],
  setup(__props) {
    const value = useModel(__props, "modelValue");
    const props = __props;
    const activeIndex = ref(0);
    const { t } = useI18n();
    const filteredProps = computed(
      () => filterWidgetProps(props.widget.options, GALLERIA_EXCLUDED_PROPS)
    );
    const galleryImages = computed(() => {
      if (!value.value || !Array.isArray(value.value)) return [];
      return value.value.filter((item) => item !== null && item !== void 0).map((item, index) => {
        if (typeof item === "string") {
          return {
            itemImageSrc: item,
            thumbnailImageSrc: item,
            alt: `Image ${index}`
          };
        }
        return item ?? {};
      });
    });
    const showThumbnails = computed(() => {
      return props.widget.options?.showThumbnails !== false && galleryImages.value.length > 1;
    });
    const showNavButtons = computed(() => {
      return props.widget.options?.showItemNavigators !== false && galleryImages.value.length > 1;
    });
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1, [
        createVNode(unref(script), mergeProps({
          "active-index": activeIndex.value,
          "onUpdate:activeIndex": _cache[0] || (_cache[0] = ($event) => activeIndex.value = $event),
          value: galleryImages.value
        }, filteredProps.value, {
          "show-thumbnails": showThumbnails.value,
          "show-item-navigators": showNavButtons.value,
          class: "max-w-full",
          pt: {
            thumbnails: {
              class: "overflow-hidden"
            },
            thumbnailContent: {
              class: "py-4 px-2"
            },
            thumbnailPrevButton: {
              class: "m-0"
            },
            thumbnailNextButton: {
              class: "m-0"
            }
          }
        }), {
          item: withCtx(({ item }) => [
            createBaseVNode("img", {
              src: item?.itemImageSrc || item?.src || "",
              alt: item?.alt || `${unref(t)("g.galleryImage")} ${activeIndex.value + 1} of ${galleryImages.value.length}`,
              class: "h-auto max-h-64 w-full object-contain"
            }, null, 8, _hoisted_2)
          ]),
          thumbnail: withCtx(({ item }) => [
            createBaseVNode("div", _hoisted_3, [
              createBaseVNode("img", {
                src: item?.thumbnailImageSrc || item?.src || "",
                alt: item?.alt || `${unref(t)("g.galleryThumbnail")} ${galleryImages.value.findIndex((img) => img === item) + 1} of ${galleryImages.value.length}`,
                class: "h-full w-full rounded-lg object-cover"
              }, null, 8, _hoisted_4)
            ])
          ]),
          _: 1
        }, 16, ["active-index", "value", "show-thumbnails", "show-item-navigators"])
      ]);
    };
  }
});
const WidgetGalleria = /* @__PURE__ */ _export_sfc(_sfc_main, [["__scopeId", "data-v-34cd3eda"]]);
export {
  WidgetGalleria as default
};
//# sourceMappingURL=WidgetGalleria-CAZUx2hy.js.map
