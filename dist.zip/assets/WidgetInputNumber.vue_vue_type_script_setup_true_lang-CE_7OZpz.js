var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
import { J as script } from "./vendor-primevue-Ch6rhmJJ.js";
import { c as cn, d as _export_sfc } from "./index-DUabtg_Q.js";
import { f as filterWidgetProps, I as INPUT_EXCLUDED_PROPS, S as STANDARD_EXCLUDED_PROPS } from "./widgetPropFilter-BIbGSUAt.js";
import { W as WidgetInputBaseClass } from "./index-CY00T4i0.js";
import { _ as _sfc_main$4 } from "./WidgetLayoutField.vue_vue_type_script_setup_true_lang-D1WxT0r0.js";
import { bq as defineComponent, cF as mergeModels, cG as useModel, E as computed, h as resolveDirective, j as createBlock, d as openBlock, k as withCtx, l as withDirectives, e as createBaseVNode, br as unref, m as mergeProps, p as renderSlot, r as ref, eq as reactiveOmit, er as useForwardPropsEmits, es as SliderRoot_default, z as createVNode, c as createElementBlock, et as SliderRange_default, s as normalizeClass, eu as SliderTrack_default, y as renderList, ev as SliderThumb_default, F as Fragment, L as toValue, t as resolveDynamicComponent } from "./vendor-other-CzYzbUcM.js";
import { _ as _sfc_main$5 } from "./WidgetWithControl.vue_vue_type_script_setup_true_lang-BeNSu7-x.js";
const _hoisted_1 = { class: "absolute top-5 right-8 h-4 w-7 -translate-y-4/5 flex" };
const _sfc_main$3 = /* @__PURE__ */ defineComponent({
  __name: "WidgetInputNumberInput",
  props: /* @__PURE__ */ mergeModels({
    widget: {}
  }, {
    "modelValue": { default: 0 },
    "modelModifiers": {}
  }),
  emits: ["update:modelValue"],
  setup(__props) {
    const props = __props;
    const modelValue = useModel(__props, "modelValue");
    const filteredProps = computed(
      () => filterWidgetProps(props.widget.options, INPUT_EXCLUDED_PROPS)
    );
    const precision = computed(() => {
      const p = props.widget.options?.precision;
      return typeof p === "number" && p >= 0 ? p : void 0;
    });
    const stepValue = computed(() => {
      if (props.widget.options?.step2 !== void 0) {
        return Number(props.widget.options.step2);
      }
      if (precision.value !== void 0) {
        if (precision.value === 0) {
          return 1;
        }
        return Number((1 / Math.pow(10, precision.value)).toFixed(precision.value));
      }
      return 0;
    });
    const useGrouping = computed(() => {
      return props.widget.options?.useGrouping === true;
    });
    const buttonsDisabled = computed(() => {
      const currentValue = modelValue.value ?? 0;
      return !Number.isFinite(currentValue) || Math.abs(currentValue) > Number.MAX_SAFE_INTEGER;
    });
    const buttonTooltip = computed(() => {
      if (buttonsDisabled.value) {
        return "Increment/decrement disabled: value exceeds JavaScript precision limit (±2^53)";
      }
      return null;
    });
    return (_ctx, _cache) => {
      const _directive_tooltip = resolveDirective("tooltip");
      return openBlock(), createBlock(_sfc_main$4, { widget: _ctx.widget }, {
        default: withCtx(() => [
          withDirectives((openBlock(), createBlock(unref(script), mergeProps({
            modelValue: modelValue.value,
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => modelValue.value = $event)
          }, filteredProps.value, {
            fluid: "",
            "button-layout": "horizontal",
            size: "small",
            variant: "outlined",
            step: stepValue.value,
            "min-fraction-digits": precision.value,
            "max-fraction-digits": precision.value,
            "use-grouping": useGrouping.value,
            class: unref(cn)(unref(WidgetInputBaseClass), "grow text-xs"),
            "aria-label": _ctx.widget.name,
            "show-buttons": !buttonsDisabled.value,
            pt: {
              root: {
                class: unref(cn)(
                  "[&>input]:bg-transparent [&>input]:border-0",
                  "[&>input]:truncate [&>input]:min-w-[4ch]",
                  _ctx.$slots.default && "[&>input]:pr-7"
                )
              },
              decrementButton: {
                class: "w-8 border-0"
              },
              incrementButton: {
                class: "w-8 border-0"
              }
            }
          }), {
            incrementicon: withCtx(() => _cache[1] || (_cache[1] = [
              createBaseVNode("span", { class: "pi pi-plus text-sm" }, null, -1)
            ])),
            decrementicon: withCtx(() => _cache[2] || (_cache[2] = [
              createBaseVNode("span", { class: "pi pi-minus text-sm" }, null, -1)
            ])),
            _: 1
          }, 16, ["modelValue", "step", "min-fraction-digits", "max-fraction-digits", "use-grouping", "class", "aria-label", "show-buttons", "pt"])), [
            [_directive_tooltip, buttonTooltip.value]
          ]),
          createBaseVNode("div", _hoisted_1, [
            renderSlot(_ctx.$slots, "default", {}, void 0, true)
          ])
        ]),
        _: 3
      }, 8, ["widget"]);
    };
  }
});
const WidgetInputNumberInput = /* @__PURE__ */ _export_sfc(_sfc_main$3, [["__scopeId", "data-v-fe5dadc9"]]);
const _sfc_main$2 = /* @__PURE__ */ defineComponent({
  __name: "Slider",
  props: {
    defaultValue: {},
    modelValue: {},
    disabled: { type: Boolean },
    orientation: {},
    dir: {},
    inverted: { type: Boolean },
    min: {},
    max: {},
    step: {},
    minStepsBetweenThumbs: {},
    thumbAlignment: {},
    asChild: { type: Boolean },
    as: {},
    name: {},
    required: { type: Boolean },
    class: {}
  },
  emits: ["update:modelValue", "valueCommit"],
  setup(__props, { emit: __emit }) {
    const props = __props;
    const pressed = ref(false);
    const setPressed = /* @__PURE__ */ __name((val) => {
      pressed.value = val;
    }, "setPressed");
    const emits = __emit;
    const delegatedProps = reactiveOmit(props, "class");
    const forwarded = useForwardPropsEmits(delegatedProps, emits);
    return (_ctx, _cache) => {
      return openBlock(), createBlock(unref(SliderRoot_default), mergeProps({
        "data-slot": "slider",
        class: unref(cn)(
          "relative flex w-full touch-none items-center select-none data-[disabled]:opacity-50",
          "data-[orientation=vertical]:h-full data-[orientation=vertical]:min-h-44 data-[orientation=vertical]:w-auto data-[orientation=vertical]:flex-col",
          props.class
        )
      }, unref(forwarded), {
        onSlideStart: _cache[0] || (_cache[0] = () => setPressed(true)),
        onSlideMove: _cache[1] || (_cache[1] = () => setPressed(true)),
        onSlideEnd: _cache[2] || (_cache[2] = () => setPressed(false))
      }), {
        default: withCtx(({ modelValue }) => [
          createVNode(unref(SliderTrack_default), {
            "data-slot": "slider-track",
            class: normalizeClass(
              unref(cn)(
                "bg-node-stroke relative grow overflow-hidden rounded-full",
                "cursor-pointer overflow-visible",
                `before:absolute before:-inset-2 before:block before:bg-transparent`,
                "data-[orientation=horizontal]:h-0.5 data-[orientation=horizontal]:w-full",
                "data-[orientation=vertical]:h-full data-[orientation=vertical]:w-0.5"
              )
            )
          }, {
            default: withCtx(() => [
              createVNode(unref(SliderRange_default), {
                "data-slot": "slider-range",
                class: "absolute bg-node-component-surface-highlight data-[orientation=horizontal]:h-full data-[orientation=vertical]:w-full"
              })
            ]),
            _: 1
          }, 8, ["class"]),
          (openBlock(true), createElementBlock(Fragment, null, renderList(modelValue, (_, key) => {
            return openBlock(), createBlock(unref(SliderThumb_default), {
              key,
              "data-slot": "slider-thumb",
              class: normalizeClass(
                unref(cn)(
                  "bg-node-component-surface-highlight ring-node-component-surface-selected block size-3.5 shrink-0 rounded-full shadow-sm transition-[color,box-shadow]",
                  "cursor-grab",
                  "before:absolute before:-inset-1 before:block before:bg-transparent before:rounded-full",
                  "hover:ring-2 focus-visible:ring-2 focus-visible:outline-hidden disabled:pointer-events-none disabled:opacity-50",
                  { "cursor-grabbing": pressed.value }
                )
              )
            }, null, 8, ["class"]);
          }), 128))
        ]),
        _: 1
      }, 16, ["class"]);
    };
  }
});
function useNumberStepCalculation(options, precisionArg, returnUndefinedForDefault = false) {
  return computed(() => {
    const precision = toValue(precisionArg);
    if (options?.step2 !== void 0) {
      return Number(options.step2);
    }
    if (precision === void 0) {
      return returnUndefinedForDefault ? void 0 : 0;
    }
    if (precision === 0) return 1;
    const step = 1 / Math.pow(10, precision);
    return returnUndefinedForDefault ? step : Number(step.toFixed(precision));
  });
}
__name(useNumberStepCalculation, "useNumberStepCalculation");
const sharedButtonClasses = cn(
  "inline-flex items-center justify-center border-0 bg-transparent text-inherit transition-colors duration-150 ease-in-out ",
  "hover:bg-node-component-surface-hovered active:bg-node-component-surface-selected",
  "disabled:bg-node-component-disabled disabled:text-node-icon-disabled disabled:cursor-not-allowed"
);
function useNumberWidgetButtonPt(options) {
  const { roundedLeft = false, roundedRight = false } = options ?? {};
  const increment = cn(sharedButtonClasses, roundedRight && "rounded-r-lg");
  const decrement = cn(sharedButtonClasses, roundedLeft && "rounded-l-lg");
  return {
    incrementButton: {
      class: increment
    },
    decrementButton: {
      class: decrement
    }
  };
}
__name(useNumberWidgetButtonPt, "useNumberWidgetButtonPt");
const _sfc_main$1 = /* @__PURE__ */ defineComponent({
  __name: "WidgetInputNumberSlider",
  props: /* @__PURE__ */ mergeModels({
    widget: {}
  }, {
    "modelValue": { default: 0 },
    "modelModifiers": {}
  }),
  emits: ["update:modelValue"],
  setup(__props) {
    const modelValue = useModel(__props, "modelValue");
    const timesEmptied = ref(0);
    const updateLocalValue = /* @__PURE__ */ __name((newValue) => {
      if (newValue?.length) modelValue.value = newValue[0];
    }, "updateLocalValue");
    const handleNumberInputUpdate = /* @__PURE__ */ __name((newValue) => {
      if (newValue !== void 0) {
        updateLocalValue([newValue]);
        return;
      }
      timesEmptied.value += 1;
    }, "handleNumberInputUpdate");
    const filteredProps = computed(
      () => filterWidgetProps(__props.widget.options, STANDARD_EXCLUDED_PROPS)
    );
    const p = __props.widget.options?.precision;
    const precision = typeof p === "number" && p >= 0 ? p : void 0;
    const stepValue = useNumberStepCalculation(__props.widget.options, precision, true);
    const sliderNumberPt = useNumberWidgetButtonPt({
      roundedLeft: true,
      roundedRight: true
    });
    return (_ctx, _cache) => {
      return openBlock(), createBlock(_sfc_main$4, { widget: _ctx.widget }, {
        default: withCtx(() => [
          createBaseVNode("div", {
            class: normalizeClass(unref(cn)(unref(WidgetInputBaseClass), "flex items-center gap-2 pl-3 pr-2"))
          }, [
            createVNode(_sfc_main$2, mergeProps({
              "model-value": [modelValue.value]
            }, filteredProps.value, {
              class: "flex-grow text-xs",
              step: unref(stepValue),
              "aria-label": _ctx.widget.name,
              "onUpdate:modelValue": updateLocalValue
            }), null, 16, ["model-value", "step", "aria-label"]),
            (openBlock(), createBlock(unref(script), mergeProps({
              key: timesEmptied.value,
              "model-value": modelValue.value
            }, filteredProps.value, {
              step: unref(stepValue),
              "min-fraction-digits": unref(precision),
              "max-fraction-digits": unref(precision),
              "aria-label": _ctx.widget.name,
              size: "small",
              "pt:pc-input-text:root": "min-w-[4ch] bg-transparent border-none text-center truncate",
              class: "w-16",
              pt: unref(sliderNumberPt),
              "onUpdate:modelValue": handleNumberInputUpdate
            }), null, 16, ["model-value", "step", "min-fraction-digits", "max-fraction-digits", "aria-label", "pt"]))
          ], 2)
        ]),
        _: 1
      }, 8, ["widget"]);
    };
  }
});
const WidgetInputNumberSlider = /* @__PURE__ */ _export_sfc(_sfc_main$1, [["__scopeId", "data-v-989ee2f9"]]);
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "WidgetInputNumber",
  props: /* @__PURE__ */ mergeModels({
    widget: {}
  }, {
    "modelValue": { default: 0 },
    "modelModifiers": {}
  }),
  emits: ["update:modelValue"],
  setup(__props) {
    const props = __props;
    const modelValue = useModel(__props, "modelValue");
    const hasControlAfterGenerate = computed(() => {
      return !!props.widget.controlWidget;
    });
    return (_ctx, _cache) => {
      return hasControlAfterGenerate.value ? (openBlock(), createBlock(_sfc_main$5, {
        key: 0,
        modelValue: modelValue.value,
        "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => modelValue.value = $event),
        widget: _ctx.widget,
        component: _ctx.widget.type === "slider" ? WidgetInputNumberSlider : WidgetInputNumberInput
      }, null, 8, ["modelValue", "widget", "component"])) : (openBlock(), createBlock(resolveDynamicComponent(
        _ctx.widget.type === "slider" ? WidgetInputNumberSlider : WidgetInputNumberInput
      ), mergeProps({
        key: 1,
        modelValue: modelValue.value,
        "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => modelValue.value = $event),
        widget: _ctx.widget
      }, _ctx.$attrs), null, 16, ["modelValue", "widget"]));
    };
  }
});
export {
  _sfc_main as _
};
//# sourceMappingURL=WidgetInputNumber.vue_vue_type_script_setup_true_lang-CE_7OZpz.js.map
