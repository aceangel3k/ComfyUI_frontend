import { e as script } from "./vendor-primevue-Ch6rhmJJ.js";
import { c as cn } from "./index-Olrb7AGO.js";
import { f as filterWidgetProps, I as INPUT_EXCLUDED_PROPS } from "./widgetPropFilter-BIbGSUAt.js";
import { W as WidgetInputBaseClass } from "./index-B57RGC9W.js";
import { _ as _sfc_main$1 } from "./WidgetLayoutField.vue_vue_type_script_setup_true_lang-MW4Ts3C1.js";
import { bq as defineComponent, cF as mergeModels, cG as useModel, E as computed, j as createBlock, d as openBlock, k as withCtx, z as createVNode, br as unref, m as mergeProps } from "./vendor-other-CzYzbUcM.js";
import "./vendor-vue-DLbRHZS7.js";
import "./vendor-xterm-BF8peZ5_.js";
import "./vendor-three-DYL0ZbEr.js";
import "./vendor-tiptap-XfQ74oRB.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "WidgetInputText",
  props: /* @__PURE__ */ mergeModels({
    widget: {}
  }, {
    "modelValue": { default: "" },
    "modelModifiers": {}
  }),
  emits: ["update:modelValue"],
  setup(__props) {
    const props = __props;
    const modelValue = useModel(__props, "modelValue");
    const filteredProps = computed(
      () => filterWidgetProps(props.widget.options, INPUT_EXCLUDED_PROPS)
    );
    return (_ctx, _cache) => {
      return openBlock(), createBlock(_sfc_main$1, { widget: _ctx.widget }, {
        default: withCtx(() => [
          createVNode(unref(script), mergeProps({
            modelValue: modelValue.value,
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => modelValue.value = $event)
          }, filteredProps.value, {
            class: unref(cn)(unref(WidgetInputBaseClass), "w-full text-xs py-2 px-4"),
            "aria-label": _ctx.widget.name,
            size: "small",
            pt: { root: "truncate min-w-[4ch]" }
          }), null, 16, ["modelValue", "class", "aria-label"])
        ]),
        _: 1
      }, 8, ["widget"]);
    };
  }
});
export {
  _sfc_main as default
};
//# sourceMappingURL=WidgetInputText-ByecrAWb.js.map
