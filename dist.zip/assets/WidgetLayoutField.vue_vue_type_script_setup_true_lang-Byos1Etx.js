import { bq as defineComponent, i as inject, c as createElementBlock, d as openBlock, q as createCommentVNode, e as createBaseVNode, br as unref, F as Fragment, A as createTextVNode, u as toDisplayString, I as withModifiers, s as normalizeClass, p as renderSlot } from "./vendor-other-CzYzbUcM.js";
import { c as cn } from "./index-c_wVuoti.js";
const _hoisted_1 = { class: "grid grid-cols-subgrid min-w-0 justify-between gap-1 text-node-component-slot-text" };
const _hoisted_2 = {
  key: 0,
  class: "truncate content-center-safe"
};
const _hoisted_3 = { class: "relative min-w-0 flex-1" };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "WidgetLayoutField",
  props: {
    widget: {}
  },
  setup(__props) {
    const hideLayoutField = inject("hideLayoutField", false);
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1, [
        !unref(hideLayoutField) ? (openBlock(), createElementBlock("div", _hoisted_2, [
          _ctx.widget.name ? (openBlock(), createElementBlock(Fragment, { key: 0 }, [
            createTextVNode(toDisplayString(_ctx.widget.label || _ctx.widget.name), 1)
          ], 64)) : createCommentVNode("", true)
        ])) : createCommentVNode("", true),
        createBaseVNode("div", _hoisted_3, [
          createBaseVNode("div", {
            class: normalizeClass(
              unref(cn)(
                "cursor-default min-w-0 rounded-lg focus-within:ring focus-within:ring-component-node-widget-background-highlighted transition-all",
                _ctx.widget.borderStyle
              )
            ),
            onPointerdown: _cache[0] || (_cache[0] = withModifiers(() => {
            }, ["stop"])),
            onPointermove: _cache[1] || (_cache[1] = withModifiers(() => {
            }, ["stop"])),
            onPointerup: _cache[2] || (_cache[2] = withModifiers(() => {
            }, ["stop"]))
          }, [
            renderSlot(_ctx.$slots, "default")
          ], 34)
        ])
      ]);
    };
  }
});
export {
  _sfc_main as _
};
//# sourceMappingURL=WidgetLayoutField.vue_vue_type_script_setup_true_lang-Byos1Etx.js.map
