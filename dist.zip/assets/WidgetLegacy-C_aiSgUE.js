import { aQ as _sfc_main } from "./index-CiA0eywX.js";
import "./vendor-primevue-Ch6rhmJJ.js";
import "./vendor-other-CzYzbUcM.js";
import "./vendor-vue-DLbRHZS7.js";
import "./vendor-xterm-BF8peZ5_.js";
import "./vendor-three-DYL0ZbEr.js";
import "./vendor-tiptap-XfQ74oRB.js";
export {
  _sfc_main as default
};
//# sourceMappingURL=WidgetLegacy-C_aiSgUE.js.map
