var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
import { bq as defineComponent, cF as mergeModels, cG as useModel, r as ref, E as computed, c as createElementBlock, d as openBlock, e as createBaseVNode, l as withDirectives, s as normalizeClass, v as vShow, z as createVNode, I as withModifiers, br as unref, n as nextTick } from "./vendor-other-CzYzbUcM.js";
import { a9 as script } from "./vendor-primevue-Ch6rhmJJ.js";
import { bp as renderMarkdownToHtml } from "./index-DUabtg_Q.js";
import "./vendor-vue-DLbRHZS7.js";
import "./vendor-xterm-BF8peZ5_.js";
import "./vendor-three-DYL0ZbEr.js";
import "./vendor-tiptap-XfQ74oRB.js";
const _hoisted_1 = ["innerHTML"];
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "WidgetMarkdown",
  props: /* @__PURE__ */ mergeModels({
    widget: {}
  }, {
    "modelValue": { default: "" },
    "modelModifiers": {}
  }),
  emits: ["update:modelValue"],
  setup(__props) {
    const modelValue = useModel(__props, "modelValue");
    const isEditing = ref(false);
    const textareaRef = ref();
    const renderedHtml = computed(() => {
      return renderMarkdownToHtml(modelValue.value || "");
    });
    const startEditing = /* @__PURE__ */ __name(async () => {
      if (isEditing.value || __props.widget.options?.read_only) return;
      isEditing.value = true;
      await nextTick();
      textareaRef.value?.$el?.focus();
    }, "startEditing");
    const handleBlur = /* @__PURE__ */ __name(() => {
      isEditing.value = false;
    }, "handleBlur");
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", {
        class: "widget-markdown relative w-full",
        onDblclick: startEditing
      }, [
        createBaseVNode("div", {
          class: normalizeClass(["comfy-markdown-content size-full min-h-[60px] overflow-y-auto rounded-lg text-sm", isEditing.value === false ? "visible" : "invisible"]),
          innerHTML: renderedHtml.value
        }, null, 10, _hoisted_1),
        withDirectives(createVNode(unref(script), {
          ref_key: "textareaRef",
          ref: textareaRef,
          modelValue: modelValue.value,
          "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => modelValue.value = $event),
          "aria-label": `${_ctx.$t("g.edit")} ${_ctx.widget.name || _ctx.$t("g.markdown")} ${_ctx.$t("g.content")}`,
          class: "absolute inset-0 min-h-[60px] w-full resize-none",
          pt: {
            root: {
              class: "text-sm w-full h-full",
              onBlur: handleBlur
            }
          },
          "data-capture-wheel": "true",
          onClick: _cache[1] || (_cache[1] = withModifiers(() => {
          }, ["stop"])),
          onKeydown: _cache[2] || (_cache[2] = withModifiers(() => {
          }, ["stop"]))
        }, null, 8, ["modelValue", "aria-label", "pt"]), [
          [vShow, isEditing.value]
        ])
      ], 32);
    };
  }
});
export {
  _sfc_main as default
};
//# sourceMappingURL=WidgetMarkdown-C_cUhUo5.js.map
