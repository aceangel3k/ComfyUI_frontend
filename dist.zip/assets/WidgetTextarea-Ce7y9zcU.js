import { bq as defineComponent, cF as mergeModels, cG as useModel, E as computed, d$ as useId, j as createBlock, d as openBlock, k as withCtx, z as createVNode, e as createBaseVNode, br as unref, m as mergeProps, I as withModifiers, u as toDisplayString, s as normalizeClass } from "./vendor-other-CzYzbUcM.js";
import { a9 as script, B as script$1 } from "./vendor-primevue-Ch6rhmJJ.js";
import { c as cn } from "./index-45IpBQOM.js";
import { f as filterWidgetProps, I as INPUT_EXCLUDED_PROPS } from "./widgetPropFilter-BIbGSUAt.js";
import { W as WidgetInputBaseClass } from "./index-DVL01i4N.js";
import "./vendor-vue-DLbRHZS7.js";
import "./vendor-xterm-BF8peZ5_.js";
import "./vendor-three-DYL0ZbEr.js";
import "./vendor-tiptap-XfQ74oRB.js";
const _hoisted_1 = ["for"];
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "WidgetTextarea",
  props: /* @__PURE__ */ mergeModels({
    widget: {},
    placeholder: { default: "" }
  }, {
    "modelValue": { default: "" },
    "modelModifiers": {}
  }),
  emits: ["update:modelValue"],
  setup(__props) {
    const modelValue = useModel(__props, "modelValue");
    const filteredProps = computed(
      () => filterWidgetProps(__props.widget.options, INPUT_EXCLUDED_PROPS)
    );
    const displayName = computed(() => __props.widget.label || __props.widget.name);
    const id = useId();
    return (_ctx, _cache) => {
      return openBlock(), createBlock(unref(script$1), {
        variant: "in",
        class: normalizeClass(
          unref(cn)(
            "rounded-lg space-y-1 focus-within:ring focus-within:ring-component-node-widget-background-highlighted transition-all",
            _ctx.widget.borderStyle
          )
        )
      }, {
        default: withCtx(() => [
          createVNode(unref(script), mergeProps(filteredProps.value, {
            id: unref(id),
            modelValue: modelValue.value,
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => modelValue.value = $event),
            class: unref(cn)(unref(WidgetInputBaseClass), "size-full text-xs resize-none"),
            placeholder: _ctx.placeholder,
            readonly: _ctx.widget.options?.read_only,
            disabled: _ctx.widget.options?.read_only,
            fluid: "",
            "data-capture-wheel": "true",
            onPointerdownCapture: _cache[1] || (_cache[1] = withModifiers(() => {
            }, ["stop"])),
            onPointermoveCapture: _cache[2] || (_cache[2] = withModifiers(() => {
            }, ["stop"])),
            onPointerupCapture: _cache[3] || (_cache[3] = withModifiers(() => {
            }, ["stop"])),
            onContextmenuCapture: _cache[4] || (_cache[4] = withModifiers(() => {
            }, ["stop"]))
          }), null, 16, ["id", "modelValue", "class", "placeholder", "readonly", "disabled"]),
          createBaseVNode("label", { for: unref(id) }, toDisplayString(displayName.value), 9, _hoisted_1)
        ]),
        _: 1
      }, 8, ["class"]);
    };
  }
});
export {
  _sfc_main as default
};
//# sourceMappingURL=WidgetTextarea-Ce7y9zcU.js.map
