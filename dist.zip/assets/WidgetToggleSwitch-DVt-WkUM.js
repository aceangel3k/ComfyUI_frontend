import { L as script } from "./vendor-primevue-Ch6rhmJJ.js";
import { f as filterWidgetProps, S as STANDARD_EXCLUDED_PROPS } from "./widgetPropFilter-BIbGSUAt.js";
import { _ as _sfc_main$1 } from "./WidgetLayoutField.vue_vue_type_script_setup_true_lang-BI0qfN_B.js";
import { bq as defineComponent, cF as mergeModels, cG as useModel, E as computed, j as createBlock, d as openBlock, k as withCtx, z as createVNode, br as unref, m as mergeProps } from "./vendor-other-CzYzbUcM.js";
import "./index-45IpBQOM.js";
import "./vendor-vue-DLbRHZS7.js";
import "./vendor-xterm-BF8peZ5_.js";
import "./vendor-three-DYL0ZbEr.js";
import "./vendor-tiptap-XfQ74oRB.js";
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "WidgetToggleSwitch",
  props: /* @__PURE__ */ mergeModels({
    widget: {}
  }, {
    "modelValue": { type: Boolean },
    "modelModifiers": {}
  }),
  emits: ["update:modelValue"],
  setup(__props) {
    const modelValue = useModel(__props, "modelValue");
    const filteredProps = computed(
      () => filterWidgetProps(__props.widget.options, STANDARD_EXCLUDED_PROPS)
    );
    return (_ctx, _cache) => {
      return openBlock(), createBlock(_sfc_main$1, { widget: _ctx.widget }, {
        default: withCtx(() => [
          createVNode(unref(script), mergeProps({
            modelValue: modelValue.value,
            "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => modelValue.value = $event)
          }, filteredProps.value, {
            class: "ml-auto block",
            "aria-label": _ctx.widget.name
          }), null, 16, ["modelValue", "aria-label"])
        ]),
        _: 1
      }, 8, ["widget"]);
    };
  }
});
export {
  _sfc_main as default
};
//# sourceMappingURL=WidgetToggleSwitch-DVt-WkUM.js.map
