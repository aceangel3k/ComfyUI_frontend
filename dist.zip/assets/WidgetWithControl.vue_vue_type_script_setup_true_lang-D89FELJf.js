const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./ValueControlPopover-Dtk85Ejp.js","./vendor-primevue-Ch6rhmJJ.js","./vendor-other-CzYzbUcM.js","./vendor-other-DODGPXtn.css","./index-c_wVuoti.js","./vendor-vue-DLbRHZS7.js","./vendor-xterm-BF8peZ5_.js","./vendor-xterm-BKlWQB97.css","./vendor-three-DYL0ZbEr.js","./vendor-tiptap-XfQ74oRB.js","./index-DIm29Vzn.css"])))=>i.map(i=>d[i]);
var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
import { _ as __vitePreload } from "./vendor-primevue-Ch6rhmJJ.js";
import { bq as defineComponent, cF as mergeModels, cG as useModel, r as ref, E as computed, w as watch, c as createElementBlock, d as openBlock, j as createBlock, z as createVNode, t as resolveDynamicComponent, m as mergeProps, k as withCtx, I as withModifiers, e as createBaseVNode, s as normalizeClass, br as unref, df as defineAsyncComponent } from "./vendor-other-CzYzbUcM.js";
import { _ as _sfc_main$1 } from "./index-c_wVuoti.js";
const _hoisted_1 = { class: "relative grid grid-cols-subgrid" };
const _sfc_main = /* @__PURE__ */ defineComponent({
  __name: "WidgetWithControl",
  props: /* @__PURE__ */ mergeModels({
    widget: {},
    component: {}
  }, {
    "modelValue": {},
    "modelModifiers": {}
  }),
  emits: ["update:modelValue"],
  setup(__props) {
    const ValueControlPopover = defineAsyncComponent(
      () => __vitePreload(() => import("./ValueControlPopover-Dtk85Ejp.js"), true ? __vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10]) : void 0, import.meta.url)
    );
    const props = __props;
    const modelValue = useModel(__props, "modelValue");
    const popover = ref();
    const controlModel = ref(props.widget.controlWidget.value);
    const controlButtonIcon = computed(() => {
      switch (controlModel.value) {
        case "increment":
          return "pi pi-plus";
        case "decrement":
          return "pi pi-minus";
        case "fixed":
          return "icon-[lucide--pencil-off]";
        default:
          return "icon-[lucide--shuffle]";
      }
    });
    watch(controlModel, props.widget.controlWidget.update);
    const togglePopover = /* @__PURE__ */ __name((event) => {
      popover.value.toggle(event);
    }, "togglePopover");
    return (_ctx, _cache) => {
      return openBlock(), createElementBlock("div", _hoisted_1, [
        (openBlock(), createBlock(resolveDynamicComponent(_ctx.component), mergeProps(_ctx.$attrs, {
          modelValue: modelValue.value,
          "onUpdate:modelValue": _cache[0] || (_cache[0] = ($event) => modelValue.value = $event),
          widget: _ctx.widget
        }), {
          default: withCtx(() => [
            createVNode(_sfc_main$1, {
              variant: "textonly",
              size: "sm",
              class: "h-4 w-7 self-center rounded-xl bg-blue-100/30 p-0",
              onPointerdown: withModifiers(togglePopover, ["stop", "prevent"])
            }, {
              default: withCtx(() => [
                createBaseVNode("i", {
                  class: normalizeClass(`${controlButtonIcon.value} text-blue-100 text-xs size-3.5`)
                }, null, 2)
              ]),
              _: 1
            })
          ]),
          _: 1
        }, 16, ["modelValue", "widget"])),
        createVNode(unref(ValueControlPopover), {
          ref_key: "popover",
          ref: popover,
          modelValue: controlModel.value,
          "onUpdate:modelValue": _cache[1] || (_cache[1] = ($event) => controlModel.value = $event)
        }, null, 8, ["modelValue"])
      ]);
    };
  }
});
export {
  _sfc_main as _
};
//# sourceMappingURL=WidgetWithControl.vue_vue_type_script_setup_true_lang-D89FELJf.js.map
