var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
import { eA as register, eB as connect } from "./vendor-other-CzYzbUcM.js";
import { a as api, f as useToastStore } from "./index-45IpBQOM.js";
let isEncoderRegistered = false;
const useAudioService = /* @__PURE__ */ __name(() => {
  const handleError = /* @__PURE__ */ __name((type, message, originalError) => {
    console.error(`Audio Service Error (${type}):`, message, originalError);
  }, "handleError");
  const stopAllTracks = /* @__PURE__ */ __name((currentStream) => {
    if (currentStream) {
      currentStream.getTracks().forEach((track) => {
        track.stop();
      });
      currentStream = null;
    }
  }, "stopAllTracks");
  const registerWavEncoder = /* @__PURE__ */ __name(async () => {
    if (isEncoderRegistered) {
      return;
    }
    try {
      await register(await connect());
      isEncoderRegistered = true;
    } catch (err) {
      if (err instanceof Error && err.message.includes("already an encoder stored")) {
        isEncoderRegistered = true;
      } else {
        handleError("encoder", "Failed to register WAV encoder", err);
      }
    }
  }, "registerWavEncoder");
  const convertBlobToFileAndSubmit = /* @__PURE__ */ __name(async (blob) => {
    const name = `recording-${Date.now()}.wav`;
    const file = new File([blob], name, { type: blob.type || "audio/wav" });
    const body = new FormData();
    body.append("image", file);
    body.append("subfolder", "audio");
    body.append("type", "temp");
    const resp = await api.fetchApi("/upload/image", {
      method: "POST",
      body
    });
    if (resp.status !== 200) {
      const err = `Error uploading temp file: ${resp.status} - ${resp.statusText}`;
      useToastStore().addAlert(err);
      throw new Error(err);
    }
    const tempAudio = await resp.json();
    return `audio/${tempAudio.name} [temp]`;
  }, "convertBlobToFileAndSubmit");
  return {
    // Methods
    convertBlobToFileAndSubmit,
    registerWavEncoder,
    stopAllTracks
  };
}, "useAudioService");
export {
  useAudioService as u
};
//# sourceMappingURL=audioService-BccVaVfj.js.map
