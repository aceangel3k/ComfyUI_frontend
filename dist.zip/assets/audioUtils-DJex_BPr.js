var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
import { a as api, q as app } from "./index-CiA0eywX.js";
function formatTime(seconds) {
  if (isNaN(seconds) || seconds === 0) return "0:00";
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins}:${secs.toString().padStart(2, "0")}`;
}
__name(formatTime, "formatTime");
function getAudioUrlFromPath(path, type = "input") {
  const [subfolder, filename] = splitFilePath(path);
  return api.apiURL(getResourceURL(subfolder, filename, type));
}
__name(getAudioUrlFromPath, "getAudioUrlFromPath");
function getResourceURL(subfolder, filename, type = "input") {
  const params = [
    "filename=" + encodeURIComponent(filename),
    "type=" + type,
    "subfolder=" + subfolder,
    app.getRandParam().substring(1)
  ].join("&");
  return `/view?${params}`;
}
__name(getResourceURL, "getResourceURL");
function splitFilePath(path) {
  const folder_separator = path.lastIndexOf("/");
  if (folder_separator === -1) {
    return ["", path];
  }
  return [
    path.substring(0, folder_separator),
    path.substring(folder_separator + 1)
  ];
}
__name(splitFilePath, "splitFilePath");
export {
  getAudioUrlFromPath as a,
  formatTime as f,
  getResourceURL as g,
  splitFilePath as s
};
//# sourceMappingURL=audioUtils-DJex_BPr.js.map
