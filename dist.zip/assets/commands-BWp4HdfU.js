const commands = {};
export {
  commands as default
};
//# sourceMappingURL=commands-BWp4HdfU.js.map
