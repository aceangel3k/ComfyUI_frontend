const Comfy_3DViewer_Open3DViewer = { "label": "فتح عارض ثلاثي الأبعاد (بيتا) للعقدة المحددة" };
const Comfy_BrowseModelAssets = { "label": "تجريبي: تصفح أصول النماذج" };
const Comfy_BrowseTemplates = { "label": "تصفح القوالب" };
const Comfy_Canvas_DeleteSelectedItems = { "label": "حذف العناصر المحددة" };
const Comfy_Canvas_FitView = { "label": "تعديل العرض ليناسب العقد المحددة" };
const Comfy_Canvas_Lock = { "label": "قفل اللوحة" };
const Comfy_Canvas_MoveSelectedNodes_Down = { "label": "تحريك العقد المحددة للأسفل" };
const Comfy_Canvas_MoveSelectedNodes_Left = { "label": "تحريك العقد المحددة لليسار" };
const Comfy_Canvas_MoveSelectedNodes_Right = { "label": "تحريك العقد المحددة لليمين" };
const Comfy_Canvas_MoveSelectedNodes_Up = { "label": "تحريك العقد المحددة للأعلى" };
const Comfy_Canvas_ResetView = { "label": "إعادة تعيين العرض" };
const Comfy_Canvas_Resize = { "label": "تغيير حجم العقد المحددة" };
const Comfy_Canvas_ToggleLinkVisibility = { "label": "تبديل رؤية الروابط في اللوحة" };
const Comfy_Canvas_ToggleLock = { "label": "تبديل القفل في اللوحة" };
const Comfy_Canvas_ToggleMinimap = { "label": "تبديل الخريطة المصغرة في اللوحة" };
const Comfy_Canvas_ToggleSelectedNodes_Bypass = { "label": "تجاوز/إلغاء تجاوز العقد المحددة" };
const Comfy_Canvas_ToggleSelectedNodes_Collapse = { "label": "طي/توسيع العقد المحددة" };
const Comfy_Canvas_ToggleSelectedNodes_Mute = { "label": "كتم/إلغاء كتم العقد المحددة" };
const Comfy_Canvas_ToggleSelectedNodes_Pin = { "label": "تثبيت/إلغاء تثبيت العقد المحددة" };
const Comfy_Canvas_ToggleSelected_Pin = { "label": "تثبيت/إلغاء تثبيت العناصر المحددة" };
const Comfy_Canvas_Unlock = { "label": "فتح اللوحة" };
const Comfy_Canvas_ZoomIn = { "label": "تكبير" };
const Comfy_Canvas_ZoomOut = { "label": "تصغير" };
const Comfy_ClearPendingTasks = { "label": "مسح المهام المعلقة" };
const Comfy_ClearWorkflow = { "label": "مسح سير العمل" };
const Comfy_ContactSupport = { "label": "الاتصال بالدعم" };
const Comfy_Dev_ShowModelSelector = { "label": "إظهار منتقي النماذج (للمطورين)" };
const Comfy_DuplicateWorkflow = { "label": "تكرار سير العمل الحالي" };
const Comfy_ExportWorkflow = { "label": "تصدير سير العمل" };
const Comfy_ExportWorkflowAPI = { "label": "تصدير سير العمل (تنسيق API)" };
const Comfy_Graph_ConvertToSubgraph = { "label": "تحويل التحديد إلى رسم فرعي" };
const Comfy_Graph_EditSubgraphWidgets = { "label": "تحرير عناصر واجهة الرسم البياني الفرعي" };
const Comfy_Graph_ExitSubgraph = { "label": "الخروج من الرسم البياني الفرعي" };
const Comfy_Graph_FitGroupToContents = { "label": "ضبط المجموعة على المحتويات" };
const Comfy_Graph_GroupSelectedNodes = { "label": "تجميع العقد المحددة" };
const Comfy_Graph_ToggleWidgetPromotion = { "label": "تبديل ترقية عنصر الواجهة المحوم فوقه" };
const Comfy_Graph_UnpackSubgraph = { "label": "فك التفرع الفرعي المحدد" };
const Comfy_GroupNode_ConvertSelectedNodesToGroupNode = { "label": "تحويل العقد المحددة إلى عقدة مجموعة" };
const Comfy_GroupNode_ManageGroupNodes = { "label": "إدارة عقد المجموعات" };
const Comfy_GroupNode_UngroupSelectedGroupNodes = { "label": "إلغاء تجميع عقد المجموعات المحددة" };
const Comfy_Help_AboutComfyUI = { "label": "حول ComfyUI" };
const Comfy_Help_OpenComfyOrgDiscord = { "label": "فتح خادم Comfy-Org على Discord" };
const Comfy_Help_OpenComfyUIDocs = { "label": "فتح مستندات ComfyUI" };
const Comfy_Help_OpenComfyUIForum = { "label": "فتح منتدى ComfyUI" };
const Comfy_Help_OpenComfyUIIssues = { "label": "فتح مشكلات ComfyUI" };
const Comfy_Interrupt = { "label": "إيقاف مؤقت" };
const Comfy_LoadDefaultWorkflow = { "label": "تحميل سير العمل الافتراضي" };
const Comfy_Manager_CustomNodesManager_ShowCustomNodesMenu = { "label": "مدير العقد المخصصة" };
const Comfy_Manager_CustomNodesManager_ShowLegacyCustomNodesMenu = { "label": "العقد المخصصة (قديم)" };
const Comfy_Manager_ShowLegacyManagerMenu = { "label": "قائمة المدير (قديم)" };
const Comfy_Manager_ShowMissingPacks = { "label": "تثبيت العقد المخصصة المفقودة" };
const Comfy_Manager_ShowUpdateAvailablePacks = { "label": "التحقق من تحديثات العقد المخصصة" };
const Comfy_Manager_ToggleManagerProgressDialog = { "label": "تبديل شريط تقدم مدير العقد المخصصة" };
const Comfy_MaskEditor_BrushSize_Decrease = { "label": "تقليل حجم الفرشاة في محرر القناع" };
const Comfy_MaskEditor_BrushSize_Increase = { "label": "زيادة حجم الفرشاة في محرر القناع" };
const Comfy_MaskEditor_OpenMaskEditor = { "label": "فتح محرر القناع للعقدة المحددة" };
const Comfy_Memory_UnloadModels = { "label": "تفريغ النماذج" };
const Comfy_Memory_UnloadModelsAndExecutionCache = { "label": "تفريغ النماذج وذاكرة التنفيذ المؤقتة" };
const Comfy_NewBlankWorkflow = { "label": "سير عمل جديد فارغ" };
const Comfy_OpenClipspace = { "label": "Clipspace" };
const Comfy_OpenManagerDialog = { "label": "مدير" };
const Comfy_OpenWorkflow = { "label": "فتح سير عمل" };
const Comfy_PublishSubgraph = { "label": "نشر الرسم البياني الفرعي" };
const Comfy_QueuePrompt = { "label": "إضافة الأمر إلى قائمة الانتظار" };
const Comfy_QueuePromptFront = { "label": "إضافة الأمر إلى مقدمة قائمة الانتظار" };
const Comfy_QueueSelectedOutputNodes = { "label": "إدراج عقد الإخراج المحددة في قائمة الانتظار" };
const Comfy_Redo = { "label": "إعادة" };
const Comfy_RefreshNodeDefinitions = { "label": "تحديث تعريفات العقد" };
const Comfy_SaveWorkflow = { "label": "حفظ سير العمل" };
const Comfy_SaveWorkflowAs = { "label": "حفظ سير العمل باسم" };
const Comfy_ShowSettingsDialog = { "label": "عرض نافذة الإعدادات" };
const Comfy_ToggleAssetAPI = { "label": "تجريبي: تمكين AssetAPI" };
const Comfy_ToggleCanvasInfo = { "label": "أداء اللوحة" };
const Comfy_ToggleHelpCenter = { "label": "مركز المساعدة" };
const Comfy_ToggleTheme = { "label": "تبديل النمط (فاتح/داكن)" };
const Comfy_Undo = { "label": "تراجع" };
const Comfy_User_OpenSignInDialog = { "label": "فتح نافذة تسجيل الدخول" };
const Comfy_User_SignOut = { "label": "تسجيل الخروج" };
const Experimental_ToggleVueNodes = { "label": "تجريبي: تمكين عقد Vue" };
const Workspace_CloseWorkflow = { "label": "إغلاق سير العمل الحالي" };
const Workspace_NextOpenedWorkflow = { "label": "سير العمل التالي المفتوح" };
const Workspace_PreviousOpenedWorkflow = { "label": "سير العمل السابق المفتوح" };
const Workspace_SearchBox_Toggle = { "label": "تبديل مربع البحث" };
const Workspace_ToggleBottomPanel = { "label": "تبديل اللوحة السفلية" };
const Workspace_ToggleBottomPanel_Shortcuts = { "label": "عرض مربع حوار اختصارات لوحة المفاتيح" };
const Workspace_ToggleFocusMode = { "label": "تبديل وضع التركيز" };
const Workspace_ToggleSidebarTab_assets = { "label": "تبديل الشريط الجانبي للأصول", "tooltip": "الأصول" };
const Workspace_ToggleSidebarTab_workflows = { "label": "تبديل الشريط الجانبي لسير العمل", "tooltip": "سير العمل" };
const commands = {
  Comfy_3DViewer_Open3DViewer,
  Comfy_BrowseModelAssets,
  Comfy_BrowseTemplates,
  Comfy_Canvas_DeleteSelectedItems,
  Comfy_Canvas_FitView,
  Comfy_Canvas_Lock,
  Comfy_Canvas_MoveSelectedNodes_Down,
  Comfy_Canvas_MoveSelectedNodes_Left,
  Comfy_Canvas_MoveSelectedNodes_Right,
  Comfy_Canvas_MoveSelectedNodes_Up,
  Comfy_Canvas_ResetView,
  Comfy_Canvas_Resize,
  Comfy_Canvas_ToggleLinkVisibility,
  Comfy_Canvas_ToggleLock,
  Comfy_Canvas_ToggleMinimap,
  Comfy_Canvas_ToggleSelectedNodes_Bypass,
  Comfy_Canvas_ToggleSelectedNodes_Collapse,
  Comfy_Canvas_ToggleSelectedNodes_Mute,
  Comfy_Canvas_ToggleSelectedNodes_Pin,
  Comfy_Canvas_ToggleSelected_Pin,
  Comfy_Canvas_Unlock,
  Comfy_Canvas_ZoomIn,
  Comfy_Canvas_ZoomOut,
  Comfy_ClearPendingTasks,
  Comfy_ClearWorkflow,
  Comfy_ContactSupport,
  Comfy_Dev_ShowModelSelector,
  Comfy_DuplicateWorkflow,
  Comfy_ExportWorkflow,
  Comfy_ExportWorkflowAPI,
  Comfy_Graph_ConvertToSubgraph,
  Comfy_Graph_EditSubgraphWidgets,
  Comfy_Graph_ExitSubgraph,
  Comfy_Graph_FitGroupToContents,
  Comfy_Graph_GroupSelectedNodes,
  Comfy_Graph_ToggleWidgetPromotion,
  Comfy_Graph_UnpackSubgraph,
  Comfy_GroupNode_ConvertSelectedNodesToGroupNode,
  Comfy_GroupNode_ManageGroupNodes,
  Comfy_GroupNode_UngroupSelectedGroupNodes,
  Comfy_Help_AboutComfyUI,
  Comfy_Help_OpenComfyOrgDiscord,
  Comfy_Help_OpenComfyUIDocs,
  Comfy_Help_OpenComfyUIForum,
  Comfy_Help_OpenComfyUIIssues,
  Comfy_Interrupt,
  Comfy_LoadDefaultWorkflow,
  Comfy_Manager_CustomNodesManager_ShowCustomNodesMenu,
  Comfy_Manager_CustomNodesManager_ShowLegacyCustomNodesMenu,
  Comfy_Manager_ShowLegacyManagerMenu,
  Comfy_Manager_ShowMissingPacks,
  Comfy_Manager_ShowUpdateAvailablePacks,
  Comfy_Manager_ToggleManagerProgressDialog,
  Comfy_MaskEditor_BrushSize_Decrease,
  Comfy_MaskEditor_BrushSize_Increase,
  Comfy_MaskEditor_OpenMaskEditor,
  Comfy_Memory_UnloadModels,
  Comfy_Memory_UnloadModelsAndExecutionCache,
  Comfy_NewBlankWorkflow,
  Comfy_OpenClipspace,
  Comfy_OpenManagerDialog,
  Comfy_OpenWorkflow,
  Comfy_PublishSubgraph,
  Comfy_QueuePrompt,
  Comfy_QueuePromptFront,
  Comfy_QueueSelectedOutputNodes,
  Comfy_Redo,
  Comfy_RefreshNodeDefinitions,
  Comfy_SaveWorkflow,
  Comfy_SaveWorkflowAs,
  Comfy_ShowSettingsDialog,
  Comfy_ToggleAssetAPI,
  Comfy_ToggleCanvasInfo,
  Comfy_ToggleHelpCenter,
  Comfy_ToggleTheme,
  Comfy_Undo,
  Comfy_User_OpenSignInDialog,
  Comfy_User_SignOut,
  Experimental_ToggleVueNodes,
  Workspace_CloseWorkflow,
  Workspace_NextOpenedWorkflow,
  Workspace_PreviousOpenedWorkflow,
  Workspace_SearchBox_Toggle,
  Workspace_ToggleBottomPanel,
  "Workspace_ToggleBottomPanelTab_command-terminal": { "label": "تبديل لوحة الطرفية السفلية" },
  "Workspace_ToggleBottomPanelTab_logs-terminal": { "label": "تبديل لوحة السجلات السفلية" },
  "Workspace_ToggleBottomPanelTab_shortcuts-essentials": { "label": "تبديل اللوحة السفلية الأساسية" },
  "Workspace_ToggleBottomPanelTab_shortcuts-view-controls": { "label": "تبديل لوحة تحكم العرض السفلية" },
  Workspace_ToggleBottomPanel_Shortcuts,
  Workspace_ToggleFocusMode,
  Workspace_ToggleSidebarTab_assets,
  "Workspace_ToggleSidebarTab_model-library": { "label": "تبديل الشريط الجانبي لمكتبة النماذج", "tooltip": "مكتبة النماذج" },
  "Workspace_ToggleSidebarTab_node-library": { "label": "تبديل الشريط الجانبي لمكتبة العقد", "tooltip": "مكتبة العقد" },
  Workspace_ToggleSidebarTab_workflows
};
export {
  Comfy_3DViewer_Open3DViewer,
  Comfy_BrowseModelAssets,
  Comfy_BrowseTemplates,
  Comfy_Canvas_DeleteSelectedItems,
  Comfy_Canvas_FitView,
  Comfy_Canvas_Lock,
  Comfy_Canvas_MoveSelectedNodes_Down,
  Comfy_Canvas_MoveSelectedNodes_Left,
  Comfy_Canvas_MoveSelectedNodes_Right,
  Comfy_Canvas_MoveSelectedNodes_Up,
  Comfy_Canvas_ResetView,
  Comfy_Canvas_Resize,
  Comfy_Canvas_ToggleLinkVisibility,
  Comfy_Canvas_ToggleLock,
  Comfy_Canvas_ToggleMinimap,
  Comfy_Canvas_ToggleSelectedNodes_Bypass,
  Comfy_Canvas_ToggleSelectedNodes_Collapse,
  Comfy_Canvas_ToggleSelectedNodes_Mute,
  Comfy_Canvas_ToggleSelectedNodes_Pin,
  Comfy_Canvas_ToggleSelected_Pin,
  Comfy_Canvas_Unlock,
  Comfy_Canvas_ZoomIn,
  Comfy_Canvas_ZoomOut,
  Comfy_ClearPendingTasks,
  Comfy_ClearWorkflow,
  Comfy_ContactSupport,
  Comfy_Dev_ShowModelSelector,
  Comfy_DuplicateWorkflow,
  Comfy_ExportWorkflow,
  Comfy_ExportWorkflowAPI,
  Comfy_Graph_ConvertToSubgraph,
  Comfy_Graph_EditSubgraphWidgets,
  Comfy_Graph_ExitSubgraph,
  Comfy_Graph_FitGroupToContents,
  Comfy_Graph_GroupSelectedNodes,
  Comfy_Graph_ToggleWidgetPromotion,
  Comfy_Graph_UnpackSubgraph,
  Comfy_GroupNode_ConvertSelectedNodesToGroupNode,
  Comfy_GroupNode_ManageGroupNodes,
  Comfy_GroupNode_UngroupSelectedGroupNodes,
  Comfy_Help_AboutComfyUI,
  Comfy_Help_OpenComfyOrgDiscord,
  Comfy_Help_OpenComfyUIDocs,
  Comfy_Help_OpenComfyUIForum,
  Comfy_Help_OpenComfyUIIssues,
  Comfy_Interrupt,
  Comfy_LoadDefaultWorkflow,
  Comfy_Manager_CustomNodesManager_ShowCustomNodesMenu,
  Comfy_Manager_CustomNodesManager_ShowLegacyCustomNodesMenu,
  Comfy_Manager_ShowLegacyManagerMenu,
  Comfy_Manager_ShowMissingPacks,
  Comfy_Manager_ShowUpdateAvailablePacks,
  Comfy_Manager_ToggleManagerProgressDialog,
  Comfy_MaskEditor_BrushSize_Decrease,
  Comfy_MaskEditor_BrushSize_Increase,
  Comfy_MaskEditor_OpenMaskEditor,
  Comfy_Memory_UnloadModels,
  Comfy_Memory_UnloadModelsAndExecutionCache,
  Comfy_NewBlankWorkflow,
  Comfy_OpenClipspace,
  Comfy_OpenManagerDialog,
  Comfy_OpenWorkflow,
  Comfy_PublishSubgraph,
  Comfy_QueuePrompt,
  Comfy_QueuePromptFront,
  Comfy_QueueSelectedOutputNodes,
  Comfy_Redo,
  Comfy_RefreshNodeDefinitions,
  Comfy_SaveWorkflow,
  Comfy_SaveWorkflowAs,
  Comfy_ShowSettingsDialog,
  Comfy_ToggleAssetAPI,
  Comfy_ToggleCanvasInfo,
  Comfy_ToggleHelpCenter,
  Comfy_ToggleTheme,
  Comfy_Undo,
  Comfy_User_OpenSignInDialog,
  Comfy_User_SignOut,
  Experimental_ToggleVueNodes,
  Workspace_CloseWorkflow,
  Workspace_NextOpenedWorkflow,
  Workspace_PreviousOpenedWorkflow,
  Workspace_SearchBox_Toggle,
  Workspace_ToggleBottomPanel,
  Workspace_ToggleBottomPanel_Shortcuts,
  Workspace_ToggleFocusMode,
  Workspace_ToggleSidebarTab_assets,
  Workspace_ToggleSidebarTab_workflows,
  commands as default
};
//# sourceMappingURL=commands-COSt-Bjx.js.map
