const Comfy_3DViewer_Open3DViewer = { "label": "選択したノードの3Dビューアー（ベータ）を開く" };
const Comfy_BrowseModelAssets = { "label": "実験的: モデルアセットを参照" };
const Comfy_BrowseTemplates = { "label": "テンプレートを参照" };
const Comfy_Canvas_DeleteSelectedItems = { "label": "選択したアイテムを削除" };
const Comfy_Canvas_FitView = { "label": "選択したノードにビューを合わせる" };
const Comfy_Canvas_Lock = { "label": "キャンバスをロック" };
const Comfy_Canvas_MoveSelectedNodes_Down = { "label": "選択したノードを下に移動" };
const Comfy_Canvas_MoveSelectedNodes_Left = { "label": "選択したノードを左に移動" };
const Comfy_Canvas_MoveSelectedNodes_Right = { "label": "選択したノードを右に移動" };
const Comfy_Canvas_MoveSelectedNodes_Up = { "label": "選択したノードを上に移動" };
const Comfy_Canvas_ResetView = { "label": "ビューをリセット" };
const Comfy_Canvas_Resize = { "label": "選択したノードのサイズ変更" };
const Comfy_Canvas_ToggleLinkVisibility = { "label": "キャンバスのリンク表示を切り替える" };
const Comfy_Canvas_ToggleLock = { "label": "キャンバスのロックを切り替える" };
const Comfy_Canvas_ToggleMinimap = { "label": "キャンバス ミニマップ切り替え" };
const Comfy_Canvas_ToggleSelectedNodes_Bypass = { "label": "選択したノードのバイパス/バイパス解除" };
const Comfy_Canvas_ToggleSelectedNodes_Collapse = { "label": "選択したノードの折りたたみ/展開" };
const Comfy_Canvas_ToggleSelectedNodes_Mute = { "label": "選択したノードのミュート/ミュート解除" };
const Comfy_Canvas_ToggleSelectedNodes_Pin = { "label": "選択したノードのピン留め/ピン留め解除" };
const Comfy_Canvas_ToggleSelected_Pin = { "label": "選択したアイテムのピン留め/ピン留め解除" };
const Comfy_Canvas_Unlock = { "label": "キャンバスをロック解除" };
const Comfy_Canvas_ZoomIn = { "label": "ズームイン" };
const Comfy_Canvas_ZoomOut = { "label": "ズームアウト" };
const Comfy_ClearPendingTasks = { "label": "保留中のタスクをクリア" };
const Comfy_ClearWorkflow = { "label": "ワークフローをクリア" };
const Comfy_ContactSupport = { "label": "サポートに連絡" };
const Comfy_Dev_ShowModelSelector = { "label": "モデルセレクターを表示（開発用）" };
const Comfy_DuplicateWorkflow = { "label": "現在のワークフローを複製" };
const Comfy_ExportWorkflow = { "label": "ワークフローをエクスポート" };
const Comfy_ExportWorkflowAPI = { "label": "ワークフローをエクスポート（API形式）" };
const Comfy_Graph_ConvertToSubgraph = { "label": "選択範囲をサブグラフに変換" };
const Comfy_Graph_EditSubgraphWidgets = { "label": "サブグラフウィジェットを編集" };
const Comfy_Graph_ExitSubgraph = { "label": "サブグラフを終了" };
const Comfy_Graph_FitGroupToContents = { "label": "グループを内容に合わせて調整" };
const Comfy_Graph_GroupSelectedNodes = { "label": "選択したノードをグループ化" };
const Comfy_Graph_ToggleWidgetPromotion = { "label": "ホバー中のウィジェットの優先表示を切り替え" };
const Comfy_Graph_UnpackSubgraph = { "label": "選択したサブグラフを展開" };
const Comfy_GroupNode_ConvertSelectedNodesToGroupNode = { "label": "選択したノードをグループノードに変換" };
const Comfy_GroupNode_ManageGroupNodes = { "label": "グループノードの管理" };
const Comfy_GroupNode_UngroupSelectedGroupNodes = { "label": "選択したグループノードのグループ解除" };
const Comfy_Help_AboutComfyUI = { "label": "ComfyUIについてを開く" };
const Comfy_Help_OpenComfyOrgDiscord = { "label": "Comfy-OrgのDiscordを開く" };
const Comfy_Help_OpenComfyUIDocs = { "label": "ComfyUIのドキュメントを開く" };
const Comfy_Help_OpenComfyUIForum = { "label": "Comfy-Orgフォーラムを開く" };
const Comfy_Help_OpenComfyUIIssues = { "label": "ComfyUIの問題を開く" };
const Comfy_Interrupt = { "label": "中断" };
const Comfy_LoadDefaultWorkflow = { "label": "デフォルトのワークフローを読み込む" };
const Comfy_Manager_CustomNodesManager_ShowCustomNodesMenu = { "label": "カスタムノード（ベータ版）" };
const Comfy_Manager_CustomNodesManager_ShowLegacyCustomNodesMenu = { "label": "カスタムノード（レガシー）" };
const Comfy_Manager_ShowLegacyManagerMenu = { "label": "マネージャーメニュー（レガシー）" };
const Comfy_Manager_ShowMissingPacks = { "label": "不足しているパックをインストール" };
const Comfy_Manager_ShowUpdateAvailablePacks = { "label": "更新を確認" };
const Comfy_Manager_ToggleManagerProgressDialog = { "label": "プログレスダイアログの切り替え" };
const Comfy_MaskEditor_BrushSize_Decrease = { "label": "マスクエディタでブラシサイズを縮小" };
const Comfy_MaskEditor_BrushSize_Increase = { "label": "マスクエディタでブラシサイズを大きくする" };
const Comfy_MaskEditor_OpenMaskEditor = { "label": "選択したノードのマスクエディタを開く" };
const Comfy_Memory_UnloadModels = { "label": "モデルのアンロード" };
const Comfy_Memory_UnloadModelsAndExecutionCache = { "label": "モデルと実行キャッシュのアンロード" };
const Comfy_NewBlankWorkflow = { "label": "新しい空のワークフロー" };
const Comfy_OpenClipspace = { "label": "クリップスペース" };
const Comfy_OpenManagerDialog = { "label": "マネージャー" };
const Comfy_OpenWorkflow = { "label": "ワークフローを開く" };
const Comfy_PublishSubgraph = { "label": "サブグラフを公開" };
const Comfy_QueuePrompt = { "label": "キュープロンプト" };
const Comfy_QueuePromptFront = { "label": "キュープロンプト（フロント）" };
const Comfy_QueueSelectedOutputNodes = { "label": "選択した出力ノードをキューに追加" };
const Comfy_Redo = { "label": "やり直す" };
const Comfy_RefreshNodeDefinitions = { "label": "ノード定義を更新" };
const Comfy_SaveWorkflow = { "label": "ワークフローを保存する" };
const Comfy_SaveWorkflowAs = { "label": "名前を付けてワークフローを保存" };
const Comfy_ShowSettingsDialog = { "label": "設定ダイアログを表示" };
const Comfy_ToggleAssetAPI = { "label": "実験的: AssetAPIを有効化" };
const Comfy_ToggleCanvasInfo = { "label": "キャンバスパフォーマンス" };
const Comfy_ToggleHelpCenter = { "label": "ヘルプセンター" };
const Comfy_ToggleTheme = { "label": "テーマの切り替え（ダーク/ライト）" };
const Comfy_Undo = { "label": "元に戻す" };
const Comfy_User_OpenSignInDialog = { "label": "サインインダイアログを開く" };
const Comfy_User_SignOut = { "label": "サインアウト" };
const Experimental_ToggleVueNodes = { "label": "実験的: Vueノードを有効化" };
const Workspace_CloseWorkflow = { "label": "現在のワークフローを閉じる" };
const Workspace_NextOpenedWorkflow = { "label": "次の開いたワークフロー" };
const Workspace_PreviousOpenedWorkflow = { "label": "前の開いたワークフロー" };
const Workspace_SearchBox_Toggle = { "label": "検索ボックスの切り替え" };
const Workspace_ToggleBottomPanel = { "label": "パネル下部の切り替え" };
const Workspace_ToggleBottomPanel_Shortcuts = { "label": "キーバインドダイアログを表示" };
const Workspace_ToggleFocusMode = { "label": "フォーカスモードの切り替え" };
const Workspace_ToggleSidebarTab_assets = { "label": "アセットサイドバーの表示切り替え", "tooltip": "アセット" };
const Workspace_ToggleSidebarTab_workflows = { "label": "ワークフローサイドバーの切り替え", "tooltip": "ワークフロー" };
const commands = {
  Comfy_3DViewer_Open3DViewer,
  Comfy_BrowseModelAssets,
  Comfy_BrowseTemplates,
  Comfy_Canvas_DeleteSelectedItems,
  Comfy_Canvas_FitView,
  Comfy_Canvas_Lock,
  Comfy_Canvas_MoveSelectedNodes_Down,
  Comfy_Canvas_MoveSelectedNodes_Left,
  Comfy_Canvas_MoveSelectedNodes_Right,
  Comfy_Canvas_MoveSelectedNodes_Up,
  Comfy_Canvas_ResetView,
  Comfy_Canvas_Resize,
  Comfy_Canvas_ToggleLinkVisibility,
  Comfy_Canvas_ToggleLock,
  Comfy_Canvas_ToggleMinimap,
  Comfy_Canvas_ToggleSelectedNodes_Bypass,
  Comfy_Canvas_ToggleSelectedNodes_Collapse,
  Comfy_Canvas_ToggleSelectedNodes_Mute,
  Comfy_Canvas_ToggleSelectedNodes_Pin,
  Comfy_Canvas_ToggleSelected_Pin,
  Comfy_Canvas_Unlock,
  Comfy_Canvas_ZoomIn,
  Comfy_Canvas_ZoomOut,
  Comfy_ClearPendingTasks,
  Comfy_ClearWorkflow,
  Comfy_ContactSupport,
  Comfy_Dev_ShowModelSelector,
  Comfy_DuplicateWorkflow,
  Comfy_ExportWorkflow,
  Comfy_ExportWorkflowAPI,
  Comfy_Graph_ConvertToSubgraph,
  Comfy_Graph_EditSubgraphWidgets,
  Comfy_Graph_ExitSubgraph,
  Comfy_Graph_FitGroupToContents,
  Comfy_Graph_GroupSelectedNodes,
  Comfy_Graph_ToggleWidgetPromotion,
  Comfy_Graph_UnpackSubgraph,
  Comfy_GroupNode_ConvertSelectedNodesToGroupNode,
  Comfy_GroupNode_ManageGroupNodes,
  Comfy_GroupNode_UngroupSelectedGroupNodes,
  Comfy_Help_AboutComfyUI,
  Comfy_Help_OpenComfyOrgDiscord,
  Comfy_Help_OpenComfyUIDocs,
  Comfy_Help_OpenComfyUIForum,
  Comfy_Help_OpenComfyUIIssues,
  Comfy_Interrupt,
  Comfy_LoadDefaultWorkflow,
  Comfy_Manager_CustomNodesManager_ShowCustomNodesMenu,
  Comfy_Manager_CustomNodesManager_ShowLegacyCustomNodesMenu,
  Comfy_Manager_ShowLegacyManagerMenu,
  Comfy_Manager_ShowMissingPacks,
  Comfy_Manager_ShowUpdateAvailablePacks,
  Comfy_Manager_ToggleManagerProgressDialog,
  Comfy_MaskEditor_BrushSize_Decrease,
  Comfy_MaskEditor_BrushSize_Increase,
  Comfy_MaskEditor_OpenMaskEditor,
  Comfy_Memory_UnloadModels,
  Comfy_Memory_UnloadModelsAndExecutionCache,
  Comfy_NewBlankWorkflow,
  Comfy_OpenClipspace,
  Comfy_OpenManagerDialog,
  Comfy_OpenWorkflow,
  Comfy_PublishSubgraph,
  Comfy_QueuePrompt,
  Comfy_QueuePromptFront,
  Comfy_QueueSelectedOutputNodes,
  Comfy_Redo,
  Comfy_RefreshNodeDefinitions,
  Comfy_SaveWorkflow,
  Comfy_SaveWorkflowAs,
  Comfy_ShowSettingsDialog,
  Comfy_ToggleAssetAPI,
  Comfy_ToggleCanvasInfo,
  Comfy_ToggleHelpCenter,
  Comfy_ToggleTheme,
  Comfy_Undo,
  Comfy_User_OpenSignInDialog,
  Comfy_User_SignOut,
  Experimental_ToggleVueNodes,
  Workspace_CloseWorkflow,
  Workspace_NextOpenedWorkflow,
  Workspace_PreviousOpenedWorkflow,
  Workspace_SearchBox_Toggle,
  Workspace_ToggleBottomPanel,
  "Workspace_ToggleBottomPanelTab_command-terminal": { "label": "ターミナルパネル下部の切り替え" },
  "Workspace_ToggleBottomPanelTab_logs-terminal": { "label": "ログパネル下部の切り替え" },
  "Workspace_ToggleBottomPanelTab_shortcuts-essentials": { "label": "必須な下部パネルを切り替え" },
  "Workspace_ToggleBottomPanelTab_shortcuts-view-controls": { "label": "表示コントロール下部パネルの切り替え" },
  Workspace_ToggleBottomPanel_Shortcuts,
  Workspace_ToggleFocusMode,
  Workspace_ToggleSidebarTab_assets,
  "Workspace_ToggleSidebarTab_model-library": { "label": "モデルライブラリサイドバーの切り替え", "tooltip": "モデルライブラリ" },
  "Workspace_ToggleSidebarTab_node-library": { "label": "ノードライブラリサイドバーの切り替え", "tooltip": "ノードライブラリ" },
  Workspace_ToggleSidebarTab_workflows
};
export {
  Comfy_3DViewer_Open3DViewer,
  Comfy_BrowseModelAssets,
  Comfy_BrowseTemplates,
  Comfy_Canvas_DeleteSelectedItems,
  Comfy_Canvas_FitView,
  Comfy_Canvas_Lock,
  Comfy_Canvas_MoveSelectedNodes_Down,
  Comfy_Canvas_MoveSelectedNodes_Left,
  Comfy_Canvas_MoveSelectedNodes_Right,
  Comfy_Canvas_MoveSelectedNodes_Up,
  Comfy_Canvas_ResetView,
  Comfy_Canvas_Resize,
  Comfy_Canvas_ToggleLinkVisibility,
  Comfy_Canvas_ToggleLock,
  Comfy_Canvas_ToggleMinimap,
  Comfy_Canvas_ToggleSelectedNodes_Bypass,
  Comfy_Canvas_ToggleSelectedNodes_Collapse,
  Comfy_Canvas_ToggleSelectedNodes_Mute,
  Comfy_Canvas_ToggleSelectedNodes_Pin,
  Comfy_Canvas_ToggleSelected_Pin,
  Comfy_Canvas_Unlock,
  Comfy_Canvas_ZoomIn,
  Comfy_Canvas_ZoomOut,
  Comfy_ClearPendingTasks,
  Comfy_ClearWorkflow,
  Comfy_ContactSupport,
  Comfy_Dev_ShowModelSelector,
  Comfy_DuplicateWorkflow,
  Comfy_ExportWorkflow,
  Comfy_ExportWorkflowAPI,
  Comfy_Graph_ConvertToSubgraph,
  Comfy_Graph_EditSubgraphWidgets,
  Comfy_Graph_ExitSubgraph,
  Comfy_Graph_FitGroupToContents,
  Comfy_Graph_GroupSelectedNodes,
  Comfy_Graph_ToggleWidgetPromotion,
  Comfy_Graph_UnpackSubgraph,
  Comfy_GroupNode_ConvertSelectedNodesToGroupNode,
  Comfy_GroupNode_ManageGroupNodes,
  Comfy_GroupNode_UngroupSelectedGroupNodes,
  Comfy_Help_AboutComfyUI,
  Comfy_Help_OpenComfyOrgDiscord,
  Comfy_Help_OpenComfyUIDocs,
  Comfy_Help_OpenComfyUIForum,
  Comfy_Help_OpenComfyUIIssues,
  Comfy_Interrupt,
  Comfy_LoadDefaultWorkflow,
  Comfy_Manager_CustomNodesManager_ShowCustomNodesMenu,
  Comfy_Manager_CustomNodesManager_ShowLegacyCustomNodesMenu,
  Comfy_Manager_ShowLegacyManagerMenu,
  Comfy_Manager_ShowMissingPacks,
  Comfy_Manager_ShowUpdateAvailablePacks,
  Comfy_Manager_ToggleManagerProgressDialog,
  Comfy_MaskEditor_BrushSize_Decrease,
  Comfy_MaskEditor_BrushSize_Increase,
  Comfy_MaskEditor_OpenMaskEditor,
  Comfy_Memory_UnloadModels,
  Comfy_Memory_UnloadModelsAndExecutionCache,
  Comfy_NewBlankWorkflow,
  Comfy_OpenClipspace,
  Comfy_OpenManagerDialog,
  Comfy_OpenWorkflow,
  Comfy_PublishSubgraph,
  Comfy_QueuePrompt,
  Comfy_QueuePromptFront,
  Comfy_QueueSelectedOutputNodes,
  Comfy_Redo,
  Comfy_RefreshNodeDefinitions,
  Comfy_SaveWorkflow,
  Comfy_SaveWorkflowAs,
  Comfy_ShowSettingsDialog,
  Comfy_ToggleAssetAPI,
  Comfy_ToggleCanvasInfo,
  Comfy_ToggleHelpCenter,
  Comfy_ToggleTheme,
  Comfy_Undo,
  Comfy_User_OpenSignInDialog,
  Comfy_User_SignOut,
  Experimental_ToggleVueNodes,
  Workspace_CloseWorkflow,
  Workspace_NextOpenedWorkflow,
  Workspace_PreviousOpenedWorkflow,
  Workspace_SearchBox_Toggle,
  Workspace_ToggleBottomPanel,
  Workspace_ToggleBottomPanel_Shortcuts,
  Workspace_ToggleFocusMode,
  Workspace_ToggleSidebarTab_assets,
  Workspace_ToggleSidebarTab_workflows,
  commands as default
};
//# sourceMappingURL=commands-CcfGaui5.js.map
