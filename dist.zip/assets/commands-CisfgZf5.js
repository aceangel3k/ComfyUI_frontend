const Comfy_3DViewer_Open3DViewer = { "label": "Abrir visor 3D (Beta) para el nodo seleccionado" };
const Comfy_BrowseModelAssets = { "label": "Experimental: Explorar recursos de modelos" };
const Comfy_BrowseTemplates = { "label": "Explorar plantillas" };
const Comfy_Canvas_DeleteSelectedItems = { "label": "Eliminar elementos seleccionados" };
const Comfy_Canvas_FitView = { "label": "Ajustar vista a los nodos seleccionados" };
const Comfy_Canvas_Lock = { "label": "Bloquear lienzo" };
const Comfy_Canvas_MoveSelectedNodes_Down = { "label": "Mover nodos seleccionados hacia abajo" };
const Comfy_Canvas_MoveSelectedNodes_Left = { "label": "Mover nodos seleccionados a la izquierda" };
const Comfy_Canvas_MoveSelectedNodes_Right = { "label": "Mover nodos seleccionados a la derecha" };
const Comfy_Canvas_MoveSelectedNodes_Up = { "label": "Mover nodos seleccionados hacia arriba" };
const Comfy_Canvas_ResetView = { "label": "Restablecer vista" };
const Comfy_Canvas_Resize = { "label": "Redimensionar Nodos Seleccionados" };
const Comfy_Canvas_ToggleLinkVisibility = { "label": "Alternar visibilidad de enlace en lienzo" };
const Comfy_Canvas_ToggleLock = { "label": "Alternar bloqueo en lienzo" };
const Comfy_Canvas_ToggleMinimap = { "label": "Lienzo Alternar Minimapa" };
const Comfy_Canvas_ToggleSelectedNodes_Bypass = { "label": "Omitir/No omitir nodos seleccionados" };
const Comfy_Canvas_ToggleSelectedNodes_Collapse = { "label": "Colapsar/Expandir nodos seleccionados" };
const Comfy_Canvas_ToggleSelectedNodes_Mute = { "label": "Silenciar/Activar sonido de nodos seleccionados" };
const Comfy_Canvas_ToggleSelectedNodes_Pin = { "label": "Anclar/Desanclar nodos seleccionados" };
const Comfy_Canvas_ToggleSelected_Pin = { "label": "Anclar/Desanclar elementos seleccionados" };
const Comfy_Canvas_Unlock = { "label": "Desbloquear lienzo" };
const Comfy_Canvas_ZoomIn = { "label": "Acercar" };
const Comfy_Canvas_ZoomOut = { "label": "Alejar" };
const Comfy_ClearPendingTasks = { "label": "Borrar tareas pendientes" };
const Comfy_ClearWorkflow = { "label": "Borrar flujo de trabajo" };
const Comfy_ContactSupport = { "label": "Contactar soporte" };
const Comfy_Dev_ShowModelSelector = { "label": "Mostrar selector de modelo (Dev)" };
const Comfy_DuplicateWorkflow = { "label": "Duplicar flujo de trabajo actual" };
const Comfy_ExportWorkflow = { "label": "Exportar flujo de trabajo" };
const Comfy_ExportWorkflowAPI = { "label": "Exportar flujo de trabajo (formato API)" };
const Comfy_Graph_ConvertToSubgraph = { "label": "Convertir selección en subgrafo" };
const Comfy_Graph_EditSubgraphWidgets = { "label": "Editar widgets de subgráficos" };
const Comfy_Graph_ExitSubgraph = { "label": "Salir de subgrafo" };
const Comfy_Graph_FitGroupToContents = { "label": "Ajustar grupo al contenido" };
const Comfy_Graph_GroupSelectedNodes = { "label": "Agrupar nodos seleccionados" };
const Comfy_Graph_ToggleWidgetPromotion = { "label": "Alternar promoción del widget sobre el que se pasa el cursor" };
const Comfy_Graph_UnpackSubgraph = { "label": "Desempaquetar el subgrafo seleccionado" };
const Comfy_GroupNode_ConvertSelectedNodesToGroupNode = { "label": "Convertir nodos seleccionados en nodo de grupo" };
const Comfy_GroupNode_ManageGroupNodes = { "label": "Administrar nodos de grupo" };
const Comfy_GroupNode_UngroupSelectedGroupNodes = { "label": "Desagrupar nodos de grupo seleccionados" };
const Comfy_Help_AboutComfyUI = { "label": "Abrir Acerca de ComfyUI" };
const Comfy_Help_OpenComfyOrgDiscord = { "label": "Abrir Comfy-Org Discord" };
const Comfy_Help_OpenComfyUIDocs = { "label": "Abrir documentación de ComfyUI" };
const Comfy_Help_OpenComfyUIForum = { "label": "Abrir foro de ComfyUI" };
const Comfy_Help_OpenComfyUIIssues = { "label": "Abrir problemas de ComfyUI" };
const Comfy_Interrupt = { "label": "Interrumpir" };
const Comfy_LoadDefaultWorkflow = { "label": "Cargar flujo de trabajo predeterminado" };
const Comfy_Manager_CustomNodesManager_ShowCustomNodesMenu = { "label": "Nodos personalizados (Beta)" };
const Comfy_Manager_CustomNodesManager_ShowLegacyCustomNodesMenu = { "label": "Nodos personalizados (heredados)" };
const Comfy_Manager_ShowLegacyManagerMenu = { "label": "Menú del administrador (heredado)" };
const Comfy_Manager_ShowMissingPacks = { "label": "Instalar faltantes" };
const Comfy_Manager_ShowUpdateAvailablePacks = { "label": "Buscar actualizaciones" };
const Comfy_Manager_ToggleManagerProgressDialog = { "label": "Alternar diálogo de progreso del administrador" };
const Comfy_MaskEditor_BrushSize_Decrease = { "label": "Disminuir tamaño del pincel en MaskEditor" };
const Comfy_MaskEditor_BrushSize_Increase = { "label": "Aumentar tamaño del pincel en MaskEditor" };
const Comfy_MaskEditor_OpenMaskEditor = { "label": "Abrir editor de máscara para el nodo seleccionado" };
const Comfy_Memory_UnloadModels = { "label": "Descargar modelos" };
const Comfy_Memory_UnloadModelsAndExecutionCache = { "label": "Descargar modelos y caché de ejecución" };
const Comfy_NewBlankWorkflow = { "label": "Nuevo flujo de trabajo en blanco" };
const Comfy_OpenClipspace = { "label": "Abrir espacio de clips" };
const Comfy_OpenManagerDialog = { "label": "Administrador" };
const Comfy_OpenWorkflow = { "label": "Abrir Flujo de Trabajo" };
const Comfy_PublishSubgraph = { "label": "Publicar subgrafo" };
const Comfy_QueuePrompt = { "label": "Prompt de Cola" };
const Comfy_QueuePromptFront = { "label": "Prompt de Cola (Frente)" };
const Comfy_QueueSelectedOutputNodes = { "label": "Encolar nodos de salida seleccionados" };
const Comfy_Redo = { "label": "Rehacer" };
const Comfy_RefreshNodeDefinitions = { "label": "Actualizar Definiciones de Nodo" };
const Comfy_SaveWorkflow = { "label": "Guardar Flujo de Trabajo" };
const Comfy_SaveWorkflowAs = { "label": "Guardar Flujo de Trabajo Como" };
const Comfy_ShowSettingsDialog = { "label": "Mostrar Diálogo de Configuraciones" };
const Comfy_ToggleAssetAPI = { "label": "Experimental: Habilitar AssetAPI" };
const Comfy_ToggleCanvasInfo = { "label": "Rendimiento del lienzo" };
const Comfy_ToggleHelpCenter = { "label": "Centro de ayuda" };
const Comfy_ToggleTheme = { "label": "Cambiar Tema (Oscuro/Claro)" };
const Comfy_Undo = { "label": "Deshacer" };
const Comfy_User_OpenSignInDialog = { "label": "Abrir diálogo de inicio de sesión" };
const Comfy_User_SignOut = { "label": "Cerrar sesión" };
const Experimental_ToggleVueNodes = { "label": "Experimental: Habilitar nodos Vue" };
const Workspace_CloseWorkflow = { "label": "Cerrar Flujo de Trabajo Actual" };
const Workspace_NextOpenedWorkflow = { "label": "Siguiente Flujo de Trabajo Abierto" };
const Workspace_PreviousOpenedWorkflow = { "label": "Flujo de Trabajo Abierto Anterior" };
const Workspace_SearchBox_Toggle = { "label": "Alternar Caja de Búsqueda" };
const Workspace_ToggleBottomPanel = { "label": "Alternar Panel Inferior" };
const Workspace_ToggleBottomPanel_Shortcuts = { "label": "Mostrar diálogo de combinaciones de teclas" };
const Workspace_ToggleFocusMode = { "label": "Alternar Modo de Enfoque" };
const Workspace_ToggleSidebarTab_assets = { "label": "Alternar barra lateral de recursos", "tooltip": "Recursos" };
const Workspace_ToggleSidebarTab_workflows = { "label": "Alternar Barra Lateral de Flujos de Trabajo", "tooltip": "Flujos de Trabajo" };
const commands = {
  Comfy_3DViewer_Open3DViewer,
  Comfy_BrowseModelAssets,
  Comfy_BrowseTemplates,
  Comfy_Canvas_DeleteSelectedItems,
  Comfy_Canvas_FitView,
  Comfy_Canvas_Lock,
  Comfy_Canvas_MoveSelectedNodes_Down,
  Comfy_Canvas_MoveSelectedNodes_Left,
  Comfy_Canvas_MoveSelectedNodes_Right,
  Comfy_Canvas_MoveSelectedNodes_Up,
  Comfy_Canvas_ResetView,
  Comfy_Canvas_Resize,
  Comfy_Canvas_ToggleLinkVisibility,
  Comfy_Canvas_ToggleLock,
  Comfy_Canvas_ToggleMinimap,
  Comfy_Canvas_ToggleSelectedNodes_Bypass,
  Comfy_Canvas_ToggleSelectedNodes_Collapse,
  Comfy_Canvas_ToggleSelectedNodes_Mute,
  Comfy_Canvas_ToggleSelectedNodes_Pin,
  Comfy_Canvas_ToggleSelected_Pin,
  Comfy_Canvas_Unlock,
  Comfy_Canvas_ZoomIn,
  Comfy_Canvas_ZoomOut,
  Comfy_ClearPendingTasks,
  Comfy_ClearWorkflow,
  Comfy_ContactSupport,
  Comfy_Dev_ShowModelSelector,
  Comfy_DuplicateWorkflow,
  Comfy_ExportWorkflow,
  Comfy_ExportWorkflowAPI,
  Comfy_Graph_ConvertToSubgraph,
  Comfy_Graph_EditSubgraphWidgets,
  Comfy_Graph_ExitSubgraph,
  Comfy_Graph_FitGroupToContents,
  Comfy_Graph_GroupSelectedNodes,
  Comfy_Graph_ToggleWidgetPromotion,
  Comfy_Graph_UnpackSubgraph,
  Comfy_GroupNode_ConvertSelectedNodesToGroupNode,
  Comfy_GroupNode_ManageGroupNodes,
  Comfy_GroupNode_UngroupSelectedGroupNodes,
  Comfy_Help_AboutComfyUI,
  Comfy_Help_OpenComfyOrgDiscord,
  Comfy_Help_OpenComfyUIDocs,
  Comfy_Help_OpenComfyUIForum,
  Comfy_Help_OpenComfyUIIssues,
  Comfy_Interrupt,
  Comfy_LoadDefaultWorkflow,
  Comfy_Manager_CustomNodesManager_ShowCustomNodesMenu,
  Comfy_Manager_CustomNodesManager_ShowLegacyCustomNodesMenu,
  Comfy_Manager_ShowLegacyManagerMenu,
  Comfy_Manager_ShowMissingPacks,
  Comfy_Manager_ShowUpdateAvailablePacks,
  Comfy_Manager_ToggleManagerProgressDialog,
  Comfy_MaskEditor_BrushSize_Decrease,
  Comfy_MaskEditor_BrushSize_Increase,
  Comfy_MaskEditor_OpenMaskEditor,
  Comfy_Memory_UnloadModels,
  Comfy_Memory_UnloadModelsAndExecutionCache,
  Comfy_NewBlankWorkflow,
  Comfy_OpenClipspace,
  Comfy_OpenManagerDialog,
  Comfy_OpenWorkflow,
  Comfy_PublishSubgraph,
  Comfy_QueuePrompt,
  Comfy_QueuePromptFront,
  Comfy_QueueSelectedOutputNodes,
  Comfy_Redo,
  Comfy_RefreshNodeDefinitions,
  Comfy_SaveWorkflow,
  Comfy_SaveWorkflowAs,
  Comfy_ShowSettingsDialog,
  Comfy_ToggleAssetAPI,
  Comfy_ToggleCanvasInfo,
  Comfy_ToggleHelpCenter,
  Comfy_ToggleTheme,
  Comfy_Undo,
  Comfy_User_OpenSignInDialog,
  Comfy_User_SignOut,
  Experimental_ToggleVueNodes,
  Workspace_CloseWorkflow,
  Workspace_NextOpenedWorkflow,
  Workspace_PreviousOpenedWorkflow,
  Workspace_SearchBox_Toggle,
  Workspace_ToggleBottomPanel,
  "Workspace_ToggleBottomPanelTab_command-terminal": { "label": "Alternar Panel Inferior de Terminal" },
  "Workspace_ToggleBottomPanelTab_logs-terminal": { "label": "Alternar Panel Inferior de Registros" },
  "Workspace_ToggleBottomPanelTab_shortcuts-essentials": { "label": "Alternar panel inferior esencial" },
  "Workspace_ToggleBottomPanelTab_shortcuts-view-controls": { "label": "Alternar panel inferior de controles de vista" },
  Workspace_ToggleBottomPanel_Shortcuts,
  Workspace_ToggleFocusMode,
  Workspace_ToggleSidebarTab_assets,
  "Workspace_ToggleSidebarTab_model-library": { "label": "Alternar Barra Lateral de Biblioteca de Modelos", "tooltip": "Biblioteca de Modelos" },
  "Workspace_ToggleSidebarTab_node-library": { "label": "Alternar Barra Lateral de Biblioteca de Nodos", "tooltip": "Biblioteca de Nodos" },
  Workspace_ToggleSidebarTab_workflows
};
export {
  Comfy_3DViewer_Open3DViewer,
  Comfy_BrowseModelAssets,
  Comfy_BrowseTemplates,
  Comfy_Canvas_DeleteSelectedItems,
  Comfy_Canvas_FitView,
  Comfy_Canvas_Lock,
  Comfy_Canvas_MoveSelectedNodes_Down,
  Comfy_Canvas_MoveSelectedNodes_Left,
  Comfy_Canvas_MoveSelectedNodes_Right,
  Comfy_Canvas_MoveSelectedNodes_Up,
  Comfy_Canvas_ResetView,
  Comfy_Canvas_Resize,
  Comfy_Canvas_ToggleLinkVisibility,
  Comfy_Canvas_ToggleLock,
  Comfy_Canvas_ToggleMinimap,
  Comfy_Canvas_ToggleSelectedNodes_Bypass,
  Comfy_Canvas_ToggleSelectedNodes_Collapse,
  Comfy_Canvas_ToggleSelectedNodes_Mute,
  Comfy_Canvas_ToggleSelectedNodes_Pin,
  Comfy_Canvas_ToggleSelected_Pin,
  Comfy_Canvas_Unlock,
  Comfy_Canvas_ZoomIn,
  Comfy_Canvas_ZoomOut,
  Comfy_ClearPendingTasks,
  Comfy_ClearWorkflow,
  Comfy_ContactSupport,
  Comfy_Dev_ShowModelSelector,
  Comfy_DuplicateWorkflow,
  Comfy_ExportWorkflow,
  Comfy_ExportWorkflowAPI,
  Comfy_Graph_ConvertToSubgraph,
  Comfy_Graph_EditSubgraphWidgets,
  Comfy_Graph_ExitSubgraph,
  Comfy_Graph_FitGroupToContents,
  Comfy_Graph_GroupSelectedNodes,
  Comfy_Graph_ToggleWidgetPromotion,
  Comfy_Graph_UnpackSubgraph,
  Comfy_GroupNode_ConvertSelectedNodesToGroupNode,
  Comfy_GroupNode_ManageGroupNodes,
  Comfy_GroupNode_UngroupSelectedGroupNodes,
  Comfy_Help_AboutComfyUI,
  Comfy_Help_OpenComfyOrgDiscord,
  Comfy_Help_OpenComfyUIDocs,
  Comfy_Help_OpenComfyUIForum,
  Comfy_Help_OpenComfyUIIssues,
  Comfy_Interrupt,
  Comfy_LoadDefaultWorkflow,
  Comfy_Manager_CustomNodesManager_ShowCustomNodesMenu,
  Comfy_Manager_CustomNodesManager_ShowLegacyCustomNodesMenu,
  Comfy_Manager_ShowLegacyManagerMenu,
  Comfy_Manager_ShowMissingPacks,
  Comfy_Manager_ShowUpdateAvailablePacks,
  Comfy_Manager_ToggleManagerProgressDialog,
  Comfy_MaskEditor_BrushSize_Decrease,
  Comfy_MaskEditor_BrushSize_Increase,
  Comfy_MaskEditor_OpenMaskEditor,
  Comfy_Memory_UnloadModels,
  Comfy_Memory_UnloadModelsAndExecutionCache,
  Comfy_NewBlankWorkflow,
  Comfy_OpenClipspace,
  Comfy_OpenManagerDialog,
  Comfy_OpenWorkflow,
  Comfy_PublishSubgraph,
  Comfy_QueuePrompt,
  Comfy_QueuePromptFront,
  Comfy_QueueSelectedOutputNodes,
  Comfy_Redo,
  Comfy_RefreshNodeDefinitions,
  Comfy_SaveWorkflow,
  Comfy_SaveWorkflowAs,
  Comfy_ShowSettingsDialog,
  Comfy_ToggleAssetAPI,
  Comfy_ToggleCanvasInfo,
  Comfy_ToggleHelpCenter,
  Comfy_ToggleTheme,
  Comfy_Undo,
  Comfy_User_OpenSignInDialog,
  Comfy_User_SignOut,
  Experimental_ToggleVueNodes,
  Workspace_CloseWorkflow,
  Workspace_NextOpenedWorkflow,
  Workspace_PreviousOpenedWorkflow,
  Workspace_SearchBox_Toggle,
  Workspace_ToggleBottomPanel,
  Workspace_ToggleBottomPanel_Shortcuts,
  Workspace_ToggleFocusMode,
  Workspace_ToggleSidebarTab_assets,
  Workspace_ToggleSidebarTab_workflows,
  commands as default
};
//# sourceMappingURL=commands-CisfgZf5.js.map
