const Comfy_3DViewer_Open3DViewer = { "label": "為選取的節點開啟 3D 檢視器（Beta）" };
const Comfy_BrowseModelAssets = { "label": "實驗性：瀏覽模型資源" };
const Comfy_BrowseTemplates = { "label": "瀏覽範本" };
const Comfy_Canvas_DeleteSelectedItems = { "label": "刪除選取項目" };
const Comfy_Canvas_FitView = { "label": "將視圖適應至所選節點" };
const Comfy_Canvas_Lock = { "label": "鎖定畫布" };
const Comfy_Canvas_MoveSelectedNodes_Down = { "label": "將選取的節點下移" };
const Comfy_Canvas_MoveSelectedNodes_Left = { "label": "左移選取的節點" };
const Comfy_Canvas_MoveSelectedNodes_Right = { "label": "右移選取的節點" };
const Comfy_Canvas_MoveSelectedNodes_Up = { "label": "上移選取的節點" };
const Comfy_Canvas_ResetView = { "label": "重設視圖" };
const Comfy_Canvas_Resize = { "label": "調整所選節點大小" };
const Comfy_Canvas_ToggleLinkVisibility = { "label": "畫布切換連結可見性" };
const Comfy_Canvas_ToggleLock = { "label": "畫布切換鎖定" };
const Comfy_Canvas_ToggleMinimap = { "label": "畫布切換小地圖" };
const Comfy_Canvas_ToggleSelectedNodes_Bypass = { "label": "略過/取消略過選取的節點" };
const Comfy_Canvas_ToggleSelectedNodes_Collapse = { "label": "收合／展開選取的節點" };
const Comfy_Canvas_ToggleSelectedNodes_Mute = { "label": "停用/啟用選取的節點" };
const Comfy_Canvas_ToggleSelectedNodes_Pin = { "label": "釘選/取消釘選已選取的節點" };
const Comfy_Canvas_ToggleSelected_Pin = { "label": "釘選/取消釘選已選項目" };
const Comfy_Canvas_Unlock = { "label": "解鎖畫布" };
const Comfy_Canvas_ZoomIn = { "label": "放大" };
const Comfy_Canvas_ZoomOut = { "label": "縮小" };
const Comfy_ClearPendingTasks = { "label": "清除待處理任務" };
const Comfy_ClearWorkflow = { "label": "清除工作流程" };
const Comfy_ContactSupport = { "label": "聯絡支援" };
const Comfy_Dev_ShowModelSelector = { "label": "顯示模型選擇器（開發）" };
const Comfy_DuplicateWorkflow = { "label": "複製目前工作流程" };
const Comfy_ExportWorkflow = { "label": "匯出工作流程" };
const Comfy_ExportWorkflowAPI = { "label": "匯出工作流程（API 格式）" };
const Comfy_Graph_ConvertToSubgraph = { "label": "將選取內容轉換為子圖" };
const Comfy_Graph_EditSubgraphWidgets = { "label": "編輯子圖表小工具" };
const Comfy_Graph_ExitSubgraph = { "label": "離開子圖" };
const Comfy_Graph_FitGroupToContents = { "label": "調整群組以符合內容" };
const Comfy_Graph_GroupSelectedNodes = { "label": "群組所選節點" };
const Comfy_Graph_ToggleWidgetPromotion = { "label": "切換懸停小工具的提升" };
const Comfy_Graph_UnpackSubgraph = { "label": "解開所選子圖" };
const Comfy_GroupNode_ConvertSelectedNodesToGroupNode = { "label": "將選取的節點轉換為群組節點" };
const Comfy_GroupNode_ManageGroupNodes = { "label": "管理群組節點" };
const Comfy_GroupNode_UngroupSelectedGroupNodes = { "label": "取消群組所選群組節點" };
const Comfy_Help_AboutComfyUI = { "label": "開啟關於 ComfyUI" };
const Comfy_Help_OpenComfyOrgDiscord = { "label": "開啟 Comfy-Org Discord" };
const Comfy_Help_OpenComfyUIDocs = { "label": "開啟 ComfyUI 文件" };
const Comfy_Help_OpenComfyUIForum = { "label": "開啟 ComfyUI 論壇" };
const Comfy_Help_OpenComfyUIIssues = { "label": "開啟 ComfyUI 問題追蹤" };
const Comfy_Interrupt = { "label": "中斷" };
const Comfy_LoadDefaultWorkflow = { "label": "載入預設工作流程" };
const Comfy_Manager_CustomNodesManager_ShowCustomNodesMenu = { "label": "自訂節點管理器" };
const Comfy_Manager_CustomNodesManager_ShowLegacyCustomNodesMenu = { "label": "自訂節點（舊版）" };
const Comfy_Manager_ShowLegacyManagerMenu = { "label": "管理選單（舊版）" };
const Comfy_Manager_ShowMissingPacks = { "label": "安裝缺少的自訂節點" };
const Comfy_Manager_ShowUpdateAvailablePacks = { "label": "檢查自訂節點更新" };
const Comfy_Manager_ToggleManagerProgressDialog = { "label": "切換自訂節點管理器進度條" };
const Comfy_MaskEditor_BrushSize_Decrease = { "label": "減少 MaskEditor 畫筆大小" };
const Comfy_MaskEditor_BrushSize_Increase = { "label": "增加 MaskEditor 畫筆大小" };
const Comfy_MaskEditor_OpenMaskEditor = { "label": "為選取的節點開啟 Mask 編輯器" };
const Comfy_Memory_UnloadModels = { "label": "卸載模型" };
const Comfy_Memory_UnloadModelsAndExecutionCache = { "label": "卸載模型與執行快取" };
const Comfy_NewBlankWorkflow = { "label": "新增空白工作流程" };
const Comfy_OpenClipspace = { "label": "Clipspace" };
const Comfy_OpenManagerDialog = { "label": "管理器" };
const Comfy_OpenWorkflow = { "label": "開啟工作流程" };
const Comfy_PublishSubgraph = { "label": "發布子圖" };
const Comfy_QueuePrompt = { "label": "將提示詞加入佇列" };
const Comfy_QueuePromptFront = { "label": "將提示詞加入佇列前方" };
const Comfy_QueueSelectedOutputNodes = { "label": "佇列所選的輸出節點" };
const Comfy_Redo = { "label": "重做" };
const Comfy_RefreshNodeDefinitions = { "label": "重新整理節點定義" };
const Comfy_SaveWorkflow = { "label": "儲存工作流程" };
const Comfy_SaveWorkflowAs = { "label": "另存工作流程" };
const Comfy_ShowSettingsDialog = { "label": "顯示設定對話框" };
const Comfy_ToggleAssetAPI = { "label": "實驗性：啟用 AssetAPI" };
const Comfy_ToggleCanvasInfo = { "label": "畫布效能" };
const Comfy_ToggleHelpCenter = { "label": "說明中心" };
const Comfy_ToggleTheme = { "label": "切換主題（深色／淺色）" };
const Comfy_Undo = { "label": "復原" };
const Comfy_User_OpenSignInDialog = { "label": "開啟登入對話框" };
const Comfy_User_SignOut = { "label": "登出" };
const Experimental_ToggleVueNodes = { "label": "實驗性：啟用 Vue 節點" };
const Workspace_CloseWorkflow = { "label": "關閉當前工作流程" };
const Workspace_NextOpenedWorkflow = { "label": "下一個已開啟的工作流程" };
const Workspace_PreviousOpenedWorkflow = { "label": "上次開啟的工作流程" };
const Workspace_SearchBox_Toggle = { "label": "切換搜尋框" };
const Workspace_ToggleBottomPanel = { "label": "切換下方面板" };
const Workspace_ToggleBottomPanel_Shortcuts = { "label": "顯示快捷鍵對話框" };
const Workspace_ToggleFocusMode = { "label": "切換專注模式" };
const Workspace_ToggleSidebarTab_assets = { "label": "切換資源側邊欄", "tooltip": "資源" };
const Workspace_ToggleSidebarTab_workflows = { "label": "切換工作流程側邊欄", "tooltip": "工作流程" };
const commands = {
  Comfy_3DViewer_Open3DViewer,
  Comfy_BrowseModelAssets,
  Comfy_BrowseTemplates,
  Comfy_Canvas_DeleteSelectedItems,
  Comfy_Canvas_FitView,
  Comfy_Canvas_Lock,
  Comfy_Canvas_MoveSelectedNodes_Down,
  Comfy_Canvas_MoveSelectedNodes_Left,
  Comfy_Canvas_MoveSelectedNodes_Right,
  Comfy_Canvas_MoveSelectedNodes_Up,
  Comfy_Canvas_ResetView,
  Comfy_Canvas_Resize,
  Comfy_Canvas_ToggleLinkVisibility,
  Comfy_Canvas_ToggleLock,
  Comfy_Canvas_ToggleMinimap,
  Comfy_Canvas_ToggleSelectedNodes_Bypass,
  Comfy_Canvas_ToggleSelectedNodes_Collapse,
  Comfy_Canvas_ToggleSelectedNodes_Mute,
  Comfy_Canvas_ToggleSelectedNodes_Pin,
  Comfy_Canvas_ToggleSelected_Pin,
  Comfy_Canvas_Unlock,
  Comfy_Canvas_ZoomIn,
  Comfy_Canvas_ZoomOut,
  Comfy_ClearPendingTasks,
  Comfy_ClearWorkflow,
  Comfy_ContactSupport,
  Comfy_Dev_ShowModelSelector,
  Comfy_DuplicateWorkflow,
  Comfy_ExportWorkflow,
  Comfy_ExportWorkflowAPI,
  Comfy_Graph_ConvertToSubgraph,
  Comfy_Graph_EditSubgraphWidgets,
  Comfy_Graph_ExitSubgraph,
  Comfy_Graph_FitGroupToContents,
  Comfy_Graph_GroupSelectedNodes,
  Comfy_Graph_ToggleWidgetPromotion,
  Comfy_Graph_UnpackSubgraph,
  Comfy_GroupNode_ConvertSelectedNodesToGroupNode,
  Comfy_GroupNode_ManageGroupNodes,
  Comfy_GroupNode_UngroupSelectedGroupNodes,
  Comfy_Help_AboutComfyUI,
  Comfy_Help_OpenComfyOrgDiscord,
  Comfy_Help_OpenComfyUIDocs,
  Comfy_Help_OpenComfyUIForum,
  Comfy_Help_OpenComfyUIIssues,
  Comfy_Interrupt,
  Comfy_LoadDefaultWorkflow,
  Comfy_Manager_CustomNodesManager_ShowCustomNodesMenu,
  Comfy_Manager_CustomNodesManager_ShowLegacyCustomNodesMenu,
  Comfy_Manager_ShowLegacyManagerMenu,
  Comfy_Manager_ShowMissingPacks,
  Comfy_Manager_ShowUpdateAvailablePacks,
  Comfy_Manager_ToggleManagerProgressDialog,
  Comfy_MaskEditor_BrushSize_Decrease,
  Comfy_MaskEditor_BrushSize_Increase,
  Comfy_MaskEditor_OpenMaskEditor,
  Comfy_Memory_UnloadModels,
  Comfy_Memory_UnloadModelsAndExecutionCache,
  Comfy_NewBlankWorkflow,
  Comfy_OpenClipspace,
  Comfy_OpenManagerDialog,
  Comfy_OpenWorkflow,
  Comfy_PublishSubgraph,
  Comfy_QueuePrompt,
  Comfy_QueuePromptFront,
  Comfy_QueueSelectedOutputNodes,
  Comfy_Redo,
  Comfy_RefreshNodeDefinitions,
  Comfy_SaveWorkflow,
  Comfy_SaveWorkflowAs,
  Comfy_ShowSettingsDialog,
  Comfy_ToggleAssetAPI,
  Comfy_ToggleCanvasInfo,
  Comfy_ToggleHelpCenter,
  Comfy_ToggleTheme,
  Comfy_Undo,
  Comfy_User_OpenSignInDialog,
  Comfy_User_SignOut,
  Experimental_ToggleVueNodes,
  Workspace_CloseWorkflow,
  Workspace_NextOpenedWorkflow,
  Workspace_PreviousOpenedWorkflow,
  Workspace_SearchBox_Toggle,
  Workspace_ToggleBottomPanel,
  "Workspace_ToggleBottomPanelTab_command-terminal": { "label": "切換終端機底部面板" },
  "Workspace_ToggleBottomPanelTab_logs-terminal": { "label": "切換日誌底部面板" },
  "Workspace_ToggleBottomPanelTab_shortcuts-essentials": { "label": "切換基本下方面板" },
  "Workspace_ToggleBottomPanelTab_shortcuts-view-controls": { "label": "切換檢視控制底部面板" },
  Workspace_ToggleBottomPanel_Shortcuts,
  Workspace_ToggleFocusMode,
  Workspace_ToggleSidebarTab_assets,
  "Workspace_ToggleSidebarTab_model-library": { "label": "切換模型庫側邊欄", "tooltip": "模型庫" },
  "Workspace_ToggleSidebarTab_node-library": { "label": "切換節點庫側邊欄", "tooltip": "節點庫" },
  Workspace_ToggleSidebarTab_workflows
};
export {
  Comfy_3DViewer_Open3DViewer,
  Comfy_BrowseModelAssets,
  Comfy_BrowseTemplates,
  Comfy_Canvas_DeleteSelectedItems,
  Comfy_Canvas_FitView,
  Comfy_Canvas_Lock,
  Comfy_Canvas_MoveSelectedNodes_Down,
  Comfy_Canvas_MoveSelectedNodes_Left,
  Comfy_Canvas_MoveSelectedNodes_Right,
  Comfy_Canvas_MoveSelectedNodes_Up,
  Comfy_Canvas_ResetView,
  Comfy_Canvas_Resize,
  Comfy_Canvas_ToggleLinkVisibility,
  Comfy_Canvas_ToggleLock,
  Comfy_Canvas_ToggleMinimap,
  Comfy_Canvas_ToggleSelectedNodes_Bypass,
  Comfy_Canvas_ToggleSelectedNodes_Collapse,
  Comfy_Canvas_ToggleSelectedNodes_Mute,
  Comfy_Canvas_ToggleSelectedNodes_Pin,
  Comfy_Canvas_ToggleSelected_Pin,
  Comfy_Canvas_Unlock,
  Comfy_Canvas_ZoomIn,
  Comfy_Canvas_ZoomOut,
  Comfy_ClearPendingTasks,
  Comfy_ClearWorkflow,
  Comfy_ContactSupport,
  Comfy_Dev_ShowModelSelector,
  Comfy_DuplicateWorkflow,
  Comfy_ExportWorkflow,
  Comfy_ExportWorkflowAPI,
  Comfy_Graph_ConvertToSubgraph,
  Comfy_Graph_EditSubgraphWidgets,
  Comfy_Graph_ExitSubgraph,
  Comfy_Graph_FitGroupToContents,
  Comfy_Graph_GroupSelectedNodes,
  Comfy_Graph_ToggleWidgetPromotion,
  Comfy_Graph_UnpackSubgraph,
  Comfy_GroupNode_ConvertSelectedNodesToGroupNode,
  Comfy_GroupNode_ManageGroupNodes,
  Comfy_GroupNode_UngroupSelectedGroupNodes,
  Comfy_Help_AboutComfyUI,
  Comfy_Help_OpenComfyOrgDiscord,
  Comfy_Help_OpenComfyUIDocs,
  Comfy_Help_OpenComfyUIForum,
  Comfy_Help_OpenComfyUIIssues,
  Comfy_Interrupt,
  Comfy_LoadDefaultWorkflow,
  Comfy_Manager_CustomNodesManager_ShowCustomNodesMenu,
  Comfy_Manager_CustomNodesManager_ShowLegacyCustomNodesMenu,
  Comfy_Manager_ShowLegacyManagerMenu,
  Comfy_Manager_ShowMissingPacks,
  Comfy_Manager_ShowUpdateAvailablePacks,
  Comfy_Manager_ToggleManagerProgressDialog,
  Comfy_MaskEditor_BrushSize_Decrease,
  Comfy_MaskEditor_BrushSize_Increase,
  Comfy_MaskEditor_OpenMaskEditor,
  Comfy_Memory_UnloadModels,
  Comfy_Memory_UnloadModelsAndExecutionCache,
  Comfy_NewBlankWorkflow,
  Comfy_OpenClipspace,
  Comfy_OpenManagerDialog,
  Comfy_OpenWorkflow,
  Comfy_PublishSubgraph,
  Comfy_QueuePrompt,
  Comfy_QueuePromptFront,
  Comfy_QueueSelectedOutputNodes,
  Comfy_Redo,
  Comfy_RefreshNodeDefinitions,
  Comfy_SaveWorkflow,
  Comfy_SaveWorkflowAs,
  Comfy_ShowSettingsDialog,
  Comfy_ToggleAssetAPI,
  Comfy_ToggleCanvasInfo,
  Comfy_ToggleHelpCenter,
  Comfy_ToggleTheme,
  Comfy_Undo,
  Comfy_User_OpenSignInDialog,
  Comfy_User_SignOut,
  Experimental_ToggleVueNodes,
  Workspace_CloseWorkflow,
  Workspace_NextOpenedWorkflow,
  Workspace_PreviousOpenedWorkflow,
  Workspace_SearchBox_Toggle,
  Workspace_ToggleBottomPanel,
  Workspace_ToggleBottomPanel_Shortcuts,
  Workspace_ToggleFocusMode,
  Workspace_ToggleSidebarTab_assets,
  Workspace_ToggleSidebarTab_workflows,
  commands as default
};
//# sourceMappingURL=commands-CkU12Foh.js.map
