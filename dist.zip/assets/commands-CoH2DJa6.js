const Comfy_3DViewer_Open3DViewer = { "label": "Ouvrir le visualiseur 3D (bêta) pour le nœud sélectionné" };
const Comfy_BrowseModelAssets = { "label": "Expérimental : Parcourir les ressources de modèles" };
const Comfy_BrowseTemplates = { "label": "Parcourir les modèles" };
const Comfy_Canvas_DeleteSelectedItems = { "label": "Supprimer les éléments sélectionnés" };
const Comfy_Canvas_FitView = { "label": "Ajuster la vue aux nœuds sélectionnés" };
const Comfy_Canvas_Lock = { "label": "Verrouiller la toile" };
const Comfy_Canvas_MoveSelectedNodes_Down = { "label": "Déplacer les nœuds sélectionnés vers le bas" };
const Comfy_Canvas_MoveSelectedNodes_Left = { "label": "Déplacer les nœuds sélectionnés vers la gauche" };
const Comfy_Canvas_MoveSelectedNodes_Right = { "label": "Déplacer les nœuds sélectionnés vers la droite" };
const Comfy_Canvas_MoveSelectedNodes_Up = { "label": "Déplacer les nœuds sélectionnés vers le haut" };
const Comfy_Canvas_ResetView = { "label": "Réinitialiser la vue" };
const Comfy_Canvas_Resize = { "label": "Redimensionner les nœuds sélectionnés" };
const Comfy_Canvas_ToggleLinkVisibility = { "label": "Basculer la visibilité du lien sur le canevas" };
const Comfy_Canvas_ToggleLock = { "label": "Basculer le verrouillage du canevas" };
const Comfy_Canvas_ToggleMinimap = { "label": "Basculer la mini-carte du canevas" };
const Comfy_Canvas_ToggleSelectedNodes_Bypass = { "label": "Contourner/Ne pas contourner les nœuds sélectionnés" };
const Comfy_Canvas_ToggleSelectedNodes_Collapse = { "label": "Réduire/Étendre les nœuds sélectionnés" };
const Comfy_Canvas_ToggleSelectedNodes_Mute = { "label": "Mettre en sourdine/Activer le son des nœuds sélectionnés" };
const Comfy_Canvas_ToggleSelectedNodes_Pin = { "label": "Épingler/Désépingler les nœuds sélectionnés" };
const Comfy_Canvas_ToggleSelected_Pin = { "label": "Épingler/Désépingler les éléments sélectionnés" };
const Comfy_Canvas_Unlock = { "label": "Déverrouiller le Canvas" };
const Comfy_Canvas_ZoomIn = { "label": "Zoom avant" };
const Comfy_Canvas_ZoomOut = { "label": "Zoom arrière" };
const Comfy_ClearPendingTasks = { "label": "Effacer les tâches en attente" };
const Comfy_ClearWorkflow = { "label": "Effacer le flux de travail" };
const Comfy_ContactSupport = { "label": "Contacter le support" };
const Comfy_Dev_ShowModelSelector = { "label": "Afficher le sélecteur de modèle (Dev)" };
const Comfy_DuplicateWorkflow = { "label": "Dupliquer le flux de travail actuel" };
const Comfy_ExportWorkflow = { "label": "Exporter le flux de travail" };
const Comfy_ExportWorkflowAPI = { "label": "Exporter le flux de travail (format API)" };
const Comfy_Graph_ConvertToSubgraph = { "label": "Convertir la sélection en sous-graphe" };
const Comfy_Graph_EditSubgraphWidgets = { "label": "Modifier les widgets de sous-graphe" };
const Comfy_Graph_ExitSubgraph = { "label": "Quitter le sous-graphe" };
const Comfy_Graph_FitGroupToContents = { "label": "Ajuster le groupe au contenu" };
const Comfy_Graph_GroupSelectedNodes = { "label": "Grouper les nœuds sélectionnés" };
const Comfy_Graph_ToggleWidgetPromotion = { "label": "Activer/désactiver la promotion du widget survolé" };
const Comfy_Graph_UnpackSubgraph = { "label": "Décompresser le sous-graphe sélectionné" };
const Comfy_GroupNode_ConvertSelectedNodesToGroupNode = { "label": "Convertir les nœuds sélectionnés en nœud de groupe" };
const Comfy_GroupNode_ManageGroupNodes = { "label": "Gérer les nœuds de groupe" };
const Comfy_GroupNode_UngroupSelectedGroupNodes = { "label": "Dégrouper les nœuds de groupe sélectionnés" };
const Comfy_Help_AboutComfyUI = { "label": "Ouvrir À propos de ComfyUI" };
const Comfy_Help_OpenComfyOrgDiscord = { "label": "Ouvrir Comfy-Org Discord" };
const Comfy_Help_OpenComfyUIDocs = { "label": "Ouvrir les documents ComfyUI" };
const Comfy_Help_OpenComfyUIForum = { "label": "Ouvrir le forum Comfy-Org" };
const Comfy_Help_OpenComfyUIIssues = { "label": "Ouvrir les problèmes ComfyUI" };
const Comfy_Interrupt = { "label": "Interrompre" };
const Comfy_LoadDefaultWorkflow = { "label": "Charger le flux de travail par défaut" };
const Comfy_Manager_CustomNodesManager_ShowCustomNodesMenu = { "label": "Nœuds personnalisés (Beta)" };
const Comfy_Manager_CustomNodesManager_ShowLegacyCustomNodesMenu = { "label": "Nœuds personnalisés (hérités)" };
const Comfy_Manager_ShowLegacyManagerMenu = { "label": "Menu du gestionnaire (héritage)" };
const Comfy_Manager_ShowMissingPacks = { "label": "Installer manquants" };
const Comfy_Manager_ShowUpdateAvailablePacks = { "label": "Vérifier les mises à jour" };
const Comfy_Manager_ToggleManagerProgressDialog = { "label": "Basculer la boîte de dialogue de progression" };
const Comfy_MaskEditor_BrushSize_Decrease = { "label": "Réduire la taille du pinceau dans MaskEditor" };
const Comfy_MaskEditor_BrushSize_Increase = { "label": "Augmenter la taille du pinceau dans MaskEditor" };
const Comfy_MaskEditor_OpenMaskEditor = { "label": "Ouvrir l'éditeur de masque pour le nœud sélectionné" };
const Comfy_Memory_UnloadModels = { "label": "Décharger les modèles" };
const Comfy_Memory_UnloadModelsAndExecutionCache = { "label": "Décharger les modèles et le cache d'exécution" };
const Comfy_NewBlankWorkflow = { "label": "Nouveau flux de travail vierge" };
const Comfy_OpenClipspace = { "label": "Espace de clip" };
const Comfy_OpenManagerDialog = { "label": "Gestionnaire" };
const Comfy_OpenWorkflow = { "label": "Ouvrir le flux de travail" };
const Comfy_PublishSubgraph = { "label": "Publier le sous-graphe" };
const Comfy_QueuePrompt = { "label": "Invite de file d'attente" };
const Comfy_QueuePromptFront = { "label": "Invite de file d'attente (avant)" };
const Comfy_QueueSelectedOutputNodes = { "label": "Mettre en file d’attente les nœuds de sortie sélectionnés" };
const Comfy_Redo = { "label": "Refaire" };
const Comfy_RefreshNodeDefinitions = { "label": "Actualiser les définitions de nœud" };
const Comfy_SaveWorkflow = { "label": "Enregistrer le flux de travail" };
const Comfy_SaveWorkflowAs = { "label": "Enregistrer le flux de travail sous" };
const Comfy_ShowSettingsDialog = { "label": "Afficher la boîte de dialogue des paramètres" };
const Comfy_ToggleAssetAPI = { "label": "Expérimental : Activer AssetAPI" };
const Comfy_ToggleCanvasInfo = { "label": "Performance du canvas" };
const Comfy_ToggleHelpCenter = { "label": "Centre d'aide" };
const Comfy_ToggleTheme = { "label": "Changer de thème (Sombre/Clair)" };
const Comfy_Undo = { "label": "Annuler" };
const Comfy_User_OpenSignInDialog = { "label": "Ouvrir la boîte de dialogue de connexion" };
const Comfy_User_SignOut = { "label": "Se déconnecter" };
const Experimental_ToggleVueNodes = { "label": "Expérimental : Activer les nœuds Vue" };
const Workspace_CloseWorkflow = { "label": "Fermer le flux de travail actuel" };
const Workspace_NextOpenedWorkflow = { "label": "Flux de travail ouvert suivant" };
const Workspace_PreviousOpenedWorkflow = { "label": "Flux de travail ouvert précédent" };
const Workspace_SearchBox_Toggle = { "label": "Basculer la boîte de recherche" };
const Workspace_ToggleBottomPanel = { "label": "Basculer le panneau inférieur" };
const Workspace_ToggleBottomPanel_Shortcuts = { "label": "Afficher la boîte de dialogue des raccourcis clavier" };
const Workspace_ToggleFocusMode = { "label": "Basculer le mode focus" };
const Workspace_ToggleSidebarTab_assets = { "label": "Afficher/Masquer la barre latérale des ressources", "tooltip": "Ressources" };
const Workspace_ToggleSidebarTab_workflows = { "label": "Basculer la barre latérale des flux de travail", "tooltip": "Flux de travail" };
const commands = {
  Comfy_3DViewer_Open3DViewer,
  Comfy_BrowseModelAssets,
  Comfy_BrowseTemplates,
  Comfy_Canvas_DeleteSelectedItems,
  Comfy_Canvas_FitView,
  Comfy_Canvas_Lock,
  Comfy_Canvas_MoveSelectedNodes_Down,
  Comfy_Canvas_MoveSelectedNodes_Left,
  Comfy_Canvas_MoveSelectedNodes_Right,
  Comfy_Canvas_MoveSelectedNodes_Up,
  Comfy_Canvas_ResetView,
  Comfy_Canvas_Resize,
  Comfy_Canvas_ToggleLinkVisibility,
  Comfy_Canvas_ToggleLock,
  Comfy_Canvas_ToggleMinimap,
  Comfy_Canvas_ToggleSelectedNodes_Bypass,
  Comfy_Canvas_ToggleSelectedNodes_Collapse,
  Comfy_Canvas_ToggleSelectedNodes_Mute,
  Comfy_Canvas_ToggleSelectedNodes_Pin,
  Comfy_Canvas_ToggleSelected_Pin,
  Comfy_Canvas_Unlock,
  Comfy_Canvas_ZoomIn,
  Comfy_Canvas_ZoomOut,
  Comfy_ClearPendingTasks,
  Comfy_ClearWorkflow,
  Comfy_ContactSupport,
  Comfy_Dev_ShowModelSelector,
  Comfy_DuplicateWorkflow,
  Comfy_ExportWorkflow,
  Comfy_ExportWorkflowAPI,
  Comfy_Graph_ConvertToSubgraph,
  Comfy_Graph_EditSubgraphWidgets,
  Comfy_Graph_ExitSubgraph,
  Comfy_Graph_FitGroupToContents,
  Comfy_Graph_GroupSelectedNodes,
  Comfy_Graph_ToggleWidgetPromotion,
  Comfy_Graph_UnpackSubgraph,
  Comfy_GroupNode_ConvertSelectedNodesToGroupNode,
  Comfy_GroupNode_ManageGroupNodes,
  Comfy_GroupNode_UngroupSelectedGroupNodes,
  Comfy_Help_AboutComfyUI,
  Comfy_Help_OpenComfyOrgDiscord,
  Comfy_Help_OpenComfyUIDocs,
  Comfy_Help_OpenComfyUIForum,
  Comfy_Help_OpenComfyUIIssues,
  Comfy_Interrupt,
  Comfy_LoadDefaultWorkflow,
  Comfy_Manager_CustomNodesManager_ShowCustomNodesMenu,
  Comfy_Manager_CustomNodesManager_ShowLegacyCustomNodesMenu,
  Comfy_Manager_ShowLegacyManagerMenu,
  Comfy_Manager_ShowMissingPacks,
  Comfy_Manager_ShowUpdateAvailablePacks,
  Comfy_Manager_ToggleManagerProgressDialog,
  Comfy_MaskEditor_BrushSize_Decrease,
  Comfy_MaskEditor_BrushSize_Increase,
  Comfy_MaskEditor_OpenMaskEditor,
  Comfy_Memory_UnloadModels,
  Comfy_Memory_UnloadModelsAndExecutionCache,
  Comfy_NewBlankWorkflow,
  Comfy_OpenClipspace,
  Comfy_OpenManagerDialog,
  Comfy_OpenWorkflow,
  Comfy_PublishSubgraph,
  Comfy_QueuePrompt,
  Comfy_QueuePromptFront,
  Comfy_QueueSelectedOutputNodes,
  Comfy_Redo,
  Comfy_RefreshNodeDefinitions,
  Comfy_SaveWorkflow,
  Comfy_SaveWorkflowAs,
  Comfy_ShowSettingsDialog,
  Comfy_ToggleAssetAPI,
  Comfy_ToggleCanvasInfo,
  Comfy_ToggleHelpCenter,
  Comfy_ToggleTheme,
  Comfy_Undo,
  Comfy_User_OpenSignInDialog,
  Comfy_User_SignOut,
  Experimental_ToggleVueNodes,
  Workspace_CloseWorkflow,
  Workspace_NextOpenedWorkflow,
  Workspace_PreviousOpenedWorkflow,
  Workspace_SearchBox_Toggle,
  Workspace_ToggleBottomPanel,
  "Workspace_ToggleBottomPanelTab_command-terminal": { "label": "Basculer le panneau inférieur du terminal" },
  "Workspace_ToggleBottomPanelTab_logs-terminal": { "label": "Basculer le panneau inférieur des journaux" },
  "Workspace_ToggleBottomPanelTab_shortcuts-essentials": { "label": "Afficher/Masquer le panneau inférieur essentiel" },
  "Workspace_ToggleBottomPanelTab_shortcuts-view-controls": { "label": "Afficher/Masquer le panneau inférieur des contrôles de vue" },
  Workspace_ToggleBottomPanel_Shortcuts,
  Workspace_ToggleFocusMode,
  Workspace_ToggleSidebarTab_assets,
  "Workspace_ToggleSidebarTab_model-library": { "label": "Basculer la barre latérale de la bibliothèque de modèles", "tooltip": "Bibliothèque de modèles" },
  "Workspace_ToggleSidebarTab_node-library": { "label": "Basculer la barre latérale de la bibliothèque de nœuds", "tooltip": "Bibliothèque de nœuds" },
  Workspace_ToggleSidebarTab_workflows
};
export {
  Comfy_3DViewer_Open3DViewer,
  Comfy_BrowseModelAssets,
  Comfy_BrowseTemplates,
  Comfy_Canvas_DeleteSelectedItems,
  Comfy_Canvas_FitView,
  Comfy_Canvas_Lock,
  Comfy_Canvas_MoveSelectedNodes_Down,
  Comfy_Canvas_MoveSelectedNodes_Left,
  Comfy_Canvas_MoveSelectedNodes_Right,
  Comfy_Canvas_MoveSelectedNodes_Up,
  Comfy_Canvas_ResetView,
  Comfy_Canvas_Resize,
  Comfy_Canvas_ToggleLinkVisibility,
  Comfy_Canvas_ToggleLock,
  Comfy_Canvas_ToggleMinimap,
  Comfy_Canvas_ToggleSelectedNodes_Bypass,
  Comfy_Canvas_ToggleSelectedNodes_Collapse,
  Comfy_Canvas_ToggleSelectedNodes_Mute,
  Comfy_Canvas_ToggleSelectedNodes_Pin,
  Comfy_Canvas_ToggleSelected_Pin,
  Comfy_Canvas_Unlock,
  Comfy_Canvas_ZoomIn,
  Comfy_Canvas_ZoomOut,
  Comfy_ClearPendingTasks,
  Comfy_ClearWorkflow,
  Comfy_ContactSupport,
  Comfy_Dev_ShowModelSelector,
  Comfy_DuplicateWorkflow,
  Comfy_ExportWorkflow,
  Comfy_ExportWorkflowAPI,
  Comfy_Graph_ConvertToSubgraph,
  Comfy_Graph_EditSubgraphWidgets,
  Comfy_Graph_ExitSubgraph,
  Comfy_Graph_FitGroupToContents,
  Comfy_Graph_GroupSelectedNodes,
  Comfy_Graph_ToggleWidgetPromotion,
  Comfy_Graph_UnpackSubgraph,
  Comfy_GroupNode_ConvertSelectedNodesToGroupNode,
  Comfy_GroupNode_ManageGroupNodes,
  Comfy_GroupNode_UngroupSelectedGroupNodes,
  Comfy_Help_AboutComfyUI,
  Comfy_Help_OpenComfyOrgDiscord,
  Comfy_Help_OpenComfyUIDocs,
  Comfy_Help_OpenComfyUIForum,
  Comfy_Help_OpenComfyUIIssues,
  Comfy_Interrupt,
  Comfy_LoadDefaultWorkflow,
  Comfy_Manager_CustomNodesManager_ShowCustomNodesMenu,
  Comfy_Manager_CustomNodesManager_ShowLegacyCustomNodesMenu,
  Comfy_Manager_ShowLegacyManagerMenu,
  Comfy_Manager_ShowMissingPacks,
  Comfy_Manager_ShowUpdateAvailablePacks,
  Comfy_Manager_ToggleManagerProgressDialog,
  Comfy_MaskEditor_BrushSize_Decrease,
  Comfy_MaskEditor_BrushSize_Increase,
  Comfy_MaskEditor_OpenMaskEditor,
  Comfy_Memory_UnloadModels,
  Comfy_Memory_UnloadModelsAndExecutionCache,
  Comfy_NewBlankWorkflow,
  Comfy_OpenClipspace,
  Comfy_OpenManagerDialog,
  Comfy_OpenWorkflow,
  Comfy_PublishSubgraph,
  Comfy_QueuePrompt,
  Comfy_QueuePromptFront,
  Comfy_QueueSelectedOutputNodes,
  Comfy_Redo,
  Comfy_RefreshNodeDefinitions,
  Comfy_SaveWorkflow,
  Comfy_SaveWorkflowAs,
  Comfy_ShowSettingsDialog,
  Comfy_ToggleAssetAPI,
  Comfy_ToggleCanvasInfo,
  Comfy_ToggleHelpCenter,
  Comfy_ToggleTheme,
  Comfy_Undo,
  Comfy_User_OpenSignInDialog,
  Comfy_User_SignOut,
  Experimental_ToggleVueNodes,
  Workspace_CloseWorkflow,
  Workspace_NextOpenedWorkflow,
  Workspace_PreviousOpenedWorkflow,
  Workspace_SearchBox_Toggle,
  Workspace_ToggleBottomPanel,
  Workspace_ToggleBottomPanel_Shortcuts,
  Workspace_ToggleFocusMode,
  Workspace_ToggleSidebarTab_assets,
  Workspace_ToggleSidebarTab_workflows,
  commands as default
};
//# sourceMappingURL=commands-CoH2DJa6.js.map
