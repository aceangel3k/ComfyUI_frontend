const Comfy_3DViewer_Open3DViewer = { "label": "Открыть 3D-просмотрщик (бета) для выбранного узла" };
const Comfy_BrowseModelAssets = { "label": "Экспериментально: Просмотр ресурсов моделей" };
const Comfy_BrowseTemplates = { "label": "Просмотр шаблонов" };
const Comfy_Canvas_DeleteSelectedItems = { "label": "Удалить выбранные элементы" };
const Comfy_Canvas_FitView = { "label": "Подогнать вид к выбранным нодам" };
const Comfy_Canvas_Lock = { "label": "Заблокировать холст" };
const Comfy_Canvas_MoveSelectedNodes_Down = { "label": "Переместить выбранные узлы вниз" };
const Comfy_Canvas_MoveSelectedNodes_Left = { "label": "Переместить выбранные узлы влево" };
const Comfy_Canvas_MoveSelectedNodes_Right = { "label": "Переместить выбранные узлы вправо" };
const Comfy_Canvas_MoveSelectedNodes_Up = { "label": "Переместить выбранные узлы вверх" };
const Comfy_Canvas_ResetView = { "label": "Сбросить вид" };
const Comfy_Canvas_Resize = { "label": "Изменить размер выбранных узлов" };
const Comfy_Canvas_ToggleLinkVisibility = { "label": "Переключить видимость ссылки" };
const Comfy_Canvas_ToggleLock = { "label": "Переключить блокировку холста" };
const Comfy_Canvas_ToggleMinimap = { "label": "Полотно: переключить миникарту" };
const Comfy_Canvas_ToggleSelectedNodes_Bypass = { "label": "Обход/Необход выбранных нод" };
const Comfy_Canvas_ToggleSelectedNodes_Collapse = { "label": "Свернуть/Развернуть выбранные ноды" };
const Comfy_Canvas_ToggleSelectedNodes_Mute = { "label": "Отключить/Включить звук выбранных нод" };
const Comfy_Canvas_ToggleSelectedNodes_Pin = { "label": "Закрепить/Открепить выбранные ноды" };
const Comfy_Canvas_ToggleSelected_Pin = { "label": "Закрепить/Открепить выбранных нод" };
const Comfy_Canvas_Unlock = { "label": "Разблокировать Canvas" };
const Comfy_Canvas_ZoomIn = { "label": "Увеличить" };
const Comfy_Canvas_ZoomOut = { "label": "Уменьшить" };
const Comfy_ClearPendingTasks = { "label": "Очистить ожидающие задачи" };
const Comfy_ClearWorkflow = { "label": "Очистить рабочий процесс" };
const Comfy_ContactSupport = { "label": "Связаться с поддержкой" };
const Comfy_Dev_ShowModelSelector = { "label": "Показать выбор модели (Dev)" };
const Comfy_DuplicateWorkflow = { "label": "Дублировать текущий рабочий процесс" };
const Comfy_ExportWorkflow = { "label": "Экспорт рабочего процесса" };
const Comfy_ExportWorkflowAPI = { "label": "Экспорт рабочего процесса (формат API)" };
const Comfy_Graph_ConvertToSubgraph = { "label": "Преобразовать выделенное в подграф" };
const Comfy_Graph_EditSubgraphWidgets = { "label": "Редактировать виджеты подграфов" };
const Comfy_Graph_ExitSubgraph = { "label": "Выйти из подграфа" };
const Comfy_Graph_FitGroupToContents = { "label": "Подогнать группу к содержимому" };
const Comfy_Graph_GroupSelectedNodes = { "label": "Группировать выбранные ноды" };
const Comfy_Graph_ToggleWidgetPromotion = { "label": "Переключить продвижение наведенного виджета" };
const Comfy_Graph_UnpackSubgraph = { "label": "Распаковать выбранный подграф" };
const Comfy_GroupNode_ConvertSelectedNodesToGroupNode = { "label": "Преобразовать выбранные ноды в групповую ноду" };
const Comfy_GroupNode_ManageGroupNodes = { "label": "Управление групповыми нодами" };
const Comfy_GroupNode_UngroupSelectedGroupNodes = { "label": "Разгруппировать выбранные групповые ноды" };
const Comfy_Help_AboutComfyUI = { "label": "Открыть «О ComfyUI»" };
const Comfy_Help_OpenComfyOrgDiscord = { "label": "Открыть Comfy-Org Discord" };
const Comfy_Help_OpenComfyUIDocs = { "label": "Открыть документацию ComfyUI" };
const Comfy_Help_OpenComfyUIForum = { "label": "Открыть форум Comfy-Org" };
const Comfy_Help_OpenComfyUIIssues = { "label": "Открыть ComfyUI  Issues" };
const Comfy_Interrupt = { "label": "Прервать" };
const Comfy_LoadDefaultWorkflow = { "label": "Загрузить стандартный рабочий процесс" };
const Comfy_Manager_CustomNodesManager_ShowCustomNodesMenu = { "label": "Пользовательские узлы (Бета)" };
const Comfy_Manager_CustomNodesManager_ShowLegacyCustomNodesMenu = { "label": "Пользовательские узлы (устаревшие)" };
const Comfy_Manager_ShowLegacyManagerMenu = { "label": "Меню менеджера (устаревшее)" };
const Comfy_Manager_ShowMissingPacks = { "label": "Установить отсутствующие" };
const Comfy_Manager_ShowUpdateAvailablePacks = { "label": "Проверить наличие обновлений" };
const Comfy_Manager_ToggleManagerProgressDialog = { "label": "Переключить диалоговое окно прогресса" };
const Comfy_MaskEditor_BrushSize_Decrease = { "label": "Уменьшить размер кисти в MaskEditor" };
const Comfy_MaskEditor_BrushSize_Increase = { "label": "Увеличить размер кисти в MaskEditor" };
const Comfy_MaskEditor_OpenMaskEditor = { "label": "Открыть редактор масок для выбранной ноды" };
const Comfy_Memory_UnloadModels = { "label": "Выгрузить модели" };
const Comfy_Memory_UnloadModelsAndExecutionCache = { "label": "Выгрузить модели и кэш выполнения" };
const Comfy_NewBlankWorkflow = { "label": "Новый пустой рабочий процесс" };
const Comfy_OpenClipspace = { "label": "Клипспейс" };
const Comfy_OpenManagerDialog = { "label": "Менеджер" };
const Comfy_OpenWorkflow = { "label": "Открыть рабочий процесс" };
const Comfy_PublishSubgraph = { "label": "Опубликовать подграф" };
const Comfy_QueuePrompt = { "label": "Очередь запросов" };
const Comfy_QueuePromptFront = { "label": "Очередь запросов (передняя)" };
const Comfy_QueueSelectedOutputNodes = { "label": "Добавить выбранные выходные узлы в очередь" };
const Comfy_Redo = { "label": "Повторить" };
const Comfy_RefreshNodeDefinitions = { "label": "Обновить определения нод" };
const Comfy_SaveWorkflow = { "label": "Сохранить рабочий процесс" };
const Comfy_SaveWorkflowAs = { "label": "Сохранить рабочий процесс как" };
const Comfy_ShowSettingsDialog = { "label": "Показать диалог настроек" };
const Comfy_ToggleAssetAPI = { "label": "Экспериментально: Включить AssetAPI" };
const Comfy_ToggleCanvasInfo = { "label": "Производительность холста" };
const Comfy_ToggleHelpCenter = { "label": "Центр поддержки" };
const Comfy_ToggleTheme = { "label": "Переключить тему (Тёмная/Светлая)" };
const Comfy_Undo = { "label": "Отменить" };
const Comfy_User_OpenSignInDialog = { "label": "Открыть окно входа" };
const Comfy_User_SignOut = { "label": "Выйти" };
const Experimental_ToggleVueNodes = { "label": "Экспериментально: Включить Vue узлы" };
const Workspace_CloseWorkflow = { "label": "Закрыть текущий рабочий процесс" };
const Workspace_NextOpenedWorkflow = { "label": "Следующий открытый рабочий процесс" };
const Workspace_PreviousOpenedWorkflow = { "label": "Предыдущий открытый рабочий процесс" };
const Workspace_SearchBox_Toggle = { "label": "Переключить поисковое окно" };
const Workspace_ToggleBottomPanel = { "label": "Переключить нижнюю панель" };
const Workspace_ToggleBottomPanel_Shortcuts = { "label": "Показать диалог клавиш" };
const Workspace_ToggleFocusMode = { "label": "Переключить режим фокуса" };
const Workspace_ToggleSidebarTab_assets = { "label": "Переключить боковую панель ресурсов", "tooltip": "Ресурсы" };
const Workspace_ToggleSidebarTab_workflows = { "label": "Переключить боковую панель рабочих процессов", "tooltip": "Рабочие процессы" };
const commands = {
  Comfy_3DViewer_Open3DViewer,
  Comfy_BrowseModelAssets,
  Comfy_BrowseTemplates,
  Comfy_Canvas_DeleteSelectedItems,
  Comfy_Canvas_FitView,
  Comfy_Canvas_Lock,
  Comfy_Canvas_MoveSelectedNodes_Down,
  Comfy_Canvas_MoveSelectedNodes_Left,
  Comfy_Canvas_MoveSelectedNodes_Right,
  Comfy_Canvas_MoveSelectedNodes_Up,
  Comfy_Canvas_ResetView,
  Comfy_Canvas_Resize,
  Comfy_Canvas_ToggleLinkVisibility,
  Comfy_Canvas_ToggleLock,
  Comfy_Canvas_ToggleMinimap,
  Comfy_Canvas_ToggleSelectedNodes_Bypass,
  Comfy_Canvas_ToggleSelectedNodes_Collapse,
  Comfy_Canvas_ToggleSelectedNodes_Mute,
  Comfy_Canvas_ToggleSelectedNodes_Pin,
  Comfy_Canvas_ToggleSelected_Pin,
  Comfy_Canvas_Unlock,
  Comfy_Canvas_ZoomIn,
  Comfy_Canvas_ZoomOut,
  Comfy_ClearPendingTasks,
  Comfy_ClearWorkflow,
  Comfy_ContactSupport,
  Comfy_Dev_ShowModelSelector,
  Comfy_DuplicateWorkflow,
  Comfy_ExportWorkflow,
  Comfy_ExportWorkflowAPI,
  Comfy_Graph_ConvertToSubgraph,
  Comfy_Graph_EditSubgraphWidgets,
  Comfy_Graph_ExitSubgraph,
  Comfy_Graph_FitGroupToContents,
  Comfy_Graph_GroupSelectedNodes,
  Comfy_Graph_ToggleWidgetPromotion,
  Comfy_Graph_UnpackSubgraph,
  Comfy_GroupNode_ConvertSelectedNodesToGroupNode,
  Comfy_GroupNode_ManageGroupNodes,
  Comfy_GroupNode_UngroupSelectedGroupNodes,
  Comfy_Help_AboutComfyUI,
  Comfy_Help_OpenComfyOrgDiscord,
  Comfy_Help_OpenComfyUIDocs,
  Comfy_Help_OpenComfyUIForum,
  Comfy_Help_OpenComfyUIIssues,
  Comfy_Interrupt,
  Comfy_LoadDefaultWorkflow,
  Comfy_Manager_CustomNodesManager_ShowCustomNodesMenu,
  Comfy_Manager_CustomNodesManager_ShowLegacyCustomNodesMenu,
  Comfy_Manager_ShowLegacyManagerMenu,
  Comfy_Manager_ShowMissingPacks,
  Comfy_Manager_ShowUpdateAvailablePacks,
  Comfy_Manager_ToggleManagerProgressDialog,
  Comfy_MaskEditor_BrushSize_Decrease,
  Comfy_MaskEditor_BrushSize_Increase,
  Comfy_MaskEditor_OpenMaskEditor,
  Comfy_Memory_UnloadModels,
  Comfy_Memory_UnloadModelsAndExecutionCache,
  Comfy_NewBlankWorkflow,
  Comfy_OpenClipspace,
  Comfy_OpenManagerDialog,
  Comfy_OpenWorkflow,
  Comfy_PublishSubgraph,
  Comfy_QueuePrompt,
  Comfy_QueuePromptFront,
  Comfy_QueueSelectedOutputNodes,
  Comfy_Redo,
  Comfy_RefreshNodeDefinitions,
  Comfy_SaveWorkflow,
  Comfy_SaveWorkflowAs,
  Comfy_ShowSettingsDialog,
  Comfy_ToggleAssetAPI,
  Comfy_ToggleCanvasInfo,
  Comfy_ToggleHelpCenter,
  Comfy_ToggleTheme,
  Comfy_Undo,
  Comfy_User_OpenSignInDialog,
  Comfy_User_SignOut,
  Experimental_ToggleVueNodes,
  Workspace_CloseWorkflow,
  Workspace_NextOpenedWorkflow,
  Workspace_PreviousOpenedWorkflow,
  Workspace_SearchBox_Toggle,
  Workspace_ToggleBottomPanel,
  "Workspace_ToggleBottomPanelTab_command-terminal": { "label": "Переключить нижнюю панель терминала" },
  "Workspace_ToggleBottomPanelTab_logs-terminal": { "label": "Переключить нижнюю панель логов" },
  "Workspace_ToggleBottomPanelTab_shortcuts-essentials": { "label": "Показать/скрыть основную нижнюю панель" },
  "Workspace_ToggleBottomPanelTab_shortcuts-view-controls": { "label": "Показать/скрыть нижнюю панель управления просмотром" },
  Workspace_ToggleBottomPanel_Shortcuts,
  Workspace_ToggleFocusMode,
  Workspace_ToggleSidebarTab_assets,
  "Workspace_ToggleSidebarTab_model-library": { "label": "Переключить боковую панель библиотеки моделей", "tooltip": "Библиотека моделей" },
  "Workspace_ToggleSidebarTab_node-library": { "label": "Переключить боковую панель библиотеки нод", "tooltip": "Библиотека нод" },
  Workspace_ToggleSidebarTab_workflows
};
export {
  Comfy_3DViewer_Open3DViewer,
  Comfy_BrowseModelAssets,
  Comfy_BrowseTemplates,
  Comfy_Canvas_DeleteSelectedItems,
  Comfy_Canvas_FitView,
  Comfy_Canvas_Lock,
  Comfy_Canvas_MoveSelectedNodes_Down,
  Comfy_Canvas_MoveSelectedNodes_Left,
  Comfy_Canvas_MoveSelectedNodes_Right,
  Comfy_Canvas_MoveSelectedNodes_Up,
  Comfy_Canvas_ResetView,
  Comfy_Canvas_Resize,
  Comfy_Canvas_ToggleLinkVisibility,
  Comfy_Canvas_ToggleLock,
  Comfy_Canvas_ToggleMinimap,
  Comfy_Canvas_ToggleSelectedNodes_Bypass,
  Comfy_Canvas_ToggleSelectedNodes_Collapse,
  Comfy_Canvas_ToggleSelectedNodes_Mute,
  Comfy_Canvas_ToggleSelectedNodes_Pin,
  Comfy_Canvas_ToggleSelected_Pin,
  Comfy_Canvas_Unlock,
  Comfy_Canvas_ZoomIn,
  Comfy_Canvas_ZoomOut,
  Comfy_ClearPendingTasks,
  Comfy_ClearWorkflow,
  Comfy_ContactSupport,
  Comfy_Dev_ShowModelSelector,
  Comfy_DuplicateWorkflow,
  Comfy_ExportWorkflow,
  Comfy_ExportWorkflowAPI,
  Comfy_Graph_ConvertToSubgraph,
  Comfy_Graph_EditSubgraphWidgets,
  Comfy_Graph_ExitSubgraph,
  Comfy_Graph_FitGroupToContents,
  Comfy_Graph_GroupSelectedNodes,
  Comfy_Graph_ToggleWidgetPromotion,
  Comfy_Graph_UnpackSubgraph,
  Comfy_GroupNode_ConvertSelectedNodesToGroupNode,
  Comfy_GroupNode_ManageGroupNodes,
  Comfy_GroupNode_UngroupSelectedGroupNodes,
  Comfy_Help_AboutComfyUI,
  Comfy_Help_OpenComfyOrgDiscord,
  Comfy_Help_OpenComfyUIDocs,
  Comfy_Help_OpenComfyUIForum,
  Comfy_Help_OpenComfyUIIssues,
  Comfy_Interrupt,
  Comfy_LoadDefaultWorkflow,
  Comfy_Manager_CustomNodesManager_ShowCustomNodesMenu,
  Comfy_Manager_CustomNodesManager_ShowLegacyCustomNodesMenu,
  Comfy_Manager_ShowLegacyManagerMenu,
  Comfy_Manager_ShowMissingPacks,
  Comfy_Manager_ShowUpdateAvailablePacks,
  Comfy_Manager_ToggleManagerProgressDialog,
  Comfy_MaskEditor_BrushSize_Decrease,
  Comfy_MaskEditor_BrushSize_Increase,
  Comfy_MaskEditor_OpenMaskEditor,
  Comfy_Memory_UnloadModels,
  Comfy_Memory_UnloadModelsAndExecutionCache,
  Comfy_NewBlankWorkflow,
  Comfy_OpenClipspace,
  Comfy_OpenManagerDialog,
  Comfy_OpenWorkflow,
  Comfy_PublishSubgraph,
  Comfy_QueuePrompt,
  Comfy_QueuePromptFront,
  Comfy_QueueSelectedOutputNodes,
  Comfy_Redo,
  Comfy_RefreshNodeDefinitions,
  Comfy_SaveWorkflow,
  Comfy_SaveWorkflowAs,
  Comfy_ShowSettingsDialog,
  Comfy_ToggleAssetAPI,
  Comfy_ToggleCanvasInfo,
  Comfy_ToggleHelpCenter,
  Comfy_ToggleTheme,
  Comfy_Undo,
  Comfy_User_OpenSignInDialog,
  Comfy_User_SignOut,
  Experimental_ToggleVueNodes,
  Workspace_CloseWorkflow,
  Workspace_NextOpenedWorkflow,
  Workspace_PreviousOpenedWorkflow,
  Workspace_SearchBox_Toggle,
  Workspace_ToggleBottomPanel,
  Workspace_ToggleBottomPanel_Shortcuts,
  Workspace_ToggleFocusMode,
  Workspace_ToggleSidebarTab_assets,
  Workspace_ToggleSidebarTab_workflows,
  commands as default
};
//# sourceMappingURL=commands-DalfIW5f.js.map
