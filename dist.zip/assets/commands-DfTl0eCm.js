const Comfy_3DViewer_Open3DViewer = { "label": "선택한 노드에 대해 3D 뷰어(베타) 열기" };
const Comfy_BrowseModelAssets = { "label": "실험적: 모델 에셋 탐색" };
const Comfy_BrowseTemplates = { "label": "템플릿 탐색" };
const Comfy_Canvas_DeleteSelectedItems = { "label": "선택한 항목 삭제" };
const Comfy_Canvas_FitView = { "label": "선택한 노드에 뷰 맞추기" };
const Comfy_Canvas_Lock = { "label": "캔버스 잠금" };
const Comfy_Canvas_MoveSelectedNodes_Down = { "label": "선택한 노드 아래로 이동" };
const Comfy_Canvas_MoveSelectedNodes_Left = { "label": "선택한 노드 왼쪽으로 이동" };
const Comfy_Canvas_MoveSelectedNodes_Right = { "label": "선택한 노드 오른쪽으로 이동" };
const Comfy_Canvas_MoveSelectedNodes_Up = { "label": "선택한 노드 위로 이동" };
const Comfy_Canvas_ResetView = { "label": "뷰 재설정" };
const Comfy_Canvas_Resize = { "label": "선택된 노드 크기 조정" };
const Comfy_Canvas_ToggleLinkVisibility = { "label": "캔버스 링크 가시성 토글" };
const Comfy_Canvas_ToggleLock = { "label": "캔버스 잠금 토글" };
const Comfy_Canvas_ToggleMinimap = { "label": "캔버스 미니맵 전환" };
const Comfy_Canvas_ToggleSelectedNodes_Bypass = { "label": "선택한 노드 우회/우회 해제" };
const Comfy_Canvas_ToggleSelectedNodes_Collapse = { "label": "선택한 노드 축소/확장" };
const Comfy_Canvas_ToggleSelectedNodes_Mute = { "label": "선택한 노드 음소거/음소거 해제" };
const Comfy_Canvas_ToggleSelectedNodes_Pin = { "label": "선택한 노드 고정/고정 해제" };
const Comfy_Canvas_ToggleSelected_Pin = { "label": "선택한 항목 고정/고정 해제" };
const Comfy_Canvas_Unlock = { "label": "캔버스 잠금 해제" };
const Comfy_Canvas_ZoomIn = { "label": "확대" };
const Comfy_Canvas_ZoomOut = { "label": "축소" };
const Comfy_ClearPendingTasks = { "label": "보류 중인 작업 지우기" };
const Comfy_ClearWorkflow = { "label": "워크플로 내용 지우기" };
const Comfy_ContactSupport = { "label": "지원팀에 문의하기" };
const Comfy_Dev_ShowModelSelector = { "label": "모델 선택기 표시 (개발자용)" };
const Comfy_DuplicateWorkflow = { "label": "현재 워크플로 복제" };
const Comfy_ExportWorkflow = { "label": "워크플로 내보내기" };
const Comfy_ExportWorkflowAPI = { "label": "워크플로 내보내기 (API 형식)" };
const Comfy_Graph_ConvertToSubgraph = { "label": "선택 영역을 서브그래프로 변환" };
const Comfy_Graph_EditSubgraphWidgets = { "label": "서브그래프 위젯 편집" };
const Comfy_Graph_ExitSubgraph = { "label": "서브그래프 나가기" };
const Comfy_Graph_FitGroupToContents = { "label": "그룹을 내용에 맞게 맞추기" };
const Comfy_Graph_GroupSelectedNodes = { "label": "선택한 노드 그룹화" };
const Comfy_Graph_ToggleWidgetPromotion = { "label": "호버링된 위젯 프로모션 전환" };
const Comfy_Graph_UnpackSubgraph = { "label": "선택한 서브그래프 묶음 풀기" };
const Comfy_GroupNode_ConvertSelectedNodesToGroupNode = { "label": "선택한 노드를 그룹 노드로 변환" };
const Comfy_GroupNode_ManageGroupNodes = { "label": "그룹 노드 관리" };
const Comfy_GroupNode_UngroupSelectedGroupNodes = { "label": "선택한 그룹 노드 분리" };
const Comfy_Help_AboutComfyUI = { "label": "ComfyUI 정보 열기" };
const Comfy_Help_OpenComfyOrgDiscord = { "label": "Comfy-Org 디스코드 열기" };
const Comfy_Help_OpenComfyUIDocs = { "label": "ComfyUI 문서 열기" };
const Comfy_Help_OpenComfyUIForum = { "label": "Comfy-Org 포럼 열기" };
const Comfy_Help_OpenComfyUIIssues = { "label": "ComfyUI 문제 열기" };
const Comfy_Interrupt = { "label": "중단" };
const Comfy_LoadDefaultWorkflow = { "label": "기본 워크플로 로드" };
const Comfy_Manager_CustomNodesManager_ShowCustomNodesMenu = { "label": "커스텀 노드 (베타)" };
const Comfy_Manager_CustomNodesManager_ShowLegacyCustomNodesMenu = { "label": "커스텀 노드 (구버전)" };
const Comfy_Manager_ShowLegacyManagerMenu = { "label": "매니저 메뉴 (구버전)" };
const Comfy_Manager_ShowMissingPacks = { "label": "누락된 팩 설치" };
const Comfy_Manager_ShowUpdateAvailablePacks = { "label": "업데이트 확인" };
const Comfy_Manager_ToggleManagerProgressDialog = { "label": "진행 상황 대화 상자 전환" };
const Comfy_MaskEditor_BrushSize_Decrease = { "label": "마스크 편집기에서 브러시 크기 줄이기" };
const Comfy_MaskEditor_BrushSize_Increase = { "label": "마스크 편집기에서 브러시 크기 늘리기" };
const Comfy_MaskEditor_OpenMaskEditor = { "label": "선택한 노드 마스크 편집기 열기" };
const Comfy_Memory_UnloadModels = { "label": "모델 언로드" };
const Comfy_Memory_UnloadModelsAndExecutionCache = { "label": "모델 및 실행 캐시 언로드" };
const Comfy_NewBlankWorkflow = { "label": "새로운 빈 워크플로" };
const Comfy_OpenClipspace = { "label": "클립스페이스" };
const Comfy_OpenManagerDialog = { "label": "매니저" };
const Comfy_OpenWorkflow = { "label": "워크플로 열기" };
const Comfy_PublishSubgraph = { "label": "서브그래프 게시" };
const Comfy_QueuePrompt = { "label": "실행 큐에 프롬프트 추가" };
const Comfy_QueuePromptFront = { "label": "실행 큐 맨 앞에 프롬프트 추가" };
const Comfy_QueueSelectedOutputNodes = { "label": "선택한 출력 노드 대기열에 추가" };
const Comfy_Redo = { "label": "다시 실행" };
const Comfy_RefreshNodeDefinitions = { "label": "노드 정의 새로 고침" };
const Comfy_SaveWorkflow = { "label": "워크플로 저장" };
const Comfy_SaveWorkflowAs = { "label": "다른 이름으로 워크플로 저장" };
const Comfy_ShowSettingsDialog = { "label": "설정 대화상자 보기" };
const Comfy_ToggleAssetAPI = { "label": "실험적: AssetAPI 활성화" };
const Comfy_ToggleCanvasInfo = { "label": "캔버스 성능" };
const Comfy_ToggleHelpCenter = { "label": "도움말 센터" };
const Comfy_ToggleTheme = { "label": "밝기 테마 전환 (어두운/밝은)" };
const Comfy_Undo = { "label": "실행 취소" };
const Comfy_User_OpenSignInDialog = { "label": "로그인 대화상자 열기" };
const Comfy_User_SignOut = { "label": "로그아웃" };
const Experimental_ToggleVueNodes = { "label": "실험적: Vue 노드 활성화" };
const Workspace_CloseWorkflow = { "label": "현재 워크플로 닫기" };
const Workspace_NextOpenedWorkflow = { "label": "다음 열린 워크플로" };
const Workspace_PreviousOpenedWorkflow = { "label": "이전 열린 워크플로" };
const Workspace_SearchBox_Toggle = { "label": "검색 상자 토글" };
const Workspace_ToggleBottomPanel = { "label": "하단 패널 토글" };
const Workspace_ToggleBottomPanel_Shortcuts = { "label": "키 바인딩 대화상자 표시" };
const Workspace_ToggleFocusMode = { "label": "포커스 모드 토글" };
const Workspace_ToggleSidebarTab_assets = { "label": "에셋 사이드바 전환", "tooltip": "에셋" };
const Workspace_ToggleSidebarTab_workflows = { "label": "워크플로 사이드바 토글", "tooltip": "워크플로" };
const commands = {
  Comfy_3DViewer_Open3DViewer,
  Comfy_BrowseModelAssets,
  Comfy_BrowseTemplates,
  Comfy_Canvas_DeleteSelectedItems,
  Comfy_Canvas_FitView,
  Comfy_Canvas_Lock,
  Comfy_Canvas_MoveSelectedNodes_Down,
  Comfy_Canvas_MoveSelectedNodes_Left,
  Comfy_Canvas_MoveSelectedNodes_Right,
  Comfy_Canvas_MoveSelectedNodes_Up,
  Comfy_Canvas_ResetView,
  Comfy_Canvas_Resize,
  Comfy_Canvas_ToggleLinkVisibility,
  Comfy_Canvas_ToggleLock,
  Comfy_Canvas_ToggleMinimap,
  Comfy_Canvas_ToggleSelectedNodes_Bypass,
  Comfy_Canvas_ToggleSelectedNodes_Collapse,
  Comfy_Canvas_ToggleSelectedNodes_Mute,
  Comfy_Canvas_ToggleSelectedNodes_Pin,
  Comfy_Canvas_ToggleSelected_Pin,
  Comfy_Canvas_Unlock,
  Comfy_Canvas_ZoomIn,
  Comfy_Canvas_ZoomOut,
  Comfy_ClearPendingTasks,
  Comfy_ClearWorkflow,
  Comfy_ContactSupport,
  Comfy_Dev_ShowModelSelector,
  Comfy_DuplicateWorkflow,
  Comfy_ExportWorkflow,
  Comfy_ExportWorkflowAPI,
  Comfy_Graph_ConvertToSubgraph,
  Comfy_Graph_EditSubgraphWidgets,
  Comfy_Graph_ExitSubgraph,
  Comfy_Graph_FitGroupToContents,
  Comfy_Graph_GroupSelectedNodes,
  Comfy_Graph_ToggleWidgetPromotion,
  Comfy_Graph_UnpackSubgraph,
  Comfy_GroupNode_ConvertSelectedNodesToGroupNode,
  Comfy_GroupNode_ManageGroupNodes,
  Comfy_GroupNode_UngroupSelectedGroupNodes,
  Comfy_Help_AboutComfyUI,
  Comfy_Help_OpenComfyOrgDiscord,
  Comfy_Help_OpenComfyUIDocs,
  Comfy_Help_OpenComfyUIForum,
  Comfy_Help_OpenComfyUIIssues,
  Comfy_Interrupt,
  Comfy_LoadDefaultWorkflow,
  Comfy_Manager_CustomNodesManager_ShowCustomNodesMenu,
  Comfy_Manager_CustomNodesManager_ShowLegacyCustomNodesMenu,
  Comfy_Manager_ShowLegacyManagerMenu,
  Comfy_Manager_ShowMissingPacks,
  Comfy_Manager_ShowUpdateAvailablePacks,
  Comfy_Manager_ToggleManagerProgressDialog,
  Comfy_MaskEditor_BrushSize_Decrease,
  Comfy_MaskEditor_BrushSize_Increase,
  Comfy_MaskEditor_OpenMaskEditor,
  Comfy_Memory_UnloadModels,
  Comfy_Memory_UnloadModelsAndExecutionCache,
  Comfy_NewBlankWorkflow,
  Comfy_OpenClipspace,
  Comfy_OpenManagerDialog,
  Comfy_OpenWorkflow,
  Comfy_PublishSubgraph,
  Comfy_QueuePrompt,
  Comfy_QueuePromptFront,
  Comfy_QueueSelectedOutputNodes,
  Comfy_Redo,
  Comfy_RefreshNodeDefinitions,
  Comfy_SaveWorkflow,
  Comfy_SaveWorkflowAs,
  Comfy_ShowSettingsDialog,
  Comfy_ToggleAssetAPI,
  Comfy_ToggleCanvasInfo,
  Comfy_ToggleHelpCenter,
  Comfy_ToggleTheme,
  Comfy_Undo,
  Comfy_User_OpenSignInDialog,
  Comfy_User_SignOut,
  Experimental_ToggleVueNodes,
  Workspace_CloseWorkflow,
  Workspace_NextOpenedWorkflow,
  Workspace_PreviousOpenedWorkflow,
  Workspace_SearchBox_Toggle,
  Workspace_ToggleBottomPanel,
  "Workspace_ToggleBottomPanelTab_command-terminal": { "label": "터미널 하단 패널 토글" },
  "Workspace_ToggleBottomPanelTab_logs-terminal": { "label": "로그 하단 패널 토글" },
  "Workspace_ToggleBottomPanelTab_shortcuts-essentials": { "label": "필수 하단 패널 전환" },
  "Workspace_ToggleBottomPanelTab_shortcuts-view-controls": { "label": "뷰 컨트롤 하단 패널 전환" },
  Workspace_ToggleBottomPanel_Shortcuts,
  Workspace_ToggleFocusMode,
  Workspace_ToggleSidebarTab_assets,
  "Workspace_ToggleSidebarTab_model-library": { "label": "모델 라이브러리 사이드바 토글", "tooltip": "모델 라이브러리" },
  "Workspace_ToggleSidebarTab_node-library": { "label": "노드 라이브러리 사이드바 토글", "tooltip": "노드 라이브러리" },
  Workspace_ToggleSidebarTab_workflows
};
export {
  Comfy_3DViewer_Open3DViewer,
  Comfy_BrowseModelAssets,
  Comfy_BrowseTemplates,
  Comfy_Canvas_DeleteSelectedItems,
  Comfy_Canvas_FitView,
  Comfy_Canvas_Lock,
  Comfy_Canvas_MoveSelectedNodes_Down,
  Comfy_Canvas_MoveSelectedNodes_Left,
  Comfy_Canvas_MoveSelectedNodes_Right,
  Comfy_Canvas_MoveSelectedNodes_Up,
  Comfy_Canvas_ResetView,
  Comfy_Canvas_Resize,
  Comfy_Canvas_ToggleLinkVisibility,
  Comfy_Canvas_ToggleLock,
  Comfy_Canvas_ToggleMinimap,
  Comfy_Canvas_ToggleSelectedNodes_Bypass,
  Comfy_Canvas_ToggleSelectedNodes_Collapse,
  Comfy_Canvas_ToggleSelectedNodes_Mute,
  Comfy_Canvas_ToggleSelectedNodes_Pin,
  Comfy_Canvas_ToggleSelected_Pin,
  Comfy_Canvas_Unlock,
  Comfy_Canvas_ZoomIn,
  Comfy_Canvas_ZoomOut,
  Comfy_ClearPendingTasks,
  Comfy_ClearWorkflow,
  Comfy_ContactSupport,
  Comfy_Dev_ShowModelSelector,
  Comfy_DuplicateWorkflow,
  Comfy_ExportWorkflow,
  Comfy_ExportWorkflowAPI,
  Comfy_Graph_ConvertToSubgraph,
  Comfy_Graph_EditSubgraphWidgets,
  Comfy_Graph_ExitSubgraph,
  Comfy_Graph_FitGroupToContents,
  Comfy_Graph_GroupSelectedNodes,
  Comfy_Graph_ToggleWidgetPromotion,
  Comfy_Graph_UnpackSubgraph,
  Comfy_GroupNode_ConvertSelectedNodesToGroupNode,
  Comfy_GroupNode_ManageGroupNodes,
  Comfy_GroupNode_UngroupSelectedGroupNodes,
  Comfy_Help_AboutComfyUI,
  Comfy_Help_OpenComfyOrgDiscord,
  Comfy_Help_OpenComfyUIDocs,
  Comfy_Help_OpenComfyUIForum,
  Comfy_Help_OpenComfyUIIssues,
  Comfy_Interrupt,
  Comfy_LoadDefaultWorkflow,
  Comfy_Manager_CustomNodesManager_ShowCustomNodesMenu,
  Comfy_Manager_CustomNodesManager_ShowLegacyCustomNodesMenu,
  Comfy_Manager_ShowLegacyManagerMenu,
  Comfy_Manager_ShowMissingPacks,
  Comfy_Manager_ShowUpdateAvailablePacks,
  Comfy_Manager_ToggleManagerProgressDialog,
  Comfy_MaskEditor_BrushSize_Decrease,
  Comfy_MaskEditor_BrushSize_Increase,
  Comfy_MaskEditor_OpenMaskEditor,
  Comfy_Memory_UnloadModels,
  Comfy_Memory_UnloadModelsAndExecutionCache,
  Comfy_NewBlankWorkflow,
  Comfy_OpenClipspace,
  Comfy_OpenManagerDialog,
  Comfy_OpenWorkflow,
  Comfy_PublishSubgraph,
  Comfy_QueuePrompt,
  Comfy_QueuePromptFront,
  Comfy_QueueSelectedOutputNodes,
  Comfy_Redo,
  Comfy_RefreshNodeDefinitions,
  Comfy_SaveWorkflow,
  Comfy_SaveWorkflowAs,
  Comfy_ShowSettingsDialog,
  Comfy_ToggleAssetAPI,
  Comfy_ToggleCanvasInfo,
  Comfy_ToggleHelpCenter,
  Comfy_ToggleTheme,
  Comfy_Undo,
  Comfy_User_OpenSignInDialog,
  Comfy_User_SignOut,
  Experimental_ToggleVueNodes,
  Workspace_CloseWorkflow,
  Workspace_NextOpenedWorkflow,
  Workspace_PreviousOpenedWorkflow,
  Workspace_SearchBox_Toggle,
  Workspace_ToggleBottomPanel,
  Workspace_ToggleBottomPanel_Shortcuts,
  Workspace_ToggleFocusMode,
  Workspace_ToggleSidebarTab_assets,
  Workspace_ToggleSidebarTab_workflows,
  commands as default
};
//# sourceMappingURL=commands-DfTl0eCm.js.map
