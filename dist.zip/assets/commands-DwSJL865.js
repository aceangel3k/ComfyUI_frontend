const Comfy_3DViewer_Open3DViewer = { "label": "Seçili Düğüm için 3D Görüntüleyiciyi (Beta) Aç" };
const Comfy_BrowseModelAssets = { "label": "Deneysel: Model Varlıklarını Gözat" };
const Comfy_BrowseTemplates = { "label": "Şablonlara Gözat" };
const Comfy_Canvas_DeleteSelectedItems = { "label": "Seçili Öğeleri Sil" };
const Comfy_Canvas_FitView = { "label": "Görünümü seçili düğümlere sığdır" };
const Comfy_Canvas_Lock = { "label": "Tuvali Kilitle" };
const Comfy_Canvas_MoveSelectedNodes_Down = { "label": "Seçili Düğümleri Aşağı Taşı" };
const Comfy_Canvas_MoveSelectedNodes_Left = { "label": "Seçili Düğümleri Sola Taşı" };
const Comfy_Canvas_MoveSelectedNodes_Right = { "label": "Seçili Düğümleri Sağa Taşı" };
const Comfy_Canvas_MoveSelectedNodes_Up = { "label": "Seçili Düğümleri Yukarı Taşı" };
const Comfy_Canvas_ResetView = { "label": "Görünümü Sıfırla" };
const Comfy_Canvas_Resize = { "label": "Seçili Düğümleri Yeniden Boyutlandır" };
const Comfy_Canvas_ToggleLinkVisibility = { "label": "Tuval Bağlantı Görünürlüğünü Aç/Kapat" };
const Comfy_Canvas_ToggleLock = { "label": "Tuval Kilidini Aç/Kapat" };
const Comfy_Canvas_ToggleMinimap = { "label": "Mini Haritayı Aç/Kapat" };
const Comfy_Canvas_ToggleSelectedNodes_Bypass = { "label": "Seçili Düğümleri Atla/Geri Al" };
const Comfy_Canvas_ToggleSelectedNodes_Collapse = { "label": "Seçili Düğümleri Daralt/Genişlet" };
const Comfy_Canvas_ToggleSelectedNodes_Mute = { "label": "Seçili Düğümleri Sessize Al/Sesi Aç" };
const Comfy_Canvas_ToggleSelectedNodes_Pin = { "label": "Seçili Düğümleri Sabitle/Sabitlemeyi Kaldır" };
const Comfy_Canvas_ToggleSelected_Pin = { "label": "Seçili Öğeleri Sabitle/Sabitlemeyi Kaldır" };
const Comfy_Canvas_Unlock = { "label": "Tuvalin Kilidini Aç" };
const Comfy_Canvas_ZoomIn = { "label": "Yakınlaştır" };
const Comfy_Canvas_ZoomOut = { "label": "Uzaklaştır" };
const Comfy_ClearPendingTasks = { "label": "Bekleyen Görevleri Temizle" };
const Comfy_ClearWorkflow = { "label": "İş Akışını Temizle" };
const Comfy_ContactSupport = { "label": "Destekle İletişime Geç" };
const Comfy_Dev_ShowModelSelector = { "label": "Model Seçiciyi Göster (Geliştirici)" };
const Comfy_DuplicateWorkflow = { "label": "Mevcut İş Akışını Çoğalt" };
const Comfy_ExportWorkflow = { "label": "İş Akışını Dışa Aktar" };
const Comfy_ExportWorkflowAPI = { "label": "İş Akışını Dışa Aktar (API Formatı)" };
const Comfy_Graph_ConvertToSubgraph = { "label": "Seçimi Alt Grafiğe Dönüştür" };
const Comfy_Graph_EditSubgraphWidgets = { "label": "Alt Grafik Bileşenlerini Düzenle" };
const Comfy_Graph_ExitSubgraph = { "label": "Alt Grafikten Çık" };
const Comfy_Graph_FitGroupToContents = { "label": "Grubu İçeriğe Sığdır" };
const Comfy_Graph_GroupSelectedNodes = { "label": "Seçili Düğümleri Gruplandır" };
const Comfy_Graph_ToggleWidgetPromotion = { "label": "Vurgulanan bileşenin önceliğini değiştir" };
const Comfy_Graph_UnpackSubgraph = { "label": "Seçili Alt Grafiği Aç" };
const Comfy_GroupNode_ConvertSelectedNodesToGroupNode = { "label": "Seçili düğümleri grup düğümüne dönüştür" };
const Comfy_GroupNode_ManageGroupNodes = { "label": "Grup düğümlerini yönet" };
const Comfy_GroupNode_UngroupSelectedGroupNodes = { "label": "Seçili grup düğümlerinin grubunu çöz" };
const Comfy_Help_AboutComfyUI = { "label": "ComfyUI Hakkında'yı Aç" };
const Comfy_Help_OpenComfyOrgDiscord = { "label": "Comfy-Org Discord'unu Aç" };
const Comfy_Help_OpenComfyUIDocs = { "label": "ComfyUI Belgelerini Aç" };
const Comfy_Help_OpenComfyUIForum = { "label": "ComfyUI Forumunu Aç" };
const Comfy_Help_OpenComfyUIIssues = { "label": "ComfyUI Sorunlarını Aç" };
const Comfy_Interrupt = { "label": "Kes" };
const Comfy_LoadDefaultWorkflow = { "label": "Varsayılan İş Akışını Yükle" };
const Comfy_Manager_CustomNodesManager_ShowCustomNodesMenu = { "label": "Özel Düğüm Yöneticisi" };
const Comfy_Manager_CustomNodesManager_ShowLegacyCustomNodesMenu = { "label": "Özel Düğümler (Eski)" };
const Comfy_Manager_ShowLegacyManagerMenu = { "label": "Yönetici Menüsü (Eski)" };
const Comfy_Manager_ShowMissingPacks = { "label": "Eksik Özel Düğümleri Yükle" };
const Comfy_Manager_ShowUpdateAvailablePacks = { "label": "Özel Düğüm Güncellemelerini Kontrol Et" };
const Comfy_Manager_ToggleManagerProgressDialog = { "label": "Özel Düğüm Yöneticisi İlerleme Çubuğunu Aç/Kapat" };
const Comfy_MaskEditor_BrushSize_Decrease = { "label": "Maske Düzenleyicide Fırça Boyutunu Azalt" };
const Comfy_MaskEditor_BrushSize_Increase = { "label": "Maske Düzenleyicide Fırça Boyutunu Artır" };
const Comfy_MaskEditor_OpenMaskEditor = { "label": "Seçili Düğüm için Maske Düzenleyiciyi Aç" };
const Comfy_Memory_UnloadModels = { "label": "Modelleri Boşalt" };
const Comfy_Memory_UnloadModelsAndExecutionCache = { "label": "Modelleri ve Yürütme Önbelleğini Boşalt" };
const Comfy_NewBlankWorkflow = { "label": "Yeni Boş İş Akışı" };
const Comfy_OpenClipspace = { "label": "Clipspace" };
const Comfy_OpenManagerDialog = { "label": "Yönetici" };
const Comfy_OpenWorkflow = { "label": "İş Akışını Aç" };
const Comfy_PublishSubgraph = { "label": "Alt Grafiği Yayınla" };
const Comfy_QueuePrompt = { "label": "İstemi Kuyruğa Al" };
const Comfy_QueuePromptFront = { "label": "İstemi Kuyruğa Al (Ön)" };
const Comfy_QueueSelectedOutputNodes = { "label": "Seçili Çıktı Düğümlerini Kuyruğa Al" };
const Comfy_Redo = { "label": "Yinele" };
const Comfy_RefreshNodeDefinitions = { "label": "Düğüm Tanımlarını Yenile" };
const Comfy_SaveWorkflow = { "label": "İş Akışını Kaydet" };
const Comfy_SaveWorkflowAs = { "label": "İş Akışını Farklı Kaydet" };
const Comfy_ShowSettingsDialog = { "label": "Ayarlar İletişim Kutusunu Göster" };
const Comfy_ToggleAssetAPI = { "label": "Deneysel: AssetAPI'yi Etkinleştir" };
const Comfy_ToggleCanvasInfo = { "label": "Tuval Performansı" };
const Comfy_ToggleHelpCenter = { "label": "Yardım Merkezi" };
const Comfy_ToggleTheme = { "label": "Temayı Değiştir (Karanlık/Açık)" };
const Comfy_Undo = { "label": "Geri Al" };
const Comfy_User_OpenSignInDialog = { "label": "Giriş Yapma İletişim Kutusunu Aç" };
const Comfy_User_SignOut = { "label": "Çıkış Yap" };
const Experimental_ToggleVueNodes = { "label": "Deneysel: Vue Düğümlerini Etkinleştir" };
const Workspace_CloseWorkflow = { "label": "Mevcut İş Akışını Kapat" };
const Workspace_NextOpenedWorkflow = { "label": "Sonraki Açılan İş Akışı" };
const Workspace_PreviousOpenedWorkflow = { "label": "Önceki Açılan İş Akışı" };
const Workspace_SearchBox_Toggle = { "label": "Arama Kutusunu Aç/Kapat" };
const Workspace_ToggleBottomPanel = { "label": "Alt Paneli Aç/Kapat" };
const Workspace_ToggleBottomPanel_Shortcuts = { "label": "Tuş Atamaları İletişim Kutusunu Göster" };
const Workspace_ToggleFocusMode = { "label": "Odak Modunu Aç/Kapat" };
const Workspace_ToggleSidebarTab_assets = { "label": "Varlıklar Kenar Çubuğunu Aç/Kapat", "tooltip": "Varlıklar" };
const Workspace_ToggleSidebarTab_workflows = { "label": "İş Akışları Kenar Çubuğunu Aç/Kapat", "tooltip": "İş Akışları" };
const commands = {
  Comfy_3DViewer_Open3DViewer,
  Comfy_BrowseModelAssets,
  Comfy_BrowseTemplates,
  Comfy_Canvas_DeleteSelectedItems,
  Comfy_Canvas_FitView,
  Comfy_Canvas_Lock,
  Comfy_Canvas_MoveSelectedNodes_Down,
  Comfy_Canvas_MoveSelectedNodes_Left,
  Comfy_Canvas_MoveSelectedNodes_Right,
  Comfy_Canvas_MoveSelectedNodes_Up,
  Comfy_Canvas_ResetView,
  Comfy_Canvas_Resize,
  Comfy_Canvas_ToggleLinkVisibility,
  Comfy_Canvas_ToggleLock,
  Comfy_Canvas_ToggleMinimap,
  Comfy_Canvas_ToggleSelectedNodes_Bypass,
  Comfy_Canvas_ToggleSelectedNodes_Collapse,
  Comfy_Canvas_ToggleSelectedNodes_Mute,
  Comfy_Canvas_ToggleSelectedNodes_Pin,
  Comfy_Canvas_ToggleSelected_Pin,
  Comfy_Canvas_Unlock,
  Comfy_Canvas_ZoomIn,
  Comfy_Canvas_ZoomOut,
  Comfy_ClearPendingTasks,
  Comfy_ClearWorkflow,
  Comfy_ContactSupport,
  Comfy_Dev_ShowModelSelector,
  Comfy_DuplicateWorkflow,
  Comfy_ExportWorkflow,
  Comfy_ExportWorkflowAPI,
  Comfy_Graph_ConvertToSubgraph,
  Comfy_Graph_EditSubgraphWidgets,
  Comfy_Graph_ExitSubgraph,
  Comfy_Graph_FitGroupToContents,
  Comfy_Graph_GroupSelectedNodes,
  Comfy_Graph_ToggleWidgetPromotion,
  Comfy_Graph_UnpackSubgraph,
  Comfy_GroupNode_ConvertSelectedNodesToGroupNode,
  Comfy_GroupNode_ManageGroupNodes,
  Comfy_GroupNode_UngroupSelectedGroupNodes,
  Comfy_Help_AboutComfyUI,
  Comfy_Help_OpenComfyOrgDiscord,
  Comfy_Help_OpenComfyUIDocs,
  Comfy_Help_OpenComfyUIForum,
  Comfy_Help_OpenComfyUIIssues,
  Comfy_Interrupt,
  Comfy_LoadDefaultWorkflow,
  Comfy_Manager_CustomNodesManager_ShowCustomNodesMenu,
  Comfy_Manager_CustomNodesManager_ShowLegacyCustomNodesMenu,
  Comfy_Manager_ShowLegacyManagerMenu,
  Comfy_Manager_ShowMissingPacks,
  Comfy_Manager_ShowUpdateAvailablePacks,
  Comfy_Manager_ToggleManagerProgressDialog,
  Comfy_MaskEditor_BrushSize_Decrease,
  Comfy_MaskEditor_BrushSize_Increase,
  Comfy_MaskEditor_OpenMaskEditor,
  Comfy_Memory_UnloadModels,
  Comfy_Memory_UnloadModelsAndExecutionCache,
  Comfy_NewBlankWorkflow,
  Comfy_OpenClipspace,
  Comfy_OpenManagerDialog,
  Comfy_OpenWorkflow,
  Comfy_PublishSubgraph,
  Comfy_QueuePrompt,
  Comfy_QueuePromptFront,
  Comfy_QueueSelectedOutputNodes,
  Comfy_Redo,
  Comfy_RefreshNodeDefinitions,
  Comfy_SaveWorkflow,
  Comfy_SaveWorkflowAs,
  Comfy_ShowSettingsDialog,
  Comfy_ToggleAssetAPI,
  Comfy_ToggleCanvasInfo,
  Comfy_ToggleHelpCenter,
  Comfy_ToggleTheme,
  Comfy_Undo,
  Comfy_User_OpenSignInDialog,
  Comfy_User_SignOut,
  Experimental_ToggleVueNodes,
  Workspace_CloseWorkflow,
  Workspace_NextOpenedWorkflow,
  Workspace_PreviousOpenedWorkflow,
  Workspace_SearchBox_Toggle,
  Workspace_ToggleBottomPanel,
  "Workspace_ToggleBottomPanelTab_command-terminal": { "label": "Terminal Alt Panelini Aç/Kapat" },
  "Workspace_ToggleBottomPanelTab_logs-terminal": { "label": "Kayıtlar Alt Panelini Aç/Kapat" },
  "Workspace_ToggleBottomPanelTab_shortcuts-essentials": { "label": "Temel Alt Paneli Aç/Kapat" },
  "Workspace_ToggleBottomPanelTab_shortcuts-view-controls": { "label": "Görünüm Kontrolleri Alt Panelini Aç/Kapat" },
  Workspace_ToggleBottomPanel_Shortcuts,
  Workspace_ToggleFocusMode,
  Workspace_ToggleSidebarTab_assets,
  "Workspace_ToggleSidebarTab_model-library": { "label": "Model Kütüphanesi Kenar Çubuğunu Aç/Kapat", "tooltip": "Model Kütüphanesi" },
  "Workspace_ToggleSidebarTab_node-library": { "label": "Düğüm Kütüphanesi Kenar Çubuğunu Aç/Kapat", "tooltip": "Düğüm Kütüphanesi" },
  Workspace_ToggleSidebarTab_workflows
};
export {
  Comfy_3DViewer_Open3DViewer,
  Comfy_BrowseModelAssets,
  Comfy_BrowseTemplates,
  Comfy_Canvas_DeleteSelectedItems,
  Comfy_Canvas_FitView,
  Comfy_Canvas_Lock,
  Comfy_Canvas_MoveSelectedNodes_Down,
  Comfy_Canvas_MoveSelectedNodes_Left,
  Comfy_Canvas_MoveSelectedNodes_Right,
  Comfy_Canvas_MoveSelectedNodes_Up,
  Comfy_Canvas_ResetView,
  Comfy_Canvas_Resize,
  Comfy_Canvas_ToggleLinkVisibility,
  Comfy_Canvas_ToggleLock,
  Comfy_Canvas_ToggleMinimap,
  Comfy_Canvas_ToggleSelectedNodes_Bypass,
  Comfy_Canvas_ToggleSelectedNodes_Collapse,
  Comfy_Canvas_ToggleSelectedNodes_Mute,
  Comfy_Canvas_ToggleSelectedNodes_Pin,
  Comfy_Canvas_ToggleSelected_Pin,
  Comfy_Canvas_Unlock,
  Comfy_Canvas_ZoomIn,
  Comfy_Canvas_ZoomOut,
  Comfy_ClearPendingTasks,
  Comfy_ClearWorkflow,
  Comfy_ContactSupport,
  Comfy_Dev_ShowModelSelector,
  Comfy_DuplicateWorkflow,
  Comfy_ExportWorkflow,
  Comfy_ExportWorkflowAPI,
  Comfy_Graph_ConvertToSubgraph,
  Comfy_Graph_EditSubgraphWidgets,
  Comfy_Graph_ExitSubgraph,
  Comfy_Graph_FitGroupToContents,
  Comfy_Graph_GroupSelectedNodes,
  Comfy_Graph_ToggleWidgetPromotion,
  Comfy_Graph_UnpackSubgraph,
  Comfy_GroupNode_ConvertSelectedNodesToGroupNode,
  Comfy_GroupNode_ManageGroupNodes,
  Comfy_GroupNode_UngroupSelectedGroupNodes,
  Comfy_Help_AboutComfyUI,
  Comfy_Help_OpenComfyOrgDiscord,
  Comfy_Help_OpenComfyUIDocs,
  Comfy_Help_OpenComfyUIForum,
  Comfy_Help_OpenComfyUIIssues,
  Comfy_Interrupt,
  Comfy_LoadDefaultWorkflow,
  Comfy_Manager_CustomNodesManager_ShowCustomNodesMenu,
  Comfy_Manager_CustomNodesManager_ShowLegacyCustomNodesMenu,
  Comfy_Manager_ShowLegacyManagerMenu,
  Comfy_Manager_ShowMissingPacks,
  Comfy_Manager_ShowUpdateAvailablePacks,
  Comfy_Manager_ToggleManagerProgressDialog,
  Comfy_MaskEditor_BrushSize_Decrease,
  Comfy_MaskEditor_BrushSize_Increase,
  Comfy_MaskEditor_OpenMaskEditor,
  Comfy_Memory_UnloadModels,
  Comfy_Memory_UnloadModelsAndExecutionCache,
  Comfy_NewBlankWorkflow,
  Comfy_OpenClipspace,
  Comfy_OpenManagerDialog,
  Comfy_OpenWorkflow,
  Comfy_PublishSubgraph,
  Comfy_QueuePrompt,
  Comfy_QueuePromptFront,
  Comfy_QueueSelectedOutputNodes,
  Comfy_Redo,
  Comfy_RefreshNodeDefinitions,
  Comfy_SaveWorkflow,
  Comfy_SaveWorkflowAs,
  Comfy_ShowSettingsDialog,
  Comfy_ToggleAssetAPI,
  Comfy_ToggleCanvasInfo,
  Comfy_ToggleHelpCenter,
  Comfy_ToggleTheme,
  Comfy_Undo,
  Comfy_User_OpenSignInDialog,
  Comfy_User_SignOut,
  Experimental_ToggleVueNodes,
  Workspace_CloseWorkflow,
  Workspace_NextOpenedWorkflow,
  Workspace_PreviousOpenedWorkflow,
  Workspace_SearchBox_Toggle,
  Workspace_ToggleBottomPanel,
  Workspace_ToggleBottomPanel_Shortcuts,
  Workspace_ToggleFocusMode,
  Workspace_ToggleSidebarTab_assets,
  Workspace_ToggleSidebarTab_workflows,
  commands as default
};
//# sourceMappingURL=commands-DwSJL865.js.map
