const Comfy_3DViewer_Open3DViewer = { "label": "为所选节点开启 3D 浏览器（Beta 版）" };
const Comfy_BrowseModelAssets = { "label": "实验性：浏览模型资源" };
const Comfy_BrowseTemplates = { "label": "浏览模板" };
const Comfy_Canvas_DeleteSelectedItems = { "label": "删除选定的项目" };
const Comfy_Canvas_FitView = { "label": "适应视图到选中节点" };
const Comfy_Canvas_Lock = { "label": "锁定画布" };
const Comfy_Canvas_MoveSelectedNodes_Down = { "label": "下移选中的节点" };
const Comfy_Canvas_MoveSelectedNodes_Left = { "label": "向左移动选中节点" };
const Comfy_Canvas_MoveSelectedNodes_Right = { "label": "向右移动选中节点" };
const Comfy_Canvas_MoveSelectedNodes_Up = { "label": "上移选中的节点" };
const Comfy_Canvas_ResetView = { "label": "重置视图" };
const Comfy_Canvas_Resize = { "label": "调整选定节点的大小" };
const Comfy_Canvas_ToggleLinkVisibility = { "label": "切换链接可见性" };
const Comfy_Canvas_ToggleLock = { "label": "锁定视图" };
const Comfy_Canvas_ToggleMinimap = { "label": "画布切换小地图" };
const Comfy_Canvas_ToggleSelectedNodes_Bypass = { "label": "忽略/取消忽略选中节点" };
const Comfy_Canvas_ToggleSelectedNodes_Collapse = { "label": "折叠/展开选中节点" };
const Comfy_Canvas_ToggleSelectedNodes_Mute = { "label": "静音/取消静音选中节点" };
const Comfy_Canvas_ToggleSelectedNodes_Pin = { "label": "固定/取消固定选中节点" };
const Comfy_Canvas_ToggleSelected_Pin = { "label": "固定/取消固定选中项" };
const Comfy_Canvas_Unlock = { "label": "解锁画布" };
const Comfy_Canvas_ZoomIn = { "label": "放大" };
const Comfy_Canvas_ZoomOut = { "label": "缩小" };
const Comfy_ClearPendingTasks = { "label": "清除待处理任务" };
const Comfy_ClearWorkflow = { "label": "清除工作流" };
const Comfy_ContactSupport = { "label": "联系支持" };
const Comfy_Dev_ShowModelSelector = { "label": "显示模型选择器（开发）" };
const Comfy_DuplicateWorkflow = { "label": "复制当前工作流" };
const Comfy_ExportWorkflow = { "label": "导出工作流" };
const Comfy_ExportWorkflowAPI = { "label": "导出工作流（API格式）" };
const Comfy_Graph_ConvertToSubgraph = { "label": "将选区转换为子图" };
const Comfy_Graph_EditSubgraphWidgets = { "label": "编辑子图组件" };
const Comfy_Graph_ExitSubgraph = { "label": "退出子图" };
const Comfy_Graph_FitGroupToContents = { "label": "适应节点框到内容" };
const Comfy_Graph_GroupSelectedNodes = { "label": "添加框到选中节点" };
const Comfy_Graph_ToggleWidgetPromotion = { "label": "切换悬停小部件的推广" };
const Comfy_Graph_UnpackSubgraph = { "label": "解开所选子图" };
const Comfy_GroupNode_ConvertSelectedNodesToGroupNode = { "label": "将选中节点转换为组节点" };
const Comfy_GroupNode_ManageGroupNodes = { "label": "管理组节点" };
const Comfy_GroupNode_UngroupSelectedGroupNodes = { "label": "解散选中组节点" };
const Comfy_Help_AboutComfyUI = { "label": "打开关于ComfyUI" };
const Comfy_Help_OpenComfyOrgDiscord = { "label": "打开Comfy-Org Discord" };
const Comfy_Help_OpenComfyUIDocs = { "label": "打开ComfyUI文档" };
const Comfy_Help_OpenComfyUIForum = { "label": "打开 Comfy-Org 论坛" };
const Comfy_Help_OpenComfyUIIssues = { "label": "打开ComfyUI问题" };
const Comfy_Interrupt = { "label": "中断" };
const Comfy_LoadDefaultWorkflow = { "label": "加载默认工作流" };
const Comfy_Manager_CustomNodesManager_ShowCustomNodesMenu = { "label": "自定义节点（测试版）" };
const Comfy_Manager_CustomNodesManager_ShowLegacyCustomNodesMenu = { "label": "自定义节点（旧版）" };
const Comfy_Manager_ShowLegacyManagerMenu = { "label": "管理员菜单（旧版）" };
const Comfy_Manager_ShowMissingPacks = { "label": "安装缺失的包" };
const Comfy_Manager_ShowUpdateAvailablePacks = { "label": "检查更新" };
const Comfy_Manager_ToggleManagerProgressDialog = { "label": "切换进度对话框" };
const Comfy_MaskEditor_BrushSize_Decrease = { "label": "减小 MaskEditor 中的笔刷大小" };
const Comfy_MaskEditor_BrushSize_Increase = { "label": "增加 MaskEditor 画笔大小" };
const Comfy_MaskEditor_OpenMaskEditor = { "label": "打开选中节点的遮罩编辑器" };
const Comfy_Memory_UnloadModels = { "label": "卸载模型" };
const Comfy_Memory_UnloadModelsAndExecutionCache = { "label": "卸载模型和执行缓存" };
const Comfy_NewBlankWorkflow = { "label": "新建空白工作流" };
const Comfy_OpenClipspace = { "label": "打开剪贴板" };
const Comfy_OpenManagerDialog = { "label": "管理器" };
const Comfy_OpenWorkflow = { "label": "打开工作流" };
const Comfy_PublishSubgraph = { "label": "发布子图" };
const Comfy_QueuePrompt = { "label": "执行提示词" };
const Comfy_QueuePromptFront = { "label": "执行提示词（前端）" };
const Comfy_QueueSelectedOutputNodes = { "label": "队列所选输出节点" };
const Comfy_Redo = { "label": "重做" };
const Comfy_RefreshNodeDefinitions = { "label": "刷新节点定义" };
const Comfy_SaveWorkflow = { "label": "保存工作流" };
const Comfy_SaveWorkflowAs = { "label": "另存工作流" };
const Comfy_ShowSettingsDialog = { "label": "显示设置对话框" };
const Comfy_ToggleAssetAPI = { "label": "实验性：启用 AssetAPI" };
const Comfy_ToggleCanvasInfo = { "label": "画布性能" };
const Comfy_ToggleHelpCenter = { "label": "说明中心" };
const Comfy_ToggleLinear = { "label": "切换线性模式" };
const Comfy_ToggleTheme = { "label": "切换主题" };
const Comfy_Undo = { "label": "撤销" };
const Comfy_User_OpenSignInDialog = { "label": "打开登录对话框" };
const Comfy_User_SignOut = { "label": "退出登录" };
const Experimental_ToggleVueNodes = { "label": "实验性：启用 Vue 节点" };
const Workspace_CloseWorkflow = { "label": "关闭当前工作流" };
const Workspace_NextOpenedWorkflow = { "label": "下一个打开的工作流" };
const Workspace_PreviousOpenedWorkflow = { "label": "上一个打开的工作流" };
const Workspace_SearchBox_Toggle = { "label": "切换搜索框" };
const Workspace_ToggleBottomPanel = { "label": "切换底部面板" };
const Workspace_ToggleBottomPanel_Shortcuts = { "label": "显示快捷键对话框" };
const Workspace_ToggleFocusMode = { "label": "切换焦点模式" };
const Workspace_ToggleSidebarTab_assets = { "label": "切换资产侧边栏", "tooltip": "资产" };
const Workspace_ToggleSidebarTab_workflows = { "label": "切换工作流侧边栏", "tooltip": "工作流" };
const commands = {
  "Comfy-Desktop_CheckForUpdates": { "label": "检查更新" },
  "Comfy-Desktop_Folders_OpenCustomNodesFolder": { "label": "打开自定义节点文件夹" },
  "Comfy-Desktop_Folders_OpenInputsFolder": { "label": "打开输入文件夹" },
  "Comfy-Desktop_Folders_OpenLogsFolder": { "label": "打开日志文件夹" },
  "Comfy-Desktop_Folders_OpenModelConfig": { "label": "打开 extra_model_paths.yaml" },
  "Comfy-Desktop_Folders_OpenModelsFolder": { "label": "打开模型文件夹" },
  "Comfy-Desktop_Folders_OpenOutputsFolder": { "label": "打开输出文件夹" },
  "Comfy-Desktop_OpenDevTools": { "label": "打开开发者工具" },
  "Comfy-Desktop_OpenUserGuide": { "label": "桌面端用户手册" },
  "Comfy-Desktop_Quit": { "label": "退出" },
  "Comfy-Desktop_Reinstall": { "label": "重装" },
  "Comfy-Desktop_Restart": { "label": "重启" },
  Comfy_3DViewer_Open3DViewer,
  Comfy_BrowseModelAssets,
  Comfy_BrowseTemplates,
  Comfy_Canvas_DeleteSelectedItems,
  Comfy_Canvas_FitView,
  Comfy_Canvas_Lock,
  Comfy_Canvas_MoveSelectedNodes_Down,
  Comfy_Canvas_MoveSelectedNodes_Left,
  Comfy_Canvas_MoveSelectedNodes_Right,
  Comfy_Canvas_MoveSelectedNodes_Up,
  Comfy_Canvas_ResetView,
  Comfy_Canvas_Resize,
  Comfy_Canvas_ToggleLinkVisibility,
  Comfy_Canvas_ToggleLock,
  Comfy_Canvas_ToggleMinimap,
  Comfy_Canvas_ToggleSelectedNodes_Bypass,
  Comfy_Canvas_ToggleSelectedNodes_Collapse,
  Comfy_Canvas_ToggleSelectedNodes_Mute,
  Comfy_Canvas_ToggleSelectedNodes_Pin,
  Comfy_Canvas_ToggleSelected_Pin,
  Comfy_Canvas_Unlock,
  Comfy_Canvas_ZoomIn,
  Comfy_Canvas_ZoomOut,
  Comfy_ClearPendingTasks,
  Comfy_ClearWorkflow,
  Comfy_ContactSupport,
  Comfy_Dev_ShowModelSelector,
  Comfy_DuplicateWorkflow,
  Comfy_ExportWorkflow,
  Comfy_ExportWorkflowAPI,
  Comfy_Graph_ConvertToSubgraph,
  Comfy_Graph_EditSubgraphWidgets,
  Comfy_Graph_ExitSubgraph,
  Comfy_Graph_FitGroupToContents,
  Comfy_Graph_GroupSelectedNodes,
  Comfy_Graph_ToggleWidgetPromotion,
  Comfy_Graph_UnpackSubgraph,
  Comfy_GroupNode_ConvertSelectedNodesToGroupNode,
  Comfy_GroupNode_ManageGroupNodes,
  Comfy_GroupNode_UngroupSelectedGroupNodes,
  Comfy_Help_AboutComfyUI,
  Comfy_Help_OpenComfyOrgDiscord,
  Comfy_Help_OpenComfyUIDocs,
  Comfy_Help_OpenComfyUIForum,
  Comfy_Help_OpenComfyUIIssues,
  Comfy_Interrupt,
  Comfy_LoadDefaultWorkflow,
  Comfy_Manager_CustomNodesManager_ShowCustomNodesMenu,
  Comfy_Manager_CustomNodesManager_ShowLegacyCustomNodesMenu,
  Comfy_Manager_ShowLegacyManagerMenu,
  Comfy_Manager_ShowMissingPacks,
  Comfy_Manager_ShowUpdateAvailablePacks,
  Comfy_Manager_ToggleManagerProgressDialog,
  Comfy_MaskEditor_BrushSize_Decrease,
  Comfy_MaskEditor_BrushSize_Increase,
  Comfy_MaskEditor_OpenMaskEditor,
  Comfy_Memory_UnloadModels,
  Comfy_Memory_UnloadModelsAndExecutionCache,
  Comfy_NewBlankWorkflow,
  Comfy_OpenClipspace,
  Comfy_OpenManagerDialog,
  Comfy_OpenWorkflow,
  Comfy_PublishSubgraph,
  Comfy_QueuePrompt,
  Comfy_QueuePromptFront,
  Comfy_QueueSelectedOutputNodes,
  Comfy_Redo,
  Comfy_RefreshNodeDefinitions,
  Comfy_SaveWorkflow,
  Comfy_SaveWorkflowAs,
  Comfy_ShowSettingsDialog,
  Comfy_ToggleAssetAPI,
  Comfy_ToggleCanvasInfo,
  Comfy_ToggleHelpCenter,
  Comfy_ToggleLinear,
  Comfy_ToggleTheme,
  Comfy_Undo,
  Comfy_User_OpenSignInDialog,
  Comfy_User_SignOut,
  Experimental_ToggleVueNodes,
  Workspace_CloseWorkflow,
  Workspace_NextOpenedWorkflow,
  Workspace_PreviousOpenedWorkflow,
  Workspace_SearchBox_Toggle,
  Workspace_ToggleBottomPanel,
  "Workspace_ToggleBottomPanelTab_command-terminal": { "label": "切换终端底部面板" },
  "Workspace_ToggleBottomPanelTab_logs-terminal": { "label": "切换日志底部面板" },
  "Workspace_ToggleBottomPanelTab_shortcuts-essentials": { "label": "切换基本下方面板" },
  "Workspace_ToggleBottomPanelTab_shortcuts-view-controls": { "label": "切换检视控制底部面板" },
  Workspace_ToggleBottomPanel_Shortcuts,
  Workspace_ToggleFocusMode,
  Workspace_ToggleSidebarTab_assets,
  "Workspace_ToggleSidebarTab_model-library": { "label": "切换模型库侧边栏", "tooltip": "模型库" },
  "Workspace_ToggleSidebarTab_node-library": { "label": "切换节点库侧边栏", "tooltip": "节点库" },
  Workspace_ToggleSidebarTab_workflows
};
export {
  Comfy_3DViewer_Open3DViewer,
  Comfy_BrowseModelAssets,
  Comfy_BrowseTemplates,
  Comfy_Canvas_DeleteSelectedItems,
  Comfy_Canvas_FitView,
  Comfy_Canvas_Lock,
  Comfy_Canvas_MoveSelectedNodes_Down,
  Comfy_Canvas_MoveSelectedNodes_Left,
  Comfy_Canvas_MoveSelectedNodes_Right,
  Comfy_Canvas_MoveSelectedNodes_Up,
  Comfy_Canvas_ResetView,
  Comfy_Canvas_Resize,
  Comfy_Canvas_ToggleLinkVisibility,
  Comfy_Canvas_ToggleLock,
  Comfy_Canvas_ToggleMinimap,
  Comfy_Canvas_ToggleSelectedNodes_Bypass,
  Comfy_Canvas_ToggleSelectedNodes_Collapse,
  Comfy_Canvas_ToggleSelectedNodes_Mute,
  Comfy_Canvas_ToggleSelectedNodes_Pin,
  Comfy_Canvas_ToggleSelected_Pin,
  Comfy_Canvas_Unlock,
  Comfy_Canvas_ZoomIn,
  Comfy_Canvas_ZoomOut,
  Comfy_ClearPendingTasks,
  Comfy_ClearWorkflow,
  Comfy_ContactSupport,
  Comfy_Dev_ShowModelSelector,
  Comfy_DuplicateWorkflow,
  Comfy_ExportWorkflow,
  Comfy_ExportWorkflowAPI,
  Comfy_Graph_ConvertToSubgraph,
  Comfy_Graph_EditSubgraphWidgets,
  Comfy_Graph_ExitSubgraph,
  Comfy_Graph_FitGroupToContents,
  Comfy_Graph_GroupSelectedNodes,
  Comfy_Graph_ToggleWidgetPromotion,
  Comfy_Graph_UnpackSubgraph,
  Comfy_GroupNode_ConvertSelectedNodesToGroupNode,
  Comfy_GroupNode_ManageGroupNodes,
  Comfy_GroupNode_UngroupSelectedGroupNodes,
  Comfy_Help_AboutComfyUI,
  Comfy_Help_OpenComfyOrgDiscord,
  Comfy_Help_OpenComfyUIDocs,
  Comfy_Help_OpenComfyUIForum,
  Comfy_Help_OpenComfyUIIssues,
  Comfy_Interrupt,
  Comfy_LoadDefaultWorkflow,
  Comfy_Manager_CustomNodesManager_ShowCustomNodesMenu,
  Comfy_Manager_CustomNodesManager_ShowLegacyCustomNodesMenu,
  Comfy_Manager_ShowLegacyManagerMenu,
  Comfy_Manager_ShowMissingPacks,
  Comfy_Manager_ShowUpdateAvailablePacks,
  Comfy_Manager_ToggleManagerProgressDialog,
  Comfy_MaskEditor_BrushSize_Decrease,
  Comfy_MaskEditor_BrushSize_Increase,
  Comfy_MaskEditor_OpenMaskEditor,
  Comfy_Memory_UnloadModels,
  Comfy_Memory_UnloadModelsAndExecutionCache,
  Comfy_NewBlankWorkflow,
  Comfy_OpenClipspace,
  Comfy_OpenManagerDialog,
  Comfy_OpenWorkflow,
  Comfy_PublishSubgraph,
  Comfy_QueuePrompt,
  Comfy_QueuePromptFront,
  Comfy_QueueSelectedOutputNodes,
  Comfy_Redo,
  Comfy_RefreshNodeDefinitions,
  Comfy_SaveWorkflow,
  Comfy_SaveWorkflowAs,
  Comfy_ShowSettingsDialog,
  Comfy_ToggleAssetAPI,
  Comfy_ToggleCanvasInfo,
  Comfy_ToggleHelpCenter,
  Comfy_ToggleLinear,
  Comfy_ToggleTheme,
  Comfy_Undo,
  Comfy_User_OpenSignInDialog,
  Comfy_User_SignOut,
  Experimental_ToggleVueNodes,
  Workspace_CloseWorkflow,
  Workspace_NextOpenedWorkflow,
  Workspace_PreviousOpenedWorkflow,
  Workspace_SearchBox_Toggle,
  Workspace_ToggleBottomPanel,
  Workspace_ToggleBottomPanel_Shortcuts,
  Workspace_ToggleFocusMode,
  Workspace_ToggleSidebarTab_assets,
  Workspace_ToggleSidebarTab_workflows,
  commands as default
};
//# sourceMappingURL=commands-bTEY9Mp6.js.map
