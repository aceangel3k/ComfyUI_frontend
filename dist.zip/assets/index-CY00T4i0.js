import { c as cn } from "./index-DUabtg_Q.js";
const WidgetInputBaseClass = cn([
  // Background
  "not-disabled:bg-component-node-widget-background",
  "not-disabled:text-component-node-foreground",
  // Outline
  "border-none",
  // Rounded
  "rounded-lg"
]);
export {
  WidgetInputBaseClass as W
};
//# sourceMappingURL=index-CY00T4i0.js.map
