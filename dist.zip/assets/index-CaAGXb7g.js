import { c as cn } from "./index-c_wVuoti.js";
const WidgetInputBaseClass = cn([
  // Background
  "not-disabled:bg-component-node-widget-background",
  "not-disabled:text-component-node-foreground",
  // Outline
  "border-none",
  // Rounded
  "rounded-lg"
]);
export {
  WidgetInputBaseClass as W
};
//# sourceMappingURL=index-CaAGXb7g.js.map
