import { c as cn } from "./index-45IpBQOM.js";
const WidgetInputBaseClass = cn([
  // Background
  "not-disabled:bg-component-node-widget-background",
  "not-disabled:text-component-node-foreground",
  // Outline
  "border-none",
  // Rounded
  "rounded-lg"
]);
export {
  WidgetInputBaseClass as W
};
//# sourceMappingURL=index-DVL01i4N.js.map
