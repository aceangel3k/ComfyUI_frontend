import { c as cn } from "./index-C4ZdIbOw.js";
const WidgetInputBaseClass = cn([
  // Background
  "not-disabled:bg-component-node-widget-background",
  "not-disabled:text-component-node-foreground",
  // Outline
  "border-none",
  // Rounded
  "rounded-lg"
]);
export {
  WidgetInputBaseClass as W
};
//# sourceMappingURL=index-b8dwM04U.js.map
