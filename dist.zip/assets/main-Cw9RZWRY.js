const main = {};
export {
  main as default
};
//# sourceMappingURL=main-Cw9RZWRY.js.map
