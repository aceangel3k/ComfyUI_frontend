const actionbar = { "dockToTop": "停靠到頂部" };
const apiNodesCostBreakdown = { "costPerRun": "每次執行成本", "title": "API 節點", "totalCost": "總成本" };
const apiNodesSignInDialog = { "message": "此工作流程包含 API 節點，您必須登入帳戶才能執行。", "title": "需要登入以使用 API 節點" };
const assetBrowser = { "allCategory": "所有 {category}", "allModels": "所有模型", "ariaLabel": { "assetCard": "{name} - {type} 資源", "loadingAsset": "載入資源中" }, "assets": "資產", "baseModels": "基礎模型", "browseAssets": "瀏覽資產", "connectionError": "請檢查您的連線並重試", "failedToCreateNode": "無法建立節點。請重試或查看主控台以取得詳細資訊。", "fileFormats": "檔案格式", "loadingModels": "正在載入 {type}...", "noAssetsFound": "找不到資產", "noModelsInFolder": "此資料夾中沒有可用的 {type}", "sortAZ": "A-Z", "sortBy": "排序依據", "sortPopular": "熱門", "sortRecent": "最近", "sortZA": "Z-A", "tryAdjustingFilters": "請嘗試調整您的搜尋或篩選條件", "unknown": "未知" };
const auth = { "apiKey": { "cleared": "API 金鑰已清除", "clearedDetail": "您的 API 金鑰已成功清除", "description": "使用您的 Comfy API 金鑰以啟用 API 節點", "error": "無效的 API 金鑰", "generateKey": "點此取得", "helpText": "需要 API 金鑰？", "invalid": "無效的 API 金鑰", "invalidDetail": "請輸入有效的 API 金鑰", "label": "API 金鑰", "placeholder": "請輸入您的 API 金鑰", "storageFailed": "儲存 API 金鑰失敗", "storageFailedDetail": "請再試一次。", "stored": "API 金鑰已儲存", "storedDetail": "您的 API 金鑰已成功儲存", "title": "API 金鑰", "whitelistInfo": "關於未列入白名單的網站" }, "deleteAccount": { "cancel": "取消", "confirm": "刪除帳號", "confirmMessage": "您確定要刪除您的帳號嗎？此操作無法復原，且將永久移除您所有的資料。", "confirmTitle": "刪除帳號", "deleteAccount": "刪除帳號", "success": "帳號已刪除", "successDetail": "您的帳號已成功刪除。" }, "errors": { "auth/cancelled-popup-request": "登入已取消。請再試一次。", "auth/email-already-in-use": "此電子郵件已有帳戶存在。請嘗試登入。", "auth/invalid-credential": "登入憑證無效。請檢查您的電子郵件和密碼。", "auth/invalid-email": "請輸入有效的電子郵件地址。", "auth/network-request-failed": "網路錯誤。請檢查您的連線並再試一次。", "auth/operation-not-allowed": "目前不支援此登入方式。", "auth/popup-closed-by-user": "登入已取消。請再試一次。", "auth/too-many-requests": "登入嘗試次數過多。請稍候再試。", "auth/user-disabled": "此帳戶已被停用。請聯絡支援團隊。", "auth/user-not-found": "找不到使用此電子郵件的帳戶。您要建立新帳戶嗎？", "auth/weak-password": "密碼強度不足。請使用至少 6 個字元的更強密碼。", "auth/wrong-password": "您輸入的密碼不正確。請再試一次。" }, "login": { "andText": "以及", "backToLogin": "返回登入", "confirmPasswordLabel": "確認密碼", "confirmPasswordPlaceholder": "請再次輸入相同密碼", "didntReceiveEmail": "沒有收到電子郵件？請聯絡我們：", "emailLabel": "電子郵件", "emailPlaceholder": "請輸入您的電子郵件", "failed": "登入失敗", "forgotPassword": "忘記密碼？", "forgotPasswordError": "密碼重設郵件發送失敗", "insecureContextWarning": "此連線不安全（HTTP）。如果您繼續登入，您的憑證可能會被攻擊者攔截。", "loginButton": "登入", "loginWithGithub": "使用 Github 登入", "loginWithGoogle": "使用 Google 登入", "newUser": "新用戶？", "noAssociatedUser": "所提供的 API 金鑰未關聯任何 Comfy 用戶", "orContinueWith": "或繼續使用", "passwordLabel": "密碼", "passwordPlaceholder": "請輸入您的密碼", "passwordResetError": "無法發送密碼重設郵件。請再試一次。", "passwordResetInstructions": "請輸入您的電子郵件地址，我們將發送重設密碼連結給您。", "passwordResetSent": "密碼重設郵件已發送", "passwordResetSentDetail": "請檢查您的電子郵件以取得重設密碼的連結。", "privacyLink": "隱私權政策", "questionsContactPrefix": "有問題嗎？請聯絡我們：", "sendResetLink": "發送重設連結", "signInOrSignUp": "登入 / 註冊", "signUp": "註冊", "success": "登入成功", "termsLink": "使用條款", "termsText": "點擊「下一步」或「註冊」即表示您同意我們的", "title": "登入您的帳戶", "useApiKey": "Comfy API 金鑰", "userAvatar": "用戶頭像" }, "loginButton": { "tooltipHelp": "登入以使用「API 節點」", "tooltipLearnMore": "了解更多..." }, "passwordUpdate": { "success": "密碼已更新", "successDetail": "您的密碼已成功更新" }, "reauthRequired": { "cancel": "取消", "confirm": "重新登入", "message": "基於安全原因，此操作需要您重新登入。是否要繼續？", "title": "需要重新驗證" }, "signOut": { "signOut": "登出", "success": "成功登出", "successDetail": "您已成功登出您的帳戶。" }, "signup": { "alreadyHaveAccount": "已經有帳戶？", "emailLabel": "電子郵件", "emailPlaceholder": "請輸入您的電子郵件", "passwordLabel": "密碼", "passwordPlaceholder": "請輸入新密碼", "personalDataConsentLabel": "我同意處理我的個人資料。", "regionRestrictionChina": "因當地法規限制，本服務暫無法向中國地區開放。", "signIn": "登入", "signUpButton": "註冊", "signUpWithGithub": "使用 Github 註冊", "signUpWithGoogle": "使用 Google 註冊", "title": "建立帳戶" } };
const breadcrumbsMenu = { "clearWorkflow": "清除工作流程", "deleteBlueprint": "刪除藍圖", "deleteWorkflow": "刪除工作流程", "duplicate": "複製", "enterNewName": "輸入新名稱" };
const clipboard = { "errorMessage": "複製到剪貼簿失敗", "errorNotSupported": "您的瀏覽器不支援剪貼簿 API", "successMessage": "已複製到剪貼簿" };
const cloudFooter_needHelp = "需要幫助？";
const cloudForgotPassword_backToLogin = "返回登入";
const cloudForgotPassword_didntReceiveEmail = "未收到電子郵件？";
const cloudForgotPassword_emailLabel = "電子郵件";
const cloudForgotPassword_emailPlaceholder = "輸入您的電子郵件";
const cloudForgotPassword_emailRequired = "必須填寫電子郵件";
const cloudForgotPassword_instructions = "輸入您的電子郵件地址，我們將寄送重設密碼連結給您。";
const cloudForgotPassword_passwordResetError = "發送密碼重設郵件失敗";
const cloudForgotPassword_passwordResetSent = "密碼重設已發送";
const cloudForgotPassword_sendResetLink = "寄送重設連結";
const cloudForgotPassword_title = "忘記密碼";
const cloudOnboarding = { "authTimeout": { "causes": ["企業防火牆或代理伺服器阻擋驗證服務", "VPN 或網路限制", "瀏覽器擴充功能干擾請求", "區域網路限制", "請嘗試使用不同的瀏覽器或網路"], "helpText": "需要協助？聯絡", "message": "我們在連線至 ComfyUI 雲端時遇到問題。這可能是由於連線速度緩慢或暫時性服務問題所致。", "restart": "登出並重試", "supportLink": "支援團隊", "technicalDetails": "技術詳情", "title": "連線時間過長", "troubleshooting": "常見原因：" }, "checkingStatus": "正在檢查您的帳戶狀態...", "forgotPassword": { "backToLogin": "返回登入", "didntReceiveEmail": "沒有收到郵件？請聯絡我們：", "emailLabel": "電子郵件", "emailPlaceholder": "輸入電子郵件", "emailRequired": "電子郵件為必填欄位", "instructions": "請輸入您的電子郵件地址，我們將發送重設密碼連結給您。", "passwordResetError": "發送密碼重設郵件失敗，請再試一次。", "passwordResetSent": "密碼重設郵件已發送", "sendResetLink": "發送重設連結", "title": "忘記密碼" }, "privateBeta": { "desc": "登入以加入等候名單。輪到您時我們會通知您。已收到通知？請登入開始使用雲端服務。", "title": "雲端服務目前處於封閉測試階段" }, "retry": "再試一次", "retrying": "正在重試...", "start": { "desc": "無需任何設定。可在任何裝置上使用。", "download": "下載 ComfyUI", "explain": "一次生成多個輸出。輕鬆分享工作流程。", "learnAboutButton": "了解雲端服務", "title": "數秒內開始創作", "wantToRun": "想要在本機運行 ComfyUI？" }, "survey": { "options": { "familiarity": { "advanced": "進階使用者（自訂工作流程）", "basics": "熟悉基礎操作", "expert": "專家（協助他人）", "new": "ComfyUI 新手（從未使用過）", "starting": "剛開始（正在跟隨教學）" }, "industry": { "architecture": "建築", "education": "教育", "film_tv_animation": "電影、電視與動畫", "fine_art": "美術與插畫", "gaming": "遊戲", "marketing": "行銷與廣告", "other": "其他", "otherPlaceholder": "請具體說明", "product_design": "產品與平面設計", "software": "軟體與科技" }, "making": { "3d": "3D 資產", "audio": "音訊 / 音樂", "custom_nodes": "自訂節點與工作流程", "images": "圖片", "video": "影片與動畫" }, "purpose": { "client": "客戶工作（自由接案）", "community": "社群貢獻（節點、工作流程等）", "inhouse": "我的工作場所（公司內部）", "personal": "個人專案／興趣", "research": "學術研究" } }, "placeholder": "問卷問題佔位符", "questions": { "familiarity": "您對 ComfyUI 的熟悉程度如何？", "industry": "您的主要行業是什麼？", "making": "您計劃製作什麼？", "purpose": "您主要會使用 ComfyUI 來做什麼？" }, "steps": { "familiarity": "您對 ComfyUI 的熟悉程度如何？", "industry": "您的主要行業是什麼？", "making": "您計劃製作什麼內容？", "purpose": "您主要會使用 ComfyUI 來做什麼？" }, "title": "雲端問卷" } };
const cloudPrivateBeta_desc = "登入以加入等候名單。輪到您時我們會通知您。已收到通知？請登入開始使用雲端服務。";
const cloudPrivateBeta_title = "雲端服務目前處於私人測試階段";
const cloudSorryContactSupport_title = "抱歉，請聯絡支援團隊";
const cloudStart_desc = "無需設定。可在任何裝置上使用。";
const cloudStart_download = "下載 ComfyUI";
const cloudStart_explain = "一次生成多個輸出。輕鬆分享工作流程。";
const cloudStart_learnAboutButton = "了解雲端服務";
const cloudStart_title = "數秒內開始創作";
const cloudStart_wantToRun = "想要在本機運行 ComfyUI？";
const cloudSurvey_steps_familiarity = "您對 ComfyUI 的熟悉程度如何？";
const cloudSurvey_steps_industry = "您的主要行業是什麼？";
const cloudSurvey_steps_making = "您計劃製作什麼？";
const cloudSurvey_steps_purpose = "您主要會使用 ComfyUI 做什麼？";
const cloudWaitlist_contactLink = "此處";
const cloudWaitlist_questionsText = "有問題？聯絡我們";
const color = { "black": "黑色", "blue": "藍色", "brown": "棕色", "custom": "自訂", "cyan": "青色", "default": "預設", "green": "綠色", "noColor": "無顏色", "pale_blue": "淡藍色", "pink": "粉紅色", "purple": "紫色", "red": "紅色", "yellow": "黃色" };
const commands = { "clear": "清除工作流程", "clipspace": "開啟 Clipspace", "dark": "深色", "execute": "執行", "help": "說明", "interrupt": "取消目前執行", "light": "淺色", "manageExtensions": "管理擴充功能", "queue": "佇列面板", "refresh": "重新整理節點定義", "resetView": "重設畫布視圖", "run": "執行", "runWorkflow": "執行工作流程", "runWorkflowFront": "執行工作流程（在前方排隊）", "settings": "設定", "theme": "主題", "toggleBottomPanel": "切換底部面板" };
const contextMenu = { "Add Group": "新增群組", "Add Group For Selected Nodes": "為選取的節點新增群組", "Add Node": "新增節點", "Add Subgraph to Library": "將子圖加入程式庫", "Adjust Size": "調整大小", "Align Selected To": "對齊選取項目至", "Bottom": "底部", "Bypass": "略過", "Clone": "複製", "Collapse": "收合", "Color": "顏色", "Colors": "顏色", "Convert to Group Node": "轉換為群組節點", "Convert to Subgraph": "轉換為子圖", "Copy": "複製", "Copy (Clipspace)": "複製（剪貼空間）", "Copy Image": "複製圖片", "Delete": "刪除", "Distribute Nodes": "分佈節點", "Duplicate": "複製", "Edit Subgraph Widgets": "編輯子圖小工具", "Expand": "展開", "Expand Node": "展開節點", "Horizontal": "水平", "Inputs": "輸入", "Left": "左側", "Manage": "管理", "Manage Group Nodes": "管理群組節點", "Minimize Node": "最小化節點", "Mode": "模式", "Node Info": "節點資訊", "Node Templates": "節點範本", "Open Image": "開啟圖片", "Open in Mask Editor": "在遮罩編輯器中開啟", "Outputs": "輸出", "Paste": "貼上", "Pin": "釘選", "Properties": "屬性", "Properties Panel": "屬性面板", "Remove": "移除", "Remove Bypass": "移除繞過", "Rename": "重新命名", "Resize": "調整大小", "Right": "右側", "Run Branch": "執行分支", "Save Image": "儲存圖片", "Save Selected as Template": "將選取項目儲存為範本", "Search": "搜尋", "Shape": "形狀", "Shapes": "形狀", "Title": "標題", "Top": "頂部", "Unpack Subgraph": "解包子圖", "Unpin": "取消釘選", "Vertical": "垂直", "deprecated": "已棄用", "new": "新" };
const credits = { "accountInitialized": "帳戶已初始化", "activity": "活動", "added": "已新增", "additionalInfo": "其他資訊", "apiPricing": "API 價格", "credits": "點數", "details": "詳細資料", "eventType": "事件類型", "faqs": "常見問題", "invoiceHistory": "發票紀錄", "lastUpdated": "最後更新", "messageSupport": "聯絡客服", "model": "模型", "purchaseCredits": "購買點數", "time": "時間", "topUp": { "buyNow": "立即購買", "insufficientMessage": "您的點數不足，無法執行此工作流程。", "insufficientTitle": "點數不足", "maxAmount": "（最高 $1,000 美元）", "quickPurchase": "快速購買", "seeDetails": "查看詳情", "topUp": "儲值" }, "yourCreditBalance": "您的點數餘額" };
const dataTypes = { "*": "*", "AUDIO": "音訊", "AUDIO_ENCODER": "音訊編碼器", "AUDIO_ENCODER_OUTPUT": "音訊編碼器輸出", "AUDIO_RECORD": "音訊錄製", "BOOLEAN": "布林值", "CAMERA_CONTROL": "攝影機控制", "CLIP": "CLIP", "CLIP_VISION": "CLIP 視覺", "CLIP_VISION_OUTPUT": "CLIP 視覺輸出", "COMBO": "組合", "CONDITIONING": "條件設定", "CONTROL_NET": "ControlNet", "FLOAT": "浮點數", "FLOATS": "浮點數組", "GEMINI_INPUT_FILES": "Gemini輸入檔案", "GLIGEN": "GLIGEN", "GUIDER": "引導器", "HOOKS": "掛鉤", "HOOK_KEYFRAMES": "關鍵影格掛鉤", "IMAGE": "影像", "INT": "整數", "LATENT": "latent (潛空間)", "LATENT_OPERATION": "latent 操作", "LOAD3D_CAMERA": "載入 3D 攝影機", "LOAD_3D": "載入 3D", "LORA_MODEL": "LoRA模型", "LOSS_MAP": "損失圖", "LUMA_CONCEPTS": "LUMA 概念", "LUMA_REF": "LUMA 參考", "MASK": "遮罩", "MESH": "網格", "MODEL": "模型", "MODEL_PATCH": "模型修補", "MODEL_TASK_ID": "模型任務ID", "NOISE": "雜訊", "OPENAI_CHAT_CONFIG": "OpenAI聊天配置", "OPENAI_INPUT_FILES": "OpenAI輸入檔案", "PHOTOMAKER": "PhotoMaker", "PIXVERSE_TEMPLATE": "PIXVERSE 範本", "RECRAFT_COLOR": "RECRAFT 顏色", "RECRAFT_CONTROLS": "RECRAFT 控制", "RECRAFT_V3_STYLE": "RECRAFT V3 風格", "RETARGET_TASK_ID": "重定向任務ID", "RIG_TASK_ID": "綁定任務ID", "SAMPLER": "取樣器", "SIGMAS": "Sigma 值", "STRING": "字串", "STYLE_MODEL": "風格模型", "SVG": "SVG", "TIMESTEPS_RANGE": "時間步範圍", "UPSCALE_MODEL": "升頻模型", "VAE": "VAE", "VIDEO": "影片", "VOXEL": "體素", "WAN_CAMERA_EMBEDDING": "Wan相機嵌入", "WEBCAM": "網路攝影機" };
const desktopDialogs = { "": { "buttons": { "Close": "關閉" }, "message": "提供的對話框 ID 無效。", "title": "無效對話框" } };
const desktopMenu = { "confirmQuit": "有未儲存的工作流程，任何未儲存的變更都將遺失。確定要退出嗎？", "confirmReinstall": "這將清除您的 extra_models_config.yaml 檔案，\n並重新開始安裝。\n\n您確定要繼續嗎？", "quit": "退出", "reinstall": "重新安裝" };
const desktopStart = { "initialising": "初始化中..." };
const desktopUpdate = { "description": "ComfyUI Desktop 正在安裝新相依套件，這可能需要幾分鐘。", "errorCheckingUpdate": "檢查更新時發生錯誤", "errorInstallingUpdate": "安裝更新時發生錯誤", "noUpdateFound": "未發現更新", "terminalDefaultMessage": "任何來自更新的主控台輸出都會顯示在這裡。", "title": "正在更新 ComfyUI Desktop", "updateAvailableMessage": "有可用的更新。您要立即重新啟動並更新嗎？", "updateFoundTitle": "發現更新（v{version}）" };
const downloadGit = { "gitWebsite": "下載 git", "instructions": "請下載並安裝適用於您作業系統的最新版本。下方的「下載 git」按鈕會開啟 git-scm.com 的下載頁面。", "message": "無法找到 git。正常運作需要安裝可用的 git。", "skip": "略過", "title": "下載 git", "warning": "如果您確定不需要安裝 git，或這是一個誤判，您可以點擊「略過」來跳過此檢查。目前不支援在沒有可用 git 的情況下執行 ComfyUI。" };
const electronFileDownload = { "cancel": "取消下載", "cancelled": "已取消", "inProgress": "下載中", "pause": "暫停下載", "paused": "已暫停", "resume": "繼續下載" };
const errorDialog = { "defaultTitle": "發生錯誤", "extensionFileHint": "這可能是由於以下指令碼所致", "loadWorkflowTitle": "由於重新載入工作流程資料時發生錯誤，已中止載入", "noStackTrace": "沒有可用的堆疊追蹤", "promptExecutionError": "提示執行失敗" };
const g = { "1x": "1倍速", "2x": "2倍速", "about": "關於", "add": "新增", "addNodeFilterCondition": "新增節點篩選條件", "all": "全部", "amount": "數量", "apply": "套用", "architecture": "架構", "audioFailedToLoad": "無法載入音訊", "audioProgress": "音訊進度", "author": "作者", "back": "返回", "beta": "測試版", "bookmark": "儲存至程式庫", "calculatingDimensions": "計算尺寸中", "cancel": "取消", "capture": "擷取", "category": "分類", "chart": "圖表", "chartLowercase": "圖表", "choose_file_to_upload": "選擇要上傳的檔案", "clear": "清除", "clearAll": "全部清除", "clearFilters": "清除篩選", "close": "關閉", "color": "顏色", "comfy": "Comfy", "comfyOrgLogoAlt": "ComfyOrg 標誌", "comingSoon": "即將推出", "command": "指令", "commandProhibited": "指令 {command} 已被禁止。如需更多資訊，請聯絡管理員。", "community": "社群", "completed": "已完成", "confirm": "確認", "confirmed": "已確認", "content": "內容", "continue": "繼續", "control_after_generate": "生成後控制", "control_before_generate": "生成前控制", "copied": "已複製", "copy": "複製", "copyJobId": "複製工作 ID", "copyToClipboard": "複製到剪貼簿", "copyURL": "複製網址", "currentUser": "目前使用者", "customBackground": "自訂背景", "customize": "自訂", "customizeFolder": "自訂資料夾", "defaultBanner": "預設橫幅", "delete": "刪除", "deleteAudioFile": "刪除音訊檔案", "deleteImage": "刪除圖片", "deprecated": "已棄用", "description": "描述", "devices": "裝置", "disableAll": "全部停用", "disabling": "停用中", "dismiss": "關閉", "download": "下載", "downloadImage": "下載圖片", "downloadVideo": "下載影片", "dropYourFileOr": "拖放您的檔案或", "duplicate": "複製", "edit": "編輯", "editImage": "編輯圖片", "editOrMaskImage": "編輯或遮罩圖片", "empty": "空", "enableAll": "全部啟用", "enableOrDisablePack": "啟用或停用套件", "enabled": "已啟用", "enabling": "啟用中", "error": "錯誤", "errorLoadingImage": "載入圖片時發生錯誤", "errorLoadingVideo": "載入影片時發生錯誤", "experimental": "實驗性", "export": "匯出", "extensionName": "擴充套件名稱", "failedToCopyJobId": "複製工作 ID 失敗", "failedToDownloadImage": "下載圖片失敗", "failedToDownloadVideo": "下載影片失敗", "feedback": "意見回饋", "file": "檔案", "filter": "篩選", "findIssues": "尋找問題", "frameNodes": "框架節點", "frontendNewer": "前端版本 {frontendVersion} 可能與後端版本 {backendVersion} 不相容。", "frontendOutdated": "前端版本 {frontendVersion} 已過時。後端需要 {requiredVersion} 或更高版本。", "galleryImage": "圖庫圖片", "galleryThumbnail": "圖庫縮圖", "goToNode": "前往節點", "graphNavigation": "圖形導覽", "halfSpeed": "0.5倍速", "icon": "圖示", "imageFailedToLoad": "無法載入圖片", "imagePreview": "圖片預覽 - 使用方向鍵在圖片間導航", "imageUrl": "圖片網址", "import": "匯入", "inProgress": "進行中", "info": "節點資訊", "insert": "插入", "install": "安裝", "installed": "已安裝", "installing": "安裝中", "interrupted": "已中斷", "itemSelected": "已選取 {selectedCount} 項", "itemsSelected": "已選取 {selectedCount} 項", "jobIdCopied": "工作 ID 已複製到剪貼簿", "keybinding": "快捷鍵", "keybindingAlreadyExists": "快捷鍵已存在於", "learnMore": "了解更多", "listening": "聆聽中...", "liveSamplingPreview": "即時取樣預覽", "loadAllFolders": "載入所有資料夾", "loadWorkflow": "載入工作流程", "loading": "載入中", "loadingPanel": "正在載入{panel}面板...", "login": "登入", "logoAlt": "ComfyUI 標誌", "logs": "日誌", "markdown": "標記語言", "micPermissionDenied": "麥克風權限被拒絕", "migrate": "遷移", "missing": "缺少", "moreOptions": "更多選項", "moreWorkflows": "更多工作流程", "multiSelectDropdown": "多選下拉式選單", "name": "名稱", "newFolder": "新資料夾", "next": "下一步", "no": "否", "noAudioRecorded": "沒有錄製到音訊", "noResultsFound": "找不到結果", "noTasksFound": "找不到任務", "noTasksFoundMessage": "佇列中沒有任務。", "noWorkflowsFound": "找不到工作流程。", "nodeContentError": "節點內容錯誤", "nodeHeaderError": "節點標頭錯誤", "nodeRenderError": "節點渲染錯誤", "nodeSlotsError": "節點插槽錯誤", "nodeWidgetsError": "節點小工具錯誤", "nodes": "節點", "nodesRunning": "節點執行中", "none": "無", "ok": "確定", "openManager": "開啟管理器", "openNewIssue": "開啟新問題", "overwrite": "覆蓋", "playRecording": "播放錄製", "playbackSpeed": "播放速度", "playing": "播放中", "pressKeysForNewBinding": "按下按鍵設定新綁定", "preview": "預覽", "progressCountOf": "共", "ready": "就緒", "reconnected": "已重新連線", "reconnecting": "重新連線中", "refresh": "重新整理", "refreshNode": "重新整理節點", "releaseTitle": "{package} {version} 版本發佈", "reloadToApplyChanges": "重新載入以套用變更", "removeImage": "移除圖片", "removeVideo": "移除影片", "rename": "重新命名", "reportIssue": "送出回報", "reportIssueTooltip": "將錯誤報告提交給 Comfy Org", "reportSent": "已提交報告", "reset": "重設", "resetAll": "全部重設", "resetAllKeybindingsTooltip": "將所有快捷鍵重設為預設值", "resizeFromBottomLeft": "從左下角調整大小", "resizeFromBottomRight": "從右下角調整大小", "resizeFromTopLeft": "從左上角調整大小", "resizeFromTopRight": "從右上角調整大小", "restart": "重新啟動", "resultsCount": "找到 {count} 筆結果", "save": "儲存", "saving": "儲存中", "search": "搜尋", "searchExtensions": "搜尋擴充套件", "searchFailedMessage": "找不到符合您搜尋的設定。請嘗試調整搜尋條件。", "searchKeybindings": "搜尋快捷鍵", "searchModels": "搜尋模型", "searchNodes": "搜尋節點", "searchSettings": "搜尋設定", "searchWorkflows": "搜尋工作流程", "seeTutorial": "查看教學", "selectedFile": "已選取的檔案", "setAsBackground": "設為背景", "settings": "設定", "showReport": "顯示報告", "singleSelectDropdown": "單選下拉式選單", "sort": "排序", "source": "來源", "startRecording": "開始錄音", "status": "狀態", "stopPlayback": "停止播放", "stopRecording": "停止錄音", "success": "成功", "systemInfo": "系統資訊", "terminal": "終端機", "title": "標題", "triggerPhrase": "觸發詞", "unknownError": "未知錯誤", "update": "更新", "updateAvailable": "有可用更新", "updateFrontend": "更新前端", "updated": "已更新", "updating": "更新中", "upload": "上傳", "usageHint": "使用提示", "user": "使用者", "versionMismatchWarning": "版本相容性警告", "versionMismatchWarningMessage": "{warning}：{detail} 請參閱 https://docs.comfy.org/installation/update_comfyui#common-update-issues 以取得更新說明。", "videoFailedToLoad": "無法載入影片", "videoPreview": "影片預覽 - 使用方向鍵在影片間導航", "viewImageOfTotal": "檢視第 {index} 張圖片（共 {total} 張）", "viewVideoOfTotal": "檢視第 {index} 個影片（共 {total} 個）", "vitePreloadErrorMessage": "應用程式的新版本已發佈。您要重新載入嗎？\n如果不重新載入，應用程式的某些部分可能無法正常運作。\n您可以拒絕並先儲存進度，稍後再重新載入。", "vitePreloadErrorTitle": "新版本可用", "volume": "音量", "warning": "警告", "workflow": "工作流程" };
const graphCanvasMenu = { "fitView": "適合視窗", "focusMode": "專注模式", "hand": "手形", "hideLinks": "隱藏連結", "panMode": "平移模式", "resetView": "重設視圖", "select": "選取", "selectMode": "選取模式", "showLinks": "顯示連結", "toggleLinkVisibility": "切換連結顯示", "toggleMinimap": "切換小地圖", "zoomIn": "放大", "zoomOptions": "縮放選項", "zoomOut": "縮小" };
const groupNode = { "create": "建立群組節點", "enterName": "輸入名稱" };
const helpCenter = { "clickToLearnMore": "點擊了解更多 →", "desktopUserGuide": "桌面版使用指南", "docs": "文件", "github": "Github", "loadingReleases": "正在載入版本資訊…", "managerExtension": "管理器擴充功能", "more": "更多…", "noRecentReleases": "近期沒有新版本", "openDevTools": "開啟開發者工具", "recentReleases": "近期發布", "reinstall": "重新安裝", "updateAvailable": "有更新", "whatsNew": "有什麼新功能？" };
const icon = { "bookmark": "書籤", "box": "盒子", "briefcase": "公事包", "exclamation-triangle": "警告", "file": "檔案", "folder": "資料夾", "heart": "愛心", "inbox": "收件匣", "star": "星號" };
const install = { "appDataLocationTooltip": "ComfyUI 的應用程式資料目錄。儲存：\n- 日誌\n- 伺服器設定", "appPathLocationTooltip": "ComfyUI 的應用程式資產目錄。儲存 ComfyUI 程式碼與資產", "cannotWrite": "無法寫入所選路徑", "chooseInstallationLocation": "選擇安裝位置", "customNodes": "自訂節點", "customNodesDescription": "從現有的 ComfyUI 安裝重新安裝自訂節點。", "desktopAppSettings": "桌面應用程式設定", "desktopAppSettingsDescription": "設定 ComfyUI 在桌面的行為。您之後可以變更這些設定。", "desktopSettings": "桌面設定", "failedToSelectDirectory": "選擇目錄失敗", "gpu": "GPU", "gpuPicker": { "appleMetalDescription": "利用您 Mac 的 GPU 提升速度並獲得更好的整體體驗", "cpuDescription": "當 GPU 加速不可用時，使用 CPU 模式以取得相容性", "cpuSubtitle": "CPU 模式", "manualDescription": "為進階設定或不支援的硬體手動設定 ComfyUI", "manualSubtitle": "手動設定", "nvidiaDescription": "使用您的 NVIDIA GPU 與 CUDA 加速以獲得最佳效能。", "nvidiaSubtitle": "NVIDIA CUDA", "recommended": "建議", "title": "選擇您的硬體設定" }, "gpuSelection": { "cpuMode": "CPU 模式", "cpuModeDescription": "CPU 模式僅供開發者及極少數特殊情境使用。", "cpuModeDescription2": "如果您不確定需要此選項，請忽略此選項並在上方選擇您的 GPU。", "customComfyNeedsPython": "ComfyUI 需要先設定 Python 才能運作", "customInstallRequirements": "安裝所有需求與相依套件（例如自訂 torch）", "customManualVenv": "手動設定 Python venv", "customMayNotWork": "此選項完全不受支援，可能無法正常運作", "customSkipsPython": "此選項會略過一般的 Python 設定。", "enableCpuMode": "啟用 CPU 模式", "mpsDescription": "Apple Metal Performance Shaders 可透過 PyTorch nightly 支援。", "nvidiaDescription": "NVIDIA 裝置可直接透過 PyTorch CUDA 版本支援。", "selectGpu": "選擇 GPU", "selectGpuDescription": "選擇您擁有的 GPU 類型" }, "helpImprove": "請協助改進 ComfyUI", "installLocation": "安裝位置", "installLocationDescription": "選擇 ComfyUI 使用者資料的目錄。Python 環境將安裝在所選位置。", "installLocationTooltip": "ComfyUI 的使用者資料目錄。儲存：\n- Python 環境\n- 模型\n- 自訂節點\n", "insufficientFreeSpace": "空間不足 - 最低可用空間", "isOneDrive": "不支援 OneDrive。請將 ComfyUI 安裝在其他位置。", "locationPicker": { "chooseDownloadServers": "手動選擇下載伺服器", "downloadServersDescription": "根據您的位置選擇特定的鏡像伺服器來下載 Python、PyPI 套件與 PyTorch。", "migrateDescription": "從先前的 ComfyUI 安裝複製或連結您現有的模型、自訂節點與設定。", "migrateFromExisting": "從現有安裝遷移", "migrationPathPlaceholder": "選取現有的 ComfyUI 安裝（選填）", "pathPlaceholder": "/Users/username/Documents/ComfyUI", "subtitle": "為 ComfyUI 的檔案選擇一個資料夾。我們也會自動在該處設定 Python。", "title": "選擇 ComfyUI 安裝位置" }, "manualConfiguration": { "createVenv": "您需要在下列目錄建立虛擬環境", "requirements": "需求", "restartWhenFinished": "完成虛擬環境設定後，請重新啟動 ComfyUI。", "title": "手動設定", "virtualEnvironmentPath": "虛擬環境路徑" }, "metricsDisabled": "統計已停用", "metricsEnabled": "統計已啟用", "migrateFromExistingInstallation": "從現有安裝遷移", "migration": "遷移", "migrationOptional": "遷移為選擇性步驟。如果您沒有現有安裝，可以略過此步驟。", "migrationSourcePathDescription": "如果您已有 ComfyUI 安裝，我們可以將您現有的使用者檔案與模型複製/連結到新安裝。您現有的 ComfyUI 安裝不會受到影響。", "moreInfo": "更多資訊請參閱", "nonDefaultDrive": "請將 ComfyUI 安裝在您的系統磁碟（例如 C:\\）。不同檔案系統的磁碟可能會導致不可預期的問題。安裝後，模型和其他檔案可以儲存在其他磁碟。", "parentMissing": "路徑不存在 - 請先建立上層目錄", "pathExists": "目錄已存在 - 請確保您已備份所有資料", "pathValidationFailed": "路徑驗證失敗", "privacyPolicy": "隱私權政策", "selectItemsToMigrate": "選擇要遷移的項目", "settings": { "allowMetrics": "使用統計", "allowMetricsDescription": "協助改進 ComfyUI，傳送匿名使用統計資料。不會收集個人資訊或工作流程內容。", "autoUpdate": "自動更新", "autoUpdateDescription": "自動下載可用更新。安裝前會通知您。", "checkingMirrors": "正在檢查 Python 鏡像的網路連線...", "dataCollectionDialog": { "collect": { "errorReports": "錯誤訊息與堆疊追蹤", "systemInfo": "硬體、作業系統類型與應用程式版本", "userJourneyEvents": "使用者操作事件" }, "doNotCollect": { "customNodeConfigurations": "自訂節點設定", "fileSystemInformation": "檔案系統資訊", "personalInformation": "個人資訊", "workflowContents": "工作流程內容" }, "title": "關於資料收集", "viewFullPolicy": "檢視完整政策", "whatWeCollect": "我們收集：", "whatWeDoNotCollect": "我們不收集：" }, "errorUpdatingConsent": "更新同意時發生錯誤", "errorUpdatingConsentDetail": "無法更新統計同意設定", "learnMoreAboutData": "了解更多資料收集資訊", "mirrorSettings": "鏡像設定", "mirrorsReachable": "Python 鏡像網路連線正常", "mirrorsUnreachable": "部分 Python 鏡像網路連線異常", "pypiMirrorPlaceholder": "請輸入 PyPI 鏡像網址", "pythonMirrorPlaceholder": "請輸入 Python 鏡像網址" }, "systemLocations": "系統位置", "unhandledError": "未知錯誤", "updateConsent": "您先前已選擇回報當機。現在我們會追蹤事件型統計資料，以協助找出錯誤並改進應用程式。不會收集任何可識別個人身分的資訊。" };
const issueReport = { "helpFix": "協助修復此問題" };
const load3d = { "applyingTexture": "正在套用材質貼圖...", "backgroundColor": "背景顏色", "camera": "相機", "cameraType": { "orthographic": "正交", "perspective": "透視" }, "clearRecording": "清除錄影", "dropToLoad": "拖放3D模型以載入", "edgeThreshold": "邊緣閾值", "export": "匯出", "exportModel": "匯出模型", "exportRecording": "匯出錄影", "exportingModel": "正在匯出模型...", "fov": "視野角度", "light": "光源", "lightIntensity": "光源強度", "loadingBackgroundImage": "正在載入背景圖片", "loadingModel": "正在載入 3D 模型...", "materialMode": "材質模式", "materialModes": { "depth": "深度", "lineart": "線稿", "normal": "一般", "original": "原始", "wireframe": "線框" }, "model": "模型", "openIn3DViewer": "在 3D 檢視器中開啟", "previewOutput": "預覽輸出", "reloadingModel": "重新載入模型中...", "removeBackgroundImage": "移除背景圖片", "resizeNodeMatchOutput": "調整節點以符合輸出", "scene": "場景", "showGrid": "顯示格線", "startRecording": "開始錄影", "stopRecording": "停止錄影", "switchCamera": "切換相機", "switchingMaterialMode": "正在切換材質模式...", "unsupportedFileType": "不支援的檔案類型（支援 .gltf、.glb、.obj、.fbx、.stl）", "upDirection": "上方方向", "upDirections": { "original": "原始" }, "uploadBackgroundImage": "上傳背景圖片", "uploadTexture": "上傳材質貼圖", "uploadingModel": "正在上傳 3D 模型...", "viewer": { "apply": "套用", "cameraSettings": "相機設定", "cameraType": "相機類型", "cancel": "取消", "exportSettings": "匯出設定", "lightSettings": "燈光設定", "modelSettings": "模型設定", "sceneSettings": "場景設定", "title": "3D 檢視器（測試版）" } };
const maintenance = { "None": "無", "OK": "正常", "Skipped": "已略過", "allOk": "未偵測到任何問題。", "confirmTitle": "確定要繼續嗎？", "consoleLogs": "控制台日誌", "detected": "已偵測", "error": { "cannotContinue": "無法繼續 - 仍有錯誤存在", "defaultDescription": "執行維護任務時發生錯誤。", "taskFailed": "任務執行失敗。", "toastTitle": "任務錯誤" }, "refreshing": "正在重新整理", "showManual": "顯示維護任務", "status": "狀態", "terminalDefaultMessage": "當您執行疑難排解指令時，任何輸出都會顯示在這裡。", "title": "維護" };
const manager = { "allMissingNodesInstalled": "所有缺少的節點已成功安裝", "applyChanges": "套用變更", "changingVersion": "正在將版本從 {from} 變更為 {to}", "clickToFinishSetup": "點擊", "conflicts": { "conflictInfoTitle": "為什麼會發生這種情況？", "conflictMessages": { "accelerator": "不支援的 GPU/加速器（可用：{current}，需要：{required}）", "banned": "此套件因安全原因被禁用", "comfyui_version": "ComfyUI 版本不符（目前：{current}，需要：{required}）", "frontend_version": "前端版本不符（目前：{current}，需要：{required}）", "generic": "相容性問題（目前：{current}，需要：{required}）", "import_failed": "匯入失敗", "os": "不支援的作業系統（目前：{current}，需要：{required}）", "pending": "安全性驗證待處理 - 無法驗證相容性" }, "conflicts": "衝突", "description": "我們偵測到部分擴充功能與新版 ComfyUI 之間存在衝突。更新後，依賴這些擴充功能的工作流程可能會失效。", "enableAnyway": "仍然啟用", "extensionAtRisk": "有風險的擴充功能", "importFailedExtensions": "匯入失敗的擴充功能", "info": "若您繼續更新，衝突的擴充功能將自動停用。您可以隨時在 ComfyUI 管理器中查看和管理它們。", "installAnyway": "仍然安裝", "title": "偵測到節點套件問題！", "understood": "了解", "warningBanner": { "button": "了解更多...", "message": "這些擴充功能需要與您目前設定不同的系統套件版本。安裝它們可能會覆蓋核心相依套件，並影響其他擴充功能或工作流程。", "title": "部分擴充功能因與您目前的設定不相容而被停用" }, "warningTooltip": "此套件可能與您目前的環境存在相容性問題" }, "createdBy": "建立者", "dependencies": "相依套件", "disabledNodesWontUpdate": "已停用的節點將不會更新", "discoverCommunityContent": "探索社群製作的節點包、擴充功能等...", "downloads": "下載次數", "enablePackToChangeVersion": "啟用此套件以變更版本", "errorConnecting": "連線至 Comfy Node Registry 時發生錯誤。", "extensionsSuccessfullyInstalled": "擴充功能已成功安裝並可使用！", "failed": "失敗（{count}）", "failedToInstall": "安裝失敗", "filter": { "disabled": "已停用", "enabled": "已啟用", "nodePack": "節點包" }, "gettingInfo": "正在取得資訊...", "importFailedGenericError": "套件匯入失敗。請查看主控台以取得更多詳細資訊。", "inWorkflow": "於工作流程中", "infoPanelEmpty": "點擊項目以查看資訊", "installAllMissingNodes": "安裝所有缺少的節點", "installError": "安裝錯誤", "installSelected": "安裝所選項目", "installationQueue": "安裝佇列", "installingDependencies": "正在安裝相依套件...", "lastUpdated": "最後更新", "latestVersion": "最新版本", "legacyManagerUI": "使用舊版介面", "legacyManagerUIDescription": "若要使用舊版管理介面，請以 --enable-manager-legacy-ui 啟動 ComfyUI", "legacyMenuNotAvailable": "舊版管理選單不可用，已預設切換至新版管理選單。", "license": "授權條款", "loadingVersions": "正在載入版本...", "mixedSelectionMessage": "無法對混合選取執行批次操作", "nightlyVersion": "每夜建置版", "noDescription": "沒有可用的說明", "noNodesFound": "找不到任何節點", "noNodesFoundDescription": "此套件的節點無法解析，或此套件僅為前端擴充功能，沒有任何節點。", "noResultsFound": "找不到符合搜尋條件的結果。", "nodePack": "節點包", "notAvailable": "不可用", "packsSelected": "已選擇套件", "repository": "儲存庫", "restartToApplyChanges": "請重新啟動 ComfyUI 以套用變更", "restartingBackend": "正在重新啟動後端以套用變更...", "searchPlaceholder": "搜尋", "selectVersion": "選擇版本", "sort": { "created": "最新上架", "downloads": "最受歡迎", "publisher": "發佈者", "updated": "最近更新" }, "status": { "active": "啟用中", "banned": "已封鎖", "conflicting": "衝突", "deleted": "已刪除", "flagged": "已標記", "importFailed": "安裝錯誤", "pending": "待處理", "unknown": "未知" }, "title": "自訂節點管理器", "toFinishSetup": "完成設定", "totalNodes": "節點總數", "tryAgainLater": "請稍後再試。", "tryDifferentSearch": "請嘗試其他搜尋關鍵字。", "uninstall": "解除安裝", "uninstallSelected": "解除安裝所選項目", "uninstalling": "正在解除安裝", "update": "更新", "updateAll": "全部更新", "updateSelected": "更新所選項目", "updatingAllPacks": "正在更新所有套件", "version": "版本" };
const maskEditor = {};
const mediaAsset = { "assetDeletedSuccessfully": "資源刪除成功", "deleteAssetDescription": "此資源將被永久移除。", "deleteAssetTitle": "刪除此資源？", "deleteSelectedDescription": "{count} 個資源將被永久移除。", "deleteSelectedTitle": "刪除選取的資源？", "deletingImportedFilesCloudOnly": "僅雲端版本支援刪除匯入的檔案", "failedToDeleteAsset": "刪除資源失敗", "jobIdToast": { "copied": "已複製", "error": "錯誤", "jobIdCopied": "工作 ID 已複製到剪貼簿", "jobIdCopyFailed": "複製工作 ID 失敗" }, "selection": { "assetsDeletedSuccessfully": "{count} 個資源刪除成功", "deleteSelected": "刪除", "deselectAll": "取消全選", "downloadSelected": "下載", "downloadStarted": "正在下載 {count} 個檔案...", "downloadsStarted": "已開始下載 {count} 個檔案", "failedToDeleteAssets": "刪除選取資源失敗", "selectedCount": "已選取資源：{count}" } };
const menu = { "autoQueue": "自動排隊", "batchCount": "批次數量", "batchCountTooltip": "工作流程產生應排入佇列的次數", "clear": "清除工作流程", "clipspace": "開啟 Clipspace", "dark": "深色", "disabled": "已停用", "disabledTooltip": "工作流程將不會自動排入佇列", "execute": "執行", "help": "說明", "hideMenu": "隱藏選單", "instant": "立即", "instantTooltip": "每次產生完成後，工作流程會立即排入佇列", "interrupt": "取消目前執行", "light": "淺色", "manageExtensions": "管理擴充功能", "onChange": "變更時", "onChangeTooltip": "每當有變更時，工作流程會排入佇列", "queue": "佇列面板", "refresh": "重新整理節點定義", "resetView": "重設畫布視圖", "run": "執行", "runWorkflow": "執行工作流程（Shift 於前方排隊）", "runWorkflowFront": "執行工作流程（前方排隊）", "settings": "設定", "showMenu": "顯示選單", "theme": "主題", "toggleBottomPanel": "切換下方面板" };
const menuLabels = { "About ComfyUI": "關於 ComfyUI", "Assets": "資源", "Bottom Panel": "底部面板", "Browse Templates": "瀏覽範本", "Bypass/Unbypass Selected Nodes": "繞過/取消繞過選取節點", "Canvas Performance": "畫布效能", "Canvas Toggle Lock": "切換畫布鎖定", "Check for Custom Node Updates": "檢查自訂節點更新", "Clear Pending Tasks": "清除待處理任務", "Clear Workflow": "清除工作流程", "Clipspace": "Clipspace", "Close Current Workflow": "關閉目前工作流程", "Collapse/Expand Selected Nodes": "收合/展開選取節點", "Comfy-Org Discord": "Comfy-Org Discord", "ComfyUI Docs": "ComfyUI 文件", "ComfyUI Forum": "ComfyUI 論壇", "ComfyUI Issues": "ComfyUI 問題回報", "Contact Support": "聯絡支援", "Convert Selection to Subgraph": "將選取內容轉為子圖", "Convert selected nodes to group node": "將選取節點轉為群組節點", "Custom Nodes (Legacy)": "自訂節點（舊版）", "Custom Nodes Manager": "自訂節點管理員", "Decrease Brush Size in MaskEditor": "在 MaskEditor 中減小筆刷大小", "Delete Selected Items": "刪除選取項目", "Duplicate Current Workflow": "複製目前工作流程", "Edit": "編輯", "Edit Subgraph Widgets": "編輯子圖小工具", "Exit Subgraph": "退出子圖", "Experimental: Browse Model Assets": "實驗性：瀏覽模型資源", "Experimental: Enable AssetAPI": "實驗性：啟用 AssetAPI", "Export": "匯出", "Export (API)": "匯出（API）", "File": "檔案", "Fit Group To Contents": "群組貼合內容", "Focus Mode": "專注模式", "Group Selected Nodes": "群組選取節點", "Help": "說明", "Help Center": "幫助中心", "Increase Brush Size in MaskEditor": "在 MaskEditor 中增大筆刷大小", "Install Missing Custom Nodes": "安裝缺少的自訂節點", "Interrupt": "中斷", "Load Default Workflow": "載入預設工作流程", "Lock Canvas": "鎖定畫布", "Manage group nodes": "管理群組節點", "Manager": "管理員", "Manager Menu (Legacy)": "管理員選單（舊版）", "Minimap": "迷你地圖", "Model Library": "模型庫", "Move Selected Nodes Down": "選取節點下移", "Move Selected Nodes Left": "選取節點左移", "Move Selected Nodes Right": "選取節點右移", "Move Selected Nodes Up": "選取節點上移", "Mute/Unmute Selected Nodes": "靜音/取消靜音選取節點", "New": "新增", "Next Opened Workflow": "下一個已開啟的工作流程", "Node Library": "節點庫", "Node Links": "節點連結", "Open": "開啟", "Open 3D Viewer (Beta) for Selected Node": "為選取節點開啟 3D 檢視器（測試版）", "Open Mask Editor for Selected Node": "為選取節點開啟遮罩編輯器", "Open Sign In Dialog": "開啟登入對話框", "Pin/Unpin Selected Items": "釘選/取消釘選選取項目", "Pin/Unpin Selected Nodes": "釘選/取消釘選選取節點", "Previous Opened Workflow": "上一個已開啟的工作流程", "Publish": "發佈", "Queue Prompt": "加入提示至佇列", "Queue Prompt (Front)": "將提示加入佇列前端", "Queue Selected Output Nodes": "將選取的輸出節點加入佇列", "Redo": "重做", "Refresh Node Definitions": "重新整理節點定義", "Reset View": "重設視圖", "Resize Selected Nodes": "調整選取節點大小", "Save": "儲存", "Save As": "另存新檔", "Show Keybindings Dialog": "顯示快捷鍵對話框", "Show Model Selector (Dev)": "顯示模型選擇器（開發用）", "Show Settings Dialog": "顯示設定對話框", "Sign Out": "登出", "Toggle Essential Bottom Panel": "切換基本底部面板", "Toggle Logs Bottom Panel": "切換日誌底部面板", "Toggle Search Box": "切換搜尋框", "Toggle Terminal Bottom Panel": "切換終端機底部面板", "Toggle Theme (Dark/Light)": "切換主題（深色/淺色）", "Toggle View Controls Bottom Panel": "切換檢視控制底部面板", "Toggle promotion of hovered widget": "切換懸停小工具提升狀態", "Toggle the Custom Nodes Manager Progress Bar": "切換自訂節點管理器進度條", "Undo": "復原", "Ungroup selected group nodes": "取消群組選取的群組節點", "Unload Models": "卸載模型", "Unload Models and Execution Cache": "卸載模型與執行快取", "Unlock Canvas": "解除鎖定畫布", "Unpack the selected Subgraph": "解包所選子圖", "View": "檢視", "Workflows": "工作流程", "Zoom In": "放大", "Zoom Out": "縮小", "Zoom to fit": "縮放至適合大小" };
const minimap = { "nodeColors": "節點顏色", "renderBypassState": "渲染繞過狀態", "renderErrorState": "渲染錯誤狀態", "showGroups": "顯示框架/群組", "showLinks": "顯示連結" };
const missingModelsDialog = { "doNotAskAgain": "不要再顯示此訊息", "missingModels": "缺少模型", "missingModelsMessage": "載入圖形時，找不到以下模型" };
const nodeCategories = { "3d": "3D", "3d_models": "3D 模型", "BFL": "BFL", "ByteDance": "字節跳動", "Gemini": "雙子星", "Ideogram": "Ideogram", "Kling": "Kling", "LTXV": "LTXV", "Luma": "Luma", "MiniMax": "MiniMax", "Moonvalley Marey": "月谷馬雷", "OpenAI": "OpenAI", "PixVerse": "PixVerse", "Recraft": "Recraft", "Rodin": "羅丹", "Runway": "跑道", "Sora": "蒼穹", "Stability AI": "Stability AI", "Tripo": "三重奏", "Veo": "Veo", "Vidu": "維度", "Wan": "Wan", "_for_testing": "_for_testing", "advanced": "進階", "animation": "動畫", "api": "API", "api node": "API 節點", "attention_experiments": "注意力實驗", "audio": "音訊", "batch": "批次", "camera": "相機", "chroma_radiance": "色度光輝", "clip": "CLIP", "combine": "合併", "compositing": "合成", "cond pair": "條件配對", "cond single": "單一條件", "conditioning": "條件設定", "context": "上下文", "controlnet": "ControlNet", "create": "建立", "custom_sampling": "自訂取樣", "debug": "除錯", "deprecated": "已棄用", "edit_models": "編輯模型", "flux": "Flux", "gligen": "GLIGEN", "guidance": "引導", "guiders": "引導器", "hooks": "掛鉤", "image": "影像", "inpaint": "修補", "instructpix2pix": "instructpix2pix", "latent": "潛空間", "loaders": "載入器", "lotus": "lotus", "ltxv": "ltxv", "mask": "遮罩", "model": "模型", "model_merging": "模型合併", "model_patches": "模型修補", "model_specific": "特定模型", "noise": "雜訊", "operations": "操作", "photomaker": "photomaker", "postprocessing": "後處理", "preprocessors": "前處理器", "primitive": "基礎元件", "qwen": "千問", "samplers": "取樣器", "sampling": "取樣", "save": "儲存", "schedulers": "排程器", "scheduling": "排程", "sd": "SD", "sd3": "sd3", "sigmas": "西格瑪值", "stable_cascade": "stable_cascade", "string": "字串", "style_model": "風格模型", "text": "文字", "training": "訓練", "transform": "轉換", "unet": "UNet", "upscale_diffusion": "擴散放大", "upscaling": "放大", "utils": "工具", "video": "影片", "video_models": "影片模型" };
const nodeHelpPage = { "documentationPage": "說明文件頁面", "inputs": "輸入", "loadError": "載入說明失敗：{error}", "moreHelp": "如需更多協助，請造訪", "outputs": "輸出", "type": "類型" };
const nodeTemplates = { "enterName": "輸入名稱", "saveAsTemplate": "儲存為範本" };
const notSupported = { "continue": "繼續", "continueTooltip": "我確定我的裝置受支援", "learnMore": "了解更多", "message": "僅支援以下裝置：", "reportIssue": "回報問題", "supportedDevices": { "macos": "macOS（M1 或更新版本）", "windows": "Windows（支援 CUDA 的 NVIDIA 顯示卡）" }, "title": "您的裝置不受支援" };
const releaseToast = { "newVersionAvailable": "有新版本可用！", "skip": "跳過", "update": "更新", "whatsNew": "有什麼新功能？" };
const selectionToolbox = { "Bypass Group Nodes": "繞過群組節點", "Set Group Nodes to Always": "將群組節點設為總是", "Set Group Nodes to Never": "將群組節點設為永不", "executeButton": { "disabledTooltip": "未選取任何輸出節點", "tooltip": "執行至選取的輸出節點（以橙色邊框標示）" } };
const serverConfig = { "modifiedConfigs": "您已修改以下伺服器設定。請重新啟動以套用變更。", "restart": "重新啟動", "revertChanges": "還原變更" };
const serverConfigCategories = { "Attention": "注意力", "CUDA": "CUDA", "Cache": "快取", "Directories": "目錄", "General": "一般", "Inference": "推論", "Memory": "記憶體", "Network": "網路", "Preview": "預覽" };
const serverConfigItems = { "cache-classic": { "name": "使用經典快取系統" }, "cache-lru": { "name": "使用 LRU 快取，最多快取 N 個節點結果。", "tooltip": "可能會佔用更多 RAM/VRAM。" }, "cpu-vae": { "name": "在 CPU 上執行 VAE" }, "cross-attention-method": { "name": "Cross attention 方法" }, "cuda-device": { "name": "要使用的 CUDA 裝置索引" }, "cuda-malloc": { "name": "使用 CUDA malloc 進行記憶體分配" }, "default-hashing-function": { "name": "模型檔案的預設雜湊函式" }, "deterministic": { "name": "讓 PyTorch 優先使用較慢的確定性演算法。", "tooltip": "請注意，這不一定能讓所有情況下的圖片都完全可重現。" }, "directml": { "name": "DirectML 裝置索引" }, "disable-all-custom-nodes": { "name": "停用載入所有自訂節點。" }, "disable-ipex-optimize": { "name": "停用 IPEX 最佳化" }, "disable-metadata": { "name": "停用在檔案中儲存提示詞中繼資料。" }, "disable-smart-memory": { "name": "停用智慧型記憶體管理", "tooltip": "強制 ComfyUI 積極地將模型卸載到一般 RAM，而不是在可行時保留於 VRAM。" }, "disable-xformers": { "name": "停用 xFormers 最佳化" }, "dont-print-server": { "name": "不在主控台輸出伺服器訊息。" }, "dont-upcast-attention": { "name": "防止 attention upcast" }, "enable-cors-header": { "name": "啟用 CORS 標頭：使用「*」允許所有來源或指定網域" }, "fast": { "name": "啟用部分未經測試且可能降低品質的最佳化。" }, "force-channels-last": { "name": "強制使用 channels-last 記憶體格式" }, "force-upcast-attention": { "name": "強制 attention upcast" }, "global-precision": { "name": "全域浮點精度", "tooltip": "全域浮點精度" }, "input-directory": { "name": "輸入目錄" }, "listen": { "name": "主機：要監聽的 IP 位址" }, "log-level": { "name": "日誌詳細等級" }, "max-upload-size": { "name": "最大上傳檔案大小（MB）" }, "output-directory": { "name": "輸出目錄" }, "port": { "name": "連接埠：要監聽的連接埠" }, "preview-method": { "name": "用於 latent (潛空間) 預覽的方法" }, "preview-size": { "name": "預覽圖片大小" }, "reserve-vram": { "name": "保留 VRAM（GB）", "tooltip": "設定要為作業系統/其他軟體保留的 VRAM（GB）數量。預設會依作業系統自動保留部分空間。" }, "text-encoder-precision": { "name": "文字編碼器精度", "tooltip": "文字編碼器精度" }, "tls-certfile": { "name": "TLS 憑證檔案：HTTPS 用的 TLS 憑證檔案路徑" }, "tls-keyfile": { "name": "TLS 金鑰檔案：HTTPS 用的 TLS 金鑰檔案路徑" }, "unet-precision": { "name": "UNET 精度", "tooltip": "UNET 精度" }, "vae-precision": { "name": "VAE 精度", "tooltip": "VAE 精度" }, "vram-management": { "name": "VRAM 管理模式" } };
const serverStart = { "copyAllTooltip": "複製全部", "copySelectionTooltip": "複製所選內容", "errorMessage": "無法啟動 ComfyUI Desktop", "installation": { "title": "正在安裝 ComfyUI" }, "openLogs": "開啟日誌", "process": { "error": "無法啟動 ComfyUI 桌面版", "initial-state": "載入中...", "python-setup": "正在設定 Python 環境...", "ready": "完成中...", "starting-server": "正在啟動 ComfyUI 伺服器..." }, "reportIssue": "回報問題", "showTerminal": "顯示終端機", "title": "正在啟動 ComfyUI", "troubleshoot": "疑難排解" };
const settingsCategories = { "3D": "3D", "3DViewer": "3DViewer", "API Nodes": "API 節點", "About": "關於", "Appearance": "外觀", "BrushAdjustment": "筆刷調整", "Camera": "相機", "Canvas": "畫布", "Canvas Navigation": "畫布導航", "ColorPalette": "色彩調色盤", "Comfy": "Comfy", "Comfy-Desktop": "Comfy-Desktop", "ContextMenu": "右鍵選單", "Credits": "點數", "CustomColorPalettes": "自訂色彩調色盤", "DevMode": "開發者模式", "EditTokenWeight": "編輯權重", "Extension": "擴充功能", "General": "一般", "Graph": "圖形", "Group": "群組", "Keybinding": "快捷鍵綁定", "Light": "燈光", "Link": "連結", "LinkRelease": "連結釋放", "LiteGraph": "Lite Graph", "Load 3D": "載入 3D", "Locale": "語言地區", "Mask Editor": "遮罩編輯器", "Menu": "選單", "ModelLibrary": "模型庫", "Node": "節點", "Node Search Box": "節點搜尋框", "Node Widget": "節點元件", "NodeLibrary": "節點庫", "Notification Preferences": "通知偏好設定", "PlanCredits": "方案與點數", "Pointer": "指標", "Queue": "佇列", "QueueButton": "佇列按鈕", "Reroute": "重新導向", "RerouteBeta": "重新導向 Beta", "Scene": "場景", "Server": "伺服器", "Server-Config": "伺服器設定", "Settings": "設定", "Sidebar": "側邊欄", "Tree Explorer": "樹狀瀏覽器", "UV": "UV", "User": "使用者", "Validation": "驗證", "Vue Nodes": "Vue 節點", "VueNodes": "Vue 節點", "Window": "視窗", "Workflow": "工作流程" };
const shape = { "CARD": "卡片", "arrow": "箭頭", "box": "方框", "circle": "圓形", "default": "預設", "round": "圓角" };
const shortcuts = { "essentials": "基本功能", "keyboardShortcuts": "鍵盤快捷鍵", "manageShortcuts": "管理快捷鍵", "noKeybinding": "無快捷鍵綁定", "shortcuts": "快捷鍵", "subcategories": { "node": "節點", "panelControls": "面板控制", "queue": "佇列", "view": "檢視", "workflow": "工作流程" }, "viewControls": "檢視控制" };
const sideToolbar = { "assets": "資源", "backToAssets": "返回所有資源", "browseTemplates": "瀏覽範例模板", "downloads": "下載", "helpCenter": "說明中心", "labels": { "assets": "資源", "console": "控制台", "generated": "已生成", "imported": "已匯入", "menu": "選單", "models": "模型", "nodes": "節點", "queue": "佇列", "templates": "範本", "workflows": "工作流程" }, "logout": "登出", "mediaAssets": "媒體資源", "modelLibrary": "模型庫", "newBlankWorkflow": "建立新的空白工作流程", "noFilesFound": "找不到檔案", "noFilesFoundMessage": "上傳檔案或生成內容以在此查看", "noGeneratedFiles": "找不到已生成的檔案", "noImportedFiles": "找不到已匯入的檔案", "nodeLibrary": "節點庫", "nodeLibraryTab": { "groupBy": "分組依據", "groupStrategies": { "category": "類別", "categoryDesc": "依節點類別分組", "module": "模組", "moduleDesc": "依模組來源分組", "source": "來源", "sourceDesc": "依來源類型分組（核心、自訂、API）" }, "resetView": "重設檢視為預設值", "sortBy": { "alphabetical": "字母順序", "alphabeticalDesc": "在分組內以字母排序", "original": "原始順序", "originalDesc": "保持原始順序" }, "sortMode": "排序模式" }, "openWorkflow": "在本機檔案系統中開啟工作流程", "queue": "佇列", "templates": "範本", "themeToggle": "切換主題", "workflowTab": { "confirmDelete": "您確定要刪除這個工作流程嗎？", "confirmDeleteTitle": "刪除工作流程？", "confirmOverwrite": "下列檔案已存在。您要覆蓋它嗎？", "confirmOverwriteTitle": "覆蓋現有檔案？", "deleteFailed": "刪除工作流程失敗。", "deleteFailedTitle": "刪除失敗", "deleted": "工作流程已刪除", "dirtyClose": "下列檔案已被修改。您要在關閉前儲存它們嗎？", "dirtyCloseHint": "按住 Shift 可直接關閉不提示", "dirtyCloseTitle": "儲存變更？", "workflowTreeType": { "bookmarks": "書籤", "browse": "瀏覽", "open": "開啟" } }, "workflows": "工作流程" };
const subgraphStore = { "blueprintName": "子圖名稱", "confirmDelete": "此操作將永久從您的程式庫中移除藍圖", "confirmDeleteTitle": "刪除藍圖？", "hidden": "隱藏 / 巢狀參數", "hideAll": "全部隱藏", "loadFailure": "載入子圖藍圖失敗", "overwriteBlueprint": "儲存將以您的變更覆蓋目前的藍圖", "overwriteBlueprintTitle": "覆蓋現有藍圖？", "promoteOutsideSubgraph": "不在子圖中時無法提升小工具", "publish": "發佈子圖", "publishSuccess": "已儲存至節點庫", "publishSuccessMessage": "您可以在節點庫的「子圖藍圖」中找到您的子圖藍圖", "saveBlueprint": "將子圖儲存到資料庫", "showAll": "顯示全部", "showRecommended": "顯示建議的小工具", "shown": "在節點上顯示" };
const subscription = { "addApiCredits": "新增 API 點數", "addCredits": "新增點數", "benefits": { "benefit1": "合作節點每月點數 — 需要時可隨時加值", "benefit2": "每項任務最多運行 30 分鐘" }, "beta": "測試版", "comfyCloud": "Comfy Cloud", "expiresDate": "將於 {date} 到期", "invoiceHistory": "發票記錄", "learnMore": "了解更多", "manageSubscription": "管理訂閱", "messageSupport": "聯繫客服", "monthlyBonusDescription": "每月點數獎勵", "monthlyCreditsRollover": "這些點數將結轉至下個月", "nextBillingCycle": "下個計費週期", "partnerNodesBalance": "「合作夥伴節點」點數餘額", "partnerNodesCredits": "合作節點點數", "partnerNodesDescription": "用於執行商業/專有模型", "perMonth": "美元 / 月", "prepaidCreditsInfo": "單獨購買且不會過期的點數", "prepaidDescription": "預付點數", "renewsDate": "將於 {date} 續訂", "required": { "subscribe": "訂閱", "title": "訂閱", "waitingForSubscription": "請在新分頁中完成訂閱。完成後我們會自動偵測！" }, "subscribeNow": "立即訂閱", "subscribeToComfyCloud": "訂閱 Comfy Cloud", "subscribeToRun": "訂閱", "subscribeToRunFull": "訂閱運行方案", "title": "訂閱方案", "titleUnsubscribed": "訂閱 Comfy Cloud", "totalCredits": "總點數", "viewMoreDetails": "查看更多詳情", "viewUsageHistory": "檢視使用記錄", "yourPlanIncludes": "您的方案包含：" };
const tabMenu = { "addToBookmarks": "加入書籤", "closeOtherTabs": "關閉其他分頁", "closeTab": "關閉分頁", "closeTabsToLeft": "關閉左側分頁", "closeTabsToRight": "關閉右側分頁", "duplicateTab": "複製分頁", "removeFromBookmarks": "從書籤移除" };
const templateWorkflows = { "activeFilters": "篩選條件：", "categories": "分類", "category": { "3D": "3D", "All": "所有範本", "Area Composition": "區域合成", "Audio": "音訊", "Basics": "基礎", "ComfyUI Examples": "ComfyUI 範例", "ControlNet": "ControlNet", "Custom Nodes": "自訂節點", "Extensions": "擴充功能", "Flux": "Flux", "Generation Type": "生成類型", "GettingStarted": "入門指南", "Image": "圖片", "Image API": "圖片 API", "LLM API": "LLM API", "LLMs": "LLMs", "Partner Nodes": "合作節點", "Upscaling": "放大", "Video": "影片", "Video API": "影片 API" }, "error": { "templateNotFound": '找不到範本 "{templateName}"' }, "loading": "正在載入範本...", "loadingMore": "載入更多範本...", "modelFilter": "模型篩選", "modelsSelected": "{count} 個模型", "noResults": "找不到範本", "noResultsHint": "請嘗試調整您的搜尋或篩選條件", "resetFilters": "清除篩選", "resultsCount": "顯示 {count} 個範本（共 {total} 個）", "runsOnFilter": "運行於", "runsOnSelected": "{count} 次運行於", "searchPlaceholder": "搜尋範本...", "sort": { "alphabetical": "A → Z", "default": "預設", "modelSizeLowToHigh": "模型大小 (低到高)", "newest": "最新", "recommended": "推薦", "searchPlaceholder": "搜尋...", "vramLowToHigh": "VRAM 使用量 (低到高)" }, "sorting": "排序依據", "title": "從範本開始", "useCasesSelected": "{count} 個使用案例" };
const toastMessages = { "cannotCreateSubgraph": "無法建立子圖", "couldNotDetermineFileType": "無法判斷檔案類型", "dropFileError": "無法處理拖放項目：{error}", "emptyCanvas": "畫布為空", "errorCopyImage": "複製圖片時發生錯誤：{error}", "errorLoadingModel": "載入模型時發生錯誤", "errorSaveSetting": "儲存設定 {id} 時發生錯誤：{err}", "exportSuccess": "已成功將模型匯出為 {format}", "failedExecutionPathResolution": "無法解析所選節點的路徑", "failedToAccessBillingPortal": "無法存取帳單入口", "failedToApplyTexture": "套用材質失敗", "failedToConvertToSubgraph": "轉換項目為子圖失敗", "failedToCreateCustomer": "建立客戶失敗：{error}", "failedToDownloadFile": "檔案下載失敗", "failedToExportModel": "無法將模型匯出為 {format}", "failedToFetchBalance": "取得餘額失敗：{error}", "failedToFetchLogs": "無法取得伺服器日誌", "failedToFetchSubscription": "無法取得訂閱狀態：{error}", "failedToInitializeLoad3dViewer": "無法初始化 3D 檢視器", "failedToInitiateCreditPurchase": "啟動點數購買失敗：{error}", "failedToInitiateSubscription": "無法啟用訂閱：{error}", "failedToLoadBackgroundImage": "無法載入背景圖片", "failedToLoadModel": "無法載入 3D 模型", "failedToPurchaseCredits": "購買點數失敗：{error}", "failedToQueue": "加入佇列失敗", "fileLoadError": "無法在 {fileName} 中找到工作流程", "fileUploadFailed": "檔案上傳失敗", "interrupted": "執行已被中斷", "migrateToLitegraphReroute": "重導節點將於未來版本移除。點擊以遷移至 litegraph 原生重導。", "modelLoadedSuccessfully": "3D 模型載入成功", "no3dScene": "沒有 3D 場景可套用材質", "no3dSceneToExport": "沒有 3D 場景可匯出", "noTemplatesToExport": "沒有可匯出的範本", "nodeDefinitionsUpdated": "節點定義已更新", "nothingSelected": "未選取任何項目", "nothingToGroup": "沒有項目可分組", "nothingToQueue": "沒有項目可加入佇列", "pendingTasksDeleted": "待處理任務已刪除", "pleaseSelectNodesToGroup": "請選擇要建立群組的節點（或其他群組）", "pleaseSelectOutputNodes": "請選擇輸出節點", "unableToGetModelFilePath": "無法取得模型檔案路徑", "unauthorizedDomain": "您的網域 {domain} 未被授權使用此服務。請聯絡 {email} 以將您的網域加入白名單。", "updateRequested": "已請求更新", "useApiKeyTip": "提示：無法正常登入？請使用 Comfy API 金鑰選項。", "userNotAuthenticated": "使用者未驗證" };
const userSelect = { "enterUsername": "輸入用戶名稱", "existingUser": "現有用戶", "newUser": "新用戶", "next": "下一步", "selectUser": "選擇用戶" };
const userSettings = { "email": "電子郵件", "name": "名稱", "notSet": "未設定", "provider": "登入提供者", "title": "使用者設定", "updatePassword": "更新密碼" };
const validation = { "descriptionRequired": "說明為必填項目", "invalidEmail": "無效的電子郵件地址", "length": "必須為 {length} 個字元", "maxLength": "不得超過 {length} 個字元", "minLength": "至少需有 {length} 個字元", "password": { "lowercase": "必須包含至少一個小寫字母", "match": "密碼必須相符", "minLength": "必須介於 8 到 32 個字元之間", "number": "必須包含至少一個數字", "requirements": "密碼要求", "special": "必須包含至少一個特殊字元", "uppercase": "必須包含至少一個大寫字母" }, "personalDataConsentRequired": "您必須同意我們處理您的個人資料。", "prefix": "必須以 {prefix} 開頭", "required": "必填" };
const versionMismatchWarning = { "dismiss": "關閉", "frontendNewer": "前端版本 {frontendVersion} 可能與後端版本 {backendVersion} 不相容。", "frontendOutdated": "前端版本 {frontendVersion} 已過時。後端需要版本 {requiredVersion} 或更高版本。", "title": "版本相容性警告", "updateFrontend": "更新前端" };
const vueNodesBanner = { "tryItOut": "試試看" };
const vueNodesMigration = { "button": "開啟設定", "message": "偏好經典節點設計？" };
const welcome = { "getStarted": "開始使用", "title": "歡迎使用 ComfyUI" };
const whatsNewPopup = { "learnMore": "了解更多", "noReleaseNotes": "沒有可用的發行說明。" };
const widgets = { "selectModel": "選擇模型", "uploadSelect": { "placeholder": "選擇...", "placeholderAudio": "選擇音訊...", "placeholderImage": "選擇圖片...", "placeholderModel": "選擇模型...", "placeholderUnknown": "選擇媒體...", "placeholderVideo": "選擇影片..." } };
const workflowService = { "enterFilename": "輸入檔案名稱", "exportWorkflow": "匯出工作流程", "saveWorkflow": "儲存工作流程" };
const zoomControls = { "hideMinimap": "隱藏小地圖", "label": "縮放控制", "showMinimap": "顯示小地圖", "zoomToFit": "縮放至適合大小" };
const main = {
  actionbar,
  apiNodesCostBreakdown,
  apiNodesSignInDialog,
  assetBrowser,
  auth,
  breadcrumbsMenu,
  clipboard,
  cloudFooter_needHelp,
  cloudForgotPassword_backToLogin,
  cloudForgotPassword_didntReceiveEmail,
  cloudForgotPassword_emailLabel,
  cloudForgotPassword_emailPlaceholder,
  cloudForgotPassword_emailRequired,
  cloudForgotPassword_instructions,
  cloudForgotPassword_passwordResetError,
  cloudForgotPassword_passwordResetSent,
  cloudForgotPassword_sendResetLink,
  cloudForgotPassword_title,
  cloudOnboarding,
  cloudPrivateBeta_desc,
  cloudPrivateBeta_title,
  cloudSorryContactSupport_title,
  cloudStart_desc,
  cloudStart_download,
  cloudStart_explain,
  cloudStart_learnAboutButton,
  cloudStart_title,
  cloudStart_wantToRun,
  cloudSurvey_steps_familiarity,
  cloudSurvey_steps_industry,
  cloudSurvey_steps_making,
  cloudSurvey_steps_purpose,
  cloudWaitlist_contactLink,
  cloudWaitlist_questionsText,
  color,
  commands,
  contextMenu,
  credits,
  dataTypes,
  desktopDialogs,
  desktopMenu,
  desktopStart,
  desktopUpdate,
  downloadGit,
  electronFileDownload,
  errorDialog,
  g,
  graphCanvasMenu,
  groupNode,
  helpCenter,
  icon,
  install,
  issueReport,
  load3d,
  maintenance,
  manager,
  maskEditor,
  mediaAsset,
  menu,
  menuLabels,
  minimap,
  missingModelsDialog,
  nodeCategories,
  nodeHelpPage,
  nodeTemplates,
  notSupported,
  releaseToast,
  selectionToolbox,
  serverConfig,
  serverConfigCategories,
  serverConfigItems,
  serverStart,
  settingsCategories,
  shape,
  shortcuts,
  sideToolbar,
  subgraphStore,
  subscription,
  tabMenu,
  templateWorkflows,
  toastMessages,
  userSelect,
  userSettings,
  validation,
  versionMismatchWarning,
  vueNodesBanner,
  vueNodesMigration,
  welcome,
  whatsNewPopup,
  widgets,
  workflowService,
  zoomControls
};
export {
  actionbar,
  apiNodesCostBreakdown,
  apiNodesSignInDialog,
  assetBrowser,
  auth,
  breadcrumbsMenu,
  clipboard,
  cloudFooter_needHelp,
  cloudForgotPassword_backToLogin,
  cloudForgotPassword_didntReceiveEmail,
  cloudForgotPassword_emailLabel,
  cloudForgotPassword_emailPlaceholder,
  cloudForgotPassword_emailRequired,
  cloudForgotPassword_instructions,
  cloudForgotPassword_passwordResetError,
  cloudForgotPassword_passwordResetSent,
  cloudForgotPassword_sendResetLink,
  cloudForgotPassword_title,
  cloudOnboarding,
  cloudPrivateBeta_desc,
  cloudPrivateBeta_title,
  cloudSorryContactSupport_title,
  cloudStart_desc,
  cloudStart_download,
  cloudStart_explain,
  cloudStart_learnAboutButton,
  cloudStart_title,
  cloudStart_wantToRun,
  cloudSurvey_steps_familiarity,
  cloudSurvey_steps_industry,
  cloudSurvey_steps_making,
  cloudSurvey_steps_purpose,
  cloudWaitlist_contactLink,
  cloudWaitlist_questionsText,
  color,
  commands,
  contextMenu,
  credits,
  dataTypes,
  main as default,
  desktopDialogs,
  desktopMenu,
  desktopStart,
  desktopUpdate,
  downloadGit,
  electronFileDownload,
  errorDialog,
  g,
  graphCanvasMenu,
  groupNode,
  helpCenter,
  icon,
  install,
  issueReport,
  load3d,
  maintenance,
  manager,
  maskEditor,
  mediaAsset,
  menu,
  menuLabels,
  minimap,
  missingModelsDialog,
  nodeCategories,
  nodeHelpPage,
  nodeTemplates,
  notSupported,
  releaseToast,
  selectionToolbox,
  serverConfig,
  serverConfigCategories,
  serverConfigItems,
  serverStart,
  settingsCategories,
  shape,
  shortcuts,
  sideToolbar,
  subgraphStore,
  subscription,
  tabMenu,
  templateWorkflows,
  toastMessages,
  userSelect,
  userSettings,
  validation,
  versionMismatchWarning,
  vueNodesBanner,
  vueNodesMigration,
  welcome,
  whatsNewPopup,
  widgets,
  workflowService,
  zoomControls
};
//# sourceMappingURL=main-DDqR5EuX.js.map
