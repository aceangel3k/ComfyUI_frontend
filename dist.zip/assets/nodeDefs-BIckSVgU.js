const APG = { "display_name": "適応的投影ガイダンス", "inputs": { "eta": { "name": "イータ", "tooltip": "並列ガイダンスベクトルのスケールを制御します。設定値1でデフォルトのCFG動作になります。" }, "model": { "name": "モデル" }, "momentum": { "name": "モーメンタム", "tooltip": "拡散中のガイダンスの移動平均を制御します。設定値0で無効になります。" }, "norm_threshold": { "name": "正規化閾値", "tooltip": "ガイダンスベクトルをこの値に正規化します。設定値0で正規化は無効になります。" } }, "outputs": { "0": { "tooltip": null } } };
const AddNoise = { "display_name": "ノイズを追加", "inputs": { "latent_image": { "name": "潜在イメージ" }, "model": { "name": "モデル" }, "noise": { "name": "ノイズ" }, "sigmas": { "name": "シグマ" } } };
const AlignYourStepsScheduler = { "display_name": "ステップを整列", "inputs": { "denoise": { "name": "ノイズ除去" }, "model_type": { "name": "モデルタイプ" }, "steps": { "name": "ステップ" } }, "outputs": { "0": { "tooltip": null } } };
const AudioAdjustVolume = { "display_name": "オーディオ音量調整", "inputs": { "audio": { "name": "オーディオ" }, "volume": { "name": "音量", "tooltip": "デシベル(dB)単位での音量調整。0 = 変更なし、+6 = 2倍、-6 = 半分、など" } } };
const AudioConcat = { "description": "指定された方向にaudio1をaudio2に連結します。", "display_name": "オーディオ連結", "inputs": { "audio1": { "name": "オーディオ1" }, "audio2": { "name": "オーディオ2" }, "direction": { "name": "方向", "tooltip": "audio2をaudio1の後ろに追加するか前に追加するか。" } } };
const AudioEncoderEncode = { "display_name": "オーディオエンコーダーエンコード", "inputs": { "audio": { "name": "オーディオ" }, "audio_encoder": { "name": "オーディオエンコーダー" } }, "outputs": { "0": { "tooltip": null } } };
const AudioEncoderLoader = { "display_name": "オーディオエンコーダーローダー", "inputs": { "audio_encoder_name": { "name": "オーディオエンコーダー名" } }, "outputs": { "0": { "tooltip": null } } };
const AudioMerge = { "description": "2つのオーディオトラックを波形を重ねて結合します。", "display_name": "オーディオ結合", "inputs": { "audio1": { "name": "オーディオ1" }, "audio2": { "name": "オーディオ2" }, "merge_method": { "name": "結合方法", "tooltip": "オーディオ波形を結合するために使用する方法。" } } };
const BasicGuider = { "display_name": "基本ガイダー", "inputs": { "conditioning": { "name": "コンディショニング" }, "model": { "name": "モデル" } } };
const BasicScheduler = { "display_name": "基本スケジューラー", "inputs": { "denoise": { "name": "ノイズ除去" }, "model": { "name": "モデル" }, "scheduler": { "name": "スケジューラ" }, "steps": { "name": "ステップ" } } };
const BetaSamplingScheduler = { "display_name": "ベータサンプリングスケジューラー", "inputs": { "alpha": { "name": "アルファ" }, "beta": { "name": "ベータ" }, "model": { "name": "モデル" }, "steps": { "name": "ステップ" } } };
const ByteDanceFirstLastFrameNode = { "description": "プロンプトと最初・最後のフレームを使用して動画を生成します。", "display_name": "ByteDance 最初-最後フレームから動画生成", "inputs": { "aspect_ratio": { "name": "アスペクト比", "tooltip": "出力動画のアスペクト比。" }, "camera_fixed": { "name": "カメラ固定", "tooltip": "カメラを固定するかどうかを指定します。プラットフォームはカメラを固定する指示をプロンプトに追加しますが、実際の効果を保証するものではありません。" }, "control_after_generate": { "name": "生成後の制御" }, "duration": { "name": "再生時間", "tooltip": "出力動画の再生時間（秒単位）。" }, "first_frame": { "name": "最初のフレーム", "tooltip": "動画に使用する最初のフレーム。" }, "last_frame": { "name": "最後のフレーム", "tooltip": "動画に使用する最後のフレーム。" }, "model": { "name": "モデル" }, "prompt": { "name": "プロンプト", "tooltip": "動画生成に使用するテキストプロンプト。" }, "resolution": { "name": "解像度", "tooltip": "出力動画の解像度。" }, "seed": { "name": "シード", "tooltip": "生成に使用するシード値。" }, "watermark": { "name": "ウォーターマーク", "tooltip": "動画に「AI生成」の透かしを追加するかどうか。" } }, "outputs": { "0": { "tooltip": null } } };
const ByteDanceImageEditNode = { "description": "プロンプトに基づいてAPI経由でByteDanceモデルを使用して画像を編集", "display_name": "ByteDance画像編集", "inputs": { "control_after_generate": { "name": "生成後の制御" }, "guidance_scale": { "name": "ガイダンススケール", "tooltip": "値が高いほどプロンプトに忠実な画像になります" }, "image": { "name": "画像", "tooltip": "編集するベース画像" }, "model": { "name": "モデル" }, "prompt": { "name": "プロンプト", "tooltip": "画像編集の指示" }, "seed": { "name": "シード", "tooltip": "生成に使用するシード値" }, "watermark": { "name": "透かし", "tooltip": "画像に「AI生成」の透かしを追加するかどうか" } }, "outputs": { "0": { "tooltip": null } } };
const ByteDanceImageNode = { "description": "プロンプトに基づいてAPI経由でByteDanceモデルを使用して画像を生成", "display_name": "ByteDance画像", "inputs": { "control_after_generate": { "name": "生成後の制御" }, "guidance_scale": { "name": "ガイダンススケール", "tooltip": "値が高いほどプロンプトに忠実な画像になります" }, "height": { "name": "高さ", "tooltip": "画像のカスタム高さ。`size_preset`が`Custom`に設定されている場合のみ有効" }, "model": { "name": "モデル" }, "prompt": { "name": "プロンプト", "tooltip": "画像生成に使用するテキストプロンプト" }, "seed": { "name": "シード", "tooltip": "生成に使用するシード値" }, "size_preset": { "name": "サイズプリセット", "tooltip": "推奨サイズを選択。カスタムを選択すると下記の幅と高さを使用します" }, "watermark": { "name": "透かし", "tooltip": "画像に「AI生成」の透かしを追加するかどうか" }, "width": { "name": "幅", "tooltip": "画像のカスタム幅。`size_preset`が`Custom`に設定されている場合のみ有効" } }, "outputs": { "0": { "tooltip": null } } };
const ByteDanceImageReferenceNode = { "description": "プロンプトと参照画像を使用して動画を生成", "display_name": "ByteDance参照画像から動画生成", "inputs": { "aspect_ratio": { "name": "アスペクト比", "tooltip": "出力動画のアスペクト比" }, "control_after_generate": { "name": "control after generate" }, "duration": { "name": "再生時間", "tooltip": "出力動画の再生時間（秒）" }, "images": { "name": "画像", "tooltip": "1〜4枚の画像" }, "model": { "name": "モデル" }, "prompt": { "name": "プロンプト", "tooltip": "動画生成に使用するテキストプロンプト" }, "resolution": { "name": "解像度", "tooltip": "出力動画の解像度" }, "seed": { "name": "seed", "tooltip": "生成に使用するシード値。" }, "watermark": { "name": "watermark", "tooltip": "動画に「AI生成」の透かしを追加するかどうか。" } }, "outputs": { "0": { "tooltip": null } } };
const ByteDanceImageToVideoNode = { "description": "画像とプロンプトに基づいてAPI経由でByteDanceモデルを使用して動画を生成", "display_name": "ByteDance Image to Video", "inputs": { "aspect_ratio": { "name": "aspect_ratio", "tooltip": "出力動画のアスペクト比。" }, "camera_fixed": { "name": "camera_fixed", "tooltip": "カメラを固定するかどうかを指定します。プラットフォームはカメラ固定の指示をプロンプトに追加しますが、実際の効果を保証するものではありません。" }, "control_after_generate": { "name": "control after generate" }, "duration": { "name": "duration", "tooltip": "出力動画の長さ（秒単位）。" }, "image": { "name": "image", "tooltip": "動画の最初のフレームとして使用する画像。" }, "model": { "name": "model" }, "prompt": { "name": "prompt", "tooltip": "動画生成に使用するテキストプロンプト。" }, "resolution": { "name": "resolution", "tooltip": "出力動画の解像度。" }, "seed": { "name": "seed", "tooltip": "生成に使用するシード値。" }, "watermark": { "name": "watermark", "tooltip": "動画に「AI生成」の透かしを追加するかどうか。" } }, "outputs": { "0": { "tooltip": null } } };
const ByteDanceSeedreamNode = { "description": "最大4K解像度での統一されたテキストから画像への生成と精密な単文編集。", "display_name": "ByteDance Seedream 4", "inputs": { "control_after_generate": { "name": "生成後の制御" }, "fail_on_partial": { "name": "fail_on_partial", "tooltip": "有効にすると、要求された画像の一部が欠落しているかエラーが返された場合に実行を中止します。" }, "height": { "name": "height", "tooltip": "画像のカスタム高さ。`size_preset`が`Custom`に設定されている場合のみ有効です" }, "image": { "name": "image", "tooltip": "画像から画像への生成用の入力画像。単一または複数参照生成用に1〜10枚の画像リスト。" }, "max_images": { "name": "max_images", "tooltip": "sequential_image_generation='auto'時の最大生成画像数。総画像数（入力＋生成）は15を超えることはできません。" }, "model": { "name": "model", "tooltip": "モデル名" }, "prompt": { "name": "prompt", "tooltip": "画像の作成または編集のためのテキストプロンプト。" }, "seed": { "name": "seed", "tooltip": "生成に使用するシード値。" }, "sequential_image_generation": { "name": "sequential_image_generation", "tooltip": "グループ画像生成モード。'disabled'は単一画像を生成。'auto'はモデルが複数の関連画像（例：ストーリーシーン、キャラクターバリエーション）を生成するかどうかを決定します。" }, "size_preset": { "name": "size_preset", "tooltip": "推奨サイズを選択。カスタムを選択すると、下記の幅と高さを使用します。" }, "watermark": { "name": "watermark", "tooltip": "画像に「AI生成」の透かしを追加するかどうか。" }, "width": { "name": "width", "tooltip": "画像のカスタム幅。`size_preset`が`Custom`に設定されている場合のみ有効です" } }, "outputs": { "0": { "tooltip": null } } };
const ByteDanceTextToVideoNode = { "description": "プロンプトに基づきAPI経由でByteDanceモデルを使用して動画を生成", "display_name": "ByteDance テキストから動画へ", "inputs": { "aspect_ratio": { "name": "アスペクト比", "tooltip": "出力動画のアスペクト比。" }, "camera_fixed": { "name": "カメラ固定", "tooltip": "カメラを固定するかどうかを指定します。プラットフォームはカメラを固定する指示をプロンプトに追加しますが、実際の効果は保証されません。" }, "control_after_generate": { "name": "生成後の制御" }, "duration": { "name": "長さ", "tooltip": "出力動画の長さ（秒単位）。" }, "model": { "name": "モデル" }, "prompt": { "name": "プロンプト", "tooltip": "動画生成に使用するテキストプロンプト。" }, "resolution": { "name": "解像度", "tooltip": "出力動画の解像度。" }, "seed": { "name": "シード", "tooltip": "生成に使用するシード値。" }, "watermark": { "name": "透かし", "tooltip": "動画に「AI生成」の透かしを追加するかどうか。" } }, "outputs": { "0": { "tooltip": null } } };
const CFGGuider = { "display_name": "CFGガイダー", "inputs": { "cfg": { "name": "cfg" }, "model": { "name": "モデル" }, "negative": { "name": "ネガティブ" }, "positive": { "name": "ポジティブ" } } };
const CFGNorm = { "display_name": "CFG正規化", "inputs": { "model": { "name": "モデル" }, "strength": { "name": "強度" } }, "outputs": { "0": { "name": "修正済みモデル", "tooltip": null } } };
const CFGZeroStar = { "display_name": "CFGZeroStar", "inputs": { "model": { "name": "モデル" } }, "outputs": { "0": { "name": "パッチ済みモデル", "tooltip": null } } };
const CLIPAttentionMultiply = { "display_name": "CLIP注意の乗算", "inputs": { "clip": { "name": "clip" }, "k": { "name": "k" }, "out": { "name": "出力" }, "q": { "name": "q" }, "v": { "name": "v" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPLoader = { "description": "[レシピ]\n\nstable_diffusion: clip-l\nstable_cascade: clip-g\nsd3: t5 / clip-g / clip-l\nstable_audio: t5\nmochi: t5\ncosmos: old t5 xxl", "display_name": "CLIPを読み込む", "inputs": { "clip_name": { "name": "clip名" }, "device": { "name": "デバイス" }, "type": { "name": "タイプ" } } };
const CLIPMergeAdd = { "display_name": "CLIPマージ追加", "inputs": { "clip1": { "name": "clip1" }, "clip2": { "name": "clip2" } } };
const CLIPMergeSimple = { "display_name": "CLIPマージシンプル", "inputs": { "clip1": { "name": "clip1" }, "clip2": { "name": "clip2" }, "ratio": { "name": "比率" } } };
const CLIPMergeSubtract = { "display_name": "CLIPマージ減算", "inputs": { "clip1": { "name": "clip1" }, "clip2": { "name": "clip2" }, "multiplier": { "name": "乗数" } } };
const CLIPSave = { "display_name": "CLIPを保存", "inputs": { "clip": { "name": "clip" }, "filename_prefix": { "name": "ファイル名プレフィックス" } } };
const CLIPSetLastLayer = { "display_name": "CLIPの最終層を設定", "inputs": { "clip": { "name": "クリップ" }, "stop_at_clip_layer": { "name": "クリップ_レイヤーで停止" } } };
const CLIPTextEncode = { "description": "テキストプロンプトをCLIPモデルを使用してエンコードし、特定の画像を生成するために拡散モデルをガイドするために使用できる埋め込みに変換します。", "display_name": "CLIPテキストエンコード（プロンプト）", "inputs": { "clip": { "name": "クリップ", "tooltip": "テキストのエンコードに使用されるCLIPモデル。" }, "text": { "name": "テキスト", "tooltip": "エンコードするテキスト。" } }, "outputs": { "0": { "tooltip": "拡散モデルをガイドするために使用される埋め込まれたテキストを含む条件付け。" } } };
const CLIPTextEncodeControlnet = { "display_name": "CLIPテキストエンコードコントロールネット", "inputs": { "clip": { "name": "クリップ" }, "conditioning": { "name": "コンディショニング" }, "text": { "name": "テキスト" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeFlux = { "display_name": "CLIPテキストエンコードフラックス", "inputs": { "clip": { "name": "クリップ" }, "clip_l": { "name": "クリップ_l" }, "guidance": { "name": "ガイダンス" }, "t5xxl": { "name": "t5xxl" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeHiDream = { "display_name": "CLIPTextEncodeHiDream", "inputs": { "clip": { "name": "clip" }, "clip_g": { "name": "clip_g" }, "clip_l": { "name": "clip_l" }, "llama": { "name": "llama" }, "t5xxl": { "name": "t5xxl" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeHunyuanDiT = { "display_name": "CLIPテキストエンコードフンユアンDiT", "inputs": { "bert": { "name": "bert" }, "clip": { "name": "クリップ" }, "mt5xl": { "name": "mt5xl" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeLumina2 = { "description": "CLIPモデルを使用してシステムプロンプトとユーザープロンプトをエンコードし、特定の画像の生成をガイドするために使用できる埋め込みを生成します。", "display_name": "CLIP Text Encode for Lumina2", "inputs": { "clip": { "name": "clip", "tooltip": "テキストのエンコードに使用されるCLIPモデル。" }, "system_prompt": { "name": "system_prompt", "tooltip": "Lumina2は2種類のシステムプロンプトを提供します：Superior: あなたは、テキストプロンプトまたはユーザープロンプトに基づいて優れた画像と画像テキストの整列度を生成するためのアシスタントです。 Alignment: あなたは、テキストプロンプトに基づいて高品質の画像と最高度の画像テキストの整列度を生成するためのアシスタントです。" }, "user_prompt": { "name": "user_prompt", "tooltip": "エンコードするテキスト。" } }, "outputs": { "0": { "tooltip": "拡散モデルをガイドするために使用される埋め込まれたテキストを含む条件付け。" } } };
const CLIPTextEncodePixArtAlpha = { "description": "テキストをエンコードし、PixArt Alphaの解像度条件を設定します。PixArt Sigmaには適用されません。", "display_name": "CLIPTextEncodePixArtAlpha", "inputs": { "clip": { "name": "clip" }, "height": { "name": "高さ" }, "text": { "name": "テキスト" }, "width": { "name": "幅" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeSD3 = { "display_name": "CLIPテキストエンコードSD3", "inputs": { "clip": { "name": "クリップ" }, "clip_g": { "name": "クリップ_g" }, "clip_l": { "name": "クリップ_l" }, "empty_padding": { "name": "空のパディング" }, "t5xxl": { "name": "t5xxl" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeSDXL = { "display_name": "CLIPテキストエンコードSDXL", "inputs": { "clip": { "name": "クリップ" }, "crop_h": { "name": "crop_h" }, "crop_w": { "name": "crop_w" }, "height": { "name": "高さ" }, "target_height": { "name": "目標の高さ" }, "target_width": { "name": "目標の幅" }, "text_g": { "name": "テキスト_g" }, "text_l": { "name": "テキスト_l" }, "width": { "name": "幅" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeSDXLRefiner = { "display_name": "CLIPテキストエンコードSDXLリファイナー", "inputs": { "ascore": { "name": "ascore" }, "clip": { "name": "クリップ" }, "height": { "name": "高さ" }, "text": { "name": "テキスト" }, "width": { "name": "幅" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPVisionEncode = { "display_name": "CLIPビジョンエンコード", "inputs": { "clip_vision": { "name": "クリップビジョン" }, "crop": { "name": "クロップ" }, "image": { "name": "画像" } } };
const CLIPVisionLoader = { "display_name": "CLIPビジョンを読み込む", "inputs": { "clip_name": { "name": "クリップ名" } } };
const Canny = { "display_name": "キャニー", "inputs": { "high_threshold": { "name": "高い閾値" }, "image": { "name": "イメージ" }, "low_threshold": { "name": "低い閾値" } }, "outputs": { "0": { "tooltip": null } } };
const CaseConverter = { "display_name": "ケースコンバーター", "inputs": { "mode": { "name": "モード" }, "string": { "name": "文字列" } }, "outputs": { "0": { "tooltip": null } } };
const CheckpointLoader = { "display_name": "設定でチェックポイントを読み込む（非推奨）", "inputs": { "ckpt_name": { "name": "ckpt名" }, "config_name": { "name": "設定名" } } };
const CheckpointLoaderSimple = { "description": "拡散モデルのチェックポイントを読み込みます。拡散モデルは潜在変数のノイズを除去するために使用されます。", "display_name": "チェックポイントを読み込む", "inputs": { "ckpt_name": { "name": "ckpt名", "tooltip": "読み込むチェックポイント（モデル）の名前。" } }, "outputs": { "0": { "tooltip": "潜在変数のデノイズに使用されるモデル。" }, "1": { "tooltip": "テキストプロンプトをエンコードするために使用されるCLIPモデル。" }, "2": { "tooltip": "画像を潜在空間にエンコードおよびデコードするために使用されるVAEモデル。" } } };
const CheckpointSave = { "display_name": "チェックポイントを保存", "inputs": { "clip": { "name": "clip" }, "filename_prefix": { "name": "ファイル名プレフィックス" }, "model": { "name": "モデル" }, "vae": { "name": "vae" } } };
const ChromaRadianceOptions = { "description": "Chroma Radianceモデルの高度なオプションを設定できます。", "display_name": "ChromaRadianceオプション", "inputs": { "end_sigma": { "name": "終了シグマ", "tooltip": "これらのオプションが有効になる最後のシグマ値。" }, "model": { "name": "モデル" }, "nerf_tile_size": { "name": "NeRFタイルサイズ", "tooltip": "デフォルトのNeRFタイルサイズを上書きできます。-1はデフォルト（32）を使用、0は非タイルモードを使用（多くのVRAMが必要な場合があります）。" }, "preserve_wrapper": { "name": "ラッパーを保持", "tooltip": "有効にすると、既存のモデル関数ラッパーが存在する場合にそれを委任します。通常は有効のままにしてください。" }, "start_sigma": { "name": "開始シグマ", "tooltip": "これらのオプションが有効になる最初のシグマ値。" } }, "outputs": { "0": { "tooltip": null } } };
const CombineHooks2 = { "display_name": "フックを組み合わせる [2]", "inputs": { "hooks_A": { "name": "フック_A" }, "hooks_B": { "name": "フック_B" } } };
const CombineHooks4 = { "display_name": "フックを組み合わせる [4]", "inputs": { "hooks_A": { "name": "フック_A" }, "hooks_B": { "name": "フック_B" }, "hooks_C": { "name": "フック_C" }, "hooks_D": { "name": "フック_D" } } };
const CombineHooks8 = { "display_name": "フックを組み合わせる [8]", "inputs": { "hooks_A": { "name": "フック_A" }, "hooks_B": { "name": "フック_B" }, "hooks_C": { "name": "フック_C" }, "hooks_D": { "name": "フック_D" }, "hooks_E": { "name": "フック_E" }, "hooks_F": { "name": "フック_F" }, "hooks_G": { "name": "フック_G" }, "hooks_H": { "name": "フック_H" } } };
const ConditioningAverage = { "display_name": "条件付け平均", "inputs": { "conditioning_from": { "name": "条件付け元" }, "conditioning_to": { "name": "条件付け先" }, "conditioning_to_strength": { "name": "条件付け先の強度" } } };
const ConditioningCombine = { "display_name": "条件付け（組み合わせ）", "inputs": { "conditioning_1": { "name": "条件付け_1" }, "conditioning_2": { "name": "条件付け_2" } } };
const ConditioningConcat = { "display_name": "条件付け（連結）", "inputs": { "conditioning_from": { "name": "条件付け元" }, "conditioning_to": { "name": "条件付け先" } } };
const ConditioningSetArea = { "display_name": "条件付け（エリア設定）", "inputs": { "conditioning": { "name": "条件付け" }, "height": { "name": "高さ" }, "strength": { "name": "強度" }, "width": { "name": "幅" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const ConditioningSetAreaPercentage = { "display_name": "条件付け（パーセンテージでエリア設定）", "inputs": { "conditioning": { "name": "条件付け" }, "height": { "name": "高さ" }, "strength": { "name": "強度" }, "width": { "name": "幅" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const ConditioningSetAreaPercentageVideo = { "display_name": "ビデオの条件設定エリアのパーセンテージ", "inputs": { "conditioning": { "name": "条件設定" }, "height": { "name": "高さ" }, "strength": { "name": "強度" }, "temporal": { "name": "時間的" }, "width": { "name": "幅" }, "x": { "name": "x" }, "y": { "name": "y" }, "z": { "name": "z" } } };
const ConditioningSetAreaStrength = { "display_name": "条件付けエリア強度", "inputs": { "conditioning": { "name": "条件付け" }, "strength": { "name": "強度" } } };
const ConditioningSetDefaultCombine = { "display_name": "条件付けデフォルト組み合わせを設定", "inputs": { "cond": { "name": "条件" }, "cond_DEFAULT": { "name": "デフォルト条件" }, "hooks": { "name": "フック" } } };
const ConditioningSetMask = { "display_name": "条件付け（マスク設定）", "inputs": { "conditioning": { "name": "条件付け" }, "mask": { "name": "マスク" }, "set_cond_area": { "name": "条件付けエリア設定" }, "strength": { "name": "強度" } } };
const ConditioningSetProperties = { "display_name": "条件付けプロパティ設定", "inputs": { "cond_NEW": { "name": "新しい条件" }, "hooks": { "name": "フック" }, "mask": { "name": "マスク" }, "set_cond_area": { "name": "条件付けエリア設定" }, "strength": { "name": "強度" }, "timesteps": { "name": "タイムステップ" } } };
const ConditioningSetPropertiesAndCombine = { "display_name": "条件付けプロパティ設定と組み合わせ", "inputs": { "cond": { "name": "条件" }, "cond_NEW": { "name": "新しい条件" }, "hooks": { "name": "フック" }, "mask": { "name": "マスク" }, "set_cond_area": { "name": "条件付けエリア設定" }, "strength": { "name": "強度" }, "timesteps": { "name": "タイムステップ" } } };
const ConditioningSetTimestepRange = { "display_name": "条件付けタイムステップ範囲", "inputs": { "conditioning": { "name": "コンディショニング" }, "end": { "name": "終了" }, "start": { "name": "開始" } } };
const ConditioningStableAudio = { "display_name": "ConditioningStableAudio", "inputs": { "negative": { "name": "ネガティブ" }, "positive": { "name": "ポジティブ" }, "seconds_start": { "name": "秒_開始" }, "seconds_total": { "name": "秒_合計" } }, "outputs": { "0": { "name": "ポジティブ" }, "1": { "name": "ネガティブ" } } };
const ConditioningTimestepsRange = { "display_name": "タイムステップ範囲", "inputs": { "end_percent": { "name": "終了パーセント" }, "start_percent": { "name": "開始パーセント" } }, "outputs": { "1": { "name": "範囲前" }, "2": { "name": "範囲後" } } };
const ConditioningZeroOut = { "display_name": "条件付けゼロアウト", "inputs": { "conditioning": { "name": "コンディショニング" } } };
const ContextWindowsManual = { "description": "コンテキストウィンドウを手動で設定します。", "display_name": "コンテキストウィンドウ（手動）", "inputs": { "closed_loop": { "name": "closed_loop", "tooltip": "コンテキストウィンドウのループを閉じるかどうか。ループスケジュールにのみ適用されます。" }, "context_length": { "name": "コンテキスト長", "tooltip": "コンテキストウィンドウの長さ。" }, "context_overlap": { "name": "コンテキストオーバーラップ", "tooltip": "コンテキストウィンドウのオーバーラップ。" }, "context_schedule": { "name": "コンテキストスケジュール", "tooltip": "コンテキストウィンドウのストライド。" }, "context_stride": { "name": "コンテキストストライド", "tooltip": "コンテキストウィンドウのストライド。均一スケジュールにのみ適用されます。" }, "dim": { "name": "dim", "tooltip": "コンテキストウィンドウを適用する次元。" }, "fuse_method": { "name": "fuse_method", "tooltip": "コンテキストウィンドウを融合するために使用する方法。" }, "model": { "name": "モデル", "tooltip": "サンプリング中にコンテキストウィンドウを適用するモデル。" } }, "outputs": { "0": { "tooltip": "サンプリング中にコンテキストウィンドウが適用されたモデル。" } } };
const ControlNetApply = { "display_name": "ControlNetを適用（旧）", "inputs": { "conditioning": { "name": "コンディショニング" }, "control_net": { "name": "コントロールネット" }, "image": { "name": "画像" }, "strength": { "name": "強度" } } };
const ControlNetApplyAdvanced = { "display_name": "ControlNetを適用", "inputs": { "control_net": { "name": "コントロールネット" }, "end_percent": { "name": "終了パーセント" }, "image": { "name": "画像" }, "negative": { "name": "ネガティブ" }, "positive": { "name": "ポジティブ" }, "start_percent": { "name": "開始パーセント" }, "strength": { "name": "強度" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "ポジティブ" }, "1": { "name": "ネガティブ" } } };
const ControlNetApplySD3 = { "display_name": "VAEでControlNetを適用", "inputs": { "control_net": { "name": "コントロールネット" }, "end_percent": { "name": "終了パーセント" }, "image": { "name": "画像" }, "negative": { "name": "ネガティブ" }, "positive": { "name": "ポジティブ" }, "start_percent": { "name": "開始パーセント" }, "strength": { "name": "強度" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "ポジティブ", "tooltip": null }, "1": { "name": "ネガティブ", "tooltip": null } } };
const ControlNetInpaintingAliMamaApply = { "display_name": "ControlNetインペインティングAliMamaを適用", "inputs": { "control_net": { "name": "コントロールネット" }, "end_percent": { "name": "終了パーセント" }, "image": { "name": "画像" }, "mask": { "name": "マスク" }, "negative": { "name": "ネガティブ" }, "positive": { "name": "ポジティブ" }, "start_percent": { "name": "開始パーセント" }, "strength": { "name": "強度" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "ポジティブ", "tooltip": null }, "1": { "name": "ネガティブ", "tooltip": null } } };
const ControlNetLoader = { "display_name": "ControlNetモデルを読み込む", "inputs": { "control_net_name": { "name": "コントロールネット名" } } };
const CosmosImageToVideoLatent = { "display_name": "CosmosImageToVideoLatent", "inputs": { "batch_size": { "name": "バッチサイズ" }, "end_image": { "name": "終了画像" }, "height": { "name": "高さ" }, "length": { "name": "長さ" }, "start_image": { "name": "開始画像" }, "vae": { "name": "vae" }, "width": { "name": "幅" } }, "outputs": { "0": { "tooltip": null } } };
const CosmosPredict2ImageToVideoLatent = { "display_name": "CosmosPredict2ImageToVideoLatent", "inputs": { "batch_size": { "name": "batch_size" }, "end_image": { "name": "end_image" }, "height": { "name": "height" }, "length": { "name": "length" }, "start_image": { "name": "start_image" }, "vae": { "name": "vae" }, "width": { "name": "width" } }, "outputs": { "0": { "tooltip": null } } };
const CreateHookKeyframe = { "display_name": "フックキーフレームを作成", "inputs": { "prev_hook_kf": { "name": "前のフックキーフレーム" }, "start_percent": { "name": "開始パーセント" }, "strength_mult": { "name": "強度倍数" } }, "outputs": { "0": { "name": "フックKF" } } };
const CreateHookKeyframesFromFloats = { "display_name": "フックキーフレームを浮動小数点から作成", "inputs": { "end_percent": { "name": "終了パーセント" }, "floats_strength": { "name": "浮動小数点数の強度" }, "prev_hook_kf": { "name": "前のフックキーフレーム" }, "print_keyframes": { "name": "キーフレームを印刷" }, "start_percent": { "name": "開始パーセント" } }, "outputs": { "0": { "name": "フックKF" } } };
const CreateHookKeyframesInterpolated = { "display_name": "フックキーフレームを補間", "inputs": { "end_percent": { "name": "end_percent" }, "interpolation": { "name": "補間" }, "keyframes_count": { "name": "キーフレーム数" }, "prev_hook_kf": { "name": "prev_hook_kf" }, "print_keyframes": { "name": "キーフレームを印刷" }, "start_percent": { "name": "start_percent" }, "strength_end": { "name": "strength_end" }, "strength_start": { "name": "strength_start" } }, "outputs": { "0": { "name": "フックKF" } } };
const CreateHookLora = { "display_name": "フックLoRAを作成", "inputs": { "lora_name": { "name": "lora_name" }, "prev_hooks": { "name": "prev_hooks" }, "strength_clip": { "name": "strength_clip" }, "strength_model": { "name": "strength_model" } } };
const CreateHookLoraModelOnly = { "display_name": "フックLoRA（モデルのみ）", "inputs": { "lora_name": { "name": "lora_name" }, "prev_hooks": { "name": "prev_hooks" }, "strength_model": { "name": "strength_model" } } };
const CreateHookModelAsLora = { "display_name": "フックモデルをLoRAとして作成", "inputs": { "ckpt_name": { "name": "ckpt_name" }, "prev_hooks": { "name": "prev_hooks" }, "strength_clip": { "name": "strength_clip" }, "strength_model": { "name": "strength_model" } } };
const CreateHookModelAsLoraModelOnly = { "display_name": "フックモデルをLoRAとして作成（モデルのみ）", "inputs": { "ckpt_name": { "name": "ckpt_name" }, "prev_hooks": { "name": "prev_hooks" }, "strength_model": { "name": "strength_model" } } };
const CreateVideo = { "description": "画像から動画を作成します。", "display_name": "動画を作成", "inputs": { "audio": { "name": "オーディオ", "tooltip": "動画に追加するオーディオです。" }, "fps": { "name": "fps" }, "images": { "name": "画像", "tooltip": "動画を作成するための画像です。" } }, "outputs": { "0": { "tooltip": null } } };
const CropMask = { "display_name": "マスクをトリミング", "inputs": { "height": { "name": "高さ" }, "mask": { "name": "マスク" }, "width": { "name": "幅" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const DiffControlNetLoader = { "display_name": "ControlNetモデルを読み込む（diff）", "inputs": { "control_net_name": { "name": "control_net_name" }, "model": { "name": "モデル" } } };
const DifferentialDiffusion = { "display_name": "差分拡散", "inputs": { "model": { "name": "モデル" }, "strength": { "name": "strength" } }, "outputs": { "0": { "tooltip": null } } };
const DiffusersLoader = { "display_name": "ディフューザーを読み込む", "inputs": { "model_path": { "name": "モデルパス" } } };
const DisableNoise = { "display_name": "ノイズを無効にする" };
const DualCFGGuider = { "display_name": "デュアルCFGガイダー", "inputs": { "cfg_cond2_negative": { "name": "cfg_cond2_negative" }, "cfg_conds": { "name": "cfg_conds" }, "cond1": { "name": "cond1" }, "cond2": { "name": "cond2" }, "model": { "name": "モデル" }, "negative": { "name": "ネガティブ" }, "style": { "name": "style" } } };
const DualCLIPLoader = { "description": "[レシピ]\n\nsdxl: clip-l, clip-g\nsd3: clip-l, clip-g / clip-l, t5 / clip-g, t5\nflux: clip-l, t5", "display_name": "デュアルCLIPを読み込む", "inputs": { "clip_name1": { "name": "clip_name1" }, "clip_name2": { "name": "clip_name2" }, "device": { "name": "デバイス" }, "type": { "name": "タイプ" } } };
const EasyCache = { "description": "ネイティブEasyCache実装。", "display_name": "EasyCache", "inputs": { "end_percent": { "name": "end_percent", "tooltip": "EasyCacheの使用を終了する相対サンプリングステップ。" }, "model": { "name": "model", "tooltip": "EasyCacheを追加するモデル。" }, "reuse_threshold": { "name": "reuse_threshold", "tooltip": "キャッシュされたステップを再利用するためのしきい値。" }, "start_percent": { "name": "start_percent", "tooltip": "EasyCacheの使用を開始する相対サンプリングステップ。" }, "verbose": { "name": "verbose", "tooltip": "詳細情報をログに記録するかどうか。" } }, "outputs": { "0": { "tooltip": "EasyCacheが適用されたモデル。" } } };
const EmptyAceStepLatentAudio = { "display_name": "EmptyAceStepLatentAudio", "inputs": { "batch_size": { "name": "batch_size", "tooltip": "バッチ内の潜在画像の数。" }, "seconds": { "name": "seconds" } }, "outputs": { "0": { "tooltip": null } } };
const EmptyAudio = { "display_name": "空のオーディオ", "inputs": { "channels": { "name": "channels", "tooltip": "オーディオチャンネル数（1:モノラル、2:ステレオ）。" }, "duration": { "name": "duration", "tooltip": "空のオーディオクリップの長さ（秒単位）" }, "sample_rate": { "name": "sample_rate", "tooltip": "空のオーディオクリップのサンプルレート。" } } };
const EmptyChromaRadianceLatentImage = { "display_name": "EmptyChromaRadianceLatentImage", "inputs": { "batch_size": { "name": "batch_size" }, "height": { "name": "height" }, "width": { "name": "width" } }, "outputs": { "0": { "tooltip": null } } };
const EmptyCosmosLatentVideo = { "display_name": "EmptyCosmosLatentVideo", "inputs": { "batch_size": { "name": "バッチサイズ" }, "height": { "name": "高さ" }, "length": { "name": "長さ" }, "width": { "name": "幅" } }, "outputs": { "0": { "tooltip": null } } };
const EmptyHunyuanImageLatent = { "display_name": "EmptyHunyuanImageLatent", "inputs": { "batch_size": { "name": "batch_size" }, "height": { "name": "height" }, "width": { "name": "width" } }, "outputs": { "0": { "tooltip": null } } };
const EmptyHunyuanLatentVideo = { "display_name": "EmptyHunyuanLatentVideo", "inputs": { "batch_size": { "name": "バッチサイズ" }, "height": { "name": "高さ" }, "length": { "name": "長さ" }, "width": { "name": "幅" } }, "outputs": { "0": { "tooltip": null } } };
const EmptyImage = { "display_name": "空の画像", "inputs": { "batch_size": { "name": "バッチサイズ" }, "color": { "name": "色" }, "height": { "name": "高さ" }, "width": { "name": "幅" } } };
const EmptyLTXVLatentVideo = { "display_name": "空のLTXV潜在ビデオ", "inputs": { "batch_size": { "name": "バッチサイズ" }, "height": { "name": "高さ" }, "length": { "name": "長さ" }, "width": { "name": "幅" } }, "outputs": { "0": { "tooltip": null } } };
const EmptyLatentAudio = { "display_name": "空の潜在音声", "inputs": { "batch_size": { "name": "バッチサイズ", "tooltip": "バッチ内の潜在画像の数。" }, "seconds": { "name": "秒" } } };
const EmptyLatentHunyuan3Dv2 = { "display_name": "EmptyLatentHunyuan3Dv2", "inputs": { "batch_size": { "name": "バッチサイズ", "tooltip": "バッチ内の潜在画像の数。" }, "resolution": { "name": "解像度" } } };
const EmptyLatentImage = { "description": "サンプリングを通じてノイズを除去するための空の潜在画像の新しいバッチを作成します。", "display_name": "空の潜在画像", "inputs": { "batch_size": { "name": "バッチサイズ", "tooltip": "バッチ内の潜在画像の数。" }, "height": { "name": "高さ", "tooltip": "潜在画像の高さ（ピクセル単位）。" }, "width": { "name": "幅", "tooltip": "潜在画像の幅（ピクセル単位）。" } }, "outputs": { "0": { "tooltip": "空の潜在画像バッチ。" } } };
const EmptyMochiLatentVideo = { "display_name": "空のMochi潜在ビデオ", "inputs": { "batch_size": { "name": "バッチサイズ" }, "height": { "name": "高さ" }, "length": { "name": "長さ" }, "width": { "name": "幅" } }, "outputs": { "0": { "tooltip": null } } };
const EmptySD3LatentImage = { "display_name": "空のSD3潜在画像", "inputs": { "batch_size": { "name": "バッチサイズ" }, "height": { "name": "高さ" }, "width": { "name": "幅" } }, "outputs": { "0": { "tooltip": null } } };
const ExponentialScheduler = { "display_name": "指数スケジューラー", "inputs": { "sigma_max": { "name": "sigma_max" }, "sigma_min": { "name": "sigma_min" }, "steps": { "name": "ステップ" } } };
const ExtendIntermediateSigmas = { "display_name": "ExtendIntermediateSigmas", "inputs": { "end_at_sigma": { "name": "終了シグマ" }, "sigmas": { "name": "sigmas" }, "spacing": { "name": "間隔" }, "start_at_sigma": { "name": "開始シグマ" }, "steps": { "name": "ステップ数" } } };
const FeatherMask = { "display_name": "フェザー マスク", "inputs": { "bottom": { "name": "下" }, "left": { "name": "左" }, "mask": { "name": "マスク" }, "right": { "name": "右" }, "top": { "name": "上" } } };
const FlipSigmas = { "display_name": "シグマを反転", "inputs": { "sigmas": { "name": "sigmas" } } };
const FluxDisableGuidance = { "description": "このノードはFluxおよびFluxのようなモデルのガイダンス埋め込みを完全に無効にします", "display_name": "FluxDisableGuidance", "inputs": { "conditioning": { "name": "conditioning" } }, "outputs": { "0": { "tooltip": null } } };
const FluxGuidance = { "display_name": "フラックスガイダンス", "inputs": { "conditioning": { "name": "コンディショニング" }, "guidance": { "name": "ガイダンス" } }, "outputs": { "0": { "tooltip": null } } };
const FluxKontextImageScale = { "description": "このノードは、Flux Kontextに最適なサイズに画像をリサイズします。", "display_name": "FluxKontextImageScale", "inputs": { "image": { "name": "画像" } }, "outputs": { "0": { "tooltip": null } } };
const FluxKontextMaxImageNode = { "description": "プロンプトとアスペクト比に基づいて、API経由でFlux.1 Kontext [max]を使用して画像を編集します。", "display_name": "Flux.1 Kontext [max] 画像", "inputs": { "aspect_ratio": { "name": "アスペクト比", "tooltip": "画像のアスペクト比。1:4から4:1の間でなければなりません。" }, "control_after_generate": { "name": "生成後に制御" }, "guidance": { "name": "ガイダンス", "tooltip": "画像生成プロセスにおけるガイダンスの強度" }, "input_image": { "name": "入力画像" }, "prompt": { "name": "プロンプト", "tooltip": "画像生成のためのプロンプト - 何をどのように編集するかを指定します。" }, "prompt_upsampling": { "name": "プロンプトアップサンプリング", "tooltip": "プロンプトに対してアップサンプリングを実行するかどうか。有効にすると、より創造的な生成のためにプロンプトを自動的に変更しますが、結果は非決定的になります（同じシードでも全く同じ結果にはなりません）。" }, "seed": { "name": "シード", "tooltip": "ノイズ生成に使用されるランダムシード。" }, "steps": { "name": "ステップ数", "tooltip": "画像生成プロセスのステップ数" } }, "outputs": { "0": { "tooltip": null } } };
const FluxKontextMultiReferenceLatentMethod = { "display_name": "FluxKontextMultiReferenceLatentMethod", "inputs": { "conditioning": { "name": "コンディショニング" }, "reference_latents_method": { "name": "参照潜在変数メソッド" } }, "outputs": { "0": { "tooltip": null } } };
const FluxKontextProImageNode = { "description": "プロンプトとアスペクト比に基づいて、API経由でFlux.1 Kontext [pro]を使用して画像を編集します。", "display_name": "Flux.1 Kontext [pro] 画像", "inputs": { "aspect_ratio": { "name": "アスペクト比", "tooltip": "画像のアスペクト比。1:4から4:1の間でなければなりません。" }, "control_after_generate": { "name": "生成後に制御" }, "guidance": { "name": "ガイダンス", "tooltip": "画像生成プロセスにおけるガイダンスの強度" }, "input_image": { "name": "入力画像" }, "prompt": { "name": "プロンプト", "tooltip": "画像生成のためのプロンプト - 何をどのように編集するかを指定します。" }, "prompt_upsampling": { "name": "プロンプトアップサンプリング", "tooltip": "プロンプトに対してアップサンプリングを実行するかどうか。有効にすると、より創造的な生成のためにプロンプトを自動的に変更しますが、結果は非決定的になります（同じシードでも全く同じ結果にはなりません）。" }, "seed": { "name": "シード", "tooltip": "ノイズ生成に使用されるランダムシード。" }, "steps": { "name": "ステップ数", "tooltip": "画像生成プロセスのステップ数" } }, "outputs": { "0": { "tooltip": null } } };
const FluxProExpandNode = { "description": "プロンプトに基づいて画像をアウトペイントします。", "display_name": "Flux.1 画像拡張", "inputs": { "bottom": { "name": "下", "tooltip": "画像の下部に拡張するピクセル数" }, "control_after_generate": { "name": "生成後のコントロール" }, "guidance": { "name": "ガイダンス", "tooltip": "画像生成プロセスのガイダンス強度" }, "image": { "name": "画像" }, "left": { "name": "左", "tooltip": "画像の左側に拡張するピクセル数" }, "prompt": { "name": "プロンプト", "tooltip": "画像生成用のプロンプト" }, "prompt_upsampling": { "name": "プロンプトアップサンプリング", "tooltip": "プロンプトにアップサンプリングを行うかどうか。有効にすると、より創造的な生成のためにプロンプトが自動的に修正されますが、結果は非決定的になります（同じシードでも全く同じ結果にはなりません）。" }, "right": { "name": "右", "tooltip": "画像の右側に拡張するピクセル数" }, "seed": { "name": "シード", "tooltip": "ノイズ生成に使用されるランダムシード。" }, "steps": { "name": "ステップ数", "tooltip": "画像生成プロセスのステップ数" }, "top": { "name": "上", "tooltip": "画像の上部に拡張するピクセル数" } }, "outputs": { "0": { "tooltip": null } } };
const FluxProFillNode = { "description": "マスクとプロンプトに基づいて画像をインペイントします。", "display_name": "Flux.1 画像塗りつぶし", "inputs": { "control_after_generate": { "name": "生成後のコントロール" }, "guidance": { "name": "ガイダンス", "tooltip": "画像生成プロセスのガイダンス強度" }, "image": { "name": "画像" }, "mask": { "name": "マスク" }, "prompt": { "name": "プロンプト", "tooltip": "画像生成用のプロンプト" }, "prompt_upsampling": { "name": "プロンプトアップサンプリング", "tooltip": "プロンプトにアップサンプリングを行うかどうか。有効にすると、より創造的な生成のためにプロンプトが自動的に修正されますが、結果は非決定的になります（同じシードでも全く同じ結果にはなりません）。" }, "seed": { "name": "シード", "tooltip": "ノイズ生成に使用されるランダムシード。" }, "steps": { "name": "ステップ数", "tooltip": "画像生成プロセスのステップ数" } }, "outputs": { "0": { "tooltip": null } } };
const FluxProUltraImageNode = { "description": "プロンプトと解像度に基づき、API経由でFlux Pro 1.1 Ultraを使用して画像を生成します。", "display_name": "Flux 1.1 [pro] ウルトラ画像", "inputs": { "aspect_ratio": { "name": "アスペクト比", "tooltip": "画像のアスペクト比。1:4から4:1の間で指定してください。" }, "control_after_generate": { "name": "生成後のコントロール" }, "image_prompt": { "name": "画像プロンプト" }, "image_prompt_strength": { "name": "画像プロンプト強度", "tooltip": "プロンプトと画像プロンプトのブレンド比率。" }, "prompt": { "name": "プロンプト", "tooltip": "画像生成のためのプロンプト" }, "prompt_upsampling": { "name": "プロンプトアップサンプリング", "tooltip": "プロンプトにアップサンプリングを行うかどうか。有効にすると、よりクリエイティブな生成のためにプロンプトが自動的に修正されますが、結果は非決定的になります（同じシードでも全く同じ結果にはなりません）。" }, "raw": { "name": "生画像", "tooltip": "Trueの場合、処理が少なく、より自然な見た目の画像を生成します。" }, "seed": { "name": "シード", "tooltip": "ノイズ生成に使用されるランダムシード。" } }, "outputs": { "0": { "tooltip": null } } };
const FreSca = { "description": "ガイダンスに周波数依存のスケーリングを適用します", "display_name": "FreSca", "inputs": { "freq_cutoff": { "name": "freq_cutoff", "tooltip": "中心付近の低周波数成分として扱う周波数インデックス数" }, "model": { "name": "model" }, "scale_high": { "name": "scale_high", "tooltip": "高周波成分のスケーリング係数" }, "scale_low": { "name": "scale_low", "tooltip": "低周波成分のスケーリング係数" } }, "outputs": { "0": { "tooltip": null } } };
const FreeU = { "display_name": "FreeU", "inputs": { "b1": { "name": "b1" }, "b2": { "name": "b2" }, "model": { "name": "モデル" }, "s1": { "name": "s1" }, "s2": { "name": "s2" } } };
const FreeU_V2 = { "display_name": "FreeU_V2", "inputs": { "b1": { "name": "b1" }, "b2": { "name": "b2" }, "model": { "name": "モデル" }, "s1": { "name": "s1" }, "s2": { "name": "s2" } } };
const GITSScheduler = { "display_name": "GITSスケジューラー", "inputs": { "coeff": { "name": "係数" }, "denoise": { "name": "ノイズ除去" }, "steps": { "name": "ステップ" } }, "outputs": { "0": { "tooltip": null } } };
const GLIGENLoader = { "display_name": "GLIGENを読み込む", "inputs": { "gligen_name": { "name": "gligen_name" } } };
const GLIGENTextBoxApply = { "display_name": "GLIGENテキストボックスを適用", "inputs": { "clip": { "name": "クリップ" }, "conditioning_to": { "name": "条件付け先" }, "gligen_textbox_model": { "name": "gligen_textbox_model" }, "height": { "name": "高さ" }, "text": { "name": "テキスト" }, "width": { "name": "幅" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const GeminiImageNode = { "description": "Google API経由で画像を同期的に編集します。", "display_name": "Google Gemini 画像", "inputs": { "aspect_ratio": { "name": "アスペクト比", "tooltip": "デフォルトでは入力画像のサイズに合わせて出力画像のサイズを設定し、それ以外の場合は1:1の正方形を生成します。" }, "control_after_generate": { "name": "生成後に制御" }, "files": { "name": "ファイル", "tooltip": "モデルのコンテキストとして使用するオプションのファイル。Gemini Generate Content Input Filesノードからの入力を受け付けます。" }, "images": { "name": "画像", "tooltip": "モデルのコンテキストとして使用するオプションの画像。複数の画像を含めるには、バッチ画像ノードを使用できます。" }, "model": { "name": "モデル", "tooltip": "応答生成に使用するGeminiモデル。" }, "prompt": { "name": "プロンプト", "tooltip": "生成用のテキストプロンプト" }, "seed": { "name": "シード", "tooltip": "シードが特定の値に固定されている場合、モデルは繰り返しリクエストに対して同じ応答を提供するよう最善を尽くします。決定的な出力は保証されません。また、モデルや温度などのパラメータ設定を変更すると、同じシード値を使用しても応答にばらつきが生じることがあります。デフォルトでは、ランダムなシード値が使用されます。" } }, "outputs": { "0": { "tooltip": null }, "1": { "tooltip": null } } };
const GeminiInputFiles = { "description": "Gemini LLMノードの入力として含めるファイルを読み込み、準備します。ファイルはGeminiモデルが応答を生成する際に読み込まれます。テキストファイルの内容はトークン制限にカウントされます。🛈 ヒント：他のGemini入力ファイルノードと連結できます。", "display_name": "Gemini入力ファイル", "inputs": { "GEMINI_INPUT_FILES": { "name": "GEMINI_INPUT_FILES", "tooltip": "このノードから読み込まれたファイルと一緒にバッチ処理するオプションの追加ファイル。単一のメッセージに複数の入力ファイルを含められるように、入力ファイルを連結できます。" }, "file": { "name": "ファイル", "tooltip": "モデルのコンテキストとして含める入力ファイル。現在はテキスト（.txt）ファイルとPDF（.pdf）ファイルのみ受け付けます。" } }, "outputs": { "0": { "tooltip": null } } };
const GeminiNode = { "description": "GoogleのGemini AIモデルでテキスト応答を生成します。テキスト、画像、音声、動画など複数の種類の入力をコンテキストとして提供し、より関連性の高い意味のある応答を生成できます。", "display_name": "Google Gemini", "inputs": { "audio": { "name": "音声", "tooltip": "モデルのコンテキストとして使用するオプションの音声。" }, "control_after_generate": { "name": "生成後に制御" }, "files": { "name": "ファイル", "tooltip": "モデルのコンテキストとして使用するオプションのファイル。Gemini Generate Content Input Filesノードからの入力を受け付けます。" }, "images": { "name": "画像", "tooltip": "モデルのコンテキストとして使用するオプションの画像。複数の画像を含めるには、Batch Imagesノードを使用できます。" }, "model": { "name": "モデル", "tooltip": "応答生成に使用するGeminiモデル。" }, "prompt": { "name": "プロンプト", "tooltip": "モデルへのテキスト入力。応答を生成するために使用されます。モデルに対する詳細な指示、質問、コンテキストを含めることができます。" }, "seed": { "name": "シード", "tooltip": "シードを特定の値に固定すると、モデルは繰り返しリクエストに対して同じ応答を提供するよう最善を尽くします。確定的な出力は保証されません。また、モデルや温度などのパラメータ設定を変更すると、同じシード値を使用しても応答にばらつきが生じることがあります。デフォルトではランダムなシード値が使用されます。" }, "video": { "name": "動画", "tooltip": "モデルのコンテキストとして使用するオプションの動画。" } }, "outputs": { "0": { "tooltip": null } } };
const GetImageSize = { "description": "画像の幅と高さを返し、変更せずに通過させます。", "display_name": "画像サイズ取得", "inputs": { "image": { "name": "画像" } }, "outputs": { "0": { "name": "幅" }, "1": { "name": "高さ" }, "2": { "name": "バッチサイズ" } } };
const GetVideoComponents = { "description": "ビデオからすべてのコンポーネント（フレーム、オーディオ、フレームレート）を抽出します。", "display_name": "ビデオコンポーネントの取得", "inputs": { "video": { "name": "ビデオ", "tooltip": "コンポーネントを抽出するビデオ。" } }, "outputs": { "0": { "name": "画像", "tooltip": null }, "1": { "name": "オーディオ", "tooltip": null }, "2": { "name": "fps", "tooltip": null } } };
const GrowMask = { "display_name": "マスクを拡大", "inputs": { "expand": { "name": "拡大" }, "mask": { "name": "マスク" }, "tapered_corners": { "name": "テーパードコーナー" } } };
const Hunyuan3Dv2Conditioning = { "display_name": "Hunyuan3Dv2Conditioning", "inputs": { "clip_vision_output": { "name": "clip_vision_output" } }, "outputs": { "0": { "name": "ポジティブ" }, "1": { "name": "ネガティブ" } } };
const Hunyuan3Dv2ConditioningMultiView = { "display_name": "Hunyuan3Dv2ConditioningMultiView", "inputs": { "back": { "name": "バック" }, "front": { "name": "フロント" }, "left": { "name": "左" }, "right": { "name": "右" } }, "outputs": { "0": { "name": "ポジティブ" }, "1": { "name": "ネガティブ" } } };
const HunyuanImageToVideo = { "display_name": "HunyuanImageToVideo", "inputs": { "batch_size": { "name": "バッチサイズ" }, "guidance_type": { "name": "ガイダンスタイプ" }, "height": { "name": "高さ" }, "length": { "name": "長さ" }, "positive": { "name": "ポジティブ" }, "start_image": { "name": "開始画像" }, "vae": { "name": "vae" }, "width": { "name": "幅" } }, "outputs": { "0": { "name": "ポジティブ", "tooltip": null }, "1": { "name": "潜在", "tooltip": null } } };
const HunyuanRefinerLatent = { "display_name": "HunyuanRefinerLatent", "inputs": { "latent": { "name": "潜在表現" }, "negative": { "name": "ネガティブ" }, "noise_augmentation": { "name": "ノイズ増強" }, "positive": { "name": "ポジティブ" } }, "outputs": { "0": { "name": "ポジティブ", "tooltip": null }, "1": { "name": "ネガティブ", "tooltip": null }, "2": { "name": "潜在表現", "tooltip": null } } };
const HyperTile = { "display_name": "ハイパータイル", "inputs": { "max_depth": { "name": "最大深度" }, "model": { "name": "モデル" }, "scale_depth": { "name": "スケール深度" }, "swap_size": { "name": "スワップサイズ" }, "tile_size": { "name": "タイルサイズ" } }, "outputs": { "0": { "tooltip": null } } };
const HypernetworkLoader = { "display_name": "ハイパーネットワークを読み込む", "inputs": { "hypernetwork_name": { "name": "hypernetwork_name" }, "model": { "name": "モデル" }, "strength": { "name": "強度" } }, "outputs": { "0": { "tooltip": null } } };
const IdeogramV1 = { "description": "Ideogram V1モデルを使用して同期的に画像を生成します。\n\n画像リンクは一定期間のみ有効です。画像を保存したい場合は、ダウンロードしてください。", "display_name": "Ideogram V1", "inputs": { "aspect_ratio": { "name": "アスペクト比", "tooltip": "画像生成のアスペクト比。" }, "control_after_generate": { "name": "生成後のコントロール" }, "magic_prompt_option": { "name": "マジックプロンプトオプション", "tooltip": "生成時にMagicPromptを使用するかどうかを決定" }, "negative_prompt": { "name": "ネガティブプロンプト", "tooltip": "画像から除外したい内容の説明" }, "num_images": { "name": "画像数" }, "prompt": { "name": "プロンプト", "tooltip": "画像生成のためのプロンプト" }, "seed": { "name": "シード" }, "turbo": { "name": "ターボ", "tooltip": "ターボモードを使用するかどうか（高速生成、品質が低下する可能性あり）" } }, "outputs": { "0": { "tooltip": null } } };
const IdeogramV2 = { "description": "Ideogram V2モデルを使用して同期的に画像を生成します。\n\n画像リンクは一定期間のみ有効です。画像を保存したい場合は、ダウンロードしてください。", "display_name": "Ideogram V2", "inputs": { "aspect_ratio": { "name": "アスペクト比", "tooltip": "画像生成のアスペクト比。解像度がAUTOでない場合は無視されます。" }, "control_after_generate": { "name": "生成後のコントロール" }, "magic_prompt_option": { "name": "マジックプロンプトオプション", "tooltip": "生成時にMagicPromptを使用するかどうかを決定します" }, "negative_prompt": { "name": "ネガティブプロンプト", "tooltip": "画像から除外したい内容の説明" }, "num_images": { "name": "画像数" }, "prompt": { "name": "プロンプト", "tooltip": "画像生成のためのプロンプト" }, "resolution": { "name": "解像度", "tooltip": "画像生成の解像度。AUTOでない場合、aspect_ratioの設定を上書きします。" }, "seed": { "name": "シード" }, "style_type": { "name": "スタイルタイプ", "tooltip": "生成時のスタイルタイプ（V2のみ）" }, "turbo": { "name": "ターボ", "tooltip": "ターボモードを使用するかどうか（高速生成、品質が低下する可能性あり）" } }, "outputs": { "0": { "tooltip": null } } };
const IdeogramV3 = { "description": "Ideogram V3モデルを使用して同期的に画像を生成します。\n\nテキストプロンプトからの通常の画像生成と、マスクを使った画像編集の両方に対応しています。\n画像リンクは一定期間のみ有効です。画像を保存したい場合は、必ずダウンロードしてください。", "display_name": "Ideogram V3", "inputs": { "aspect_ratio": { "name": "アスペクト比", "tooltip": "画像生成時のアスペクト比。解像度が自動でない場合は無視されます。" }, "character_image": { "name": "キャラクター画像", "tooltip": "キャラクター参照として使用する画像。" }, "character_mask": { "name": "キャラクターマスク", "tooltip": "キャラクター参照画像用のオプションマスク。" }, "control_after_generate": { "name": "生成後のコントロール" }, "image": { "name": "画像", "tooltip": "画像編集用のオプションの参照画像。" }, "magic_prompt_option": { "name": "マジックプロンプトオプション", "tooltip": "生成時にMagicPromptを使用するかどうかを決定します" }, "mask": { "name": "マスク", "tooltip": "インペインティング用のオプションのマスク（白い部分が置き換えられます）" }, "num_images": { "name": "画像数" }, "prompt": { "name": "プロンプト", "tooltip": "画像生成または編集のためのプロンプト" }, "rendering_speed": { "name": "レンダリング速度", "tooltip": "生成速度と品質のトレードオフを制御します" }, "resolution": { "name": "解像度", "tooltip": "画像生成時の解像度。自動でない場合、アスペクト比の設定を上書きします。" }, "seed": { "name": "シード" } }, "outputs": { "0": { "tooltip": null } } };
const ImageAddNoise = { "display_name": "ImageAddNoise", "inputs": { "control_after_generate": { "name": "生成後の制御" }, "image": { "name": "画像" }, "seed": { "name": "シード", "tooltip": "ノイズ作成に使用されるランダムシード。" }, "strength": { "name": "強度" } } };
const ImageBatch = { "display_name": "画像バッチ", "inputs": { "image1": { "name": "画像1" }, "image2": { "name": "画像2" } } };
const ImageBlend = { "display_name": "画像ブレンド", "inputs": { "blend_factor": { "name": "ブレンドファクター" }, "blend_mode": { "name": "ブレンドモード" }, "image1": { "name": "画像1" }, "image2": { "name": "画像2" } }, "outputs": { "0": { "tooltip": null } } };
const ImageBlur = { "display_name": "画像ぼかし", "inputs": { "blur_radius": { "name": "ブラーレイディウス" }, "image": { "name": "画像" }, "sigma": { "name": "シグマ" } }, "outputs": { "0": { "tooltip": null } } };
const ImageColorToMask = { "display_name": "画像色をマスクに変換", "inputs": { "color": { "name": "色" }, "image": { "name": "画像" } } };
const ImageCompositeMasked = { "display_name": "マスクされた画像合成", "inputs": { "destination": { "name": "宛先" }, "mask": { "name": "マスク" }, "resize_source": { "name": "ソースのリサイズ" }, "source": { "name": "ソース" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const ImageCrop = { "display_name": "画像トリミング", "inputs": { "height": { "name": "高さ" }, "image": { "name": "画像" }, "width": { "name": "幅" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const ImageFlip = { "display_name": "画像反転", "inputs": { "flip_method": { "name": "反転方法" }, "image": { "name": "画像" } } };
const ImageFromBatch = { "display_name": "バッチから画像を取得", "inputs": { "batch_index": { "name": "バッチインデックス" }, "image": { "name": "画像" }, "length": { "name": "長さ" } } };
const ImageInvert = { "display_name": "画像を反転", "inputs": { "image": { "name": "画像" } } };
const ImageOnlyCheckpointLoader = { "display_name": "画像のみのチェックポイントローダー（img2vidモデル）", "inputs": { "ckpt_name": { "name": "ckpt_name" } } };
const ImageOnlyCheckpointSave = { "display_name": "画像のみのチェックポイント保存", "inputs": { "clip_vision": { "name": "clip_vision" }, "filename_prefix": { "name": "ファイル名プレフィックス" }, "model": { "name": "モデル" }, "vae": { "name": "vae" } } };
const ImagePadForOutpaint = { "display_name": "アウトペイント用に画像をパッド", "inputs": { "bottom": { "name": "下" }, "feathering": { "name": "フェザリング" }, "image": { "name": "画像" }, "left": { "name": "左" }, "right": { "name": "右" }, "top": { "name": "上" } } };
const ImageQuantize = { "display_name": "画像を量子化", "inputs": { "colors": { "name": "色" }, "dither": { "name": "ディザリング" }, "image": { "name": "画像" } }, "outputs": { "0": { "tooltip": null } } };
const ImageRGBToYUV = { "display_name": "ImageRGBToYUV", "inputs": { "image": { "name": "画像" } }, "outputs": { "0": { "name": "Y", "tooltip": null }, "1": { "name": "U", "tooltip": null }, "2": { "name": "V", "tooltip": null } } };
const ImageRotate = { "display_name": "画像回転", "inputs": { "image": { "name": "画像" }, "rotation": { "name": "回転" } } };
const ImageScale = { "display_name": "画像を拡大", "inputs": { "crop": { "name": "クロップ" }, "height": { "name": "高さ" }, "image": { "name": "画像" }, "upscale_method": { "name": "拡大方法" }, "width": { "name": "幅" } } };
const ImageScaleBy = { "display_name": "画像を拡大（指定サイズ）", "inputs": { "image": { "name": "画像" }, "scale_by": { "name": "スケールバイ" }, "upscale_method": { "name": "拡大方法" } } };
const ImageScaleToMaxDimension = { "display_name": "画像最大寸法へのスケール", "inputs": { "image": { "name": "画像" }, "largest_size": { "name": "最大サイズ" }, "upscale_method": { "name": "アップスケール方法" } } };
const ImageScaleToTotalPixels = { "display_name": "画像を総ピクセルにスケール", "inputs": { "image": { "name": "画像" }, "megapixels": { "name": "メガピクセル" }, "upscale_method": { "name": "拡大方法" } }, "outputs": { "0": { "tooltip": null } } };
const ImageSharpen = { "display_name": "画像をシャープ化", "inputs": { "alpha": { "name": "アルファ" }, "image": { "name": "画像" }, "sharpen_radius": { "name": "シャープ化半径" }, "sigma": { "name": "シグマ" } }, "outputs": { "0": { "tooltip": null } } };
const ImageStitch = { "description": "\n指定された方向にimage2をimage1に結合します。\nimage2が提供されない場合は、image1を変更せずに返します。\n画像間にオプションで間隔を追加できます。\n", "display_name": "画像結合", "inputs": { "direction": { "name": "方向" }, "image1": { "name": "画像1" }, "image2": { "name": "画像2" }, "match_image_size": { "name": "画像サイズを一致させる" }, "spacing_color": { "name": "間隔の色" }, "spacing_width": { "name": "間隔の幅" } } };
const ImageToMask = { "display_name": "画像をマスクに変換", "inputs": { "channel": { "name": "チャンネル" }, "image": { "name": "画像" } } };
const ImageUpscaleWithModel = { "display_name": "モデルを使用して画像を拡大", "inputs": { "image": { "name": "画像" }, "upscale_model": { "name": "拡大モデル" } }, "outputs": { "0": { "tooltip": null } } };
const ImageYUVToRGB = { "display_name": "ImageYUVToRGB", "inputs": { "U": { "name": "U" }, "V": { "name": "V" }, "Y": { "name": "Y" } }, "outputs": { "0": { "tooltip": null } } };
const InpaintModelConditioning = { "display_name": "インペイントモデル条件付け", "inputs": { "mask": { "name": "マスク" }, "negative": { "name": "ネガティブ" }, "noise_mask": { "name": "ノイズマスク", "tooltip": "潜在にノイズマスクを追加し、サンプリングがマスク内でのみ行われるようにします。モデルによっては結果が改善されるか、完全に壊れる可能性があります。" }, "pixels": { "name": "ピクセル" }, "positive": { "name": "ポジティブ" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "ポジティブ" }, "1": { "name": "ネガティブ" }, "2": { "name": "潜在" } } };
const InstructPixToPixConditioning = { "display_name": "PixToPix条件付け", "inputs": { "negative": { "name": "ネガティブ" }, "pixels": { "name": "ピクセル" }, "positive": { "name": "ポジティブ" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "ポジティブ", "tooltip": null }, "1": { "name": "ネガティブ", "tooltip": null }, "2": { "name": "潜在", "tooltip": null } } };
const InvertMask = { "display_name": "マスクを反転", "inputs": { "mask": { "name": "マスク" } } };
const JoinImageWithAlpha = { "display_name": "アルファで画像を結合", "inputs": { "alpha": { "name": "アルファ" }, "image": { "name": "画像" } }, "outputs": { "0": { "tooltip": null } } };
const KSampler = { "description": "提供されたモデル、正の条件付けと負の条件付けを使用して潜在画像のノイズを除去します。", "display_name": "Kサンプラー", "inputs": { "cfg": { "name": "cfg", "tooltip": "Classifier-Free Guidanceスケールは、創造性とプロンプトへの遵守のバランスを取ります。値が高いほど、生成される画像はプロンプトにより近くなりますが、値が高すぎると品質に悪影響を及ぼす可能性があります。" }, "control_after_generate": { "name": "生成後の制御" }, "denoise": { "name": "ノイズ除去", "tooltip": "適用されるデノイズの量。値が低いほど、初期画像の構造を維持し、画像から画像へのサンプリングが可能になります。" }, "latent_image": { "name": "潜在画像", "tooltip": "デノイズする潜在画像。" }, "model": { "name": "モデル", "tooltip": "入力潜在のデノイズに使用されるモデル。" }, "negative": { "name": "ネガティブ", "tooltip": "画像から除外したい属性を説明する条件付け。" }, "positive": { "name": "ポジティブ", "tooltip": "画像に含めたい属性を説明する条件付け。" }, "sampler_name": { "name": "サンプラー名", "tooltip": "サンプリング時に使用されるアルゴリズムで、生成される出力の品質、速度、スタイルに影響を与える可能性があります。" }, "scheduler": { "name": "スケジューラ", "tooltip": "スケジューラは、ノイズが徐々に除去されて画像が形成される方法を制御します。" }, "seed": { "name": "シード", "tooltip": "ノイズを生成するために使用されるランダムシード。" }, "steps": { "name": "ステップ", "tooltip": "デノイズプロセスで使用されるステップ数。" } }, "outputs": { "0": { "tooltip": "デノイズされた潜在変数。" } } };
const KSamplerAdvanced = { "display_name": "Kサンプラー（高度）", "inputs": { "add_noise": { "name": "ノイズ追加" }, "cfg": { "name": "cfg" }, "control_after_generate": { "name": "生成後の制御" }, "end_at_step": { "name": "ステップ終了" }, "latent_image": { "name": "潜在画像" }, "model": { "name": "モデル" }, "negative": { "name": "ネガティブ" }, "noise_seed": { "name": "ノイズシード" }, "positive": { "name": "ポジティブ" }, "return_with_leftover_noise": { "name": "残りのノイズと一緒に返す" }, "sampler_name": { "name": "サンプラー名" }, "scheduler": { "name": "スケジューラ" }, "start_at_step": { "name": "ステップ開始" }, "steps": { "name": "ステップ" } } };
const KSamplerSelect = { "display_name": "Kサンプラー選択", "inputs": { "sampler_name": { "name": "サンプラー名" } } };
const KarrasScheduler = { "display_name": "カラススケジューラー", "inputs": { "rho": { "name": "ロー" }, "sigma_max": { "name": "シグマ_最大" }, "sigma_min": { "name": "シグマ_最小" }, "steps": { "name": "ステップ" } } };
const KlingCameraControlI2VNode = { "description": "静止画像を、実際の映画撮影のようなプロフェッショナルなカメラ動作でシネマティックな動画に変換します。ズーム、回転、パン、チルト、一人称視点などのバーチャルカメラ操作を制御し、元画像へのフォーカスを維持します。", "display_name": "Kling 画像から動画へ（カメラコントロール）", "inputs": { "aspect_ratio": { "name": "aspect_ratio" }, "camera_control": { "name": "camera_control", "tooltip": "Kling Camera Controlsノードで作成できます。動画生成時のカメラの動きやモーションを制御します。" }, "cfg_scale": { "name": "cfg_scale" }, "negative_prompt": { "name": "negative_prompt", "tooltip": "ネガティブテキストプロンプト" }, "prompt": { "name": "prompt", "tooltip": "ポジティブテキストプロンプト" }, "start_frame": { "name": "start_frame", "tooltip": "参照画像 - URLまたはBase64エンコード文字列。10MBを超えず、解像度は300×300px以上、アスペクト比は1:2.5〜2.5:1の範囲。Base64の場合、data:imageプレフィックスは含めないでください。" } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "video_id", "tooltip": null }, "2": { "name": "duration", "tooltip": null } } };
const KlingCameraControlT2VNode = { "description": "テキストを本格的なカメラワークで映画のようなビデオに変換します。ズーム、回転、パン、チルト、一人称視点など、実際の映画撮影を模したバーチャルカメラの動きを制御し、元のテキストの内容に焦点を当てたまま映像を生成します。", "display_name": "Kling テキストからビデオへ（カメラコントロール）", "inputs": { "aspect_ratio": { "name": "aspect_ratio" }, "camera_control": { "name": "camera_control", "tooltip": "Kling Camera Controlsノードで作成できます。ビデオ生成中のカメラの動きやモーションを制御します。" }, "cfg_scale": { "name": "cfg_scale" }, "negative_prompt": { "name": "negative_prompt", "tooltip": "ネガティブなテキストプロンプト" }, "prompt": { "name": "prompt", "tooltip": "ポジティブなテキストプロンプト" } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "video_id", "tooltip": null }, "2": { "name": "duration", "tooltip": null } } };
const KlingCameraControls = { "description": "Klingカメラコントロールおよびモーションコントロール効果の設定オプションを指定できます。", "display_name": "Klingカメラコントロール", "inputs": { "camera_control_type": { "name": "camera_control_type" }, "horizontal_movement": { "name": "horizontal_movement", "tooltip": "カメラの水平方向（x軸）の動きを制御します。負の値は左、正の値は右を示します。" }, "pan": { "name": "pan", "tooltip": "カメラの垂直面（x軸）での回転を制御します。負の値は下方向への回転、正の値は上方向への回転を示します。" }, "roll": { "name": "roll", "tooltip": "カメラの回転量（z軸）を制御します。負の値は反時計回り、正の値は時計回りを示します。" }, "tilt": { "name": "tilt", "tooltip": "カメラの水平面（y軸）での回転を制御します。負の値は左回転、正の値は右回転を示します。" }, "vertical_movement": { "name": "vertical_movement", "tooltip": "カメラの垂直方向（y軸）の動きを制御します。負の値は下方向、正の値は上方向を示します。" }, "zoom": { "name": "zoom", "tooltip": "カメラの焦点距離の変化を制御します。負の値は視野が狭くなり、正の値は視野が広くなります。" } }, "outputs": { "0": { "name": "camera_control", "tooltip": null } } };
const KlingDualCharacterVideoEffectNode = { "description": "effect_scene に基づいて動画生成時に様々な特殊効果を実現します。最初の画像は合成画像の左側に、2番目の画像は右側に配置されます。", "display_name": "Kling デュアルキャラクター動画エフェクト", "inputs": { "duration": { "name": "duration" }, "effect_scene": { "name": "effect_scene" }, "image_left": { "name": "image_left", "tooltip": "左側の画像" }, "image_right": { "name": "image_right", "tooltip": "右側の画像" }, "mode": { "name": "mode" }, "model_name": { "name": "model_name" } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "duration", "tooltip": null } } };
const KlingImage2VideoNode = { "display_name": "Kling 画像から動画へ", "inputs": { "aspect_ratio": { "name": "aspect_ratio" }, "cfg_scale": { "name": "cfg_scale" }, "duration": { "name": "duration" }, "mode": { "name": "mode" }, "model_name": { "name": "model_name" }, "negative_prompt": { "name": "negative_prompt", "tooltip": "ネガティブテキストプロンプト" }, "prompt": { "name": "prompt", "tooltip": "ポジティブテキストプロンプト" }, "start_frame": { "name": "start_frame", "tooltip": "参照画像 - URLまたはBase64エンコード文字列。10MBを超えてはいけません。解像度は300×300px以上、アスペクト比は1:2.5〜2.5:1の範囲。Base64の場合、data:imageプレフィックスは含めないでください。" } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "video_id", "tooltip": null }, "2": { "name": "duration", "tooltip": null } } };
const KlingImageGenerationNode = { "description": "Kling画像生成ノード。テキストプロンプトと任意の参照画像から画像を生成します。", "display_name": "Kling画像生成", "inputs": { "aspect_ratio": { "name": "アスペクト比" }, "human_fidelity": { "name": "人物忠実度", "tooltip": "被写体の参照類似度" }, "image": { "name": "画像" }, "image_fidelity": { "name": "画像忠実度", "tooltip": "ユーザーがアップロードした画像の参照強度" }, "image_type": { "name": "画像タイプ" }, "model_name": { "name": "モデル名" }, "n": { "name": "生成画像数", "tooltip": "生成される画像の数" }, "negative_prompt": { "name": "ネガティブプロンプト", "tooltip": "ネガティブテキストプロンプト" }, "prompt": { "name": "プロンプト", "tooltip": "ポジティブテキストプロンプト" } }, "outputs": { "0": { "tooltip": null } } };
const KlingLipSyncAudioToVideoNode = { "description": "Klingリップシンク音声から動画ノード。動画ファイル内の口の動きを音声ファイルの内容に同期します。", "display_name": "Klingリップシンク：音声付き動画", "inputs": { "audio": { "name": "音声" }, "video": { "name": "動画" }, "voice_language": { "name": "音声言語" } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "動画ID", "tooltip": null }, "2": { "name": "再生時間", "tooltip": null } } };
const KlingLipSyncTextToVideoNode = { "description": "Kling リップシンク テキストから動画ノード。動画ファイル内の口の動きをテキストプロンプトに同期させます。", "display_name": "Kling リップシンク動画（テキスト入力）", "inputs": { "text": { "name": "テキスト", "tooltip": "リップシンク動画生成用のテキスト内容。モードが text2video の場合は必須です。最大120文字まで。" }, "video": { "name": "動画" }, "voice": { "name": "音声" }, "voice_speed": { "name": "話速", "tooltip": "話す速度。有効範囲：0.8～2.0、小数点第一位まで指定可能。" } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "動画ID", "tooltip": null }, "2": { "name": "再生時間", "tooltip": null } } };
const KlingSingleImageVideoEffectNode = { "description": "effect_scene に基づいてビデオを生成する際に、さまざまな特殊効果を実現します。", "display_name": "Kling ビデオエフェクト", "inputs": { "duration": { "name": "duration" }, "effect_scene": { "name": "effect_scene" }, "image": { "name": "image", "tooltip": "参照画像。URL または Base64 エンコード文字列（data:image プレフィックスなし）。ファイルサイズは10MB以下、解像度は300×300px以上、アスペクト比は1:2.5～2.5:1の範囲である必要があります。" }, "model_name": { "name": "model_name" } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "video_id", "tooltip": null }, "2": { "name": "duration", "tooltip": null } } };
const KlingStartEndFrameNode = { "description": "指定した開始画像と終了画像の間を遷移する動画シーケンスを生成します。このノードは中間のすべてのフレームを作成し、最初のフレームから最後のフレームまで滑らかな変化を実現します。", "display_name": "Kling 開始-終了フレームから動画生成", "inputs": { "aspect_ratio": { "name": "aspect_ratio" }, "cfg_scale": { "name": "cfg_scale" }, "end_frame": { "name": "end_frame", "tooltip": "参照画像 - 終了フレームの指定。URLまたはBase64エンコード文字列。10MBを超えてはいけません。解像度は300×300px以上。Base64の場合、data:imageプレフィックスは含めないでください。" }, "mode": { "name": "mode", "tooltip": "動画生成に使用する設定。形式：mode / duration / model_name" }, "negative_prompt": { "name": "negative_prompt", "tooltip": "ネガティブテキストプロンプト" }, "prompt": { "name": "prompt", "tooltip": "ポジティブテキストプロンプト" }, "start_frame": { "name": "start_frame", "tooltip": "参照画像 - URLまたはBase64エンコード文字列。10MBを超えてはいけません。解像度は300×300px以上、アスペクト比は1:2.5～2.5:1の範囲。Base64の場合、data:imageプレフィックスは含めないでください。" } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "video_id", "tooltip": null }, "2": { "name": "duration", "tooltip": null } } };
const KlingTextToVideoNode = { "description": "Kling テキストからビデオノード", "display_name": "Kling テキストからビデオへ", "inputs": { "aspect_ratio": { "name": "アスペクト比" }, "cfg_scale": { "name": "cfg_scale" }, "mode": { "name": "モード", "tooltip": "ビデオ生成のために使用する設定（形式: モード / 継続時間 / モデル名）" }, "negative_prompt": { "name": "ネガティブプロンプト", "tooltip": "ネガティブテキストプロンプト" }, "prompt": { "name": "プロンプト", "tooltip": "ポジティブテキストプロンプト" } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "video_id", "tooltip": null }, "2": { "name": "継続時間", "tooltip": null } } };
const KlingVideoExtendNode = { "description": "Kling Video Extendノード。他のKlingノードで作成された動画を拡張します。video_idは他のKlingノードを使用して作成されます。", "display_name": "Kling Video Extend", "inputs": { "cfg_scale": { "name": "cfg_scale" }, "negative_prompt": { "name": "negative_prompt", "tooltip": "拡張動画で避けたい要素のネガティブテキストプロンプト" }, "prompt": { "name": "prompt", "tooltip": "動画拡張をガイドするためのポジティブなテキストプロンプト" }, "video_id": { "name": "video_id", "tooltip": "拡張する動画のID。テキストから動画、画像から動画、または以前の動画拡張操作で生成された動画をサポートします。拡張後の合計再生時間は3分を超えることはできません。" } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "video_id", "tooltip": null }, "2": { "name": "duration", "tooltip": null } } };
const KlingVirtualTryOnNode = { "description": "Klingバーチャル試着ノード。人物画像と服画像を入力して、人物に服を試着させます。", "display_name": "Klingバーチャル試着", "inputs": { "cloth_image": { "name": "服画像" }, "human_image": { "name": "人物画像" }, "model_name": { "name": "モデル名" } }, "outputs": { "0": { "tooltip": null } } };
const LTXVAddGuide = { "display_name": "LTXVAddGuide", "inputs": { "frame_idx": { "name": "フレームインデックス", "tooltip": "条件付けを開始するフレームインデックス。単一フレームの画像や1-8フレームのビデオの場合、任意のframe_idx値が許容されます。9フレーム以上のビデオの場合、frame_idxは8で割り切れる数でなければならず、そうでない場合は最も近い8の倍数に切り捨てられます。負の値はビデオの終わりから数えます。" }, "image": { "name": "画像", "tooltip": "潜在ビデオの条件付けに使用する画像またはビデオ。フレーム数は8*n + 1でなければなりません。ビデオが8*n + 1フレームでない場合、最も近い8*n + 1フレームに切り取られます。" }, "latent": { "name": "潜在" }, "negative": { "name": "ネガティブ" }, "positive": { "name": "ポジティブ" }, "strength": { "name": "強度" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "ポジティブ", "tooltip": null }, "1": { "name": "ネガティブ", "tooltip": null }, "2": { "name": "潜在", "tooltip": null } } };
const LTXVConditioning = { "display_name": "LTXV条件付け", "inputs": { "frame_rate": { "name": "フレームレート" }, "negative": { "name": "ネガティブ" }, "positive": { "name": "ポジティブ" } }, "outputs": { "0": { "name": "ポジティブ", "tooltip": null }, "1": { "name": "ネガティブ", "tooltip": null } } };
const LTXVCropGuides = { "display_name": "LTXVCropGuides", "inputs": { "latent": { "name": "潜在" }, "negative": { "name": "ネガティブ" }, "positive": { "name": "ポジティブ" } }, "outputs": { "0": { "name": "ポジティブ", "tooltip": null }, "1": { "name": "ネガティブ", "tooltip": null }, "2": { "name": "潜在", "tooltip": null } } };
const LTXVImgToVideo = { "display_name": "LTXV画像からビデオへ", "inputs": { "batch_size": { "name": "バッチサイズ" }, "height": { "name": "高さ" }, "image": { "name": "画像" }, "length": { "name": "長さ" }, "negative": { "name": "ネガティブ" }, "positive": { "name": "ポジティブ" }, "strength": { "name": "強度" }, "vae": { "name": "vae" }, "width": { "name": "幅" } }, "outputs": { "0": { "name": "ポジティブ", "tooltip": null }, "1": { "name": "ネガティブ", "tooltip": null }, "2": { "name": "潜在", "tooltip": null } } };
const LTXVPreprocess = { "display_name": "LTXVPreprocess", "inputs": { "image": { "name": "画像" }, "img_compression": { "name": "画像圧縮", "tooltip": "画像に適用する圧縮の量。" } }, "outputs": { "0": { "name": "出力画像", "tooltip": null } } };
const LTXVScheduler = { "display_name": "LTXVスケジューラー", "inputs": { "base_shift": { "name": "基本シフト" }, "latent": { "name": "潜在" }, "max_shift": { "name": "最大シフト" }, "steps": { "name": "ステップ" }, "stretch": { "name": "ストレッチ", "tooltip": "シグマを[terminal, 1]の範囲に伸ばします。" }, "terminal": { "name": "端末", "tooltip": "ストレッチ後のシグマの端末値。" } }, "outputs": { "0": { "tooltip": null } } };
const LaplaceScheduler = { "display_name": "ラプラススケジューラー", "inputs": { "beta": { "name": "ベータ" }, "mu": { "name": "ミュー" }, "sigma_max": { "name": "シグマ_最大" }, "sigma_min": { "name": "シグマ_最小" }, "steps": { "name": "ステップ" } } };
const LatentAdd = { "display_name": "潜在追加", "inputs": { "samples1": { "name": "サンプル1" }, "samples2": { "name": "サンプル2" } }, "outputs": { "0": { "tooltip": null } } };
const LatentApplyOperation = { "display_name": "潜在操作を適用", "inputs": { "operation": { "name": "操作" }, "samples": { "name": "サンプル" } }, "outputs": { "0": { "tooltip": null } } };
const LatentApplyOperationCFG = { "display_name": "潜在操作CFGを適用", "inputs": { "model": { "name": "モデル" }, "operation": { "name": "操作" } }, "outputs": { "0": { "tooltip": null } } };
const LatentBatch = { "display_name": "潜在バッチ", "inputs": { "samples1": { "name": "サンプル1" }, "samples2": { "name": "サンプル2" } }, "outputs": { "0": { "tooltip": null } } };
const LatentBatchSeedBehavior = { "display_name": "潜在バッチシード動作", "inputs": { "samples": { "name": "サンプル" }, "seed_behavior": { "name": "シード行動" } }, "outputs": { "0": { "tooltip": null } } };
const LatentBlend = { "display_name": "潜在ブレンド", "inputs": { "blend_factor": { "name": "ブレンド係数" }, "samples1": { "name": "サンプル1" }, "samples2": { "name": "サンプル2" } } };
const LatentComposite = { "display_name": "潜在合成", "inputs": { "feather": { "name": "フェザー" }, "samples_from": { "name": "samples_from" }, "samples_to": { "name": "samples_to" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const LatentCompositeMasked = { "display_name": "マスクされた潜在合成", "inputs": { "destination": { "name": "destination" }, "mask": { "name": "マスク" }, "resize_source": { "name": "resize_source" }, "source": { "name": "source" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const LatentConcat = { "display_name": "潜在空間結合", "inputs": { "dim": { "name": "次元" }, "samples1": { "name": "サンプル1" }, "samples2": { "name": "サンプル2" } }, "outputs": { "0": { "tooltip": null } } };
const LatentCrop = { "display_name": "潜在トリミング", "inputs": { "height": { "name": "高さ" }, "samples": { "name": "samples" }, "width": { "name": "幅" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const LatentCut = { "display_name": "潜在空間カット", "inputs": { "amount": { "name": "量" }, "dim": { "name": "次元" }, "index": { "name": "インデックス" }, "samples": { "name": "サンプル" } }, "outputs": { "0": { "tooltip": null } } };
const LatentFlip = { "display_name": "潜在反転", "inputs": { "flip_method": { "name": "反転方法" }, "samples": { "name": "samples" } } };
const LatentFromBatch = { "display_name": "バッチから潜在を取得", "inputs": { "batch_index": { "name": "バッチインデックス" }, "length": { "name": "長さ" }, "samples": { "name": "samples" } } };
const LatentInterpolate = { "display_name": "潜在補間", "inputs": { "ratio": { "name": "比率" }, "samples1": { "name": "samples1" }, "samples2": { "name": "samples2" } }, "outputs": { "0": { "tooltip": null } } };
const LatentMultiply = { "display_name": "潜在乗算", "inputs": { "multiplier": { "name": "乗数" }, "samples": { "name": "samples" } }, "outputs": { "0": { "tooltip": null } } };
const LatentOperationSharpen = { "display_name": "潜在操作シャープ化", "inputs": { "alpha": { "name": "アルファ" }, "sharpen_radius": { "name": "シャープ化半径" }, "sigma": { "name": "シグマ" } }, "outputs": { "0": { "tooltip": null } } };
const LatentOperationTonemapReinhard = { "display_name": "潜在操作トーンマップライナード", "inputs": { "multiplier": { "name": "乗数" } }, "outputs": { "0": { "tooltip": null } } };
const LatentRotate = { "display_name": "潜在回転", "inputs": { "rotation": { "name": "回転" }, "samples": { "name": "samples" } } };
const LatentSubtract = { "display_name": "潜在減算", "inputs": { "samples1": { "name": "samples1" }, "samples2": { "name": "samples2" } }, "outputs": { "0": { "tooltip": null } } };
const LatentUpscale = { "display_name": "潜在を拡大", "inputs": { "crop": { "name": "クロップ" }, "height": { "name": "高さ" }, "samples": { "name": "samples" }, "upscale_method": { "name": "拡大方法" }, "width": { "name": "幅" } } };
const LatentUpscaleBy = { "display_name": "潜在を拡大（指定サイズ）", "inputs": { "samples": { "name": "samples" }, "scale_by": { "name": "スケールバイ" }, "upscale_method": { "name": "拡大方法" } } };
const LazyCache = { "description": "EasyCacheの自家製バージョン - EasyCacheをさらに「簡単に」実装するバージョン。全体的にはEasyCacheより劣りますが、一部の稀なケースでは優れており、ComfyUIのすべてとの普遍的な互換性があります。", "display_name": "LazyCache", "inputs": { "end_percent": { "name": "終了パーセント", "tooltip": "LazyCacheの使用を終了する相対サンプリングステップ。" }, "model": { "name": "モデル", "tooltip": "LazyCacheを追加するモデル。" }, "reuse_threshold": { "name": "再利用しきい値", "tooltip": "キャッシュされたステップを再利用するしきい値。" }, "start_percent": { "name": "開始パーセント", "tooltip": "LazyCacheの使用を開始する相対サンプリングステップ。" }, "verbose": { "name": "詳細表示", "tooltip": "詳細情報をログに記録するかどうか。" } }, "outputs": { "0": { "tooltip": "LazyCacheを適用したモデル。" } } };
const Load3D = { "display_name": "3Dを読み込む", "inputs": { "clear": {}, "height": { "name": "高さ" }, "image": { "name": "画像" }, "model_file": { "name": "モデルファイル" }, "upload 3d model": {}, "width": { "name": "幅" } }, "outputs": { "0": { "name": "画像" }, "1": { "name": "マスク" }, "2": { "name": "メッシュパス" }, "3": { "name": "法線" }, "4": { "name": "線画" }, "5": { "name": "カメラ情報" } } };
const LoadAudio = { "display_name": "音声を読み込む", "inputs": { "audio": { "name": "オーディオ" }, "audioUI": { "name": "audioUI" }, "upload": { "name": "アップロードするファイルを選択" } } };
const LoadImage = { "display_name": "画像を読み込む", "inputs": { "image": { "name": "画像" }, "upload": { "name": "アップロードするファイルを選択" } } };
const LoadImageMask = { "display_name": "画像を読み込む（マスクとして）", "inputs": { "channel": { "name": "チャンネル" }, "image": { "name": "画像" }, "upload": { "name": "アップロードするファイルを選択" } } };
const LoadImageOutput = { "description": "出力フォルダから画像を読み込みます。更新ボタンをクリックすると、ノードは画像リストを更新し、自動的に最初の画像を選択します。これにより、簡単に反復処理が可能になります。", "display_name": "画像の読み込み（出力から）", "inputs": { "image": { "name": "画像" }, "refresh": {}, "upload": { "name": "アップロードするファイルを選択" } } };
const LoadLatent = { "display_name": "潜在を読み込む", "inputs": { "latent": { "name": "latent" } } };
const LoadVideo = { "display_name": "ビデオを読み込む", "inputs": { "file": { "name": "ファイル" }, "upload": { "name": "アップロードするファイルを選択" } }, "outputs": { "0": { "tooltip": null } } };
const LoraLoader = { "description": "LoRAは拡散およびCLIPモデルを修正するために使用され、潜在のノイズ除去方法を変更します。複数のLoRAノードを連結できます。", "display_name": "LoRAを読み込む", "inputs": { "clip": { "name": "クリップ", "tooltip": "LoRAが適用されるCLIPモデル。" }, "lora_name": { "name": "lora_name", "tooltip": "LoRAの名前。" }, "model": { "name": "モデル", "tooltip": "LoRAが適用される拡散モデル。" }, "strength_clip": { "name": "クリップの強度", "tooltip": "CLIPモデルをどの程度変更するか。この値は負の値になる可能性があります。" }, "strength_model": { "name": "モデルの強度", "tooltip": "拡散モデルをどの程度変更するか。この値は負の値になる可能性があります。" } }, "outputs": { "0": { "tooltip": "修正された拡散モデル。" }, "1": { "tooltip": "修正されたCLIPモデル。" } } };
const LoraLoaderModelOnly = { "description": "LoRAは拡散およびCLIPモデルを修正するために使用され、潜在のノイズ除去方法を変更します。複数のLoRAノードを連結できます。", "display_name": "LoRAローダーモデルのみ", "inputs": { "lora_name": { "name": "lora_name" }, "model": { "name": "モデル" }, "strength_model": { "name": "モデルの強度" } }, "outputs": { "0": { "tooltip": "修正された拡散モデル。" } } };
const LoraModelLoader = { "display_name": "LoRAモデルを読み込み", "inputs": { "lora": { "name": "LoRA", "tooltip": "拡散モデルに適用するLoRAモデル。" }, "model": { "name": "モデル", "tooltip": "LoRAが適用される拡散モデル。" }, "strength_model": { "name": "モデル強度", "tooltip": "拡散モデルを変更する強度。この値は負の値も可能です。" } }, "outputs": { "0": { "tooltip": "変更された拡散モデル。" } } };
const LoraSave = { "display_name": "LoRAを抽出して保存", "inputs": { "bias_diff": { "name": "バイアスの差" }, "filename_prefix": { "name": "ファイル名のプレフィックス" }, "lora_type": { "name": "lora_type" }, "model_diff": { "name": "モデルの差", "tooltip": "loraに変換されるModelSubtract出力。" }, "rank": { "name": "ランク" }, "text_encoder_diff": { "name": "テキストエンコーダの差", "tooltip": "loraに変換されるCLIPSubtract出力。" } } };
const LossGraphNode = { "display_name": "損失グラフをプロット", "inputs": { "filename_prefix": { "name": "ファイル名プレフィックス" }, "loss": { "name": "損失" } } };
const LotusConditioning = { "display_name": "LotusConditioning", "outputs": { "0": { "name": "コンディショニング", "tooltip": null } } };
const LtxvApiImageToVideo = { "description": "開始画像に基づいてカスタマイズ可能な長さと解像度のプロフェッショナル品質の動画。", "display_name": "LTXV 画像から動画へ", "inputs": { "duration": { "name": "長さ" }, "fps": { "name": "fps" }, "generate_audio": { "name": "オーディオ生成", "tooltip": "trueの場合、生成された動画にはシーンに合ったAI生成オーディオが含まれます。" }, "image": { "name": "画像", "tooltip": "動画の最初のフレームとして使用する画像。" }, "model": { "name": "モデル" }, "prompt": { "name": "プロンプト" }, "resolution": { "name": "解像度" } }, "outputs": { "0": { "tooltip": null } } };
const LtxvApiTextToVideo = { "description": "カスタマイズ可能な長さと解像度のプロフェッショナル品質の動画。", "display_name": "LTXV テキストから動画へ", "inputs": { "duration": { "name": "長さ" }, "fps": { "name": "fps" }, "generate_audio": { "name": "オーディオ生成", "tooltip": "trueの場合、生成された動画にはシーンに合ったAI生成オーディオが含まれます。" }, "model": { "name": "モデル" }, "prompt": { "name": "プロンプト" }, "resolution": { "name": "解像度" } }, "outputs": { "0": { "tooltip": null } } };
const LumaConceptsNode = { "description": "Luma Text to VideoおよびLuma Image to Videoノードで使用するための1つ以上のカメラコンセプトを保持します。", "display_name": "Lumaコンセプト", "inputs": { "concept1": { "name": "concept1" }, "concept2": { "name": "concept2" }, "concept3": { "name": "concept3" }, "concept4": { "name": "concept4" }, "luma_concepts": { "name": "luma_concepts", "tooltip": "ここで選択したものに追加するオプションのカメラコンセプト。" } }, "outputs": { "0": { "name": "luma_concepts", "tooltip": null } } };
const LumaImageModifyNode = { "description": "プロンプトとアスペクト比に基づいて画像を同期的に変更します。", "display_name": "Luma 画像から画像へ", "inputs": { "control_after_generate": { "name": "生成後のコントロール" }, "image": { "name": "画像" }, "image_weight": { "name": "画像の重み", "tooltip": "画像の重み。1.0に近いほど画像の変更が少なくなります。" }, "model": { "name": "モデル" }, "prompt": { "name": "プロンプト", "tooltip": "画像生成のためのプロンプト" }, "seed": { "name": "シード", "tooltip": "ノードを再実行するかどうかを決定するシード。実際の結果はシードに関係なく非決定的です。" } }, "outputs": { "0": { "tooltip": null } } };
const LumaImageNode = { "description": "プロンプトとアスペクト比に基づいて同期的に画像を生成します。", "display_name": "Luma テキストから画像へ", "inputs": { "aspect_ratio": { "name": "アスペクト比" }, "character_image": { "name": "キャラクター参照画像", "tooltip": "キャラクター参照画像。複数のバッチが可能で、最大4枚の画像が考慮されます。" }, "control_after_generate": { "name": "生成後のコントロール" }, "image_luma_ref": { "name": "Luma参照画像", "tooltip": "入力画像で生成を補助するLuma参照ノード接続。最大4枚の画像が考慮されます。" }, "model": { "name": "モデル" }, "prompt": { "name": "プロンプト", "tooltip": "画像生成のためのプロンプト" }, "seed": { "name": "シード", "tooltip": "ノードを再実行するかどうかを決定するシード。実際の結果はシードに関係なく非決定的です。" }, "style_image": { "name": "スタイル参照画像", "tooltip": "スタイル参照画像。1枚のみ使用されます。" }, "style_image_weight": { "name": "スタイル画像の重み", "tooltip": "スタイル画像の重み。style_imageが指定されていない場合は無視されます。" } }, "outputs": { "0": { "tooltip": null } } };
const LumaImageToVideoNode = { "description": "プロンプト、入力画像、およびoutput_sizeに基づいて同期的に動画を生成します。", "display_name": "Luma画像から動画へ", "inputs": { "control_after_generate": { "name": "生成後の制御" }, "duration": { "name": "再生時間" }, "first_image": { "name": "最初の画像", "tooltip": "生成された動画の最初のフレーム。" }, "last_image": { "name": "最後の画像", "tooltip": "生成された動画の最後のフレーム。" }, "loop": { "name": "ループ" }, "luma_concepts": { "name": "luma_concepts", "tooltip": "Luma Conceptsノードを通じてカメラの動きを制御するためのオプションのカメラコンセプト。" }, "model": { "name": "モデル" }, "prompt": { "name": "プロンプト", "tooltip": "動画生成用のプロンプト" }, "resolution": { "name": "解像度" }, "seed": { "name": "シード", "tooltip": "ノードを再実行するかどうかを決定するシード値。実際の結果はシードに関係なく非決定的です。" } }, "outputs": { "0": { "tooltip": null } } };
const LumaReferenceNode = { "description": "Luma Generate Imageノードで使用する画像と重みを保持します。", "display_name": "Luma Reference", "inputs": { "image": { "name": "image", "tooltip": "参照として使用する画像。" }, "luma_ref": { "name": "luma_ref" }, "weight": { "name": "weight", "tooltip": "画像参照の重み。" } }, "outputs": { "0": { "name": "luma_ref", "tooltip": null } } };
const LumaVideoNode = { "description": "プロンプトと出力サイズに基づいて同期的にビデオを生成します。", "display_name": "Luma テキストからビデオへ", "inputs": { "aspect_ratio": { "name": "アスペクト比" }, "control_after_generate": { "name": "生成後のコントロール" }, "duration": { "name": "再生時間" }, "loop": { "name": "ループ" }, "luma_concepts": { "name": "luma_concepts", "tooltip": "Luma Conceptsノードを通じてカメラの動きを指示するためのオプションのカメラコンセプト。" }, "model": { "name": "モデル" }, "prompt": { "name": "プロンプト", "tooltip": "ビデオ生成のためのプロンプト" }, "resolution": { "name": "解像度" }, "seed": { "name": "シード", "tooltip": "ノードを再実行するかどうかを決定するシード。実際の結果はシードに関係なく非決定的です。" } }, "outputs": { "0": { "tooltip": null } } };
const Mahiro = { "description": "ネガティブなプロンプトとの差ではなく、ポジティブなプロンプトの「方向」によりスケールするようにガイダンスを修正します。", "display_name": "Mahiroはとても可愛いので、より良いガイダンス機能が必要です!! (。・ω・。)", "inputs": { "model": { "name": "モデル" } }, "outputs": { "0": { "name": "パッチ適用モデル", "tooltip": null } } };
const MaskComposite = { "display_name": "マスク合成", "inputs": { "destination": { "name": "目的地" }, "operation": { "name": "操作" }, "source": { "name": "ソース" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const MaskPreview = { "description": "入力画像をComfyUIの出力ディレクトリに保存します。", "display_name": "MaskPreview", "inputs": { "mask": { "name": "mask" } } };
const MaskToImage = { "display_name": "マスクを画像に変換", "inputs": { "mask": { "name": "マスク" } } };
const MinimaxHailuoVideoNode = { "description": "新しいMiniMax Hailuo-02モデルを使用して、プロンプトから動画を生成します（開始フレームはオプション）。", "display_name": "MiniMax Hailuo 動画", "inputs": { "control_after_generate": { "name": "生成後の制御" }, "duration": { "name": "再生時間", "tooltip": "出力動画の長さ（秒単位）。" }, "first_frame_image": { "name": "最初のフレーム画像", "tooltip": "動画生成の最初のフレームとして使用するオプションの画像。" }, "prompt_optimizer": { "name": "プロンプト最適化", "tooltip": "必要に応じて生成品質を向上させるためにプロンプトを最適化します。" }, "prompt_text": { "name": "プロンプトテキスト", "tooltip": "動画生成をガイドするテキストプロンプト。" }, "resolution": { "name": "解像度", "tooltip": "動画表示の寸法。1080pは1920x1080、768pは1366x768です。" }, "seed": { "name": "シード", "tooltip": "ノイズ生成に使用されるランダムシード。" } }, "outputs": { "0": { "tooltip": null } } };
const MinimaxImageToVideoNode = { "description": "MiniMaxのAPIを使用して画像とプロンプトから動画を生成します", "display_name": "MiniMax 画像から動画へ", "inputs": { "control_after_generate": { "name": "生成後のコントロール" }, "image": { "name": "画像", "tooltip": "動画生成の最初のフレームとして使用する画像" }, "model": { "name": "モデル", "tooltip": "動画生成に使用するモデル" }, "prompt_text": { "name": "プロンプトテキスト", "tooltip": "動画生成をガイドするテキストプロンプト" }, "seed": { "name": "シード", "tooltip": "ノイズ生成に使用される乱数シード。" } }, "outputs": { "0": { "tooltip": null } } };
const MinimaxTextToVideoNode = { "description": "MiniMaxのAPIを使用してプロンプトからビデオを生成します", "display_name": "MiniMax テキストからビデオへ", "inputs": { "control_after_generate": { "name": "生成後のコントロール" }, "model": { "name": "モデル", "tooltip": "ビデオ生成に使用するモデル" }, "prompt_text": { "name": "プロンプトテキスト", "tooltip": "ビデオ生成をガイドするテキストプロンプト" }, "seed": { "name": "シード", "tooltip": "ノイズ生成に使用されるランダムシード。" } }, "outputs": { "0": { "tooltip": null } } };
const ModelComputeDtype = { "display_name": "ModelComputeDtype", "inputs": { "dtype": { "name": "dtype" }, "model": { "name": "モデル" } } };
const ModelMergeAdd = { "display_name": "モデルマージ追加", "inputs": { "model1": { "name": "モデル1" }, "model2": { "name": "モデル2" } } };
const ModelMergeAuraflow = { "display_name": "モデルマージオーラフロー", "inputs": { "cond_seq_linear_": { "name": "cond_seq_linear." }, "double_layers_0_": { "name": "double_layers.0." }, "double_layers_1_": { "name": "double_layers.1." }, "double_layers_2_": { "name": "double_layers.2." }, "double_layers_3_": { "name": "double_layers.3." }, "final_linear_": { "name": "final_linear." }, "init_x_linear_": { "name": "init_x_linear." }, "modF_": { "name": "modF." }, "model1": { "name": "モデル1" }, "model2": { "name": "モデル2" }, "positional_encoding": { "name": "位置エンコーディング" }, "register_tokens": { "name": "トークンを登録" }, "single_layers_0_": { "name": "single_layers.0." }, "single_layers_10_": { "name": "single_layers.10." }, "single_layers_11_": { "name": "single_layers.11." }, "single_layers_12_": { "name": "single_layers.12." }, "single_layers_13_": { "name": "single_layers.13." }, "single_layers_14_": { "name": "single_layers.14." }, "single_layers_15_": { "name": "single_layers.15." }, "single_layers_16_": { "name": "single_layers.16." }, "single_layers_17_": { "name": "single_layers.17." }, "single_layers_18_": { "name": "single_layers.18." }, "single_layers_19_": { "name": "single_layers.19." }, "single_layers_1_": { "name": "single_layers.1." }, "single_layers_20_": { "name": "single_layers.20." }, "single_layers_21_": { "name": "single_layers.21." }, "single_layers_22_": { "name": "single_layers.22." }, "single_layers_23_": { "name": "single_layers.23." }, "single_layers_24_": { "name": "single_layers.24." }, "single_layers_25_": { "name": "single_layers.25." }, "single_layers_26_": { "name": "single_layers.26." }, "single_layers_27_": { "name": "single_layers.27." }, "single_layers_28_": { "name": "single_layers.28." }, "single_layers_29_": { "name": "single_layers.29." }, "single_layers_2_": { "name": "single_layers.2." }, "single_layers_30_": { "name": "single_layers.30." }, "single_layers_31_": { "name": "single_layers.31." }, "single_layers_3_": { "name": "single_layers.3." }, "single_layers_4_": { "name": "single_layers.4." }, "single_layers_5_": { "name": "single_layers.5." }, "single_layers_6_": { "name": "single_layers.6." }, "single_layers_7_": { "name": "single_layers.7." }, "single_layers_8_": { "name": "single_layers.8." }, "single_layers_9_": { "name": "single_layers.9." }, "t_embedder_": { "name": "t_embedder." } } };
const ModelMergeBlocks = { "display_name": "モデルマージブロック", "inputs": { "input": { "name": "入力" }, "middle": { "name": "中間" }, "model1": { "name": "モデル1" }, "model2": { "name": "モデル2" }, "out": { "name": "出力" } } };
const ModelMergeCosmos14B = { "display_name": "ModelMergeCosmos14B", "inputs": { "affline_norm_": { "name": "affline_norm." }, "blocks_block0_": { "name": "blocks.block0." }, "blocks_block10_": { "name": "blocks.block10." }, "blocks_block11_": { "name": "blocks.block11." }, "blocks_block12_": { "name": "blocks.block12." }, "blocks_block13_": { "name": "blocks.block13." }, "blocks_block14_": { "name": "blocks.block14." }, "blocks_block15_": { "name": "blocks.block15." }, "blocks_block16_": { "name": "blocks.block16." }, "blocks_block17_": { "name": "blocks.block17." }, "blocks_block18_": { "name": "blocks.block18." }, "blocks_block19_": { "name": "blocks.block19." }, "blocks_block1_": { "name": "blocks.block1." }, "blocks_block20_": { "name": "blocks.block20." }, "blocks_block21_": { "name": "blocks.block21." }, "blocks_block22_": { "name": "blocks.block22." }, "blocks_block23_": { "name": "blocks.block23." }, "blocks_block24_": { "name": "blocks.block24." }, "blocks_block25_": { "name": "blocks.block25." }, "blocks_block26_": { "name": "blocks.block26." }, "blocks_block27_": { "name": "blocks.block27." }, "blocks_block28_": { "name": "blocks.block28." }, "blocks_block29_": { "name": "blocks.block29." }, "blocks_block2_": { "name": "blocks.block2." }, "blocks_block30_": { "name": "blocks.block30." }, "blocks_block31_": { "name": "blocks.block31." }, "blocks_block32_": { "name": "blocks.block32." }, "blocks_block33_": { "name": "blocks.block33." }, "blocks_block34_": { "name": "blocks.block34." }, "blocks_block35_": { "name": "blocks.block35." }, "blocks_block3_": { "name": "blocks.block3." }, "blocks_block4_": { "name": "blocks.block4." }, "blocks_block5_": { "name": "blocks.block5." }, "blocks_block6_": { "name": "blocks.block6." }, "blocks_block7_": { "name": "blocks.block7." }, "blocks_block8_": { "name": "blocks.block8." }, "blocks_block9_": { "name": "blocks.block9." }, "extra_pos_embedder_": { "name": "extra_pos_embedder." }, "final_layer_": { "name": "final_layer." }, "model1": { "name": "モデル1" }, "model2": { "name": "モデル2" }, "pos_embedder_": { "name": "pos_embedder." }, "t_embedder_": { "name": "t_embedder." }, "x_embedder_": { "name": "x_embedder." } } };
const ModelMergeCosmos7B = { "display_name": "ModelMergeCosmos7B", "inputs": { "affline_norm_": { "name": "affline_norm." }, "blocks_block0_": { "name": "blocks.block0." }, "blocks_block10_": { "name": "blocks.block10." }, "blocks_block11_": { "name": "blocks.block11." }, "blocks_block12_": { "name": "blocks.block12." }, "blocks_block13_": { "name": "blocks.block13." }, "blocks_block14_": { "name": "blocks.block14." }, "blocks_block15_": { "name": "blocks.block15." }, "blocks_block16_": { "name": "blocks.block16." }, "blocks_block17_": { "name": "blocks.block17." }, "blocks_block18_": { "name": "blocks.block18." }, "blocks_block19_": { "name": "blocks.block19." }, "blocks_block1_": { "name": "blocks.block1." }, "blocks_block20_": { "name": "blocks.block20." }, "blocks_block21_": { "name": "blocks.block21." }, "blocks_block22_": { "name": "blocks.block22." }, "blocks_block23_": { "name": "blocks.block23." }, "blocks_block24_": { "name": "blocks.block24." }, "blocks_block25_": { "name": "blocks.block25." }, "blocks_block26_": { "name": "blocks.block26." }, "blocks_block27_": { "name": "blocks.block27." }, "blocks_block2_": { "name": "blocks.block2." }, "blocks_block3_": { "name": "blocks.block3." }, "blocks_block4_": { "name": "blocks.block4." }, "blocks_block5_": { "name": "blocks.block5." }, "blocks_block6_": { "name": "blocks.block6." }, "blocks_block7_": { "name": "blocks.block7." }, "blocks_block8_": { "name": "blocks.block8." }, "blocks_block9_": { "name": "blocks.block9." }, "extra_pos_embedder_": { "name": "extra_pos_embedder." }, "final_layer_": { "name": "final_layer." }, "model1": { "name": "モデル1" }, "model2": { "name": "モデル2" }, "pos_embedder_": { "name": "pos_embedder." }, "t_embedder_": { "name": "t_embedder." }, "x_embedder_": { "name": "x_embedder." } } };
const ModelMergeCosmosPredict2_14B = { "display_name": "モデル統合コスモス予測2_14B", "inputs": { "blocks_0_": { "name": "ブロック0" }, "blocks_10_": { "name": "ブロック10" }, "blocks_11_": { "name": "ブロック11" }, "blocks_12_": { "name": "ブロック12" }, "blocks_13_": { "name": "ブロック13" }, "blocks_14_": { "name": "ブロック14" }, "blocks_15_": { "name": "ブロック15" }, "blocks_16_": { "name": "ブロック16" }, "blocks_17_": { "name": "ブロック17" }, "blocks_18_": { "name": "ブロック18" }, "blocks_19_": { "name": "ブロック19" }, "blocks_1_": { "name": "ブロック1" }, "blocks_20_": { "name": "ブロック20" }, "blocks_21_": { "name": "ブロック21" }, "blocks_22_": { "name": "ブロック22" }, "blocks_23_": { "name": "ブロック23" }, "blocks_24_": { "name": "ブロック24" }, "blocks_25_": { "name": "ブロック25" }, "blocks_26_": { "name": "ブロック26" }, "blocks_27_": { "name": "ブロック27" }, "blocks_28_": { "name": "ブロック28" }, "blocks_29_": { "name": "ブロック29" }, "blocks_2_": { "name": "ブロック2" }, "blocks_30_": { "name": "ブロック30" }, "blocks_31_": { "name": "ブロック31" }, "blocks_32_": { "name": "ブロック32" }, "blocks_33_": { "name": "ブロック33" }, "blocks_34_": { "name": "ブロック34" }, "blocks_35_": { "name": "blocks.35." }, "blocks_3_": { "name": "ブロック3" }, "blocks_4_": { "name": "ブロック4" }, "blocks_5_": { "name": "ブロック5" }, "blocks_6_": { "name": "ブロック6" }, "blocks_7_": { "name": "ブロック7" }, "blocks_8_": { "name": "ブロック8" }, "blocks_9_": { "name": "ブロック9" }, "final_layer_": { "name": "final_layer." }, "model1": { "name": "モデル1" }, "model2": { "name": "モデル2" }, "pos_embedder_": { "name": "位置埋め込み" }, "t_embedder_": { "name": "t埋め込み" }, "t_embedding_norm_": { "name": "t埋め込み正規化" }, "x_embedder_": { "name": "x埋め込み" } } };
const ModelMergeCosmosPredict2_2B = { "display_name": "ModelMergeCosmosPredict2_2B", "inputs": { "blocks_0_": { "name": "blocks.0." }, "blocks_10_": { "name": "blocks.10." }, "blocks_11_": { "name": "blocks.11." }, "blocks_12_": { "name": "blocks.12." }, "blocks_13_": { "name": "blocks.13." }, "blocks_14_": { "name": "blocks.14." }, "blocks_15_": { "name": "blocks.15." }, "blocks_16_": { "name": "blocks.16." }, "blocks_17_": { "name": "blocks.17." }, "blocks_18_": { "name": "blocks.18." }, "blocks_19_": { "name": "blocks.19." }, "blocks_1_": { "name": "blocks.1." }, "blocks_20_": { "name": "blocks.20." }, "blocks_21_": { "name": "blocks.21." }, "blocks_22_": { "name": "blocks.22." }, "blocks_23_": { "name": "blocks.23." }, "blocks_24_": { "name": "blocks.24." }, "blocks_25_": { "name": "blocks.25." }, "blocks_26_": { "name": "blocks.26." }, "blocks_27_": { "name": "blocks.27." }, "blocks_2_": { "name": "blocks.2." }, "blocks_3_": { "name": "blocks.3." }, "blocks_4_": { "name": "blocks.4." }, "blocks_5_": { "name": "blocks.5." }, "blocks_6_": { "name": "blocks.6." }, "blocks_7_": { "name": "blocks.7." }, "blocks_8_": { "name": "blocks.8." }, "blocks_9_": { "name": "blocks.9." }, "final_layer_": { "name": "final_layer." }, "model1": { "name": "model1" }, "model2": { "name": "model2" }, "pos_embedder_": { "name": "pos_embedder." }, "t_embedder_": { "name": "t_embedder." }, "t_embedding_norm_": { "name": "t_embedding_norm." }, "x_embedder_": { "name": "x_embedder." } } };
const ModelMergeFlux1 = { "display_name": "モデルマージフラックス1", "inputs": { "double_blocks_0_": { "name": "double_blocks.0." }, "double_blocks_10_": { "name": "double_blocks.10." }, "double_blocks_11_": { "name": "double_blocks.11." }, "double_blocks_12_": { "name": "double_blocks.12." }, "double_blocks_13_": { "name": "double_blocks.13." }, "double_blocks_14_": { "name": "double_blocks.14." }, "double_blocks_15_": { "name": "double_blocks.15." }, "double_blocks_16_": { "name": "double_blocks.16." }, "double_blocks_17_": { "name": "double_blocks.17." }, "double_blocks_18_": { "name": "double_blocks.18." }, "double_blocks_1_": { "name": "double_blocks.1." }, "double_blocks_2_": { "name": "double_blocks.2." }, "double_blocks_3_": { "name": "double_blocks.3." }, "double_blocks_4_": { "name": "double_blocks.4." }, "double_blocks_5_": { "name": "double_blocks.5." }, "double_blocks_6_": { "name": "double_blocks.6." }, "double_blocks_7_": { "name": "double_blocks.7." }, "double_blocks_8_": { "name": "double_blocks.8." }, "double_blocks_9_": { "name": "double_blocks.9." }, "final_layer_": { "name": "final_layer." }, "guidance_in": { "name": "guidance_in" }, "img_in_": { "name": "img_in." }, "model1": { "name": "モデル1" }, "model2": { "name": "モデル2" }, "single_blocks_0_": { "name": "single_blocks.0." }, "single_blocks_10_": { "name": "single_blocks.10." }, "single_blocks_11_": { "name": "single_blocks.11." }, "single_blocks_12_": { "name": "single_blocks.12." }, "single_blocks_13_": { "name": "single_blocks.13." }, "single_blocks_14_": { "name": "single_blocks.14." }, "single_blocks_15_": { "name": "single_blocks.15." }, "single_blocks_16_": { "name": "single_blocks.16." }, "single_blocks_17_": { "name": "single_blocks.17." }, "single_blocks_18_": { "name": "single_blocks.18." }, "single_blocks_19_": { "name": "single_blocks.19." }, "single_blocks_1_": { "name": "single_blocks.1." }, "single_blocks_20_": { "name": "single_blocks.20." }, "single_blocks_21_": { "name": "single_blocks.21." }, "single_blocks_22_": { "name": "single_blocks.22." }, "single_blocks_23_": { "name": "single_blocks.23." }, "single_blocks_24_": { "name": "single_blocks.24." }, "single_blocks_25_": { "name": "single_blocks.25." }, "single_blocks_26_": { "name": "single_blocks.26." }, "single_blocks_27_": { "name": "single_blocks.27." }, "single_blocks_28_": { "name": "single_blocks.28." }, "single_blocks_29_": { "name": "single_blocks.29." }, "single_blocks_2_": { "name": "single_blocks.2." }, "single_blocks_30_": { "name": "single_blocks.30." }, "single_blocks_31_": { "name": "single_blocks.31." }, "single_blocks_32_": { "name": "single_blocks.32." }, "single_blocks_33_": { "name": "single_blocks.33." }, "single_blocks_34_": { "name": "single_blocks.34." }, "single_blocks_35_": { "name": "single_blocks.35." }, "single_blocks_36_": { "name": "single_blocks.36." }, "single_blocks_37_": { "name": "single_blocks.37." }, "single_blocks_3_": { "name": "single_blocks.3." }, "single_blocks_4_": { "name": "single_blocks.4." }, "single_blocks_5_": { "name": "single_blocks.5." }, "single_blocks_6_": { "name": "single_blocks.6." }, "single_blocks_7_": { "name": "single_blocks.7." }, "single_blocks_8_": { "name": "single_blocks.8." }, "single_blocks_9_": { "name": "single_blocks.9." }, "time_in_": { "name": "time_in." }, "txt_in_": { "name": "txt_in." }, "vector_in_": { "name": "vector_in." } } };
const ModelMergeLTXV = { "display_name": "モデルマージLTXV", "inputs": { "adaln_single_": { "name": "adaln_single." }, "caption_projection_": { "name": "キャプション投影." }, "model1": { "name": "モデル1" }, "model2": { "name": "モデル2" }, "patchify_proj_": { "name": "patchify_proj." }, "proj_out_": { "name": "proj_out." }, "scale_shift_table": { "name": "スケールシフトテーブル" }, "transformer_blocks_0_": { "name": "トランスフォーマーブロック.0." }, "transformer_blocks_10_": { "name": "トランスフォーマーブロック.10." }, "transformer_blocks_11_": { "name": "トランスフォーマーブロック.11." }, "transformer_blocks_12_": { "name": "トランスフォーマーブロック.12." }, "transformer_blocks_13_": { "name": "トランスフォーマーブロック.13." }, "transformer_blocks_14_": { "name": "トランスフォーマーブロック.14." }, "transformer_blocks_15_": { "name": "トランスフォーマーブロック.15." }, "transformer_blocks_16_": { "name": "トランスフォーマーブロック.16." }, "transformer_blocks_17_": { "name": "トランスフォーマーブロック.17." }, "transformer_blocks_18_": { "name": "トランスフォーマーブロック.18." }, "transformer_blocks_19_": { "name": "トランスフォーマーブロック.19." }, "transformer_blocks_1_": { "name": "トランスフォーマーブロック.1." }, "transformer_blocks_20_": { "name": "トランスフォーマーブロック.20." }, "transformer_blocks_21_": { "name": "トランスフォーマーブロック.21." }, "transformer_blocks_22_": { "name": "トランスフォーマーブロック.22." }, "transformer_blocks_23_": { "name": "トランスフォーマーブロック.23." }, "transformer_blocks_24_": { "name": "トランスフォーマーブロック.24." }, "transformer_blocks_25_": { "name": "トランスフォーマーブロック.25." }, "transformer_blocks_26_": { "name": "トランスフォーマーブロック.26." }, "transformer_blocks_27_": { "name": "トランスフォーマーブロック.27." }, "transformer_blocks_2_": { "name": "トランスフォーマーブロック.2." }, "transformer_blocks_3_": { "name": "トランスフォーマーブロック.3." }, "transformer_blocks_4_": { "name": "トランスフォーマーブロック.4." }, "transformer_blocks_5_": { "name": "トランスフォーマーブロック.5." }, "transformer_blocks_6_": { "name": "トランスフォーマーブロック.6." }, "transformer_blocks_7_": { "name": "トランスフォーマーブロック.7." }, "transformer_blocks_8_": { "name": "トランスフォーマーブロック.8." }, "transformer_blocks_9_": { "name": "トランスフォーマーブロック.9." } } };
const ModelMergeMochiPreview = { "display_name": "モデルマージMochiプレビュー", "inputs": { "blocks_0_": { "name": "blocks.0." }, "blocks_10_": { "name": "blocks.10." }, "blocks_11_": { "name": "blocks.11." }, "blocks_12_": { "name": "blocks.12." }, "blocks_13_": { "name": "blocks.13." }, "blocks_14_": { "name": "blocks.14." }, "blocks_15_": { "name": "blocks.15." }, "blocks_16_": { "name": "blocks.16." }, "blocks_17_": { "name": "blocks.17." }, "blocks_18_": { "name": "blocks.18." }, "blocks_19_": { "name": "blocks.19." }, "blocks_1_": { "name": "blocks.1." }, "blocks_20_": { "name": "blocks.20." }, "blocks_21_": { "name": "blocks.21." }, "blocks_22_": { "name": "blocks.22." }, "blocks_23_": { "name": "blocks.23." }, "blocks_24_": { "name": "blocks.24." }, "blocks_25_": { "name": "blocks.25." }, "blocks_26_": { "name": "blocks.26." }, "blocks_27_": { "name": "blocks.27." }, "blocks_28_": { "name": "blocks.28." }, "blocks_29_": { "name": "blocks.29." }, "blocks_2_": { "name": "blocks.2." }, "blocks_30_": { "name": "blocks.30." }, "blocks_31_": { "name": "blocks.31." }, "blocks_32_": { "name": "blocks.32." }, "blocks_33_": { "name": "blocks.33." }, "blocks_34_": { "name": "blocks.34." }, "blocks_35_": { "name": "blocks.35." }, "blocks_36_": { "name": "blocks.36." }, "blocks_37_": { "name": "blocks.37." }, "blocks_38_": { "name": "blocks.38." }, "blocks_39_": { "name": "blocks.39." }, "blocks_3_": { "name": "blocks.3." }, "blocks_40_": { "name": "blocks.40." }, "blocks_41_": { "name": "blocks.41." }, "blocks_42_": { "name": "blocks.42." }, "blocks_43_": { "name": "blocks.43." }, "blocks_44_": { "name": "blocks.44." }, "blocks_45_": { "name": "blocks.45." }, "blocks_46_": { "name": "blocks.46." }, "blocks_47_": { "name": "blocks.47." }, "blocks_4_": { "name": "blocks.4." }, "blocks_5_": { "name": "blocks.5." }, "blocks_6_": { "name": "blocks.6." }, "blocks_7_": { "name": "blocks.7." }, "blocks_8_": { "name": "blocks.8." }, "blocks_9_": { "name": "blocks.9." }, "final_layer_": { "name": "final_layer." }, "model1": { "name": "モデル1" }, "model2": { "name": "モデル2" }, "pos_frequencies_": { "name": "pos_frequencies." }, "t5_y_embedder_": { "name": "t5_y_embedder." }, "t5_yproj_": { "name": "t5_yproj." }, "t_embedder_": { "name": "t_embedder." } } };
const ModelMergeQwenImage = { "display_name": "ModelMergeQwenImage", "inputs": { "img_in_": { "name": "img_in." }, "model1": { "name": "model1" }, "model2": { "name": "model2" }, "pos_embeds_": { "name": "pos_embeds." }, "proj_out_": { "name": "proj_out." }, "time_text_embed_": { "name": "time_text_embed." }, "transformer_blocks_0_": { "name": "transformer_blocks.0." }, "transformer_blocks_10_": { "name": "transformer_blocks.10." }, "transformer_blocks_11_": { "name": "transformer_blocks.11." }, "transformer_blocks_12_": { "name": "transformer_blocks.12." }, "transformer_blocks_13_": { "name": "transformer_blocks.13." }, "transformer_blocks_14_": { "name": "transformer_blocks.14." }, "transformer_blocks_15_": { "name": "transformer_blocks.15." }, "transformer_blocks_16_": { "name": "transformer_blocks.16." }, "transformer_blocks_17_": { "name": "transformer_blocks.17." }, "transformer_blocks_18_": { "name": "transformer_blocks.18." }, "transformer_blocks_19_": { "name": "transformer_blocks.19." }, "transformer_blocks_1_": { "name": "transformer_blocks.1." }, "transformer_blocks_20_": { "name": "transformer_blocks.20." }, "transformer_blocks_21_": { "name": "transformer_blocks.21." }, "transformer_blocks_22_": { "name": "transformer_blocks.22." }, "transformer_blocks_23_": { "name": "transformer_blocks.23." }, "transformer_blocks_24_": { "name": "transformer_blocks.24." }, "transformer_blocks_25_": { "name": "transformer_blocks.25." }, "transformer_blocks_26_": { "name": "transformer_blocks.26." }, "transformer_blocks_27_": { "name": "transformer_blocks.27." }, "transformer_blocks_28_": { "name": "transformer_blocks.28." }, "transformer_blocks_29_": { "name": "transformer_blocks.29." }, "transformer_blocks_2_": { "name": "transformer_blocks.2." }, "transformer_blocks_30_": { "name": "transformer_blocks.30." }, "transformer_blocks_31_": { "name": "transformer_blocks.31." }, "transformer_blocks_32_": { "name": "transformer_blocks.32." }, "transformer_blocks_33_": { "name": "transformer_blocks.33." }, "transformer_blocks_34_": { "name": "transformer_blocks.34." }, "transformer_blocks_35_": { "name": "transformer_blocks.35." }, "transformer_blocks_36_": { "name": "transformer_blocks.36." }, "transformer_blocks_37_": { "name": "transformer_blocks.37." }, "transformer_blocks_38_": { "name": "transformer_blocks.38." }, "transformer_blocks_39_": { "name": "transformer_blocks.39." }, "transformer_blocks_3_": { "name": "transformer_blocks.3." }, "transformer_blocks_40_": { "name": "transformer_blocks.40." }, "transformer_blocks_41_": { "name": "transformer_blocks.41." }, "transformer_blocks_42_": { "name": "transformer_blocks.42." }, "transformer_blocks_43_": { "name": "transformer_blocks.43." }, "transformer_blocks_44_": { "name": "transformer_blocks.44." }, "transformer_blocks_45_": { "name": "transformer_blocks.45." }, "transformer_blocks_46_": { "name": "transformer_blocks.46." }, "transformer_blocks_47_": { "name": "transformer_blocks.47." }, "transformer_blocks_48_": { "name": "transformer_blocks.48." }, "transformer_blocks_49_": { "name": "transformer_blocks.49." }, "transformer_blocks_4_": { "name": "transformer_blocks.4." }, "transformer_blocks_50_": { "name": "transformer_blocks.50." }, "transformer_blocks_51_": { "name": "transformer_blocks.51." }, "transformer_blocks_52_": { "name": "transformer_blocks.52." }, "transformer_blocks_53_": { "name": "transformer_blocks.53." }, "transformer_blocks_54_": { "name": "transformer_blocks.54." }, "transformer_blocks_55_": { "name": "transformer_blocks.55." }, "transformer_blocks_56_": { "name": "transformer_blocks.56." }, "transformer_blocks_57_": { "name": "transformer_blocks.57." }, "transformer_blocks_58_": { "name": "transformer_blocks.58." }, "transformer_blocks_59_": { "name": "transformer_blocks.59." }, "transformer_blocks_5_": { "name": "transformer_blocks.5." }, "transformer_blocks_6_": { "name": "transformer_blocks.6." }, "transformer_blocks_7_": { "name": "transformer_blocks.7." }, "transformer_blocks_8_": { "name": "transformer_blocks.8." }, "transformer_blocks_9_": { "name": "transformer_blocks.9." }, "txt_in_": { "name": "txt_in." }, "txt_norm_": { "name": "txt_norm." } } };
const ModelMergeSD1 = { "display_name": "モデルマージSD1", "inputs": { "input_blocks_0_": { "name": "input_blocks.0." }, "input_blocks_10_": { "name": "input_blocks.10." }, "input_blocks_11_": { "name": "input_blocks.11." }, "input_blocks_1_": { "name": "input_blocks.1." }, "input_blocks_2_": { "name": "input_blocks.2." }, "input_blocks_3_": { "name": "input_blocks.3." }, "input_blocks_4_": { "name": "input_blocks.4." }, "input_blocks_5_": { "name": "input_blocks.5." }, "input_blocks_6_": { "name": "input_blocks.6." }, "input_blocks_7_": { "name": "input_blocks.7." }, "input_blocks_8_": { "name": "input_blocks.8." }, "input_blocks_9_": { "name": "input_blocks.9." }, "label_emb_": { "name": "label_emb." }, "middle_block_0_": { "name": "middle_block.0." }, "middle_block_1_": { "name": "middle_block.1." }, "middle_block_2_": { "name": "middle_block.2." }, "model1": { "name": "モデル1" }, "model2": { "name": "モデル2" }, "out_": { "name": "out." }, "output_blocks_0_": { "name": "output_blocks.0." }, "output_blocks_10_": { "name": "output_blocks.10." }, "output_blocks_11_": { "name": "output_blocks.11." }, "output_blocks_1_": { "name": "output_blocks.1." }, "output_blocks_2_": { "name": "output_blocks.2." }, "output_blocks_3_": { "name": "output_blocks.3." }, "output_blocks_4_": { "name": "output_blocks.4." }, "output_blocks_5_": { "name": "output_blocks.5." }, "output_blocks_6_": { "name": "output_blocks.6." }, "output_blocks_7_": { "name": "output_blocks.7." }, "output_blocks_8_": { "name": "output_blocks.8." }, "output_blocks_9_": { "name": "output_blocks.9." }, "time_embed_": { "name": "time_embed." } } };
const ModelMergeSD2 = { "display_name": "モデルマージSD2", "inputs": { "input_blocks_0_": { "name": "input_blocks.0." }, "input_blocks_10_": { "name": "input_blocks.10." }, "input_blocks_11_": { "name": "input_blocks.11." }, "input_blocks_1_": { "name": "input_blocks.1." }, "input_blocks_2_": { "name": "input_blocks.2." }, "input_blocks_3_": { "name": "input_blocks.3." }, "input_blocks_4_": { "name": "input_blocks.4." }, "input_blocks_5_": { "name": "input_blocks.5." }, "input_blocks_6_": { "name": "input_blocks.6." }, "input_blocks_7_": { "name": "input_blocks.7." }, "input_blocks_8_": { "name": "input_blocks.8." }, "input_blocks_9_": { "name": "input_blocks.9." }, "label_emb_": { "name": "label_emb." }, "middle_block_0_": { "name": "middle_block.0." }, "middle_block_1_": { "name": "middle_block.1." }, "middle_block_2_": { "name": "middle_block.2." }, "model1": { "name": "モデル1" }, "model2": { "name": "モデル2" }, "out_": { "name": "out." }, "output_blocks_0_": { "name": "output_blocks.0." }, "output_blocks_10_": { "name": "output_blocks.10." }, "output_blocks_11_": { "name": "output_blocks.11." }, "output_blocks_1_": { "name": "output_blocks.1." }, "output_blocks_2_": { "name": "output_blocks.2." }, "output_blocks_3_": { "name": "output_blocks.3." }, "output_blocks_4_": { "name": "output_blocks.4." }, "output_blocks_5_": { "name": "output_blocks.5." }, "output_blocks_6_": { "name": "output_blocks.6." }, "output_blocks_7_": { "name": "output_blocks.7." }, "output_blocks_8_": { "name": "output_blocks.8." }, "output_blocks_9_": { "name": "output_blocks.9." }, "time_embed_": { "name": "time_embed." } } };
const ModelMergeSD35_Large = { "display_name": "モデルマージSD35_Large", "inputs": { "context_embedder_": { "name": "context_embedder." }, "final_layer_": { "name": "final_layer." }, "joint_blocks_0_": { "name": "joint_blocks.0." }, "joint_blocks_10_": { "name": "joint_blocks.10." }, "joint_blocks_11_": { "name": "joint_blocks.11." }, "joint_blocks_12_": { "name": "joint_blocks.12." }, "joint_blocks_13_": { "name": "joint_blocks.13." }, "joint_blocks_14_": { "name": "joint_blocks.14." }, "joint_blocks_15_": { "name": "joint_blocks.15." }, "joint_blocks_16_": { "name": "joint_blocks.16." }, "joint_blocks_17_": { "name": "joint_blocks.17." }, "joint_blocks_18_": { "name": "joint_blocks.18." }, "joint_blocks_19_": { "name": "joint_blocks.19." }, "joint_blocks_1_": { "name": "joint_blocks.1." }, "joint_blocks_20_": { "name": "joint_blocks.20." }, "joint_blocks_21_": { "name": "joint_blocks.21." }, "joint_blocks_22_": { "name": "joint_blocks.22." }, "joint_blocks_23_": { "name": "joint_blocks.23." }, "joint_blocks_24_": { "name": "joint_blocks.24." }, "joint_blocks_25_": { "name": "joint_blocks.25." }, "joint_blocks_26_": { "name": "joint_blocks.26." }, "joint_blocks_27_": { "name": "joint_blocks.27." }, "joint_blocks_28_": { "name": "joint_blocks.28." }, "joint_blocks_29_": { "name": "joint_blocks.29." }, "joint_blocks_2_": { "name": "joint_blocks.2." }, "joint_blocks_30_": { "name": "joint_blocks.30." }, "joint_blocks_31_": { "name": "joint_blocks.31." }, "joint_blocks_32_": { "name": "joint_blocks.32." }, "joint_blocks_33_": { "name": "joint_blocks.33." }, "joint_blocks_34_": { "name": "joint_blocks.34." }, "joint_blocks_35_": { "name": "joint_blocks.35." }, "joint_blocks_36_": { "name": "joint_blocks.36." }, "joint_blocks_37_": { "name": "joint_blocks.37." }, "joint_blocks_3_": { "name": "joint_blocks.3." }, "joint_blocks_4_": { "name": "joint_blocks.4." }, "joint_blocks_5_": { "name": "joint_blocks.5." }, "joint_blocks_6_": { "name": "joint_blocks.6." }, "joint_blocks_7_": { "name": "joint_blocks.7." }, "joint_blocks_8_": { "name": "joint_blocks.8." }, "joint_blocks_9_": { "name": "joint_blocks.9." }, "model1": { "name": "モデル1" }, "model2": { "name": "モデル2" }, "pos_embed_": { "name": "pos_embed." }, "t_embedder_": { "name": "t_embedder." }, "x_embedder_": { "name": "x_embedder." }, "y_embedder_": { "name": "y_embedder." } } };
const ModelMergeSD3_2B = { "display_name": "モデルマージSD3_2B", "inputs": { "context_embedder_": { "name": "context_embedder." }, "final_layer_": { "name": "final_layer." }, "joint_blocks_0_": { "name": "joint_blocks.0." }, "joint_blocks_10_": { "name": "joint_blocks.10." }, "joint_blocks_11_": { "name": "joint_blocks.11." }, "joint_blocks_12_": { "name": "joint_blocks.12." }, "joint_blocks_13_": { "name": "joint_blocks.13." }, "joint_blocks_14_": { "name": "joint_blocks.14." }, "joint_blocks_15_": { "name": "joint_blocks.15." }, "joint_blocks_16_": { "name": "joint_blocks.16." }, "joint_blocks_17_": { "name": "joint_blocks.17." }, "joint_blocks_18_": { "name": "joint_blocks.18." }, "joint_blocks_19_": { "name": "joint_blocks.19." }, "joint_blocks_1_": { "name": "joint_blocks.1." }, "joint_blocks_20_": { "name": "joint_blocks.20." }, "joint_blocks_21_": { "name": "joint_blocks.21." }, "joint_blocks_22_": { "name": "joint_blocks.22." }, "joint_blocks_23_": { "name": "joint_blocks.23." }, "joint_blocks_2_": { "name": "joint_blocks.2." }, "joint_blocks_3_": { "name": "joint_blocks.3." }, "joint_blocks_4_": { "name": "joint_blocks.4." }, "joint_blocks_5_": { "name": "joint_blocks.5." }, "joint_blocks_6_": { "name": "joint_blocks.6." }, "joint_blocks_7_": { "name": "joint_blocks.7." }, "joint_blocks_8_": { "name": "joint_blocks.8." }, "joint_blocks_9_": { "name": "joint_blocks.9." }, "model1": { "name": "モデル1" }, "model2": { "name": "モデル2" }, "pos_embed_": { "name": "pos_embed." }, "t_embedder_": { "name": "t_embedder." }, "x_embedder_": { "name": "x_embedder." }, "y_embedder_": { "name": "y_embedder." } } };
const ModelMergeSDXL = { "display_name": "モデルマージSDXL", "inputs": { "input_blocks_0": { "name": "input_blocks.0" }, "input_blocks_1": { "name": "input_blocks.1" }, "input_blocks_2": { "name": "input_blocks.2" }, "input_blocks_3": { "name": "input_blocks.3" }, "input_blocks_4": { "name": "input_blocks.4" }, "input_blocks_5": { "name": "input_blocks.5" }, "input_blocks_6": { "name": "input_blocks.6" }, "input_blocks_7": { "name": "input_blocks.7" }, "input_blocks_8": { "name": "input_blocks.8" }, "label_emb_": { "name": "label_emb." }, "middle_block_0": { "name": "middle_block.0" }, "middle_block_1": { "name": "middle_block.1" }, "middle_block_2": { "name": "middle_block.2" }, "model1": { "name": "モデル1" }, "model2": { "name": "モデル2" }, "out_": { "name": "out." }, "output_blocks_0": { "name": "output_blocks.0" }, "output_blocks_1": { "name": "output_blocks.1" }, "output_blocks_2": { "name": "output_blocks.2" }, "output_blocks_3": { "name": "output_blocks.3" }, "output_blocks_4": { "name": "output_blocks.4" }, "output_blocks_5": { "name": "output_blocks.5" }, "output_blocks_6": { "name": "output_blocks.6" }, "output_blocks_7": { "name": "output_blocks.7" }, "output_blocks_8": { "name": "output_blocks.8" }, "time_embed_": { "name": "time_embed." } } };
const ModelMergeSimple = { "display_name": "モデルマージシンプル", "inputs": { "model1": { "name": "モデル1" }, "model2": { "name": "モデル2" }, "ratio": { "name": "比率" } } };
const ModelMergeSubtract = { "display_name": "モデルマージ減算", "inputs": { "model1": { "name": "モデル1" }, "model2": { "name": "モデル2" }, "multiplier": { "name": "乗数" } } };
const ModelMergeWAN2_1 = { "description": "1.3Bモデルは30ブロック、14Bモデルは40ブロックです。画像から動画へのモデルには追加のimg_embがあります。", "display_name": "ModelMergeWAN2_1", "inputs": { "blocks_0_": { "name": "blocks.0." }, "blocks_10_": { "name": "blocks.10." }, "blocks_11_": { "name": "blocks.11." }, "blocks_12_": { "name": "blocks.12." }, "blocks_13_": { "name": "blocks.13." }, "blocks_14_": { "name": "blocks.14." }, "blocks_15_": { "name": "blocks.15." }, "blocks_16_": { "name": "blocks.16." }, "blocks_17_": { "name": "blocks.17." }, "blocks_18_": { "name": "blocks.18." }, "blocks_19_": { "name": "blocks.19." }, "blocks_1_": { "name": "blocks.1." }, "blocks_20_": { "name": "blocks.20." }, "blocks_21_": { "name": "blocks.21." }, "blocks_22_": { "name": "blocks.22." }, "blocks_23_": { "name": "blocks.23." }, "blocks_24_": { "name": "blocks.24." }, "blocks_25_": { "name": "blocks.25." }, "blocks_26_": { "name": "blocks.26." }, "blocks_27_": { "name": "blocks.27." }, "blocks_28_": { "name": "blocks.28." }, "blocks_29_": { "name": "blocks.29." }, "blocks_2_": { "name": "blocks.2." }, "blocks_30_": { "name": "blocks.30." }, "blocks_31_": { "name": "blocks.31." }, "blocks_32_": { "name": "blocks.32." }, "blocks_33_": { "name": "blocks.33." }, "blocks_34_": { "name": "blocks.34." }, "blocks_35_": { "name": "blocks.35." }, "blocks_36_": { "name": "blocks.36." }, "blocks_37_": { "name": "blocks.37." }, "blocks_38_": { "name": "blocks.38." }, "blocks_39_": { "name": "blocks.39." }, "blocks_3_": { "name": "blocks.3." }, "blocks_4_": { "name": "blocks.4." }, "blocks_5_": { "name": "blocks.5." }, "blocks_6_": { "name": "blocks.6." }, "blocks_7_": { "name": "blocks.7." }, "blocks_8_": { "name": "blocks.8." }, "blocks_9_": { "name": "blocks.9." }, "head_": { "name": "head." }, "img_emb_": { "name": "img_emb." }, "model1": { "name": "model1" }, "model2": { "name": "model2" }, "patch_embedding_": { "name": "patch_embedding." }, "text_embedding_": { "name": "text_embedding." }, "time_embedding_": { "name": "time_embedding." }, "time_projection_": { "name": "time_projection." } } };
const ModelPatchLoader = { "display_name": "モデルパッチローダー", "inputs": { "name": { "name": "名前" } } };
const ModelSamplingAuraFlow = { "display_name": "モデルサンプリングオーラフロー", "inputs": { "model": { "name": "モデル" }, "shift": { "name": "シフト" } } };
const ModelSamplingContinuousEDM = { "display_name": "モデルサンプリング連続EDM", "inputs": { "model": { "name": "モデル" }, "sampling": { "name": "サンプリング" }, "sigma_max": { "name": "sigma_max" }, "sigma_min": { "name": "sigma_min" } } };
const ModelSamplingContinuousV = { "display_name": "モデルサンプリング連続V", "inputs": { "model": { "name": "モデル" }, "sampling": { "name": "サンプリング" }, "sigma_max": { "name": "sigma_max" }, "sigma_min": { "name": "sigma_min" } } };
const ModelSamplingDiscrete = { "display_name": "モデルサンプリング離散", "inputs": { "model": { "name": "モデル" }, "sampling": { "name": "サンプリング" }, "zsnr": { "name": "zsnr" } } };
const ModelSamplingFlux = { "display_name": "モデルサンプリングフラックス", "inputs": { "base_shift": { "name": "基本シフト" }, "height": { "name": "高さ" }, "max_shift": { "name": "最大シフト" }, "model": { "name": "モデル" }, "width": { "name": "幅" } } };
const ModelSamplingLTXV = { "display_name": "モデルサンプリングLTXV", "inputs": { "base_shift": { "name": "基本シフト" }, "latent": { "name": "潜在" }, "max_shift": { "name": "最大シフト" }, "model": { "name": "モデル" } }, "outputs": { "0": { "tooltip": null } } };
const ModelSamplingSD3 = { "display_name": "モデルサンプリングSD3", "inputs": { "model": { "name": "モデル" }, "shift": { "name": "シフト" } } };
const ModelSamplingStableCascade = { "display_name": "モデルサンプリング安定カスケード", "inputs": { "model": { "name": "モデル" }, "shift": { "name": "シフト" } } };
const ModelSave = { "display_name": "モデルを保存", "inputs": { "filename_prefix": { "name": "ファイル名プレフィックス" }, "model": { "name": "モデル" } } };
const MoonvalleyImg2VideoNode = { "description": "Moonvalley Marey 画像から動画ノード", "display_name": "Moonvalley Marey 画像から動画", "inputs": { "control_after_generate": { "name": "生成後の制御" }, "image": { "name": "画像", "tooltip": "動画生成に使用する参照画像" }, "negative_prompt": { "name": "ネガティブプロンプト", "tooltip": "ネガティブプロンプトテキスト" }, "prompt": { "name": "プロンプト" }, "prompt_adherence": { "name": "プロンプト遵守度", "tooltip": "生成制御のためのガイダンススケール" }, "resolution": { "name": "解像度", "tooltip": "出力動画の解像度" }, "seed": { "name": "シード", "tooltip": "ランダムシード値" }, "steps": { "name": "ステップ数", "tooltip": "ノイズ除去ステップ数" } }, "outputs": { "0": { "tooltip": null } } };
const MoonvalleyTxt2VideoNode = { "display_name": "Moonvalley Marey テキストから動画", "inputs": { "control_after_generate": { "name": "生成後の制御" }, "negative_prompt": { "name": "ネガティブプロンプト", "tooltip": "ネガティブプロンプトテキスト" }, "prompt": { "name": "プロンプト" }, "prompt_adherence": { "name": "プロンプト遵守度", "tooltip": "生成制御のためのガイダンススケール" }, "resolution": { "name": "解像度", "tooltip": "出力動画の解像度" }, "seed": { "name": "シード", "tooltip": "ランダムシード値" }, "steps": { "name": "ステップ数", "tooltip": "推論ステップ数" } }, "outputs": { "0": { "tooltip": null } } };
const MoonvalleyVideo2VideoNode = { "display_name": "Moonvalley Marey 動画から動画", "inputs": { "control_type": { "name": "制御タイプ" }, "motion_intensity": { "name": "モーション強度", "tooltip": "control_typeが「モーション転送」の場合のみ使用" }, "negative_prompt": { "name": "ネガティブプロンプト", "tooltip": "ネガティブプロンプトテキスト" }, "prompt": { "name": "プロンプト", "tooltip": "生成する動画の説明" }, "seed": { "name": "シード", "tooltip": "ランダムシード値" }, "steps": { "name": "ステップ数", "tooltip": "推論ステップ数" }, "video": { "name": "動画", "tooltip": "出力動画の生成に使用する参照動画。最低5秒以上である必要があります。5秒を超える動画は自動的にトリミングされます。MP4形式のみ対応。" } }, "outputs": { "0": { "tooltip": null } } };
const Morphology = { "display_name": "画像形態学", "inputs": { "image": { "name": "画像" }, "kernel_size": { "name": "カーネルサイズ" }, "operation": { "name": "操作" } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIChatConfig = { "description": "OpenAIチャットノードの詳細設定オプションを指定できます。", "display_name": "OpenAI ChatGPT 詳細オプション", "inputs": { "instructions": { "name": "指示", "tooltip": "応答を生成する方法に関するモデルへの指示" }, "max_output_tokens": { "name": "最大出力トークン数", "tooltip": "生成できる応答のトークン数の上限（表示可能な出力トークンを含む）" }, "truncation": { "name": "切り捨て", "tooltip": "モデル応答に使用する切り捨て戦略。auto: この応答と以前の応答のコンテキストがモデルのコンテキストウィンドウサイズを超える場合、モデルは会話の中間の入力項目を削除してコンテキストウィンドウに収まるように応答を切り捨てます。disabled: モデル応答がモデルのコンテキストウィンドウサイズを超える場合、リクエストは400エラーで失敗します" } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIChatNode = { "description": "OpenAIモデルからテキスト応答を生成します。", "display_name": "OpenAI ChatGPT", "inputs": { "advanced_options": { "name": "詳細オプション", "tooltip": "モデルのオプション設定。OpenAIチャット詳細オプションノードからの入力を受け付けます。" }, "files": { "name": "ファイル", "tooltip": "モデルのコンテキストとして使用するオプションのファイル。OpenAIチャット入力ファイルノードからの入力を受け付けます。" }, "images": { "name": "画像", "tooltip": "モデルのコンテキストとして使用するオプションの画像。複数の画像を含めるには、バッチ画像ノードを使用できます。" }, "model": { "name": "モデル", "tooltip": "応答を生成するために使用されるモデル" }, "persist_context": { "name": "コンテキストの永続化", "tooltip": "このパラメータは非推奨であり、効果はありません。" }, "prompt": { "name": "プロンプト", "tooltip": "モデルへのテキスト入力。応答を生成するために使用されます。" } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIDalle2 = { "description": "OpenAIのDALL·E 2エンドポイントを通じて同期的に画像を生成します。", "display_name": "OpenAI DALL·E 2", "inputs": { "control_after_generate": { "name": "生成後のコントロール" }, "image": { "name": "画像", "tooltip": "画像編集用のオプション参照画像。" }, "mask": { "name": "マスク", "tooltip": "インペインティング用のオプションマスク（白い部分が置き換えられます）" }, "n": { "name": "生成数", "tooltip": "生成する画像の枚数" }, "prompt": { "name": "プロンプト", "tooltip": "DALL·E用のテキストプロンプト" }, "seed": { "name": "シード", "tooltip": "バックエンドではまだ未実装" }, "size": { "name": "サイズ", "tooltip": "画像サイズ" } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIDalle3 = { "description": "OpenAIのDALL·E 3エンドポイントを通じて同期的に画像を生成します。", "display_name": "OpenAI DALL·E 3", "inputs": { "control_after_generate": { "name": "生成後のコントロール" }, "prompt": { "name": "プロンプト", "tooltip": "DALL·E用のテキストプロンプト" }, "quality": { "name": "画質", "tooltip": "画像の品質" }, "seed": { "name": "シード", "tooltip": "バックエンドではまだ未実装" }, "size": { "name": "サイズ", "tooltip": "画像サイズ" }, "style": { "name": "スタイル", "tooltip": "「Vivid」はモデルがハイパーリアルでドラマチックな画像を生成する傾向になります。「Natural」はより自然で、ハイパーリアルではない画像を生成します。" } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIGPTImage1 = { "description": "OpenAIのGPT Image 1エンドポイントを通じて同期的に画像を生成します。", "display_name": "OpenAI GPT Image 1", "inputs": { "background": { "name": "背景", "tooltip": "背景あり／なしの画像を返す" }, "control_after_generate": { "name": "生成後のコントロール" }, "image": { "name": "参照画像", "tooltip": "画像編集用のオプション参照画像。" }, "mask": { "name": "マスク", "tooltip": "インペインティング用のオプションマスク（白い部分が置き換えられます）" }, "n": { "name": "生成数", "tooltip": "生成する画像の枚数" }, "prompt": { "name": "プロンプト", "tooltip": "GPT Image 1用のテキストプロンプト" }, "quality": { "name": "品質", "tooltip": "画像の品質。コストと生成時間に影響します。" }, "seed": { "name": "シード", "tooltip": "バックエンドではまだ未実装" }, "size": { "name": "サイズ", "tooltip": "画像サイズ" } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIInputFiles = { "description": "OpenAIチャットノードの入力として含める入力ファイル（テキスト、PDFなど）を読み込み、準備します。ファイルはOpenAIモデルによって応答生成時に読み込まれます。🛈 ヒント: 他のOpenAI入力ファイルノードと連結できます。", "display_name": "OpenAI ChatGPT 入力ファイル", "inputs": { "OPENAI_INPUT_FILES": { "name": "OPENAI_INPUT_FILES", "tooltip": "このノードから読み込まれたファイルと一緒にバッチ処理するオプションの追加ファイル。単一のメッセージに複数の入力ファイルを含められるように、入力ファイルの連結を可能にします。" }, "file": { "name": "ファイル", "tooltip": "モデルのコンテキストとして含める入力ファイル。現在はテキスト（.txt）ファイルとPDF（.pdf）ファイルのみを受け付けます。" } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIVideoSora2 = { "description": "OpenAIのビデオおよびオーディオ生成。", "display_name": "OpenAI Sora - ビデオ", "inputs": { "control_after_generate": { "name": "生成後の制御" }, "duration": { "name": "長さ" }, "image": { "name": "画像" }, "model": { "name": "モデル" }, "prompt": { "name": "プロンプト", "tooltip": "ガイドとなるテキスト。入力画像が存在する場合は空でも可。" }, "seed": { "name": "シード", "tooltip": "ノードを再実行するかどうかを決定するシード。実際の結果はシードに関係なく非決定的です。" }, "size": { "name": "サイズ" } }, "outputs": { "0": { "tooltip": null } } };
const OptimalStepsScheduler = { "display_name": "OptimalStepsScheduler", "inputs": { "denoise": { "name": "ノイズ除去" }, "model_type": { "name": "model_type" }, "steps": { "name": "ステップ数" } }, "outputs": { "0": { "tooltip": null } } };
const PairConditioningCombine = { "display_name": "ペア条件付け組み合わせ", "inputs": { "negative_A": { "name": "ネガティブ_A" }, "negative_B": { "name": "ネガティブ_B" }, "positive_A": { "name": "ポジティブ_A" }, "positive_B": { "name": "ポジティブ_B" } }, "outputs": { "0": { "name": "ポジティブ" }, "1": { "name": "ネガティブ" } } };
const PairConditioningSetDefaultCombine = { "display_name": "ペア条件付けデフォルト組み合わせを設定", "inputs": { "hooks": { "name": "フック" }, "negative": { "name": "ネガティブ" }, "negative_DEFAULT": { "name": "ネガティブ_DEFAULT" }, "positive": { "name": "ポジティブ" }, "positive_DEFAULT": { "name": "ポジティブ_DEFAULT" } }, "outputs": { "0": { "name": "ポジティブ" }, "1": { "name": "ネガティブ" } } };
const PairConditioningSetProperties = { "display_name": "ペア条件付けプロパティ設定", "inputs": { "hooks": { "name": "フック" }, "mask": { "name": "マスク" }, "negative_NEW": { "name": "ネガティブ_NEW" }, "positive_NEW": { "name": "ポジティブ_NEW" }, "set_cond_area": { "name": "set_cond_area" }, "strength": { "name": "強度" }, "timesteps": { "name": "タイムステップ" } }, "outputs": { "0": { "name": "ポジティブ" }, "1": { "name": "ネガティブ" } } };
const PairConditioningSetPropertiesAndCombine = { "display_name": "ペア条件付けプロパティ設定と組み合わせ", "inputs": { "hooks": { "name": "フック" }, "mask": { "name": "マスク" }, "negative": { "name": "ネガティブ" }, "negative_NEW": { "name": "ネガティブ_NEW" }, "positive": { "name": "ポジティブ" }, "positive_NEW": { "name": "ポジティブ_NEW" }, "set_cond_area": { "name": "set_cond_area" }, "strength": { "name": "強度" }, "timesteps": { "name": "タイムステップ" } }, "outputs": { "0": { "name": "ポジティブ" }, "1": { "name": "ネガティブ" } } };
const PatchModelAddDownscale = { "display_name": "パッチモデル追加ダウンスケール（Kohya Deep Shrink）", "inputs": { "block_number": { "name": "ブロック番号" }, "downscale_after_skip": { "name": "スキップ後のダウンスケール" }, "downscale_factor": { "name": "ダウンスケール係数" }, "downscale_method": { "name": "ダウンスケール方法" }, "end_percent": { "name": "終了パーセント" }, "model": { "name": "モデル" }, "start_percent": { "name": "開始パーセント" }, "upscale_method": { "name": "アップスケール方法" } }, "outputs": { "0": { "tooltip": null } } };
const PerpNeg = { "display_name": "Perp-Neg（PerpNegGuiderによって非推奨）", "inputs": { "empty_conditioning": { "name": "空のコンディショニング" }, "model": { "name": "モデル" }, "neg_scale": { "name": "ネガティブスケール" } }, "outputs": { "0": { "tooltip": null } } };
const PerpNegGuider = { "display_name": "PerpNegガイダー", "inputs": { "cfg": { "name": "cfg" }, "empty_conditioning": { "name": "空のコンディショニング" }, "model": { "name": "モデル" }, "neg_scale": { "name": "ネガティブスケール" }, "negative": { "name": "ネガティブ" }, "positive": { "name": "ポジティブ" } }, "outputs": { "0": { "tooltip": null } } };
const PerturbedAttentionGuidance = { "display_name": "摂動注意ガイダンス", "inputs": { "model": { "name": "モデル" }, "scale": { "name": "スケール" } }, "outputs": { "0": { "tooltip": null } } };
const PhotoMakerEncode = { "display_name": "フォトメーカーエンコード", "inputs": { "clip": { "name": "clip" }, "image": { "name": "画像" }, "photomaker": { "name": "photomaker" }, "text": { "name": "テキスト" } }, "outputs": { "0": { "tooltip": null } } };
const PhotoMakerLoader = { "display_name": "フォトメーカーを読み込む", "inputs": { "photomaker_model_name": { "name": "photomakerモデル名" } }, "outputs": { "0": { "tooltip": null } } };
const PixverseImageToVideoNode = { "description": "プロンプトと出力サイズに基づいて同期的に動画を生成します。", "display_name": "PixVerse 画像から動画へ", "inputs": { "control_after_generate": { "name": "生成後のコントロール" }, "duration_seconds": { "name": "継続時間（秒）" }, "image": { "name": "画像" }, "motion_mode": { "name": "モーションモード" }, "negative_prompt": { "name": "ネガティブプロンプト", "tooltip": "画像に含めたくない要素のテキスト説明（任意）。" }, "pixverse_template": { "name": "PixVerseテンプレート", "tooltip": "生成スタイルに影響を与える任意のテンプレート。PixVerse Templateノードで作成。" }, "prompt": { "name": "プロンプト", "tooltip": "動画生成用のプロンプト" }, "quality": { "name": "品質" }, "seed": { "name": "シード", "tooltip": "動画生成用のシード値。" } }, "outputs": { "0": { "tooltip": null } } };
const PixverseTemplateNode = { "display_name": "PixVerseテンプレート", "inputs": { "template": { "name": "テンプレート" } }, "outputs": { "0": { "name": "pixverse_template", "tooltip": null } } };
const PixverseTextToVideoNode = { "description": "プロンプトと出力サイズに基づいて同期的にビデオを生成します。", "display_name": "PixVerse テキストからビデオへ", "inputs": { "aspect_ratio": { "name": "アスペクト比" }, "control_after_generate": { "name": "生成後のコントロール" }, "duration_seconds": { "name": "秒数" }, "motion_mode": { "name": "モーションモード" }, "negative_prompt": { "name": "ネガティブプロンプト", "tooltip": "画像に含めたくない要素のテキスト説明（任意）。" }, "pixverse_template": { "name": "PixVerse テンプレート", "tooltip": "生成スタイルに影響を与える任意のテンプレート。PixVerse Templateノードで作成。" }, "prompt": { "name": "プロンプト", "tooltip": "ビデオ生成のためのプロンプト" }, "quality": { "name": "品質" }, "seed": { "name": "シード", "tooltip": "ビデオ生成のためのシード。" } }, "outputs": { "0": { "tooltip": null } } };
const PixverseTransitionVideoNode = { "description": "プロンプトと出力サイズに基づいて同期的にビデオを生成します。", "display_name": "PixVerse トランジションビデオ", "inputs": { "control_after_generate": { "name": "生成後のコントロール" }, "duration_seconds": { "name": "継続時間（秒）" }, "first_frame": { "name": "first_frame" }, "last_frame": { "name": "last_frame" }, "motion_mode": { "name": "モーションモード" }, "negative_prompt": { "name": "ネガティブプロンプト", "tooltip": "画像に含めたくない要素のテキスト説明（任意）。" }, "prompt": { "name": "プロンプト", "tooltip": "ビデオ生成用のプロンプト" }, "quality": { "name": "品質" }, "seed": { "name": "シード", "tooltip": "ビデオ生成用のシード値。" } }, "outputs": { "0": { "tooltip": null } } };
const PolyexponentialScheduler = { "display_name": "ポリ指数スケジューラー", "inputs": { "rho": { "name": "ロー" }, "sigma_max": { "name": "シグママックス" }, "sigma_min": { "name": "シグマミン" }, "steps": { "name": "ステップ" } } };
const PorterDuffImageComposite = { "display_name": "ポーターダフ画像合成", "inputs": { "destination": { "name": "デスティネーション" }, "destination_alpha": { "name": "デスティネーションアルファ" }, "mode": { "name": "モード" }, "source": { "name": "ソース" }, "source_alpha": { "name": "ソースアルファ" } }, "outputs": { "0": { "tooltip": null }, "1": { "tooltip": null } } };
const Preview3D = { "display_name": "3Dプレビュー", "inputs": { "camera_info": { "name": "カメラ情報" }, "image": { "name": "画像" }, "model_file": { "name": "モデルファイル" } } };
const PreviewAny = { "display_name": "プレビュー任意", "inputs": { "preview": {}, "source": { "name": "ソース" } } };
const PreviewAudio = { "display_name": "オーディオプレビュー", "inputs": { "audio": { "name": "オーディオ" }, "audioUI": { "name": "audioUI" } } };
const PreviewImage = { "description": "入力画像をComfyUI出力ディレクトリに保存します。", "display_name": "画像プレビュー", "inputs": { "images": { "name": "画像" } } };
const PrimitiveBoolean = { "display_name": "ブール値", "inputs": { "value": { "name": "値" } }, "outputs": { "0": { "tooltip": null } } };
const PrimitiveFloat = { "display_name": "浮動小数点数", "inputs": { "value": { "name": "値" } }, "outputs": { "0": { "tooltip": null } } };
const PrimitiveInt = { "display_name": "整数", "inputs": { "control_after_generate": { "name": "生成後に制御" }, "value": { "name": "値" } }, "outputs": { "0": { "tooltip": null } } };
const PrimitiveString = { "display_name": "文字列", "inputs": { "value": { "name": "値" } }, "outputs": { "0": { "tooltip": null } } };
const PrimitiveStringMultiline = { "display_name": "文字列（複数行）", "inputs": { "value": { "name": "値" } }, "outputs": { "0": { "tooltip": null } } };
const QuadrupleCLIPLoader = { "description": "[レシピ]\n\nhidream: long clip-l、long clip-g、t5xxl、llama_8b_3.1_instruct", "display_name": "QuadrupleCLIPLoader", "inputs": { "clip_name1": { "name": "clip_name1" }, "clip_name2": { "name": "clip_name2" }, "clip_name3": { "name": "clip_name3" }, "clip_name4": { "name": "clip_name4" } }, "outputs": { "0": { "tooltip": null } } };
const QwenImageDiffsynthControlnet = { "display_name": "QwenImageDiffsynthControlnet", "inputs": { "image": { "name": "画像" }, "mask": { "name": "マスク" }, "model": { "name": "モデル" }, "model_patch": { "name": "モデルパッチ" }, "strength": { "name": "強度" }, "vae": { "name": "vae" } } };
const RandomNoise = { "display_name": "ランダムノイズ", "inputs": { "control_after_generate": { "name": "生成後の制御" }, "noise_seed": { "name": "ノイズシード" } } };
const RebatchImages = { "display_name": "画像を再バッチ", "inputs": { "batch_size": { "name": "バッチサイズ" }, "images": { "name": "画像" } }, "outputs": { "0": { "tooltip": null } } };
const RebatchLatents = { "display_name": "潜在を再バッチ", "inputs": { "batch_size": { "name": "バッチサイズ" }, "latents": { "name": "潜在変数" } }, "outputs": { "0": { "tooltip": null } } };
const RecordAudio = { "display_name": "録音", "inputs": { "audio": { "name": "オーディオ" } } };
const RecraftColorRGB = { "description": "特定のRGB値を選択してRecraftカラーを作成します。", "display_name": "Recraft カラー RGB", "inputs": { "b": { "name": "b", "tooltip": "色の青の値。" }, "g": { "name": "g", "tooltip": "色の緑の値。" }, "r": { "name": "r", "tooltip": "色の赤の値。" }, "recraft_color": { "name": "recraft_color" } }, "outputs": { "0": { "name": "recraft_color", "tooltip": null } } };
const RecraftControls = { "description": "Recraft生成をカスタマイズするためのRecraftコントロールを作成します。", "display_name": "Recraftコントロール", "inputs": { "background_color": { "name": "background_color" }, "colors": { "name": "colors" } }, "outputs": { "0": { "name": "recraft_controls", "tooltip": null } } };
const RecraftCreativeUpscaleNode = { "description": "画像を同期的にアップスケールします。\n「creative upscale」ツールを使用して指定されたラスタ画像を強化し、解像度を高めながら細部や顔の精細さに重点を置いて向上させます。", "display_name": "Recraft Creative アップスケール画像", "inputs": { "image": { "name": "画像" } }, "outputs": { "0": { "tooltip": null } } };
const RecraftCrispUpscaleNode = { "description": "画像を同期的にアップスケールします。\n「シャープ高解像度アップスケール」ツールを使用して、指定されたラスタ画像の解像度を上げ、より鮮明でクリアな画像にします。", "display_name": "Recraft シャープ高解像度アップスケール画像", "inputs": { "image": { "name": "画像" } }, "outputs": { "0": { "tooltip": null } } };
const RecraftImageInpaintingNode = { "description": "プロンプトとマスクに基づいて画像を修正します。", "display_name": "Recraft画像インペインティング", "inputs": { "control_after_generate": { "name": "生成後のコントロール" }, "image": { "name": "image" }, "mask": { "name": "mask" }, "n": { "name": "生成数", "tooltip": "生成する画像の枚数。" }, "negative_prompt": { "name": "ネガティブプロンプト", "tooltip": "画像に含めたくない要素のテキスト説明（任意）。" }, "prompt": { "name": "プロンプト", "tooltip": "画像生成のためのプロンプト。" }, "recraft_style": { "name": "recraft_style" }, "seed": { "name": "シード値", "tooltip": "ノードを再実行するかどうかを決定するシード値です。実際の結果はシード値に関係なく非決定的です。" } }, "outputs": { "0": { "tooltip": null } } };
const RecraftImageToImageNode = { "description": "プロンプトと強度に基づいて画像を修正します。", "display_name": "Recraft 画像から画像へ", "inputs": { "control_after_generate": { "name": "生成後のコントロール" }, "image": { "name": "画像" }, "n": { "name": "生成数", "tooltip": "生成する画像の枚数。" }, "negative_prompt": { "name": "ネガティブプロンプト", "tooltip": "画像に含めたくない要素のための任意のテキスト説明。" }, "prompt": { "name": "プロンプト", "tooltip": "画像生成のためのプロンプト。" }, "recraft_controls": { "name": "recraft_controls", "tooltip": "Recraft Controlsノードを通じて生成に追加のコントロールを加えるオプション。" }, "recraft_style": { "name": "recraft_style" }, "seed": { "name": "シード", "tooltip": "ノードを再実行するかどうかを決定するシード値。実際の結果はシードに関係なく非決定的です。" }, "strength": { "name": "強度", "tooltip": "元画像との違いを定義します。[0, 1]の範囲で、0はほぼ同一、1は大きく異なります。" } }, "outputs": { "0": { "tooltip": null } } };
const RecraftRemoveBackgroundNode = { "description": "画像の背景を除去し、処理済み画像とmaskを返します。", "display_name": "Recraft 背景除去", "inputs": { "image": { "name": "画像" } }, "outputs": { "0": { "tooltip": null }, "1": { "tooltip": null } } };
const RecraftReplaceBackgroundNode = { "description": "指定されたプロンプトに基づいて画像の背景を置き換えます。", "display_name": "Recraft 背景置換", "inputs": { "control_after_generate": { "name": "生成後のコントロール" }, "image": { "name": "画像" }, "n": { "name": "生成数", "tooltip": "生成する画像の枚数。" }, "negative_prompt": { "name": "ネガティブプロンプト", "tooltip": "画像に含めたくない要素のテキスト説明（任意）。" }, "prompt": { "name": "プロンプト", "tooltip": "画像生成のためのプロンプト。" }, "recraft_style": { "name": "Recraftスタイル" }, "seed": { "name": "シード", "tooltip": "ノードを再実行するかどうかを決定するシード値。実際の結果はシードに関係なく非決定的です。" } }, "outputs": { "0": { "tooltip": null } } };
const RecraftStyleV3DigitalIllustration = { "description": "realistic_imageスタイルとオプションのサブスタイルを選択してください。", "display_name": "Recraftスタイル - デジタルイラストレーション", "inputs": { "substyle": { "name": "サブスタイル" } }, "outputs": { "0": { "name": "recraft_style", "tooltip": null } } };
const RecraftStyleV3InfiniteStyleLibrary = { "description": "Recraftのインフィニットスタイルライブラリから既存のUUIDに基づいてスタイルを選択します。", "display_name": "Recraftスタイル - インフィニットスタイルライブラリ", "inputs": { "style_id": { "name": "style_id", "tooltip": "インフィニットスタイルライブラリのスタイルUUID。" } }, "outputs": { "0": { "name": "recraft_style", "tooltip": null } } };
const RecraftStyleV3LogoRaster = { "description": "realistic_imageスタイルとオプションのサブスタイルを選択します。", "display_name": "Recraft Style - ロゴラスタ", "inputs": { "substyle": { "name": "サブスタイル" } }, "outputs": { "0": { "name": "recraft_style", "tooltip": null } } };
const RecraftStyleV3RealisticImage = { "description": "realistic_imageスタイルとオプションのサブスタイルを選択します。", "display_name": "Recraftスタイル - リアルな画像", "inputs": { "substyle": { "name": "サブスタイル" } }, "outputs": { "0": { "name": "recraft_style", "tooltip": null } } };
const RecraftTextToImageNode = { "description": "プロンプトと解像度に基づいて同期的に画像を生成します。", "display_name": "Recraft テキストから画像へ", "inputs": { "control_after_generate": { "name": "生成後コントロール" }, "n": { "name": "枚数", "tooltip": "生成する画像の枚数。" }, "negative_prompt": { "name": "ネガティブプロンプト", "tooltip": "画像に含めたくない要素のオプションのテキスト説明。" }, "prompt": { "name": "プロンプト", "tooltip": "画像生成のためのプロンプト。" }, "recraft_controls": { "name": "Recraftコントロール", "tooltip": "Recraft Controlsノードを通じて生成に対する追加のコントロール（オプション）。" }, "recraft_style": { "name": "recraft_style" }, "seed": { "name": "シード", "tooltip": "ノードを再実行するかどうかを決定するためのシード。実際の結果はシードに関係なく非決定的です。" }, "size": { "name": "サイズ", "tooltip": "生成される画像のサイズ。" } }, "outputs": { "0": { "tooltip": null } } };
const RecraftTextToVectorNode = { "description": "プロンプトと解像度に基づいてSVGを同期的に生成します。", "display_name": "Recraft テキストからベクターへ", "inputs": { "control_after_generate": { "name": "生成後のコントロール" }, "n": { "name": "生成数", "tooltip": "生成する画像の枚数。" }, "negative_prompt": { "name": "ネガティブプロンプト", "tooltip": "画像に含めたくない要素のテキスト説明（オプション）。" }, "prompt": { "name": "プロンプト", "tooltip": "画像生成のためのプロンプト。" }, "recraft_controls": { "name": "Recraft コントロール", "tooltip": "Recraft Controlsノードを通じて生成に追加のコントロールを加える（オプション）。" }, "seed": { "name": "シード", "tooltip": "ノードを再実行するかどうかを決定するシード；実際の結果はシードに関係なく非決定的です。" }, "size": { "name": "サイズ", "tooltip": "生成される画像のサイズ。" }, "substyle": { "name": "サブスタイル" } }, "outputs": { "0": { "tooltip": null } } };
const RecraftVectorizeImageNode = { "description": "入力画像からSVGを同期的に生成します。", "display_name": "Recraft ベクトル化画像", "inputs": { "image": { "name": "画像" } }, "outputs": { "0": { "tooltip": null } } };
const ReferenceLatent = { "description": "このノードは編集モデルのガイドとなる潜在変数を設定します。モデルが対応している場合、複数をチェーンして複数の参照画像を設定できます。", "display_name": "参照潜在変数", "inputs": { "conditioning": { "name": "条件付け" }, "latent": { "name": "潜在変数" } }, "outputs": { "0": { "tooltip": null } } };
const RegexExtract = { "display_name": "正規表現抽出", "inputs": { "case_insensitive": { "name": "大文字小文字を区別しない" }, "dotall": { "name": "ドット全一致" }, "group_index": { "name": "グループインデックス" }, "mode": { "name": "モード" }, "multiline": { "name": "複数行" }, "regex_pattern": { "name": "正規表現パターン" }, "string": { "name": "文字列" } }, "outputs": { "0": { "tooltip": null } } };
const RegexMatch = { "display_name": "正規表現マッチ", "inputs": { "case_insensitive": { "name": "大文字小文字を区別しない" }, "dotall": { "name": "ドット全一致" }, "multiline": { "name": "複数行" }, "regex_pattern": { "name": "正規表現パターン" }, "string": { "name": "文字列" } }, "outputs": { "0": { "name": "マッチ", "tooltip": null } } };
const RegexReplace = { "description": "正規表現パターンを使用してテキストを検索・置換します。", "display_name": "正規表現置換", "inputs": { "case_insensitive": { "name": "大文字小文字を区別しない" }, "count": { "name": "回数", "tooltip": "置換を行う最大回数。0に設定するとすべての出現を置換します（デフォルト）。1に設定すると最初の一致のみ、2に設定すると最初の2つの一致を置換します。" }, "dotall": { "name": "ドット全一致", "tooltip": "有効にすると、ドット（.）文字が改行文字を含む任意の文字に一致します。無効にすると、ドットは改行に一致しません。" }, "multiline": { "name": "複数行" }, "regex_pattern": { "name": "正規表現パターン" }, "replace": { "name": "置換" }, "string": { "name": "文字列" } }, "outputs": { "0": { "tooltip": null } } };
const RenormCFG = { "display_name": "RenormCFG", "inputs": { "cfg_trunc": { "name": "cfg_trunc" }, "model": { "name": "モデル" }, "renorm_cfg": { "name": "renorm_cfg" } }, "outputs": { "0": { "tooltip": null } } };
const RepeatImageBatch = { "display_name": "画像バッチを繰り返す", "inputs": { "amount": { "name": "量" }, "image": { "name": "画像" } } };
const RepeatLatentBatch = { "display_name": "潜在バッチを繰り返す", "inputs": { "amount": { "name": "量" }, "samples": { "name": "サンプル" } } };
const RescaleCFG = { "display_name": "CFGを再スケール", "inputs": { "model": { "name": "モデル" }, "multiplier": { "name": "乗数" } } };
const ResizeAndPadImage = { "display_name": "画像のリサイズとパディング", "inputs": { "image": { "name": "画像" }, "interpolation": { "name": "補間" }, "padding_color": { "name": "パディング色" }, "target_height": { "name": "ターゲット高さ" }, "target_width": { "name": "ターゲット幅" } } };
const Rodin3D_Detail = { "description": "Rodin APIを使用して3Dアセットを生成", "display_name": "Rodin 3D生成 - 詳細生成", "inputs": { "Images": { "name": "画像" }, "Material_Type": { "name": "マテリアルタイプ" }, "Polygon_count": { "name": "ポリゴン数" }, "Seed": { "name": "シード" } }, "outputs": { "0": { "name": "3Dモデルパス", "tooltip": null } } };
const Rodin3D_Gen2 = { "description": "Rodin APIを使用して3Dアセットを生成", "display_name": "Rodin 3D生成 - Gen-2生成", "inputs": { "Images": { "name": "画像" }, "Material_Type": { "name": "マテリアルタイプ" }, "Polygon_count": { "name": "ポリゴン数" }, "Seed": { "name": "シード" }, "TAPose": { "name": "TAPose" } }, "outputs": { "0": { "name": "3Dモデルパス", "tooltip": null } } };
const Rodin3D_Regular = { "description": "Rodin APIを使用して3Dアセットを生成", "display_name": "Rodin 3D生成 - 通常生成", "inputs": { "Images": { "name": "画像" }, "Material_Type": { "name": "マテリアルタイプ" }, "Polygon_count": { "name": "ポリゴン数" }, "Seed": { "name": "シード" } }, "outputs": { "0": { "name": "3Dモデルパス", "tooltip": null } } };
const Rodin3D_Sketch = { "description": "Rodin APIを使用して3Dアセットを生成", "display_name": "Rodin 3D生成 - スケッチ生成", "inputs": { "Images": { "name": "画像" }, "Seed": { "name": "シード" } }, "outputs": { "0": { "name": "3Dモデルパス", "tooltip": null } } };
const Rodin3D_Smooth = { "description": "Rodin APIを使用して3Dアセットを生成", "display_name": "Rodin 3D生成 - スムーズ生成", "inputs": { "Images": { "name": "画像" }, "Material_Type": { "name": "マテリアルタイプ" }, "Polygon_count": { "name": "ポリゴン数" }, "Seed": { "name": "シード" } }, "outputs": { "0": { "name": "3Dモデルパス", "tooltip": null } } };
const RunwayFirstLastFrameNode = { "description": "最初と最後のキーフレームをアップロードし、プロンプトを作成して動画を生成します。最後のフレームが最初のフレームと完全に異なる場合など、より複雑な遷移では、長い10秒の期間が効果的です。これにより、2つの入力間を滑らかに遷移するための時間がより多く確保されます。始める前に、これらのベストプラクティスを確認して、入力選択が生成を成功に導くようにしてください: https://help.runwayml.com/hc/en-us/articles/34170748696595-Creating-with-Keyframes-on-Gen-3.", "display_name": "Runway 最初-最後フレームから動画生成", "inputs": { "control_after_generate": { "name": "生成後の制御" }, "duration": { "name": "期間" }, "end_frame": { "name": "終了フレーム", "tooltip": "動画に使用する終了フレーム。gen3a_turboのみでサポートされています。" }, "prompt": { "name": "プロンプト", "tooltip": "生成用のテキストプロンプト" }, "ratio": { "name": "比率" }, "seed": { "name": "シード", "tooltip": "生成用のランダムシード" }, "start_frame": { "name": "開始フレーム", "tooltip": "動画に使用する開始フレーム" } }, "outputs": { "0": { "tooltip": null } } };
const RunwayImageToVideoNodeGen3a = { "description": "Gen3a Turboモデルを使用して単一の開始フレームから動画を生成します。始める前に、これらのベストプラクティスを確認して、入力選択が生成を成功に導くようにしてください: https://help.runwayml.com/hc/en-us/articles/33927968552339-Creating-with-Act-One-on-Gen-3-Alpha-and-Turbo.", "display_name": "Runway 画像から動画生成 (Gen3a Turbo)", "inputs": { "control_after_generate": { "name": "生成後の制御" }, "duration": { "name": "期間" }, "prompt": { "name": "プロンプト", "tooltip": "生成用のテキストプロンプト" }, "ratio": { "name": "比率" }, "seed": { "name": "シード", "tooltip": "生成用のランダムシード" }, "start_frame": { "name": "開始フレーム", "tooltip": "動画に使用する開始フレーム" } }, "outputs": { "0": { "tooltip": null } } };
const RunwayImageToVideoNodeGen4 = { "description": "Gen4 Turboモデルを使用して単一の開始フレームから動画を生成します。始める前に、これらのベストプラクティスを確認して、入力選択が生成を成功に導くようにしてください: https://help.runwayml.com/hc/en-us/articles/37327109429011-Creating-with-Gen-4-Video.", "display_name": "Runway 画像から動画生成 (Gen4 Turbo)", "inputs": { "control_after_generate": { "name": "control after generate" }, "duration": { "name": "duration" }, "prompt": { "name": "プロンプト", "tooltip": "生成用のテキストプロンプト" }, "ratio": { "name": "ratio" }, "seed": { "name": "seed", "tooltip": "生成用のランダムシード" }, "start_frame": { "name": "start_frame", "tooltip": "ビデオで使用する開始フレーム" } }, "outputs": { "0": { "tooltip": null } } };
const RunwayTextToImageNode = { "description": "RunwayのGen 4モデルを使用してテキストプロンプトから画像を生成します。生成をガイドするために参照画像を含めることもできます。", "display_name": "Runway Text to Image", "inputs": { "prompt": { "name": "prompt", "tooltip": "生成用のテキストプロンプト" }, "ratio": { "name": "ratio" }, "reference_image": { "name": "reference_image", "tooltip": "生成をガイドするためのオプションの参照画像" } }, "outputs": { "0": { "tooltip": null } } };
const SDTurboScheduler = { "display_name": "SDターボスケジューラー", "inputs": { "denoise": { "name": "ノイズ除去" }, "model": { "name": "モデル" }, "steps": { "name": "ステップ" } } };
const SD_4XUpscale_Conditioning = { "display_name": "SD_4X拡大条件付け", "inputs": { "images": { "name": "画像" }, "negative": { "name": "ネガティブ" }, "noise_augmentation": { "name": "ノイズ増強" }, "positive": { "name": "ポジティブ" }, "scale_ratio": { "name": "スケール比" } }, "outputs": { "0": { "name": "ポジティブ", "tooltip": null }, "1": { "name": "ネガティブ", "tooltip": null }, "2": { "name": "潜在", "tooltip": null } } };
const SV3D_Conditioning = { "display_name": "SV3D条件付け", "inputs": { "clip_vision": { "name": "クリップビジョン" }, "elevation": { "name": "高度" }, "height": { "name": "高さ" }, "init_image": { "name": "初期画像" }, "vae": { "name": "vae" }, "video_frames": { "name": "ビデオフレーム" }, "width": { "name": "幅" } }, "outputs": { "0": { "name": "ポジティブ", "tooltip": null }, "1": { "name": "ネガティブ", "tooltip": null }, "2": { "name": "潜在", "tooltip": null } } };
const SVD_img2vid_Conditioning = { "display_name": "SVD_img2vid条件付け", "inputs": { "augmentation_level": { "name": "増強レベル" }, "clip_vision": { "name": "clip_vision" }, "fps": { "name": "fps" }, "height": { "name": "高さ" }, "init_image": { "name": "初期画像" }, "motion_bucket_id": { "name": "モーションバケットID" }, "vae": { "name": "vae" }, "video_frames": { "name": "ビデオフレーム" }, "width": { "name": "幅" } }, "outputs": { "0": { "name": "ポジティブ" }, "1": { "name": "ネガティブ" }, "2": { "name": "潜在" } } };
const SamplerCustom = { "display_name": "カスタムサンプラー", "inputs": { "add_noise": { "name": "ノイズを追加" }, "cfg": { "name": "cfg" }, "control_after_generate": { "name": "生成後の制御" }, "latent_image": { "name": "潜在画像" }, "model": { "name": "モデル" }, "negative": { "name": "ネガティブ" }, "noise_seed": { "name": "ノイズシード" }, "positive": { "name": "ポジティブ" }, "sampler": { "name": "サンプラー" }, "sigmas": { "name": "シグマ" } }, "outputs": { "0": { "name": "出力" }, "1": { "name": "デノイズ出力" } } };
const SamplerCustomAdvanced = { "display_name": "カスタムサンプラー（高度）", "inputs": { "guider": { "name": "ガイダー" }, "latent_image": { "name": "潜在イメージ" }, "noise": { "name": "ノイズ" }, "sampler": { "name": "サンプラー" }, "sigmas": { "name": "シグマ" } }, "outputs": { "0": { "name": "出力" }, "1": { "name": "デノイズ出力" } } };
const SamplerDPMAdaptative = { "display_name": "サンプラーDPM適応", "inputs": { "accept_safety": { "name": "accept_safety" }, "atol": { "name": "atol" }, "dcoeff": { "name": "dcoeff" }, "eta": { "name": "eta" }, "h_init": { "name": "h_init" }, "icoeff": { "name": "icoeff" }, "order": { "name": "順序" }, "pcoeff": { "name": "pcoeff" }, "rtol": { "name": "rtol" }, "s_noise": { "name": "s_noise" } } };
const SamplerDPMPP_2M_SDE = { "display_name": "サンプラーDPMPP_2M_SDE", "inputs": { "eta": { "name": "eta" }, "noise_device": { "name": "ノイズデバイス" }, "s_noise": { "name": "s_noise" }, "solver_type": { "name": "ソルバータイプ" } } };
const SamplerDPMPP_2S_Ancestral = { "display_name": "サンプラーDPMPP_2S_祖先", "inputs": { "eta": { "name": "eta" }, "s_noise": { "name": "s_noise" } } };
const SamplerDPMPP_3M_SDE = { "display_name": "サンプラーDPMPP_3M_SDE", "inputs": { "eta": { "name": "eta" }, "noise_device": { "name": "ノイズデバイス" }, "s_noise": { "name": "s_noise" } } };
const SamplerDPMPP_SDE = { "display_name": "サンプラーDPMPP_SDE", "inputs": { "eta": { "name": "eta" }, "noise_device": { "name": "ノイズデバイス" }, "r": { "name": "r" }, "s_noise": { "name": "s_noise" } } };
const SamplerER_SDE = { "display_name": "SamplerER_SDE", "inputs": { "eta": { "name": "eta", "tooltip": "逆時間SDEの確率的強度。\neta=0の場合、決定論的ODEに縮退します。この設定はER-SDEソルバータイプには適用されません。" }, "max_stage": { "name": "max_stage" }, "s_noise": { "name": "s_noise" }, "solver_type": { "name": "solver_type" } } };
const SamplerEulerAncestral = { "display_name": "サンプラーオイラー祖先", "inputs": { "eta": { "name": "eta" }, "s_noise": { "name": "s_noise" } } };
const SamplerEulerAncestralCFGPP = { "display_name": "サンプラーオイラー祖先CFG++", "inputs": { "eta": { "name": "eta" }, "s_noise": { "name": "s_noise" } } };
const SamplerEulerCFGpp = { "display_name": "サンプラーオイラーCFG++", "inputs": { "version": { "name": "バージョン" } }, "outputs": { "0": { "tooltip": null } } };
const SamplerLCMUpscale = { "display_name": "サンプラーLCM拡大", "inputs": { "scale_ratio": { "name": "スケール比" }, "scale_steps": { "name": "スケールステップ" }, "upscale_method": { "name": "アップスケール方法" } }, "outputs": { "0": { "tooltip": null } } };
const SamplerLMS = { "display_name": "サンプラーLMS", "inputs": { "order": { "name": "順序" } } };
const SamplerSASolver = { "display_name": "SamplerSASolver", "inputs": { "corrector_order": { "name": "corrector_order" }, "eta": { "name": "eta" }, "model": { "name": "model" }, "predictor_order": { "name": "predictor_order" }, "s_noise": { "name": "s_noise" }, "sde_end_percent": { "name": "sde_end_percent" }, "sde_start_percent": { "name": "sde_start_percent" }, "simple_order_2": { "name": "simple_order_2" }, "use_pece": { "name": "use_pece" } } };
const SamplingPercentToSigma = { "display_name": "SamplingPercentToSigma", "inputs": { "model": { "name": "model" }, "return_actual_sigma": { "name": "return_actual_sigma", "tooltip": "間隔チェックに使用された値の代わりに実際のシグマ値を返します。\nこれは0.0と1.0での結果にのみ影響します。" }, "sampling_percent": { "name": "sampling_percent" } }, "outputs": { "0": { "name": "sigma_value" } } };
const SaveAnimatedPNG = { "display_name": "アニメーションPNGを保存", "inputs": { "compress_level": { "name": "圧縮レベル" }, "filename_prefix": { "name": "ファイル名プレフィックス" }, "fps": { "name": "fps" }, "images": { "name": "画像" } } };
const SaveAnimatedWEBP = { "display_name": "アニメーションWEBPを保存", "inputs": { "filename_prefix": { "name": "ファイル名プレフィックス" }, "fps": { "name": "fps" }, "images": { "name": "画像" }, "lossless": { "name": "ロスレス" }, "method": { "name": "方法" }, "quality": { "name": "品質" } } };
const SaveAudio = { "display_name": "オーディオを保存", "inputs": { "audio": { "name": "オーディオ" }, "audioUI": { "name": "audioUI" }, "filename_prefix": { "name": "ファイル名_プレフィックス" } } };
const SaveAudioMP3 = { "display_name": "オーディオ保存 (MP3)", "inputs": { "audio": { "name": "audio" }, "audioUI": { "name": "audioUI" }, "filename_prefix": { "name": "filename_prefix" }, "quality": { "name": "quality" } } };
const SaveAudioOpus = { "display_name": "オーディオ保存 (Opus)", "inputs": { "audio": { "name": "audio" }, "audioUI": { "name": "audioUI" }, "filename_prefix": { "name": "filename_prefix" }, "quality": { "name": "quality" } } };
const SaveGLB = { "display_name": "SaveGLB", "inputs": { "filename_prefix": { "name": "ファイル名のプレフィックス" }, "image": { "name": "画像" }, "mesh": { "name": "メッシュ" } } };
const SaveImage = { "description": "入力画像をComfyUI出力ディレクトリに保存します。", "display_name": "画像を保存", "inputs": { "filename_prefix": { "name": "ファイル名_プレフィックス", "tooltip": "保存するファイルのプレフィックス。この中には、ノードからの値を含めるために、%date:yyyy-MM-dd%や%Empty Latent Image.width%などのフォーマット情報が含まれる場合があります。" }, "images": { "name": "画像", "tooltip": "保存する画像。" } } };
const SaveImageWebsocket = { "display_name": "画像を保存するWebSocket", "inputs": { "images": { "name": "画像" } } };
const SaveLatent = { "display_name": "潜在を保存", "inputs": { "filename_prefix": { "name": "ファイル名_プレフィックス" }, "samples": { "name": "サンプル" } } };
const SaveSVGNode = { "description": "SVGファイルをディスクに保存します。", "display_name": "SVG保存ノード", "inputs": { "filename_prefix": { "name": "ファイル名プレフィックス", "tooltip": "保存するファイルのプレフィックス。%date:yyyy-MM-dd%や%Empty Latent Image.width%などのノードからの値を含むフォーマット情報を含めることができます。" }, "svg": { "name": "svg" } } };
const SaveVideo = { "description": "入力画像をComfyUIの出力ディレクトリに保存します。", "display_name": "ビデオを保存", "inputs": { "codec": { "name": "コーデック", "tooltip": "ビデオに使用するコーデック。" }, "filename_prefix": { "name": "ファイル名プレフィックス", "tooltip": "保存するファイルのプレフィックス。%date:yyyy-MM-dd% や %Empty Latent Image.width% など、ノードからの値を含める書式情報を含めることができます。" }, "format": { "name": "フォーマット", "tooltip": "ビデオを保存するフォーマット。" }, "video": { "name": "ビデオ", "tooltip": "保存するビデオ。" } } };
const SaveWEBM = { "display_name": "SaveWEBM", "inputs": { "codec": { "name": "コーデック" }, "crf": { "name": "crf", "tooltip": "crfが高いほどファイルサイズは小さくなりますが、品質は低下します。逆に、crfが低いほど品質は高くなりますが、ファイルサイズは大きくなります。" }, "filename_prefix": { "name": "ファイル名の接頭辞" }, "fps": { "name": "fps" }, "images": { "name": "画像" } } };
const ScaleROPE = { "description": "モデルのROPEをスケーリングおよびシフトします。", "display_name": "ROPEスケーリング", "inputs": { "model": { "name": "モデル" }, "scale_t": { "name": "時間軸スケール" }, "scale_x": { "name": "X軸スケール" }, "scale_y": { "name": "Y軸スケール" }, "shift_t": { "name": "時間軸シフト" }, "shift_x": { "name": "X軸シフト" }, "shift_y": { "name": "Y軸シフト" } }, "outputs": { "0": { "tooltip": null } } };
const SelfAttentionGuidance = { "display_name": "自己注意ガイダンス", "inputs": { "blur_sigma": { "name": "ブラーシグマ" }, "model": { "name": "モデル" }, "scale": { "name": "スケール" } }, "outputs": { "0": { "tooltip": null } } };
const SetClipHooks = { "display_name": "CLIPフックを設定", "inputs": { "apply_to_conds": { "name": "apply_to_conds" }, "clip": { "name": "クリップ" }, "hooks": { "name": "フック" }, "schedule_clip": { "name": "schedule_clip" } } };
const SetFirstSigma = { "display_name": "SetFirstSigma", "inputs": { "sigma": { "name": "シグマ" }, "sigmas": { "name": "シグマ" } } };
const SetHookKeyframes = { "display_name": "フックキーフレームを設定", "inputs": { "hook_kf": { "name": "フック_kf" }, "hooks": { "name": "フック" } } };
const SetLatentNoiseMask = { "display_name": "潜在ノイズマスクを設定", "inputs": { "mask": { "name": "マスク" }, "samples": { "name": "サンプル" } } };
const SetUnionControlNetType = { "display_name": "Union ControlNetタイプを設定", "inputs": { "control_net": { "name": "control_net" }, "type": { "name": "タイプ" } }, "outputs": { "0": { "tooltip": null } } };
const SkipLayerGuidanceDiT = { "description": "すべてのDiTモデルで使用できるSkipLayerGuidanceノードの一般的なバージョン。", "display_name": "SkipLayerGuidanceDiT", "inputs": { "double_layers": { "name": "ダブルレイヤー" }, "end_percent": { "name": "終了パーセント" }, "model": { "name": "モデル" }, "rescaling_scale": { "name": "リスケーリングスケール" }, "scale": { "name": "スケール" }, "single_layers": { "name": "シングルレイヤー" }, "start_percent": { "name": "開始パーセント" } }, "outputs": { "0": { "tooltip": null } } };
const SkipLayerGuidanceDiTSimple = { "description": "非条件付きパスのみを変更するSkipLayerGuidanceDiTノードの簡易版。", "display_name": "スキップレイヤーガイダンスDiT簡易版", "inputs": { "double_layers": { "name": "二重レイヤー" }, "end_percent": { "name": "終了パーセンテージ" }, "model": { "name": "モデル" }, "single_layers": { "name": "単一レイヤー" }, "start_percent": { "name": "開始パーセンテージ" } }, "outputs": { "0": { "tooltip": null } } };
const SkipLayerGuidanceSD3 = { "description": "すべてのDiTモデルで使用できるSkipLayerGuidanceノードの一般的なバージョン。", "display_name": "SkipLayerGuidanceSD3", "inputs": { "end_percent": { "name": "終了パーセント" }, "layers": { "name": "レイヤー" }, "model": { "name": "モデル" }, "scale": { "name": "スケール" }, "start_percent": { "name": "開始パーセント" } }, "outputs": { "0": { "tooltip": null } } };
const SolidMask = { "display_name": "ソリッドマスク", "inputs": { "height": { "name": "高さ" }, "value": { "name": "値" }, "width": { "name": "幅" } } };
const SplitAudioChannels = { "description": "オーディオを左右のチャンネルに分離します。", "display_name": "オーディオチャンネル分割", "inputs": { "audio": { "name": "オーディオ" } }, "outputs": { "0": { "name": "左チャンネル" }, "1": { "name": "右チャンネル" } } };
const SplitImageWithAlpha = { "display_name": "アルファで画像を分割", "inputs": { "image": { "name": "画像" } }, "outputs": { "0": { "tooltip": null }, "1": { "tooltip": null } } };
const SplitSigmas = { "display_name": "シグマを分割", "inputs": { "sigmas": { "name": "シグマ" }, "step": { "name": "ステップ" } }, "outputs": { "0": { "name": "高シグマ" }, "1": { "name": "低シグマ" } } };
const SplitSigmasDenoise = { "display_name": "シグマを分割してノイズ除去", "inputs": { "denoise": { "name": "ノイズ除去" }, "sigmas": { "name": "シグマ" } }, "outputs": { "0": { "name": "高シグマ" }, "1": { "name": "低シグマ" } } };
const StabilityAudioInpaint = { "description": "テキスト指示を使用して既存のオーディオサンプルの一部を変換します。", "display_name": "Stability AI オーディオインペイント", "inputs": { "audio": { "name": "オーディオ", "tooltip": "オーディオは6秒から190秒の間でなければなりません。" }, "control_after_generate": { "name": "生成後の制御" }, "duration": { "name": "再生時間", "tooltip": "生成されるオーディオの再生時間（秒）を制御します。" }, "mask_end": { "name": "マスク終了位置" }, "mask_start": { "name": "マスク開始位置" }, "model": { "name": "モデル" }, "prompt": { "name": "プロンプト" }, "seed": { "name": "シード", "tooltip": "生成に使用されるランダムシード。" }, "steps": { "name": "ステップ数", "tooltip": "サンプリングステップ数を制御します。" } }, "outputs": { "0": { "tooltip": null } } };
const StabilityAudioToAudio = { "description": "テキスト指示を使用して既存のオーディオサンプルを新しい高品質な構成に変換します。", "display_name": "Stability AI オーディオ変換", "inputs": { "audio": { "name": "オーディオ", "tooltip": "オーディオは6秒から190秒の間でなければなりません。" }, "control_after_generate": { "name": "control after generate" }, "duration": { "name": "duration", "tooltip": "生成されるオーディオの長さを秒単位で制御します。" }, "model": { "name": "モデル" }, "prompt": { "name": "プロンプト" }, "seed": { "name": "seed", "tooltip": "生成に使用されるランダムシード。" }, "steps": { "name": "steps", "tooltip": "サンプリングステップ数を制御します。" }, "strength": { "name": "strength", "tooltip": "オーディオパラメータが生成されるオーディオに与える影響の強さを制御するパラメータ。" } }, "outputs": { "0": { "tooltip": null } } };
const StabilityStableImageSD_3_5Node = { "description": "プロンプトと解像度に基づいて同期的に画像を生成します。", "display_name": "Stability AI Stable Diffusion 3.5 Image", "inputs": { "aspect_ratio": { "name": "アスペクト比", "tooltip": "生成される画像のアスペクト比。" }, "cfg_scale": { "name": "cfgスケール", "tooltip": "拡散プロセスがプロンプトテキストにどれだけ厳密に従うか（値が高いほどプロンプトに近い画像になります）" }, "control_after_generate": { "name": "生成後コントロール" }, "image": { "name": "画像" }, "image_denoise": { "name": "画像ノイズ除去", "tooltip": "入力画像のノイズ除去度合い。0.0は入力画像と同一、1.0は画像が全く提供されていない状態と同じです。" }, "model": { "name": "モデル" }, "negative_prompt": { "name": "ネガティブプロンプト", "tooltip": "出力画像に表示したくないキーワード。上級者向けの機能です。" }, "prompt": { "name": "プロンプト", "tooltip": "出力画像に表示したい内容を入力してください。要素、色、被写体を明確に定義した強く詳細なプロンプトは、より良い結果につながります。" }, "seed": { "name": "シード", "tooltip": "ノイズ生成に使用されるランダムシード。" }, "style_preset": { "name": "スタイルプリセット", "tooltip": "生成画像に希望するスタイル（任意）。" } }, "outputs": { "0": { "tooltip": null } } };
const StabilityStableImageUltraNode = { "description": "プロンプトと解像度に基づいて同期的に画像を生成します。", "display_name": "Stability AI Stable Image Ultra", "inputs": { "aspect_ratio": { "name": "aspect_ratio", "tooltip": "生成される画像のアスペクト比。" }, "control_after_generate": { "name": "control after generate" }, "image": { "name": "image" }, "image_denoise": { "name": "image_denoise", "tooltip": "入力画像のノイズ除去度合い。0.0は入力画像と同一、1.0は画像が全く提供されていない状態と同じです。" }, "negative_prompt": { "name": "negative_prompt", "tooltip": "出力画像に表示したくない内容を記述します。これは上級者向けの機能です。" }, "prompt": { "name": "prompt", "tooltip": "出力画像に見たいものを入力します。要素、色、被写体を明確に定義した強く詳細なプロンプトがより良い結果につながります。特定の単語の重みを調整したい場合は、`(word:weight)`の形式を使用します。ここで`word`は重みを調整したい単語、`weight`は0から1の値です。例: `The sky was a crisp (blue:0.3) and (green:0.8)`は、空が青と緑で、青よりも緑が強いことを表します。" }, "seed": { "name": "seed", "tooltip": "ノイズ生成に使用されるランダムシード。" }, "style_preset": { "name": "style_preset", "tooltip": "生成画像の任意のスタイル。" } }, "outputs": { "0": { "tooltip": null } } };
const StabilityTextToAudio = { "description": "テキストの説明から高品質な音楽とサウンドエフェクトを生成します。", "display_name": "Stability AI テキストからオーディオへ", "inputs": { "control_after_generate": { "name": "control after generate" }, "duration": { "name": "duration", "tooltip": "生成されるオーディオの長さを秒単位で制御します。" }, "model": { "name": "model" }, "prompt": { "name": "prompt" }, "seed": { "name": "seed", "tooltip": "生成に使用されるランダムシード。" }, "steps": { "name": "steps", "tooltip": "サンプリングステップ数を制御します。" } }, "outputs": { "0": { "tooltip": null } } };
const StabilityUpscaleConservativeNode = { "description": "画像を最小限の変更で4K解像度にアップスケールします。", "display_name": "Stability AI アップスケール（コンサバティブ）", "inputs": { "control_after_generate": { "name": "生成後のコントロール" }, "creativity": { "name": "クリエイティビティ", "tooltip": "初期画像に強く依存しない追加のディテールを生成する可能性を制御します。" }, "image": { "name": "image" }, "negative_prompt": { "name": "ネガティブプロンプト", "tooltip": "出力画像に表示したくないキーワード。上級者向けの機能です。" }, "prompt": { "name": "プロンプト", "tooltip": "出力画像に何を表示したいか。要素、色、被写体を明確に定義した強く詳細なプロンプトが、より良い結果につながります。" }, "seed": { "name": "シード", "tooltip": "ノイズ生成に使用されるランダムシードです。" } }, "outputs": { "0": { "tooltip": null } } };
const StabilityUpscaleCreativeNode = { "description": "画像を最小限の変更で4K解像度にアップスケールします。", "display_name": "Stability AI アップスケール クリエイティブ", "inputs": { "control_after_generate": { "name": "生成後のコントロール" }, "creativity": { "name": "クリエイティビティ", "tooltip": "初期画像に強く依存しない追加のディテールを生成する可能性を制御します。" }, "image": { "name": "画像" }, "negative_prompt": { "name": "ネガティブプロンプト", "tooltip": "出力画像に表示したくないキーワード。上級者向けの機能です。" }, "prompt": { "name": "プロンプト", "tooltip": "出力画像に何を表示したいか。要素、色、被写体を明確に定義した強く詳細なプロンプトが、より良い結果につながります。" }, "seed": { "name": "シード", "tooltip": "ノイズ生成に使用されるランダムシード。" }, "style_preset": { "name": "スタイルプリセット", "tooltip": "生成画像の希望するスタイル（任意）。" } }, "outputs": { "0": { "tooltip": null } } };
const StabilityUpscaleFastNode = { "description": "Stability API を使用して画像を元の4倍のサイズに素早くアップスケールします。低品質や圧縮された画像のアップスケールを目的としています。", "display_name": "Stability AI 高速アップスケール", "inputs": { "image": { "name": "画像" } }, "outputs": { "0": { "tooltip": null } } };
const StableCascade_EmptyLatentImage = { "display_name": "安定カスケード_空の潜在画像", "inputs": { "batch_size": { "name": "バッチサイズ" }, "compression": { "name": "圧縮" }, "height": { "name": "高さ" }, "width": { "name": "幅" } }, "outputs": { "0": { "name": "ステージC", "tooltip": null }, "1": { "name": "ステージB", "tooltip": null } } };
const StableCascade_StageB_Conditioning = { "display_name": "安定カスケード_ステージB条件付け", "inputs": { "conditioning": { "name": "コンディショニング" }, "stage_c": { "name": "ステージc" } }, "outputs": { "0": { "tooltip": null } } };
const StableCascade_StageC_VAEEncode = { "display_name": "安定カスケード_ステージC_VAEエンコード", "inputs": { "compression": { "name": "圧縮" }, "image": { "name": "画像" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "ステージC", "tooltip": null }, "1": { "name": "ステージB", "tooltip": null } } };
const StableCascade_SuperResolutionControlnet = { "display_name": "安定カスケード_超解像Controlnet", "inputs": { "image": { "name": "画像" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "コントロールネット入力", "tooltip": null }, "1": { "name": "ステージC", "tooltip": null }, "2": { "name": "ステージB", "tooltip": null } } };
const StableZero123_Conditioning = { "display_name": "安定ゼロ123条件付け", "inputs": { "azimuth": { "name": "方位角" }, "batch_size": { "name": "バッチサイズ" }, "clip_vision": { "name": "クリップビジョン" }, "elevation": { "name": "高度" }, "height": { "name": "高さ" }, "init_image": { "name": "初期画像" }, "vae": { "name": "vae" }, "width": { "name": "幅" } }, "outputs": { "0": { "name": "ポジティブ", "tooltip": null }, "1": { "name": "ネガティブ", "tooltip": null }, "2": { "name": "潜在", "tooltip": null } } };
const StableZero123_Conditioning_Batched = { "display_name": "安定ゼロ123条件付け（バッチ）", "inputs": { "azimuth": { "name": "方位角" }, "azimuth_batch_increment": { "name": "方位角バッチ増分" }, "batch_size": { "name": "バッチサイズ" }, "clip_vision": { "name": "クリップビジョン" }, "elevation": { "name": "高度" }, "elevation_batch_increment": { "name": "高度バッチ増分" }, "height": { "name": "高さ" }, "init_image": { "name": "初期画像" }, "vae": { "name": "vae" }, "width": { "name": "幅" } }, "outputs": { "0": { "name": "ポジティブ", "tooltip": null }, "1": { "name": "ネガティブ", "tooltip": null }, "2": { "name": "潜在", "tooltip": null } } };
const StringCompare = { "display_name": "比較", "inputs": { "case_sensitive": { "name": "case_sensitive" }, "mode": { "name": "mode" }, "string_a": { "name": "string_a" }, "string_b": { "name": "string_b" } }, "outputs": { "0": { "tooltip": null } } };
const StringConcatenate = { "display_name": "連結", "inputs": { "delimiter": { "name": "delimiter" }, "string_a": { "name": "string_a" }, "string_b": { "name": "string_b" } }, "outputs": { "0": { "tooltip": null } } };
const StringContains = { "display_name": "含む", "inputs": { "case_sensitive": { "name": "case_sensitive" }, "string": { "name": "string" }, "substring": { "name": "substring" } }, "outputs": { "0": { "name": "contains", "tooltip": null } } };
const StringLength = { "display_name": "長さ", "inputs": { "string": { "name": "string" } }, "outputs": { "0": { "name": "length", "tooltip": null } } };
const StringReplace = { "display_name": "置換", "inputs": { "find": { "name": "find" }, "replace": { "name": "replace" }, "string": { "name": "string" } }, "outputs": { "0": { "tooltip": null } } };
const StringSubstring = { "display_name": "部分文字列", "inputs": { "end": { "name": "end" }, "start": { "name": "start" }, "string": { "name": "string" } }, "outputs": { "0": { "tooltip": null } } };
const StringTrim = { "display_name": "トリム", "inputs": { "mode": { "name": "mode" }, "string": { "name": "string" } }, "outputs": { "0": { "tooltip": null } } };
const StyleModelApply = { "display_name": "スタイルモデルを適用", "inputs": { "clip_vision_output": { "name": "クリップビジョン出力" }, "conditioning": { "name": "コンディショニング" }, "strength": { "name": "強度" }, "strength_type": { "name": "強度タイプ" }, "style_model": { "name": "スタイルモデル" } } };
const StyleModelLoader = { "display_name": "スタイルモデルを読み込む", "inputs": { "style_model_name": { "name": "スタイルモデル名" } } };
const T5TokenizerOptions = { "display_name": "T5TokenizerOptions", "inputs": { "clip": { "name": "clip" }, "min_length": { "name": "最小長" }, "min_padding": { "name": "最小パディング" } }, "outputs": { "0": { "tooltip": null } } };
const TCFG = { "description": "TCFG – 接線減衰 CFG (2503.18137)\n\n品質向上のために、uncond（ネガティブ）をcond（ポジティブ）に合わせて調整します。", "display_name": "接線減衰 CFG", "inputs": { "model": { "name": "モデル" } }, "outputs": { "0": { "name": "パッチ適用済みモデル", "tooltip": null } } };
const TemporalScoreRescaling = { "description": "[Post-CFG関数]\nTSR - 時間的スコアリスケーリング (2510.01184)\n\nモデルのスコアまたはノイズをリスケーリングして、サンプリングの多様性を制御します。", "display_name": "TSR - 時間的スコアリスケーリング", "inputs": { "model": { "name": "モデル" }, "tsr_k": { "name": "tsr_k", "tooltip": "リスケーリングの強度を制御します。\n低いk値はより詳細な結果を生成し、高いk値は画像生成でより滑らかな結果を生成します。k=1に設定するとリスケーリングが無効になります。" }, "tsr_sigma": { "name": "tsr_sigma", "tooltip": "リスケーリングがいつ効果を発揮するかを制御します。\n大きい値ほど早く効果が現れます。" } }, "outputs": { "0": { "name": "パッチ適用済みモデル", "tooltip": null } } };
const TextEncodeAceStepAudio = { "display_name": "TextEncodeAceStepAudio", "inputs": { "clip": { "name": "clip" }, "lyrics": { "name": "歌詞" }, "lyrics_strength": { "name": "歌詞強度" }, "tags": { "name": "タグ" } }, "outputs": { "0": { "tooltip": null } } };
const TextEncodeHunyuanVideo_ImageToVideo = { "display_name": "TextEncodeHunyuanVideo_ImageToVideo", "inputs": { "clip": { "name": "clip" }, "clip_vision_output": { "name": "clip_vision_output" }, "image_interleave": { "name": "画像インターリーブ", "tooltip": "画像がテキストプロンプトと比べてどれだけ影響を与えるか。数値が大きいほどテキストプロンプトからの影響が大きくなります。" }, "prompt": { "name": "プロンプト" } }, "outputs": { "0": { "tooltip": null } } };
const TextEncodeQwenImageEdit = { "display_name": "TextEncodeQwenImageEdit", "inputs": { "clip": { "name": "clip" }, "image": { "name": "画像" }, "prompt": { "name": "プロンプト" }, "vae": { "name": "vae" } }, "outputs": { "0": { "tooltip": null } } };
const TextEncodeQwenImageEditPlus = { "display_name": "TextEncodeQwenImageEditPlus", "inputs": { "clip": { "name": "clip" }, "image1": { "name": "画像1" }, "image2": { "name": "画像2" }, "image3": { "name": "画像3" }, "prompt": { "name": "プロンプト" }, "vae": { "name": "vae" } }, "outputs": { "0": { "tooltip": null } } };
const ThresholdMask = { "display_name": "しきい値マスク", "inputs": { "mask": { "name": "マスク" }, "value": { "name": "値" } } };
const TomePatchModel = { "display_name": "トメパッチモデル", "inputs": { "model": { "name": "モデル" }, "ratio": { "name": "比率" } }, "outputs": { "0": { "tooltip": null } } };
const TorchCompileModel = { "display_name": "Torchコンパイルモデル", "inputs": { "backend": { "name": "バックエンド" }, "model": { "name": "モデル" } }, "outputs": { "0": { "tooltip": null } } };
const TrainLoraNode = { "display_name": "LoRA学習", "inputs": { "algorithm": { "name": "algorithm", "tooltip": "トレーニングに使用するアルゴリズム。" }, "batch_size": { "name": "バッチサイズ", "tooltip": "学習に使用するバッチサイズ。" }, "control_after_generate": { "name": "control after generate" }, "existing_lora": { "name": "existing_lora", "tooltip": "追加する既存のLoRA。新規LoRAの場合はNoneに設定。" }, "grad_accumulation_steps": { "name": "勾配蓄積ステップ数", "tooltip": "学習に使用する勾配蓄積ステップの数。" }, "gradient_checkpointing": { "name": "gradient_checkpointing", "tooltip": "トレーニングに勾配チェックポイントを使用する。" }, "latents": { "name": "潜在変数", "tooltip": "学習に使用する潜在変数。モデルのデータセット/入力として機能します。" }, "learning_rate": { "name": "学習率", "tooltip": "学習に使用する学習率。" }, "lora_dtype": { "name": "lora_dtype", "tooltip": "LoRAに使用するデータ型。" }, "loss_function": { "name": "損失関数", "tooltip": "学習に使用する損失関数。" }, "model": { "name": "モデル", "tooltip": "LoRAを学習させる対象のモデル。" }, "optimizer": { "name": "オプティマイザ", "tooltip": "学習に使用するオプティマイザ。" }, "positive": { "name": "ポジティブ条件付け", "tooltip": "学習に使用するポジティブな条件付け。" }, "rank": { "name": "ランク", "tooltip": "LoRAレイヤーのランク。" }, "seed": { "name": "シード", "tooltip": "学習に使用するシード（LoRA重み初期化とノイズサンプリング用のジェネレーターで使用）" }, "steps": { "name": "ステップ数", "tooltip": "LoRAを学習させるステップ数。" }, "training_dtype": { "name": "training_dtype", "tooltip": "トレーニングに使用するデータ型。" } }, "outputs": { "0": { "name": "model_with_lora" }, "1": { "name": "lora" }, "2": { "name": "loss" }, "3": { "name": "steps" } } };
const TrimAudioDuration = { "description": "オーディオテンソルを選択した時間範囲でトリミングします。", "display_name": "オーディオの長さをトリミング", "inputs": { "audio": { "name": "audio" }, "duration": { "name": "duration", "tooltip": "継続時間（秒）" }, "start_index": { "name": "start_index", "tooltip": "開始時間（秒）。負の値を指定すると末尾からカウント（小数点以下対応）。" } } };
const TrimVideoLatent = { "display_name": "TrimVideoLatent", "inputs": { "samples": { "name": "サンプル" }, "trim_amount": { "name": "トリム量" } }, "outputs": { "0": { "tooltip": null } } };
const TripleCLIPLoader = { "description": "[レシピ]\n\nsd3: clip-l, clip-g, t5", "display_name": "トリプルCLIPを読み込む", "inputs": { "clip_name1": { "name": "clip_name1" }, "clip_name2": { "name": "clip_name2" }, "clip_name3": { "name": "clip_name3" } }, "outputs": { "0": { "tooltip": null } } };
const TripoConversionNode = { "display_name": "Tripo: モデル変換", "inputs": { "face_limit": { "name": "face_limit" }, "format": { "name": "format" }, "original_model_task_id": { "name": "original_model_task_id" }, "quad": { "name": "quad" }, "texture_format": { "name": "texture_format" }, "texture_size": { "name": "texture_size" } } };
const TripoImageToModelNode = { "display_name": "Tripo: 画像からモデル", "inputs": { "face_limit": { "name": "face_limit" }, "image": { "name": "image" }, "model_seed": { "name": "model_seed" }, "model_version": { "name": "model_version", "tooltip": "生成に使用するモデルバージョン" }, "orientation": { "name": "orientation" }, "pbr": { "name": "pbr" }, "quad": { "name": "quad" }, "style": { "name": "style" }, "texture": { "name": "texture" }, "texture_alignment": { "name": "texture_alignment" }, "texture_quality": { "name": "texture_quality" }, "texture_seed": { "name": "texture_seed" } }, "outputs": { "0": { "name": "model_file", "tooltip": null }, "1": { "name": "model task_id", "tooltip": null } } };
const TripoMultiviewToModelNode = { "display_name": "Tripo: マルチビューからモデル", "inputs": { "face_limit": { "name": "face_limit" }, "image": { "name": "image" }, "image_back": { "name": "image_back" }, "image_left": { "name": "image_left" }, "image_right": { "name": "image_right" }, "model_seed": { "name": "model_seed" }, "model_version": { "name": "model_version", "tooltip": "生成に使用するモデルバージョン" }, "orientation": { "name": "orientation" }, "pbr": { "name": "pbr" }, "quad": { "name": "quad" }, "texture": { "name": "texture" }, "texture_alignment": { "name": "texture_alignment" }, "texture_quality": { "name": "texture_quality" }, "texture_seed": { "name": "texture_seed" } }, "outputs": { "0": { "name": "model_file", "tooltip": null }, "1": { "name": "model task_id", "tooltip": null } } };
const TripoRefineNode = { "description": "v1.4 Tripoモデルでのみ作成されたドラフトモデルをリファインします。", "display_name": "Tripo: ドラフトモデルのリファイン", "inputs": { "model_task_id": { "name": "model_task_id", "tooltip": "v1.4 Tripoモデルである必要があります" } }, "outputs": { "0": { "name": "model_file", "tooltip": null }, "1": { "name": "model task_id", "tooltip": null } } };
const TripoRetargetNode = { "display_name": "Tripo: リグ付きモデルのリターゲット", "inputs": { "animation": { "name": "animation" }, "original_model_task_id": { "name": "original_model_task_id" } }, "outputs": { "0": { "name": "model_file", "tooltip": null }, "1": { "name": "retarget task_id", "tooltip": null } } };
const TripoRigNode = { "display_name": "Tripo: モデルのリグ設定", "inputs": { "original_model_task_id": { "name": "original_model_task_id" } }, "outputs": { "0": { "name": "model_file", "tooltip": null }, "1": { "name": "rig task_id", "tooltip": null } } };
const TripoTextToModelNode = { "display_name": "Tripo: テキストからモデル生成", "inputs": { "face_limit": { "name": "face_limit" }, "image_seed": { "name": "image_seed" }, "model_seed": { "name": "model_seed" }, "model_version": { "name": "model_version" }, "negative_prompt": { "name": "negative_prompt" }, "pbr": { "name": "pbr" }, "prompt": { "name": "prompt" }, "quad": { "name": "quad" }, "style": { "name": "style" }, "texture": { "name": "texture" }, "texture_quality": { "name": "texture_quality" }, "texture_seed": { "name": "texture_seed" } }, "outputs": { "0": { "name": "model_file", "tooltip": null }, "1": { "name": "model task_id", "tooltip": null } } };
const TripoTextureNode = { "display_name": "Tripo: モデルのテクスチャリング", "inputs": { "model_task_id": { "name": "model_task_id" }, "pbr": { "name": "pbr" }, "texture": { "name": "texture" }, "texture_alignment": { "name": "texture_alignment" }, "texture_quality": { "name": "texture_quality" }, "texture_seed": { "name": "texture_seed" } }, "outputs": { "0": { "name": "モデルファイル", "tooltip": null }, "1": { "name": "モデル タスクID", "tooltip": null } } };
const UNETLoader = { "display_name": "拡散モデルを読み込む", "inputs": { "unet_name": { "name": "unet_name" }, "weight_dtype": { "name": "重みdtype" } } };
const UNetCrossAttentionMultiply = { "display_name": "UNetクロス注意の乗算", "inputs": { "k": { "name": "k" }, "model": { "name": "モデル" }, "out": { "name": "出力" }, "q": { "name": "q" }, "v": { "name": "v" } }, "outputs": { "0": { "tooltip": null } } };
const UNetSelfAttentionMultiply = { "display_name": "UNet自己注意の乗算", "inputs": { "k": { "name": "k" }, "model": { "name": "モデル" }, "out": { "name": "出力" }, "q": { "name": "q" }, "v": { "name": "v" } }, "outputs": { "0": { "tooltip": null } } };
const UNetTemporalAttentionMultiply = { "display_name": "UNet時間的注意の乗算", "inputs": { "cross_structural": { "name": "クロス構造" }, "cross_temporal": { "name": "クロス時間" }, "model": { "name": "モデル" }, "self_structural": { "name": "自己構造" }, "self_temporal": { "name": "自己時間" } }, "outputs": { "0": { "tooltip": null } } };
const USOStyleReference = { "display_name": "USOスタイルリファレンス", "inputs": { "clip_vision_output": { "name": "CLIP Vision出力" }, "model": { "name": "モデル" }, "model_patch": { "name": "モデルパッチ" } } };
const UpscaleModelLoader = { "display_name": "拡大モデルを読み込む", "inputs": { "model_name": { "name": "モデル名" } }, "outputs": { "0": { "tooltip": null } } };
const VAEDecode = { "description": "潜在画像をピクセル空間画像にデコードします。", "display_name": "VAEデコード", "inputs": { "samples": { "name": "サンプル", "tooltip": "デコードされる潜在。" }, "vae": { "name": "vae", "tooltip": "潜在のデコードに使用されるVAEモデル。" } }, "outputs": { "0": { "tooltip": "デコードされた画像。" } } };
const VAEDecodeAudio = { "display_name": "VAEデコード音声", "inputs": { "samples": { "name": "サンプル" }, "vae": { "name": "vae" } } };
const VAEDecodeHunyuan3D = { "display_name": "VAEDecodeHunyuan3D", "inputs": { "num_chunks": { "name": "num_chunks" }, "octree_resolution": { "name": "octree_resolution" }, "samples": { "name": "サンプル" }, "vae": { "name": "vae" } } };
const VAEDecodeTiled = { "display_name": "VAEデコード（タイル）", "inputs": { "overlap": { "name": "オーバーラップ" }, "samples": { "name": "サンプル" }, "temporal_overlap": { "name": "temporal_overlap", "tooltip": "ビデオVAE専用：重複するフレームの数。" }, "temporal_size": { "name": "temporal_size", "tooltip": "ビデオVAE専用：一度にデコードするフレームの数。" }, "tile_size": { "name": "タイルサイズ" }, "vae": { "name": "vae" } } };
const VAEEncode = { "display_name": "VAEエンコード", "inputs": { "pixels": { "name": "ピクセル" }, "vae": { "name": "vae" } } };
const VAEEncodeAudio = { "display_name": "VAEエンコード音声", "inputs": { "audio": { "name": "オーディオ" }, "vae": { "name": "vae" } } };
const VAEEncodeForInpaint = { "display_name": "VAEエンコード（インペイント用）", "inputs": { "grow_mask_by": { "name": "マスクの拡大" }, "mask": { "name": "マスク" }, "pixels": { "name": "ピクセル" }, "vae": { "name": "vae" } } };
const VAEEncodeTiled = { "display_name": "VAEエンコード（タイル）", "inputs": { "overlap": { "name": "オーバーラップ" }, "pixels": { "name": "ピクセル" }, "temporal_overlap": { "name": "temporal_overlap", "tooltip": "ビデオVAE専用：重複するフレームの数。" }, "temporal_size": { "name": "temporal_size", "tooltip": "ビデオVAE専用：一度にエンコードするフレームの数。" }, "tile_size": { "name": "タイルサイズ" }, "vae": { "name": "vae" } } };
const VAELoader = { "display_name": "VAEを読み込む", "inputs": { "vae_name": { "name": "vae_name" } } };
const VAESave = { "display_name": "VAEを保存", "inputs": { "filename_prefix": { "name": "ファイル名プレフィックス" }, "vae": { "name": "vae" } } };
const VPScheduler = { "display_name": "VPスケジューラー", "inputs": { "beta_d": { "name": "beta_d" }, "beta_min": { "name": "beta_min" }, "eps_s": { "name": "eps_s" }, "steps": { "name": "ステップ" } } };
const Veo3VideoGenerationNode = { "description": "GoogleのVeo 3 APIを使用してテキストプロンプトからビデオを生成します", "display_name": "Google Veo 3 ビデオ生成", "inputs": { "aspect_ratio": { "name": "アスペクト比", "tooltip": "出力ビデオのアスペクト比" }, "control_after_generate": { "name": "生成後の制御" }, "duration_seconds": { "name": "秒数", "tooltip": "出力ビデオの秒数（Veo 3は8秒のみ対応）" }, "enhance_prompt": { "name": "プロンプトの強化", "tooltip": "AI支援でプロンプトを強化するかどうか" }, "generate_audio": { "name": "オーディオ生成", "tooltip": "ビデオのオーディオを生成します。すべてのVeo 3モデルで対応しています。" }, "image": { "name": "画像", "tooltip": "ビデオ生成をガイドするオプションの参照画像" }, "model": { "name": "モデル", "tooltip": "ビデオ生成に使用するVeo 3モデル" }, "negative_prompt": { "name": "ネガティブプロンプト", "tooltip": "ビデオで避けるべき内容をガイドするネガティブテキストプロンプト" }, "person_generation": { "name": "人物生成", "tooltip": "ビデオでの人物生成を許可するかどうか" }, "prompt": { "name": "プロンプト", "tooltip": "ビデオのテキスト説明" }, "seed": { "name": "シード", "tooltip": "ビデオ生成のシード値（0でランダム）" } }, "outputs": { "0": { "tooltip": null } } };
const VeoVideoGenerationNode = { "description": "Google の Veo API を使用してテキストプロンプトからビデオを生成します", "display_name": "Google Veo2 ビデオ生成", "inputs": { "aspect_ratio": { "name": "aspect_ratio", "tooltip": "出力ビデオのアスペクト比" }, "control_after_generate": { "name": "control after generate" }, "duration_seconds": { "name": "duration_seconds", "tooltip": "出力ビデオの長さ（秒）" }, "enhance_prompt": { "name": "enhance_prompt", "tooltip": "AIアシストでプロンプトを強化するかどうか" }, "image": { "name": "image", "tooltip": "ビデオ生成の参考となる画像（オプション）" }, "model": { "name": "モデル", "tooltip": "ビデオ生成に使用するVeo 2モデル" }, "negative_prompt": { "name": "negative_prompt", "tooltip": "ビデオで避けたい内容を指定するネガティブプロンプト" }, "person_generation": { "name": "person_generation", "tooltip": "ビデオ内で人物生成を許可するかどうか" }, "prompt": { "name": "prompt", "tooltip": "ビデオのテキスト説明" }, "seed": { "name": "seed", "tooltip": "ビデオ生成用のシード値（0でランダム）" } }, "outputs": { "0": { "tooltip": null } } };
const VideoLinearCFGGuidance = { "display_name": "ビデオ線形CFGガイダンス", "inputs": { "min_cfg": { "name": "最小cfg" }, "model": { "name": "モデル" } } };
const VideoTriangleCFGGuidance = { "display_name": "ビデオ三角形CFGガイダンス", "inputs": { "min_cfg": { "name": "最小cfg" }, "model": { "name": "モデル" } } };
const ViduImageToVideoNode = { "description": "画像とオプションのプロンプトからビデオを生成", "display_name": "Vidu 画像からビデオ生成", "inputs": { "control_after_generate": { "name": "生成後の制御" }, "duration": { "name": "秒数", "tooltip": "出力ビデオの秒数" }, "image": { "name": "画像", "tooltip": "生成ビデオの開始フレームとして使用する画像" }, "model": { "name": "モデル", "tooltip": "モデル名" }, "movement_amplitude": { "name": "動きの振幅", "tooltip": "フレーム内のオブジェクトの動きの振幅" }, "prompt": { "name": "プロンプト", "tooltip": "ビデオ生成のためのテキスト記述" }, "resolution": { "name": "解像度", "tooltip": "サポートされる値はモデルと秒数によって異なる場合があります" }, "seed": { "name": "シード", "tooltip": "ビデオ生成のシード値（0でランダム）" } }, "outputs": { "0": { "tooltip": null } } };
const ViduReferenceVideoNode = { "description": "複数の画像とプロンプトからビデオを生成", "display_name": "Vidu リファレンスからビデオ生成", "inputs": { "aspect_ratio": { "name": "aspect_ratio", "tooltip": "出力ビデオのアスペクト比" }, "control_after_generate": { "name": "control after generate" }, "duration": { "name": "duration", "tooltip": "出力ビデオの長さ（秒）" }, "images": { "name": "images", "tooltip": "一貫した被写体でビデオを生成するための参照画像（最大7枚）。" }, "model": { "name": "model", "tooltip": "モデル名" }, "movement_amplitude": { "name": "movement_amplitude", "tooltip": "フレーム内のオブジェクトの動きの振幅" }, "prompt": { "name": "prompt", "tooltip": "ビデオ生成のためのテキストによる説明" }, "resolution": { "name": "resolution", "tooltip": "サポートされている値はモデルと長さによって異なる場合があります" }, "seed": { "name": "seed", "tooltip": "ビデオ生成のシード値（0でランダム）" } }, "outputs": { "0": { "tooltip": null } } };
const ViduStartEndToVideoNode = { "description": "開始フレームと終了フレームとプロンプトからビデオを生成", "display_name": "Vidu 開始終了からビデオ生成", "inputs": { "control_after_generate": { "name": "control after generate" }, "duration": { "name": "duration", "tooltip": "出力ビデオの長さ（秒）" }, "end_frame": { "name": "end_frame", "tooltip": "終了フレーム" }, "first_frame": { "name": "first_frame", "tooltip": "開始フレーム" }, "model": { "name": "model", "tooltip": "モデル名" }, "movement_amplitude": { "name": "movement_amplitude", "tooltip": "フレーム内のオブジェクトの動きの振幅" }, "prompt": { "name": "prompt", "tooltip": "ビデオ生成のためのテキストによる説明" }, "resolution": { "name": "resolution", "tooltip": "サポートされている値はモデルと長さによって異なる場合があります" }, "seed": { "name": "seed", "tooltip": "ビデオ生成のシード値（0でランダム）" } }, "outputs": { "0": { "tooltip": null } } };
const ViduTextToVideoNode = { "description": "テキストプロンプトからビデオを生成", "display_name": "Vidu テキストからビデオ生成", "inputs": { "aspect_ratio": { "name": "aspect_ratio", "tooltip": "出力ビデオのアスペクト比" }, "control_after_generate": { "name": "生成後の制御" }, "duration": { "name": "duration", "tooltip": "出力ビデオの長さ（秒）" }, "model": { "name": "model", "tooltip": "モデル名" }, "movement_amplitude": { "name": "movement_amplitude", "tooltip": "フレーム内のオブジェクトの動きの振幅" }, "prompt": { "name": "prompt", "tooltip": "ビデオ生成のためのテキストによる説明" }, "resolution": { "name": "resolution", "tooltip": "サポートされている値はモデルと長さによって異なる場合があります" }, "seed": { "name": "seed", "tooltip": "ビデオ生成のシード値（0でランダム）" } }, "outputs": { "0": { "tooltip": null } } };
const VoxelToMesh = { "display_name": "VoxelToMesh", "inputs": { "algorithm": { "name": "アルゴリズム" }, "threshold": { "name": "しきい値" }, "voxel": { "name": "voxel" } } };
const VoxelToMeshBasic = { "display_name": "VoxelToMeshBasic", "inputs": { "threshold": { "name": "閾値" }, "voxel": { "name": "ボクセル" } } };
const Wan22FunControlToVideo = { "display_name": "Wan22FunControlToVideo", "inputs": { "batch_size": { "name": "バッチサイズ" }, "control_video": { "name": "制御動画" }, "height": { "name": "高さ" }, "length": { "name": "長さ" }, "negative": { "name": "ネガティブ" }, "positive": { "name": "ポジティブ" }, "ref_image": { "name": "参照画像" }, "vae": { "name": "vae" }, "width": { "name": "幅" } }, "outputs": { "0": { "name": "ポジティブ", "tooltip": null }, "1": { "name": "ネガティブ", "tooltip": null }, "2": { "name": "潜在変数", "tooltip": null } } };
const Wan22ImageToVideoLatent = { "display_name": "Wan22ImageToVideoLatent", "inputs": { "batch_size": { "name": "バッチサイズ" }, "height": { "name": "高さ" }, "length": { "name": "長さ" }, "start_image": { "name": "開始画像" }, "vae": { "name": "vae" }, "width": { "name": "幅" } }, "outputs": { "0": { "tooltip": null } } };
const WanAnimateToVideo = { "display_name": "WanAnimateToVideo", "inputs": { "background_video": { "name": "背景動画" }, "batch_size": { "name": "バッチサイズ" }, "character_mask": { "name": "キャラクターマスク" }, "clip_vision_output": { "name": "クリップビジョン出力" }, "continue_motion": { "name": "継続モーション" }, "continue_motion_max_frames": { "name": "継続モーション最大フレーム数" }, "face_video": { "name": "顔動画" }, "height": { "name": "高さ" }, "length": { "name": "長さ" }, "negative": { "name": "ネガティブ" }, "pose_video": { "name": "ポーズ動画" }, "positive": { "name": "ポジティブ" }, "reference_image": { "name": "参照画像" }, "vae": { "name": "vae" }, "video_frame_offset": { "name": "動画フレームオフセット", "tooltip": "すべての入力動画でシークするフレーム数。チャンクによる長い動画生成に使用されます。動画を延長するには、前のノードのvideo_frame_offset出力に接続してください。" }, "width": { "name": "幅" } }, "outputs": { "0": { "name": "ポジティブ", "tooltip": null }, "1": { "name": "ネガティブ", "tooltip": null }, "2": { "name": "潜在変数", "tooltip": null }, "3": { "name": "トリム潜在変数", "tooltip": null }, "4": { "name": "トリム画像", "tooltip": null }, "5": { "name": "動画フレームオフセット", "tooltip": null } } };
const WanCameraEmbedding = { "display_name": "WanCameraEmbedding", "inputs": { "camera_pose": { "name": "カメラポーズ" }, "cx": { "name": "cx" }, "cy": { "name": "cy" }, "fx": { "name": "fx" }, "fy": { "name": "fy" }, "height": { "name": "高さ" }, "length": { "name": "長さ" }, "speed": { "name": "速度" }, "width": { "name": "幅" } }, "outputs": { "0": { "name": "カメラ埋め込み", "tooltip": null }, "1": { "name": "幅", "tooltip": null }, "2": { "name": "高さ", "tooltip": null }, "3": { "name": "長さ", "tooltip": null } } };
const WanCameraImageToVideo = { "display_name": "WanCameraImageToVideo", "inputs": { "batch_size": { "name": "バッチサイズ" }, "camera_conditions": { "name": "カメラ条件" }, "clip_vision_output": { "name": "CLIPビジョン出力" }, "height": { "name": "高さ" }, "length": { "name": "長さ" }, "negative": { "name": "ネガティブ" }, "positive": { "name": "ポジティブ" }, "start_image": { "name": "開始画像" }, "vae": { "name": "VAE" }, "width": { "name": "幅" } }, "outputs": { "0": { "name": "ポジティブ", "tooltip": null }, "1": { "name": "ネガティブ", "tooltip": null }, "2": { "name": "潜在変数", "tooltip": null } } };
const WanContextWindowsManual = { "description": "WANライクモデル（dim=2）のコンテキストウィンドウを手動で設定します。", "display_name": "WAN コンテキストウィンドウ（手動）", "inputs": { "closed_loop": { "name": "クローズドループ", "tooltip": "コンテキストウィンドウのループを閉じるかどうか。ループスケジュールにのみ適用されます。" }, "context_length": { "name": "コンテキスト長", "tooltip": "コンテキストウィンドウの長さ。" }, "context_overlap": { "name": "コンテキストオーバーラップ", "tooltip": "コンテキストウィンドウのオーバーラップ。" }, "context_schedule": { "name": "コンテキストスケジュール", "tooltip": "コンテキストウィンドウのストライド。" }, "context_stride": { "name": "コンテキストストライド", "tooltip": "コンテキストウィンドウのストライド。均一スケジュールにのみ適用されます。" }, "fuse_method": { "name": "融合方法", "tooltip": "コンテキストウィンドウを融合するために使用する方法。" }, "model": { "name": "モデル", "tooltip": "サンプリング中にコンテキストウィンドウを適用するモデル。" } }, "outputs": { "0": { "tooltip": "サンプリング中にコンテキストウィンドウが適用されたモデル。" } } };
const WanFirstLastFrameToVideo = { "display_name": "WanFirstLastFrameToVideo", "inputs": { "batch_size": { "name": "バッチサイズ" }, "clip_vision_end_image": { "name": "clipビジョン終了画像" }, "clip_vision_start_image": { "name": "clipビジョン開始画像" }, "end_image": { "name": "終了画像" }, "height": { "name": "高さ" }, "length": { "name": "長さ" }, "negative": { "name": "ネガティブ" }, "positive": { "name": "ポジティブ" }, "start_image": { "name": "開始画像" }, "vae": { "name": "vae" }, "width": { "name": "幅" } }, "outputs": { "0": { "name": "ポジティブ", "tooltip": null }, "1": { "name": "ネガティブ", "tooltip": null }, "2": { "name": "latent", "tooltip": null } } };
const WanFunControlToVideo = { "display_name": "WanFunControlToVideo", "inputs": { "batch_size": { "name": "バッチサイズ" }, "clip_vision_output": { "name": "clip_vision_output" }, "control_video": { "name": "コントロールビデオ" }, "height": { "name": "高さ" }, "length": { "name": "長さ" }, "negative": { "name": "ネガティブ" }, "positive": { "name": "ポジティブ" }, "start_image": { "name": "開始画像" }, "vae": { "name": "vae" }, "width": { "name": "幅" } }, "outputs": { "0": { "name": "ポジティブ", "tooltip": null }, "1": { "name": "ネガティブ", "tooltip": null }, "2": { "name": "latent", "tooltip": null } } };
const WanFunInpaintToVideo = { "display_name": "WanFunInpaintToVideo", "inputs": { "batch_size": { "name": "バッチサイズ" }, "clip_vision_output": { "name": "clip_vision_output" }, "end_image": { "name": "終了画像" }, "height": { "name": "高さ" }, "length": { "name": "長さ" }, "negative": { "name": "ネガティブ" }, "positive": { "name": "ポジティブ" }, "start_image": { "name": "開始画像" }, "vae": { "name": "vae" }, "width": { "name": "幅" } }, "outputs": { "0": { "name": "ポジティブ", "tooltip": null }, "1": { "name": "ネガティブ", "tooltip": null }, "2": { "name": "latent", "tooltip": null } } };
const WanHuMoImageToVideo = { "display_name": "WanHuMoImageToVideo", "inputs": { "audio_encoder_output": { "name": "オーディオエンコーダー出力" }, "batch_size": { "name": "バッチサイズ" }, "height": { "name": "高さ" }, "length": { "name": "長さ" }, "negative": { "name": "ネガティブ" }, "positive": { "name": "ポジティブ" }, "ref_image": { "name": "参照画像" }, "vae": { "name": "VAE" }, "width": { "name": "幅" } }, "outputs": { "0": { "name": "ポジティブ", "tooltip": null }, "1": { "name": "ネガティブ", "tooltip": null }, "2": { "name": "潜在表現", "tooltip": null } } };
const WanImageToImageApi = { "description": "1つまたは2つの入力画像とテキストプロンプトから画像を生成します。出力画像は現在1.6MPに固定されており、アスペクト比は入力画像に合わせます。", "display_name": "Wan 画像から画像へ", "inputs": { "control_after_generate": { "name": "生成後の制御" }, "image": { "name": "画像", "tooltip": "単一画像編集または複数画像融合、最大2画像まで。" }, "model": { "name": "モデル", "tooltip": "使用するモデル。" }, "negative_prompt": { "name": "ネガティブプロンプト", "tooltip": "避けるべき要素を指示するネガティブテキストプロンプト。" }, "prompt": { "name": "プロンプト", "tooltip": "要素や視覚的特徴を記述するプロンプト。英語/中国語をサポート。" }, "seed": { "name": "シード", "tooltip": "生成に使用するシード値。" }, "watermark": { "name": "透かし", "tooltip": "結果に「AI生成」の透かしを追加するかどうか。" } }, "outputs": { "0": { "tooltip": null } } };
const WanImageToVideo = { "display_name": "Wan画像からビデオへ", "inputs": { "batch_size": { "name": "バッチサイズ" }, "clip_vision_output": { "name": "clipビジョン出力" }, "height": { "name": "高さ" }, "length": { "name": "長さ" }, "negative": { "name": "ネガティブ" }, "positive": { "name": "ポジティブ" }, "start_image": { "name": "開始画像" }, "vae": { "name": "vae" }, "width": { "name": "幅" } }, "outputs": { "0": { "name": "ポジティブ", "tooltip": null }, "1": { "name": "ネガティブ", "tooltip": null }, "2": { "name": "潜在", "tooltip": null } } };
const WanImageToVideoApi = { "description": "最初のフレームとテキストプロンプトに基づいて動画を生成します。", "display_name": "Wan 画像から動画へ", "inputs": { "audio": { "name": "オーディオ", "tooltip": "オーディオは明確で大きな声を含み、余分なノイズや背景音楽がないこと。" }, "control_after_generate": { "name": "生成後の制御" }, "duration": { "name": "長さ", "tooltip": "利用可能な長さ：5秒と10秒" }, "generate_audio": { "name": "オーディオ生成", "tooltip": "オーディオ入力がない場合、自動的にオーディオを生成します。" }, "image": { "name": "画像" }, "model": { "name": "モデル", "tooltip": "使用するモデル。" }, "negative_prompt": { "name": "ネガティブプロンプト", "tooltip": "避けるべき要素を指示するネガティブテキストプロンプト。" }, "prompt": { "name": "プロンプト", "tooltip": "要素や視覚的特徴を記述するプロンプト。英語/中国語をサポート。" }, "prompt_extend": { "name": "プロンプト拡張", "tooltip": "AI支援でプロンプトを強化するかどうか。" }, "resolution": { "name": "解像度" }, "seed": { "name": "シード", "tooltip": "生成に使用するシード値。" }, "watermark": { "name": "透かし", "tooltip": "結果に「AI生成」の透かしを追加するかどうか。" } }, "outputs": { "0": { "tooltip": null } } };
const WanPhantomSubjectToVideo = { "display_name": "WanPhantomSubjectToVideo", "inputs": { "batch_size": { "name": "バッチサイズ" }, "height": { "name": "高さ" }, "images": { "name": "画像" }, "length": { "name": "長さ" }, "negative": { "name": "ネガティブ" }, "positive": { "name": "ポジティブ" }, "vae": { "name": "VAE" }, "width": { "name": "幅" } }, "outputs": { "0": { "name": "ポジティブ", "tooltip": null }, "1": { "name": "ネガティブテキスト", "tooltip": null }, "2": { "name": "ネガティブ画像テキスト", "tooltip": null }, "3": { "name": "潜在表現", "tooltip": null } } };
const WanSoundImageToVideo = { "display_name": "WanSoundImageToVideo", "inputs": { "audio_encoder_output": { "name": "オーディオエンコーダ出力" }, "batch_size": { "name": "バッチサイズ" }, "control_video": { "name": "制御ビデオ" }, "height": { "name": "高さ" }, "length": { "name": "長さ" }, "negative": { "name": "ネガティブ" }, "positive": { "name": "ポジティブ" }, "ref_image": { "name": "参照画像" }, "ref_motion": { "name": "参照モーション" }, "vae": { "name": "VAE" }, "width": { "name": "幅" } }, "outputs": { "0": { "name": "ポジティブ", "tooltip": null }, "1": { "name": "ネガティブ", "tooltip": null }, "2": { "name": "潜在表現", "tooltip": null } } };
const WanSoundImageToVideoExtend = { "display_name": "WanSoundImageToVideoExtend", "inputs": { "audio_encoder_output": { "name": "オーディオエンコーダ出力" }, "control_video": { "name": "制御ビデオ" }, "length": { "name": "長さ" }, "negative": { "name": "ネガティブ" }, "positive": { "name": "ポジティブ" }, "ref_image": { "name": "参照画像" }, "vae": { "name": "VAE" }, "video_latent": { "name": "ビデオ潜在表現" } }, "outputs": { "0": { "name": "ポジティブ", "tooltip": null }, "1": { "name": "ネガティブ", "tooltip": null }, "2": { "name": "潜在表現", "tooltip": null } } };
const WanTextToImageApi = { "description": "テキストプロンプトに基づいて画像を生成します。", "display_name": "Wan テキストから画像へ", "inputs": { "control_after_generate": { "name": "生成後の制御" }, "height": { "name": "高さ" }, "model": { "name": "モデル", "tooltip": "使用するモデル。" }, "negative_prompt": { "name": "ネガティブプロンプト", "tooltip": "避けるべき要素をガイドするネガティブテキストプロンプト。" }, "prompt": { "name": "プロンプト", "tooltip": "要素や視覚的特徴を説明するためのプロンプト。英語/中国語をサポート。" }, "prompt_extend": { "name": "プロンプト拡張", "tooltip": "AI支援でプロンプトを強化するかどうか。" }, "seed": { "name": "シード", "tooltip": "生成に使用するシード値。" }, "watermark": { "name": "透かし", "tooltip": "結果に「AI生成」の透かしを追加するかどうか。" }, "width": { "name": "幅" } }, "outputs": { "0": { "tooltip": null } } };
const WanTextToVideoApi = { "description": "テキストプロンプトに基づいて動画を生成します。", "display_name": "Wan Text to Video", "inputs": { "audio": { "name": "audio", "tooltip": "オーディオは明確で大きな声を含み、余分なノイズや背景音楽がないこと。" }, "control_after_generate": { "name": "control after generate" }, "duration": { "name": "duration", "tooltip": "利用可能な長さ: 5秒と10秒" }, "generate_audio": { "name": "generate_audio", "tooltip": "オーディオ入力がない場合、自動的にオーディオを生成します。" }, "model": { "name": "model", "tooltip": "使用するモデル。" }, "negative_prompt": { "name": "negative_prompt", "tooltip": "避けるべき要素をガイドするネガティブテキストプロンプト。" }, "prompt": { "name": "prompt", "tooltip": "要素や視覚的特徴を説明するために使用するプロンプト。英語/中国語をサポート。" }, "prompt_extend": { "name": "prompt_extend", "tooltip": "AI支援でプロンプトを拡張するかどうか。" }, "seed": { "name": "seed", "tooltip": "生成に使用するシード値。" }, "size": { "name": "size" }, "watermark": { "name": "watermark", "tooltip": "結果に「AI生成」の透かしを追加するかどうか。" } }, "outputs": { "0": { "tooltip": null } } };
const WanTrackToVideo = { "display_name": "WanTrackToVideo", "inputs": { "batch_size": { "name": "batch_size" }, "clip_vision_output": { "name": "clip_vision_output" }, "height": { "name": "height" }, "length": { "name": "length" }, "negative": { "name": "negative" }, "positive": { "name": "positive" }, "start_image": { "name": "start_image" }, "temperature": { "name": "temperature" }, "topk": { "name": "topk" }, "tracks": { "name": "tracks" }, "vae": { "name": "vae" }, "width": { "name": "width" } }, "outputs": { "0": { "name": "positive", "tooltip": null }, "1": { "name": "negative", "tooltip": null }, "2": { "name": "latent", "tooltip": null } } };
const WanVaceToVideo = { "display_name": "WanVaceToVideo", "inputs": { "batch_size": { "name": "バッチサイズ" }, "control_masks": { "name": "コントロールマスク" }, "control_video": { "name": "コントロールビデオ" }, "height": { "name": "高さ" }, "length": { "name": "長さ" }, "negative": { "name": "ネガティブ" }, "positive": { "name": "ポジティブ" }, "reference_image": { "name": "参照画像" }, "strength": { "name": "強度" }, "vae": { "name": "vae" }, "width": { "name": "幅" } }, "outputs": { "0": { "name": "ポジティブ", "tooltip": null }, "1": { "name": "ネガティブ", "tooltip": null }, "2": { "name": "latent", "tooltip": null }, "3": { "name": "トリムlatent", "tooltip": null } } };
const WebcamCapture = { "display_name": "ウェブカメラキャプチャ", "inputs": { "capture_on_queue": { "name": "キューでキャプチャ" }, "height": { "name": "高さ" }, "image": { "name": "画像" }, "waiting for camera___": {}, "width": { "name": "幅" } } };
const unCLIPCheckpointLoader = { "display_name": "unCLIPチェックポイントローダー", "inputs": { "ckpt_name": { "name": "ckpt_name" } } };
const unCLIPConditioning = { "display_name": "unCLIP条件付け", "inputs": { "clip_vision_output": { "name": "clip_vision_output" }, "conditioning": { "name": "コンディショニング" }, "noise_augmentation": { "name": "ノイズ増強" }, "strength": { "name": "強度" } } };
const nodeDefs = {
  APG,
  AddNoise,
  AlignYourStepsScheduler,
  AudioAdjustVolume,
  AudioConcat,
  AudioEncoderEncode,
  AudioEncoderLoader,
  AudioMerge,
  BasicGuider,
  BasicScheduler,
  BetaSamplingScheduler,
  ByteDanceFirstLastFrameNode,
  ByteDanceImageEditNode,
  ByteDanceImageNode,
  ByteDanceImageReferenceNode,
  ByteDanceImageToVideoNode,
  ByteDanceSeedreamNode,
  ByteDanceTextToVideoNode,
  CFGGuider,
  CFGNorm,
  CFGZeroStar,
  CLIPAttentionMultiply,
  CLIPLoader,
  CLIPMergeAdd,
  CLIPMergeSimple,
  CLIPMergeSubtract,
  CLIPSave,
  CLIPSetLastLayer,
  CLIPTextEncode,
  CLIPTextEncodeControlnet,
  CLIPTextEncodeFlux,
  CLIPTextEncodeHiDream,
  CLIPTextEncodeHunyuanDiT,
  CLIPTextEncodeLumina2,
  CLIPTextEncodePixArtAlpha,
  CLIPTextEncodeSD3,
  CLIPTextEncodeSDXL,
  CLIPTextEncodeSDXLRefiner,
  CLIPVisionEncode,
  CLIPVisionLoader,
  Canny,
  CaseConverter,
  CheckpointLoader,
  CheckpointLoaderSimple,
  CheckpointSave,
  ChromaRadianceOptions,
  CombineHooks2,
  CombineHooks4,
  CombineHooks8,
  ConditioningAverage,
  ConditioningCombine,
  ConditioningConcat,
  ConditioningSetArea,
  ConditioningSetAreaPercentage,
  ConditioningSetAreaPercentageVideo,
  ConditioningSetAreaStrength,
  ConditioningSetDefaultCombine,
  ConditioningSetMask,
  ConditioningSetProperties,
  ConditioningSetPropertiesAndCombine,
  ConditioningSetTimestepRange,
  ConditioningStableAudio,
  ConditioningTimestepsRange,
  ConditioningZeroOut,
  ContextWindowsManual,
  ControlNetApply,
  ControlNetApplyAdvanced,
  ControlNetApplySD3,
  ControlNetInpaintingAliMamaApply,
  ControlNetLoader,
  CosmosImageToVideoLatent,
  CosmosPredict2ImageToVideoLatent,
  CreateHookKeyframe,
  CreateHookKeyframesFromFloats,
  CreateHookKeyframesInterpolated,
  CreateHookLora,
  CreateHookLoraModelOnly,
  CreateHookModelAsLora,
  CreateHookModelAsLoraModelOnly,
  CreateVideo,
  CropMask,
  DiffControlNetLoader,
  DifferentialDiffusion,
  DiffusersLoader,
  DisableNoise,
  DualCFGGuider,
  DualCLIPLoader,
  EasyCache,
  EmptyAceStepLatentAudio,
  EmptyAudio,
  EmptyChromaRadianceLatentImage,
  EmptyCosmosLatentVideo,
  EmptyHunyuanImageLatent,
  EmptyHunyuanLatentVideo,
  EmptyImage,
  EmptyLTXVLatentVideo,
  EmptyLatentAudio,
  EmptyLatentHunyuan3Dv2,
  EmptyLatentImage,
  EmptyMochiLatentVideo,
  EmptySD3LatentImage,
  "Epsilon Scaling": { "display_name": "Epsilon Scaling", "inputs": { "model": { "name": "モデル" }, "scaling_factor": { "name": "スケーリング係数" } }, "outputs": { "0": { "tooltip": null } } },
  ExponentialScheduler,
  ExtendIntermediateSigmas,
  FeatherMask,
  FlipSigmas,
  FluxDisableGuidance,
  FluxGuidance,
  FluxKontextImageScale,
  FluxKontextMaxImageNode,
  FluxKontextMultiReferenceLatentMethod,
  FluxKontextProImageNode,
  FluxProExpandNode,
  FluxProFillNode,
  FluxProUltraImageNode,
  FreSca,
  FreeU,
  FreeU_V2,
  GITSScheduler,
  GLIGENLoader,
  GLIGENTextBoxApply,
  GeminiImageNode,
  GeminiInputFiles,
  GeminiNode,
  GetImageSize,
  GetVideoComponents,
  GrowMask,
  Hunyuan3Dv2Conditioning,
  Hunyuan3Dv2ConditioningMultiView,
  HunyuanImageToVideo,
  HunyuanRefinerLatent,
  HyperTile,
  HypernetworkLoader,
  IdeogramV1,
  IdeogramV2,
  IdeogramV3,
  ImageAddNoise,
  ImageBatch,
  ImageBlend,
  ImageBlur,
  ImageColorToMask,
  ImageCompositeMasked,
  ImageCrop,
  ImageFlip,
  ImageFromBatch,
  ImageInvert,
  ImageOnlyCheckpointLoader,
  ImageOnlyCheckpointSave,
  ImagePadForOutpaint,
  ImageQuantize,
  ImageRGBToYUV,
  ImageRotate,
  ImageScale,
  ImageScaleBy,
  ImageScaleToMaxDimension,
  ImageScaleToTotalPixels,
  ImageSharpen,
  ImageStitch,
  ImageToMask,
  ImageUpscaleWithModel,
  ImageYUVToRGB,
  InpaintModelConditioning,
  InstructPixToPixConditioning,
  InvertMask,
  JoinImageWithAlpha,
  KSampler,
  KSamplerAdvanced,
  KSamplerSelect,
  KarrasScheduler,
  KlingCameraControlI2VNode,
  KlingCameraControlT2VNode,
  KlingCameraControls,
  KlingDualCharacterVideoEffectNode,
  KlingImage2VideoNode,
  KlingImageGenerationNode,
  KlingLipSyncAudioToVideoNode,
  KlingLipSyncTextToVideoNode,
  KlingSingleImageVideoEffectNode,
  KlingStartEndFrameNode,
  KlingTextToVideoNode,
  KlingVideoExtendNode,
  KlingVirtualTryOnNode,
  LTXVAddGuide,
  LTXVConditioning,
  LTXVCropGuides,
  LTXVImgToVideo,
  LTXVPreprocess,
  LTXVScheduler,
  LaplaceScheduler,
  LatentAdd,
  LatentApplyOperation,
  LatentApplyOperationCFG,
  LatentBatch,
  LatentBatchSeedBehavior,
  LatentBlend,
  LatentComposite,
  LatentCompositeMasked,
  LatentConcat,
  LatentCrop,
  LatentCut,
  LatentFlip,
  LatentFromBatch,
  LatentInterpolate,
  LatentMultiply,
  LatentOperationSharpen,
  LatentOperationTonemapReinhard,
  LatentRotate,
  LatentSubtract,
  LatentUpscale,
  LatentUpscaleBy,
  LazyCache,
  Load3D,
  LoadAudio,
  LoadImage,
  LoadImageMask,
  LoadImageOutput,
  LoadLatent,
  LoadVideo,
  LoraLoader,
  LoraLoaderModelOnly,
  LoraModelLoader,
  LoraSave,
  LossGraphNode,
  LotusConditioning,
  LtxvApiImageToVideo,
  LtxvApiTextToVideo,
  LumaConceptsNode,
  LumaImageModifyNode,
  LumaImageNode,
  LumaImageToVideoNode,
  LumaReferenceNode,
  LumaVideoNode,
  Mahiro,
  MaskComposite,
  MaskPreview,
  MaskToImage,
  MinimaxHailuoVideoNode,
  MinimaxImageToVideoNode,
  MinimaxTextToVideoNode,
  ModelComputeDtype,
  ModelMergeAdd,
  ModelMergeAuraflow,
  ModelMergeBlocks,
  ModelMergeCosmos14B,
  ModelMergeCosmos7B,
  ModelMergeCosmosPredict2_14B,
  ModelMergeCosmosPredict2_2B,
  ModelMergeFlux1,
  ModelMergeLTXV,
  ModelMergeMochiPreview,
  ModelMergeQwenImage,
  ModelMergeSD1,
  ModelMergeSD2,
  ModelMergeSD35_Large,
  ModelMergeSD3_2B,
  ModelMergeSDXL,
  ModelMergeSimple,
  ModelMergeSubtract,
  ModelMergeWAN2_1,
  ModelPatchLoader,
  ModelSamplingAuraFlow,
  ModelSamplingContinuousEDM,
  ModelSamplingContinuousV,
  ModelSamplingDiscrete,
  ModelSamplingFlux,
  ModelSamplingLTXV,
  ModelSamplingSD3,
  ModelSamplingStableCascade,
  ModelSave,
  MoonvalleyImg2VideoNode,
  MoonvalleyTxt2VideoNode,
  MoonvalleyVideo2VideoNode,
  Morphology,
  OpenAIChatConfig,
  OpenAIChatNode,
  OpenAIDalle2,
  OpenAIDalle3,
  OpenAIGPTImage1,
  OpenAIInputFiles,
  OpenAIVideoSora2,
  OptimalStepsScheduler,
  PairConditioningCombine,
  PairConditioningSetDefaultCombine,
  PairConditioningSetProperties,
  PairConditioningSetPropertiesAndCombine,
  PatchModelAddDownscale,
  PerpNeg,
  PerpNegGuider,
  PerturbedAttentionGuidance,
  PhotoMakerEncode,
  PhotoMakerLoader,
  PixverseImageToVideoNode,
  PixverseTemplateNode,
  PixverseTextToVideoNode,
  PixverseTransitionVideoNode,
  PolyexponentialScheduler,
  PorterDuffImageComposite,
  Preview3D,
  PreviewAny,
  PreviewAudio,
  PreviewImage,
  PrimitiveBoolean,
  PrimitiveFloat,
  PrimitiveInt,
  PrimitiveString,
  PrimitiveStringMultiline,
  QuadrupleCLIPLoader,
  QwenImageDiffsynthControlnet,
  RandomNoise,
  RebatchImages,
  RebatchLatents,
  RecordAudio,
  RecraftColorRGB,
  RecraftControls,
  RecraftCreativeUpscaleNode,
  RecraftCrispUpscaleNode,
  RecraftImageInpaintingNode,
  RecraftImageToImageNode,
  RecraftRemoveBackgroundNode,
  RecraftReplaceBackgroundNode,
  RecraftStyleV3DigitalIllustration,
  RecraftStyleV3InfiniteStyleLibrary,
  RecraftStyleV3LogoRaster,
  RecraftStyleV3RealisticImage,
  RecraftTextToImageNode,
  RecraftTextToVectorNode,
  RecraftVectorizeImageNode,
  ReferenceLatent,
  RegexExtract,
  RegexMatch,
  RegexReplace,
  RenormCFG,
  RepeatImageBatch,
  RepeatLatentBatch,
  RescaleCFG,
  ResizeAndPadImage,
  Rodin3D_Detail,
  Rodin3D_Gen2,
  Rodin3D_Regular,
  Rodin3D_Sketch,
  Rodin3D_Smooth,
  RunwayFirstLastFrameNode,
  RunwayImageToVideoNodeGen3a,
  RunwayImageToVideoNodeGen4,
  RunwayTextToImageNode,
  SDTurboScheduler,
  SD_4XUpscale_Conditioning,
  SV3D_Conditioning,
  SVD_img2vid_Conditioning,
  SamplerCustom,
  SamplerCustomAdvanced,
  SamplerDPMAdaptative,
  SamplerDPMPP_2M_SDE,
  SamplerDPMPP_2S_Ancestral,
  SamplerDPMPP_3M_SDE,
  SamplerDPMPP_SDE,
  SamplerER_SDE,
  SamplerEulerAncestral,
  SamplerEulerAncestralCFGPP,
  SamplerEulerCFGpp,
  SamplerLCMUpscale,
  SamplerLMS,
  SamplerSASolver,
  SamplingPercentToSigma,
  SaveAnimatedPNG,
  SaveAnimatedWEBP,
  SaveAudio,
  SaveAudioMP3,
  SaveAudioOpus,
  SaveGLB,
  SaveImage,
  SaveImageWebsocket,
  SaveLatent,
  SaveSVGNode,
  SaveVideo,
  SaveWEBM,
  ScaleROPE,
  SelfAttentionGuidance,
  SetClipHooks,
  SetFirstSigma,
  SetHookKeyframes,
  SetLatentNoiseMask,
  SetUnionControlNetType,
  SkipLayerGuidanceDiT,
  SkipLayerGuidanceDiTSimple,
  SkipLayerGuidanceSD3,
  SolidMask,
  SplitAudioChannels,
  SplitImageWithAlpha,
  SplitSigmas,
  SplitSigmasDenoise,
  StabilityAudioInpaint,
  StabilityAudioToAudio,
  StabilityStableImageSD_3_5Node,
  StabilityStableImageUltraNode,
  StabilityTextToAudio,
  StabilityUpscaleConservativeNode,
  StabilityUpscaleCreativeNode,
  StabilityUpscaleFastNode,
  StableCascade_EmptyLatentImage,
  StableCascade_StageB_Conditioning,
  StableCascade_StageC_VAEEncode,
  StableCascade_SuperResolutionControlnet,
  StableZero123_Conditioning,
  StableZero123_Conditioning_Batched,
  StringCompare,
  StringConcatenate,
  StringContains,
  StringLength,
  StringReplace,
  StringSubstring,
  StringTrim,
  StyleModelApply,
  StyleModelLoader,
  T5TokenizerOptions,
  TCFG,
  TemporalScoreRescaling,
  TextEncodeAceStepAudio,
  TextEncodeHunyuanVideo_ImageToVideo,
  TextEncodeQwenImageEdit,
  TextEncodeQwenImageEditPlus,
  ThresholdMask,
  TomePatchModel,
  TorchCompileModel,
  TrainLoraNode,
  TrimAudioDuration,
  TrimVideoLatent,
  TripleCLIPLoader,
  TripoConversionNode,
  TripoImageToModelNode,
  TripoMultiviewToModelNode,
  TripoRefineNode,
  TripoRetargetNode,
  TripoRigNode,
  TripoTextToModelNode,
  TripoTextureNode,
  UNETLoader,
  UNetCrossAttentionMultiply,
  UNetSelfAttentionMultiply,
  UNetTemporalAttentionMultiply,
  USOStyleReference,
  UpscaleModelLoader,
  VAEDecode,
  VAEDecodeAudio,
  VAEDecodeHunyuan3D,
  VAEDecodeTiled,
  VAEEncode,
  VAEEncodeAudio,
  VAEEncodeForInpaint,
  VAEEncodeTiled,
  VAELoader,
  VAESave,
  VPScheduler,
  Veo3VideoGenerationNode,
  VeoVideoGenerationNode,
  VideoLinearCFGGuidance,
  VideoTriangleCFGGuidance,
  ViduImageToVideoNode,
  ViduReferenceVideoNode,
  ViduStartEndToVideoNode,
  ViduTextToVideoNode,
  VoxelToMesh,
  VoxelToMeshBasic,
  Wan22FunControlToVideo,
  Wan22ImageToVideoLatent,
  WanAnimateToVideo,
  WanCameraEmbedding,
  WanCameraImageToVideo,
  WanContextWindowsManual,
  WanFirstLastFrameToVideo,
  WanFunControlToVideo,
  WanFunInpaintToVideo,
  WanHuMoImageToVideo,
  WanImageToImageApi,
  WanImageToVideo,
  WanImageToVideoApi,
  WanPhantomSubjectToVideo,
  WanSoundImageToVideo,
  WanSoundImageToVideoExtend,
  WanTextToImageApi,
  WanTextToVideoApi,
  WanTrackToVideo,
  WanVaceToVideo,
  WebcamCapture,
  unCLIPCheckpointLoader,
  unCLIPConditioning
};
export {
  APG,
  AddNoise,
  AlignYourStepsScheduler,
  AudioAdjustVolume,
  AudioConcat,
  AudioEncoderEncode,
  AudioEncoderLoader,
  AudioMerge,
  BasicGuider,
  BasicScheduler,
  BetaSamplingScheduler,
  ByteDanceFirstLastFrameNode,
  ByteDanceImageEditNode,
  ByteDanceImageNode,
  ByteDanceImageReferenceNode,
  ByteDanceImageToVideoNode,
  ByteDanceSeedreamNode,
  ByteDanceTextToVideoNode,
  CFGGuider,
  CFGNorm,
  CFGZeroStar,
  CLIPAttentionMultiply,
  CLIPLoader,
  CLIPMergeAdd,
  CLIPMergeSimple,
  CLIPMergeSubtract,
  CLIPSave,
  CLIPSetLastLayer,
  CLIPTextEncode,
  CLIPTextEncodeControlnet,
  CLIPTextEncodeFlux,
  CLIPTextEncodeHiDream,
  CLIPTextEncodeHunyuanDiT,
  CLIPTextEncodeLumina2,
  CLIPTextEncodePixArtAlpha,
  CLIPTextEncodeSD3,
  CLIPTextEncodeSDXL,
  CLIPTextEncodeSDXLRefiner,
  CLIPVisionEncode,
  CLIPVisionLoader,
  Canny,
  CaseConverter,
  CheckpointLoader,
  CheckpointLoaderSimple,
  CheckpointSave,
  ChromaRadianceOptions,
  CombineHooks2,
  CombineHooks4,
  CombineHooks8,
  ConditioningAverage,
  ConditioningCombine,
  ConditioningConcat,
  ConditioningSetArea,
  ConditioningSetAreaPercentage,
  ConditioningSetAreaPercentageVideo,
  ConditioningSetAreaStrength,
  ConditioningSetDefaultCombine,
  ConditioningSetMask,
  ConditioningSetProperties,
  ConditioningSetPropertiesAndCombine,
  ConditioningSetTimestepRange,
  ConditioningStableAudio,
  ConditioningTimestepsRange,
  ConditioningZeroOut,
  ContextWindowsManual,
  ControlNetApply,
  ControlNetApplyAdvanced,
  ControlNetApplySD3,
  ControlNetInpaintingAliMamaApply,
  ControlNetLoader,
  CosmosImageToVideoLatent,
  CosmosPredict2ImageToVideoLatent,
  CreateHookKeyframe,
  CreateHookKeyframesFromFloats,
  CreateHookKeyframesInterpolated,
  CreateHookLora,
  CreateHookLoraModelOnly,
  CreateHookModelAsLora,
  CreateHookModelAsLoraModelOnly,
  CreateVideo,
  CropMask,
  DiffControlNetLoader,
  DifferentialDiffusion,
  DiffusersLoader,
  DisableNoise,
  DualCFGGuider,
  DualCLIPLoader,
  EasyCache,
  EmptyAceStepLatentAudio,
  EmptyAudio,
  EmptyChromaRadianceLatentImage,
  EmptyCosmosLatentVideo,
  EmptyHunyuanImageLatent,
  EmptyHunyuanLatentVideo,
  EmptyImage,
  EmptyLTXVLatentVideo,
  EmptyLatentAudio,
  EmptyLatentHunyuan3Dv2,
  EmptyLatentImage,
  EmptyMochiLatentVideo,
  EmptySD3LatentImage,
  ExponentialScheduler,
  ExtendIntermediateSigmas,
  FeatherMask,
  FlipSigmas,
  FluxDisableGuidance,
  FluxGuidance,
  FluxKontextImageScale,
  FluxKontextMaxImageNode,
  FluxKontextMultiReferenceLatentMethod,
  FluxKontextProImageNode,
  FluxProExpandNode,
  FluxProFillNode,
  FluxProUltraImageNode,
  FreSca,
  FreeU,
  FreeU_V2,
  GITSScheduler,
  GLIGENLoader,
  GLIGENTextBoxApply,
  GeminiImageNode,
  GeminiInputFiles,
  GeminiNode,
  GetImageSize,
  GetVideoComponents,
  GrowMask,
  Hunyuan3Dv2Conditioning,
  Hunyuan3Dv2ConditioningMultiView,
  HunyuanImageToVideo,
  HunyuanRefinerLatent,
  HyperTile,
  HypernetworkLoader,
  IdeogramV1,
  IdeogramV2,
  IdeogramV3,
  ImageAddNoise,
  ImageBatch,
  ImageBlend,
  ImageBlur,
  ImageColorToMask,
  ImageCompositeMasked,
  ImageCrop,
  ImageFlip,
  ImageFromBatch,
  ImageInvert,
  ImageOnlyCheckpointLoader,
  ImageOnlyCheckpointSave,
  ImagePadForOutpaint,
  ImageQuantize,
  ImageRGBToYUV,
  ImageRotate,
  ImageScale,
  ImageScaleBy,
  ImageScaleToMaxDimension,
  ImageScaleToTotalPixels,
  ImageSharpen,
  ImageStitch,
  ImageToMask,
  ImageUpscaleWithModel,
  ImageYUVToRGB,
  InpaintModelConditioning,
  InstructPixToPixConditioning,
  InvertMask,
  JoinImageWithAlpha,
  KSampler,
  KSamplerAdvanced,
  KSamplerSelect,
  KarrasScheduler,
  KlingCameraControlI2VNode,
  KlingCameraControlT2VNode,
  KlingCameraControls,
  KlingDualCharacterVideoEffectNode,
  KlingImage2VideoNode,
  KlingImageGenerationNode,
  KlingLipSyncAudioToVideoNode,
  KlingLipSyncTextToVideoNode,
  KlingSingleImageVideoEffectNode,
  KlingStartEndFrameNode,
  KlingTextToVideoNode,
  KlingVideoExtendNode,
  KlingVirtualTryOnNode,
  LTXVAddGuide,
  LTXVConditioning,
  LTXVCropGuides,
  LTXVImgToVideo,
  LTXVPreprocess,
  LTXVScheduler,
  LaplaceScheduler,
  LatentAdd,
  LatentApplyOperation,
  LatentApplyOperationCFG,
  LatentBatch,
  LatentBatchSeedBehavior,
  LatentBlend,
  LatentComposite,
  LatentCompositeMasked,
  LatentConcat,
  LatentCrop,
  LatentCut,
  LatentFlip,
  LatentFromBatch,
  LatentInterpolate,
  LatentMultiply,
  LatentOperationSharpen,
  LatentOperationTonemapReinhard,
  LatentRotate,
  LatentSubtract,
  LatentUpscale,
  LatentUpscaleBy,
  LazyCache,
  Load3D,
  LoadAudio,
  LoadImage,
  LoadImageMask,
  LoadImageOutput,
  LoadLatent,
  LoadVideo,
  LoraLoader,
  LoraLoaderModelOnly,
  LoraModelLoader,
  LoraSave,
  LossGraphNode,
  LotusConditioning,
  LtxvApiImageToVideo,
  LtxvApiTextToVideo,
  LumaConceptsNode,
  LumaImageModifyNode,
  LumaImageNode,
  LumaImageToVideoNode,
  LumaReferenceNode,
  LumaVideoNode,
  Mahiro,
  MaskComposite,
  MaskPreview,
  MaskToImage,
  MinimaxHailuoVideoNode,
  MinimaxImageToVideoNode,
  MinimaxTextToVideoNode,
  ModelComputeDtype,
  ModelMergeAdd,
  ModelMergeAuraflow,
  ModelMergeBlocks,
  ModelMergeCosmos14B,
  ModelMergeCosmos7B,
  ModelMergeCosmosPredict2_14B,
  ModelMergeCosmosPredict2_2B,
  ModelMergeFlux1,
  ModelMergeLTXV,
  ModelMergeMochiPreview,
  ModelMergeQwenImage,
  ModelMergeSD1,
  ModelMergeSD2,
  ModelMergeSD35_Large,
  ModelMergeSD3_2B,
  ModelMergeSDXL,
  ModelMergeSimple,
  ModelMergeSubtract,
  ModelMergeWAN2_1,
  ModelPatchLoader,
  ModelSamplingAuraFlow,
  ModelSamplingContinuousEDM,
  ModelSamplingContinuousV,
  ModelSamplingDiscrete,
  ModelSamplingFlux,
  ModelSamplingLTXV,
  ModelSamplingSD3,
  ModelSamplingStableCascade,
  ModelSave,
  MoonvalleyImg2VideoNode,
  MoonvalleyTxt2VideoNode,
  MoonvalleyVideo2VideoNode,
  Morphology,
  OpenAIChatConfig,
  OpenAIChatNode,
  OpenAIDalle2,
  OpenAIDalle3,
  OpenAIGPTImage1,
  OpenAIInputFiles,
  OpenAIVideoSora2,
  OptimalStepsScheduler,
  PairConditioningCombine,
  PairConditioningSetDefaultCombine,
  PairConditioningSetProperties,
  PairConditioningSetPropertiesAndCombine,
  PatchModelAddDownscale,
  PerpNeg,
  PerpNegGuider,
  PerturbedAttentionGuidance,
  PhotoMakerEncode,
  PhotoMakerLoader,
  PixverseImageToVideoNode,
  PixverseTemplateNode,
  PixverseTextToVideoNode,
  PixverseTransitionVideoNode,
  PolyexponentialScheduler,
  PorterDuffImageComposite,
  Preview3D,
  PreviewAny,
  PreviewAudio,
  PreviewImage,
  PrimitiveBoolean,
  PrimitiveFloat,
  PrimitiveInt,
  PrimitiveString,
  PrimitiveStringMultiline,
  QuadrupleCLIPLoader,
  QwenImageDiffsynthControlnet,
  RandomNoise,
  RebatchImages,
  RebatchLatents,
  RecordAudio,
  RecraftColorRGB,
  RecraftControls,
  RecraftCreativeUpscaleNode,
  RecraftCrispUpscaleNode,
  RecraftImageInpaintingNode,
  RecraftImageToImageNode,
  RecraftRemoveBackgroundNode,
  RecraftReplaceBackgroundNode,
  RecraftStyleV3DigitalIllustration,
  RecraftStyleV3InfiniteStyleLibrary,
  RecraftStyleV3LogoRaster,
  RecraftStyleV3RealisticImage,
  RecraftTextToImageNode,
  RecraftTextToVectorNode,
  RecraftVectorizeImageNode,
  ReferenceLatent,
  RegexExtract,
  RegexMatch,
  RegexReplace,
  RenormCFG,
  RepeatImageBatch,
  RepeatLatentBatch,
  RescaleCFG,
  ResizeAndPadImage,
  Rodin3D_Detail,
  Rodin3D_Gen2,
  Rodin3D_Regular,
  Rodin3D_Sketch,
  Rodin3D_Smooth,
  RunwayFirstLastFrameNode,
  RunwayImageToVideoNodeGen3a,
  RunwayImageToVideoNodeGen4,
  RunwayTextToImageNode,
  SDTurboScheduler,
  SD_4XUpscale_Conditioning,
  SV3D_Conditioning,
  SVD_img2vid_Conditioning,
  SamplerCustom,
  SamplerCustomAdvanced,
  SamplerDPMAdaptative,
  SamplerDPMPP_2M_SDE,
  SamplerDPMPP_2S_Ancestral,
  SamplerDPMPP_3M_SDE,
  SamplerDPMPP_SDE,
  SamplerER_SDE,
  SamplerEulerAncestral,
  SamplerEulerAncestralCFGPP,
  SamplerEulerCFGpp,
  SamplerLCMUpscale,
  SamplerLMS,
  SamplerSASolver,
  SamplingPercentToSigma,
  SaveAnimatedPNG,
  SaveAnimatedWEBP,
  SaveAudio,
  SaveAudioMP3,
  SaveAudioOpus,
  SaveGLB,
  SaveImage,
  SaveImageWebsocket,
  SaveLatent,
  SaveSVGNode,
  SaveVideo,
  SaveWEBM,
  ScaleROPE,
  SelfAttentionGuidance,
  SetClipHooks,
  SetFirstSigma,
  SetHookKeyframes,
  SetLatentNoiseMask,
  SetUnionControlNetType,
  SkipLayerGuidanceDiT,
  SkipLayerGuidanceDiTSimple,
  SkipLayerGuidanceSD3,
  SolidMask,
  SplitAudioChannels,
  SplitImageWithAlpha,
  SplitSigmas,
  SplitSigmasDenoise,
  StabilityAudioInpaint,
  StabilityAudioToAudio,
  StabilityStableImageSD_3_5Node,
  StabilityStableImageUltraNode,
  StabilityTextToAudio,
  StabilityUpscaleConservativeNode,
  StabilityUpscaleCreativeNode,
  StabilityUpscaleFastNode,
  StableCascade_EmptyLatentImage,
  StableCascade_StageB_Conditioning,
  StableCascade_StageC_VAEEncode,
  StableCascade_SuperResolutionControlnet,
  StableZero123_Conditioning,
  StableZero123_Conditioning_Batched,
  StringCompare,
  StringConcatenate,
  StringContains,
  StringLength,
  StringReplace,
  StringSubstring,
  StringTrim,
  StyleModelApply,
  StyleModelLoader,
  T5TokenizerOptions,
  TCFG,
  TemporalScoreRescaling,
  TextEncodeAceStepAudio,
  TextEncodeHunyuanVideo_ImageToVideo,
  TextEncodeQwenImageEdit,
  TextEncodeQwenImageEditPlus,
  ThresholdMask,
  TomePatchModel,
  TorchCompileModel,
  TrainLoraNode,
  TrimAudioDuration,
  TrimVideoLatent,
  TripleCLIPLoader,
  TripoConversionNode,
  TripoImageToModelNode,
  TripoMultiviewToModelNode,
  TripoRefineNode,
  TripoRetargetNode,
  TripoRigNode,
  TripoTextToModelNode,
  TripoTextureNode,
  UNETLoader,
  UNetCrossAttentionMultiply,
  UNetSelfAttentionMultiply,
  UNetTemporalAttentionMultiply,
  USOStyleReference,
  UpscaleModelLoader,
  VAEDecode,
  VAEDecodeAudio,
  VAEDecodeHunyuan3D,
  VAEDecodeTiled,
  VAEEncode,
  VAEEncodeAudio,
  VAEEncodeForInpaint,
  VAEEncodeTiled,
  VAELoader,
  VAESave,
  VPScheduler,
  Veo3VideoGenerationNode,
  VeoVideoGenerationNode,
  VideoLinearCFGGuidance,
  VideoTriangleCFGGuidance,
  ViduImageToVideoNode,
  ViduReferenceVideoNode,
  ViduStartEndToVideoNode,
  ViduTextToVideoNode,
  VoxelToMesh,
  VoxelToMeshBasic,
  Wan22FunControlToVideo,
  Wan22ImageToVideoLatent,
  WanAnimateToVideo,
  WanCameraEmbedding,
  WanCameraImageToVideo,
  WanContextWindowsManual,
  WanFirstLastFrameToVideo,
  WanFunControlToVideo,
  WanFunInpaintToVideo,
  WanHuMoImageToVideo,
  WanImageToImageApi,
  WanImageToVideo,
  WanImageToVideoApi,
  WanPhantomSubjectToVideo,
  WanSoundImageToVideo,
  WanSoundImageToVideoExtend,
  WanTextToImageApi,
  WanTextToVideoApi,
  WanTrackToVideo,
  WanVaceToVideo,
  WebcamCapture,
  nodeDefs as default,
  unCLIPCheckpointLoader,
  unCLIPConditioning
};
//# sourceMappingURL=nodeDefs-BIckSVgU.js.map
