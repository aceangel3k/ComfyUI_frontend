const APG = { "display_name": "Guidance Adaptatif Projeté", "inputs": { "eta": { "name": "eta", "tooltip": "Contrôle l'échelle du vecteur de guidance parallèle. Comportement CFG par défaut avec un réglage de 1." }, "model": { "name": "modèle" }, "momentum": { "name": "momentum", "tooltip": "Contrôle une moyenne mobile de la guidance pendant la diffusion, désactivé avec un réglage de 0." }, "norm_threshold": { "name": "seuil_norme", "tooltip": "Normalise le vecteur de guidance à cette valeur, la normalisation est désactivée avec un réglage de 0." } }, "outputs": { "0": { "tooltip": null } } };
const AddNoise = { "display_name": "AjouterBruit", "inputs": { "latent_image": { "name": "image_latente" }, "model": { "name": "modèle" }, "noise": { "name": "bruit" }, "sigmas": { "name": "sigmas" } } };
const AlignYourStepsScheduler = { "display_name": "PlanificateurAlignezVosÉtapes", "inputs": { "denoise": { "name": "débruitage" }, "model_type": { "name": "type_de_modèle" }, "steps": { "name": "étapes" } }, "outputs": { "0": { "tooltip": null } } };
const AudioAdjustVolume = { "display_name": "Ajuster le Volume Audio", "inputs": { "audio": { "name": "audio" }, "volume": { "name": "volume", "tooltip": "Ajustement du volume en décibels (dB). 0 = pas de changement, +6 = double, -6 = moitié, etc." } } };
const AudioConcat = { "description": "Concatène l'audio1 à l'audio2 dans la direction spécifiée.", "display_name": "Concaténer Audio", "inputs": { "audio1": { "name": "audio1" }, "audio2": { "name": "audio2" }, "direction": { "name": "direction", "tooltip": "Indique s'il faut ajouter audio2 après ou avant audio1." } } };
const AudioEncoderEncode = { "display_name": "EncodeurAudioEncoder", "inputs": { "audio": { "name": "audio" }, "audio_encoder": { "name": "encodeur_audio" } }, "outputs": { "0": { "tooltip": null } } };
const AudioEncoderLoader = { "display_name": "ChargeurEncodeurAudio", "inputs": { "audio_encoder_name": { "name": "nom_encodeur_audio" } }, "outputs": { "0": { "tooltip": null } } };
const AudioMerge = { "description": "Combine deux pistes audio en superposant leurs formes d'onde.", "display_name": "Fusion Audio", "inputs": { "audio1": { "name": "audio1" }, "audio2": { "name": "audio2" }, "merge_method": { "name": "méthode_fusion", "tooltip": "La méthode utilisée pour combiner les formes d'onde audio." } } };
const BasicGuider = { "display_name": "GuideBasique", "inputs": { "conditioning": { "name": "conditionnement" }, "model": { "name": "modèle" } } };
const BasicScheduler = { "display_name": "PlanificateurBasique", "inputs": { "denoise": { "name": "débruitage" }, "model": { "name": "modèle" }, "scheduler": { "name": "planificateur" }, "steps": { "name": "étapes" } } };
const BetaSamplingScheduler = { "display_name": "PlanificateurÉchantillonnageBeta", "inputs": { "alpha": { "name": "alpha" }, "beta": { "name": "beta" }, "model": { "name": "modèle" }, "steps": { "name": "étapes" } } };
const ByteDanceFirstLastFrameNode = { "description": "Générer une vidéo en utilisant l'invite et les première et dernière images.", "display_name": "ByteDance Première-Dernière Image vers Vidéo", "inputs": { "aspect_ratio": { "name": "ratio_d'aspect", "tooltip": "Le ratio d'aspect de la vidéo de sortie." }, "camera_fixed": { "name": "camera_fixed", "tooltip": "Spécifie si la caméra doit être fixe. L'application ajoute une instruction pour fixer la caméra à votre prompt, mais ne garantit pas l'effet réel." }, "control_after_generate": { "name": "control after generate" }, "duration": { "name": "durée", "tooltip": "La durée de la vidéo de sortie en secondes." }, "first_frame": { "name": "première_image", "tooltip": "Première image à utiliser pour la vidéo." }, "last_frame": { "name": "dernière_image", "tooltip": "Dernière image à utiliser pour la vidéo." }, "model": { "name": "modèle" }, "prompt": { "name": "invite", "tooltip": "L'invite textuelle utilisée pour générer la vidéo." }, "resolution": { "name": "résolution", "tooltip": "La résolution de la vidéo de sortie." }, "seed": { "name": "graine", "tooltip": "Graine à utiliser pour la génération." }, "watermark": { "name": "watermark", "tooltip": `Indique s'il faut ajouter un filigrane "Généré par IA" à la vidéo.` } }, "outputs": { "0": { "tooltip": null } } };
const ByteDanceImageEditNode = { "description": "Modifier des images en utilisant les modèles ByteDance via l'API basée sur le prompt", "display_name": "Édition d'image ByteDance", "inputs": { "control_after_generate": { "name": "control after generate" }, "guidance_scale": { "name": "guidance_scale", "tooltip": "Une valeur plus élevée fait que l'image suit plus fidèlement le prompt" }, "image": { "name": "image", "tooltip": "L'image de base à modifier" }, "model": { "name": "model" }, "prompt": { "name": "prompt", "tooltip": "Instruction pour modifier l'image" }, "seed": { "name": "seed", "tooltip": "Graine à utiliser pour la génération." }, "watermark": { "name": "watermark", "tooltip": `Indique s'il faut ajouter un filigrane "Généré par IA" à l'image` } }, "outputs": { "0": { "tooltip": null } } };
const ByteDanceImageNode = { "description": "Générer des images en utilisant les modèles ByteDance via l'API basée sur le prompt", "display_name": "Image ByteDance", "inputs": { "control_after_generate": { "name": "control after generate" }, "guidance_scale": { "name": "guidance_scale", "tooltip": "Une valeur plus élevée fait que l'image suit plus fidèlement le prompt" }, "height": { "name": "height", "tooltip": "Hauteur personnalisée pour l'image. La valeur fonctionne uniquement si `size_preset` est défini sur `Personnalisé`" }, "model": { "name": "model" }, "prompt": { "name": "prompt", "tooltip": "Le prompt texte utilisé pour générer l'image" }, "seed": { "name": "seed", "tooltip": "Graine à utiliser pour la génération." }, "size_preset": { "name": "size_preset", "tooltip": "Choisir une taille recommandée. Sélectionnez Personnalisé pour utiliser la largeur et la hauteur ci-dessous" }, "watermark": { "name": "watermark", "tooltip": `Indique s'il faut ajouter un filigrane "Généré par IA" à l'image` }, "width": { "name": "width", "tooltip": "Largeur personnalisée pour l'image. La valeur fonctionne uniquement si `size_preset` est défini sur `Personnalisé`" } }, "outputs": { "0": { "tooltip": null } } };
const ByteDanceImageReferenceNode = { "description": "Générer une vidéo en utilisant un prompt et des images de référence.", "display_name": "ByteDance Images de référence en vidéo", "inputs": { "aspect_ratio": { "name": "ratio_d'aspect", "tooltip": "Le ratio d'aspect de la vidéo en sortie." }, "control_after_generate": { "name": "contrôle après génération" }, "duration": { "name": "durée", "tooltip": "La durée de la vidéo en sortie en secondes." }, "images": { "name": "images", "tooltip": "Une à quatre images." }, "model": { "name": "modèle" }, "prompt": { "name": "prompt", "tooltip": "Le prompt textuel utilisé pour générer la vidéo." }, "resolution": { "name": "résolution", "tooltip": "La résolution de la vidéo en sortie." }, "seed": { "name": "graine", "tooltip": "Graine à utiliser pour la génération." }, "watermark": { "name": "filigrane", "tooltip": `Indique s'il faut ajouter un filigrane "Généré par IA" à la vidéo.` } }, "outputs": { "0": { "tooltip": null } } };
const ByteDanceImageToVideoNode = { "description": "Générer une vidéo en utilisant les modèles ByteDance via l'API basée sur l'image et le prompt", "display_name": "ByteDance Image en vidéo", "inputs": { "aspect_ratio": { "name": "ratio_d'aspect", "tooltip": "Le ratio d'aspect de la vidéo en sortie." }, "camera_fixed": { "name": "caméra_fixe", "tooltip": "Spécifie s'il faut fixer la caméra. La plateforme ajoute une instruction pour fixer la caméra à votre prompt, mais ne garantit pas l'effet réel." }, "control_after_generate": { "name": "contrôle après génération" }, "duration": { "name": "durée", "tooltip": "La durée de la vidéo en sortie en secondes." }, "image": { "name": "image", "tooltip": "Première image à utiliser pour la vidéo." }, "model": { "name": "modèle" }, "prompt": { "name": "prompt", "tooltip": "Le prompt textuel utilisé pour générer la vidéo." }, "resolution": { "name": "résolution", "tooltip": "La résolution de la vidéo en sortie." }, "seed": { "name": "graine", "tooltip": "Graine à utiliser pour la génération." }, "watermark": { "name": "filigrane", "tooltip": `Indique s'il faut ajouter un filigrane "Généré par IA" à la vidéo.` } }, "outputs": { "0": { "tooltip": null } } };
const ByteDanceSeedreamNode = { "description": "Génération unifiée de texte à image et édition précise phrase par phrase jusqu'à une résolution 4K.", "display_name": "ByteDance Seedream 4", "inputs": { "control_after_generate": { "name": "control after generate" }, "fail_on_partial": { "name": "fail_on_partial", "tooltip": "Si activé, interrompt l'exécution si des images demandées sont manquantes ou renvoient une erreur." }, "height": { "name": "height", "tooltip": "Hauteur personnalisée pour l'image. La valeur fonctionne uniquement si `size_preset` est défini sur `Personnalisé`" }, "image": { "name": "image", "tooltip": "Image(s) d'entrée pour la génération d'image à image. Liste de 1 à 10 images pour une génération à référence unique ou multiple." }, "max_images": { "name": "max_images", "tooltip": "Nombre maximum d'images à générer lorsque sequential_image_generation='auto'. Le nombre total d'images (entrée + générées) ne peut pas dépasser 15." }, "model": { "name": "model", "tooltip": "Nom du modèle" }, "prompt": { "name": "prompt", "tooltip": "Invite de texte pour créer ou modifier une image." }, "seed": { "name": "seed", "tooltip": "Graine à utiliser pour la génération." }, "sequential_image_generation": { "name": "sequential_image_generation", "tooltip": "Mode de génération d'images groupées. 'désactivé' génère une seule image. 'auto' laisse le modèle décider s'il faut générer plusieurs images liées (par exemple, scènes d'histoire, variations de personnages)." }, "size_preset": { "name": "size_preset", "tooltip": "Choisissez une taille recommandée. Sélectionnez Personnalisé pour utiliser la largeur et la hauteur ci-dessous." }, "watermark": { "name": "watermark", "tooltip": `Indique s'il faut ajouter un filigrane "Généré par IA" à l'image.` }, "width": { "name": "width", "tooltip": "Largeur personnalisée pour l'image. La valeur fonctionne uniquement si `size_preset` est défini sur `Personnalisé`" } }, "outputs": { "0": { "tooltip": null } } };
const ByteDanceTextToVideoNode = { "description": "Générer une vidéo en utilisant les modèles ByteDance via l'API basée sur l'invite", "display_name": "ByteDance Texte vers Vidéo", "inputs": { "aspect_ratio": { "name": "aspect_ratio", "tooltip": "Le rapport d'aspect de la vidéo de sortie." }, "camera_fixed": { "name": "camera_fixed", "tooltip": "Spécifie si la caméra doit être fixée. L'application ajoute une instruction pour fixer la caméra à votre prompt, mais ne garantit pas l'effet réel." }, "control_after_generate": { "name": "contrôle après génération" }, "duration": { "name": "duration", "tooltip": "La durée de la vidéo de sortie en secondes." }, "model": { "name": "model" }, "prompt": { "name": "prompt", "tooltip": "L'invite de texte utilisée pour générer la vidéo." }, "resolution": { "name": "resolution", "tooltip": "La résolution de la vidéo de sortie." }, "seed": { "name": "seed", "tooltip": "Graine à utiliser pour la génération." }, "watermark": { "name": "filigrane", "tooltip": `Indique s'il faut ajouter un filigrane "Généré par IA" à la vidéo.` } }, "outputs": { "0": { "tooltip": null } } };
const CFGGuider = { "display_name": "GuideCFG", "inputs": { "cfg": { "name": "cfg" }, "model": { "name": "modèle" }, "negative": { "name": "négative" }, "positive": { "name": "positive" } } };
const CFGNorm = { "display_name": "CFGNorm", "inputs": { "model": { "name": "modèle" }, "strength": { "name": "intensité" } }, "outputs": { "0": { "name": "modèle_patché", "tooltip": null } } };
const CFGZeroStar = { "display_name": "CFGZeroStar", "inputs": { "model": { "name": "modèle" } }, "outputs": { "0": { "name": "modèle corrigé", "tooltip": null } } };
const CLIPAttentionMultiply = { "display_name": "MultiplierAttentionCLIP", "inputs": { "clip": { "name": "clip" }, "k": { "name": "k" }, "out": { "name": "sortie" }, "q": { "name": "q" }, "v": { "name": "v" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPLoader = { "description": "[Recettes]\n\nstable_diffusion: clip-l\nstable_cascade: clip-g\nsd3: t5 / clip-g / clip-l\nstable_audio: t5\nmochi: t5\ncosmos: old t5 xxl", "display_name": "Charger CLIP", "inputs": { "clip_name": { "name": "clip_name" }, "device": { "name": "appareil" }, "type": { "name": "type" } } };
const CLIPMergeAdd = { "display_name": "CLIPMergeAdd", "inputs": { "clip1": { "name": "clip1" }, "clip2": { "name": "clip2" } } };
const CLIPMergeSimple = { "display_name": "CLIPMergeSimple", "inputs": { "clip1": { "name": "clip1" }, "clip2": { "name": "clip2" }, "ratio": { "name": "ratio" } } };
const CLIPMergeSubtract = { "display_name": "CLIPMergeSubtract", "inputs": { "clip1": { "name": "clip1" }, "clip2": { "name": "clip2" }, "multiplier": { "name": "multiplier" } } };
const CLIPSave = { "display_name": "CLIPSave", "inputs": { "clip": { "name": "clip" }, "filename_prefix": { "name": "filename_prefix" } } };
const CLIPSetLastLayer = { "display_name": "CLIP Définir Dernière Couche", "inputs": { "clip": { "name": "clip" }, "stop_at_clip_layer": { "name": "stop_at_clip_layer" } } };
const CLIPTextEncode = { "description": "Encode une invite de texte à l'aide d'un modèle CLIP en une intégration qui peut être utilisée pour guider le modèle de diffusion vers la génération d'images spécifiques.", "display_name": "CLIP Text Encode (Prompt)", "inputs": { "clip": { "name": "clip", "tooltip": "Le modèle CLIP utilisé pour encoder le texte." }, "text": { "name": "text", "tooltip": "Le texte à encoder." } }, "outputs": { "0": { "tooltip": "Une condition contenant le texte intégré utilisé pour guider le modèle de diffusion." } } };
const CLIPTextEncodeControlnet = { "display_name": "CLIPTextEncodeControlnet", "inputs": { "clip": { "name": "clip" }, "conditioning": { "name": "conditioning" }, "text": { "name": "text" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeFlux = { "display_name": "CLIPTextEncodeFlux", "inputs": { "clip": { "name": "clip" }, "clip_l": { "name": "clip_l" }, "guidance": { "name": "guidance" }, "t5xxl": { "name": "t5xxl" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeHiDream = { "display_name": "CLIPTextEncodeHiDream", "inputs": { "clip": { "name": "clip" }, "clip_g": { "name": "clip_g" }, "clip_l": { "name": "clip_l" }, "llama": { "name": "llama" }, "t5xxl": { "name": "t5xxl" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeHunyuanDiT = { "display_name": "CLIPTextEncodeHunyuanDiT", "inputs": { "bert": { "name": "bert" }, "clip": { "name": "clip" }, "mt5xl": { "name": "mt5xl" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeLumina2 = { "description": "Encode une invite système et une invite utilisateur à l'aide d'un modèle CLIP en une intégration qui peut être utilisée pour guider le modèle de diffusion vers la génération d'images spécifiques.", "display_name": "CLIP Text Encode pour Lumina2", "inputs": { "clip": { "name": "clip", "tooltip": "Le modèle CLIP utilisé pour encoder le texte." }, "system_prompt": { "name": "system_prompt", "tooltip": "Lumina2 propose deux types d'invites système : Supérieur : Vous êtes un assistant conçu pour générer des images supérieures avec le degré supérieur d'alignement image-texte basé sur des invites textuelles ou des invites utilisateur. Alignement : Vous êtes un assistant conçu pour générer des images de haute qualité avec le plus haut degré d'alignement image-texte basé sur des invites textuelles." }, "user_prompt": { "name": "user_prompt", "tooltip": "Le texte à encoder." } }, "outputs": { "0": { "tooltip": "Une condition contenant le texte intégré utilisé pour guider le modèle de diffusion." } } };
const CLIPTextEncodePixArtAlpha = { "description": "Encode le texte et définit la condition de résolution pour PixArt Alpha. Ne s'applique pas à PixArt Sigma.", "display_name": "CLIPTextEncodePixArtAlpha", "inputs": { "clip": { "name": "clip" }, "height": { "name": "height" }, "text": { "name": "text" }, "width": { "name": "width" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeSD3 = { "display_name": "CLIPTextEncodeSD3", "inputs": { "clip": { "name": "clip" }, "clip_g": { "name": "clip_g" }, "clip_l": { "name": "clip_l" }, "empty_padding": { "name": "remplissage_vide" }, "t5xxl": { "name": "t5xxl" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeSDXL = { "display_name": "CLIPTextEncodeSDXL", "inputs": { "clip": { "name": "clip" }, "crop_h": { "name": "crop_h" }, "crop_w": { "name": "crop_w" }, "height": { "name": "hauteur" }, "target_height": { "name": "hauteur_cible" }, "target_width": { "name": "largeur_cible" }, "text_g": { "name": "text_g" }, "text_l": { "name": "text_l" }, "width": { "name": "largeur" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeSDXLRefiner = { "display_name": "CLIPTextEncodeSDXLRefiner", "inputs": { "ascore": { "name": "ascore" }, "clip": { "name": "clip" }, "height": { "name": "hauteur" }, "text": { "name": "texte" }, "width": { "name": "largeur" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPVisionEncode = { "display_name": "CLIP Vision Encode", "inputs": { "clip_vision": { "name": "clip_vision" }, "crop": { "name": "crop" }, "image": { "name": "image" } } };
const CLIPVisionLoader = { "display_name": "Charger CLIP Vision", "inputs": { "clip_name": { "name": "nom_clip" } } };
const Canny = { "display_name": "Canny", "inputs": { "high_threshold": { "name": "seuil_haut" }, "image": { "name": "image" }, "low_threshold": { "name": "seuil_bas" } }, "outputs": { "0": { "tooltip": null } } };
const CaseConverter = { "display_name": "Convertisseur de casse", "inputs": { "mode": { "name": "mode" }, "string": { "name": "chaîne" } }, "outputs": { "0": { "tooltip": null } } };
const CheckpointLoader = { "display_name": "Charger Point de Contrôle Avec Config (OBSOLÈTE)", "inputs": { "ckpt_name": { "name": "nom_ckpt" }, "config_name": { "name": "nom_config" } } };
const CheckpointLoaderSimple = { "description": "Charge un point de contrôle de modèle de diffusion, les modèles de diffusion sont utilisés pour débruiter les latents.", "display_name": "Charger Point de Contrôle", "inputs": { "ckpt_name": { "name": "nom_ckpt", "tooltip": "Le nom du point de contrôle (modèle) à charger." } }, "outputs": { "0": { "tooltip": "Le modèle utilisé pour débruiter les latents." }, "1": { "tooltip": "Le modèle CLIP utilisé pour encoder les invites de texte." }, "2": { "tooltip": "Le modèle VAE utilisé pour encoder et décoder les images en espace latent et vice versa." } } };
const CheckpointSave = { "display_name": "Sauvegarder Point de Contrôle", "inputs": { "clip": { "name": "clip" }, "filename_prefix": { "name": "préfixe_nom_fichier" }, "model": { "name": "modèle" }, "vae": { "name": "vae" } } };
const ChromaRadianceOptions = { "description": "Permet de définir des options avancées pour le modèle Chroma Radiance.", "display_name": "OptionsChromaRadiance", "inputs": { "end_sigma": { "name": "sigma_fin", "tooltip": "Dernier sigma pour lequel ces options seront actives." }, "model": { "name": "modèle" }, "nerf_tile_size": { "name": "taille_tuile_nerf", "tooltip": "Permet de remplacer la taille de tuile NeRF par défaut. -1 signifie utiliser la valeur par défaut (32). 0 signifie utiliser le mode sans tuilage (peut nécessiter beaucoup de VRAM)." }, "preserve_wrapper": { "name": "préserver_wrapper", "tooltip": "Lorsqu'activé, délègue à un wrapper de fonction de modèle existant s'il existe. Doit généralement rester activé." }, "start_sigma": { "name": "sigma_début", "tooltip": "Premier sigma pour lequel ces options seront actives." } }, "outputs": { "0": { "tooltip": null } } };
const CombineHooks2 = { "display_name": "Combiner Hooks [2]", "inputs": { "hooks_A": { "name": "hooks_A" }, "hooks_B": { "name": "hooks_B" } } };
const CombineHooks4 = { "display_name": "Combiner Hooks [4]", "inputs": { "hooks_A": { "name": "hooks_A" }, "hooks_B": { "name": "hooks_B" }, "hooks_C": { "name": "hooks_C" }, "hooks_D": { "name": "hooks_D" } } };
const CombineHooks8 = { "display_name": "Combiner Hooks [8]", "inputs": { "hooks_A": { "name": "hooks_A" }, "hooks_B": { "name": "hooks_B" }, "hooks_C": { "name": "hooks_C" }, "hooks_D": { "name": "hooks_D" }, "hooks_E": { "name": "hooks_E" }, "hooks_F": { "name": "hooks_F" }, "hooks_G": { "name": "hooks_G" }, "hooks_H": { "name": "hooks_H" } } };
const ConditioningAverage = { "display_name": "Moyenne de Conditionnement", "inputs": { "conditioning_from": { "name": "conditionnement_de" }, "conditioning_to": { "name": "conditionnement_à" }, "conditioning_to_strength": { "name": "force_conditionnement_à" } } };
const ConditioningCombine = { "display_name": "Conditionnement (Combiner)", "inputs": { "conditioning_1": { "name": "conditionnement_1" }, "conditioning_2": { "name": "conditionnement_2" } } };
const ConditioningConcat = { "display_name": "Conditionnement (Concat)", "inputs": { "conditioning_from": { "name": "conditionnement_de" }, "conditioning_to": { "name": "conditionnement_vers" } } };
const ConditioningSetArea = { "display_name": "Conditionnement (Définir Zone)", "inputs": { "conditioning": { "name": "conditionnement" }, "height": { "name": "hauteur" }, "strength": { "name": "force" }, "width": { "name": "largeur" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const ConditioningSetAreaPercentage = { "display_name": "Conditionnement (Définir Zone avec Pourcentage)", "inputs": { "conditioning": { "name": "conditionnement" }, "height": { "name": "hauteur" }, "strength": { "name": "force" }, "width": { "name": "largeur" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const ConditioningSetAreaPercentageVideo = { "display_name": "Pourcentage de la zone de conditionnement vidéo", "inputs": { "conditioning": { "name": "conditionnement" }, "height": { "name": "hauteur" }, "strength": { "name": "force" }, "temporal": { "name": "temporel" }, "width": { "name": "largeur" }, "x": { "name": "x" }, "y": { "name": "y" }, "z": { "name": "z" } } };
const ConditioningSetAreaStrength = { "display_name": "ConditionnementDéfinirForceZone", "inputs": { "conditioning": { "name": "conditionnement" }, "strength": { "name": "force" } } };
const ConditioningSetDefaultCombine = { "display_name": "Cond Définir Combinaison par Défaut", "inputs": { "cond": { "name": "cond" }, "cond_DEFAULT": { "name": "cond_DEFAULT" }, "hooks": { "name": "hooks" } } };
const ConditioningSetMask = { "display_name": "Conditionnement (Définir Masque)", "inputs": { "conditioning": { "name": "conditionnement" }, "mask": { "name": "masque" }, "set_cond_area": { "name": "définir_zone_cond" }, "strength": { "name": "force" } } };
const ConditioningSetProperties = { "display_name": "Cond Définir Propriétés", "inputs": { "cond_NEW": { "name": "cond_NOUVEAU" }, "hooks": { "name": "hooks" }, "mask": { "name": "masque" }, "set_cond_area": { "name": "définir_zone_cond" }, "strength": { "name": "force" }, "timesteps": { "name": "pas_de_temps" } } };
const ConditioningSetPropertiesAndCombine = { "display_name": "Cond Définir Propriétés Combinaison", "inputs": { "cond": { "name": "cond" }, "cond_NEW": { "name": "cond_NOUVEAU" }, "hooks": { "name": "hooks" }, "mask": { "name": "masque" }, "set_cond_area": { "name": "définir_zone_cond" }, "strength": { "name": "force" }, "timesteps": { "name": "pas_de_temps" } } };
const ConditioningSetTimestepRange = { "display_name": "ConditionnementDéfinirPlagePasDeTemps", "inputs": { "conditioning": { "name": "conditionnement" }, "end": { "name": "fin" }, "start": { "name": "début" } } };
const ConditioningStableAudio = { "display_name": "ConditionnementStableAudio", "inputs": { "negative": { "name": "négative" }, "positive": { "name": "positive" }, "seconds_start": { "name": "secondes_début" }, "seconds_total": { "name": "secondes_total" } }, "outputs": { "0": { "name": "positive" }, "1": { "name": "négative" } } };
const ConditioningTimestepsRange = { "display_name": "Plage de pas de temps", "inputs": { "end_percent": { "name": "end_percent" }, "start_percent": { "name": "start_percent" } }, "outputs": { "1": { "name": "AVANT_PLAGE" }, "2": { "name": "APRÈS_PLAGE" } } };
const ConditioningZeroOut = { "display_name": "ConditioningZeroOut", "inputs": { "conditioning": { "name": "conditioning" } } };
const ContextWindowsManual = { "description": "Définir manuellement les fenêtres de contexte.", "display_name": "Fenêtres de contexte (Manuel)", "inputs": { "closed_loop": { "name": "boucle_fermée", "tooltip": "Indique s'il faut fermer la boucle de la fenêtre de contexte ; applicable uniquement aux planifications en boucle." }, "context_length": { "name": "longueur_contexte", "tooltip": "La longueur de la fenêtre de contexte." }, "context_overlap": { "name": "chevauchement_contexte", "tooltip": "Le chevauchement de la fenêtre de contexte." }, "context_schedule": { "name": "planification_contexte", "tooltip": "La progression de la fenêtre de contexte." }, "context_stride": { "name": "pas_contexte", "tooltip": "Le pas de la fenêtre de contexte ; applicable uniquement aux planifications uniformes." }, "dim": { "name": "dimension", "tooltip": "La dimension à laquelle appliquer les fenêtres de contexte." }, "fuse_method": { "name": "méthode_fusion", "tooltip": "La méthode à utiliser pour fusionner les fenêtres de contexte." }, "model": { "name": "modèle", "tooltip": "Le modèle auquel appliquer les fenêtres de contexte pendant l'échantillonnage." } }, "outputs": { "0": { "tooltip": "Le modèle avec des fenêtres contextuelles appliquées pendant l'échantillonnage." } } };
const ControlNetApply = { "display_name": "Appliquer ControlNet (ANCIEN)", "inputs": { "conditioning": { "name": "conditioning" }, "control_net": { "name": "control_net" }, "image": { "name": "image" }, "strength": { "name": "strength" } } };
const ControlNetApplyAdvanced = { "display_name": "Appliquer ControlNet", "inputs": { "control_net": { "name": "control_net" }, "end_percent": { "name": "end_percent" }, "image": { "name": "image" }, "negative": { "name": "negative" }, "positive": { "name": "positive" }, "start_percent": { "name": "start_percent" }, "strength": { "name": "strength" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "positive" }, "1": { "name": "negative" } } };
const ControlNetApplySD3 = { "display_name": "Appliquer Controlnet avec VAE", "inputs": { "control_net": { "name": "control_net" }, "end_percent": { "name": "end_percent" }, "image": { "name": "image" }, "negative": { "name": "negative" }, "positive": { "name": "positive" }, "start_percent": { "name": "start_percent" }, "strength": { "name": "strength" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "positive", "tooltip": null }, "1": { "name": "negative", "tooltip": null } } };
const ControlNetInpaintingAliMamaApply = { "display_name": "ControlNetInpaintingAliMamaApply", "inputs": { "control_net": { "name": "control_net" }, "end_percent": { "name": "end_percent" }, "image": { "name": "image" }, "mask": { "name": "mask" }, "negative": { "name": "negative" }, "positive": { "name": "positive" }, "start_percent": { "name": "start_percent" }, "strength": { "name": "strength" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "positive", "tooltip": null }, "1": { "name": "negative", "tooltip": null } } };
const ControlNetLoader = { "display_name": "Charger le modèle ControlNet", "inputs": { "control_net_name": { "name": "control_net_name" } } };
const CosmosImageToVideoLatent = { "display_name": "CosmosImageVersVidéoLatent", "inputs": { "batch_size": { "name": "taille_du_lot" }, "end_image": { "name": "image_de_fin" }, "height": { "name": "hauteur" }, "length": { "name": "longueur" }, "start_image": { "name": "image_de_départ" }, "vae": { "name": "vae" }, "width": { "name": "largeur" } }, "outputs": { "0": { "tooltip": null } } };
const CosmosPredict2ImageToVideoLatent = { "display_name": "CosmosPredict2ImageToVideoLatent", "inputs": { "batch_size": { "name": "taille_du_lot" }, "end_image": { "name": "image_de_fin" }, "height": { "name": "hauteur" }, "length": { "name": "longueur" }, "start_image": { "name": "image_de_départ" }, "vae": { "name": "vae" }, "width": { "name": "largeur" } }, "outputs": { "0": { "tooltip": null } } };
const CreateHookKeyframe = { "display_name": "Créer une image clé de crochet", "inputs": { "prev_hook_kf": { "name": "prev_hook_kf" }, "start_percent": { "name": "start_percent" }, "strength_mult": { "name": "strength_mult" } }, "outputs": { "0": { "name": "HOOK_KF" } } };
const CreateHookKeyframesFromFloats = { "display_name": "Créer des images clés de crochet à partir de flottants", "inputs": { "end_percent": { "name": "pourcentage_fin" }, "floats_strength": { "name": "force_flottants" }, "prev_hook_kf": { "name": "precedent_crochet_kf" }, "print_keyframes": { "name": "imprimer_images_cles" }, "start_percent": { "name": "pourcentage_debut" } }, "outputs": { "0": { "name": "CROCHET_KF" } } };
const CreateHookKeyframesInterpolated = { "display_name": "Créer des images clés de crochet interpolées.", "inputs": { "end_percent": { "name": "pourcentage_fin" }, "interpolation": { "name": "interpolation" }, "keyframes_count": { "name": "compte_images_cles" }, "prev_hook_kf": { "name": "precedent_crochet_kf" }, "print_keyframes": { "name": "imprimer_images_cles" }, "start_percent": { "name": "pourcentage_debut" }, "strength_end": { "name": "force_fin" }, "strength_start": { "name": "force_debut" } }, "outputs": { "0": { "name": "CROCHET_KF" } } };
const CreateHookLora = { "display_name": "Créer un crochet LoRA", "inputs": { "lora_name": { "name": "nom_lora" }, "prev_hooks": { "name": "crochets_precedents" }, "strength_clip": { "name": "force_clip" }, "strength_model": { "name": "force_modele" } } };
const CreateHookLoraModelOnly = { "display_name": "Créer un crochet LoRA (MO)", "inputs": { "lora_name": { "name": "nom_lora" }, "prev_hooks": { "name": "crochets_precedents" }, "strength_model": { "name": "force_modele" } } };
const CreateHookModelAsLora = { "display_name": "Créer un modèle de crochet comme LoRA", "inputs": { "ckpt_name": { "name": "nom_ckpt" }, "prev_hooks": { "name": "crochets_precedents" }, "strength_clip": { "name": "force_clip" }, "strength_model": { "name": "force_modele" } } };
const CreateHookModelAsLoraModelOnly = { "display_name": "Créer un modèle de crochet comme LoRA (MO)", "inputs": { "ckpt_name": { "name": "nom_ckpt" }, "prev_hooks": { "name": "crochets_precedents" }, "strength_model": { "name": "force_modele" } } };
const CreateVideo = { "description": "Créer une vidéo à partir d’images.", "display_name": "Créer une vidéo", "inputs": { "audio": { "name": "audio", "tooltip": "L’audio à ajouter à la vidéo." }, "fps": { "name": "fps" }, "images": { "name": "images", "tooltip": "Les images à utiliser pour créer une vidéo." } }, "outputs": { "0": { "tooltip": null } } };
const CropMask = { "display_name": "CropMask", "inputs": { "height": { "name": "hauteur" }, "mask": { "name": "masque" }, "width": { "name": "largeur" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const DiffControlNetLoader = { "display_name": "Charger le modèle ControlNet (diff)", "inputs": { "control_net_name": { "name": "nom_control_net" }, "model": { "name": "modèle" } } };
const DifferentialDiffusion = { "display_name": "Diffusion différentielle", "inputs": { "model": { "name": "modèle" }, "strength": { "name": "intensité" } }, "outputs": { "0": { "tooltip": null } } };
const DiffusersLoader = { "display_name": "Chargeur de diffuseurs", "inputs": { "model_path": { "name": "chemin_modèle" } } };
const DisableNoise = { "display_name": "DésactiverBruit" };
const DualCFGGuider = { "display_name": "GuideurDualCFG", "inputs": { "cfg_cond2_negative": { "name": "cfg_cond2_négatif" }, "cfg_conds": { "name": "cfg_conds" }, "cond1": { "name": "cond1" }, "cond2": { "name": "cond2" }, "model": { "name": "modèle" }, "negative": { "name": "négatif" }, "style": { "name": "style" } } };
const DualCLIPLoader = { "description": "[Recettes]\n\nsdxl: clip-l, clip-g\nsd3: clip-l, clip-g / clip-l, t5 / clip-g, t5\nflux: clip-l, t5", "display_name": "ChargeurDualCLIP", "inputs": { "clip_name1": { "name": "nom_clip1" }, "clip_name2": { "name": "nom_clip2" }, "device": { "name": "appareil" }, "type": { "name": "type" } } };
const EasyCache = { "description": "Implémentation native d'EasyCache.", "display_name": "EasyCache", "inputs": { "end_percent": { "name": "pourcentage_de_fin", "tooltip": "L'étape d'échantillonnage relative pour terminer l'utilisation d'EasyCache." }, "model": { "name": "modèle", "tooltip": "Le modèle auquel ajouter EasyCache." }, "reuse_threshold": { "name": "seuil_de_réutilisation", "tooltip": "Le seuil pour réutiliser les étapes mises en cache." }, "start_percent": { "name": "pourcentage_de_départ", "tooltip": "L'étape d'échantillonnage relative pour commencer l'utilisation d'EasyCache." }, "verbose": { "name": "verbeux", "tooltip": "Indique s'il faut enregistrer des informations détaillées." } }, "outputs": { "0": { "tooltip": "Le modèle avec EasyCache." } } };
const EmptyAceStepLatentAudio = { "display_name": "EmptyAceStepLatentAudio", "inputs": { "batch_size": { "name": "taille_du_lot", "tooltip": "Le nombre d'images latentes dans le lot." }, "seconds": { "name": "secondes" } }, "outputs": { "0": { "tooltip": null } } };
const EmptyAudio = { "display_name": "Audio vide", "inputs": { "channels": { "name": "canaux", "tooltip": "Nombre de canaux audio (1 pour mono, 2 pour stéréo)." }, "duration": { "name": "durée", "tooltip": "Durée du clip audio vide en secondes" }, "sample_rate": { "name": "fréquence_d'échantillonnage", "tooltip": "Fréquence d'échantillonnage du clip audio vide." } } };
const EmptyChromaRadianceLatentImage = { "display_name": "EmptyChromaRadianceLatentImage", "inputs": { "batch_size": { "name": "taille_du_lot" }, "height": { "name": "hauteur" }, "width": { "name": "largeur" } }, "outputs": { "0": { "tooltip": null } } };
const EmptyCosmosLatentVideo = { "display_name": "VidéoLatenteCosmosVide", "inputs": { "batch_size": { "name": "taille_du_lot" }, "height": { "name": "hauteur" }, "length": { "name": "longueur" }, "width": { "name": "largeur" } }, "outputs": { "0": { "tooltip": null } } };
const EmptyHunyuanImageLatent = { "display_name": "EmptyHunyuanImageLatent", "inputs": { "batch_size": { "name": "taille_du_lot" }, "height": { "name": "hauteur" }, "width": { "name": "largeur" } }, "outputs": { "0": { "tooltip": null } } };
const EmptyHunyuanLatentVideo = { "display_name": "EmptyHunyuanLatentVideo", "inputs": { "batch_size": { "name": "taille_du_lot" }, "height": { "name": "hauteur" }, "length": { "name": "longueur" }, "width": { "name": "largeur" } }, "outputs": { "0": { "tooltip": null } } };
const EmptyImage = { "display_name": "ImageVide", "inputs": { "batch_size": { "name": "taille_du_lot" }, "color": { "name": "couleur" }, "height": { "name": "hauteur" }, "width": { "name": "largeur" } } };
const EmptyLTXVLatentVideo = { "display_name": "EmptyLTXVLatentVideo", "inputs": { "batch_size": { "name": "taille_du_lot" }, "height": { "name": "hauteur" }, "length": { "name": "longueur" }, "width": { "name": "largeur" } }, "outputs": { "0": { "tooltip": null } } };
const EmptyLatentAudio = { "display_name": "AudioLatentVide", "inputs": { "batch_size": { "name": "taille_du_lot", "tooltip": "Le nombre d'images latentes dans le lot." }, "seconds": { "name": "secondes" } } };
const EmptyLatentHunyuan3Dv2 = { "display_name": "EmptyLatentHunyuan3Dv2", "inputs": { "batch_size": { "name": "taille_du_lot", "tooltip": "Le nombre d'images latentes dans le lot." }, "resolution": { "name": "résolution" } } };
const EmptyLatentImage = { "description": "Créez un nouveau lot d'images latentes vides à débruiter via l'échantillonnage.", "display_name": "Image Latente Vide", "inputs": { "batch_size": { "name": "taille_du_lot", "tooltip": "Le nombre d'images latentes dans le lot." }, "height": { "name": "hauteur", "tooltip": "La hauteur des images latentes en pixels." }, "width": { "name": "largeur", "tooltip": "La largeur des images latentes en pixels." } }, "outputs": { "0": { "tooltip": "Le lot d'images latentes vides." } } };
const EmptyMochiLatentVideo = { "display_name": "EmptyMochiLatentVideo", "inputs": { "batch_size": { "name": "taille_du_lot" }, "height": { "name": "hauteur" }, "length": { "name": "longueur" }, "width": { "name": "largeur" } }, "outputs": { "0": { "tooltip": null } } };
const EmptySD3LatentImage = { "display_name": "EmptySD3LatentImage", "inputs": { "batch_size": { "name": "taille_du_lot" }, "height": { "name": "hauteur" }, "width": { "name": "largeur" } }, "outputs": { "0": { "tooltip": null } } };
const ExponentialScheduler = { "display_name": "PlanificateurExponentiel", "inputs": { "sigma_max": { "name": "sigma_max" }, "sigma_min": { "name": "sigma_min" }, "steps": { "name": "étapes" } } };
const ExtendIntermediateSigmas = { "display_name": "ExtendIntermediateSigmas", "inputs": { "end_at_sigma": { "name": "finir_à_sigma" }, "sigmas": { "name": "sigmas" }, "spacing": { "name": "espacement" }, "start_at_sigma": { "name": "commencer_à_sigma" }, "steps": { "name": "étapes" } } };
const FeatherMask = { "display_name": "MasquePlume", "inputs": { "bottom": { "name": "bas" }, "left": { "name": "gauche" }, "mask": { "name": "masque" }, "right": { "name": "droite" }, "top": { "name": "haut" } } };
const FlipSigmas = { "display_name": "InverserSigmas", "inputs": { "sigmas": { "name": "sigmas" } } };
const FluxDisableGuidance = { "description": "Ce nœud désactive complètement l'intégration de guidage sur les modèles Flux et similaires à Flux", "display_name": "FluxDisableGuidance", "inputs": { "conditioning": { "name": "conditionnement" } }, "outputs": { "0": { "tooltip": null } } };
const FluxGuidance = { "display_name": "GuidageFlux", "inputs": { "conditioning": { "name": "conditionnement" }, "guidance": { "name": "guidage" } }, "outputs": { "0": { "tooltip": null } } };
const FluxKontextImageScale = { "description": "Ce nœud redimensionne l'image pour une optimisation avec flux kontext.", "display_name": "Échelle d'image FluxKontext", "inputs": { "image": { "name": "image" } }, "outputs": { "0": { "tooltip": null } } };
const FluxKontextMaxImageNode = { "description": "Modifie les images en utilisant Flux.1 Kontext [max] via l'API en fonction de l'invite et du rapport d'aspect.", "display_name": "Image Flux.1 Kontext [max]", "inputs": { "aspect_ratio": { "name": "rapport_d'aspect", "tooltip": "Rapport d'aspect de l'image ; doit être compris entre 1:4 et 4:1." }, "control_after_generate": { "name": "contrôle après génération" }, "guidance": { "name": "guidage", "tooltip": "Intensité du guidage pour le processus de génération d'image" }, "input_image": { "name": "image_d'entrée" }, "prompt": { "name": "invite", "tooltip": "Invite pour la génération d'image - spécifiez quoi et comment modifier." }, "prompt_upsampling": { "name": "suréchantillonnage_d'invite", "tooltip": "Indique s'il faut effectuer un suréchantillonnage sur l'invite. Si actif, modifie automatiquement l'invite pour une génération plus créative, mais les résultats sont non déterministes (la même graine ne produira pas exactement le même résultat)." }, "seed": { "name": "graine", "tooltip": "La graine aléatoire utilisée pour créer le bruit." }, "steps": { "name": "étapes", "tooltip": "Nombre d'étapes pour le processus de génération d'image" } }, "outputs": { "0": { "tooltip": null } } };
const FluxKontextMultiReferenceLatentMethod = { "display_name": "Méthode latente multi-référence FluxKontext", "inputs": { "conditioning": { "name": "conditionnement" }, "reference_latents_method": { "name": "méthode_des_latents_de_référence" } }, "outputs": { "0": { "tooltip": null } } };
const FluxKontextProImageNode = { "description": "Modifie les images en utilisant Flux.1 Kontext [pro] via l'API en fonction de l'invite et du rapport d'aspect.", "display_name": "Image Flux.1 Kontext [pro]", "inputs": { "aspect_ratio": { "name": "rapport_d'aspect", "tooltip": "Rapport d'aspect de l'image ; doit être compris entre 1:4 et 4:1." }, "control_after_generate": { "name": "contrôle après génération" }, "guidance": { "name": "guidage", "tooltip": "Intensité du guidage pour le processus de génération d'image" }, "input_image": { "name": "image_entrée" }, "prompt": { "name": "invite", "tooltip": "Invite pour la génération d'image - spécifiez quoi et comment modifier." }, "prompt_upsampling": { "name": "suréchantillonnage_prompt", "tooltip": "Indique s'il faut effectuer un suréchantillonnage sur le prompt. Si actif, modifie automatiquement le prompt pour une génération plus créative, mais les résultats sont non déterministes (la même graine ne produira pas exactement le même résultat)." }, "seed": { "name": "graine", "tooltip": "La graine aléatoire utilisée pour créer le bruit." }, "steps": { "name": "étapes", "tooltip": "Nombre d'étapes pour le processus de génération d'image" } }, "outputs": { "0": { "tooltip": null } } };
const FluxProExpandNode = { "description": "Étend l’image selon le prompt.", "display_name": "Flux.1 Élargir l’image", "inputs": { "bottom": { "name": "bas", "tooltip": "Nombre de pixels à ajouter en bas de l’image" }, "control_after_generate": { "name": "contrôle après génération" }, "guidance": { "name": "guidage", "tooltip": "Intensité du guidage pour le processus de génération d’image" }, "image": { "name": "image" }, "left": { "name": "gauche", "tooltip": "Nombre de pixels à ajouter à gauche de l’image" }, "prompt": { "name": "prompt", "tooltip": "Prompt pour la génération d’image" }, "prompt_upsampling": { "name": "suréchantillonnage du prompt", "tooltip": "Indique s’il faut effectuer un suréchantillonnage sur le prompt. Si activé, modifie automatiquement le prompt pour une génération plus créative, mais les résultats sont non déterministes (la même graine ne produira pas exactement le même résultat)." }, "right": { "name": "droite", "tooltip": "Nombre de pixels à ajouter à droite de l’image" }, "seed": { "name": "graine", "tooltip": "La graine aléatoire utilisée pour créer le bruit." }, "steps": { "name": "étapes", "tooltip": "Nombre d’étapes pour le processus de génération d’image" }, "top": { "name": "haut", "tooltip": "Nombre de pixels à ajouter en haut de l’image" } }, "outputs": { "0": { "tooltip": null } } };
const FluxProFillNode = { "description": "Reconstitue l'image en fonction du mask et du prompt.", "display_name": "Flux.1 Remplir l'image", "inputs": { "control_after_generate": { "name": "contrôle après génération" }, "guidance": { "name": "guidage", "tooltip": "Intensité du guidage pour le processus de génération d'image" }, "image": { "name": "image" }, "mask": { "name": "mask" }, "prompt": { "name": "prompt", "tooltip": "Prompt pour la génération d'image" }, "prompt_upsampling": { "name": "suréchantillonnage du prompt", "tooltip": "Indique s'il faut effectuer un suréchantillonnage du prompt. Si activé, modifie automatiquement le prompt pour une génération plus créative, mais les résultats sont non déterministes (la même seed ne produira pas exactement le même résultat)." }, "seed": { "name": "seed", "tooltip": "La seed aléatoire utilisée pour créer le bruit." }, "steps": { "name": "étapes", "tooltip": "Nombre d'étapes pour le processus de génération d'image" } }, "outputs": { "0": { "tooltip": null } } };
const FluxProUltraImageNode = { "description": "Génère des images avec Flux Pro 1.1 Ultra via l'API à partir d'un prompt et d'une résolution.", "display_name": "Flux 1.1 [pro] Ultra Image", "inputs": { "aspect_ratio": { "name": "aspect_ratio", "tooltip": "Rapport d'aspect de l'image ; doit être compris entre 1:4 et 4:1." }, "control_after_generate": { "name": "control after generate" }, "image_prompt": { "name": "image_prompt" }, "image_prompt_strength": { "name": "image_prompt_strength", "tooltip": "Mélange entre le prompt et le prompt image." }, "prompt": { "name": "prompt", "tooltip": "Prompt pour la génération d'image" }, "prompt_upsampling": { "name": "prompt_upsampling", "tooltip": "Indique s'il faut effectuer un upsampling sur le prompt. Si activé, modifie automatiquement le prompt pour une génération plus créative, mais les résultats sont non déterministes (la même graine ne produira pas exactement le même résultat)." }, "raw": { "name": "raw", "tooltip": "Si vrai, génère des images moins traitées et d'apparence plus naturelle." }, "seed": { "name": "seed", "tooltip": "La graine aléatoire utilisée pour créer le bruit." } }, "outputs": { "0": { "tooltip": null } } };
const FreSca = { "description": "Applique une mise à l'échelle dépendante de la fréquence au guidage", "display_name": "FreSca", "inputs": { "freq_cutoff": { "name": "seuil_fréquence", "tooltip": "Nombre d'indices de fréquence autour du centre à considérer comme basses fréquences" }, "model": { "name": "modèle" }, "scale_high": { "name": "échelle_haute", "tooltip": "Facteur d'échelle pour les composantes hautes fréquences" }, "scale_low": { "name": "échelle_basse", "tooltip": "Facteur d'échelle pour les composantes basses fréquences" } }, "outputs": { "0": { "tooltip": null } } };
const FreeU = { "display_name": "FreeU", "inputs": { "b1": { "name": "b1" }, "b2": { "name": "b2" }, "model": { "name": "modèle" }, "s1": { "name": "s1" }, "s2": { "name": "s2" } } };
const FreeU_V2 = { "display_name": "FreeU_V2", "inputs": { "b1": { "name": "b1" }, "b2": { "name": "b2" }, "model": { "name": "modèle" }, "s1": { "name": "s1" }, "s2": { "name": "s2" } } };
const GITSScheduler = { "display_name": "GITSScheduler", "inputs": { "coeff": { "name": "coeff" }, "denoise": { "name": "débruitage" }, "steps": { "name": "étapes" } }, "outputs": { "0": { "tooltip": null } } };
const GLIGENLoader = { "display_name": "GLIGENLoader", "inputs": { "gligen_name": { "name": "nom_gligen" } } };
const GLIGENTextBoxApply = { "display_name": "GLIGENTextBoxApply", "inputs": { "clip": { "name": "clip" }, "conditioning_to": { "name": "conditionnement_à" }, "gligen_textbox_model": { "name": "modèle_boîte_texte_gligen" }, "height": { "name": "hauteur" }, "text": { "name": "texte" }, "width": { "name": "largeur" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const GeminiImageNode = { "description": "Modifier les images de manière synchrone via l'API Google.", "display_name": "Image Google Gemini", "inputs": { "aspect_ratio": { "name": "ratio_d'aspect", "tooltip": "Par défaut, correspond à la taille de l'image de sortie à celle de votre image d'entrée, ou génère sinon des carrés 1:1." }, "control_after_generate": { "name": "contrôle après génération" }, "files": { "name": "fichiers", "tooltip": "Fichier(s) optionnel(s) à utiliser comme contexte pour le modèle. Accepte les entrées du nœud Fichiers d'entrée de contenu généré Gemini." }, "images": { "name": "images", "tooltip": "Image(s) optionnelle(s) à utiliser comme contexte pour le modèle. Pour inclure plusieurs images, vous pouvez utiliser le nœud Images par lot." }, "model": { "name": "modèle", "tooltip": "Le modèle Gemini à utiliser pour générer les réponses." }, "prompt": { "name": "prompt", "tooltip": "Prompt texte pour la génération" }, "seed": { "name": "graine", "tooltip": "Lorsque la graine est fixée à une valeur spécifique, le modèle fait de son mieux pour fournir la même réponse pour des requêtes répétées. La sortie déterministe n'est pas garantie. De plus, changer le modèle ou les paramètres, comme la température, peut entraîner des variations dans la réponse même en utilisant la même valeur de graine. Par défaut, une valeur de graine aléatoire est utilisée." } }, "outputs": { "0": { "tooltip": null }, "1": { "tooltip": null } } };
const GeminiInputFiles = { "description": "Charge et prépare les fichiers d'entrée à inclure comme entrées pour les nœuds LLM Gemini. Les fichiers seront lus par le modèle Gemini lors de la génération d'une réponse. Le contenu du fichier texte compte dans la limite de tokens. 🛈 ASTUCE : Peut être chaîné avec d'autres nœuds de fichiers d'entrée Gemini.", "display_name": "Fichiers d'entrée Gemini", "inputs": { "GEMINI_INPUT_FILES": { "name": "FICHIERS_ENTRÉE_GEMINI", "tooltip": "Un ou plusieurs fichiers supplémentaires optionnels à regrouper avec le fichier chargé depuis ce nœud. Permet d'enchaîner les fichiers d'entrée afin qu'un seul message puisse inclure plusieurs fichiers d'entrée." }, "file": { "name": "fichier", "tooltip": "Fichiers d'entrée à inclure comme contexte pour le modèle. N'accepte pour le moment que les fichiers texte (.txt) et PDF (.pdf)." } }, "outputs": { "0": { "tooltip": null } } };
const GeminiNode = { "description": "Génère des réponses textuelles avec le modèle d'IA Gemini de Google. Vous pouvez fournir plusieurs types d'entrées (texte, images, audio, vidéo) comme contexte pour générer des réponses plus pertinentes et significatives.", "display_name": "Google Gemini", "inputs": { "audio": { "name": "audio", "tooltip": "Audio optionnel à utiliser comme contexte pour le modèle." }, "control_after_generate": { "name": "contrôle après génération" }, "files": { "name": "fichiers", "tooltip": "Fichier(s) optionnel(s) à utiliser comme contexte pour le modèle. Accepte les entrées du nœud Fichiers d'entrée de génération de contenu Gemini." }, "images": { "name": "images", "tooltip": "Image(s) optionnelle(s) à utiliser comme contexte pour le modèle. Pour inclure plusieurs images, vous pouvez utiliser le nœud Images par lot." }, "model": { "name": "modèle", "tooltip": "Le modèle Gemini à utiliser pour générer les réponses." }, "prompt": { "name": "prompt", "tooltip": "Entrées textuelles pour le modèle, utilisées pour générer une réponse. Vous pouvez inclure des instructions détaillées, des questions ou du contexte pour le modèle." }, "seed": { "name": "graine", "tooltip": "Lorsque la graine est fixée à une valeur spécifique, le modèle fait de son mieux pour fournir la même réponse pour des requêtes répétées. La sortie déterministe n'est pas garantie. De plus, changer le modèle ou les paramètres, comme la température, peut entraîner des variations dans la réponse même en utilisant la même valeur de graine. Par défaut, une valeur de graine aléatoire est utilisée." }, "video": { "name": "vidéo", "tooltip": "Vidéo optionnelle à utiliser comme contexte pour le modèle." } }, "outputs": { "0": { "tooltip": null } } };
const GetImageSize = { "description": "Retourne la largeur et la hauteur de l'image, et la transmet inchangée.", "display_name": "Obtenir la taille de l'image", "inputs": { "image": { "name": "image" } }, "outputs": { "0": { "name": "largeur" }, "1": { "name": "hauteur" }, "2": { "name": "taille_du_lot" } } };
const GetVideoComponents = { "description": "Extrait tous les composants d'une vidéo : images, audio et fréquence d’images.", "display_name": "Obtenir les composants vidéo", "inputs": { "video": { "name": "vidéo", "tooltip": "La vidéo dont extraire les composants." } }, "outputs": { "0": { "name": "images", "tooltip": null }, "1": { "name": "audio", "tooltip": null }, "2": { "name": "ips", "tooltip": null } } };
const GrowMask = { "display_name": "GrowMask", "inputs": { "expand": { "name": "agrandir" }, "mask": { "name": "masque" }, "tapered_corners": { "name": "coins_évasés" } } };
const Hunyuan3Dv2Conditioning = { "display_name": "Hunyuan3Dv2Conditioning", "inputs": { "clip_vision_output": { "name": "sortie_vision_clip" } }, "outputs": { "0": { "name": "positif" }, "1": { "name": "négatif" } } };
const Hunyuan3Dv2ConditioningMultiView = { "display_name": "Hunyuan3Dv2ConditioningMultiView", "inputs": { "back": { "name": "arrière" }, "front": { "name": "avant" }, "left": { "name": "gauche" }, "right": { "name": "droite" } }, "outputs": { "0": { "name": "positif" }, "1": { "name": "négatif" } } };
const HunyuanImageToVideo = { "display_name": "HunyuanImageToVideo", "inputs": { "batch_size": { "name": "taille_du_lot" }, "guidance_type": { "name": "type_de_guidage" }, "height": { "name": "hauteur" }, "length": { "name": "longueur" }, "positive": { "name": "positive" }, "start_image": { "name": "image_de_départ" }, "vae": { "name": "vae" }, "width": { "name": "largeur" } }, "outputs": { "0": { "name": "positive", "tooltip": null }, "1": { "name": "latent", "tooltip": null } } };
const HunyuanRefinerLatent = { "display_name": "Latent HunyuanRefiner", "inputs": { "latent": { "name": "latent" }, "negative": { "name": "négatif" }, "noise_augmentation": { "name": "augmentation_du_bruit" }, "positive": { "name": "positif" } }, "outputs": { "0": { "name": "positif", "tooltip": null }, "1": { "name": "négatif", "tooltip": null }, "2": { "name": "latent", "tooltip": null } } };
const HyperTile = { "display_name": "HyperTile", "inputs": { "max_depth": { "name": "profondeur_max" }, "model": { "name": "modèle" }, "scale_depth": { "name": "échelle_profondeur" }, "swap_size": { "name": "taille_échange" }, "tile_size": { "name": "taille_tuile" } }, "outputs": { "0": { "tooltip": null } } };
const HypernetworkLoader = { "display_name": "HypernetworkLoader", "inputs": { "hypernetwork_name": { "name": "nom_hypernetwork" }, "model": { "name": "modèle" }, "strength": { "name": "force" } }, "outputs": { "0": { "tooltip": null } } };
const IdeogramV1 = { "description": "Génère des images de manière synchrone en utilisant le modèle Ideogram V1.\n\nLes liens des images sont disponibles pour une durée limitée ; si vous souhaitez conserver l'image, vous devez la télécharger.", "display_name": "Ideogram V1", "inputs": { "aspect_ratio": { "name": "aspect_ratio", "tooltip": "Le format d'image pour la génération." }, "control_after_generate": { "name": "control after generate" }, "magic_prompt_option": { "name": "magic_prompt_option", "tooltip": "Déterminer si MagicPrompt doit être utilisé lors de la génération" }, "negative_prompt": { "name": "negative_prompt", "tooltip": "Description de ce qu'il faut exclure de l'image" }, "num_images": { "name": "num_images" }, "prompt": { "name": "prompt", "tooltip": "Invite pour la génération d'image" }, "seed": { "name": "seed" }, "turbo": { "name": "turbo", "tooltip": "Activer le mode turbo (génération plus rapide, qualité potentiellement inférieure)" } }, "outputs": { "0": { "tooltip": null } } };
const IdeogramV2 = { "description": "Génère des images de manière synchrone en utilisant le modèle Ideogram V2.\n\nLes liens vers les images sont disponibles pour une durée limitée ; si vous souhaitez conserver l'image, vous devez la télécharger.", "display_name": "Ideogram V2", "inputs": { "aspect_ratio": { "name": "aspect_ratio", "tooltip": "Le format d'image pour la génération. Ignoré si la résolution n'est pas définie sur AUTO." }, "control_after_generate": { "name": "control after generate" }, "magic_prompt_option": { "name": "magic_prompt_option", "tooltip": "Déterminer si MagicPrompt doit être utilisé lors de la génération" }, "negative_prompt": { "name": "negative_prompt", "tooltip": "Description de ce qu'il faut exclure de l'image" }, "num_images": { "name": "num_images" }, "prompt": { "name": "prompt", "tooltip": "Invite pour la génération d'image" }, "resolution": { "name": "resolution", "tooltip": "La résolution pour la génération d'image. Si elle n'est pas définie sur AUTO, cela remplace le paramètre aspect_ratio." }, "seed": { "name": "seed" }, "style_type": { "name": "style_type", "tooltip": "Type de style pour la génération (V2 uniquement)" }, "turbo": { "name": "turbo", "tooltip": "Activer le mode turbo (génération plus rapide, qualité potentiellement inférieure)" } }, "outputs": { "0": { "tooltip": null } } };
const IdeogramV3 = { "description": "Génère des images de façon synchrone avec le modèle Ideogram V3.\n\nPrend en charge la génération d’images à partir de prompts textuels ainsi que l’édition d’images avec mask.\nLes liens des images sont disponibles pour une durée limitée ; si vous souhaitez conserver l’image, vous devez la télécharger.", "display_name": "Ideogram V3", "inputs": { "aspect_ratio": { "name": "aspect_ratio", "tooltip": "Le ratio d’aspect pour la génération d’image. Ignoré si la résolution n’est pas réglée sur Auto." }, "character_image": { "name": "image_du_personnage", "tooltip": "Image à utiliser comme référence de personnage." }, "character_mask": { "name": "masque_du_personnage", "tooltip": "Masque optionnel pour l'image de référence du personnage." }, "control_after_generate": { "name": "control after generate" }, "image": { "name": "image", "tooltip": "Image de référence optionnelle pour l’édition d’image." }, "magic_prompt_option": { "name": "magic_prompt_option", "tooltip": "Détermine si MagicPrompt doit être utilisé lors de la génération" }, "mask": { "name": "mask", "tooltip": "Mask optionnel pour l’inpainting (les zones blanches seront remplacées)" }, "num_images": { "name": "num_images" }, "prompt": { "name": "prompt", "tooltip": "Prompt pour la génération ou l’édition d’image" }, "rendering_speed": { "name": "rendering_speed", "tooltip": "Contrôle le compromis entre la vitesse de génération et la qualité" }, "resolution": { "name": "resolution", "tooltip": "La résolution pour la génération d’image. Si elle n’est pas réglée sur Auto, cela remplace le paramètre aspect_ratio." }, "seed": { "name": "seed" } }, "outputs": { "0": { "tooltip": null } } };
const ImageAddNoise = { "display_name": "Ajout de bruit à l'image", "inputs": { "control_after_generate": { "name": "contrôle après génération" }, "image": { "name": "image" }, "seed": { "name": "graine", "tooltip": "La graine aléatoire utilisée pour créer le bruit." }, "strength": { "name": "intensité" } } };
const ImageBatch = { "display_name": "Images en lot", "inputs": { "image1": { "name": "image1" }, "image2": { "name": "image2" } } };
const ImageBlend = { "display_name": "Mélange d'images", "inputs": { "blend_factor": { "name": "facteur_mélange" }, "blend_mode": { "name": "mode_mélange" }, "image1": { "name": "image1" }, "image2": { "name": "image2" } }, "outputs": { "0": { "tooltip": null } } };
const ImageBlur = { "display_name": "Flou d'image", "inputs": { "blur_radius": { "name": "rayon_flou" }, "image": { "name": "image" }, "sigma": { "name": "sigma" } }, "outputs": { "0": { "tooltip": null } } };
const ImageColorToMask = { "display_name": "ImageCouleurEnMasque", "inputs": { "color": { "name": "couleur" }, "image": { "name": "image" } } };
const ImageCompositeMasked = { "display_name": "ImageCompositeMasked", "inputs": { "destination": { "name": "destination" }, "mask": { "name": "masque" }, "resize_source": { "name": "redimensionner_source" }, "source": { "name": "source" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const ImageCrop = { "display_name": "Rogner l'image", "inputs": { "height": { "name": "hauteur" }, "image": { "name": "image" }, "width": { "name": "largeur" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const ImageFlip = { "display_name": "Retournement d'image", "inputs": { "flip_method": { "name": "méthode_de_retournement" }, "image": { "name": "image" } } };
const ImageFromBatch = { "display_name": "ImageDeBatch", "inputs": { "batch_index": { "name": "index_de_lot" }, "image": { "name": "image" }, "length": { "name": "longueur" } } };
const ImageInvert = { "display_name": "Inverser l'image", "inputs": { "image": { "name": "image" } } };
const ImageOnlyCheckpointLoader = { "display_name": "Chargeur de points de contrôle uniquement pour image (modèle img2vid)", "inputs": { "ckpt_name": { "name": "nom_ckpt" } } };
const ImageOnlyCheckpointSave = { "display_name": "ImageOnlyCheckpointSave", "inputs": { "clip_vision": { "name": "clip_vision" }, "filename_prefix": { "name": "préfixe_de_nom_de_fichier" }, "model": { "name": "modèle" }, "vae": { "name": "vae" } } };
const ImagePadForOutpaint = { "display_name": "Rembourrage d'image pour la peinture extérieure", "inputs": { "bottom": { "name": "bas" }, "feathering": { "name": "adoucissement" }, "image": { "name": "image" }, "left": { "name": "gauche" }, "right": { "name": "droite" }, "top": { "name": "haut" } } };
const ImageQuantize = { "display_name": "Quantification d'image", "inputs": { "colors": { "name": "couleurs" }, "dither": { "name": "dither" }, "image": { "name": "image" } }, "outputs": { "0": { "tooltip": null } } };
const ImageRGBToYUV = { "display_name": "ImageRGBToYUV", "inputs": { "image": { "name": "image" } }, "outputs": { "0": { "name": "Y", "tooltip": null }, "1": { "name": "U", "tooltip": null }, "2": { "name": "V", "tooltip": null } } };
const ImageRotate = { "display_name": "Rotation d'image", "inputs": { "image": { "name": "image" }, "rotation": { "name": "rotation" } } };
const ImageScale = { "display_name": "Agrandir l'image", "inputs": { "crop": { "name": "crop" }, "height": { "name": "hauteur" }, "image": { "name": "image" }, "upscale_method": { "name": "méthode_d'agrandissement" }, "width": { "name": "largeur" } } };
const ImageScaleBy = { "display_name": "Agrandir l'image par", "inputs": { "image": { "name": "image" }, "scale_by": { "name": "agrandir_par" }, "upscale_method": { "name": "méthode_d'agrandissement" } } };
const ImageScaleToMaxDimension = { "display_name": "Redimensionner à la dimension maximale", "inputs": { "image": { "name": "image" }, "largest_size": { "name": "taille_maximale" }, "upscale_method": { "name": "méthode_d'agrandissement" } } };
const ImageScaleToTotalPixels = { "display_name": "Redimensionner l'image en fonction du nombre total de pixels", "inputs": { "image": { "name": "image" }, "megapixels": { "name": "mégapixels" }, "upscale_method": { "name": "méthode_d'agrandissement" } }, "outputs": { "0": { "tooltip": null } } };
const ImageSharpen = { "display_name": "Affiner l'image", "inputs": { "alpha": { "name": "alpha" }, "image": { "name": "image" }, "sharpen_radius": { "name": "rayon_d'affûtage" }, "sigma": { "name": "sigma" } }, "outputs": { "0": { "tooltip": null } } };
const ImageStitch = { "description": "\nAssemble image2 à image1 dans la direction spécifiée.\nSi image2 n'est pas fournie, retourne image1 inchangée.\nUn espacement optionnel peut être ajouté entre les images.\n", "display_name": "Assemblage d'images", "inputs": { "direction": { "name": "direction" }, "image1": { "name": "image1" }, "image2": { "name": "image2" }, "match_image_size": { "name": "correspondre_taille_image" }, "spacing_color": { "name": "espacement_couleur" }, "spacing_width": { "name": "espacement_largeur" } } };
const ImageToMask = { "display_name": "Convertir Image en Masque", "inputs": { "channel": { "name": "canal" }, "image": { "name": "image" } } };
const ImageUpscaleWithModel = { "display_name": "Agrandir l'Image (à l'aide du Modèle)", "inputs": { "image": { "name": "image" }, "upscale_model": { "name": "modèle_d'agrandissement" } }, "outputs": { "0": { "tooltip": null } } };
const ImageYUVToRGB = { "display_name": "ImageYUVToRGB", "inputs": { "U": { "name": "U" }, "V": { "name": "V" }, "Y": { "name": "Y" } }, "outputs": { "0": { "tooltip": null } } };
const InpaintModelConditioning = { "display_name": "InpaintModelConditioning", "inputs": { "mask": { "name": "masque" }, "negative": { "name": "négatif" }, "noise_mask": { "name": "masque_de_bruit", "tooltip": "Ajoutez un masque de bruit au latent pour que l'échantillonnage ne se produise que dans le masque. Peut améliorer les résultats ou complètement les détruire en fonction du modèle." }, "pixels": { "name": "pixels" }, "positive": { "name": "positive" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "positive" }, "1": { "name": "négatif" }, "2": { "name": "latent" } } };
const InstructPixToPixConditioning = { "display_name": "InstructPixToPixConditioning", "inputs": { "negative": { "name": "négatif" }, "pixels": { "name": "pixels" }, "positive": { "name": "positive" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "positive", "tooltip": null }, "1": { "name": "négatif", "tooltip": null }, "2": { "name": "latent", "tooltip": null } } };
const InvertMask = { "display_name": "InverserMasque", "inputs": { "mask": { "name": "masque" } } };
const JoinImageWithAlpha = { "display_name": "Joindre Image avec Alpha", "inputs": { "alpha": { "name": "alpha" }, "image": { "name": "image" } }, "outputs": { "0": { "tooltip": null } } };
const KSampler = { "description": "Utilise le modèle fourni, le conditionnement positif et négatif pour débruiter l'image latente.", "display_name": "KSampler", "inputs": { "cfg": { "name": "cfg", "tooltip": "L'échelle de guidage sans classificateur équilibre la créativité et l'adhérence à l'invite. Des valeurs plus élevées donnent des images correspondant plus étroitement à l'invite, cependant des valeurs trop élevées auront un impact négatif sur la qualité." }, "control_after_generate": { "name": "contrôle après génération" }, "denoise": { "name": "denoise", "tooltip": "La quantité de débruitage appliquée, des valeurs plus faibles maintiendront la structure de l'image initiale permettant un échantillonnage d'image à image." }, "latent_image": { "name": "latent_image", "tooltip": "L'image latente à débruiter." }, "model": { "name": "model", "tooltip": "Le modèle utilisé pour débruiter l'entrée latente." }, "negative": { "name": "negative", "tooltip": "Le conditionnement décrivant les attributs que vous voulez exclure de l'image." }, "positive": { "name": "positive", "tooltip": "Le conditionnement décrivant les attributs que vous voulez inclure dans l'image." }, "sampler_name": { "name": "sampler_name", "tooltip": "L'algorithme utilisé lors de l'échantillonnage, cela peut affecter la qualité, la vitesse et le style de la sortie générée." }, "scheduler": { "name": "scheduler", "tooltip": "Le planificateur contrôle comment le bruit est progressivement éliminé pour former l'image." }, "seed": { "name": "seed", "tooltip": "La graine aléatoire utilisée pour créer le bruit." }, "steps": { "name": "steps", "tooltip": "Le nombre d'étapes utilisées dans le processus de débruitage." } }, "outputs": { "0": { "tooltip": "Le latent débruité." } } };
const KSamplerAdvanced = { "display_name": "KSampler (Avancé)", "inputs": { "add_noise": { "name": "add_noise" }, "cfg": { "name": "cfg" }, "control_after_generate": { "name": "contrôle après génération" }, "end_at_step": { "name": "end_at_step" }, "latent_image": { "name": "latent_image" }, "model": { "name": "model" }, "negative": { "name": "negative" }, "noise_seed": { "name": "noise_seed" }, "positive": { "name": "positive" }, "return_with_leftover_noise": { "name": "return_with_leftover_noise" }, "sampler_name": { "name": "sampler_name" }, "scheduler": { "name": "scheduler" }, "start_at_step": { "name": "start_at_step" }, "steps": { "name": "steps" } } };
const KSamplerSelect = { "display_name": "KSamplerSelect", "inputs": { "sampler_name": { "name": "sampler_name" } } };
const KarrasScheduler = { "display_name": "PlanificateurKarras", "inputs": { "rho": { "name": "rho" }, "sigma_max": { "name": "sigma_max" }, "sigma_min": { "name": "sigma_min" }, "steps": { "name": "étapes" } } };
const KlingCameraControlI2VNode = { "description": "Transformez des images fixes en vidéos cinématographiques avec des mouvements de caméra professionnels qui simulent la cinématographie réelle. Contrôlez les actions de la caméra virtuelle, y compris le zoom, la rotation, le panoramique, l'inclinaison et la vue à la première personne, tout en maintenant la mise au point sur votre image d'origine.", "display_name": "Kling Image to Video (Contrôle de la caméra)", "inputs": { "aspect_ratio": { "name": "aspect_ratio" }, "camera_control": { "name": "camera_control", "tooltip": "Peut être créé à l'aide du nœud Kling Camera Controls. Contrôle le mouvement et l'animation de la caméra pendant la génération de la vidéo." }, "cfg_scale": { "name": "cfg_scale" }, "negative_prompt": { "name": "negative_prompt", "tooltip": "Invite textuelle négative" }, "prompt": { "name": "prompt", "tooltip": "Invite textuelle positive" }, "start_frame": { "name": "start_frame", "tooltip": "Image de référence - URL ou chaîne encodée en Base64, ne peut pas dépasser 10 Mo, résolution d'au moins 300*300px, ratio d'aspect entre 1:2,5 et 2,5:1. Le Base64 ne doit pas inclure le préfixe data:image." } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "video_id", "tooltip": null }, "2": { "name": "duration", "tooltip": null } } };
const KlingCameraControlT2VNode = { "description": "Transformez du texte en vidéos cinématographiques avec des mouvements de caméra professionnels qui simulent la cinématographie réelle. Contrôlez les actions de la caméra virtuelle, y compris le zoom, la rotation, le panoramique, l’inclinaison et la vue à la première personne, tout en gardant le focus sur votre texte d’origine.", "display_name": "Kling Texte vers Vidéo (Contrôle de Caméra)", "inputs": { "aspect_ratio": { "name": "aspect_ratio" }, "camera_control": { "name": "camera_control", "tooltip": "Peut être créé à l’aide du nœud Kling Camera Controls. Contrôle le mouvement et l’animation de la caméra pendant la génération de la vidéo." }, "cfg_scale": { "name": "cfg_scale" }, "negative_prompt": { "name": "negative_prompt", "tooltip": "Invite de texte négative" }, "prompt": { "name": "prompt", "tooltip": "Invite de texte positive" } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "video_id", "tooltip": null }, "2": { "name": "duration", "tooltip": null } } };
const KlingCameraControls = { "description": "Permet de spécifier les options de configuration pour les contrôles de la caméra Kling et les effets de contrôle du mouvement.", "display_name": "Contrôles de la caméra Kling", "inputs": { "camera_control_type": { "name": "camera_control_type" }, "horizontal_movement": { "name": "horizontal_movement", "tooltip": "Contrôle le mouvement de la caméra sur l’axe horizontal (axe x). Négatif indique la gauche, positif indique la droite." }, "pan": { "name": "pan", "tooltip": "Contrôle la rotation de la caméra dans le plan vertical (axe x). Négatif indique une rotation vers le bas, positif indique une rotation vers le haut." }, "roll": { "name": "roll", "tooltip": "Contrôle la quantité de roulis de la caméra (axe z). Négatif indique un mouvement antihoraire, positif indique un mouvement horaire." }, "tilt": { "name": "tilt", "tooltip": "Contrôle la rotation de la caméra dans le plan horizontal (axe y). Négatif indique une rotation vers la gauche, positif indique une rotation vers la droite." }, "vertical_movement": { "name": "vertical_movement", "tooltip": "Contrôle le mouvement de la caméra sur l’axe vertical (axe y). Négatif indique vers le bas, positif indique vers le haut." }, "zoom": { "name": "zoom", "tooltip": "Contrôle le changement de la longueur focale de la caméra. Négatif indique un champ de vision plus étroit, positif indique un champ de vision plus large." } }, "outputs": { "0": { "name": "camera_control", "tooltip": null } } };
const KlingDualCharacterVideoEffectNode = { "description": "Obtenez différents effets spéciaux lors de la génération d'une vidéo en fonction de l'effect_scene. La première image sera positionnée à gauche, la seconde à droite du composite.", "display_name": "Effets vidéo à deux personnages Kling", "inputs": { "duration": { "name": "duration" }, "effect_scene": { "name": "effect_scene" }, "image_left": { "name": "image_left", "tooltip": "Image côté gauche" }, "image_right": { "name": "image_right", "tooltip": "Image côté droit" }, "mode": { "name": "mode" }, "model_name": { "name": "model_name" } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "duration", "tooltip": null } } };
const KlingImage2VideoNode = { "display_name": "Kling Image to Video", "inputs": { "aspect_ratio": { "name": "aspect_ratio" }, "cfg_scale": { "name": "cfg_scale" }, "duration": { "name": "duration" }, "mode": { "name": "mode" }, "model_name": { "name": "model_name" }, "negative_prompt": { "name": "negative_prompt", "tooltip": "Invite textuelle négative" }, "prompt": { "name": "prompt", "tooltip": "Invite textuelle positive" }, "start_frame": { "name": "start_frame", "tooltip": "Image de référence - URL ou chaîne encodée en Base64, ne doit pas dépasser 10 Mo, résolution d'au moins 300*300px, ratio d'aspect entre 1:2,5 et 2,5:1. Le Base64 ne doit pas inclure le préfixe data:image." } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "video_id", "tooltip": null }, "2": { "name": "duration", "tooltip": null } } };
const KlingImageGenerationNode = { "description": "Nœud de génération d'image Kling. Générez une image à partir d'une invite textuelle avec une image de référence optionnelle.", "display_name": "Génération d'image Kling", "inputs": { "aspect_ratio": { "name": "aspect_ratio" }, "human_fidelity": { "name": "human_fidelity", "tooltip": "Similarité de référence du sujet" }, "image": { "name": "image" }, "image_fidelity": { "name": "image_fidelity", "tooltip": "Intensité de référence pour les images téléchargées par l'utilisateur" }, "image_type": { "name": "image_type" }, "model_name": { "name": "model_name" }, "n": { "name": "n", "tooltip": "Nombre d'images générées" }, "negative_prompt": { "name": "negative_prompt", "tooltip": "Invite textuelle négative" }, "prompt": { "name": "prompt", "tooltip": "Invite textuelle positive" } }, "outputs": { "0": { "tooltip": null } } };
const KlingLipSyncAudioToVideoNode = { "description": "Nœud de synchronisation labiale Kling. Synchronise les mouvements de la bouche dans un fichier vidéo avec le contenu audio d’un fichier audio.", "display_name": "Synchronisation labiale Kling : Vidéo avec audio", "inputs": { "audio": { "name": "audio" }, "video": { "name": "vidéo" }, "voice_language": { "name": "langue de la voix" } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "id_vidéo", "tooltip": null }, "2": { "name": "durée", "tooltip": null } } };
const KlingLipSyncTextToVideoNode = { "description": "Nœud Kling de synchronisation labiale texte vers vidéo. Synchronise les mouvements de la bouche dans un fichier vidéo avec une invite textuelle.", "display_name": "Synchronisation labiale Kling vidéo avec texte", "inputs": { "text": { "name": "texte", "tooltip": "Contenu textuel pour la génération de vidéo synchronisée labiale. Requis lorsque le mode est text2video. Longueur maximale : 120 caractères." }, "video": { "name": "vidéo" }, "voice": { "name": "voix" }, "voice_speed": { "name": "vitesse de la voix", "tooltip": "Vitesse de la parole. Plage valide : 0,8~2,0, avec une précision d’un chiffre après la virgule." } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "id_vidéo", "tooltip": null }, "2": { "name": "durée", "tooltip": null } } };
const KlingSingleImageVideoEffectNode = { "description": "Obtenez différents effets spéciaux lors de la génération d'une vidéo selon le effect_scene.", "display_name": "Effets vidéo Kling", "inputs": { "duration": { "name": "durée" }, "effect_scene": { "name": "effect_scene" }, "image": { "name": "image", "tooltip": "Image de référence. URL ou chaîne encodée en Base64 (sans le préfixe data:image). La taille du fichier ne doit pas dépasser 10 Mo, la résolution ne doit pas être inférieure à 300*300px, le ratio d'aspect doit être compris entre 1:2,5 et 2,5:1" }, "model_name": { "name": "model_name" } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "video_id", "tooltip": null }, "2": { "name": "durée", "tooltip": null } } };
const KlingStartEndFrameNode = { "description": "Générez une séquence vidéo qui effectue une transition entre les images de début et de fin que vous fournissez. Le nœud crée tous les cadres intermédiaires, produisant une transformation fluide du premier au dernier cadre.", "display_name": "Kling Début-Fin Image vers Vidéo", "inputs": { "aspect_ratio": { "name": "aspect_ratio" }, "cfg_scale": { "name": "cfg_scale" }, "end_frame": { "name": "end_frame", "tooltip": "Image de référence - Contrôle de l'image de fin. URL ou chaîne encodée en Base64, ne doit pas dépasser 10 Mo, résolution d'au moins 300*300px. La Base64 ne doit pas inclure le préfixe data:image." }, "mode": { "name": "mode", "tooltip": "La configuration à utiliser pour la génération vidéo selon le format : mode / durée / nom_du_modèle." }, "negative_prompt": { "name": "negative_prompt", "tooltip": "Invite textuelle négative" }, "prompt": { "name": "prompt", "tooltip": "Invite textuelle positive" }, "start_frame": { "name": "start_frame", "tooltip": "Image de référence - URL ou chaîne encodée en Base64, ne doit pas dépasser 10 Mo, résolution d'au moins 300*300px, ratio d'aspect entre 1:2.5 et 2.5:1. La Base64 ne doit pas inclure le préfixe data:image." } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "video_id", "tooltip": null }, "2": { "name": "duration", "tooltip": null } } };
const KlingTextToVideoNode = { "description": "Nœud Kling Texte en Vidéo", "display_name": "Kling Texte en Vidéo", "inputs": { "aspect_ratio": { "name": "aspect_ratio" }, "cfg_scale": { "name": "cfg_scale" }, "mode": { "name": "mode", "tooltip": "La configuration à utiliser pour la génération vidéo selon le format : mode / durée / nom_du_modèle." }, "negative_prompt": { "name": "negative_prompt", "tooltip": "Invite texte négative" }, "prompt": { "name": "prompt", "tooltip": "Invite texte positive" } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "video_id", "tooltip": null }, "2": { "name": "duration", "tooltip": null } } };
const KlingVideoExtendNode = { "description": "Nœud Kling Video Extend. Étend les vidéos créées par d'autres nœuds Kling. Le video_id est créé en utilisant d'autres nœuds Kling.", "display_name": "Kling Video Extend", "inputs": { "cfg_scale": { "name": "cfg_scale" }, "negative_prompt": { "name": "negative_prompt", "tooltip": "Invite textuelle négative pour les éléments à éviter dans la vidéo étendue" }, "prompt": { "name": "prompt", "tooltip": "Invite textuelle positive pour guider l’extension de la vidéo" }, "video_id": { "name": "video_id", "tooltip": "L’ID de la vidéo à étendre. Prend en charge les vidéos générées par texte-vers-vidéo, image-vers-vidéo et les opérations précédentes d’extension de vidéo. La durée totale ne peut pas dépasser 3 minutes après extension." } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "video_id", "tooltip": null }, "2": { "name": "duration", "tooltip": null } } };
const KlingVirtualTryOnNode = { "description": "Nœud Kling Virtual Try On. Importez une image humaine et une image de vêtement pour essayer le vêtement sur la personne.", "display_name": "Kling Virtual Try On", "inputs": { "cloth_image": { "name": "cloth_image" }, "human_image": { "name": "human_image" }, "model_name": { "name": "model_name" } }, "outputs": { "0": { "tooltip": null } } };
const LTXVAddGuide = { "display_name": "LTXVAddGuide", "inputs": { "frame_idx": { "name": "indice_de_l'image", "tooltip": "Indice de l'image pour commencer le conditionnement. Pour les images uniques ou les vidéos de 1 à 8 images, toute valeur d'indice de l'image est acceptable. Pour les vidéos de 9 images ou plus, l'indice de l'image doit être divisible par 8, sinon il sera arrondi à la baisse au multiple de 8 le plus proche. Les valeurs négatives sont comptées à partir de la fin de la vidéo." }, "image": { "name": "image", "tooltip": "Image ou vidéo pour conditionner la vidéo latente. Doit être 8*n + 1 images. Si la vidéo n'est pas 8*n + 1 images, elle sera coupée au plus proche 8*n + 1 images." }, "latent": { "name": "latent" }, "negative": { "name": "négatif" }, "positive": { "name": "positive" }, "strength": { "name": "force" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "positive", "tooltip": null }, "1": { "name": "négatif", "tooltip": null }, "2": { "name": "latent", "tooltip": null } } };
const LTXVConditioning = { "display_name": "LTXVConditioning", "inputs": { "frame_rate": { "name": "frame_rate" }, "negative": { "name": "negative" }, "positive": { "name": "positive" } }, "outputs": { "0": { "name": "positive", "tooltip": null }, "1": { "name": "negative", "tooltip": null } } };
const LTXVCropGuides = { "display_name": "LTXVCropGuides", "inputs": { "latent": { "name": "latent" }, "negative": { "name": "négatif" }, "positive": { "name": "positive" } }, "outputs": { "0": { "name": "positive", "tooltip": null }, "1": { "name": "négatif", "tooltip": null }, "2": { "name": "latent", "tooltip": null } } };
const LTXVImgToVideo = { "display_name": "LTXVImgToVideo", "inputs": { "batch_size": { "name": "batch_size" }, "height": { "name": "height" }, "image": { "name": "image" }, "length": { "name": "length" }, "negative": { "name": "negative" }, "positive": { "name": "positive" }, "strength": { "name": "force" }, "vae": { "name": "vae" }, "width": { "name": "width" } }, "outputs": { "0": { "name": "positive", "tooltip": null }, "1": { "name": "negative", "tooltip": null }, "2": { "name": "latent", "tooltip": null } } };
const LTXVPreprocess = { "display_name": "LTXVPreprocess", "inputs": { "image": { "name": "image" }, "img_compression": { "name": "compression_d'image", "tooltip": "Quantité de compression à appliquer sur l'image." } }, "outputs": { "0": { "name": "image_de_sortie", "tooltip": null } } };
const LTXVScheduler = { "display_name": "LTXVScheduler", "inputs": { "base_shift": { "name": "décalage_base" }, "latent": { "name": "latent" }, "max_shift": { "name": "décalage_max" }, "steps": { "name": "étapes" }, "stretch": { "name": "étirement", "tooltip": "Étirez les sigmas pour être dans la plage [terminal, 1]." }, "terminal": { "name": "terminal", "tooltip": "La valeur terminale des sigmas après étirement." } }, "outputs": { "0": { "tooltip": null } } };
const LaplaceScheduler = { "display_name": "LaplaceScheduler", "inputs": { "beta": { "name": "beta" }, "mu": { "name": "mu" }, "sigma_max": { "name": "sigma_max" }, "sigma_min": { "name": "sigma_min" }, "steps": { "name": "steps" } } };
const LatentAdd = { "display_name": "LatentAdd", "inputs": { "samples1": { "name": "samples1" }, "samples2": { "name": "samples2" } }, "outputs": { "0": { "tooltip": null } } };
const LatentApplyOperation = { "display_name": "LatentApplyOperation", "inputs": { "operation": { "name": "operation" }, "samples": { "name": "samples" } }, "outputs": { "0": { "tooltip": null } } };
const LatentApplyOperationCFG = { "display_name": "LatentApplyOperationCFG", "inputs": { "model": { "name": "model" }, "operation": { "name": "operation" } }, "outputs": { "0": { "tooltip": null } } };
const LatentBatch = { "display_name": "LatentBatch", "inputs": { "samples1": { "name": "échantillons1" }, "samples2": { "name": "échantillons2" } }, "outputs": { "0": { "tooltip": null } } };
const LatentBatchSeedBehavior = { "display_name": "Comportement de la Graine LatentBatch", "inputs": { "samples": { "name": "échantillons" }, "seed_behavior": { "name": "comportement_de_graine" } }, "outputs": { "0": { "tooltip": null } } };
const LatentBlend = { "display_name": "Mélange Latent", "inputs": { "blend_factor": { "name": "facteur_de_mélange" }, "samples1": { "name": "échantillons1" }, "samples2": { "name": "échantillons2" } } };
const LatentComposite = { "display_name": "Composite Latent", "inputs": { "feather": { "name": "plume" }, "samples_from": { "name": "échantillons_de" }, "samples_to": { "name": "échantillons_vers" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const LatentCompositeMasked = { "display_name": "Composite Latent Masqué", "inputs": { "destination": { "name": "destination" }, "mask": { "name": "masque" }, "resize_source": { "name": "redimensionner_source" }, "source": { "name": "source" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const LatentConcat = { "display_name": "ConcaténationLatente", "inputs": { "dim": { "name": "dim" }, "samples1": { "name": "échantillons1" }, "samples2": { "name": "échantillons2" } }, "outputs": { "0": { "tooltip": null } } };
const LatentCrop = { "display_name": "Couper Latent", "inputs": { "height": { "name": "hauteur" }, "samples": { "name": "échantillons" }, "width": { "name": "largeur" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const LatentCut = { "display_name": "CoupeLatente", "inputs": { "amount": { "name": "quantité" }, "dim": { "name": "dim" }, "index": { "name": "index" }, "samples": { "name": "échantillons" } }, "outputs": { "0": { "tooltip": null } } };
const LatentFlip = { "display_name": "Retourner Latent", "inputs": { "flip_method": { "name": "méthode_de_retournement" }, "samples": { "name": "échantillons" } } };
const LatentFromBatch = { "display_name": "Latent De Batch", "inputs": { "batch_index": { "name": "index_de_batch" }, "length": { "name": "longueur" }, "samples": { "name": "échantillons" } } };
const LatentInterpolate = { "display_name": "Interpoler Latent", "inputs": { "ratio": { "name": "ratio" }, "samples1": { "name": "échantillons1" }, "samples2": { "name": "échantillons2" } }, "outputs": { "0": { "tooltip": null } } };
const LatentMultiply = { "display_name": "Multiplier Latent", "inputs": { "multiplier": { "name": "multiplicateur" }, "samples": { "name": "échantillons" } }, "outputs": { "0": { "tooltip": null } } };
const LatentOperationSharpen = { "display_name": "Opération d'Affûtage Latent", "inputs": { "alpha": { "name": "alpha" }, "sharpen_radius": { "name": "rayon_d'affûtage" }, "sigma": { "name": "sigma" } }, "outputs": { "0": { "tooltip": null } } };
const LatentOperationTonemapReinhard = { "display_name": "Opération de Mappage de Tons Reinhard Latent", "inputs": { "multiplier": { "name": "multiplicateur" } }, "outputs": { "0": { "tooltip": null } } };
const LatentRotate = { "display_name": "Tourner Latent", "inputs": { "rotation": { "name": "rotation" }, "samples": { "name": "échantillons" } } };
const LatentSubtract = { "display_name": "Soustraction Latente", "inputs": { "samples1": { "name": "samples1" }, "samples2": { "name": "samples2" } }, "outputs": { "0": { "tooltip": null } } };
const LatentUpscale = { "display_name": "Mise à l'échelle Latente", "inputs": { "crop": { "name": "recadrage" }, "height": { "name": "hauteur" }, "samples": { "name": "samples" }, "upscale_method": { "name": "méthode_de_mise_à_l'échelle" }, "width": { "name": "largeur" } } };
const LatentUpscaleBy = { "display_name": "Mise à l'échelle Latente Par", "inputs": { "samples": { "name": "samples" }, "scale_by": { "name": "mise_à_l'échelle_par" }, "upscale_method": { "name": "méthode_de_mise_à_l'échelle" } } };
const LazyCache = { "description": "Une version maison d'EasyCache - une version encore 'plus facile' d'EasyCache à implémenter. Fonctionne globalement moins bien qu'EasyCache, mais mieux dans certains cas rares ET une compatibilité universelle avec tout dans ComfyUI.", "display_name": "CacheParesseux", "inputs": { "end_percent": { "name": "pourcentage_fin", "tooltip": "L'étape d'échantillonnage relative pour terminer l'utilisation de CacheParesseux." }, "model": { "name": "modèle", "tooltip": "Le modèle auquel ajouter CacheParesseux." }, "reuse_threshold": { "name": "seuil_réutilisation", "tooltip": "Le seuil pour réutiliser les étapes mises en cache." }, "start_percent": { "name": "pourcentage_début", "tooltip": "L'étape d'échantillonnage relative pour commencer l'utilisation de CacheParesseux." }, "verbose": { "name": "verbeux", "tooltip": "Indique s'il faut enregistrer des informations détaillées." } }, "outputs": { "0": { "tooltip": "Le modèle avec CacheParesseux." } } };
const Load3D = { "display_name": "Charger 3D", "inputs": { "clear": {}, "height": { "name": "hauteur" }, "image": { "name": "image" }, "model_file": { "name": "fichier_modèle" }, "upload 3d model": {}, "width": { "name": "largeur" } }, "outputs": { "0": { "name": "image" }, "1": { "name": "masque" }, "2": { "name": "chemin_maillage" }, "3": { "name": "normale" }, "4": { "name": "lineart" }, "5": { "name": "info_caméra" } } };
const LoadAudio = { "display_name": "ChargerAudio", "inputs": { "audio": { "name": "audio" }, "audioUI": { "name": "audioUI" }, "upload": { "name": "choisissez le fichier à télécharger" } } };
const LoadImage = { "display_name": "Charger Image", "inputs": { "image": { "name": "image" }, "upload": { "name": "choisissez le fichier à télécharger" } } };
const LoadImageMask = { "display_name": "Charger Image (comme Masque)", "inputs": { "channel": { "name": "canal" }, "image": { "name": "image" }, "upload": { "name": "choisissez le fichier à télécharger" } } };
const LoadImageOutput = { "description": "Chargez une image à partir du dossier de sortie. Lorsque le bouton de rafraîchissement est cliqué, le nœud mettra à jour la liste des images et sélectionnera automatiquement la première image, permettant une itération facile.", "display_name": "Charger l'image (à partir des sorties)", "inputs": { "image": { "name": "image" }, "refresh": {}, "upload": { "name": "choisissez le fichier à télécharger" } } };
const LoadLatent = { "display_name": "ChargerLatent", "inputs": { "latent": { "name": "latent" } } };
const LoadVideo = { "display_name": "Charger une vidéo", "inputs": { "file": { "name": "fichier" }, "upload": { "name": "choisir un fichier à télécharger" } }, "outputs": { "0": { "tooltip": null } } };
const LoraLoader = { "description": "Les LoRAs sont utilisés pour modifier les modèles de diffusion et CLIP, modifiant la manière dont les latents sont débruités comme l'application de styles. Plusieurs nœuds LoRA peuvent être liés ensemble.", "display_name": "Charger LoRA", "inputs": { "clip": { "name": "clip", "tooltip": "Le modèle CLIP auquel le LoRA sera appliqué." }, "lora_name": { "name": "lora_name", "tooltip": "Le nom du LoRA." }, "model": { "name": "model", "tooltip": "Le modèle de diffusion auquel le LoRA sera appliqué." }, "strength_clip": { "name": "strength_clip", "tooltip": "À quel point modifier le modèle CLIP. Cette valeur peut être négative." }, "strength_model": { "name": "strength_model", "tooltip": "À quel point modifier le modèle de diffusion. Cette valeur peut être négative." } }, "outputs": { "0": { "tooltip": "Le modèle de diffusion modifié." }, "1": { "tooltip": "Le modèle CLIP modifié." } } };
const LoraLoaderModelOnly = { "description": "Les LoRAs sont utilisés pour modifier les modèles de diffusion et CLIP, modifiant la manière dont les latents sont débruités comme l'application de styles. Plusieurs nœuds LoRA peuvent être liés ensemble.", "display_name": "LoraLoaderModelOnly", "inputs": { "lora_name": { "name": "lora_name" }, "model": { "name": "model" }, "strength_model": { "name": "strength_model" } }, "outputs": { "0": { "tooltip": "Le modèle de diffusion modifié." } } };
const LoraModelLoader = { "display_name": "Charger le modèle LoRA", "inputs": { "lora": { "name": "lora", "tooltip": "Le modèle LoRA à appliquer au modèle de diffusion." }, "model": { "name": "modèle", "tooltip": "Le modèle de diffusion auquel le LoRA sera appliqué." }, "strength_model": { "name": "intensité_modèle", "tooltip": "Intensité de modification du modèle de diffusion. Cette valeur peut être négative." } }, "outputs": { "0": { "tooltip": "Le modèle de diffusion modifié." } } };
const LoraSave = { "display_name": "Extraire et Sauvegarder Lora", "inputs": { "bias_diff": { "name": "bias_diff" }, "filename_prefix": { "name": "filename_prefix" }, "lora_type": { "name": "lora_type" }, "model_diff": { "name": "model_diff", "tooltip": "La sortie ModelSubtract à convertir en lora." }, "rank": { "name": "rank" }, "text_encoder_diff": { "name": "text_encoder_diff", "tooltip": "La sortie CLIPSubtract à convertir en lora." } } };
const LossGraphNode = { "display_name": "Tracer le graphique de perte", "inputs": { "filename_prefix": { "name": "préfixe_nom_fichier" }, "loss": { "name": "perte" } } };
const LotusConditioning = { "display_name": "LotusConditioning", "outputs": { "0": { "name": "conditionnement", "tooltip": null } } };
const LtxvApiImageToVideo = { "description": "Vidéos de qualité professionnelle avec durée et résolution personnalisables basées sur l'image de départ.", "display_name": "LTXV Image vers Vidéo", "inputs": { "duration": { "name": "durée" }, "fps": { "name": "ips" }, "generate_audio": { "name": "générer_audio", "tooltip": "Lorsque activé, la vidéo générée inclura un audio généré par IA correspondant à la scène." }, "image": { "name": "image", "tooltip": "Première image à utiliser pour la vidéo." }, "model": { "name": "modèle" }, "prompt": { "name": "prompt" }, "resolution": { "name": "résolution" } }, "outputs": { "0": { "tooltip": null } } };
const LtxvApiTextToVideo = { "description": "Vidéos de qualité professionnelle avec durée et résolution personnalisables.", "display_name": "LTXV Texte vers Vidéo", "inputs": { "duration": { "name": "durée" }, "fps": { "name": "ips" }, "generate_audio": { "name": "générer_audio", "tooltip": "Lorsque activé, la vidéo générée inclura un audio généré par IA correspondant à la scène." }, "model": { "name": "modèle" }, "prompt": { "name": "prompt" }, "resolution": { "name": "résolution" } }, "outputs": { "0": { "tooltip": null } } };
const LumaConceptsNode = { "description": "Contient un ou plusieurs Concepts de Caméra à utiliser avec les nœuds Luma Text to Video et Luma Image to Video.", "display_name": "Luma Concepts", "inputs": { "concept1": { "name": "concept1" }, "concept2": { "name": "concept2" }, "concept3": { "name": "concept3" }, "concept4": { "name": "concept4" }, "luma_concepts": { "name": "luma_concepts", "tooltip": "Concepts de Caméra optionnels à ajouter à ceux sélectionnés ici." } }, "outputs": { "0": { "name": "luma_concepts", "tooltip": null } } };
const LumaImageModifyNode = { "description": "Modifie les images de manière synchrone en fonction du prompt et du format d'image.", "display_name": "Luma Image vers Image", "inputs": { "control_after_generate": { "name": "contrôle après génération" }, "image": { "name": "image" }, "image_weight": { "name": "poids de l'image", "tooltip": "Poids de l'image ; plus la valeur est proche de 1.0, moins l'image sera modifiée." }, "model": { "name": "modèle" }, "prompt": { "name": "prompt", "tooltip": "Prompt pour la génération d'image" }, "seed": { "name": "graine", "tooltip": "Graine pour déterminer si le nœud doit être relancé ; les résultats réels sont non déterministes quel que soit la graine." } }, "outputs": { "0": { "tooltip": null } } };
const LumaImageNode = { "description": "Génère des images de manière synchrone à partir d'une invite et d'un ratio d'aspect.", "display_name": "Luma Texte vers Image", "inputs": { "aspect_ratio": { "name": "ratio_d'aspect" }, "character_image": { "name": "image_de_personnage", "tooltip": "Images de référence de personnage ; peut être un lot de plusieurs, jusqu'à 4 images peuvent être prises en compte." }, "control_after_generate": { "name": "contrôle après génération" }, "image_luma_ref": { "name": "référence_image_luma", "tooltip": "Connexion au nœud de référence Luma pour influencer la génération avec des images d'entrée ; jusqu'à 4 images peuvent être prises en compte." }, "model": { "name": "modèle" }, "prompt": { "name": "invite", "tooltip": "Invite pour la génération d'image" }, "seed": { "name": "graine", "tooltip": "Graine pour déterminer si le nœud doit être relancé ; les résultats réels restent non déterministes, quelle que soit la graine." }, "style_image": { "name": "image_de_style", "tooltip": "Image de référence de style ; seule 1 image sera utilisée." }, "style_image_weight": { "name": "poids_image_de_style", "tooltip": "Poids de l'image de style. Ignoré si aucune image de style n'est fournie." } }, "outputs": { "0": { "tooltip": null } } };
const LumaImageToVideoNode = { "description": "Génère des vidéos de manière synchrone à partir d'un prompt, d'images d'entrée et de la taille de sortie.", "display_name": "Luma Image to Video", "inputs": { "control_after_generate": { "name": "contrôle après génération" }, "duration": { "name": "durée" }, "first_image": { "name": "première_image", "tooltip": "Première image de la vidéo générée." }, "last_image": { "name": "dernière_image", "tooltip": "Dernière image de la vidéo générée." }, "loop": { "name": "boucle" }, "luma_concepts": { "name": "luma_concepts", "tooltip": "Concepts de caméra optionnels pour dicter le mouvement de la caméra via le nœud Luma Concepts." }, "model": { "name": "modèle" }, "prompt": { "name": "prompt", "tooltip": "Prompt pour la génération de la vidéo" }, "resolution": { "name": "résolution" }, "seed": { "name": "seed", "tooltip": "Seed pour déterminer si le nœud doit être relancé ; les résultats réels restent non déterministes quel que soit le seed." } }, "outputs": { "0": { "tooltip": null } } };
const LumaReferenceNode = { "description": "Contient une image et un poids à utiliser avec le nœud Luma Générer Image.", "display_name": "Référence Luma", "inputs": { "image": { "name": "image", "tooltip": "Image à utiliser comme référence." }, "luma_ref": { "name": "luma_ref" }, "weight": { "name": "poids", "tooltip": "Poids de la référence d'image." } }, "outputs": { "0": { "name": "luma_ref", "tooltip": null } } };
const LumaVideoNode = { "description": "Génère des vidéos de manière synchrone à partir du prompt et de la taille de sortie.", "display_name": "Luma Texte vers Vidéo", "inputs": { "aspect_ratio": { "name": "rapport d'aspect" }, "control_after_generate": { "name": "contrôle après génération" }, "duration": { "name": "durée" }, "loop": { "name": "boucle" }, "luma_concepts": { "name": "luma_concepts", "tooltip": "Concepts de caméra optionnels pour dicter le mouvement de la caméra via le nœud Luma Concepts." }, "model": { "name": "modèle" }, "prompt": { "name": "prompt", "tooltip": "Prompt pour la génération de la vidéo" }, "resolution": { "name": "résolution" }, "seed": { "name": "graine", "tooltip": "Graine pour déterminer si le nœud doit être relancé ; les résultats réels restent non déterministes quelle que soit la graine." } }, "outputs": { "0": { "tooltip": null } } };
const Mahiro = { "description": "Modifiez le guidage pour qu'il se concentre davantage sur la 'direction' de l'invite positive plutôt que sur la différence avec l'invite négative.", "display_name": "Mahiro est si mignonne qu'elle mérite une meilleure fonction de guidage!! (。・ω・。)", "inputs": { "model": { "name": "modèle" } }, "outputs": { "0": { "name": "modèle_modifié", "tooltip": null } } };
const MaskComposite = { "display_name": "MaskComposite", "inputs": { "destination": { "name": "destination" }, "operation": { "name": "opération" }, "source": { "name": "source" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const MaskPreview = { "description": "Enregistre les images d'entrée dans votre répertoire de sortie ComfyUI.", "display_name": "MaskPreview", "inputs": { "mask": { "name": "mask" } } };
const MaskToImage = { "display_name": "Convertir le masque en image", "inputs": { "mask": { "name": "masque" } } };
const MinimaxHailuoVideoNode = { "description": "Génère des vidéos à partir d'un prompt, avec option d'image de départ utilisant le nouveau modèle MiniMax Hailuo-02.", "display_name": "MiniMax Hailuo Vidéo", "inputs": { "control_after_generate": { "name": "contrôle après génération" }, "duration": { "name": "durée", "tooltip": "La longueur de la vidéo de sortie en secondes." }, "first_frame_image": { "name": "image_premiere_frame", "tooltip": "Image optionnelle à utiliser comme première frame pour générer une vidéo." }, "prompt_optimizer": { "name": "optimiseur_prompt", "tooltip": "Optimiser le prompt pour améliorer la qualité de génération si nécessaire." }, "prompt_text": { "name": "texte_prompt", "tooltip": "Invite textuelle pour guider la génération de la vidéo." }, "resolution": { "name": "résolution", "tooltip": "Les dimensions de l'affichage vidéo. 1080p correspond à 1920x1080, 768p à 1366x768." }, "seed": { "name": "graine", "tooltip": "La graine aléatoire utilisée pour créer le bruit." } }, "outputs": { "0": { "tooltip": null } } };
const MinimaxImageToVideoNode = { "description": "Génère des vidéos à partir d'une image et d'invites en utilisant l'API de MiniMax", "display_name": "MiniMax Image vers Vidéo", "inputs": { "control_after_generate": { "name": "contrôle après génération" }, "image": { "name": "image", "tooltip": "Image à utiliser comme première image pour la génération de vidéo" }, "model": { "name": "modèle", "tooltip": "Modèle à utiliser pour la génération de vidéo" }, "prompt_text": { "name": "texte d'invite", "tooltip": "Texte d'invite pour guider la génération de la vidéo" }, "seed": { "name": "graine", "tooltip": "La graine aléatoire utilisée pour créer le bruit." } }, "outputs": { "0": { "tooltip": null } } };
const MinimaxTextToVideoNode = { "description": "Génère des vidéos à partir d'invites en utilisant l'API de MiniMax", "display_name": "MiniMax Texte en Vidéo", "inputs": { "control_after_generate": { "name": "contrôle après génération" }, "model": { "name": "modèle", "tooltip": "Modèle à utiliser pour la génération de vidéo" }, "prompt_text": { "name": "texte d'invite", "tooltip": "Texte d'invite pour guider la génération de la vidéo" }, "seed": { "name": "graine", "tooltip": "La graine aléatoire utilisée pour créer le bruit." } }, "outputs": { "0": { "tooltip": null } } };
const ModelComputeDtype = { "display_name": "ModelComputeDtype", "inputs": { "dtype": { "name": "dtype" }, "model": { "name": "modèle" } } };
const ModelMergeAdd = { "display_name": "ModelMergeAdd", "inputs": { "model1": { "name": "modèle1" }, "model2": { "name": "modèle2" } } };
const ModelMergeAuraflow = { "display_name": "ModelMergeAuraflow", "inputs": { "cond_seq_linear_": { "name": "cond_seq_linear." }, "double_layers_0_": { "name": "double_layers.0." }, "double_layers_1_": { "name": "double_layers.1." }, "double_layers_2_": { "name": "double_layers.2." }, "double_layers_3_": { "name": "double_layers.3." }, "final_linear_": { "name": "final_linear." }, "init_x_linear_": { "name": "init_x_linear." }, "modF_": { "name": "modF." }, "model1": { "name": "model1" }, "model2": { "name": "model2" }, "positional_encoding": { "name": "codage_positionnel" }, "register_tokens": { "name": "enregistrer_tokens" }, "single_layers_0_": { "name": "single_layers.0." }, "single_layers_10_": { "name": "single_layers.10." }, "single_layers_11_": { "name": "single_layers.11." }, "single_layers_12_": { "name": "single_layers.12." }, "single_layers_13_": { "name": "single_layers.13." }, "single_layers_14_": { "name": "single_layers.14." }, "single_layers_15_": { "name": "single_layers.15." }, "single_layers_16_": { "name": "single_layers.16." }, "single_layers_17_": { "name": "single_layers.17." }, "single_layers_18_": { "name": "single_layers.18." }, "single_layers_19_": { "name": "single_layers.19." }, "single_layers_1_": { "name": "single_layers.1." }, "single_layers_20_": { "name": "single_layers.20." }, "single_layers_21_": { "name": "single_layers.21." }, "single_layers_22_": { "name": "single_layers.22." }, "single_layers_23_": { "name": "single_layers.23." }, "single_layers_24_": { "name": "single_layers.24." }, "single_layers_25_": { "name": "single_layers.25." }, "single_layers_26_": { "name": "single_layers.26." }, "single_layers_27_": { "name": "single_layers.27." }, "single_layers_28_": { "name": "single_layers.28." }, "single_layers_29_": { "name": "single_layers.29." }, "single_layers_2_": { "name": "single_layers.2." }, "single_layers_30_": { "name": "single_layers.30." }, "single_layers_31_": { "name": "single_layers.31." }, "single_layers_3_": { "name": "single_layers.3." }, "single_layers_4_": { "name": "single_layers.4." }, "single_layers_5_": { "name": "single_layers.5." }, "single_layers_6_": { "name": "single_layers.6." }, "single_layers_7_": { "name": "single_layers.7." }, "single_layers_8_": { "name": "single_layers.8." }, "single_layers_9_": { "name": "single_layers.9." }, "t_embedder_": { "name": "t_embedder." } } };
const ModelMergeBlocks = { "display_name": "ModelMergeBlocks", "inputs": { "input": { "name": "entrée" }, "middle": { "name": "milieu" }, "model1": { "name": "modèle1" }, "model2": { "name": "modèle2" }, "out": { "name": "sortie" } } };
const ModelMergeCosmos14B = { "display_name": "ModelMergeCosmos14B", "inputs": { "affline_norm_": { "name": "affline_norm." }, "blocks_block0_": { "name": "blocks.block0." }, "blocks_block10_": { "name": "blocks.block10." }, "blocks_block11_": { "name": "blocks.block11." }, "blocks_block12_": { "name": "blocks.block12." }, "blocks_block13_": { "name": "blocks.block13." }, "blocks_block14_": { "name": "blocks.block14." }, "blocks_block15_": { "name": "blocks.block15." }, "blocks_block16_": { "name": "blocks.block16." }, "blocks_block17_": { "name": "blocks.block17." }, "blocks_block18_": { "name": "blocks.block18." }, "blocks_block19_": { "name": "blocks.block19." }, "blocks_block1_": { "name": "blocks.block1." }, "blocks_block20_": { "name": "blocks.block20." }, "blocks_block21_": { "name": "blocks.block21." }, "blocks_block22_": { "name": "blocks.block22." }, "blocks_block23_": { "name": "blocks.block23." }, "blocks_block24_": { "name": "blocks.block24." }, "blocks_block25_": { "name": "blocks.block25." }, "blocks_block26_": { "name": "blocks.block26." }, "blocks_block27_": { "name": "blocks.block27." }, "blocks_block28_": { "name": "blocks.block28." }, "blocks_block29_": { "name": "blocks.block29." }, "blocks_block2_": { "name": "blocks.block2." }, "blocks_block30_": { "name": "blocks.block30." }, "blocks_block31_": { "name": "blocks.block31." }, "blocks_block32_": { "name": "blocks.block32." }, "blocks_block33_": { "name": "blocks.block33." }, "blocks_block34_": { "name": "blocks.block34." }, "blocks_block35_": { "name": "blocks.block35." }, "blocks_block3_": { "name": "blocks.block3." }, "blocks_block4_": { "name": "blocks.block4." }, "blocks_block5_": { "name": "blocks.block5." }, "blocks_block6_": { "name": "blocks.block6." }, "blocks_block7_": { "name": "blocks.block7." }, "blocks_block8_": { "name": "blocks.block8." }, "blocks_block9_": { "name": "blocks.block9." }, "extra_pos_embedder_": { "name": "extra_pos_embedder." }, "final_layer_": { "name": "couche_finale." }, "model1": { "name": "modèle1" }, "model2": { "name": "modèle2" }, "pos_embedder_": { "name": "pos_embedder." }, "t_embedder_": { "name": "t_embedder." }, "x_embedder_": { "name": "x_embedder." } } };
const ModelMergeCosmos7B = { "display_name": "ModelMergeCosmos7B", "inputs": { "affline_norm_": { "name": "affline_norm." }, "blocks_block0_": { "name": "blocks.block0." }, "blocks_block10_": { "name": "blocks.block10." }, "blocks_block11_": { "name": "blocks.block11." }, "blocks_block12_": { "name": "blocks.block12." }, "blocks_block13_": { "name": "blocks.block13." }, "blocks_block14_": { "name": "blocks.block14." }, "blocks_block15_": { "name": "blocks.block15." }, "blocks_block16_": { "name": "blocks.block16." }, "blocks_block17_": { "name": "blocks.block17." }, "blocks_block18_": { "name": "blocks.block18." }, "blocks_block19_": { "name": "blocks.block19." }, "blocks_block1_": { "name": "blocks.block1." }, "blocks_block20_": { "name": "blocks.block20." }, "blocks_block21_": { "name": "blocks.block21." }, "blocks_block22_": { "name": "blocks.block22." }, "blocks_block23_": { "name": "blocks.block23." }, "blocks_block24_": { "name": "blocks.block24." }, "blocks_block25_": { "name": "blocks.block25." }, "blocks_block26_": { "name": "blocks.block26." }, "blocks_block27_": { "name": "blocks.block27." }, "blocks_block2_": { "name": "blocks.block2." }, "blocks_block3_": { "name": "blocks.block3." }, "blocks_block4_": { "name": "blocks.block4." }, "blocks_block5_": { "name": "blocks.block5." }, "blocks_block6_": { "name": "blocks.block6." }, "blocks_block7_": { "name": "blocks.block7." }, "blocks_block8_": { "name": "blocks.block8." }, "blocks_block9_": { "name": "blocks.block9." }, "extra_pos_embedder_": { "name": "extra_pos_embedder." }, "final_layer_": { "name": "final_layer." }, "model1": { "name": "model1" }, "model2": { "name": "model2" }, "pos_embedder_": { "name": "pos_embedder." }, "t_embedder_": { "name": "t_embedder." }, "x_embedder_": { "name": "x_embedder." } } };
const ModelMergeCosmosPredict2_14B = { "display_name": "ModelMergeCosmosPredict2_14B", "inputs": { "blocks_0_": { "name": "blocs.0." }, "blocks_10_": { "name": "blocs.10." }, "blocks_11_": { "name": "blocs.11." }, "blocks_12_": { "name": "blocs.12." }, "blocks_13_": { "name": "blocs.13." }, "blocks_14_": { "name": "blocs.14." }, "blocks_15_": { "name": "blocs.15." }, "blocks_16_": { "name": "blocs.16." }, "blocks_17_": { "name": "blocs.17." }, "blocks_18_": { "name": "blocs.18." }, "blocks_19_": { "name": "blocs.19." }, "blocks_1_": { "name": "blocs.1." }, "blocks_20_": { "name": "blocs.20." }, "blocks_21_": { "name": "blocs.21." }, "blocks_22_": { "name": "blocs.22." }, "blocks_23_": { "name": "blocs.23." }, "blocks_24_": { "name": "blocs.24." }, "blocks_25_": { "name": "blocs.25." }, "blocks_26_": { "name": "blocs.26." }, "blocks_27_": { "name": "blocs.27." }, "blocks_28_": { "name": "blocs.28." }, "blocks_29_": { "name": "blocs.29." }, "blocks_2_": { "name": "blocs.2." }, "blocks_30_": { "name": "blocs.30." }, "blocks_31_": { "name": "blocs.31." }, "blocks_32_": { "name": "blocs.32." }, "blocks_33_": { "name": "blocs.33." }, "blocks_34_": { "name": "blocs.34." }, "blocks_35_": { "name": "blocs.35." }, "blocks_3_": { "name": "blocs.3." }, "blocks_4_": { "name": "blocs.4." }, "blocks_5_": { "name": "blocs.5." }, "blocks_6_": { "name": "blocs.6." }, "blocks_7_": { "name": "blocs.7." }, "blocks_8_": { "name": "blocs.8." }, "blocks_9_": { "name": "blocs.9." }, "final_layer_": { "name": "couche_finale." }, "model1": { "name": "modèle1" }, "model2": { "name": "modèle2" }, "pos_embedder_": { "name": "pos_embedder." }, "t_embedder_": { "name": "t_embedder." }, "t_embedding_norm_": { "name": "t_embedding_norm." }, "x_embedder_": { "name": "x_embedder." } } };
const ModelMergeCosmosPredict2_2B = { "display_name": "FusionModèleCosmosPredict2_2B", "inputs": { "blocks_0_": { "name": "blocs.0." }, "blocks_10_": { "name": "blocs.10." }, "blocks_11_": { "name": "blocs.11." }, "blocks_12_": { "name": "blocs.12." }, "blocks_13_": { "name": "blocs.13." }, "blocks_14_": { "name": "blocs.14." }, "blocks_15_": { "name": "blocs.15." }, "blocks_16_": { "name": "blocs.16." }, "blocks_17_": { "name": "blocs.17." }, "blocks_18_": { "name": "blocs.18." }, "blocks_19_": { "name": "blocs.19." }, "blocks_1_": { "name": "blocs.1." }, "blocks_20_": { "name": "blocs.20." }, "blocks_21_": { "name": "blocs.21." }, "blocks_22_": { "name": "blocs.22." }, "blocks_23_": { "name": "blocs.23." }, "blocks_24_": { "name": "blocs.24." }, "blocks_25_": { "name": "blocs.25." }, "blocks_26_": { "name": "blocs.26." }, "blocks_27_": { "name": "blocs.27." }, "blocks_2_": { "name": "blocs.2." }, "blocks_3_": { "name": "blocs.3." }, "blocks_4_": { "name": "blocs.4." }, "blocks_5_": { "name": "blocs.5." }, "blocks_6_": { "name": "blocs.6." }, "blocks_7_": { "name": "blocs.7." }, "blocks_8_": { "name": "blocs.8." }, "blocks_9_": { "name": "blocs.9." }, "final_layer_": { "name": "couche_finale." }, "model1": { "name": "modèle1" }, "model2": { "name": "modèle2" }, "pos_embedder_": { "name": "intégrateur_pos." }, "t_embedder_": { "name": "intégrateur_t." }, "t_embedding_norm_": { "name": "normalisation_intégration_t." }, "x_embedder_": { "name": "intégrateur_x." } } };
const ModelMergeFlux1 = { "display_name": "ModelMergeFlux1", "inputs": { "double_blocks_0_": { "name": "double_blocks.0." }, "double_blocks_10_": { "name": "double_blocks.10." }, "double_blocks_11_": { "name": "double_blocks.11." }, "double_blocks_12_": { "name": "double_blocks.12." }, "double_blocks_13_": { "name": "double_blocks.13." }, "double_blocks_14_": { "name": "double_blocks.14." }, "double_blocks_15_": { "name": "double_blocks.15." }, "double_blocks_16_": { "name": "double_blocks.16." }, "double_blocks_17_": { "name": "double_blocks.17." }, "double_blocks_18_": { "name": "double_blocks.18." }, "double_blocks_1_": { "name": "double_blocks.1." }, "double_blocks_2_": { "name": "double_blocks.2." }, "double_blocks_3_": { "name": "double_blocks.3." }, "double_blocks_4_": { "name": "double_blocks.4." }, "double_blocks_5_": { "name": "double_blocks.5." }, "double_blocks_6_": { "name": "double_blocks.6." }, "double_blocks_7_": { "name": "double_blocks.7." }, "double_blocks_8_": { "name": "double_blocks.8." }, "double_blocks_9_": { "name": "double_blocks.9." }, "final_layer_": { "name": "final_layer." }, "guidance_in": { "name": "guidance_in" }, "img_in_": { "name": "img_in." }, "model1": { "name": "model1" }, "model2": { "name": "model2" }, "single_blocks_0_": { "name": "single_blocks.0." }, "single_blocks_10_": { "name": "single_blocks.10." }, "single_blocks_11_": { "name": "single_blocks.11." }, "single_blocks_12_": { "name": "single_blocks.12." }, "single_blocks_13_": { "name": "single_blocks.13." }, "single_blocks_14_": { "name": "single_blocks.14." }, "single_blocks_15_": { "name": "single_blocks.15." }, "single_blocks_16_": { "name": "single_blocks.16." }, "single_blocks_17_": { "name": "single_blocks.17." }, "single_blocks_18_": { "name": "single_blocks.18." }, "single_blocks_19_": { "name": "single_blocks.19." }, "single_blocks_1_": { "name": "single_blocks.1." }, "single_blocks_20_": { "name": "single_blocks.20." }, "single_blocks_21_": { "name": "single_blocks.21." }, "single_blocks_22_": { "name": "single_blocks.22." }, "single_blocks_23_": { "name": "single_blocks.23." }, "single_blocks_24_": { "name": "single_blocks.24." }, "single_blocks_25_": { "name": "single_blocks.25." }, "single_blocks_26_": { "name": "single_blocks.26." }, "single_blocks_27_": { "name": "single_blocks.27." }, "single_blocks_28_": { "name": "single_blocks.28." }, "single_blocks_29_": { "name": "single_blocks.29." }, "single_blocks_2_": { "name": "single_blocks.2." }, "single_blocks_30_": { "name": "single_blocks.30." }, "single_blocks_31_": { "name": "single_blocks.31." }, "single_blocks_32_": { "name": "single_blocks.32." }, "single_blocks_33_": { "name": "single_blocks.33." }, "single_blocks_34_": { "name": "single_blocks.34." }, "single_blocks_35_": { "name": "single_blocks.35." }, "single_blocks_36_": { "name": "single_blocks.36." }, "single_blocks_37_": { "name": "single_blocks.37." }, "single_blocks_3_": { "name": "single_blocks.3." }, "single_blocks_4_": { "name": "single_blocks.4." }, "single_blocks_5_": { "name": "single_blocks.5." }, "single_blocks_6_": { "name": "single_blocks.6." }, "single_blocks_7_": { "name": "single_blocks.7." }, "single_blocks_8_": { "name": "single_blocks.8." }, "single_blocks_9_": { "name": "single_blocks.9." }, "time_in_": { "name": "time_in." }, "txt_in_": { "name": "txt_in." }, "vector_in_": { "name": "vector_in." } } };
const ModelMergeLTXV = { "display_name": "ModelMergeLTXV", "inputs": { "adaln_single_": { "name": "adaln_single." }, "caption_projection_": { "name": "projection_de_légende." }, "model1": { "name": "model1" }, "model2": { "name": "model2" }, "patchify_proj_": { "name": "patchify_proj." }, "proj_out_": { "name": "proj_out." }, "scale_shift_table": { "name": "table_de_décalage_d'échelle" }, "transformer_blocks_0_": { "name": "blocs_transformateurs.0." }, "transformer_blocks_10_": { "name": "blocs_transformateurs.10." }, "transformer_blocks_11_": { "name": "blocs_transformateurs.11." }, "transformer_blocks_12_": { "name": "blocs_transformateurs.12." }, "transformer_blocks_13_": { "name": "blocs_transformateurs.13." }, "transformer_blocks_14_": { "name": "blocs_transformateurs.14." }, "transformer_blocks_15_": { "name": "blocs_transformateurs.15." }, "transformer_blocks_16_": { "name": "blocs_transformateurs.16." }, "transformer_blocks_17_": { "name": "blocs_transformateurs.17." }, "transformer_blocks_18_": { "name": "blocs_transformateurs.18." }, "transformer_blocks_19_": { "name": "blocs_transformateurs.19." }, "transformer_blocks_1_": { "name": "blocs_transformateurs.1." }, "transformer_blocks_20_": { "name": "blocs_transformateurs.20." }, "transformer_blocks_21_": { "name": "blocs_transformateurs.21." }, "transformer_blocks_22_": { "name": "blocs_transformateurs.22." }, "transformer_blocks_23_": { "name": "blocs_transformateurs.23." }, "transformer_blocks_24_": { "name": "blocs_transformateurs.24." }, "transformer_blocks_25_": { "name": "blocs_transformateurs.25." }, "transformer_blocks_26_": { "name": "blocs_transformateurs.26." }, "transformer_blocks_27_": { "name": "blocs_transformateurs.27." }, "transformer_blocks_2_": { "name": "blocs_transformateurs.2." }, "transformer_blocks_3_": { "name": "blocs_transformateurs.3." }, "transformer_blocks_4_": { "name": "blocs_transformateurs.4." }, "transformer_blocks_5_": { "name": "blocs_transformateurs.5." }, "transformer_blocks_6_": { "name": "blocs_transformateurs.6." }, "transformer_blocks_7_": { "name": "blocs_transformateurs.7." }, "transformer_blocks_8_": { "name": "blocs_transformateurs.8." }, "transformer_blocks_9_": { "name": "blocs_transformateurs.9." } } };
const ModelMergeMochiPreview = { "display_name": "Aperçu de la Fusion de Modèles Mochi", "inputs": { "blocks_0_": { "name": "blocs.0." }, "blocks_10_": { "name": "blocs.10." }, "blocks_11_": { "name": "blocs.11." }, "blocks_12_": { "name": "blocs.12." }, "blocks_13_": { "name": "blocs.13." }, "blocks_14_": { "name": "blocs.14." }, "blocks_15_": { "name": "blocs.15." }, "blocks_16_": { "name": "blocs.16." }, "blocks_17_": { "name": "blocs.17." }, "blocks_18_": { "name": "blocs.18." }, "blocks_19_": { "name": "blocs.19." }, "blocks_1_": { "name": "blocs.1." }, "blocks_20_": { "name": "blocs.20." }, "blocks_21_": { "name": "blocs.21." }, "blocks_22_": { "name": "blocs.22." }, "blocks_23_": { "name": "blocs.23." }, "blocks_24_": { "name": "blocs.24." }, "blocks_25_": { "name": "blocs.25." }, "blocks_26_": { "name": "blocs.26." }, "blocks_27_": { "name": "blocs.27." }, "blocks_28_": { "name": "blocs.28." }, "blocks_29_": { "name": "blocs.29." }, "blocks_2_": { "name": "blocs.2." }, "blocks_30_": { "name": "blocs.30." }, "blocks_31_": { "name": "blocs.31." }, "blocks_32_": { "name": "blocs.32." }, "blocks_33_": { "name": "blocs.33." }, "blocks_34_": { "name": "blocs.34." }, "blocks_35_": { "name": "blocs.35." }, "blocks_36_": { "name": "blocs.36." }, "blocks_37_": { "name": "blocs.37." }, "blocks_38_": { "name": "blocs.38." }, "blocks_39_": { "name": "blocs.39." }, "blocks_3_": { "name": "blocs.3." }, "blocks_40_": { "name": "blocs.40." }, "blocks_41_": { "name": "blocs.41." }, "blocks_42_": { "name": "blocs.42." }, "blocks_43_": { "name": "blocs.43." }, "blocks_44_": { "name": "blocs.44." }, "blocks_45_": { "name": "blocs.45." }, "blocks_46_": { "name": "blocs.46." }, "blocks_47_": { "name": "blocs.47." }, "blocks_4_": { "name": "blocs.4." }, "blocks_5_": { "name": "blocs.5." }, "blocks_6_": { "name": "blocs.6." }, "blocks_7_": { "name": "blocs.7." }, "blocks_8_": { "name": "blocs.8." }, "blocks_9_": { "name": "blocs.9." }, "final_layer_": { "name": "couche_finale." }, "model1": { "name": "modèle1" }, "model2": { "name": "modèle2" }, "pos_frequencies_": { "name": "pos_frequences." }, "t5_y_embedder_": { "name": "t5_y_embedder." }, "t5_yproj_": { "name": "t5_yproj." }, "t_embedder_": { "name": "t_embedder." } } };
const ModelMergeQwenImage = { "display_name": "FusionModèleQwenImage", "inputs": { "img_in_": { "name": "img_entrée." }, "model1": { "name": "modèle1" }, "model2": { "name": "modèle2" }, "pos_embeds_": { "name": "incrust_pos." }, "proj_out_": { "name": "proj_out." }, "time_text_embed_": { "name": "incrust_texte_temps." }, "transformer_blocks_0_": { "name": "blocs_transformateurs.0." }, "transformer_blocks_10_": { "name": "blocs_transformateurs.10." }, "transformer_blocks_11_": { "name": "blocs_transformateurs.11." }, "transformer_blocks_12_": { "name": "blocs_transformateurs.12." }, "transformer_blocks_13_": { "name": "blocs_transformateurs.13." }, "transformer_blocks_14_": { "name": "blocs_transformateurs.14." }, "transformer_blocks_15_": { "name": "blocs_transformateurs.15." }, "transformer_blocks_16_": { "name": "blocs_transformateurs.16." }, "transformer_blocks_17_": { "name": "blocs_transformateurs.17." }, "transformer_blocks_18_": { "name": "blocs_transformateurs.18." }, "transformer_blocks_19_": { "name": "blocs_transformateurs.19." }, "transformer_blocks_1_": { "name": "blocs_transformateurs.1." }, "transformer_blocks_20_": { "name": "blocs_transformateurs.20." }, "transformer_blocks_21_": { "name": "blocs_transformateurs.21." }, "transformer_blocks_22_": { "name": "blocs_transformateurs.22." }, "transformer_blocks_23_": { "name": "blocs_transformateurs.23." }, "transformer_blocks_24_": { "name": "blocs_transformateurs.24." }, "transformer_blocks_25_": { "name": "blocs_transformateurs.25." }, "transformer_blocks_26_": { "name": "blocs_transformateurs.26." }, "transformer_blocks_27_": { "name": "blocs_transformateurs.27." }, "transformer_blocks_28_": { "name": "blocs_transformateurs.28." }, "transformer_blocks_29_": { "name": "blocs_transformateurs.29." }, "transformer_blocks_2_": { "name": "blocs_transformateurs.2." }, "transformer_blocks_30_": { "name": "blocs_transformateurs.30." }, "transformer_blocks_31_": { "name": "blocs_transformateurs.31." }, "transformer_blocks_32_": { "name": "blocs_transformateurs.32." }, "transformer_blocks_33_": { "name": "blocs_transformateurs.33." }, "transformer_blocks_34_": { "name": "blocs_transformateurs.34." }, "transformer_blocks_35_": { "name": "blocs_transformateurs.35." }, "transformer_blocks_36_": { "name": "blocs_transformateurs.36." }, "transformer_blocks_37_": { "name": "blocs_transformateurs.37." }, "transformer_blocks_38_": { "name": "blocs_transformateurs.38." }, "transformer_blocks_39_": { "name": "blocs_transformateurs.39." }, "transformer_blocks_3_": { "name": "blocs_transformateurs.3." }, "transformer_blocks_40_": { "name": "blocs_transformateurs.40." }, "transformer_blocks_41_": { "name": "blocs_transformateurs.41." }, "transformer_blocks_42_": { "name": "blocs_transformateurs.42." }, "transformer_blocks_43_": { "name": "blocs_transformateurs.43." }, "transformer_blocks_44_": { "name": "blocs_transformateurs.44." }, "transformer_blocks_45_": { "name": "blocs_transformateurs.45." }, "transformer_blocks_46_": { "name": "blocs_transformateurs.46." }, "transformer_blocks_47_": { "name": "blocs_transformateurs.47." }, "transformer_blocks_48_": { "name": "blocs_transformateurs.48." }, "transformer_blocks_49_": { "name": "blocs_transformateurs.49." }, "transformer_blocks_4_": { "name": "blocs_transformateurs.4." }, "transformer_blocks_50_": { "name": "blocs_transformateurs.50." }, "transformer_blocks_51_": { "name": "blocs_transformateurs.51." }, "transformer_blocks_52_": { "name": "blocs_transformateurs.52." }, "transformer_blocks_53_": { "name": "blocs_transformateurs.53." }, "transformer_blocks_54_": { "name": "blocs_transformateurs.54." }, "transformer_blocks_55_": { "name": "blocs_transformateurs.55." }, "transformer_blocks_56_": { "name": "blocs_transformateurs.56." }, "transformer_blocks_57_": { "name": "blocs_transformateurs.57." }, "transformer_blocks_58_": { "name": "blocs_transformateurs.58." }, "transformer_blocks_59_": { "name": "blocs_transformateurs.59." }, "transformer_blocks_5_": { "name": "blocs_transformateurs.5." }, "transformer_blocks_6_": { "name": "blocs_transformateurs.6." }, "transformer_blocks_7_": { "name": "blocs_transformateurs.7." }, "transformer_blocks_8_": { "name": "blocs_transformateurs.8." }, "transformer_blocks_9_": { "name": "blocs_transformateurs.9." }, "txt_in_": { "name": "txt_entrée." }, "txt_norm_": { "name": "txt_norm." } } };
const ModelMergeSD1 = { "display_name": "ModelMergeSD1", "inputs": { "input_blocks_0_": { "name": "input_blocks.0." }, "input_blocks_10_": { "name": "input_blocks.10." }, "input_blocks_11_": { "name": "input_blocks.11." }, "input_blocks_1_": { "name": "input_blocks.1." }, "input_blocks_2_": { "name": "input_blocks.2." }, "input_blocks_3_": { "name": "input_blocks.3." }, "input_blocks_4_": { "name": "input_blocks.4." }, "input_blocks_5_": { "name": "input_blocks.5." }, "input_blocks_6_": { "name": "input_blocks.6." }, "input_blocks_7_": { "name": "input_blocks.7." }, "input_blocks_8_": { "name": "input_blocks.8." }, "input_blocks_9_": { "name": "input_blocks.9." }, "label_emb_": { "name": "label_emb." }, "middle_block_0_": { "name": "middle_block.0." }, "middle_block_1_": { "name": "middle_block.1." }, "middle_block_2_": { "name": "middle_block.2." }, "model1": { "name": "model1" }, "model2": { "name": "model2" }, "out_": { "name": "out." }, "output_blocks_0_": { "name": "output_blocks.0." }, "output_blocks_10_": { "name": "output_blocks.10." }, "output_blocks_11_": { "name": "output_blocks.11." }, "output_blocks_1_": { "name": "output_blocks.1." }, "output_blocks_2_": { "name": "output_blocks.2." }, "output_blocks_3_": { "name": "output_blocks.3." }, "output_blocks_4_": { "name": "output_blocks.4." }, "output_blocks_5_": { "name": "output_blocks.5." }, "output_blocks_6_": { "name": "output_blocks.6." }, "output_blocks_7_": { "name": "output_blocks.7." }, "output_blocks_8_": { "name": "output_blocks.8." }, "output_blocks_9_": { "name": "output_blocks.9." }, "time_embed_": { "name": "time_embed." } } };
const ModelMergeSD2 = { "display_name": "ModelMergeSD2", "inputs": { "input_blocks_0_": { "name": "input_blocks.0." }, "input_blocks_10_": { "name": "input_blocks.10." }, "input_blocks_11_": { "name": "input_blocks.11." }, "input_blocks_1_": { "name": "input_blocks.1." }, "input_blocks_2_": { "name": "input_blocks.2." }, "input_blocks_3_": { "name": "input_blocks.3." }, "input_blocks_4_": { "name": "input_blocks.4." }, "input_blocks_5_": { "name": "input_blocks.5." }, "input_blocks_6_": { "name": "input_blocks.6." }, "input_blocks_7_": { "name": "input_blocks.7." }, "input_blocks_8_": { "name": "input_blocks.8." }, "input_blocks_9_": { "name": "input_blocks.9." }, "label_emb_": { "name": "label_emb." }, "middle_block_0_": { "name": "middle_block.0." }, "middle_block_1_": { "name": "middle_block.1." }, "middle_block_2_": { "name": "middle_block.2." }, "model1": { "name": "model1" }, "model2": { "name": "model2" }, "out_": { "name": "out." }, "output_blocks_0_": { "name": "output_blocks.0." }, "output_blocks_10_": { "name": "output_blocks.10." }, "output_blocks_11_": { "name": "output_blocks.11." }, "output_blocks_1_": { "name": "output_blocks.1." }, "output_blocks_2_": { "name": "output_blocks.2." }, "output_blocks_3_": { "name": "output_blocks.3." }, "output_blocks_4_": { "name": "output_blocks.4." }, "output_blocks_5_": { "name": "output_blocks.5." }, "output_blocks_6_": { "name": "output_blocks.6." }, "output_blocks_7_": { "name": "output_blocks.7." }, "output_blocks_8_": { "name": "output_blocks.8." }, "output_blocks_9_": { "name": "output_blocks.9." }, "time_embed_": { "name": "time_embed." } } };
const ModelMergeSD35_Large = { "display_name": "ModelMergeSD35_Large", "inputs": { "context_embedder_": { "name": "context_embedder." }, "final_layer_": { "name": "final_layer." }, "joint_blocks_0_": { "name": "joint_blocks.0." }, "joint_blocks_10_": { "name": "joint_blocks.10." }, "joint_blocks_11_": { "name": "joint_blocks.11." }, "joint_blocks_12_": { "name": "joint_blocks.12." }, "joint_blocks_13_": { "name": "joint_blocks.13." }, "joint_blocks_14_": { "name": "joint_blocks.14." }, "joint_blocks_15_": { "name": "joint_blocks.15." }, "joint_blocks_16_": { "name": "joint_blocks.16." }, "joint_blocks_17_": { "name": "joint_blocks.17." }, "joint_blocks_18_": { "name": "joint_blocks.18." }, "joint_blocks_19_": { "name": "joint_blocks.19." }, "joint_blocks_1_": { "name": "joint_blocks.1." }, "joint_blocks_20_": { "name": "joint_blocks.20." }, "joint_blocks_21_": { "name": "joint_blocks.21." }, "joint_blocks_22_": { "name": "joint_blocks.22." }, "joint_blocks_23_": { "name": "joint_blocks.23." }, "joint_blocks_24_": { "name": "joint_blocks.24." }, "joint_blocks_25_": { "name": "joint_blocks.25." }, "joint_blocks_26_": { "name": "joint_blocks.26." }, "joint_blocks_27_": { "name": "joint_blocks.27." }, "joint_blocks_28_": { "name": "joint_blocks.28." }, "joint_blocks_29_": { "name": "joint_blocks.29." }, "joint_blocks_2_": { "name": "joint_blocks.2." }, "joint_blocks_30_": { "name": "joint_blocks.30." }, "joint_blocks_31_": { "name": "joint_blocks.31." }, "joint_blocks_32_": { "name": "joint_blocks.32." }, "joint_blocks_33_": { "name": "joint_blocks.33." }, "joint_blocks_34_": { "name": "joint_blocks.34." }, "joint_blocks_35_": { "name": "joint_blocks.35." }, "joint_blocks_36_": { "name": "joint_blocks.36." }, "joint_blocks_37_": { "name": "joint_blocks.37." }, "joint_blocks_3_": { "name": "joint_blocks.3." }, "joint_blocks_4_": { "name": "joint_blocks.4." }, "joint_blocks_5_": { "name": "joint_blocks.5." }, "joint_blocks_6_": { "name": "joint_blocks.6." }, "joint_blocks_7_": { "name": "joint_blocks.7." }, "joint_blocks_8_": { "name": "joint_blocks.8." }, "joint_blocks_9_": { "name": "joint_blocks.9." }, "model1": { "name": "model1" }, "model2": { "name": "model2" }, "pos_embed_": { "name": "pos_embed." }, "t_embedder_": { "name": "t_embedder." }, "x_embedder_": { "name": "x_embedder." }, "y_embedder_": { "name": "y_embedder." } } };
const ModelMergeSD3_2B = { "display_name": "ModelMergeSD3_2B", "inputs": { "context_embedder_": { "name": "context_embedder." }, "final_layer_": { "name": "couche_finale." }, "joint_blocks_0_": { "name": "joint_blocks.0." }, "joint_blocks_10_": { "name": "joint_blocks.10." }, "joint_blocks_11_": { "name": "joint_blocks.11." }, "joint_blocks_12_": { "name": "joint_blocks.12." }, "joint_blocks_13_": { "name": "joint_blocks.13." }, "joint_blocks_14_": { "name": "joint_blocks.14." }, "joint_blocks_15_": { "name": "joint_blocks.15." }, "joint_blocks_16_": { "name": "joint_blocks.16." }, "joint_blocks_17_": { "name": "joint_blocks.17." }, "joint_blocks_18_": { "name": "joint_blocks.18." }, "joint_blocks_19_": { "name": "joint_blocks.19." }, "joint_blocks_1_": { "name": "joint_blocks.1." }, "joint_blocks_20_": { "name": "joint_blocks.20." }, "joint_blocks_21_": { "name": "joint_blocks.21." }, "joint_blocks_22_": { "name": "joint_blocks.22." }, "joint_blocks_23_": { "name": "joint_blocks.23." }, "joint_blocks_2_": { "name": "joint_blocks.2." }, "joint_blocks_3_": { "name": "joint_blocks.3." }, "joint_blocks_4_": { "name": "joint_blocks.4." }, "joint_blocks_5_": { "name": "joint_blocks.5." }, "joint_blocks_6_": { "name": "joint_blocks.6." }, "joint_blocks_7_": { "name": "joint_blocks.7." }, "joint_blocks_8_": { "name": "joint_blocks.8." }, "joint_blocks_9_": { "name": "joint_blocks.9." }, "model1": { "name": "modèle1" }, "model2": { "name": "modèle2" }, "pos_embed_": { "name": "pos_embed." }, "t_embedder_": { "name": "t_embedder." }, "x_embedder_": { "name": "x_embedder." }, "y_embedder_": { "name": "y_embedder." } } };
const ModelMergeSDXL = { "display_name": "ModelMergeSDXL", "inputs": { "input_blocks_0": { "name": "input_blocks.0" }, "input_blocks_1": { "name": "input_blocks.1" }, "input_blocks_2": { "name": "input_blocks.2" }, "input_blocks_3": { "name": "input_blocks.3" }, "input_blocks_4": { "name": "input_blocks.4" }, "input_blocks_5": { "name": "input_blocks.5" }, "input_blocks_6": { "name": "input_blocks.6" }, "input_blocks_7": { "name": "input_blocks.7" }, "input_blocks_8": { "name": "input_blocks.8" }, "label_emb_": { "name": "label_emb." }, "middle_block_0": { "name": "middle_block.0" }, "middle_block_1": { "name": "middle_block.1" }, "middle_block_2": { "name": "middle_block.2" }, "model1": { "name": "modèle1" }, "model2": { "name": "modèle2" }, "out_": { "name": "out." }, "output_blocks_0": { "name": "output_blocks.0" }, "output_blocks_1": { "name": "output_blocks.1" }, "output_blocks_2": { "name": "output_blocks.2" }, "output_blocks_3": { "name": "output_blocks.3" }, "output_blocks_4": { "name": "output_blocks.4" }, "output_blocks_5": { "name": "output_blocks.5" }, "output_blocks_6": { "name": "output_blocks.6" }, "output_blocks_7": { "name": "output_blocks.7" }, "output_blocks_8": { "name": "output_blocks.8" }, "time_embed_": { "name": "time_embed." } } };
const ModelMergeSimple = { "display_name": "ModelMergeSimple", "inputs": { "model1": { "name": "modèle1" }, "model2": { "name": "modèle2" }, "ratio": { "name": "ratio" } } };
const ModelMergeSubtract = { "display_name": "ModelMergeSubtract", "inputs": { "model1": { "name": "modèle1" }, "model2": { "name": "modèle2" }, "multiplier": { "name": "multiplicateur" } } };
const ModelMergeWAN2_1 = { "description": "Le modèle 1,3B possède 30 blocs, le modèle 14B en possède 40. Le modèle image vers vidéo dispose de l'embedding supplémentaire img_emb.", "display_name": "ModelMergeWAN2_1", "inputs": { "blocks_0_": { "name": "blocks.0." }, "blocks_10_": { "name": "blocks.10." }, "blocks_11_": { "name": "blocks.11." }, "blocks_12_": { "name": "blocks.12." }, "blocks_13_": { "name": "blocks.13." }, "blocks_14_": { "name": "blocks.14." }, "blocks_15_": { "name": "blocks.15." }, "blocks_16_": { "name": "blocks.16." }, "blocks_17_": { "name": "blocks.17." }, "blocks_18_": { "name": "blocks.18." }, "blocks_19_": { "name": "blocks.19." }, "blocks_1_": { "name": "blocks.1." }, "blocks_20_": { "name": "blocks.20." }, "blocks_21_": { "name": "blocks.21." }, "blocks_22_": { "name": "blocks.22." }, "blocks_23_": { "name": "blocks.23." }, "blocks_24_": { "name": "blocks.24." }, "blocks_25_": { "name": "blocks.25." }, "blocks_26_": { "name": "blocks.26." }, "blocks_27_": { "name": "blocks.27." }, "blocks_28_": { "name": "blocks.28." }, "blocks_29_": { "name": "blocks.29." }, "blocks_2_": { "name": "blocks.2." }, "blocks_30_": { "name": "blocks.30." }, "blocks_31_": { "name": "blocks.31." }, "blocks_32_": { "name": "blocks.32." }, "blocks_33_": { "name": "blocks.33." }, "blocks_34_": { "name": "blocks.34." }, "blocks_35_": { "name": "blocks.35." }, "blocks_36_": { "name": "blocks.36." }, "blocks_37_": { "name": "blocks.37." }, "blocks_38_": { "name": "blocks.38." }, "blocks_39_": { "name": "blocks.39." }, "blocks_3_": { "name": "blocks.3." }, "blocks_4_": { "name": "blocks.4." }, "blocks_5_": { "name": "blocks.5." }, "blocks_6_": { "name": "blocks.6." }, "blocks_7_": { "name": "blocks.7." }, "blocks_8_": { "name": "blocks.8." }, "blocks_9_": { "name": "blocks.9." }, "head_": { "name": "head." }, "img_emb_": { "name": "img_emb." }, "model1": { "name": "model1" }, "model2": { "name": "model2" }, "patch_embedding_": { "name": "patch_embedding." }, "text_embedding_": { "name": "text_embedding." }, "time_embedding_": { "name": "time_embedding." }, "time_projection_": { "name": "time_projection." } } };
const ModelPatchLoader = { "display_name": "ModelPatchLoader", "inputs": { "name": { "name": "nom" } } };
const ModelSamplingAuraFlow = { "display_name": "ModelSamplingAuraFlow", "inputs": { "model": { "name": "modèle" }, "shift": { "name": "décalage" } } };
const ModelSamplingContinuousEDM = { "display_name": "ModelSamplingContinuousEDM", "inputs": { "model": { "name": "modèle" }, "sampling": { "name": "échantillonnage" }, "sigma_max": { "name": "sigma_max" }, "sigma_min": { "name": "sigma_min" } } };
const ModelSamplingContinuousV = { "display_name": "ModelSamplingContinuousV", "inputs": { "model": { "name": "modèle" }, "sampling": { "name": "échantillonnage" }, "sigma_max": { "name": "sigma_max" }, "sigma_min": { "name": "sigma_min" } } };
const ModelSamplingDiscrete = { "display_name": "ModèleÉchantillonnageDiscret", "inputs": { "model": { "name": "modèle" }, "sampling": { "name": "échantillonnage" }, "zsnr": { "name": "zsnr" } } };
const ModelSamplingFlux = { "display_name": "ModèleÉchantillonnageFlux", "inputs": { "base_shift": { "name": "décalage_base" }, "height": { "name": "hauteur" }, "max_shift": { "name": "décalage_max" }, "model": { "name": "modèle" }, "width": { "name": "largeur" } } };
const ModelSamplingLTXV = { "display_name": "ModèleÉchantillonnageLTXV", "inputs": { "base_shift": { "name": "décalage_base" }, "latent": { "name": "latent" }, "max_shift": { "name": "décalage_max" }, "model": { "name": "modèle" } }, "outputs": { "0": { "tooltip": null } } };
const ModelSamplingSD3 = { "display_name": "ModèleÉchantillonnageSD3", "inputs": { "model": { "name": "modèle" }, "shift": { "name": "décalage" } } };
const ModelSamplingStableCascade = { "display_name": "ModèleÉchantillonnageStableCascade", "inputs": { "model": { "name": "modèle" }, "shift": { "name": "décalage" } } };
const ModelSave = { "display_name": "ModèleEnregistrer", "inputs": { "filename_prefix": { "name": "préfixe_fichier" }, "model": { "name": "modèle" } } };
const MoonvalleyImg2VideoNode = { "description": "Nœud Moonvalley Marey Image vers Vidéo", "display_name": "Moonvalley Marey Image vers Vidéo", "inputs": { "control_after_generate": { "name": "control after generate" }, "image": { "name": "image", "tooltip": "L'image de référence utilisée pour générer la vidéo" }, "negative_prompt": { "name": "negative_prompt", "tooltip": "Texte de prompt négatif" }, "prompt": { "name": "prompt" }, "prompt_adherence": { "name": "prompt_adherence", "tooltip": "Échelle de guidage pour le contrôle de la génération" }, "resolution": { "name": "résolution", "tooltip": "Résolution de la vidéo de sortie" }, "seed": { "name": "seed", "tooltip": "Valeur de seed aléatoire" }, "steps": { "name": "steps", "tooltip": "Nombre d'étapes de débruitage" } }, "outputs": { "0": { "tooltip": null } } };
const MoonvalleyTxt2VideoNode = { "display_name": "Moonvalley Marey Texte vers Vidéo", "inputs": { "control_after_generate": { "name": "control after generate" }, "negative_prompt": { "name": "negative_prompt", "tooltip": "Texte de prompt négatif" }, "prompt": { "name": "prompt" }, "prompt_adherence": { "name": "prompt_adherence", "tooltip": "Échelle de guidage pour le contrôle de la génération" }, "resolution": { "name": "résolution", "tooltip": "Résolution de la vidéo de sortie" }, "seed": { "name": "seed", "tooltip": "Valeur de seed aléatoire" }, "steps": { "name": "steps", "tooltip": "Étapes d'inférence" } }, "outputs": { "0": { "tooltip": null } } };
const MoonvalleyVideo2VideoNode = { "display_name": "Moonvalley Marey Vidéo vers Vidéo", "inputs": { "control_type": { "name": "type_contrôle" }, "motion_intensity": { "name": "intensité_mouvement", "tooltip": "Utilisé uniquement si le type de contrôle est 'Transfert de mouvement'" }, "negative_prompt": { "name": "negative_prompt", "tooltip": "Texte de prompt négatif" }, "prompt": { "name": "prompt", "tooltip": "Décrit la vidéo à générer" }, "seed": { "name": "seed", "tooltip": "Valeur de seed aléatoire" }, "steps": { "name": "étapes", "tooltip": "Nombre d'étapes d'inférence" }, "video": { "name": "vidéo", "tooltip": "La vidéo de référence utilisée pour générer la vidéo de sortie. Doit durer au moins 5 secondes. Les vidéos plus longues que 5s seront automatiquement tronquées. Seul le format MP4 est pris en charge." } }, "outputs": { "0": { "tooltip": null } } };
const Morphology = { "display_name": "ImageMorphologie", "inputs": { "image": { "name": "image" }, "kernel_size": { "name": "taille_noyau" }, "operation": { "name": "opération" } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIChatConfig = { "description": "Permet de spécifier des options de configuration avancées pour les nœuds de chat OpenAI.", "display_name": "Options avancées OpenAI ChatGPT", "inputs": { "instructions": { "name": "instructions", "tooltip": "Instructions pour le modèle sur la façon de générer la réponse" }, "max_output_tokens": { "name": "jetons_sortie_max", "tooltip": "Une limite supérieure pour le nombre de jetons pouvant être générés pour une réponse, incluant les jetons de sortie visibles" }, "truncation": { "name": "troncature", "tooltip": "La stratégie de troncature à utiliser pour la réponse du modèle. auto : Si le contexte de cette réponse et des précédentes dépasse la taille de la fenêtre de contexte du modèle, le modèle tronquera la réponse pour s'adapter à la fenêtre de contexte en supprimant des éléments d'entrée au milieu de la conversation. désactivé : Si une réponse du modèle dépasse la taille de la fenêtre de contexte pour un modèle, la requête échouera avec une erreur 400" } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIChatNode = { "description": "Générer des réponses textuelles à partir d'un modèle OpenAI.", "display_name": "OpenAI ChatGPT", "inputs": { "advanced_options": { "name": "options_avancées", "tooltip": "Configuration optionnelle pour le modèle. Accepte les entrées du nœud Options avancées de chat OpenAI." }, "files": { "name": "fichiers", "tooltip": "Fichier(s) optionnel(s) à utiliser comme contexte pour le modèle. Accepte les entrées du nœud Fichiers d'entrée de chat OpenAI." }, "images": { "name": "images", "tooltip": "Image(s) optionnelle(s) à utiliser comme contexte pour le modèle. Pour inclure plusieurs images, vous pouvez utiliser le nœud Images par lot." }, "model": { "name": "modèle", "tooltip": "Le modèle utilisé pour générer la réponse" }, "persist_context": { "name": "conserver_contexte", "tooltip": "Ce paramètre est obsolète et n'a aucun effet." }, "prompt": { "name": "invite", "tooltip": "Entrées textuelles pour le modèle, utilisées pour générer une réponse." } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIDalle2 = { "description": "Génère des images de façon synchrone via l’endpoint DALL·E 2 d’OpenAI.", "display_name": "OpenAI DALL·E 2", "inputs": { "control_after_generate": { "name": "contrôle après génération" }, "image": { "name": "image", "tooltip": "Image de référence optionnelle pour l’édition d’image." }, "mask": { "name": "mask", "tooltip": "Masque optionnel pour l’inpainting (les zones blanches seront remplacées)" }, "n": { "name": "n", "tooltip": "Nombre d’images à générer" }, "prompt": { "name": "prompt", "tooltip": "Invite textuelle pour DALL·E" }, "seed": { "name": "seed", "tooltip": "pas encore implémenté côté backend" }, "size": { "name": "taille", "tooltip": "Taille de l’image" } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIDalle3 = { "description": "Génère des images de manière synchrone via l’endpoint DALL·E 3 d’OpenAI.", "display_name": "OpenAI DALL·E 3", "inputs": { "control_after_generate": { "name": "contrôle après génération" }, "prompt": { "name": "prompt", "tooltip": "Invite textuelle pour DALL·E" }, "quality": { "name": "qualité", "tooltip": "Qualité de l’image" }, "seed": { "name": "seed", "tooltip": "pas encore implémenté côté backend" }, "size": { "name": "taille", "tooltip": "Taille de l’image" }, "style": { "name": "style", "tooltip": "Vivid pousse le modèle à générer des images hyper-réalistes et dramatiques. Natural fait produire au modèle des images plus naturelles, moins hyper-réalistes." } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIGPTImage1 = { "description": "Génère des images de manière synchrone via l'endpoint GPT Image 1 d'OpenAI.", "display_name": "OpenAI GPT Image 1", "inputs": { "background": { "name": "arrière-plan", "tooltip": "Retourner l'image avec ou sans arrière-plan" }, "control_after_generate": { "name": "contrôle après génération" }, "image": { "name": "image", "tooltip": "Image de référence optionnelle pour l'édition d'image." }, "mask": { "name": "mask", "tooltip": "Masque optionnel pour l'inpainting (les zones blanches seront remplacées)" }, "n": { "name": "n", "tooltip": "Combien d'images générer" }, "prompt": { "name": "prompt", "tooltip": "Invite textuelle pour GPT Image 1" }, "quality": { "name": "qualité", "tooltip": "Qualité de l'image, affecte le coût et le temps de génération." }, "seed": { "name": "seed", "tooltip": "pas encore implémenté côté backend" }, "size": { "name": "taille", "tooltip": "Taille de l'image" } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIInputFiles = { "description": "Charge et prépare les fichiers d'entrée (texte, pdf, etc.) à inclure comme entrées pour le nœud de chat OpenAI. Les fichiers seront lus par le modèle OpenAI lors de la génération d'une réponse. 🛈 ASTUCE : Peut être chaîné avec d'autres nœuds de fichiers d'entrée OpenAI.", "display_name": "Fichiers d'entrée OpenAI ChatGPT", "inputs": { "OPENAI_INPUT_FILES": { "name": "FICHIERS_ENTRÉE_OPENAI", "tooltip": "Un ou plusieurs fichiers supplémentaires optionnels à regrouper avec le fichier chargé depuis ce nœud. Permet d'enchaîner les fichiers d'entrée afin qu'un seul message puisse inclure plusieurs fichiers d'entrée." }, "file": { "name": "fichier", "tooltip": "Fichiers d'entrée à inclure comme contexte pour le modèle. N'accepte pour l'instant que les fichiers texte (.txt) et PDF (.pdf)." } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIVideoSora2 = { "description": "Génération de vidéo et audio OpenAI.", "display_name": "OpenAI Sora - Vidéo", "inputs": { "control_after_generate": { "name": "contrôle après génération" }, "duration": { "name": "durée" }, "image": { "name": "image" }, "model": { "name": "modèle" }, "prompt": { "name": "invite", "tooltip": "Texte guide ; peut être vide si une image d'entrée est présente." }, "seed": { "name": "graine", "tooltip": "Graine pour déterminer si le nœud doit être réexécuté ; les résultats réels sont non déterministes quelle que soit la graine." }, "size": { "name": "taille" } }, "outputs": { "0": { "tooltip": null } } };
const OptimalStepsScheduler = { "display_name": "OptimalStepsScheduler", "inputs": { "denoise": { "name": "réduction du bruit" }, "model_type": { "name": "model_type" }, "steps": { "name": "étapes" } }, "outputs": { "0": { "tooltip": null } } };
const PairConditioningCombine = { "display_name": "Cond Pair Combiner", "inputs": { "negative_A": { "name": "negative_A" }, "negative_B": { "name": "negative_B" }, "positive_A": { "name": "positive_A" }, "positive_B": { "name": "positive_B" } }, "outputs": { "0": { "name": "positive" }, "1": { "name": "negative" } } };
const PairConditioningSetDefaultCombine = { "display_name": "Cond Pair Définir Combiner par Défaut", "inputs": { "hooks": { "name": "hooks" }, "negative": { "name": "negative" }, "negative_DEFAULT": { "name": "negative_DEFAULT" }, "positive": { "name": "positive" }, "positive_DEFAULT": { "name": "positive_DEFAULT" } }, "outputs": { "0": { "name": "positive" }, "1": { "name": "negative" } } };
const PairConditioningSetProperties = { "display_name": "Cond Pair Définir Propriétés", "inputs": { "hooks": { "name": "hooks" }, "mask": { "name": "masque" }, "negative_NEW": { "name": "negative_NEW" }, "positive_NEW": { "name": "positive_NEW" }, "set_cond_area": { "name": "définir_zone_cond" }, "strength": { "name": "force" }, "timesteps": { "name": "pas_de_temps" } }, "outputs": { "0": { "name": "positive" }, "1": { "name": "negative" } } };
const PairConditioningSetPropertiesAndCombine = { "display_name": "Cond Pair Set Props Combine", "inputs": { "hooks": { "name": "crochets" }, "mask": { "name": "masque" }, "negative": { "name": "negative" }, "negative_NEW": { "name": "negative_NEW" }, "positive": { "name": "positive" }, "positive_NEW": { "name": "positive_NEW" }, "set_cond_area": { "name": "set_cond_area" }, "strength": { "name": "force" }, "timesteps": { "name": "pas de temps" } }, "outputs": { "0": { "name": "positive" }, "1": { "name": "negative" } } };
const PatchModelAddDownscale = { "display_name": "PatchModelAddDownscale (Kohya Deep Shrink)", "inputs": { "block_number": { "name": "numéro de bloc" }, "downscale_after_skip": { "name": "réduction après saut" }, "downscale_factor": { "name": "facteur de réduction" }, "downscale_method": { "name": "méthode de réduction" }, "end_percent": { "name": "pourcentage de fin" }, "model": { "name": "modèle" }, "start_percent": { "name": "pourcentage de départ" }, "upscale_method": { "name": "méthode d'agrandissement" } }, "outputs": { "0": { "tooltip": null } } };
const PerpNeg = { "display_name": "Perp-Neg (OBSOLÈTE par PerpNegGuider)", "inputs": { "empty_conditioning": { "name": "conditionnement vide" }, "model": { "name": "modèle" }, "neg_scale": { "name": "échelle nég" } }, "outputs": { "0": { "tooltip": null } } };
const PerpNegGuider = { "display_name": "PerpNegGuider", "inputs": { "cfg": { "name": "cfg" }, "empty_conditioning": { "name": "conditionnement vide" }, "model": { "name": "modèle" }, "neg_scale": { "name": "échelle nég" }, "negative": { "name": "négative" }, "positive": { "name": "positive" } }, "outputs": { "0": { "tooltip": null } } };
const PerturbedAttentionGuidance = { "display_name": "PerturbedAttentionGuidance", "inputs": { "model": { "name": "modèle" }, "scale": { "name": "échelle" } }, "outputs": { "0": { "tooltip": null } } };
const PhotoMakerEncode = { "display_name": "PhotoMakerEncode", "inputs": { "clip": { "name": "clip" }, "image": { "name": "image" }, "photomaker": { "name": "photomaker" }, "text": { "name": "texte" } }, "outputs": { "0": { "tooltip": null } } };
const PhotoMakerLoader = { "display_name": "PhotoMakerLoader", "inputs": { "photomaker_model_name": { "name": "nom_du_modèle_photomaker" } }, "outputs": { "0": { "tooltip": null } } };
const PixverseImageToVideoNode = { "description": "Génère des vidéos de manière synchrone à partir du prompt et de la taille de sortie.", "display_name": "PixVerse Image vers Vidéo", "inputs": { "control_after_generate": { "name": "contrôle après génération" }, "duration_seconds": { "name": "durée_secondes" }, "image": { "name": "image" }, "motion_mode": { "name": "mode_mouvement" }, "negative_prompt": { "name": "prompt_négatif", "tooltip": "Une description textuelle optionnelle des éléments indésirables sur une image." }, "pixverse_template": { "name": "modèle_pixverse", "tooltip": "Un modèle optionnel pour influencer le style de génération, créé par le nœud PixVerse Template." }, "prompt": { "name": "prompt", "tooltip": "Prompt pour la génération de la vidéo" }, "quality": { "name": "qualité" }, "seed": { "name": "graine", "tooltip": "Graine pour la génération de la vidéo." } }, "outputs": { "0": { "tooltip": null } } };
const PixverseTemplateNode = { "display_name": "Modèle PixVerse", "inputs": { "template": { "name": "modèle" } }, "outputs": { "0": { "name": "modèle_pixverse", "tooltip": null } } };
const PixverseTextToVideoNode = { "description": "Génère des vidéos de manière synchrone à partir d'un prompt et d'une taille de sortie.", "display_name": "PixVerse Texte en Vidéo", "inputs": { "aspect_ratio": { "name": "rapport d'aspect" }, "control_after_generate": { "name": "contrôle après génération" }, "duration_seconds": { "name": "durée (secondes)" }, "motion_mode": { "name": "mode de mouvement" }, "negative_prompt": { "name": "prompt négatif", "tooltip": "Une description textuelle optionnelle des éléments indésirables sur une image." }, "pixverse_template": { "name": "modèle PixVerse", "tooltip": "Un modèle optionnel pour influencer le style de génération, créé par le nœud Modèle PixVerse." }, "prompt": { "name": "prompt", "tooltip": "Prompt pour la génération de la vidéo" }, "quality": { "name": "qualité" }, "seed": { "name": "graine", "tooltip": "Graine pour la génération de la vidéo." } }, "outputs": { "0": { "tooltip": null } } };
const PixverseTransitionVideoNode = { "description": "Génère des vidéos de manière synchrone selon le prompt et la taille de sortie.", "display_name": "PixVerse Transition Vidéo", "inputs": { "control_after_generate": { "name": "contrôle après génération" }, "duration_seconds": { "name": "durée (secondes)" }, "first_frame": { "name": "première image" }, "last_frame": { "name": "dernière image" }, "motion_mode": { "name": "mode de mouvement" }, "negative_prompt": { "name": "prompt négatif", "tooltip": "Une description textuelle optionnelle des éléments indésirables sur une image." }, "prompt": { "name": "prompt", "tooltip": "Prompt pour la génération de la vidéo" }, "quality": { "name": "qualité" }, "seed": { "name": "seed", "tooltip": "Seed pour la génération de la vidéo." } }, "outputs": { "0": { "tooltip": null } } };
const PolyexponentialScheduler = { "display_name": "PolyexponentialScheduler", "inputs": { "rho": { "name": "rho" }, "sigma_max": { "name": "sigma_max" }, "sigma_min": { "name": "sigma_min" }, "steps": { "name": "étapes" } } };
const PorterDuffImageComposite = { "display_name": "Composite d'image Porter-Duff", "inputs": { "destination": { "name": "destination" }, "destination_alpha": { "name": "alpha_destination" }, "mode": { "name": "mode" }, "source": { "name": "source" }, "source_alpha": { "name": "alpha_source" } }, "outputs": { "0": { "tooltip": null }, "1": { "tooltip": null } } };
const Preview3D = { "display_name": "Aperçu 3D", "inputs": { "camera_info": { "name": "informations_de_camera" }, "image": { "name": "image" }, "model_file": { "name": "fichier_modèle" } } };
const PreviewAny = { "display_name": "Aperçu de n'importe quel", "inputs": { "preview": {}, "source": { "name": "source" } } };
const PreviewAudio = { "display_name": "AperçuAudio", "inputs": { "audio": { "name": "audio" }, "audioUI": { "name": "audioUI" } } };
const PreviewImage = { "description": "Enregistre les images d'entrée dans votre répertoire de sortie ComfyUI.", "display_name": "Aperçu Image", "inputs": { "images": { "name": "images" } } };
const PrimitiveBoolean = { "display_name": "Booléen", "inputs": { "value": { "name": "valeur" } }, "outputs": { "0": { "tooltip": null } } };
const PrimitiveFloat = { "display_name": "Flottant", "inputs": { "value": { "name": "valeur" } }, "outputs": { "0": { "tooltip": null } } };
const PrimitiveInt = { "display_name": "Int", "inputs": { "control_after_generate": { "name": "contrôler après génération" }, "value": { "name": "valeur" } }, "outputs": { "0": { "tooltip": null } } };
const PrimitiveString = { "display_name": "Chaîne", "inputs": { "value": { "name": "valeur" } }, "outputs": { "0": { "tooltip": null } } };
const PrimitiveStringMultiline = { "display_name": "Chaîne (multiligne)", "inputs": { "value": { "name": "valeur" } }, "outputs": { "0": { "tooltip": null } } };
const QuadrupleCLIPLoader = { "description": "[Recettes]\n\nhidream : long clip-l, long clip-g, t5xxl, llama_8b_3.1_instruct", "display_name": "QuadrupleCLIPLoader", "inputs": { "clip_name1": { "name": "clip_name1" }, "clip_name2": { "name": "clip_name2" }, "clip_name3": { "name": "clip_name3" }, "clip_name4": { "name": "clip_name4" } }, "outputs": { "0": { "tooltip": null } } };
const QwenImageDiffsynthControlnet = { "display_name": "QwenImageDiffsynthControlnet", "inputs": { "image": { "name": "image" }, "mask": { "name": "masque" }, "model": { "name": "modèle" }, "model_patch": { "name": "correctif_modèle" }, "strength": { "name": "intensité" }, "vae": { "name": "vae" } } };
const RandomNoise = { "display_name": "BruitAléatoire", "inputs": { "control_after_generate": { "name": "contrôle après génération" }, "noise_seed": { "name": "graine_de_bruit" } } };
const RebatchImages = { "display_name": "Rebatch Images", "inputs": { "batch_size": { "name": "taille_de_lot" }, "images": { "name": "images" } }, "outputs": { "0": { "tooltip": null } } };
const RebatchLatents = { "display_name": "Rebatch Latents", "inputs": { "batch_size": { "name": "taille_de_lot" }, "latents": { "name": "latents" } }, "outputs": { "0": { "tooltip": null } } };
const RecordAudio = { "display_name": "Enregistrer l'audio", "inputs": { "audio": { "name": "audio" } } };
const RecraftColorRGB = { "description": "Créez une couleur Recraft en choisissant des valeurs RGB spécifiques.", "display_name": "Recraft Couleur RGB", "inputs": { "b": { "name": "b", "tooltip": "Valeur bleue de la couleur." }, "g": { "name": "g", "tooltip": "Valeur verte de la couleur." }, "r": { "name": "r", "tooltip": "Valeur rouge de la couleur." }, "recraft_color": { "name": "recraft_color" } }, "outputs": { "0": { "name": "recraft_color", "tooltip": null } } };
const RecraftControls = { "description": "Créez des contrôles Recraft pour personnaliser la génération Recraft.", "display_name": "Contrôles Recraft", "inputs": { "background_color": { "name": "couleur_de_fond" }, "colors": { "name": "couleurs" } }, "outputs": { "0": { "name": "contrôles_recraft", "tooltip": null } } };
const RecraftCreativeUpscaleNode = { "description": "Agrandit l'image de manière synchrone.\nAméliore une image matricielle donnée à l'aide de l'outil « creative upscale », augmentant la résolution avec un accent sur l'affinement des petits détails et des visages.", "display_name": "Recraft Creative Upscale Image", "inputs": { "image": { "name": "image" } }, "outputs": { "0": { "tooltip": null } } };
const RecraftCrispUpscaleNode = { "description": "Agrandit l’image de façon synchrone.\nAméliore une image matricielle donnée à l’aide de l’outil « crisp upscale », en augmentant la résolution et en rendant l’image plus nette et plus propre.", "display_name": "Recraft Crisp Upscale Image", "inputs": { "image": { "name": "image" } }, "outputs": { "0": { "tooltip": null } } };
const RecraftImageInpaintingNode = { "description": "Modifiez l’image selon l’invite et le mask.", "display_name": "Recraft Image Inpainting", "inputs": { "control_after_generate": { "name": "contrôle après génération" }, "image": { "name": "image" }, "mask": { "name": "mask" }, "n": { "name": "n", "tooltip": "Nombre d’images à générer." }, "negative_prompt": { "name": "invite négative", "tooltip": "Une description textuelle optionnelle des éléments indésirables sur une image." }, "prompt": { "name": "invite", "tooltip": "Invite pour la génération d’image." }, "recraft_style": { "name": "recraft_style" }, "seed": { "name": "seed", "tooltip": "Seed pour déterminer si le nœud doit être relancé ; les résultats réels sont non déterministes quel que soit le seed." } }, "outputs": { "0": { "tooltip": null } } };
const RecraftImageToImageNode = { "description": "Modifiez l'image en fonction de l'invite et de l'intensité.", "display_name": "Recraft Image vers Image", "inputs": { "control_after_generate": { "name": "contrôle après génération" }, "image": { "name": "image" }, "n": { "name": "n", "tooltip": "Nombre d'images à générer." }, "negative_prompt": { "name": "invite_négative", "tooltip": "Une description textuelle optionnelle des éléments indésirables sur une image." }, "prompt": { "name": "invite", "tooltip": "Invite pour la génération d'image." }, "recraft_controls": { "name": "recraft_controls", "tooltip": "Contrôles supplémentaires optionnels sur la génération via le nœud Recraft Controls." }, "recraft_style": { "name": "recraft_style" }, "seed": { "name": "graine", "tooltip": "Graine pour déterminer si le nœud doit être relancé ; les résultats réels sont non déterministes, quelle que soit la graine." }, "strength": { "name": "intensité", "tooltip": "Définit la différence avec l'image originale, doit être comprise entre [0, 1], où 0 signifie presque identique et 1 signifie une similarité très faible." } }, "outputs": { "0": { "tooltip": null } } };
const RecraftRemoveBackgroundNode = { "description": "Supprime l'arrière-plan de l'image et retourne l'image traitée ainsi que le masque.", "display_name": "Recraft Remove Background", "inputs": { "image": { "name": "image" } }, "outputs": { "0": { "tooltip": null }, "1": { "tooltip": null } } };
const RecraftReplaceBackgroundNode = { "description": "Remplace l’arrière-plan d’une image, selon l’invite fournie.", "display_name": "Recraft Remplacer l’arrière-plan", "inputs": { "control_after_generate": { "name": "contrôle après génération" }, "image": { "name": "image" }, "n": { "name": "n", "tooltip": "Nombre d’images à générer." }, "negative_prompt": { "name": "invite négative", "tooltip": "Une description textuelle optionnelle des éléments indésirables sur une image." }, "prompt": { "name": "invite", "tooltip": "Invite pour la génération d’image." }, "recraft_style": { "name": "recraft_style" }, "seed": { "name": "graine", "tooltip": "Graine pour déterminer si le nœud doit être relancé ; les résultats réels restent non déterministes, quelle que soit la graine." } }, "outputs": { "0": { "tooltip": null } } };
const RecraftStyleV3DigitalIllustration = { "description": "Sélectionnez le style realistic_image et un sous-style optionnel.", "display_name": "Style Recraft - Illustration numérique", "inputs": { "substyle": { "name": "sous-style" } }, "outputs": { "0": { "name": "recraft_style", "tooltip": null } } };
const RecraftStyleV3InfiniteStyleLibrary = { "description": "Sélectionnez un style basé sur l'UUID préexistant de la Infinite Style Library de Recraft.", "display_name": "Recraft Style - Infinite Style Library", "inputs": { "style_id": { "name": "style_id", "tooltip": "UUID du style provenant de la Infinite Style Library." } }, "outputs": { "0": { "name": "recraft_style", "tooltip": null } } };
const RecraftStyleV3LogoRaster = { "description": "Sélectionnez le style realistic_image et un sous-style optionnel.", "display_name": "Recraft Style - Logo Raster", "inputs": { "substyle": { "name": "sous-style" } }, "outputs": { "0": { "name": "recraft_style", "tooltip": null } } };
const RecraftStyleV3RealisticImage = { "description": "Sélectionnez le style realistic_image et un sous-style optionnel.", "display_name": "Recraft Style - Image réaliste", "inputs": { "substyle": { "name": "sous-style" } }, "outputs": { "0": { "name": "recraft_style", "tooltip": null } } };
const RecraftTextToImageNode = { "description": "Génère des images de manière synchrone à partir d'une invite et d'une résolution.", "display_name": "Recraft Texte en Image", "inputs": { "control_after_generate": { "name": "contrôle après génération" }, "n": { "name": "n", "tooltip": "Le nombre d'images à générer." }, "negative_prompt": { "name": "negative_prompt", "tooltip": "Une description textuelle optionnelle des éléments indésirables sur une image." }, "prompt": { "name": "prompt", "tooltip": "Invite pour la génération d'image." }, "recraft_controls": { "name": "recraft_controls", "tooltip": "Contrôles supplémentaires optionnels sur la génération via le nœud Recraft Controls." }, "recraft_style": { "name": "recraft_style" }, "seed": { "name": "seed", "tooltip": "Graine pour déterminer si le nœud doit être relancé ; les résultats réels sont non déterministes, quelle que soit la graine." }, "size": { "name": "taille", "tooltip": "La taille de l'image générée." } }, "outputs": { "0": { "tooltip": null } } };
const RecraftTextToVectorNode = { "description": "Génère un SVG de manière synchrone à partir du prompt et de la résolution.", "display_name": "Recraft Texte vers Vecteur", "inputs": { "control_after_generate": { "name": "contrôle après génération" }, "n": { "name": "n", "tooltip": "Le nombre d'images à générer." }, "negative_prompt": { "name": "prompt négatif", "tooltip": "Une description textuelle optionnelle des éléments indésirables sur une image." }, "prompt": { "name": "prompt", "tooltip": "Prompt pour la génération d'image." }, "recraft_controls": { "name": "recraft_controls", "tooltip": "Contrôles supplémentaires optionnels sur la génération via le nœud Recraft Controls." }, "seed": { "name": "seed", "tooltip": "Seed pour déterminer si le nœud doit être relancé ; les résultats réels sont non déterministes quel que soit le seed." }, "size": { "name": "taille", "tooltip": "La taille de l'image générée." }, "substyle": { "name": "sous-style" } }, "outputs": { "0": { "tooltip": null } } };
const RecraftVectorizeImageNode = { "description": "Génère un SVG de manière synchrone à partir d'une image d'entrée.", "display_name": "Vectoriser une image avec Recraft", "inputs": { "image": { "name": "image" } }, "outputs": { "0": { "tooltip": null } } };
const ReferenceLatent = { "description": "Ce nœud définit le latent de guidage pour un modèle d'édition. Si le modèle le prend en charge, vous pouvez en chaîner plusieurs pour définir plusieurs images de référence.", "display_name": "LatentDeRéférence", "inputs": { "conditioning": { "name": "conditionnement" }, "latent": { "name": "latent" } }, "outputs": { "0": { "tooltip": null } } };
const RegexExtract = { "display_name": "Extraire par Regex", "inputs": { "case_insensitive": { "name": "insensible_à_la_casse" }, "dotall": { "name": "dotall" }, "group_index": { "name": "index_groupe" }, "mode": { "name": "mode" }, "multiline": { "name": "multiligne" }, "regex_pattern": { "name": "motif_regex" }, "string": { "name": "chaîne" } }, "outputs": { "0": { "tooltip": null } } };
const RegexMatch = { "display_name": "Correspondance Regex", "inputs": { "case_insensitive": { "name": "insensible_à_la_casse" }, "dotall": { "name": "dotall" }, "multiline": { "name": "multiligne" }, "regex_pattern": { "name": "motif_regex" }, "string": { "name": "chaîne" } }, "outputs": { "0": { "name": "correspondances", "tooltip": null } } };
const RegexReplace = { "description": "Rechercher et remplacer du texte à l'aide de motifs regex.", "display_name": "Remplacer par Regex", "inputs": { "case_insensitive": { "name": "insensible à la casse" }, "count": { "name": "nombre", "tooltip": "Nombre maximum de remplacements à effectuer. Réglez sur 0 pour remplacer toutes les occurrences (par défaut). Réglez sur 1 pour remplacer uniquement la première correspondance, 2 pour les deux premières correspondances, etc." }, "dotall": { "name": "dotall", "tooltip": "Lorsqu'activé, le point (.) correspondra à n'importe quel caractère y compris les caractères de nouvelle ligne. Lorsque désactivé, les points ne correspondront pas aux nouvelles lignes." }, "multiline": { "name": "multiligne" }, "regex_pattern": { "name": "motif_regex" }, "replace": { "name": "remplacer" }, "string": { "name": "chaîne" } }, "outputs": { "0": { "tooltip": null } } };
const RenormCFG = { "display_name": "RenormCFG", "inputs": { "cfg_trunc": { "name": "cfg_trunc" }, "model": { "name": "modèle" }, "renorm_cfg": { "name": "renorm_cfg" } }, "outputs": { "0": { "tooltip": null } } };
const RepeatImageBatch = { "display_name": "RépéterLotImage", "inputs": { "amount": { "name": "quantité" }, "image": { "name": "image" } } };
const RepeatLatentBatch = { "display_name": "Répéter Lot Latent", "inputs": { "amount": { "name": "quantité" }, "samples": { "name": "échantillons" } } };
const RescaleCFG = { "display_name": "RescaleCFG", "inputs": { "model": { "name": "modèle" }, "multiplier": { "name": "multiplicateur" } } };
const ResizeAndPadImage = { "display_name": "RedimensionnerEtRembourrerImage", "inputs": { "image": { "name": "image" }, "interpolation": { "name": "interpolation" }, "padding_color": { "name": "couleur_rembourrage" }, "target_height": { "name": "hauteur_cible" }, "target_width": { "name": "largeur_cible" } } };
const Rodin3D_Detail = { "description": "Générer des actifs 3D en utilisant l'API Rodin", "display_name": "Rodin 3D Générer - Générer Détails", "inputs": { "Images": { "name": "Images" }, "Material_Type": { "name": "Type_Matériau" }, "Polygon_count": { "name": "Nombre_Polygones" }, "Seed": { "name": "Graine" } }, "outputs": { "0": { "name": "Chemin Modèle 3D", "tooltip": null } } };
const Rodin3D_Gen2 = { "description": "Générer des actifs 3D en utilisant l'API Rodin", "display_name": "Rodin 3D Générer - Génération Gen-2", "inputs": { "Images": { "name": "Images" }, "Material_Type": { "name": "Type_Matériau" }, "Polygon_count": { "name": "Nombre_Polygones" }, "Seed": { "name": "Graine" }, "TAPose": { "name": "PoseTAP" } }, "outputs": { "0": { "name": "Chemin Modèle 3D", "tooltip": null } } };
const Rodin3D_Regular = { "description": "Générer des actifs 3D en utilisant l'API Rodin", "display_name": "Rodin 3D Générer - Génération Régulière", "inputs": { "Images": { "name": "Images" }, "Material_Type": { "name": "Type_Matériau" }, "Polygon_count": { "name": "Nombre_Polygones" }, "Seed": { "name": "Graine" } }, "outputs": { "0": { "name": "Chemin Modèle 3D", "tooltip": null } } };
const Rodin3D_Sketch = { "description": "Générer des actifs 3D en utilisant l'API Rodin", "display_name": "Rodin 3D Générer - Génération Esquisse", "inputs": { "Images": { "name": "Images" }, "Seed": { "name": "Graine" } }, "outputs": { "0": { "name": "Chemin Modèle 3D", "tooltip": null } } };
const Rodin3D_Smooth = { "description": "Générer des ressources 3D avec l'API Rodin", "display_name": "Rodin 3D Générer - Génération Lisse", "inputs": { "Images": { "name": "Images" }, "Material_Type": { "name": "Type de matériau" }, "Polygon_count": { "name": "Nombre de polygones" }, "Seed": { "name": "Graine" } }, "outputs": { "0": { "name": "Chemin du modèle 3D", "tooltip": null } } };
const RunwayFirstLastFrameNode = { "description": "Téléchargez les premières et dernières images clés, rédigez un prompt et générez une vidéo. Les transitions plus complexes, comme lorsque la dernière image est complètement différente de la première, peuvent bénéficier de la durée plus longue de 10s. Cela donnerait à la génération plus de temps pour effectuer une transition fluide entre les deux entrées. Avant de commencer, consultez ces bonnes pratiques pour vous assurer que vos sélections d'entrée permettront à votre génération de réussir : https://help.runwayml.com/hc/en-us/articles/34170748696595-Creating-with-Keyframes-on-Gen-3.", "display_name": "Runway Première-Dernière image vers vidéo", "inputs": { "control_after_generate": { "name": "contrôle après génération" }, "duration": { "name": "durée" }, "end_frame": { "name": "image_fin", "tooltip": "Image de fin à utiliser pour la vidéo. Pris en charge pour gen3a_turbo uniquement." }, "prompt": { "name": "prompt", "tooltip": "Prompt texte pour la génération" }, "ratio": { "name": "ratio" }, "seed": { "name": "graine", "tooltip": "Graine aléatoire pour la génération" }, "start_frame": { "name": "image_début", "tooltip": "Image de départ à utiliser pour la vidéo" } }, "outputs": { "0": { "tooltip": null } } };
const RunwayImageToVideoNodeGen3a = { "description": "Générer une vidéo à partir d'une seule image de départ en utilisant le modèle Gen3a Turbo. Avant de commencer, consultez ces bonnes pratiques pour vous assurer que vos sélections d'entrée permettront à votre génération de réussir : https://help.runwayml.com/hc/en-us/articles/33927968552339-Creating-with-Act-One-on-Gen-3-Alpha-and-Turbo.", "display_name": "Runway Image vers Vidéo (Gen3a Turbo)", "inputs": { "control_after_generate": { "name": "contrôle après génération" }, "duration": { "name": "durée" }, "prompt": { "name": "prompt", "tooltip": "Prompt texte pour la génération" }, "ratio": { "name": "ratio" }, "seed": { "name": "graine", "tooltip": "Graine aléatoire pour la génération" }, "start_frame": { "name": "image_début", "tooltip": "Image de départ à utiliser pour la vidéo" } }, "outputs": { "0": { "tooltip": null } } };
const RunwayImageToVideoNodeGen4 = { "description": "Générer une vidéo à partir d'une seule image de départ en utilisant le modèle Gen4 Turbo. Avant de commencer, consultez ces bonnes pratiques pour vous assurer que vos sélections d'entrée permettront à votre génération de réussir : https://help.runwayml.com/hc/en-us/articles/37327109429011-Creating-with-Gen-4-Video.", "display_name": "Runway Image vers Vidéo (Gen4 Turbo)", "inputs": { "control_after_generate": { "name": "contrôle après génération" }, "duration": { "name": "durée" }, "prompt": { "name": "prompt", "tooltip": "Prompt texte pour la génération" }, "ratio": { "name": "ratio" }, "seed": { "name": "graine", "tooltip": "Graine aléatoire pour la génération" }, "start_frame": { "name": "image_début", "tooltip": "Image de départ à utiliser pour la vidéo" } }, "outputs": { "0": { "tooltip": null } } };
const RunwayTextToImageNode = { "description": "Générer une image à partir d'une invite texte en utilisant le modèle Gen 4 de Runway. Vous pouvez également inclure une image de référence pour guider la génération.", "display_name": "Runway Texte vers Image", "inputs": { "prompt": { "name": "invite", "tooltip": "Invite texte pour la génération" }, "ratio": { "name": "ratio" }, "reference_image": { "name": "image_référence", "tooltip": "Image de référence optionnelle pour guider la génération" } }, "outputs": { "0": { "tooltip": null } } };
const SDTurboScheduler = { "display_name": "SDTurboScheduler", "inputs": { "denoise": { "name": "débruitage" }, "model": { "name": "modèle" }, "steps": { "name": "étapes" } } };
const SD_4XUpscale_Conditioning = { "display_name": "SD_4XUpscale_Conditioning", "inputs": { "images": { "name": "images" }, "negative": { "name": "négatif" }, "noise_augmentation": { "name": "augmentation_du_bruit" }, "positive": { "name": "positive" }, "scale_ratio": { "name": "ratio_d'échelle" } }, "outputs": { "0": { "name": "positive", "tooltip": null }, "1": { "name": "négatif", "tooltip": null }, "2": { "name": "latent", "tooltip": null } } };
const SV3D_Conditioning = { "display_name": "SV3D_Conditioning", "inputs": { "clip_vision": { "name": "clip_vision" }, "elevation": { "name": "élévation" }, "height": { "name": "hauteur" }, "init_image": { "name": "init_image" }, "vae": { "name": "vae" }, "video_frames": { "name": "cadres_vidéo" }, "width": { "name": "largeur" } }, "outputs": { "0": { "name": "positif", "tooltip": null }, "1": { "name": "négatif", "tooltip": null }, "2": { "name": "latent", "tooltip": null } } };
const SVD_img2vid_Conditioning = { "display_name": "SVD_img2vid_Conditioning", "inputs": { "augmentation_level": { "name": "niveau_d'augmentation" }, "clip_vision": { "name": "clip_vision" }, "fps": { "name": "fps" }, "height": { "name": "hauteur" }, "init_image": { "name": "init_image" }, "motion_bucket_id": { "name": "id_seau_de_mouvement" }, "vae": { "name": "vae" }, "video_frames": { "name": "cadres_vidéo" }, "width": { "name": "largeur" } }, "outputs": { "0": { "name": "positif" }, "1": { "name": "négatif" }, "2": { "name": "latent" } } };
const SamplerCustom = { "display_name": "ÉchantillonneurPersonnalisé", "inputs": { "add_noise": { "name": "ajouter_bruit" }, "cfg": { "name": "cfg" }, "control_after_generate": { "name": "contrôle après génération" }, "latent_image": { "name": "image_latente" }, "model": { "name": "modèle" }, "negative": { "name": "négative" }, "noise_seed": { "name": "graine_de_bruit" }, "positive": { "name": "positive" }, "sampler": { "name": "échantillonneur" }, "sigmas": { "name": "sigmas" } }, "outputs": { "0": { "name": "sortie" }, "1": { "name": "sortie_débruitée" } } };
const SamplerCustomAdvanced = { "display_name": "ÉchantillonneurPersonnaliséAvancé", "inputs": { "guider": { "name": "guide" }, "latent_image": { "name": "image_latente" }, "noise": { "name": "bruit" }, "sampler": { "name": "échantillonneur" }, "sigmas": { "name": "sigmas" } }, "outputs": { "0": { "name": "sortie" }, "1": { "name": "sortie_débruitée" } } };
const SamplerDPMAdaptative = { "display_name": "SamplerDPMAdaptative", "inputs": { "accept_safety": { "name": "accept_safety" }, "atol": { "name": "atol" }, "dcoeff": { "name": "dcoeff" }, "eta": { "name": "eta" }, "h_init": { "name": "h_init" }, "icoeff": { "name": "icoeff" }, "order": { "name": "ordre" }, "pcoeff": { "name": "pcoeff" }, "rtol": { "name": "rtol" }, "s_noise": { "name": "s_bruit" } } };
const SamplerDPMPP_2M_SDE = { "display_name": "SamplerDPMPP_2M_SDE", "inputs": { "eta": { "name": "eta" }, "noise_device": { "name": "appareil_bruit" }, "s_noise": { "name": "s_bruit" }, "solver_type": { "name": "type_solveur" } } };
const SamplerDPMPP_2S_Ancestral = { "display_name": "SamplerDPMPP_2S_Ancestral", "inputs": { "eta": { "name": "eta" }, "s_noise": { "name": "s_bruit" } } };
const SamplerDPMPP_3M_SDE = { "display_name": "SamplerDPMPP_3M_SDE", "inputs": { "eta": { "name": "eta" }, "noise_device": { "name": "appareil_bruit" }, "s_noise": { "name": "s_bruit" } } };
const SamplerDPMPP_SDE = { "display_name": "SamplerDPMPP_SDE", "inputs": { "eta": { "name": "eta" }, "noise_device": { "name": "appareil_bruit" }, "r": { "name": "r" }, "s_noise": { "name": "s_bruit" } } };
const SamplerER_SDE = { "display_name": "ÉchantillonneurER_SDE", "inputs": { "eta": { "name": "eta", "tooltip": "Force stochastique de l'EDS en temps inverse.\nLorsque eta=0, cela se réduit à une EDO déterministe. Ce paramètre ne s'applique pas au type de solveur ER-SDE." }, "max_stage": { "name": "étape_max" }, "s_noise": { "name": "s_bruit" }, "solver_type": { "name": "type_solveur" } } };
const SamplerEulerAncestral = { "display_name": "SamplerEulerAncestral", "inputs": { "eta": { "name": "eta" }, "s_noise": { "name": "s_bruit" } } };
const SamplerEulerAncestralCFGPP = { "display_name": "SamplerEulerAncestralCFG++", "inputs": { "eta": { "name": "eta" }, "s_noise": { "name": "s_bruit" } } };
const SamplerEulerCFGpp = { "display_name": "SamplerEulerCFG++", "inputs": { "version": { "name": "version" } }, "outputs": { "0": { "tooltip": null } } };
const SamplerLCMUpscale = { "display_name": "SamplerLCMUpscale", "inputs": { "scale_ratio": { "name": "ratio_échelle" }, "scale_steps": { "name": "étapes_échelle" }, "upscale_method": { "name": "méthode_agrandissement" } }, "outputs": { "0": { "tooltip": null } } };
const SamplerLMS = { "display_name": "SamplerLMS", "inputs": { "order": { "name": "ordre" } } };
const SamplerSASolver = { "display_name": "ÉchantillonneurSASolveur", "inputs": { "corrector_order": { "name": "ordre_correcteur" }, "eta": { "name": "eta" }, "model": { "name": "modèle" }, "predictor_order": { "name": "ordre_prédicteur" }, "s_noise": { "name": "s_bruit" }, "sde_end_percent": { "name": "pourcent_fin_sde" }, "sde_start_percent": { "name": "pourcent_début_sde" }, "simple_order_2": { "name": "ordre_simple_2" }, "use_pece": { "name": "utiliser_pece" } } };
const SamplingPercentToSigma = { "display_name": "PourcentageÉchantillonnageVersSigma", "inputs": { "model": { "name": "modèle" }, "return_actual_sigma": { "name": "retourner_sigma_réel", "tooltip": "Retourner la valeur sigma réelle au lieu de la valeur utilisée pour les vérifications d'intervalle.\nCela n'affecte que les résultats à 0.0 et 1.0." }, "sampling_percent": { "name": "pourcent_échantillonnage" } }, "outputs": { "0": { "name": "valeur_sigma" } } };
const SaveAnimatedPNG = { "display_name": "EnregistrerPNGAnimé", "inputs": { "compress_level": { "name": "niveau_compression" }, "filename_prefix": { "name": "préfixe_nom_fichier" }, "fps": { "name": "fps" }, "images": { "name": "images" } } };
const SaveAnimatedWEBP = { "display_name": "EnregistrerWEBPAnimé", "inputs": { "filename_prefix": { "name": "préfixe_du_nom_de_fichier" }, "fps": { "name": "fps" }, "images": { "name": "images" }, "lossless": { "name": "sans_perte" }, "method": { "name": "méthode" }, "quality": { "name": "qualité" } } };
const SaveAudio = { "display_name": "EnregistrerAudio", "inputs": { "audio": { "name": "audio" }, "audioUI": { "name": "audioUI" }, "filename_prefix": { "name": "préfixe_du_nom_de_fichier" } } };
const SaveAudioMP3 = { "display_name": "Enregistrer Audio (MP3)", "inputs": { "audio": { "name": "audio" }, "audioUI": { "name": "interface_audio" }, "filename_prefix": { "name": "préfixe_nom_fichier" }, "quality": { "name": "qualité" } } };
const SaveAudioOpus = { "display_name": "Enregistrer Audio (Opus)", "inputs": { "audio": { "name": "audio" }, "audioUI": { "name": "interface_audio" }, "filename_prefix": { "name": "préfixe_nom_fichier" }, "quality": { "name": "qualité" } } };
const SaveGLB = { "display_name": "SaveGLB", "inputs": { "filename_prefix": { "name": "préfixe_du_nom_de_fichier" }, "image": { "name": "image" }, "mesh": { "name": "maillage" } } };
const SaveImage = { "description": "Enregistre les images d'entrée dans votre répertoire de sortie ComfyUI.", "display_name": "Enregistrer Image", "inputs": { "filename_prefix": { "name": "préfixe_du_nom_de_fichier", "tooltip": "Le préfixe pour le fichier à enregistrer. Cela peut inclure des informations de formatage telles que %date:yyyy-MM-dd% ou %Empty Latent Image.width% pour inclure des valeurs à partir de nœuds." }, "images": { "name": "images", "tooltip": "Les images à enregistrer." } } };
const SaveImageWebsocket = { "display_name": "EnregistrerImageWebsocket", "inputs": { "images": { "name": "images" } } };
const SaveLatent = { "display_name": "EnregistrerLatent", "inputs": { "filename_prefix": { "name": "préfixe_du_nom_de_fichier" }, "samples": { "name": "échantillons" } } };
const SaveSVGNode = { "description": "Enregistrer les fichiers SVG sur le disque.", "display_name": "NoeudEnregistrerSVG", "inputs": { "filename_prefix": { "name": "préfixe_nom_fichier", "tooltip": "Le préfixe pour le fichier à enregistrer. Peut inclure des informations de formatage telles que %date:yyyy-MM-dd% ou %Empty Latent Image.width% pour inclure des valeurs des nœuds." }, "svg": { "name": "svg" } } };
const SaveVideo = { "description": "Enregistre les images d'entrée dans votre répertoire de sortie ComfyUI.", "display_name": "Enregistrer la vidéo", "inputs": { "codec": { "name": "codec", "tooltip": "Le codec à utiliser pour la vidéo." }, "filename_prefix": { "name": "préfixe_nom_fichier", "tooltip": "Le préfixe du fichier à enregistrer. Cela peut inclure des informations de formatage telles que %date:yyyy-MM-dd% ou %Empty Latent Image.width% pour inclure des valeurs provenant des nœuds." }, "format": { "name": "format", "tooltip": "Le format sous lequel enregistrer la vidéo." }, "video": { "name": "vidéo", "tooltip": "La vidéo à enregistrer." } } };
const SaveWEBM = { "display_name": "EnregistrerWEBM", "inputs": { "codec": { "name": "codec" }, "crf": { "name": "crf", "tooltip": "Un crf plus élevé signifie une qualité inférieure avec une taille de fichier plus petite, un crf plus bas signifie une qualité supérieure avec une taille de fichier plus grande." }, "filename_prefix": { "name": "préfixe_de_nom_de_fichier" }, "fps": { "name": "fps" }, "images": { "name": "images" } } };
const ScaleROPE = { "description": "Mettre à l'échelle et décaler le ROPE du modèle.", "display_name": "ÉchelleROPE", "inputs": { "model": { "name": "modèle" }, "scale_t": { "name": "échelle_t" }, "scale_x": { "name": "échelle_x" }, "scale_y": { "name": "échelle_y" }, "shift_t": { "name": "décalage_t" }, "shift_x": { "name": "décalage_x" }, "shift_y": { "name": "décalage_y" } }, "outputs": { "0": { "tooltip": null } } };
const SelfAttentionGuidance = { "display_name": "Guidance d'Auto-Attention", "inputs": { "blur_sigma": { "name": "blur_sigma" }, "model": { "name": "modèle" }, "scale": { "name": "échelle" } }, "outputs": { "0": { "tooltip": null } } };
const SetClipHooks = { "display_name": "Définir les Crochets CLIP", "inputs": { "apply_to_conds": { "name": "appliquer_à_conds" }, "clip": { "name": "clip" }, "hooks": { "name": "crochets" }, "schedule_clip": { "name": "programmer_clip" } } };
const SetFirstSigma = { "display_name": "DéfinirPremierSigma", "inputs": { "sigma": { "name": "sigma" }, "sigmas": { "name": "sigmas" } } };
const SetHookKeyframes = { "display_name": "Définir les Images Clés de Crochet", "inputs": { "hook_kf": { "name": "crochet_kf" }, "hooks": { "name": "crochets" } } };
const SetLatentNoiseMask = { "display_name": "Définir le Masque de Bruit Latent", "inputs": { "mask": { "name": "masque" }, "samples": { "name": "échantillons" } } };
const SetUnionControlNetType = { "display_name": "Définir le Type de Réseau de Contrôle d'Union", "inputs": { "control_net": { "name": "réseau_de_contrôle" }, "type": { "name": "type" } }, "outputs": { "0": { "tooltip": null } } };
const SkipLayerGuidanceDiT = { "description": "Version générique du nœud SkipLayerGuidance qui peut être utilisée sur chaque modèle DiT.", "display_name": "SkipLayerGuidanceDiT", "inputs": { "double_layers": { "name": "double_couches" }, "end_percent": { "name": "pourcentage_de_fin" }, "model": { "name": "modèle" }, "rescaling_scale": { "name": "échelle_de_redimensionnement" }, "scale": { "name": "échelle" }, "single_layers": { "name": "couches_simples" }, "start_percent": { "name": "pourcentage_de_départ" } }, "outputs": { "0": { "tooltip": null } } };
const SkipLayerGuidanceDiTSimple = { "description": "Version simple du nœud GuidanceSautCoucheDiT qui modifie uniquement la passe sans condition.", "display_name": "GuidanceSautCoucheDiTSimple", "inputs": { "double_layers": { "name": "couches_doubles" }, "end_percent": { "name": "pourcentage_fin" }, "model": { "name": "modèle" }, "single_layers": { "name": "couches_simples" }, "start_percent": { "name": "pourcentage_début" } }, "outputs": { "0": { "tooltip": null } } };
const SkipLayerGuidanceSD3 = { "description": "Version générique du nœud SkipLayerGuidance qui peut être utilisée sur chaque modèle DiT.", "display_name": "SkipLayerGuidanceSD3", "inputs": { "end_percent": { "name": "pourcentage_de_fin" }, "layers": { "name": "couches" }, "model": { "name": "modèle" }, "scale": { "name": "échelle" }, "start_percent": { "name": "pourcentage_de_départ" } }, "outputs": { "0": { "tooltip": null } } };
const SolidMask = { "display_name": "SolidMask", "inputs": { "height": { "name": "hauteur" }, "value": { "name": "valeur" }, "width": { "name": "largeur" } } };
const SplitAudioChannels = { "description": "Sépare l'audio en canaux gauche et droit.", "display_name": "Séparer les canaux audio", "inputs": { "audio": { "name": "audio" } }, "outputs": { "0": { "name": "gauche" }, "1": { "name": "droite" } } };
const SplitImageWithAlpha = { "display_name": "Diviser l'image avec Alpha", "inputs": { "image": { "name": "image" } }, "outputs": { "0": { "tooltip": null }, "1": { "tooltip": null } } };
const SplitSigmas = { "display_name": "SplitSigmas", "inputs": { "sigmas": { "name": "sigmas" }, "step": { "name": "étape" } }, "outputs": { "0": { "name": "high_sigmas" }, "1": { "name": "low_sigmas" } } };
const SplitSigmasDenoise = { "display_name": "SplitSigmasDenoise", "inputs": { "denoise": { "name": "réduction_du_bruit" }, "sigmas": { "name": "sigmas" } }, "outputs": { "0": { "name": "high_sigmas" }, "1": { "name": "low_sigmas" } } };
const StabilityAudioInpaint = { "description": "Transforme une partie d'un échantillon audio existant en utilisant des instructions textuelles.", "display_name": "Restauration audio Stability AI", "inputs": { "audio": { "name": "audio", "tooltip": "L'audio doit durer entre 6 et 190 secondes." }, "control_after_generate": { "name": "contrôle après génération" }, "duration": { "name": "durée", "tooltip": "Contrôle la durée en secondes de l'audio généré." }, "mask_end": { "name": "fin_masque" }, "mask_start": { "name": "début_masque" }, "model": { "name": "modèle" }, "prompt": { "name": "prompt" }, "seed": { "name": "graine", "tooltip": "La graine aléatoire utilisée pour la génération." }, "steps": { "name": "étapes", "tooltip": "Contrôle le nombre d'étapes d'échantillonnage." } }, "outputs": { "0": { "tooltip": null } } };
const StabilityAudioToAudio = { "description": "Transforme des échantillons audio existants en nouvelles compositions de haute qualité à l'aide d'instructions textuelles.", "display_name": "Stability AI Audio vers Audio", "inputs": { "audio": { "name": "audio", "tooltip": "L'audio doit durer entre 6 et 190 secondes." }, "control_after_generate": { "name": "contrôle après génération" }, "duration": { "name": "durée", "tooltip": "Contrôle la durée en secondes de l'audio généré." }, "model": { "name": "modèle" }, "prompt": { "name": "consigne" }, "seed": { "name": "graine", "tooltip": "La graine aléatoire utilisée pour la génération." }, "steps": { "name": "étapes", "tooltip": "Contrôle le nombre d'étapes d'échantillonnage." }, "strength": { "name": "intensité", "tooltip": "Ce paramètre contrôle l'influence du paramètre audio sur l'audio généré." } }, "outputs": { "0": { "tooltip": null } } };
const StabilityStableImageSD_3_5Node = { "description": "Génère des images de manière synchrone à partir d'un prompt et d'une résolution.", "display_name": "Stability AI Stable Diffusion 3.5 Image", "inputs": { "aspect_ratio": { "name": "aspect_ratio", "tooltip": "Rapport d’aspect de l’image générée." }, "cfg_scale": { "name": "cfg_scale", "tooltip": "À quel point le processus de diffusion suit strictement le texte du prompt (des valeurs plus élevées rapprochent l’image de votre prompt)." }, "control_after_generate": { "name": "control after generate" }, "image": { "name": "image" }, "image_denoise": { "name": "image_denoise", "tooltip": "Dénuagement de l’image d’entrée ; 0,0 donne une image identique à l’entrée, 1,0 équivaut à ne pas fournir d’image du tout." }, "model": { "name": "model" }, "negative_prompt": { "name": "negative_prompt", "tooltip": "Mots-clés de ce que vous ne souhaitez pas voir dans l’image générée. Il s’agit d’une fonctionnalité avancée." }, "prompt": { "name": "prompt", "tooltip": "Ce que vous souhaitez voir dans l’image générée. Un prompt fort et descriptif qui définit clairement les éléments, les couleurs et les sujets donnera de meilleurs résultats." }, "seed": { "name": "seed", "tooltip": "La graine aléatoire utilisée pour créer le bruit." }, "style_preset": { "name": "style_preset", "tooltip": "Style optionnel souhaité pour l’image générée." } }, "outputs": { "0": { "tooltip": null } } };
const StabilityStableImageUltraNode = { "description": "Génère des images de manière synchrone à partir d'un prompt et d'une résolution.", "display_name": "Stability AI Stable Image Ultra", "inputs": { "aspect_ratio": { "name": "aspect_ratio", "tooltip": "Rapport d'aspect de l'image générée." }, "control_after_generate": { "name": "control after generate" }, "image": { "name": "image" }, "image_denoise": { "name": "image_denoise", "tooltip": "Dénuage de l'image d'entrée ; 0.0 donne une image identique à l'entrée, 1.0 comme si aucune image n'avait été fournie." }, "negative_prompt": { "name": "negative_prompt", "tooltip": "Un texte décrivant ce que vous ne souhaitez pas voir dans l'image générée. Il s'agit d'une fonctionnalité avancée." }, "prompt": { "name": "prompt", "tooltip": "Ce que vous souhaitez voir dans l'image générée. Un prompt fort et descriptif qui définit clairement les éléments, les couleurs et les sujets donnera de meilleurs résultats. Pour contrôler le poids d'un mot donné, utilisez le format `(mot:poids)`, où `mot` est le mot dont vous souhaitez contrôler le poids et `poids` est une valeur entre 0 et 1. Par exemple : `Le ciel était d'un (bleu:0.3) vif et (vert:0.8)` indiquerait un ciel bleu et vert, mais plus vert que bleu." }, "seed": { "name": "seed", "tooltip": "La graine aléatoire utilisée pour créer le bruit." }, "style_preset": { "name": "style_preset", "tooltip": "Style souhaité optionnel de l'image générée." } }, "outputs": { "0": { "tooltip": null } } };
const StabilityTextToAudio = { "description": "Génère de la musique et des effets sonores de haute qualité à partir de descriptions textuelles.", "display_name": "Stability AI Texte vers Audio", "inputs": { "control_after_generate": { "name": "contrôle après génération" }, "duration": { "name": "durée", "tooltip": "Contrôle la durée en secondes de l'audio généré." }, "model": { "name": "modèle" }, "prompt": { "name": "consigne" }, "seed": { "name": "graine", "tooltip": "La graine aléatoire utilisée pour la génération." }, "steps": { "name": "étapes", "tooltip": "Contrôle le nombre d'étapes d'échantillonnage." } }, "outputs": { "0": { "tooltip": null } } };
const StabilityUpscaleConservativeNode = { "description": "Agrandit l’image avec des modifications minimales jusqu’à une résolution 4K.", "display_name": "Stability AI Upscale Conservateur", "inputs": { "control_after_generate": { "name": "contrôle après génération" }, "creativity": { "name": "créativité", "tooltip": "Contrôle la probabilité de créer des détails supplémentaires non fortement conditionnés par l’image initiale." }, "image": { "name": "image" }, "negative_prompt": { "name": "prompt négatif", "tooltip": "Mots-clés de ce que vous ne souhaitez pas voir dans l’image générée. Il s’agit d’une fonctionnalité avancée." }, "prompt": { "name": "prompt", "tooltip": "Ce que vous souhaitez voir dans l’image générée. Un prompt fort et descriptif, définissant clairement les éléments, couleurs et sujets, donnera de meilleurs résultats." }, "seed": { "name": "seed", "tooltip": "La graine aléatoire utilisée pour générer le bruit." } }, "outputs": { "0": { "tooltip": null } } };
const StabilityUpscaleCreativeNode = { "description": "Agrandir l’image avec des modifications minimales jusqu’à une résolution 4K.", "display_name": "Stability AI Upscale Creative", "inputs": { "control_after_generate": { "name": "contrôle après génération" }, "creativity": { "name": "créativité", "tooltip": "Contrôle la probabilité de créer des détails supplémentaires non fortement conditionnés par l’image initiale." }, "image": { "name": "image" }, "negative_prompt": { "name": "prompt_négatif", "tooltip": "Mots-clés de ce que vous ne souhaitez pas voir dans l’image générée. Fonctionnalité avancée." }, "prompt": { "name": "prompt", "tooltip": "Ce que vous souhaitez voir dans l’image générée. Un prompt fort et descriptif, définissant clairement les éléments, couleurs et sujets, donnera de meilleurs résultats." }, "seed": { "name": "graine", "tooltip": "La graine aléatoire utilisée pour créer le bruit." }, "style_preset": { "name": "style_prédéfini", "tooltip": "Style souhaité de l’image générée (optionnel)." } }, "outputs": { "0": { "tooltip": null } } };
const StabilityUpscaleFastNode = { "description": "Agrandit rapidement une image via un appel à l’API Stability jusqu’à 4x sa taille d’origine ; destiné à l’agrandissement d’images de faible qualité ou compressées.", "display_name": "Stability AI Agrandissement Rapide", "inputs": { "image": { "name": "image" } }, "outputs": { "0": { "tooltip": null } } };
const StableCascade_EmptyLatentImage = { "display_name": "StableCascade_EmptyLatentImage", "inputs": { "batch_size": { "name": "taille_du_lot" }, "compression": { "name": "compression" }, "height": { "name": "hauteur" }, "width": { "name": "largeur" } }, "outputs": { "0": { "name": "stage_c", "tooltip": null }, "1": { "name": "stage_b", "tooltip": null } } };
const StableCascade_StageB_Conditioning = { "display_name": "StableCascade_StageB_Conditioning", "inputs": { "conditioning": { "name": "conditionnement" }, "stage_c": { "name": "stage_c" } }, "outputs": { "0": { "tooltip": null } } };
const StableCascade_StageC_VAEEncode = { "display_name": "StableCascade_StageC_VAEEncode", "inputs": { "compression": { "name": "compression" }, "image": { "name": "image" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "stage_c", "tooltip": null }, "1": { "name": "stage_b", "tooltip": null } } };
const StableCascade_SuperResolutionControlnet = { "display_name": "StableCascade_SuperResolutionControlnet", "inputs": { "image": { "name": "image" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "entrée_controlnet", "tooltip": null }, "1": { "name": "étape_c", "tooltip": null }, "2": { "name": "étape_b", "tooltip": null } } };
const StableZero123_Conditioning = { "display_name": "StableZero123_Conditioning", "inputs": { "azimuth": { "name": "azimut" }, "batch_size": { "name": "taille_lot" }, "clip_vision": { "name": "clip_vision" }, "elevation": { "name": "élévation" }, "height": { "name": "hauteur" }, "init_image": { "name": "init_image" }, "vae": { "name": "vae" }, "width": { "name": "largeur" } }, "outputs": { "0": { "name": "positif", "tooltip": null }, "1": { "name": "négatif", "tooltip": null }, "2": { "name": "latent", "tooltip": null } } };
const StableZero123_Conditioning_Batched = { "display_name": "StableZero123_Conditioning_Batched", "inputs": { "azimuth": { "name": "azimut" }, "azimuth_batch_increment": { "name": "incrément_lot_azimut" }, "batch_size": { "name": "taille_lot" }, "clip_vision": { "name": "clip_vision" }, "elevation": { "name": "élévation" }, "elevation_batch_increment": { "name": "incrément_lot_élévation" }, "height": { "name": "hauteur" }, "init_image": { "name": "init_image" }, "vae": { "name": "vae" }, "width": { "name": "largeur" } }, "outputs": { "0": { "name": "positif", "tooltip": null }, "1": { "name": "négatif", "tooltip": null }, "2": { "name": "latent", "tooltip": null } } };
const StringCompare = { "display_name": "Comparer", "inputs": { "case_sensitive": { "name": "sensible_casse" }, "mode": { "name": "mode" }, "string_a": { "name": "chaîne_a" }, "string_b": { "name": "chaîne_b" } }, "outputs": { "0": { "tooltip": null } } };
const StringConcatenate = { "display_name": "Concaténer", "inputs": { "delimiter": { "name": "délimiteur" }, "string_a": { "name": "string_a" }, "string_b": { "name": "string_b" } }, "outputs": { "0": { "tooltip": null } } };
const StringContains = { "display_name": "Contient", "inputs": { "case_sensitive": { "name": "sensible_à_la_casse" }, "string": { "name": "chaîne" }, "substring": { "name": "sous-chaîne" } }, "outputs": { "0": { "name": "contient", "tooltip": null } } };
const StringLength = { "display_name": "Longueur", "inputs": { "string": { "name": "chaîne" } }, "outputs": { "0": { "name": "longueur", "tooltip": null } } };
const StringReplace = { "display_name": "Remplacer", "inputs": { "find": { "name": "rechercher" }, "replace": { "name": "remplacer" }, "string": { "name": "chaîne" } }, "outputs": { "0": { "tooltip": null } } };
const StringSubstring = { "display_name": "Sous-chaîne", "inputs": { "end": { "name": "fin" }, "start": { "name": "début" }, "string": { "name": "chaîne" } }, "outputs": { "0": { "tooltip": null } } };
const StringTrim = { "display_name": "Tronquer", "inputs": { "mode": { "name": "mode" }, "string": { "name": "chaîne" } }, "outputs": { "0": { "tooltip": null } } };
const StyleModelApply = { "display_name": "Appliquer le modèle de style", "inputs": { "clip_vision_output": { "name": "sortie_clip_vision" }, "conditioning": { "name": "conditionnement" }, "strength": { "name": "force" }, "strength_type": { "name": "type_de_force" }, "style_model": { "name": "modèle_de_style" } } };
const StyleModelLoader = { "display_name": "Charger le modèle de style", "inputs": { "style_model_name": { "name": "nom_du_modèle_de_style" } } };
const T5TokenizerOptions = { "display_name": "T5TokenizerOptions", "inputs": { "clip": { "name": "clip" }, "min_length": { "name": "longueur_min" }, "min_padding": { "name": "remplissage_min" } }, "outputs": { "0": { "tooltip": null } } };
const TCFG = { "description": "TCFG – Amortissement tangentiel CFG (2503.18137)\n\nAffine le uncond (négatif) pour l'aligner avec le cond (positif) afin d'améliorer la qualité.", "display_name": "Amortissement tangentiel CFG", "inputs": { "model": { "name": "modèle" } }, "outputs": { "0": { "name": "modèle_corrigé", "tooltip": null } } };
const TemporalScoreRescaling = { "description": "[Fonction post-CFG]\nTSR - Rééchelonnage temporel des scores (2510.01184)\n\nRééchelonne le score ou le bruit du modèle pour orienter la diversité de l'échantillonnage.", "display_name": "TSR - Rééchelonnage temporel des scores", "inputs": { "model": { "name": "modèle" }, "tsr_k": { "name": "tsr_k", "tooltip": "Contrôle la force de rééchelonnage.\nUn k plus faible produit des résultats plus détaillés ; un k plus élevé produit des résultats plus lisses dans la génération d'images. Régler k = 1 désactive le rééchelonnage." }, "tsr_sigma": { "name": "tsr_sigma", "tooltip": "Contrôle à quel moment le rééchelonnage prend effet.\nDes valeurs plus grandes prennent effet plus tôt." } }, "outputs": { "0": { "name": "modèle_corrigé", "tooltip": null } } };
const TextEncodeAceStepAudio = { "display_name": "TextEncodeAceStepAudio", "inputs": { "clip": { "name": "clip" }, "lyrics": { "name": "paroles" }, "lyrics_strength": { "name": "force_des_paroles" }, "tags": { "name": "balises" } }, "outputs": { "0": { "tooltip": null } } };
const TextEncodeHunyuanVideo_ImageToVideo = { "display_name": "TextEncodeHunyuanVideo_ImageToVideo", "inputs": { "clip": { "name": "clip" }, "clip_vision_output": { "name": "sortie_vision_clip" }, "image_interleave": { "name": "entrelacement_image", "tooltip": "À quel point l'image influence les choses par rapport à l'invite de texte. Un nombre plus élevé signifie plus d'influence de l'invite de texte." }, "prompt": { "name": "invite" } }, "outputs": { "0": { "tooltip": null } } };
const TextEncodeQwenImageEdit = { "display_name": "TextEncodeQwenImageEdit", "inputs": { "clip": { "name": "clip" }, "image": { "name": "image" }, "prompt": { "name": "invite" }, "vae": { "name": "vae" } }, "outputs": { "0": { "tooltip": null } } };
const TextEncodeQwenImageEditPlus = { "display_name": "TextEncodeQwenImageEditPlus", "inputs": { "clip": { "name": "clip" }, "image1": { "name": "image1" }, "image2": { "name": "image2" }, "image3": { "name": "image3" }, "prompt": { "name": "invite" }, "vae": { "name": "vae" } }, "outputs": { "0": { "tooltip": null } } };
const ThresholdMask = { "display_name": "SeuilMasque", "inputs": { "mask": { "name": "masque" }, "value": { "name": "valeur" } } };
const TomePatchModel = { "display_name": "ModèlePatchTome", "inputs": { "model": { "name": "modèle" }, "ratio": { "name": "ratio" } }, "outputs": { "0": { "tooltip": null } } };
const TorchCompileModel = { "display_name": "ModèleCompilationTorch", "inputs": { "backend": { "name": "backend" }, "model": { "name": "modèle" } }, "outputs": { "0": { "tooltip": null } } };
const TrainLoraNode = { "display_name": "Entraîner LoRA", "inputs": { "algorithm": { "name": "algorithme", "tooltip": "L'algorithme à utiliser pour l'entraînement." }, "batch_size": { "name": "taille_du_lot", "tooltip": "La taille du lot à utiliser pour l'entraînement." }, "control_after_generate": { "name": "contrôle après génération" }, "existing_lora": { "name": "lora_existant", "tooltip": "Le LoRA existant à ajouter. Définir sur Aucun pour un nouveau LoRA." }, "grad_accumulation_steps": { "name": "étapes_accumulation_gradient", "tooltip": "Le nombre d'étapes d'accumulation de gradient à utiliser pour l'entraînement." }, "gradient_checkpointing": { "name": "point de contrôle de gradient", "tooltip": "Utiliser le point de contrôle de gradient pour l'entraînement." }, "latents": { "name": "latents", "tooltip": "Les latents à utiliser pour l'entraînement, servent de jeu de données/entrée du modèle." }, "learning_rate": { "name": "taux_apprentissage", "tooltip": "Le taux d'apprentissage à utiliser pour l'entraînement." }, "lora_dtype": { "name": "type_données_lora", "tooltip": "Le type de données à utiliser pour le LoRA." }, "loss_function": { "name": "fonction_perte", "tooltip": "La fonction de perte à utiliser pour l'entraînement." }, "model": { "name": "modèle", "tooltip": "Le modèle sur lequel entraîner le LoRA." }, "optimizer": { "name": "optimiseur", "tooltip": "L'optimiseur à utiliser pour l'entraînement." }, "positive": { "name": "positif", "tooltip": "Le conditionnement positif à utiliser pour l'entraînement." }, "rank": { "name": "rang", "tooltip": "Le rang des couches LoRA." }, "seed": { "name": "graine", "tooltip": "La graine à utiliser pour l'entraînement (utilisée dans le générateur pour l'initialisation des poids LoRA et l'échantillonnage du bruit)." }, "steps": { "name": "étapes", "tooltip": "Le nombre d'étapes pour entraîner le LoRA." }, "training_dtype": { "name": "type_données_entraînement", "tooltip": "Le type de données à utiliser pour l'entraînement." } }, "outputs": { "0": { "name": "modèle_avec_lora" }, "1": { "name": "lora" }, "2": { "name": "perte" }, "3": { "name": "étapes" } } };
const TrimAudioDuration = { "description": "Tronquer le tenseur audio dans la plage de temps choisie.", "display_name": "Régler la Durée Audio", "inputs": { "audio": { "name": "audio" }, "duration": { "name": "durée", "tooltip": "Durée en secondes" }, "start_index": { "name": "index_début", "tooltip": "Heure de début en secondes, peut être négative pour compter depuis la fin (prend en charge les sous-secondes)." } } };
const TrimVideoLatent = { "display_name": "TrimVideoLatent", "inputs": { "samples": { "name": "échantillons" }, "trim_amount": { "name": "quantité de découpe" } }, "outputs": { "0": { "tooltip": null } } };
const TripleCLIPLoader = { "description": "[Recettes]\n\nsd3: clip-l, clip-g, t5", "display_name": "ChargeurTripleCLIP", "inputs": { "clip_name1": { "name": "nom_clip1" }, "clip_name2": { "name": "nom_clip2" }, "clip_name3": { "name": "nom_clip3" } }, "outputs": { "0": { "tooltip": null } } };
const TripoConversionNode = { "display_name": "Tripo : Convertir le modèle", "inputs": { "face_limit": { "name": "limite_faces" }, "format": { "name": "format" }, "original_model_task_id": { "name": "id_tâche_modèle_original" }, "quad": { "name": "quad" }, "texture_format": { "name": "format_texture" }, "texture_size": { "name": "taille_texture" } } };
const TripoImageToModelNode = { "display_name": "Tripo : Image vers Modèle", "inputs": { "face_limit": { "name": "limite_faces" }, "image": { "name": "image" }, "model_seed": { "name": "graine_modèle" }, "model_version": { "name": "version_modèle", "tooltip": "La version du modèle à utiliser pour la génération" }, "orientation": { "name": "orientation" }, "pbr": { "name": "pbr" }, "quad": { "name": "quad" }, "style": { "name": "style" }, "texture": { "name": "texture" }, "texture_alignment": { "name": "alignement_texture" }, "texture_quality": { "name": "qualité_texture" }, "texture_seed": { "name": "graine_texture" } }, "outputs": { "0": { "name": "fichier_modèle", "tooltip": null }, "1": { "name": "id_tâche_modèle", "tooltip": null } } };
const TripoMultiviewToModelNode = { "display_name": "Tripo : Multivue vers Modèle", "inputs": { "face_limit": { "name": "limite_visage" }, "image": { "name": "image" }, "image_back": { "name": "image_arrière" }, "image_left": { "name": "image_gauche" }, "image_right": { "name": "image_droite" }, "model_seed": { "name": "graine_modèle" }, "model_version": { "name": "version_modèle", "tooltip": "La version du modèle à utiliser pour la génération" }, "orientation": { "name": "orientation" }, "pbr": { "name": "pbr" }, "quad": { "name": "quad" }, "texture": { "name": "texture" }, "texture_alignment": { "name": "alignement_texture" }, "texture_quality": { "name": "qualité_texture" }, "texture_seed": { "name": "graine_texture" } }, "outputs": { "0": { "name": "fichier_modèle", "tooltip": null }, "1": { "name": "ID_tâche_modèle", "tooltip": null } } };
const TripoRefineNode = { "description": "Affinez un modèle d'ébauche créé uniquement par les modèles Tripo v1.4.", "display_name": "Tripo : Modèle de raffinement d'ébauche", "inputs": { "model_task_id": { "name": "ID_tâche_modèle", "tooltip": "Doit être un modèle Tripo v1.4" } }, "outputs": { "0": { "name": "fichier_modèle", "tooltip": null }, "1": { "name": "ID_tâche_modèle", "tooltip": null } } };
const TripoRetargetNode = { "display_name": "Tripo : Modèle squeletté redirigé", "inputs": { "animation": { "name": "animation" }, "original_model_task_id": { "name": "ID_tâche_modèle_original" } }, "outputs": { "0": { "name": "fichier_modèle", "tooltip": null }, "1": { "name": "ID_tâche_redirection", "tooltip": null } } };
const TripoRigNode = { "display_name": "Tripo : Modèle squeletté", "inputs": { "original_model_task_id": { "name": "ID_tâche_modèle_original" } }, "outputs": { "0": { "name": "fichier_modèle", "tooltip": null }, "1": { "name": "ID_tâche_squelettage", "tooltip": null } } };
const TripoTextToModelNode = { "display_name": "Tripo : Texte vers Modèle", "inputs": { "face_limit": { "name": "limite_visage" }, "image_seed": { "name": "graine_image" }, "model_seed": { "name": "modèle_graine" }, "model_version": { "name": "version_modèle" }, "negative_prompt": { "name": "invite_négative" }, "pbr": { "name": "pbr" }, "prompt": { "name": "invite" }, "quad": { "name": "quad" }, "style": { "name": "style" }, "texture": { "name": "texture" }, "texture_quality": { "name": "qualité_texture" }, "texture_seed": { "name": "texture_graine" } }, "outputs": { "0": { "name": "fichier_modèle", "tooltip": null }, "1": { "name": "modèle id_tâche", "tooltip": null } } };
const TripoTextureNode = { "display_name": "Tripo : Modèle de texture", "inputs": { "model_task_id": { "name": "modèle_id_tâche" }, "pbr": { "name": "pbr" }, "texture": { "name": "texture" }, "texture_alignment": { "name": "alignement_texture" }, "texture_quality": { "name": "qualité_texture" }, "texture_seed": { "name": "texture_graine" } }, "outputs": { "0": { "name": "fichier_modèle", "tooltip": null }, "1": { "name": "modèle id_tâche", "tooltip": null } } };
const UNETLoader = { "display_name": "Charger Modèle Diffusion", "inputs": { "unet_name": { "name": "nom_unet" }, "weight_dtype": { "name": "dtype_poids" } } };
const UNetCrossAttentionMultiply = { "display_name": "UNetMultiplicationAttentionCroisée", "inputs": { "k": { "name": "k" }, "model": { "name": "modèle" }, "out": { "name": "sortie" }, "q": { "name": "q" }, "v": { "name": "v" } }, "outputs": { "0": { "tooltip": null } } };
const UNetSelfAttentionMultiply = { "display_name": "UNetMultiplicationAutoAttention", "inputs": { "k": { "name": "k" }, "model": { "name": "modèle" }, "out": { "name": "sortie" }, "q": { "name": "q" }, "v": { "name": "v" } }, "outputs": { "0": { "tooltip": null } } };
const UNetTemporalAttentionMultiply = { "display_name": "UNetTemporalAttentionMultiply", "inputs": { "cross_structural": { "name": "cross_structural" }, "cross_temporal": { "name": "cross_temporal" }, "model": { "name": "modèle" }, "self_structural": { "name": "self_structural" }, "self_temporal": { "name": "self_temporal" } }, "outputs": { "0": { "tooltip": null } } };
const USOStyleReference = { "display_name": "USOStyleReference", "inputs": { "clip_vision_output": { "name": "sortie_vision_clip" }, "model": { "name": "modèle" }, "model_patch": { "name": "correctif_modèle" } } };
const UpscaleModelLoader = { "display_name": "Charger le modèle de mise à l'échelle", "inputs": { "model_name": { "name": "nom_du_modèle" } }, "outputs": { "0": { "tooltip": null } } };
const VAEDecode = { "description": "Décode les images latentes en images d'espace de pixels.", "display_name": "VAE Decode", "inputs": { "samples": { "name": "échantillons", "tooltip": "Le latent à décoder." }, "vae": { "name": "vae", "tooltip": "Le modèle VAE utilisé pour le décodage du latent." } }, "outputs": { "0": { "tooltip": "L'image décodée." } } };
const VAEDecodeAudio = { "display_name": "VAEDecodeAudio", "inputs": { "samples": { "name": "échantillons" }, "vae": { "name": "vae" } } };
const VAEDecodeHunyuan3D = { "display_name": "VAEDecodeHunyuan3D", "inputs": { "num_chunks": { "name": "nombre_de_morceaux" }, "octree_resolution": { "name": "résolution_octree" }, "samples": { "name": "échantillons" }, "vae": { "name": "vae" } } };
const VAEDecodeTiled = { "display_name": "VAE Decode (Tiled)", "inputs": { "overlap": { "name": "chevauchement" }, "samples": { "name": "échantillons" }, "temporal_overlap": { "name": "chevauchement_temporel", "tooltip": "Uniquement utilisé pour les VAE vidéo : Nombre de trames à chevaucher." }, "temporal_size": { "name": "taille_temporelle", "tooltip": "Uniquement utilisé pour les VAE vidéo : Nombre de trames à décoder à la fois." }, "tile_size": { "name": "taille_de_tuile" }, "vae": { "name": "vae" } } };
const VAEEncode = { "display_name": "VAE Encode", "inputs": { "pixels": { "name": "pixels" }, "vae": { "name": "vae" } } };
const VAEEncodeAudio = { "display_name": "VAEEncodeAudio", "inputs": { "audio": { "name": "audio" }, "vae": { "name": "vae" } } };
const VAEEncodeForInpaint = { "display_name": "VAE Encode (pour Inpainting)", "inputs": { "grow_mask_by": { "name": "agrandir_masque_par" }, "mask": { "name": "masque" }, "pixels": { "name": "pixels" }, "vae": { "name": "vae" } } };
const VAEEncodeTiled = { "display_name": "VAE Encode (Tiled)", "inputs": { "overlap": { "name": "chevauchement" }, "pixels": { "name": "pixels" }, "temporal_overlap": { "name": "chevauchement_temporel", "tooltip": "Uniquement utilisé pour les VAE vidéo : Nombre de trames à chevaucher." }, "temporal_size": { "name": "taille_temporelle", "tooltip": "Uniquement utilisé pour les VAE vidéo : Nombre de trames à encoder à la fois." }, "tile_size": { "name": "taille_de_tuile" }, "vae": { "name": "vae" } } };
const VAELoader = { "display_name": "Charger VAE", "inputs": { "vae_name": { "name": "nom_vae" } } };
const VAESave = { "display_name": "VAESauvegarder", "inputs": { "filename_prefix": { "name": "préfixe_de_fichier" }, "vae": { "name": "vae" } } };
const VPScheduler = { "display_name": "PlanificateurVP", "inputs": { "beta_d": { "name": "beta_d" }, "beta_min": { "name": "beta_min" }, "eps_s": { "name": "eps_s" }, "steps": { "name": "étapes" } } };
const Veo3VideoGenerationNode = { "description": "Génère des vidéos à partir de descriptions textuelles en utilisant l'API Google Veo 3", "display_name": "Génération vidéo Google Veo 3", "inputs": { "aspect_ratio": { "name": "ratio_d'aspect", "tooltip": "Ratio d'aspect de la vidéo en sortie" }, "control_after_generate": { "name": "contrôle après génération" }, "duration_seconds": { "name": "durée_secondes", "tooltip": "Durée de la vidéo en sortie en secondes (Veo 3 ne prend en charge que 8 secondes)" }, "enhance_prompt": { "name": "améliorer_invite", "tooltip": "Indique s'il faut améliorer l'invite avec une assistance IA" }, "generate_audio": { "name": "générer_audio", "tooltip": "Générer l'audio pour la vidéo. Pris en charge par tous les modèles Veo 3." }, "image": { "name": "image", "tooltip": "Image de référence optionnelle pour guider la génération vidéo" }, "model": { "name": "modèle", "tooltip": "Modèle Veo 3 à utiliser pour la génération vidéo" }, "negative_prompt": { "name": "invite_négative", "tooltip": "Invite textuelle négative pour guider ce qu'il faut éviter dans la vidéo" }, "person_generation": { "name": "génération_personnes", "tooltip": "Indique s'il faut autoriser la génération de personnes dans la vidéo" }, "prompt": { "name": "invite", "tooltip": "Description textuelle de la vidéo" }, "seed": { "name": "graine", "tooltip": "Graine pour la génération vidéo (0 pour aléatoire)" } }, "outputs": { "0": { "tooltip": null } } };
const VeoVideoGenerationNode = { "description": "Génère des vidéos à partir de prompts textuels en utilisant l'API Veo de Google", "display_name": "Génération de vidéo Google Veo2", "inputs": { "aspect_ratio": { "name": "aspect_ratio", "tooltip": "Format d'image de la vidéo générée" }, "control_after_generate": { "name": "control after generate" }, "duration_seconds": { "name": "duration_seconds", "tooltip": "Durée de la vidéo générée en secondes" }, "enhance_prompt": { "name": "enhance_prompt", "tooltip": "Améliorer le prompt avec l'aide de l'IA" }, "image": { "name": "image", "tooltip": "Image de référence optionnelle pour guider la génération vidéo" }, "model": { "name": "modèle", "tooltip": "Modèle Veo 2 à utiliser pour la génération vidéo" }, "negative_prompt": { "name": "negative_prompt", "tooltip": "Prompt négatif pour indiquer ce qu'il faut éviter dans la vidéo" }, "person_generation": { "name": "person_generation", "tooltip": "Autoriser la génération de personnes dans la vidéo" }, "prompt": { "name": "prompt", "tooltip": "Description textuelle de la vidéo" }, "seed": { "name": "seed", "tooltip": "Graine pour la génération vidéo (0 pour aléatoire)" } }, "outputs": { "0": { "tooltip": null } } };
const VideoLinearCFGGuidance = { "display_name": "Guidance VideoLinearCFG", "inputs": { "min_cfg": { "name": "min_cfg" }, "model": { "name": "modèle" } } };
const VideoTriangleCFGGuidance = { "display_name": "Guidance VideoTriangleCFG", "inputs": { "min_cfg": { "name": "min_cfg" }, "model": { "name": "modèle" } } };
const ViduImageToVideoNode = { "description": "Générer une vidéo à partir d'une image et d'un éventuel prompt", "display_name": "Génération vidéo Vidu à partir d'image", "inputs": { "control_after_generate": { "name": "contrôle après génération" }, "duration": { "name": "durée", "tooltip": "Durée de la vidéo de sortie en secondes" }, "image": { "name": "image", "tooltip": "Une image à utiliser comme image de départ pour la vidéo générée" }, "model": { "name": "modèle", "tooltip": "Nom du modèle" }, "movement_amplitude": { "name": "amplitude_mouvement", "tooltip": "L'amplitude de mouvement des objets dans le cadre" }, "prompt": { "name": "prompt", "tooltip": "Une description textuelle pour la génération vidéo" }, "resolution": { "name": "résolution", "tooltip": "Les valeurs prises en charge peuvent varier selon le modèle et la durée" }, "seed": { "name": "graine", "tooltip": "Graine pour la génération vidéo (0 pour aléatoire)" } }, "outputs": { "0": { "tooltip": null } } };
const ViduReferenceVideoNode = { "description": "Générer une vidéo à partir de plusieurs images et d'un prompt", "display_name": "Génération vidéo Vidu à partir de référence", "inputs": { "aspect_ratio": { "name": "ratio_aspect", "tooltip": "Le ratio d'aspect de la vidéo de sortie" }, "control_after_generate": { "name": "contrôle après génération" }, "duration": { "name": "durée", "tooltip": "Durée de la vidéo de sortie en secondes" }, "images": { "name": "images", "tooltip": "Images à utiliser comme références pour générer une vidéo avec des sujets cohérents (max 7 images)." }, "model": { "name": "modèle", "tooltip": "Nom du modèle" }, "movement_amplitude": { "name": "amplitude_mouvement", "tooltip": "L'amplitude de mouvement des objets dans le cadre" }, "prompt": { "name": "prompt", "tooltip": "Une description textuelle pour la génération vidéo" }, "resolution": { "name": "résolution", "tooltip": "Les valeurs prises en charge peuvent varier selon le modèle et la durée" }, "seed": { "name": "graine", "tooltip": "Graine pour la génération vidéo (0 pour aléatoire)" } }, "outputs": { "0": { "tooltip": null } } };
const ViduStartEndToVideoNode = { "description": "Générer une vidéo à partir d'images de début et de fin et d'une description", "display_name": "Génération vidéo Vidu de début à fin", "inputs": { "control_after_generate": { "name": "contrôle après génération" }, "duration": { "name": "durée", "tooltip": "Durée de la vidéo de sortie en secondes" }, "end_frame": { "name": "image_fin", "tooltip": "Image de fin" }, "first_frame": { "name": "première_image", "tooltip": "Image de début" }, "model": { "name": "modèle", "tooltip": "Nom du modèle" }, "movement_amplitude": { "name": "amplitude_mouvement", "tooltip": "L'amplitude du mouvement des objets dans l'image" }, "prompt": { "name": "description", "tooltip": "Description textuelle pour la génération vidéo" }, "resolution": { "name": "résolution", "tooltip": "Les valeurs prises en charge peuvent varier selon le modèle et la durée" }, "seed": { "name": "graine", "tooltip": "Graine pour la génération vidéo (0 pour aléatoire)" } }, "outputs": { "0": { "tooltip": null } } };
const ViduTextToVideoNode = { "description": "Générer une vidéo à partir d'une description textuelle", "display_name": "Génération vidéo Vidu à partir de texte", "inputs": { "aspect_ratio": { "name": "ratio_aspect", "tooltip": "Le ratio d'aspect de la vidéo de sortie" }, "control_after_generate": { "name": "contrôle après génération" }, "duration": { "name": "durée", "tooltip": "Durée de la vidéo de sortie en secondes" }, "model": { "name": "modèle", "tooltip": "Nom du modèle" }, "movement_amplitude": { "name": "amplitude_mouvement", "tooltip": "L'amplitude du mouvement des objets dans l'image" }, "prompt": { "name": "description", "tooltip": "Description textuelle pour la génération vidéo" }, "resolution": { "name": "résolution", "tooltip": "Les valeurs prises en charge peuvent varier selon le modèle et la durée" }, "seed": { "name": "graine", "tooltip": "Graine pour la génération vidéo (0 pour aléatoire)" } }, "outputs": { "0": { "tooltip": null } } };
const VoxelToMesh = { "display_name": "VoxelToMesh", "inputs": { "algorithm": { "name": "algorithme" }, "threshold": { "name": "seuil" }, "voxel": { "name": "voxel" } } };
const VoxelToMeshBasic = { "display_name": "VoxelToMeshBasic", "inputs": { "threshold": { "name": "seuil" }, "voxel": { "name": "voxel" } } };
const Wan22FunControlToVideo = { "display_name": "Wan22FunControlToVideo", "inputs": { "batch_size": { "name": "taille_du_lot" }, "control_video": { "name": "vidéo_de_contrôle" }, "height": { "name": "hauteur" }, "length": { "name": "longueur" }, "negative": { "name": "négatif" }, "positive": { "name": "positif" }, "ref_image": { "name": "image_de_référence" }, "vae": { "name": "vae" }, "width": { "name": "largeur" } }, "outputs": { "0": { "name": "positif", "tooltip": null }, "1": { "name": "négatif", "tooltip": null }, "2": { "name": "latent", "tooltip": null } } };
const Wan22ImageToVideoLatent = { "display_name": "Wan22ImageToVideoLatent", "inputs": { "batch_size": { "name": "taille_du_lot" }, "height": { "name": "hauteur" }, "length": { "name": "longueur" }, "start_image": { "name": "image_de_départ" }, "vae": { "name": "vae" }, "width": { "name": "largeur" } }, "outputs": { "0": { "tooltip": null } } };
const WanAnimateToVideo = { "display_name": "WanAnimateToVideo", "inputs": { "background_video": { "name": "vidéo_arrière_plan" }, "batch_size": { "name": "taille_du_lot" }, "character_mask": { "name": "masque_personnage" }, "clip_vision_output": { "name": "sortie_vision_clip" }, "continue_motion": { "name": "poursuite_mouvement" }, "continue_motion_max_frames": { "name": "images_max_poursuite_mouvement" }, "face_video": { "name": "vidéo_visage" }, "height": { "name": "hauteur" }, "length": { "name": "longueur" }, "negative": { "name": "négatif" }, "pose_video": { "name": "vidéo_pose" }, "positive": { "name": "positif" }, "reference_image": { "name": "image_de_référence" }, "vae": { "name": "vae" }, "video_frame_offset": { "name": "décalage_image_vidéo", "tooltip": "Le nombre d'images à avancer dans toutes les vidéos d'entrée. Utilisé pour générer des vidéos plus longues par segments. Connectez à la sortie video_frame_offset du nœud précédent pour étendre une vidéo." }, "width": { "name": "largeur" } }, "outputs": { "0": { "name": "positif", "tooltip": null }, "1": { "name": "négatif", "tooltip": null }, "2": { "name": "latent", "tooltip": null }, "3": { "name": "latent_rogné", "tooltip": null }, "4": { "name": "image_rognée", "tooltip": null }, "5": { "name": "décalage de trame vidéo", "tooltip": null } } };
const WanCameraEmbedding = { "display_name": "Intégration de caméra Wan", "inputs": { "camera_pose": { "name": "pose de caméra" }, "cx": { "name": "cx" }, "cy": { "name": "cy" }, "fx": { "name": "fx" }, "fy": { "name": "fy" }, "height": { "name": "hauteur" }, "length": { "name": "longueur" }, "speed": { "name": "vitesse" }, "width": { "name": "largeur" } }, "outputs": { "0": { "name": "intégration de caméra", "tooltip": null }, "1": { "name": "largeur", "tooltip": null }, "2": { "name": "hauteur", "tooltip": null }, "3": { "name": "longueur", "tooltip": null } } };
const WanCameraImageToVideo = { "display_name": "Image vers vidéo WanCamera", "inputs": { "batch_size": { "name": "taille du lot" }, "camera_conditions": { "name": "conditions de caméra" }, "clip_vision_output": { "name": "sortie de vision de clip" }, "height": { "name": "hauteur" }, "length": { "name": "longueur" }, "negative": { "name": "négatif" }, "positive": { "name": "positif" }, "start_image": { "name": "image de départ" }, "vae": { "name": "vae" }, "width": { "name": "largeur" } }, "outputs": { "0": { "name": "positif", "tooltip": null }, "1": { "name": "négatif", "tooltip": null }, "2": { "name": "latent", "tooltip": null } } };
const WanContextWindowsManual = { "description": "Définir manuellement les fenêtres de contexte pour les modèles de type WAN (dim=2).", "display_name": "Fenêtres de contexte WAN (Manuel)", "inputs": { "closed_loop": { "name": "boucle_fermée", "tooltip": "Indique si la boucle de la fenêtre contextuelle doit être fermée ; applicable uniquement aux échéanciers en boucle." }, "context_length": { "name": "longueur de contexte", "tooltip": "La longueur de la fenêtre de contexte." }, "context_overlap": { "name": "chevauchement de contexte", "tooltip": "Le chevauchement de la fenêtre de contexte." }, "context_schedule": { "name": "planification de contexte", "tooltip": "Le pas de la fenêtre de contexte." }, "context_stride": { "name": "pas de contexte", "tooltip": "La progression de la fenêtre contextuelle ; applicable uniquement aux échéanciers uniformes." }, "fuse_method": { "name": "méthode_de_fusion", "tooltip": "La méthode à utiliser pour fusionner les fenêtres contextuelles." }, "model": { "name": "modèle", "tooltip": "Le modèle auquel appliquer les fenêtres de contexte pendant l'échantillonnage." } }, "outputs": { "0": { "tooltip": "Le modèle avec fenêtres contextuelles appliquées pendant l'échantillonnage." } } };
const WanFirstLastFrameToVideo = { "display_name": "WanFirstLastFrameToVideo", "inputs": { "batch_size": { "name": "taille_du_lot" }, "clip_vision_end_image": { "name": "clip_vision_image_de_fin" }, "clip_vision_start_image": { "name": "clip_vision_image_de_départ" }, "end_image": { "name": "image_de_fin" }, "height": { "name": "hauteur" }, "length": { "name": "longueur" }, "negative": { "name": "négatif" }, "positive": { "name": "positif" }, "start_image": { "name": "image_de_départ" }, "vae": { "name": "vae" }, "width": { "name": "largeur" } }, "outputs": { "0": { "name": "positif", "tooltip": null }, "1": { "name": "négatif", "tooltip": null }, "2": { "name": "latent", "tooltip": null } } };
const WanFunControlToVideo = { "display_name": "WanFunControlToVideo", "inputs": { "batch_size": { "name": "taille_du_lot" }, "clip_vision_output": { "name": "clip_vision_output" }, "control_video": { "name": "contrôler_la_vidéo" }, "height": { "name": "hauteur" }, "length": { "name": "longueur" }, "negative": { "name": "négatif" }, "positive": { "name": "positif" }, "start_image": { "name": "image_de_départ" }, "vae": { "name": "vae" }, "width": { "name": "largeur" } }, "outputs": { "0": { "name": "positif", "tooltip": null }, "1": { "name": "négatif", "tooltip": null }, "2": { "name": "latent", "tooltip": null } } };
const WanFunInpaintToVideo = { "display_name": "WanFunInpaintToVideo", "inputs": { "batch_size": { "name": "taille_du_lot" }, "clip_vision_output": { "name": "clip_vision_output" }, "end_image": { "name": "image_de_fin" }, "height": { "name": "hauteur" }, "length": { "name": "longueur" }, "negative": { "name": "négatif" }, "positive": { "name": "positif" }, "start_image": { "name": "image_de_départ" }, "vae": { "name": "vae" }, "width": { "name": "largeur" } }, "outputs": { "0": { "name": "positif", "tooltip": null }, "1": { "name": "négatif", "tooltip": null }, "2": { "name": "latent", "tooltip": null } } };
const WanHuMoImageToVideo = { "display_name": "WanHuMoImageToVideo", "inputs": { "audio_encoder_output": { "name": "sortie_encodeur_audio" }, "batch_size": { "name": "taille_du_lot" }, "height": { "name": "hauteur" }, "length": { "name": "longueur" }, "negative": { "name": "négatif" }, "positive": { "name": "positif" }, "ref_image": { "name": "image_référence" }, "vae": { "name": "vae" }, "width": { "name": "largeur" } }, "outputs": { "0": { "name": "positif", "tooltip": null }, "1": { "name": "négatif", "tooltip": null }, "2": { "name": "latent", "tooltip": null } } };
const WanImageToImageApi = { "description": "Génère une image à partir d'une ou deux images d'entrée et d'une invite texte. L'image de sortie est actuellement fixée à 1,6 MP ; son rapport d'aspect correspond à l'image/aux images d'entrée.", "display_name": "Wan Image vers Image", "inputs": { "control_after_generate": { "name": "contrôle après génération" }, "image": { "name": "image", "tooltip": "Édition d'image unique ou fusion d'images multiples, maximum 2 images." }, "model": { "name": "modèle", "tooltip": "Modèle à utiliser." }, "negative_prompt": { "name": "invite_négative", "tooltip": "Invite texte négative pour guider ce qu'il faut éviter." }, "prompt": { "name": "invite", "tooltip": "Invite utilisée pour décrire les éléments et caractéristiques visuelles, prend en charge l'anglais/le chinois." }, "seed": { "name": "graine", "tooltip": "Graine à utiliser pour la génération." }, "watermark": { "name": "filigrane", "tooltip": `Indique s'il faut ajouter un filigrane "Généré par IA" au résultat.` } }, "outputs": { "0": { "tooltip": null } } };
const WanImageToVideo = { "display_name": "WanImageVersVidéo", "inputs": { "batch_size": { "name": "taille_du_lot" }, "clip_vision_output": { "name": "sortie_vision_clip" }, "height": { "name": "hauteur" }, "length": { "name": "longueur" }, "negative": { "name": "négatif" }, "positive": { "name": "positive" }, "start_image": { "name": "image_de_départ" }, "vae": { "name": "vae" }, "width": { "name": "largeur" } }, "outputs": { "0": { "name": "positive", "tooltip": null }, "1": { "name": "négatif", "tooltip": null }, "2": { "name": "latent", "tooltip": null } } };
const WanImageToVideoApi = { "description": "Génère une vidéo basée sur la première image et l'invite texte.", "display_name": "Wan Image vers Vidéo", "inputs": { "audio": { "name": "audio", "tooltip": "L'audio doit contenir une voix claire et forte, sans bruit parasite ni musique de fond." }, "control_after_generate": { "name": "contrôle après génération" }, "duration": { "name": "durée", "tooltip": "Durées disponibles : 5 et 10 secondes" }, "generate_audio": { "name": "générer_audio", "tooltip": "S'il n'y a pas d'entrée audio, générer automatiquement l'audio." }, "image": { "name": "image" }, "model": { "name": "modèle", "tooltip": "Modèle à utiliser." }, "negative_prompt": { "name": "invite_négative", "tooltip": "Invite textuelle négative pour guider ce qu'il faut éviter." }, "prompt": { "name": "invite", "tooltip": "Invite utilisée pour décrire les éléments et les caractéristiques visuelles, prend en charge l'anglais/le chinois." }, "prompt_extend": { "name": "extension_invite", "tooltip": "S'il faut améliorer l'invite avec l'assistance de l'IA." }, "resolution": { "name": "résolution" }, "seed": { "name": "graine", "tooltip": "Graine à utiliser pour la génération." }, "watermark": { "name": "filigrane", "tooltip": `S'il faut ajouter un filigrane "Généré par IA" au résultat.` } }, "outputs": { "0": { "tooltip": null } } };
const WanPhantomSubjectToVideo = { "display_name": "WanPhantomSubjectToVideo", "inputs": { "batch_size": { "name": "taille_lot" }, "height": { "name": "hauteur" }, "images": { "name": "images" }, "length": { "name": "longueur" }, "negative": { "name": "négatif" }, "positive": { "name": "positif" }, "vae": { "name": "vae" }, "width": { "name": "largeur" } }, "outputs": { "0": { "name": "positif", "tooltip": null }, "1": { "name": "texte_négatif", "tooltip": null }, "2": { "name": "texte_img_négative", "tooltip": null }, "3": { "name": "latent", "tooltip": null } } };
const WanSoundImageToVideo = { "display_name": "WanSoundImageToVideo", "inputs": { "audio_encoder_output": { "name": "sortie_encodeur_audio" }, "batch_size": { "name": "taille_lot" }, "control_video": { "name": "vidéo de contrôle" }, "height": { "name": "hauteur" }, "length": { "name": "longueur" }, "negative": { "name": "négatif" }, "positive": { "name": "positif" }, "ref_image": { "name": "image_référence" }, "ref_motion": { "name": "mouvement de référence" }, "vae": { "name": "vae" }, "width": { "name": "largeur" } }, "outputs": { "0": { "name": "positif", "tooltip": null }, "1": { "name": "négatif", "tooltip": null }, "2": { "name": "latent", "tooltip": null } } };
const WanSoundImageToVideoExtend = { "display_name": "Extension WanSoundImageToVideo", "inputs": { "audio_encoder_output": { "name": "sortie de l'encodeur audio" }, "control_video": { "name": "vidéo de contrôle" }, "length": { "name": "longueur" }, "negative": { "name": "négatif" }, "positive": { "name": "positif" }, "ref_image": { "name": "image de référence" }, "vae": { "name": "vae" }, "video_latent": { "name": "latent vidéo" } }, "outputs": { "0": { "name": "positif", "tooltip": null }, "1": { "name": "négatif", "tooltip": null }, "2": { "name": "latent", "tooltip": null } } };
const WanTextToImageApi = { "description": "Génère une image basée sur une invite textuelle.", "display_name": "Wan Texte vers Image", "inputs": { "control_after_generate": { "name": "contrôle après génération" }, "height": { "name": "hauteur" }, "model": { "name": "modèle", "tooltip": "Modèle à utiliser." }, "negative_prompt": { "name": "invite négative", "tooltip": "Invite textuelle négative pour guider ce qu'il faut éviter." }, "prompt": { "name": "invite", "tooltip": "Invite utilisée pour décrire les éléments et caractéristiques visuelles, prend en charge l'anglais/le chinois." }, "prompt_extend": { "name": "extension d'invite", "tooltip": "Indique s'il faut améliorer l'invite avec une assistance IA." }, "seed": { "name": "graine", "tooltip": "Graine à utiliser pour la génération." }, "watermark": { "name": "filigrane", "tooltip": `Indique s'il faut ajouter un filigrane "Généré par IA" au résultat.` }, "width": { "name": "largeur" } }, "outputs": { "0": { "tooltip": null } } };
const WanTextToVideoApi = { "description": "Génère une vidéo basée sur une invite textuelle.", "display_name": "Wan Texte vers Vidéo", "inputs": { "audio": { "name": "audio", "tooltip": "L'audio doit contenir une voix claire et forte, sans bruit parasite ni musique de fond." }, "control_after_generate": { "name": "control after generate" }, "duration": { "name": "durée", "tooltip": "Durées disponibles : 5 et 10 secondes" }, "generate_audio": { "name": "generate_audio", "tooltip": "S'il n'y a pas d'entrée audio, générer automatiquement l'audio." }, "model": { "name": "modèle", "tooltip": "Modèle à utiliser." }, "negative_prompt": { "name": "negative_prompt", "tooltip": "Invite de texte négative pour guider ce qu'il faut éviter." }, "prompt": { "name": "invite", "tooltip": "Invite utilisée pour décrire les éléments et caractéristiques visuelles, prend en charge l'anglais/le chinois." }, "prompt_extend": { "name": "prompt_extend", "tooltip": "Indique s'il faut améliorer l'invite avec l'assistance de l'IA." }, "seed": { "name": "seed", "tooltip": "Graine à utiliser pour la génération." }, "size": { "name": "taille" }, "watermark": { "name": "watermark", "tooltip": `Indique s'il faut ajouter un filigrane "Généré par IA" au résultat.` } }, "outputs": { "0": { "tooltip": null } } };
const WanTrackToVideo = { "display_name": "WanTrackToVideo", "inputs": { "batch_size": { "name": "batch_size" }, "clip_vision_output": { "name": "clip_vision_output" }, "height": { "name": "hauteur" }, "length": { "name": "longueur" }, "negative": { "name": "negative" }, "positive": { "name": "positive" }, "start_image": { "name": "start_image" }, "temperature": { "name": "température" }, "topk": { "name": "topk" }, "tracks": { "name": "tracks" }, "vae": { "name": "vae" }, "width": { "name": "largeur" } }, "outputs": { "0": { "name": "positive", "tooltip": null }, "1": { "name": "negative", "tooltip": null }, "2": { "name": "latent", "tooltip": null } } };
const WanVaceToVideo = { "display_name": "WanVaceToVideo", "inputs": { "batch_size": { "name": "taille_lot" }, "control_masks": { "name": "masques_de_contrôle" }, "control_video": { "name": "contrôle_vidéo" }, "height": { "name": "hauteur" }, "length": { "name": "longueur" }, "negative": { "name": "négatif" }, "positive": { "name": "positif" }, "reference_image": { "name": "image_de_référence" }, "strength": { "name": "intensité" }, "vae": { "name": "vae" }, "width": { "name": "largeur" } }, "outputs": { "0": { "name": "positif", "tooltip": null }, "1": { "name": "négatif", "tooltip": null }, "2": { "name": "latent", "tooltip": null }, "3": { "name": "latent_coupé", "tooltip": null } } };
const WebcamCapture = { "display_name": "Capture Webcam", "inputs": { "capture_on_queue": { "name": "capture_en_file_d'attente" }, "height": { "name": "hauteur" }, "image": { "name": "image" }, "waiting for camera___": {}, "width": { "name": "largeur" } } };
const unCLIPCheckpointLoader = { "display_name": "ChargeurPointContrôleunCLIP", "inputs": { "ckpt_name": { "name": "nom_ckpt" } } };
const unCLIPConditioning = { "display_name": "ConditionnementunCLIP", "inputs": { "clip_vision_output": { "name": "sortie_vision_clip" }, "conditioning": { "name": "conditionnement" }, "noise_augmentation": { "name": "augmentation_bruit" }, "strength": { "name": "force" } } };
const nodeDefs = {
  APG,
  AddNoise,
  AlignYourStepsScheduler,
  AudioAdjustVolume,
  AudioConcat,
  AudioEncoderEncode,
  AudioEncoderLoader,
  AudioMerge,
  BasicGuider,
  BasicScheduler,
  BetaSamplingScheduler,
  ByteDanceFirstLastFrameNode,
  ByteDanceImageEditNode,
  ByteDanceImageNode,
  ByteDanceImageReferenceNode,
  ByteDanceImageToVideoNode,
  ByteDanceSeedreamNode,
  ByteDanceTextToVideoNode,
  CFGGuider,
  CFGNorm,
  CFGZeroStar,
  CLIPAttentionMultiply,
  CLIPLoader,
  CLIPMergeAdd,
  CLIPMergeSimple,
  CLIPMergeSubtract,
  CLIPSave,
  CLIPSetLastLayer,
  CLIPTextEncode,
  CLIPTextEncodeControlnet,
  CLIPTextEncodeFlux,
  CLIPTextEncodeHiDream,
  CLIPTextEncodeHunyuanDiT,
  CLIPTextEncodeLumina2,
  CLIPTextEncodePixArtAlpha,
  CLIPTextEncodeSD3,
  CLIPTextEncodeSDXL,
  CLIPTextEncodeSDXLRefiner,
  CLIPVisionEncode,
  CLIPVisionLoader,
  Canny,
  CaseConverter,
  CheckpointLoader,
  CheckpointLoaderSimple,
  CheckpointSave,
  ChromaRadianceOptions,
  CombineHooks2,
  CombineHooks4,
  CombineHooks8,
  ConditioningAverage,
  ConditioningCombine,
  ConditioningConcat,
  ConditioningSetArea,
  ConditioningSetAreaPercentage,
  ConditioningSetAreaPercentageVideo,
  ConditioningSetAreaStrength,
  ConditioningSetDefaultCombine,
  ConditioningSetMask,
  ConditioningSetProperties,
  ConditioningSetPropertiesAndCombine,
  ConditioningSetTimestepRange,
  ConditioningStableAudio,
  ConditioningTimestepsRange,
  ConditioningZeroOut,
  ContextWindowsManual,
  ControlNetApply,
  ControlNetApplyAdvanced,
  ControlNetApplySD3,
  ControlNetInpaintingAliMamaApply,
  ControlNetLoader,
  CosmosImageToVideoLatent,
  CosmosPredict2ImageToVideoLatent,
  CreateHookKeyframe,
  CreateHookKeyframesFromFloats,
  CreateHookKeyframesInterpolated,
  CreateHookLora,
  CreateHookLoraModelOnly,
  CreateHookModelAsLora,
  CreateHookModelAsLoraModelOnly,
  CreateVideo,
  CropMask,
  DiffControlNetLoader,
  DifferentialDiffusion,
  DiffusersLoader,
  DisableNoise,
  DualCFGGuider,
  DualCLIPLoader,
  EasyCache,
  EmptyAceStepLatentAudio,
  EmptyAudio,
  EmptyChromaRadianceLatentImage,
  EmptyCosmosLatentVideo,
  EmptyHunyuanImageLatent,
  EmptyHunyuanLatentVideo,
  EmptyImage,
  EmptyLTXVLatentVideo,
  EmptyLatentAudio,
  EmptyLatentHunyuan3Dv2,
  EmptyLatentImage,
  EmptyMochiLatentVideo,
  EmptySD3LatentImage,
  "Epsilon Scaling": { "display_name": "Mise à l'échelle Epsilon", "inputs": { "model": { "name": "modèle" }, "scaling_factor": { "name": "facteur_d'échelle" } }, "outputs": { "0": { "tooltip": null } } },
  ExponentialScheduler,
  ExtendIntermediateSigmas,
  FeatherMask,
  FlipSigmas,
  FluxDisableGuidance,
  FluxGuidance,
  FluxKontextImageScale,
  FluxKontextMaxImageNode,
  FluxKontextMultiReferenceLatentMethod,
  FluxKontextProImageNode,
  FluxProExpandNode,
  FluxProFillNode,
  FluxProUltraImageNode,
  FreSca,
  FreeU,
  FreeU_V2,
  GITSScheduler,
  GLIGENLoader,
  GLIGENTextBoxApply,
  GeminiImageNode,
  GeminiInputFiles,
  GeminiNode,
  GetImageSize,
  GetVideoComponents,
  GrowMask,
  Hunyuan3Dv2Conditioning,
  Hunyuan3Dv2ConditioningMultiView,
  HunyuanImageToVideo,
  HunyuanRefinerLatent,
  HyperTile,
  HypernetworkLoader,
  IdeogramV1,
  IdeogramV2,
  IdeogramV3,
  ImageAddNoise,
  ImageBatch,
  ImageBlend,
  ImageBlur,
  ImageColorToMask,
  ImageCompositeMasked,
  ImageCrop,
  ImageFlip,
  ImageFromBatch,
  ImageInvert,
  ImageOnlyCheckpointLoader,
  ImageOnlyCheckpointSave,
  ImagePadForOutpaint,
  ImageQuantize,
  ImageRGBToYUV,
  ImageRotate,
  ImageScale,
  ImageScaleBy,
  ImageScaleToMaxDimension,
  ImageScaleToTotalPixels,
  ImageSharpen,
  ImageStitch,
  ImageToMask,
  ImageUpscaleWithModel,
  ImageYUVToRGB,
  InpaintModelConditioning,
  InstructPixToPixConditioning,
  InvertMask,
  JoinImageWithAlpha,
  KSampler,
  KSamplerAdvanced,
  KSamplerSelect,
  KarrasScheduler,
  KlingCameraControlI2VNode,
  KlingCameraControlT2VNode,
  KlingCameraControls,
  KlingDualCharacterVideoEffectNode,
  KlingImage2VideoNode,
  KlingImageGenerationNode,
  KlingLipSyncAudioToVideoNode,
  KlingLipSyncTextToVideoNode,
  KlingSingleImageVideoEffectNode,
  KlingStartEndFrameNode,
  KlingTextToVideoNode,
  KlingVideoExtendNode,
  KlingVirtualTryOnNode,
  LTXVAddGuide,
  LTXVConditioning,
  LTXVCropGuides,
  LTXVImgToVideo,
  LTXVPreprocess,
  LTXVScheduler,
  LaplaceScheduler,
  LatentAdd,
  LatentApplyOperation,
  LatentApplyOperationCFG,
  LatentBatch,
  LatentBatchSeedBehavior,
  LatentBlend,
  LatentComposite,
  LatentCompositeMasked,
  LatentConcat,
  LatentCrop,
  LatentCut,
  LatentFlip,
  LatentFromBatch,
  LatentInterpolate,
  LatentMultiply,
  LatentOperationSharpen,
  LatentOperationTonemapReinhard,
  LatentRotate,
  LatentSubtract,
  LatentUpscale,
  LatentUpscaleBy,
  LazyCache,
  Load3D,
  LoadAudio,
  LoadImage,
  LoadImageMask,
  LoadImageOutput,
  LoadLatent,
  LoadVideo,
  LoraLoader,
  LoraLoaderModelOnly,
  LoraModelLoader,
  LoraSave,
  LossGraphNode,
  LotusConditioning,
  LtxvApiImageToVideo,
  LtxvApiTextToVideo,
  LumaConceptsNode,
  LumaImageModifyNode,
  LumaImageNode,
  LumaImageToVideoNode,
  LumaReferenceNode,
  LumaVideoNode,
  Mahiro,
  MaskComposite,
  MaskPreview,
  MaskToImage,
  MinimaxHailuoVideoNode,
  MinimaxImageToVideoNode,
  MinimaxTextToVideoNode,
  ModelComputeDtype,
  ModelMergeAdd,
  ModelMergeAuraflow,
  ModelMergeBlocks,
  ModelMergeCosmos14B,
  ModelMergeCosmos7B,
  ModelMergeCosmosPredict2_14B,
  ModelMergeCosmosPredict2_2B,
  ModelMergeFlux1,
  ModelMergeLTXV,
  ModelMergeMochiPreview,
  ModelMergeQwenImage,
  ModelMergeSD1,
  ModelMergeSD2,
  ModelMergeSD35_Large,
  ModelMergeSD3_2B,
  ModelMergeSDXL,
  ModelMergeSimple,
  ModelMergeSubtract,
  ModelMergeWAN2_1,
  ModelPatchLoader,
  ModelSamplingAuraFlow,
  ModelSamplingContinuousEDM,
  ModelSamplingContinuousV,
  ModelSamplingDiscrete,
  ModelSamplingFlux,
  ModelSamplingLTXV,
  ModelSamplingSD3,
  ModelSamplingStableCascade,
  ModelSave,
  MoonvalleyImg2VideoNode,
  MoonvalleyTxt2VideoNode,
  MoonvalleyVideo2VideoNode,
  Morphology,
  OpenAIChatConfig,
  OpenAIChatNode,
  OpenAIDalle2,
  OpenAIDalle3,
  OpenAIGPTImage1,
  OpenAIInputFiles,
  OpenAIVideoSora2,
  OptimalStepsScheduler,
  PairConditioningCombine,
  PairConditioningSetDefaultCombine,
  PairConditioningSetProperties,
  PairConditioningSetPropertiesAndCombine,
  PatchModelAddDownscale,
  PerpNeg,
  PerpNegGuider,
  PerturbedAttentionGuidance,
  PhotoMakerEncode,
  PhotoMakerLoader,
  PixverseImageToVideoNode,
  PixverseTemplateNode,
  PixverseTextToVideoNode,
  PixverseTransitionVideoNode,
  PolyexponentialScheduler,
  PorterDuffImageComposite,
  Preview3D,
  PreviewAny,
  PreviewAudio,
  PreviewImage,
  PrimitiveBoolean,
  PrimitiveFloat,
  PrimitiveInt,
  PrimitiveString,
  PrimitiveStringMultiline,
  QuadrupleCLIPLoader,
  QwenImageDiffsynthControlnet,
  RandomNoise,
  RebatchImages,
  RebatchLatents,
  RecordAudio,
  RecraftColorRGB,
  RecraftControls,
  RecraftCreativeUpscaleNode,
  RecraftCrispUpscaleNode,
  RecraftImageInpaintingNode,
  RecraftImageToImageNode,
  RecraftRemoveBackgroundNode,
  RecraftReplaceBackgroundNode,
  RecraftStyleV3DigitalIllustration,
  RecraftStyleV3InfiniteStyleLibrary,
  RecraftStyleV3LogoRaster,
  RecraftStyleV3RealisticImage,
  RecraftTextToImageNode,
  RecraftTextToVectorNode,
  RecraftVectorizeImageNode,
  ReferenceLatent,
  RegexExtract,
  RegexMatch,
  RegexReplace,
  RenormCFG,
  RepeatImageBatch,
  RepeatLatentBatch,
  RescaleCFG,
  ResizeAndPadImage,
  Rodin3D_Detail,
  Rodin3D_Gen2,
  Rodin3D_Regular,
  Rodin3D_Sketch,
  Rodin3D_Smooth,
  RunwayFirstLastFrameNode,
  RunwayImageToVideoNodeGen3a,
  RunwayImageToVideoNodeGen4,
  RunwayTextToImageNode,
  SDTurboScheduler,
  SD_4XUpscale_Conditioning,
  SV3D_Conditioning,
  SVD_img2vid_Conditioning,
  SamplerCustom,
  SamplerCustomAdvanced,
  SamplerDPMAdaptative,
  SamplerDPMPP_2M_SDE,
  SamplerDPMPP_2S_Ancestral,
  SamplerDPMPP_3M_SDE,
  SamplerDPMPP_SDE,
  SamplerER_SDE,
  SamplerEulerAncestral,
  SamplerEulerAncestralCFGPP,
  SamplerEulerCFGpp,
  SamplerLCMUpscale,
  SamplerLMS,
  SamplerSASolver,
  SamplingPercentToSigma,
  SaveAnimatedPNG,
  SaveAnimatedWEBP,
  SaveAudio,
  SaveAudioMP3,
  SaveAudioOpus,
  SaveGLB,
  SaveImage,
  SaveImageWebsocket,
  SaveLatent,
  SaveSVGNode,
  SaveVideo,
  SaveWEBM,
  ScaleROPE,
  SelfAttentionGuidance,
  SetClipHooks,
  SetFirstSigma,
  SetHookKeyframes,
  SetLatentNoiseMask,
  SetUnionControlNetType,
  SkipLayerGuidanceDiT,
  SkipLayerGuidanceDiTSimple,
  SkipLayerGuidanceSD3,
  SolidMask,
  SplitAudioChannels,
  SplitImageWithAlpha,
  SplitSigmas,
  SplitSigmasDenoise,
  StabilityAudioInpaint,
  StabilityAudioToAudio,
  StabilityStableImageSD_3_5Node,
  StabilityStableImageUltraNode,
  StabilityTextToAudio,
  StabilityUpscaleConservativeNode,
  StabilityUpscaleCreativeNode,
  StabilityUpscaleFastNode,
  StableCascade_EmptyLatentImage,
  StableCascade_StageB_Conditioning,
  StableCascade_StageC_VAEEncode,
  StableCascade_SuperResolutionControlnet,
  StableZero123_Conditioning,
  StableZero123_Conditioning_Batched,
  StringCompare,
  StringConcatenate,
  StringContains,
  StringLength,
  StringReplace,
  StringSubstring,
  StringTrim,
  StyleModelApply,
  StyleModelLoader,
  T5TokenizerOptions,
  TCFG,
  TemporalScoreRescaling,
  TextEncodeAceStepAudio,
  TextEncodeHunyuanVideo_ImageToVideo,
  TextEncodeQwenImageEdit,
  TextEncodeQwenImageEditPlus,
  ThresholdMask,
  TomePatchModel,
  TorchCompileModel,
  TrainLoraNode,
  TrimAudioDuration,
  TrimVideoLatent,
  TripleCLIPLoader,
  TripoConversionNode,
  TripoImageToModelNode,
  TripoMultiviewToModelNode,
  TripoRefineNode,
  TripoRetargetNode,
  TripoRigNode,
  TripoTextToModelNode,
  TripoTextureNode,
  UNETLoader,
  UNetCrossAttentionMultiply,
  UNetSelfAttentionMultiply,
  UNetTemporalAttentionMultiply,
  USOStyleReference,
  UpscaleModelLoader,
  VAEDecode,
  VAEDecodeAudio,
  VAEDecodeHunyuan3D,
  VAEDecodeTiled,
  VAEEncode,
  VAEEncodeAudio,
  VAEEncodeForInpaint,
  VAEEncodeTiled,
  VAELoader,
  VAESave,
  VPScheduler,
  Veo3VideoGenerationNode,
  VeoVideoGenerationNode,
  VideoLinearCFGGuidance,
  VideoTriangleCFGGuidance,
  ViduImageToVideoNode,
  ViduReferenceVideoNode,
  ViduStartEndToVideoNode,
  ViduTextToVideoNode,
  VoxelToMesh,
  VoxelToMeshBasic,
  Wan22FunControlToVideo,
  Wan22ImageToVideoLatent,
  WanAnimateToVideo,
  WanCameraEmbedding,
  WanCameraImageToVideo,
  WanContextWindowsManual,
  WanFirstLastFrameToVideo,
  WanFunControlToVideo,
  WanFunInpaintToVideo,
  WanHuMoImageToVideo,
  WanImageToImageApi,
  WanImageToVideo,
  WanImageToVideoApi,
  WanPhantomSubjectToVideo,
  WanSoundImageToVideo,
  WanSoundImageToVideoExtend,
  WanTextToImageApi,
  WanTextToVideoApi,
  WanTrackToVideo,
  WanVaceToVideo,
  WebcamCapture,
  unCLIPCheckpointLoader,
  unCLIPConditioning
};
export {
  APG,
  AddNoise,
  AlignYourStepsScheduler,
  AudioAdjustVolume,
  AudioConcat,
  AudioEncoderEncode,
  AudioEncoderLoader,
  AudioMerge,
  BasicGuider,
  BasicScheduler,
  BetaSamplingScheduler,
  ByteDanceFirstLastFrameNode,
  ByteDanceImageEditNode,
  ByteDanceImageNode,
  ByteDanceImageReferenceNode,
  ByteDanceImageToVideoNode,
  ByteDanceSeedreamNode,
  ByteDanceTextToVideoNode,
  CFGGuider,
  CFGNorm,
  CFGZeroStar,
  CLIPAttentionMultiply,
  CLIPLoader,
  CLIPMergeAdd,
  CLIPMergeSimple,
  CLIPMergeSubtract,
  CLIPSave,
  CLIPSetLastLayer,
  CLIPTextEncode,
  CLIPTextEncodeControlnet,
  CLIPTextEncodeFlux,
  CLIPTextEncodeHiDream,
  CLIPTextEncodeHunyuanDiT,
  CLIPTextEncodeLumina2,
  CLIPTextEncodePixArtAlpha,
  CLIPTextEncodeSD3,
  CLIPTextEncodeSDXL,
  CLIPTextEncodeSDXLRefiner,
  CLIPVisionEncode,
  CLIPVisionLoader,
  Canny,
  CaseConverter,
  CheckpointLoader,
  CheckpointLoaderSimple,
  CheckpointSave,
  ChromaRadianceOptions,
  CombineHooks2,
  CombineHooks4,
  CombineHooks8,
  ConditioningAverage,
  ConditioningCombine,
  ConditioningConcat,
  ConditioningSetArea,
  ConditioningSetAreaPercentage,
  ConditioningSetAreaPercentageVideo,
  ConditioningSetAreaStrength,
  ConditioningSetDefaultCombine,
  ConditioningSetMask,
  ConditioningSetProperties,
  ConditioningSetPropertiesAndCombine,
  ConditioningSetTimestepRange,
  ConditioningStableAudio,
  ConditioningTimestepsRange,
  ConditioningZeroOut,
  ContextWindowsManual,
  ControlNetApply,
  ControlNetApplyAdvanced,
  ControlNetApplySD3,
  ControlNetInpaintingAliMamaApply,
  ControlNetLoader,
  CosmosImageToVideoLatent,
  CosmosPredict2ImageToVideoLatent,
  CreateHookKeyframe,
  CreateHookKeyframesFromFloats,
  CreateHookKeyframesInterpolated,
  CreateHookLora,
  CreateHookLoraModelOnly,
  CreateHookModelAsLora,
  CreateHookModelAsLoraModelOnly,
  CreateVideo,
  CropMask,
  DiffControlNetLoader,
  DifferentialDiffusion,
  DiffusersLoader,
  DisableNoise,
  DualCFGGuider,
  DualCLIPLoader,
  EasyCache,
  EmptyAceStepLatentAudio,
  EmptyAudio,
  EmptyChromaRadianceLatentImage,
  EmptyCosmosLatentVideo,
  EmptyHunyuanImageLatent,
  EmptyHunyuanLatentVideo,
  EmptyImage,
  EmptyLTXVLatentVideo,
  EmptyLatentAudio,
  EmptyLatentHunyuan3Dv2,
  EmptyLatentImage,
  EmptyMochiLatentVideo,
  EmptySD3LatentImage,
  ExponentialScheduler,
  ExtendIntermediateSigmas,
  FeatherMask,
  FlipSigmas,
  FluxDisableGuidance,
  FluxGuidance,
  FluxKontextImageScale,
  FluxKontextMaxImageNode,
  FluxKontextMultiReferenceLatentMethod,
  FluxKontextProImageNode,
  FluxProExpandNode,
  FluxProFillNode,
  FluxProUltraImageNode,
  FreSca,
  FreeU,
  FreeU_V2,
  GITSScheduler,
  GLIGENLoader,
  GLIGENTextBoxApply,
  GeminiImageNode,
  GeminiInputFiles,
  GeminiNode,
  GetImageSize,
  GetVideoComponents,
  GrowMask,
  Hunyuan3Dv2Conditioning,
  Hunyuan3Dv2ConditioningMultiView,
  HunyuanImageToVideo,
  HunyuanRefinerLatent,
  HyperTile,
  HypernetworkLoader,
  IdeogramV1,
  IdeogramV2,
  IdeogramV3,
  ImageAddNoise,
  ImageBatch,
  ImageBlend,
  ImageBlur,
  ImageColorToMask,
  ImageCompositeMasked,
  ImageCrop,
  ImageFlip,
  ImageFromBatch,
  ImageInvert,
  ImageOnlyCheckpointLoader,
  ImageOnlyCheckpointSave,
  ImagePadForOutpaint,
  ImageQuantize,
  ImageRGBToYUV,
  ImageRotate,
  ImageScale,
  ImageScaleBy,
  ImageScaleToMaxDimension,
  ImageScaleToTotalPixels,
  ImageSharpen,
  ImageStitch,
  ImageToMask,
  ImageUpscaleWithModel,
  ImageYUVToRGB,
  InpaintModelConditioning,
  InstructPixToPixConditioning,
  InvertMask,
  JoinImageWithAlpha,
  KSampler,
  KSamplerAdvanced,
  KSamplerSelect,
  KarrasScheduler,
  KlingCameraControlI2VNode,
  KlingCameraControlT2VNode,
  KlingCameraControls,
  KlingDualCharacterVideoEffectNode,
  KlingImage2VideoNode,
  KlingImageGenerationNode,
  KlingLipSyncAudioToVideoNode,
  KlingLipSyncTextToVideoNode,
  KlingSingleImageVideoEffectNode,
  KlingStartEndFrameNode,
  KlingTextToVideoNode,
  KlingVideoExtendNode,
  KlingVirtualTryOnNode,
  LTXVAddGuide,
  LTXVConditioning,
  LTXVCropGuides,
  LTXVImgToVideo,
  LTXVPreprocess,
  LTXVScheduler,
  LaplaceScheduler,
  LatentAdd,
  LatentApplyOperation,
  LatentApplyOperationCFG,
  LatentBatch,
  LatentBatchSeedBehavior,
  LatentBlend,
  LatentComposite,
  LatentCompositeMasked,
  LatentConcat,
  LatentCrop,
  LatentCut,
  LatentFlip,
  LatentFromBatch,
  LatentInterpolate,
  LatentMultiply,
  LatentOperationSharpen,
  LatentOperationTonemapReinhard,
  LatentRotate,
  LatentSubtract,
  LatentUpscale,
  LatentUpscaleBy,
  LazyCache,
  Load3D,
  LoadAudio,
  LoadImage,
  LoadImageMask,
  LoadImageOutput,
  LoadLatent,
  LoadVideo,
  LoraLoader,
  LoraLoaderModelOnly,
  LoraModelLoader,
  LoraSave,
  LossGraphNode,
  LotusConditioning,
  LtxvApiImageToVideo,
  LtxvApiTextToVideo,
  LumaConceptsNode,
  LumaImageModifyNode,
  LumaImageNode,
  LumaImageToVideoNode,
  LumaReferenceNode,
  LumaVideoNode,
  Mahiro,
  MaskComposite,
  MaskPreview,
  MaskToImage,
  MinimaxHailuoVideoNode,
  MinimaxImageToVideoNode,
  MinimaxTextToVideoNode,
  ModelComputeDtype,
  ModelMergeAdd,
  ModelMergeAuraflow,
  ModelMergeBlocks,
  ModelMergeCosmos14B,
  ModelMergeCosmos7B,
  ModelMergeCosmosPredict2_14B,
  ModelMergeCosmosPredict2_2B,
  ModelMergeFlux1,
  ModelMergeLTXV,
  ModelMergeMochiPreview,
  ModelMergeQwenImage,
  ModelMergeSD1,
  ModelMergeSD2,
  ModelMergeSD35_Large,
  ModelMergeSD3_2B,
  ModelMergeSDXL,
  ModelMergeSimple,
  ModelMergeSubtract,
  ModelMergeWAN2_1,
  ModelPatchLoader,
  ModelSamplingAuraFlow,
  ModelSamplingContinuousEDM,
  ModelSamplingContinuousV,
  ModelSamplingDiscrete,
  ModelSamplingFlux,
  ModelSamplingLTXV,
  ModelSamplingSD3,
  ModelSamplingStableCascade,
  ModelSave,
  MoonvalleyImg2VideoNode,
  MoonvalleyTxt2VideoNode,
  MoonvalleyVideo2VideoNode,
  Morphology,
  OpenAIChatConfig,
  OpenAIChatNode,
  OpenAIDalle2,
  OpenAIDalle3,
  OpenAIGPTImage1,
  OpenAIInputFiles,
  OpenAIVideoSora2,
  OptimalStepsScheduler,
  PairConditioningCombine,
  PairConditioningSetDefaultCombine,
  PairConditioningSetProperties,
  PairConditioningSetPropertiesAndCombine,
  PatchModelAddDownscale,
  PerpNeg,
  PerpNegGuider,
  PerturbedAttentionGuidance,
  PhotoMakerEncode,
  PhotoMakerLoader,
  PixverseImageToVideoNode,
  PixverseTemplateNode,
  PixverseTextToVideoNode,
  PixverseTransitionVideoNode,
  PolyexponentialScheduler,
  PorterDuffImageComposite,
  Preview3D,
  PreviewAny,
  PreviewAudio,
  PreviewImage,
  PrimitiveBoolean,
  PrimitiveFloat,
  PrimitiveInt,
  PrimitiveString,
  PrimitiveStringMultiline,
  QuadrupleCLIPLoader,
  QwenImageDiffsynthControlnet,
  RandomNoise,
  RebatchImages,
  RebatchLatents,
  RecordAudio,
  RecraftColorRGB,
  RecraftControls,
  RecraftCreativeUpscaleNode,
  RecraftCrispUpscaleNode,
  RecraftImageInpaintingNode,
  RecraftImageToImageNode,
  RecraftRemoveBackgroundNode,
  RecraftReplaceBackgroundNode,
  RecraftStyleV3DigitalIllustration,
  RecraftStyleV3InfiniteStyleLibrary,
  RecraftStyleV3LogoRaster,
  RecraftStyleV3RealisticImage,
  RecraftTextToImageNode,
  RecraftTextToVectorNode,
  RecraftVectorizeImageNode,
  ReferenceLatent,
  RegexExtract,
  RegexMatch,
  RegexReplace,
  RenormCFG,
  RepeatImageBatch,
  RepeatLatentBatch,
  RescaleCFG,
  ResizeAndPadImage,
  Rodin3D_Detail,
  Rodin3D_Gen2,
  Rodin3D_Regular,
  Rodin3D_Sketch,
  Rodin3D_Smooth,
  RunwayFirstLastFrameNode,
  RunwayImageToVideoNodeGen3a,
  RunwayImageToVideoNodeGen4,
  RunwayTextToImageNode,
  SDTurboScheduler,
  SD_4XUpscale_Conditioning,
  SV3D_Conditioning,
  SVD_img2vid_Conditioning,
  SamplerCustom,
  SamplerCustomAdvanced,
  SamplerDPMAdaptative,
  SamplerDPMPP_2M_SDE,
  SamplerDPMPP_2S_Ancestral,
  SamplerDPMPP_3M_SDE,
  SamplerDPMPP_SDE,
  SamplerER_SDE,
  SamplerEulerAncestral,
  SamplerEulerAncestralCFGPP,
  SamplerEulerCFGpp,
  SamplerLCMUpscale,
  SamplerLMS,
  SamplerSASolver,
  SamplingPercentToSigma,
  SaveAnimatedPNG,
  SaveAnimatedWEBP,
  SaveAudio,
  SaveAudioMP3,
  SaveAudioOpus,
  SaveGLB,
  SaveImage,
  SaveImageWebsocket,
  SaveLatent,
  SaveSVGNode,
  SaveVideo,
  SaveWEBM,
  ScaleROPE,
  SelfAttentionGuidance,
  SetClipHooks,
  SetFirstSigma,
  SetHookKeyframes,
  SetLatentNoiseMask,
  SetUnionControlNetType,
  SkipLayerGuidanceDiT,
  SkipLayerGuidanceDiTSimple,
  SkipLayerGuidanceSD3,
  SolidMask,
  SplitAudioChannels,
  SplitImageWithAlpha,
  SplitSigmas,
  SplitSigmasDenoise,
  StabilityAudioInpaint,
  StabilityAudioToAudio,
  StabilityStableImageSD_3_5Node,
  StabilityStableImageUltraNode,
  StabilityTextToAudio,
  StabilityUpscaleConservativeNode,
  StabilityUpscaleCreativeNode,
  StabilityUpscaleFastNode,
  StableCascade_EmptyLatentImage,
  StableCascade_StageB_Conditioning,
  StableCascade_StageC_VAEEncode,
  StableCascade_SuperResolutionControlnet,
  StableZero123_Conditioning,
  StableZero123_Conditioning_Batched,
  StringCompare,
  StringConcatenate,
  StringContains,
  StringLength,
  StringReplace,
  StringSubstring,
  StringTrim,
  StyleModelApply,
  StyleModelLoader,
  T5TokenizerOptions,
  TCFG,
  TemporalScoreRescaling,
  TextEncodeAceStepAudio,
  TextEncodeHunyuanVideo_ImageToVideo,
  TextEncodeQwenImageEdit,
  TextEncodeQwenImageEditPlus,
  ThresholdMask,
  TomePatchModel,
  TorchCompileModel,
  TrainLoraNode,
  TrimAudioDuration,
  TrimVideoLatent,
  TripleCLIPLoader,
  TripoConversionNode,
  TripoImageToModelNode,
  TripoMultiviewToModelNode,
  TripoRefineNode,
  TripoRetargetNode,
  TripoRigNode,
  TripoTextToModelNode,
  TripoTextureNode,
  UNETLoader,
  UNetCrossAttentionMultiply,
  UNetSelfAttentionMultiply,
  UNetTemporalAttentionMultiply,
  USOStyleReference,
  UpscaleModelLoader,
  VAEDecode,
  VAEDecodeAudio,
  VAEDecodeHunyuan3D,
  VAEDecodeTiled,
  VAEEncode,
  VAEEncodeAudio,
  VAEEncodeForInpaint,
  VAEEncodeTiled,
  VAELoader,
  VAESave,
  VPScheduler,
  Veo3VideoGenerationNode,
  VeoVideoGenerationNode,
  VideoLinearCFGGuidance,
  VideoTriangleCFGGuidance,
  ViduImageToVideoNode,
  ViduReferenceVideoNode,
  ViduStartEndToVideoNode,
  ViduTextToVideoNode,
  VoxelToMesh,
  VoxelToMeshBasic,
  Wan22FunControlToVideo,
  Wan22ImageToVideoLatent,
  WanAnimateToVideo,
  WanCameraEmbedding,
  WanCameraImageToVideo,
  WanContextWindowsManual,
  WanFirstLastFrameToVideo,
  WanFunControlToVideo,
  WanFunInpaintToVideo,
  WanHuMoImageToVideo,
  WanImageToImageApi,
  WanImageToVideo,
  WanImageToVideoApi,
  WanPhantomSubjectToVideo,
  WanSoundImageToVideo,
  WanSoundImageToVideoExtend,
  WanTextToImageApi,
  WanTextToVideoApi,
  WanTrackToVideo,
  WanVaceToVideo,
  WebcamCapture,
  nodeDefs as default,
  unCLIPCheckpointLoader,
  unCLIPConditioning
};
//# sourceMappingURL=nodeDefs-BiYpVi7D.js.map
