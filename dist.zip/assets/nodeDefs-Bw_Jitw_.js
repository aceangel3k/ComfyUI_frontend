const nodeDefs = {};
export {
  nodeDefs as default
};
//# sourceMappingURL=nodeDefs-Bw_Jitw_.js.map
