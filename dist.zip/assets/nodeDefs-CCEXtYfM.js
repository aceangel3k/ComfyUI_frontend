const APG = { "display_name": "自適應投影引導", "inputs": { "eta": { "name": "eta", "tooltip": "控制平行引導向量的縮放比例。設定為 1 時為預設 CFG 行為。" }, "model": { "name": "模型" }, "momentum": { "name": "momentum", "tooltip": "控制擴散過程中引導的移動平均值，設定為 0 時停用。" }, "norm_threshold": { "name": "norm_threshold", "tooltip": "將引導向量正規化至此值，設定為 0 時停用正規化。" } }, "outputs": { "0": { "tooltip": null } } };
const AddNoise = { "display_name": "新增雜訊", "inputs": { "latent_image": { "name": "latent 影像" }, "model": { "name": "model" }, "noise": { "name": "noise" }, "sigmas": { "name": "sigmas" } } };
const AlignYourStepsScheduler = { "display_name": "AlignYourStepsScheduler", "inputs": { "denoise": { "name": "去雜訊強度" }, "model_type": { "name": "model_type" }, "steps": { "name": "步驟數" } }, "outputs": { "0": { "tooltip": null } } };
const AudioAdjustVolume = { "display_name": "音訊調整音量", "inputs": { "audio": { "name": "音訊" }, "volume": { "name": "volume", "tooltip": "以分貝 (dB) 為單位的音量調整。0 = 無變化，+6 = 兩倍，-6 = 一半，依此類推" } } };
const AudioConcat = { "description": "將 audio1 串接至 audio2 的指定方向。", "display_name": "音訊串接", "inputs": { "audio1": { "name": "audio1" }, "audio2": { "name": "audio2" }, "direction": { "name": "direction", "tooltip": "將 audio2 附加在 audio1 之後或之前。" } } };
const AudioEncoderEncode = { "display_name": "音訊編碼器編碼", "inputs": { "audio": { "name": "音訊" }, "audio_encoder": { "name": "audio_encoder" } }, "outputs": { "0": { "tooltip": null } } };
const AudioEncoderLoader = { "display_name": "音訊編碼器載入器", "inputs": { "audio_encoder_name": { "name": "audio_encoder_name" } }, "outputs": { "0": { "tooltip": null } } };
const AudioMerge = { "description": "透過疊加波形來合併兩個音軌。", "display_name": "音訊合併", "inputs": { "audio1": { "name": "audio1" }, "audio2": { "name": "audio2" }, "merge_method": { "name": "merge_method", "tooltip": "用於合併音訊波形的方法。" } } };
const BasicGuider = { "display_name": "基礎引導器", "inputs": { "conditioning": { "name": "條件設定" }, "model": { "name": "model" } } };
const BasicScheduler = { "display_name": "BasicScheduler", "inputs": { "denoise": { "name": "去雜訊強度" }, "model": { "name": "model" }, "scheduler": { "name": "scheduler" }, "steps": { "name": "步驟數" } } };
const BetaSamplingScheduler = { "display_name": "BetaSamplingScheduler", "inputs": { "alpha": { "name": "alpha" }, "beta": { "name": "beta" }, "model": { "name": "model" }, "steps": { "name": "步驟數" } } };
const ByteDanceFirstLastFrameNode = { "description": "使用提示詞和首尾幀生成影片。", "display_name": "字節跳動首尾幀轉影片", "inputs": { "aspect_ratio": { "name": "長寬比", "tooltip": "輸出影片的長寬比。" }, "camera_fixed": { "name": "固定攝影機", "tooltip": "指定是否固定攝影機。平台會將固定攝影機的指令附加到您的提示詞中，但不保證實際效果。" }, "control_after_generate": { "name": "生成後控制" }, "duration": { "name": "持續時間", "tooltip": "輸出影片的持續時間（秒）。" }, "first_frame": { "name": "首幀", "tooltip": "用於影片的首幀。" }, "last_frame": { "name": "尾幀", "tooltip": "用於影片的尾幀。" }, "model": { "name": "模型" }, "prompt": { "name": "提示詞", "tooltip": "用於生成影片的文字提示詞。" }, "resolution": { "name": "解析度", "tooltip": "輸出影片的解析度。" }, "seed": { "name": "種子值", "tooltip": "用於生成的種子值。" }, "watermark": { "name": "浮水印", "tooltip": "是否在影片中添加「AI 生成」浮水印。" } }, "outputs": { "0": { "tooltip": null } } };
const ByteDanceImageEditNode = { "description": "透過 API 使用字節跳動模型根據提示詞編輯圖片", "display_name": "字節跳動圖片編輯", "inputs": { "control_after_generate": { "name": "control after generate" }, "guidance_scale": { "name": "guidance_scale", "tooltip": "數值越高，圖像越遵循提示詞" }, "image": { "name": "圖片", "tooltip": "要編輯的基礎圖片" }, "model": { "name": "模型" }, "prompt": { "name": "提示詞", "tooltip": "編輯圖片的指令" }, "seed": { "name": "seed", "tooltip": "用於生成的種子值" }, "watermark": { "name": "watermark", "tooltip": "是否在圖像上添加「AI 生成」浮水印" } }, "outputs": { "0": { "tooltip": null } } };
const ByteDanceImageNode = { "description": "透過 API 基於提示詞使用字節跳動模型生成圖像", "display_name": "字節跳動圖像", "inputs": { "control_after_generate": { "name": "control after generate" }, "guidance_scale": { "name": "guidance_scale", "tooltip": "數值越高，圖像越遵循提示詞" }, "height": { "name": "height", "tooltip": "圖像的自訂高度。僅在 `size_preset` 設為 `Custom` 時生效" }, "model": { "name": "model" }, "prompt": { "name": "prompt", "tooltip": "用於生成圖像的文字提示詞" }, "seed": { "name": "seed", "tooltip": "用於生成的種子值" }, "size_preset": { "name": "size_preset", "tooltip": "選擇推薦尺寸。選擇「自訂」以使用下方的寬度和高度" }, "watermark": { "name": "watermark", "tooltip": "是否在圖像上添加「AI 生成」浮水印" }, "width": { "name": "width", "tooltip": "圖像的自訂寬度。僅在 `size_preset` 設為 `Custom` 時生效" } }, "outputs": { "0": { "tooltip": null } } };
const ByteDanceImageReferenceNode = { "description": "使用提示詞和參考圖像生成影片", "display_name": "字節跳動參考圖像轉影片", "inputs": { "aspect_ratio": { "name": "aspect_ratio", "tooltip": "輸出影片的長寬比。" }, "control_after_generate": { "name": "control after generate" }, "duration": { "name": "duration", "tooltip": "輸出影片的持續時間（以秒為單位）。" }, "images": { "name": "images", "tooltip": "一至四張圖片。" }, "model": { "name": "model" }, "prompt": { "name": "prompt", "tooltip": "用於生成影片的文字提示。" }, "resolution": { "name": "resolution", "tooltip": "輸出影片的解析度。" }, "seed": { "name": "seed", "tooltip": "用於生成的種子值。" }, "watermark": { "name": "watermark", "tooltip": "是否在影片中添加「AI 生成」浮水印。" } }, "outputs": { "0": { "tooltip": null } } };
const ByteDanceImageToVideoNode = { "description": "透過 API 使用字節跳動模型，基於圖片和提示生成影片", "display_name": "字節跳動圖片轉影片", "inputs": { "aspect_ratio": { "name": "aspect_ratio", "tooltip": "輸出影片的長寬比。" }, "camera_fixed": { "name": "camera_fixed", "tooltip": "指定是否固定相機。平台會將固定相機的指令附加到您的提示詞中，但不保證實際效果。" }, "control_after_generate": { "name": "control after generate" }, "duration": { "name": "duration", "tooltip": "輸出影片的持續時間（以秒為單位）。" }, "image": { "name": "image", "tooltip": "用於影片的第一幀圖片。" }, "model": { "name": "model" }, "prompt": { "name": "prompt", "tooltip": "用於生成影片的文字提示。" }, "resolution": { "name": "resolution", "tooltip": "輸出影片的解析度。" }, "seed": { "name": "seed", "tooltip": "用於生成的種子值。" }, "watermark": { "name": "watermark", "tooltip": "是否在影片中添加「AI 生成」浮水印。" } }, "outputs": { "0": { "tooltip": null } } };
const ByteDanceSeedreamNode = { "description": "統一文字生成圖片和精確單句編輯，最高支援 4K 解析度。", "display_name": "字節跳動 Seedream 4", "inputs": { "control_after_generate": { "name": "生成後控制" }, "fail_on_partial": { "name": "fail_on_partial", "tooltip": "若啟用，當任何請求的圖像缺失或回報錯誤時，將中止執行。" }, "height": { "name": "height", "tooltip": "圖像的自訂高度。僅在 `size_preset` 設為 `Custom` 時生效" }, "image": { "name": "image", "tooltip": "用於圖像生成圖像的輸入圖片。單一或多參考生成可使用 1-10 張圖片清單。" }, "max_images": { "name": "max_images", "tooltip": "當 sequential_image_generation='auto' 時，生成圖像的最大數量。總圖像數（輸入 + 生成）不得超過 15 張。" }, "model": { "name": "model", "tooltip": "模型名稱" }, "prompt": { "name": "prompt", "tooltip": "用於建立或編輯圖片的文字提示。" }, "seed": { "name": "seed", "tooltip": "用於生成的種子值。" }, "sequential_image_generation": { "name": "sequential_image_generation", "tooltip": "群組圖像生成模式。「disabled」生成單一圖像。「auto」讓模型決定是否生成多張相關圖像（例如故事場景、角色變體）。" }, "size_preset": { "name": "size_preset", "tooltip": "選擇推薦尺寸。選擇「自訂」以使用下方的寬度和高度。" }, "watermark": { "name": "watermark", "tooltip": "是否在圖像中添加「AI 生成」浮水印。" }, "width": { "name": "width", "tooltip": "圖像的自訂寬度。僅在 `size_preset` 設為 `Custom` 時生效" } }, "outputs": { "0": { "tooltip": null } } };
const ByteDanceTextToVideoNode = { "description": "透過 API 使用字節跳動模型根據提示生成影片", "display_name": "字節跳動文字轉影片", "inputs": { "aspect_ratio": { "name": "長寬比", "tooltip": "輸出影片的長寬比。" }, "camera_fixed": { "name": "固定攝影機", "tooltip": "指定是否固定攝影機。平台會將固定攝影機的指令附加到您的提示詞中，但不保證實際效果。" }, "control_after_generate": { "name": "生成後控制" }, "duration": { "name": "持續時間", "tooltip": "輸出影片的持續時間（秒）。" }, "model": { "name": "模型" }, "prompt": { "name": "提示詞", "tooltip": "用於生成影片的文字提示。" }, "resolution": { "name": "解析度", "tooltip": "輸出影片的解析度。" }, "seed": { "name": "種子值", "tooltip": "用於生成的種子值。" }, "watermark": { "name": "浮水印", "tooltip": "是否在影片中添加「AI 生成」浮水印。" } }, "outputs": { "0": { "tooltip": null } } };
const CFGGuider = { "display_name": "CFGGuider", "inputs": { "cfg": { "name": "cfg" }, "model": { "name": "model" }, "negative": { "name": "負向" }, "positive": { "name": "正向" } } };
const CFGNorm = { "display_name": "CFG 正規化", "inputs": { "model": { "name": "模型" }, "strength": { "name": "強度" } }, "outputs": { "0": { "name": "修補模型", "tooltip": null } } };
const CFGZeroStar = { "display_name": "CFGZeroStar", "inputs": { "model": { "name": "model" } }, "outputs": { "0": { "name": "patched_model", "tooltip": null } } };
const CLIPAttentionMultiply = { "display_name": "CLIPAttentionMultiply", "inputs": { "clip": { "name": "clip" }, "k": { "name": "k" }, "out": { "name": "out" }, "q": { "name": "q" }, "v": { "name": "v" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPLoader = { "description": "[配方]\n\nstable_diffusion: clip-l\nstable_cascade: clip-g\nsd3: t5 xxl/ clip-g / clip-l\nstable_audio: t5 base\nmochi: t5 xxl\ncosmos: 舊 t5 xxl\nlumina2: gemma 2 2B\nwan: umt5 xxl\nhidream: llama-3.1（推薦）或 t5", "display_name": "載入 CLIP", "inputs": { "clip_name": { "name": "clip_name" }, "device": { "name": "device" }, "type": { "name": "type" } } };
const CLIPMergeAdd = { "display_name": "CLIPMergeAdd", "inputs": { "clip1": { "name": "clip1" }, "clip2": { "name": "clip2" } } };
const CLIPMergeSimple = { "display_name": "CLIPMergeSimple", "inputs": { "clip1": { "name": "clip1" }, "clip2": { "name": "clip2" }, "ratio": { "name": "比例" } } };
const CLIPMergeSubtract = { "display_name": "CLIPMergeSubtract", "inputs": { "clip1": { "name": "clip1" }, "clip2": { "name": "clip2" }, "multiplier": { "name": "乘數" } } };
const CLIPSave = { "display_name": "CLIP 儲存", "inputs": { "clip": { "name": "clip" }, "filename_prefix": { "name": "檔名前綴" } } };
const CLIPSetLastLayer = { "display_name": "CLIP 設定最後一層", "inputs": { "clip": { "name": "clip" }, "stop_at_clip_layer": { "name": "停止於 CLIP 層" } } };
const CLIPTextEncode = { "description": "使用 CLIP 模型將文字提示編碼為嵌入向量，可用於引導擴散模型生成特定圖像。", "display_name": "CLIP 文字編碼（提示詞）", "inputs": { "clip": { "name": "CLIP", "tooltip": "用於編碼文字的 CLIP 模型。" }, "text": { "name": "文字", "tooltip": "要編碼的文字內容。" } }, "outputs": { "0": { "tooltip": "包含嵌入文字的條件，用於引導擴散模型。" } } };
const CLIPTextEncodeControlnet = { "display_name": "CLIPTextEncodeControlnet", "inputs": { "clip": { "name": "clip" }, "conditioning": { "name": "條件設定" }, "text": { "name": "文字" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeFlux = { "display_name": "CLIPTextEncodeFlux", "inputs": { "clip": { "name": "clip" }, "clip_l": { "name": "clip_l" }, "guidance": { "name": "引導" }, "t5xxl": { "name": "t5xxl" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeHiDream = { "display_name": "CLIPTextEncodeHiDream", "inputs": { "clip": { "name": "clip" }, "clip_g": { "name": "clip_g" }, "clip_l": { "name": "clip_l" }, "llama": { "name": "llama" }, "t5xxl": { "name": "t5xxl" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeHunyuanDiT = { "display_name": "CLIPTextEncodeHunyuanDiT", "inputs": { "bert": { "name": "bert" }, "clip": { "name": "clip" }, "mt5xl": { "name": "mt5xl" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeLumina2 = { "description": "使用 CLIP 模型將系統提示與使用者提示編碼為嵌入向量，可用於引導擴散模型生成特定圖像。", "display_name": "CLIP 文本編碼（Lumina2）", "inputs": { "clip": { "name": "clip", "tooltip": "用於編碼文字的 CLIP 模型。" }, "system_prompt": { "name": "system_prompt", "tooltip": "Lumina2 提供兩種類型的系統提示：Superior：你是一個旨在根據文字提示或使用者提示，生成圖文對齊度極高的優質圖像的助手。Alignment：你是一個旨在根據文字提示，生成圖文對齊度最高的高品質圖像的助手。" }, "user_prompt": { "name": "user_prompt", "tooltip": "要編碼的文字內容。" } }, "outputs": { "0": { "tooltip": "包含嵌入文字的條件，用於引導擴散模型。" } } };
const CLIPTextEncodePixArtAlpha = { "description": "編碼文字並設定 PixArt Alpha 的解析度條件。不適用於 PixArt Sigma。", "display_name": "CLIPTextEncodePixArtAlpha", "inputs": { "clip": { "name": "clip" }, "height": { "name": "高度" }, "text": { "name": "文字" }, "width": { "name": "寬度" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeSD3 = { "display_name": "CLIPTextEncodeSD3", "inputs": { "clip": { "name": "clip" }, "clip_g": { "name": "clip_g" }, "clip_l": { "name": "clip_l" }, "empty_padding": { "name": "空白填充" }, "t5xxl": { "name": "t5xxl" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeSDXL = { "display_name": "CLIPTextEncodeSDXL", "inputs": { "clip": { "name": "clip" }, "crop_h": { "name": "裁剪高度" }, "crop_w": { "name": "裁剪寬度" }, "height": { "name": "高度" }, "target_height": { "name": "目標高度" }, "target_width": { "name": "目標寬度" }, "text_g": { "name": "文字 G" }, "text_l": { "name": "文字 L" }, "width": { "name": "寬度" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeSDXLRefiner = { "display_name": "CLIPTextEncodeSDXLRefiner", "inputs": { "ascore": { "name": "ascore" }, "clip": { "name": "clip" }, "height": { "name": "高度" }, "text": { "name": "文字" }, "width": { "name": "寬度" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPVisionEncode = { "display_name": "CLIP Vision 編碼", "inputs": { "clip_vision": { "name": "clip_vision" }, "crop": { "name": "裁切" }, "image": { "name": "圖片" } } };
const CLIPVisionLoader = { "display_name": "載入 CLIP Vision", "inputs": { "clip_name": { "name": "clip_name" } } };
const Canny = { "display_name": "Canny", "inputs": { "high_threshold": { "name": "高閾值" }, "image": { "name": "影像" }, "low_threshold": { "name": "低閾值" } }, "outputs": { "0": { "tooltip": null } } };
const CaseConverter = { "display_name": "大小寫轉換器", "inputs": { "mode": { "name": "模式" }, "string": { "name": "字串" } }, "outputs": { "0": { "tooltip": null } } };
const CheckpointLoader = { "display_name": "載入檢查點與設定檔（已淘汰）", "inputs": { "ckpt_name": { "name": "ckpt_name" }, "config_name": { "name": "config_name" } } };
const CheckpointLoaderSimple = { "description": "載入一個擴散模型檢查點，擴散模型用於對潛在空間進行去噪處理。", "display_name": "載入檢查點", "inputs": { "ckpt_name": { "name": "ckpt_name", "tooltip": "要載入的檢查點（模型）名稱。" } }, "outputs": { "0": { "tooltip": "用於對潛在空間進行去噪處理的模型。" }, "1": { "tooltip": "用於編碼文字提示的 CLIP 模型。" }, "2": { "tooltip": "用於將影像與潛在空間之間進行編碼與解碼的 VAE 模型。" } } };
const CheckpointSave = { "display_name": "儲存檢查點", "inputs": { "clip": { "name": "clip" }, "filename_prefix": { "name": "檔名前綴" }, "model": { "name": "模型" }, "vae": { "name": "vae" } } };
const ChromaRadianceOptions = { "description": "允許為 Chroma Radiance 模型設定進階選項。", "display_name": "ChromaRadiance 選項", "inputs": { "end_sigma": { "name": "結束 sigma", "tooltip": "這些選項將生效的最後一個 sigma 值。" }, "model": { "name": "模型" }, "nerf_tile_size": { "name": "NeRF 圖塊大小", "tooltip": "允許覆寫預設的 NeRF 圖塊大小。-1 表示使用預設值 (32)。0 表示使用非平鋪模式（可能需要大量 VRAM）。" }, "preserve_wrapper": { "name": "保留包裝器", "tooltip": "啟用時，如果存在現有模型函數包裝器，將委派給它。通常應保持啟用狀態。" }, "start_sigma": { "name": "起始 sigma", "tooltip": "這些選項將生效的第一個 sigma 值。" } }, "outputs": { "0": { "tooltip": null } } };
const CombineHooks2 = { "display_name": "合併 Hooks [2]", "inputs": { "hooks_A": { "name": "hooks_A" }, "hooks_B": { "name": "hooks_B" } } };
const CombineHooks4 = { "display_name": "合併 Hooks [4]", "inputs": { "hooks_A": { "name": "hooks_A" }, "hooks_B": { "name": "hooks_B" }, "hooks_C": { "name": "hooks_C" }, "hooks_D": { "name": "hooks_D" } } };
const CombineHooks8 = { "display_name": "合併 Hooks [8]", "inputs": { "hooks_A": { "name": "hooks_A" }, "hooks_B": { "name": "hooks_B" }, "hooks_C": { "name": "hooks_C" }, "hooks_D": { "name": "hooks_D" }, "hooks_E": { "name": "hooks_E" }, "hooks_F": { "name": "hooks_F" }, "hooks_G": { "name": "hooks_G" }, "hooks_H": { "name": "hooks_H" } } };
const ConditioningAverage = { "display_name": "條件設定（平均）", "inputs": { "conditioning_from": { "name": "conditioning_from" }, "conditioning_to": { "name": "conditioning_to" }, "conditioning_to_strength": { "name": "conditioning_to_strength" } } };
const ConditioningCombine = { "display_name": "條件（合併）", "inputs": { "conditioning_1": { "name": "conditioning_1" }, "conditioning_2": { "name": "conditioning_2" } } };
const ConditioningConcat = { "display_name": "條件（串接）", "inputs": { "conditioning_from": { "name": "conditioning_from" }, "conditioning_to": { "name": "conditioning_to" } } };
const ConditioningSetArea = { "display_name": "條件設定（區域設置）", "inputs": { "conditioning": { "name": "條件" }, "height": { "name": "高度" }, "strength": { "name": "強度" }, "width": { "name": "寬度" }, "x": { "name": "X 座標" }, "y": { "name": "Y 座標" } } };
const ConditioningSetAreaPercentage = { "display_name": "條件設定（以百分比設置區域）", "inputs": { "conditioning": { "name": "條件" }, "height": { "name": "高度" }, "strength": { "name": "強度" }, "width": { "name": "寬度" }, "x": { "name": "X 座標" }, "y": { "name": "Y 座標" } } };
const ConditioningSetAreaPercentageVideo = { "display_name": "條件設定（影片區域百分比）", "inputs": { "conditioning": { "name": "條件設定" }, "height": { "name": "高度" }, "strength": { "name": "強度" }, "temporal": { "name": "時間軸" }, "width": { "name": "寬度" }, "x": { "name": "X 座標" }, "y": { "name": "Y 座標" }, "z": { "name": "Z 座標" } } };
const ConditioningSetAreaStrength = { "display_name": "條件設定（區域強度）", "inputs": { "conditioning": { "name": "條件設定" }, "strength": { "name": "強度" } } };
const ConditioningSetDefaultCombine = { "display_name": "Cond Set Default Combine", "inputs": { "cond": { "name": "cond" }, "cond_DEFAULT": { "name": "cond_DEFAULT" }, "hooks": { "name": "hooks" } } };
const ConditioningSetMask = { "display_name": "條件設定（設置遮罩）", "inputs": { "conditioning": { "name": "條件" }, "mask": { "name": "遮罩" }, "set_cond_area": { "name": "設定條件區域" }, "strength": { "name": "強度" } } };
const ConditioningSetProperties = { "display_name": "條件集屬性", "inputs": { "cond_NEW": { "name": "cond_NEW" }, "hooks": { "name": "hooks" }, "mask": { "name": "遮罩" }, "set_cond_area": { "name": "設定條件區域" }, "strength": { "name": "強度" }, "timesteps": { "name": "時間步驟" } } };
const ConditioningSetPropertiesAndCombine = { "display_name": "條件集屬性合併", "inputs": { "cond": { "name": "cond" }, "cond_NEW": { "name": "cond_NEW" }, "hooks": { "name": "hooks" }, "mask": { "name": "遮罩" }, "set_cond_area": { "name": "設定條件區域" }, "strength": { "name": "強度" }, "timesteps": { "name": "時間步驟" } } };
const ConditioningSetTimestepRange = { "display_name": "條件設定（時間步範圍）", "inputs": { "conditioning": { "name": "條件設定" }, "end": { "name": "結束" }, "start": { "name": "開始" } } };
const ConditioningStableAudio = { "display_name": "條件設定（Stable Audio）", "inputs": { "negative": { "name": "負向" }, "positive": { "name": "正向" }, "seconds_start": { "name": "起始秒數" }, "seconds_total": { "name": "總秒數" } }, "outputs": { "0": { "name": "正向" }, "1": { "name": "負向" } } };
const ConditioningTimestepsRange = { "display_name": "步驟範圍", "inputs": { "end_percent": { "name": "結束百分比" }, "start_percent": { "name": "起始百分比" } }, "outputs": { "1": { "name": "範圍之前" }, "2": { "name": "範圍之後" } } };
const ConditioningZeroOut = { "display_name": "條件設定（歸零）", "inputs": { "conditioning": { "name": "條件設定" } } };
const ContextWindowsManual = { "description": "手動設定上下文視窗。", "display_name": "上下文視窗（手動）", "inputs": { "closed_loop": { "name": "閉環", "tooltip": "是否關閉上下文窗口循環；僅適用於循環排程。" }, "context_length": { "name": "上下文長度", "tooltip": "上下文窗口的長度。" }, "context_overlap": { "name": "上下文重疊", "tooltip": "上下文窗口的重疊量。" }, "context_schedule": { "name": "上下文排程", "tooltip": "上下文窗口的步幅。" }, "context_stride": { "name": "上下文步幅", "tooltip": "上下文窗口的步幅；僅適用於均勻排程。" }, "dim": { "name": "維度", "tooltip": "應用上下文窗口的維度。" }, "fuse_method": { "name": "融合方法", "tooltip": "用於融合上下文窗口的方法。" }, "model": { "name": "模型", "tooltip": "在取樣期間應用上下文窗口的模型。" } }, "outputs": { "0": { "tooltip": "在取樣期間應用上下文窗口的模型。" } } };
const ControlNetApply = { "display_name": "套用 ControlNet（舊版）", "inputs": { "conditioning": { "name": "條件設定" }, "control_net": { "name": "control_net" }, "image": { "name": "影像" }, "strength": { "name": "強度" } } };
const ControlNetApplyAdvanced = { "display_name": "套用 ControlNet", "inputs": { "control_net": { "name": "control_net" }, "end_percent": { "name": "結束百分比" }, "image": { "name": "影像" }, "negative": { "name": "負向" }, "positive": { "name": "正向" }, "start_percent": { "name": "起始百分比" }, "strength": { "name": "強度" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "正向" }, "1": { "name": "負向" } } };
const ControlNetApplySD3 = { "display_name": "套用 ControlNet (SD3)", "inputs": { "control_net": { "name": "control_net" }, "end_percent": { "name": "結束百分比" }, "image": { "name": "影像" }, "negative": { "name": "負向" }, "positive": { "name": "正向" }, "start_percent": { "name": "起始百分比" }, "strength": { "name": "強度" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "正向", "tooltip": null }, "1": { "name": "負向", "tooltip": null } } };
const ControlNetInpaintingAliMamaApply = { "display_name": "套用 ControlNet 修補（AliMama）", "inputs": { "control_net": { "name": "control_net" }, "end_percent": { "name": "結束百分比" }, "image": { "name": "影像" }, "mask": { "name": "遮罩" }, "negative": { "name": "負向" }, "positive": { "name": "正向" }, "start_percent": { "name": "起始百分比" }, "strength": { "name": "強度" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "正向", "tooltip": null }, "1": { "name": "負向", "tooltip": null } } };
const ControlNetLoader = { "display_name": "載入 ControlNet 模型", "inputs": { "control_net_name": { "name": "control_net_name" } } };
const CosmosImageToVideoLatent = { "display_name": "Cosmos 圖片轉影片潛在編碼", "inputs": { "batch_size": { "name": "批次大小" }, "end_image": { "name": "結束圖片" }, "height": { "name": "高度" }, "length": { "name": "長度" }, "start_image": { "name": "起始影像" }, "vae": { "name": "vae" }, "width": { "name": "寬度" } }, "outputs": { "0": { "tooltip": null } } };
const CosmosPredict2ImageToVideoLatent = { "display_name": "CosmosPredict2ImageToVideoLatent", "inputs": { "batch_size": { "name": "批次大小" }, "end_image": { "name": "結束影像" }, "height": { "name": "高度" }, "length": { "name": "長度" }, "start_image": { "name": "起始影像" }, "vae": { "name": "VAE" }, "width": { "name": "寬度" } }, "outputs": { "0": { "tooltip": null } } };
const CreateHookKeyframe = { "display_name": "建立 Hook 關鍵影格", "inputs": { "prev_hook_kf": { "name": "prev_hook_kf" }, "start_percent": { "name": "start_percent" }, "strength_mult": { "name": "strength_mult" } }, "outputs": { "0": { "name": "HOOK_KF" } } };
const CreateHookKeyframesFromFloats = { "display_name": "從浮點數建立 Hook 關鍵影格", "inputs": { "end_percent": { "name": "結束百分比" }, "floats_strength": { "name": "floats_strength" }, "prev_hook_kf": { "name": "前一個 Hook 關鍵影格" }, "print_keyframes": { "name": "顯示關鍵影格" }, "start_percent": { "name": "起始百分比" } }, "outputs": { "0": { "name": "HOOK_KF" } } };
const CreateHookKeyframesInterpolated = { "display_name": "建立 Hook 關鍵影格插值", "inputs": { "end_percent": { "name": "結束百分比" }, "interpolation": { "name": "插值方式" }, "keyframes_count": { "name": "關鍵影格數量" }, "prev_hook_kf": { "name": "前一個 Hook 關鍵影格" }, "print_keyframes": { "name": "輸出關鍵影格" }, "start_percent": { "name": "起始百分比" }, "strength_end": { "name": "strength_end" }, "strength_start": { "name": "strength_start" } }, "outputs": { "0": { "name": "HOOK_KF" } } };
const CreateHookLora = { "display_name": "建立 Hook LoRA", "inputs": { "lora_name": { "name": "lora_name" }, "prev_hooks": { "name": "prev_hooks" }, "strength_clip": { "name": "strength_clip" }, "strength_model": { "name": "strength_model" } } };
const CreateHookLoraModelOnly = { "display_name": "建立 Hook LoRA (MO)", "inputs": { "lora_name": { "name": "lora_name" }, "prev_hooks": { "name": "prev_hooks" }, "strength_model": { "name": "strength_model" } } };
const CreateHookModelAsLora = { "display_name": "建立 Hook 模型為 LoRA", "inputs": { "ckpt_name": { "name": "ckpt_name" }, "prev_hooks": { "name": "前一個 hook" }, "strength_clip": { "name": "clip 強度" }, "strength_model": { "name": "模型強度" } } };
const CreateHookModelAsLoraModelOnly = { "display_name": "建立 Hook 模型為 LoRA（MO）", "inputs": { "ckpt_name": { "name": "ckpt_name" }, "prev_hooks": { "name": "prev_hooks" }, "strength_model": { "name": "strength_model" } } };
const CreateVideo = { "description": "從圖片建立影片。", "display_name": "建立影片", "inputs": { "audio": { "name": "音訊", "tooltip": "要加入影片的音訊。" }, "fps": { "name": "每秒影格數" }, "images": { "name": "影像", "tooltip": "用來建立影片的圖片。" } }, "outputs": { "0": { "tooltip": null } } };
const CropMask = { "display_name": "裁剪遮罩", "inputs": { "height": { "name": "高度" }, "mask": { "name": "遮罩" }, "width": { "name": "寬度" }, "x": { "name": "X 座標" }, "y": { "name": "Y 座標" } } };
const DiffControlNetLoader = { "display_name": "載入 ControlNet 模型（diff）", "inputs": { "control_net_name": { "name": "control_net_name" }, "model": { "name": "model" } } };
const DifferentialDiffusion = { "display_name": "差分擴散", "inputs": { "model": { "name": "模型" }, "strength": { "name": "強度" } }, "outputs": { "0": { "tooltip": null } } };
const DiffusersLoader = { "display_name": "Diffusers 載入器", "inputs": { "model_path": { "name": "model_path" } } };
const DisableNoise = { "display_name": "停用雜訊" };
const DualCFGGuider = { "display_name": "雙 CFG 引導器", "inputs": { "cfg_cond2_negative": { "name": "cfg cond2 負面" }, "cfg_conds": { "name": "cfg 條件" }, "cond1": { "name": "cond1" }, "cond2": { "name": "cond2" }, "model": { "name": "model" }, "negative": { "name": "負面" }, "style": { "name": "風格" } } };
const DualCLIPLoader = { "description": "[配方]\n\nsdxl：clip-l、clip-g\nsd3：clip-l、clip-g / clip-l、t5 / clip-g、t5\nflux：clip-l、t5\nhidream：至少需有 t5 或 llama，建議同時使用 t5 與 llama", "display_name": "雙 CLIP 載入器", "inputs": { "clip_name1": { "name": "clip_name1" }, "clip_name2": { "name": "clip_name2" }, "device": { "name": "device" }, "type": { "name": "type" } } };
const EasyCache = { "description": "原生 EasyCache 實現。", "display_name": "EasyCache", "inputs": { "end_percent": { "name": "結束百分比", "tooltip": "結束使用 EasyCache 的相對取樣步驟。" }, "model": { "name": "模型", "tooltip": "要添加 EasyCache 的模型。" }, "reuse_threshold": { "name": "重用閾值", "tooltip": "重用快取步驟的閾值。" }, "start_percent": { "name": "起始百分比", "tooltip": "開始使用 EasyCache 的相對取樣步驟。" }, "verbose": { "name": "詳細模式", "tooltip": "是否記錄詳細資訊。" } }, "outputs": { "0": { "tooltip": "帶有 EasyCache 的模型。" } } };
const EmptyAceStepLatentAudio = { "display_name": "EmptyAceStepLatentAudio", "inputs": { "batch_size": { "name": "批次大小", "tooltip": "批次中的潛在圖像數量。" }, "seconds": { "name": "秒數" } }, "outputs": { "0": { "tooltip": null } } };
const EmptyAudio = { "display_name": "空白音訊", "inputs": { "channels": { "name": "聲道數", "tooltip": "音訊聲道數量（1為單聲道，2為立體聲）。" }, "duration": { "name": "持續時間", "tooltip": "空白音訊片段的持續時間（秒）" }, "sample_rate": { "name": "取樣率", "tooltip": "空白音訊片段的取樣率。" } } };
const EmptyChromaRadianceLatentImage = { "display_name": "EmptyChromaRadianceLatentImage", "inputs": { "batch_size": { "name": "批次大小" }, "height": { "name": "高度" }, "width": { "name": "寬度" } }, "outputs": { "0": { "tooltip": null } } };
const EmptyCosmosLatentVideo = { "display_name": "EmptyCosmosLatentVideo", "inputs": { "batch_size": { "name": "批次大小" }, "height": { "name": "高度" }, "length": { "name": "長度" }, "width": { "name": "寬度" } }, "outputs": { "0": { "tooltip": null } } };
const EmptyHunyuanImageLatent = { "display_name": "EmptyHunyuanImageLatent", "inputs": { "batch_size": { "name": "批次大小" }, "height": { "name": "高度" }, "width": { "name": "寬度" } }, "outputs": { "0": { "tooltip": null } } };
const EmptyHunyuanLatentVideo = { "display_name": "EmptyHunyuanLatentVideo", "inputs": { "batch_size": { "name": "批次大小" }, "height": { "name": "高度" }, "length": { "name": "長度" }, "width": { "name": "寬度" } }, "outputs": { "0": { "tooltip": null } } };
const EmptyImage = { "display_name": "空白圖片", "inputs": { "batch_size": { "name": "批次大小" }, "color": { "name": "顏色" }, "height": { "name": "高度" }, "width": { "name": "寬度" } } };
const EmptyLTXVLatentVideo = { "display_name": "EmptyLTXVLatentVideo", "inputs": { "batch_size": { "name": "批次大小" }, "height": { "name": "高度" }, "length": { "name": "長度" }, "width": { "name": "寬度" } }, "outputs": { "0": { "tooltip": null } } };
const EmptyLatentAudio = { "display_name": "空白潛空間音訊", "inputs": { "batch_size": { "name": "批次大小", "tooltip": "此批次中的潛空間影像數量。" }, "seconds": { "name": "秒數" } } };
const EmptyLatentHunyuan3Dv2 = { "display_name": "EmptyLatentHunyuan3Dv2", "inputs": { "batch_size": { "name": "批次大小", "tooltip": "此批次中潛空間影像的數量。" }, "resolution": { "name": "解析度" } } };
const EmptyLatentImage = { "description": "建立一批新的空白潛在影像，透過取樣去除雜訊。", "display_name": "空白潛在影像", "inputs": { "batch_size": { "name": "批次大小", "tooltip": "此批次中的潛在影像數量。" }, "height": { "name": "高度", "tooltip": "潛在影像的高度（像素）。" }, "width": { "name": "寬度", "tooltip": "潛在影像的寬度（像素）。" } }, "outputs": { "0": { "tooltip": "空白潛在影像批次。" } } };
const EmptyMochiLatentVideo = { "display_name": "EmptyMochiLatentVideo", "inputs": { "batch_size": { "name": "批次大小" }, "height": { "name": "高度" }, "length": { "name": "長度" }, "width": { "name": "寬度" } }, "outputs": { "0": { "tooltip": null } } };
const EmptySD3LatentImage = { "display_name": "EmptySD3LatentImage", "inputs": { "batch_size": { "name": "批次大小" }, "height": { "name": "高度" }, "width": { "name": "寬度" } }, "outputs": { "0": { "tooltip": null } } };
const ExponentialScheduler = { "display_name": "指數排程器", "inputs": { "sigma_max": { "name": "最大 sigma" }, "sigma_min": { "name": "最小 sigma" }, "steps": { "name": "步驟數" } } };
const ExtendIntermediateSigmas = { "display_name": "ExtendIntermediateSigmas", "inputs": { "end_at_sigma": { "name": "結束 sigma" }, "sigmas": { "name": "sigmas" }, "spacing": { "name": "間距" }, "start_at_sigma": { "name": "起始 sigma" }, "steps": { "name": "步驟數" } } };
const FeatherMask = { "display_name": "羽化遮罩", "inputs": { "bottom": { "name": "下方" }, "left": { "name": "左側" }, "mask": { "name": "遮罩" }, "right": { "name": "右側" }, "top": { "name": "上方" } } };
const FlipSigmas = { "display_name": "FlipSigmas", "inputs": { "sigmas": { "name": "sigmas" } } };
const FluxDisableGuidance = { "description": "此節點會完全停用 Flux 及類似 Flux 模型上的引導嵌入", "display_name": "FluxDisableGuidance", "inputs": { "conditioning": { "name": "條件設定" } }, "outputs": { "0": { "tooltip": null } } };
const FluxGuidance = { "display_name": "FluxGuidance", "inputs": { "conditioning": { "name": "條件設定" }, "guidance": { "name": "引導" } }, "outputs": { "0": { "tooltip": null } } };
const FluxKontextImageScale = { "description": "此節點將圖像調整為更適合flux kontext的尺寸。", "display_name": "FluxKontextImageScale", "inputs": { "image": { "name": "圖像" } }, "outputs": { "0": { "tooltip": null } } };
const FluxKontextMaxImageNode = { "description": "基於提示和長寬比，透過API使用Flux.1 Kontext [max]編輯圖像。", "display_name": "Flux.1 Kontext [max] 圖像", "inputs": { "aspect_ratio": { "name": "長寬比", "tooltip": "圖像長寬比；必須介於1:4至4:1之間。" }, "control_after_generate": { "name": "生成後控制" }, "guidance": { "name": "引導強度", "tooltip": "圖像生成過程的引導強度" }, "input_image": { "name": "輸入圖像" }, "prompt": { "name": "提示詞", "tooltip": "圖像生成的提示詞 - 指定編輯內容和方式。" }, "prompt_upsampling": { "name": "提示詞上採樣", "tooltip": "是否對提示詞執行上採樣。若啟用，會自動修改提示詞以實現更具創意的生成，但結果具有不確定性（相同種子值不會產生完全相同的結果）。" }, "seed": { "name": "種子值", "tooltip": "用於創建噪聲的隨機種子值。" }, "steps": { "name": "步數", "tooltip": "圖像生成過程的步數" } }, "outputs": { "0": { "tooltip": null } } };
const FluxKontextMultiReferenceLatentMethod = { "display_name": "FluxKontext 多重參考潛在方法", "inputs": { "conditioning": { "name": "條件化" }, "reference_latents_method": { "name": "參考潛在方法" } }, "outputs": { "0": { "tooltip": null } } };
const FluxKontextProImageNode = { "description": "使用 Flux.1 Kontext [專業版] 透過 API 根據提示詞和長寬比編輯影像。", "display_name": "Flux.1 Kontext [專業版] 影像", "inputs": { "aspect_ratio": { "name": "長寬比", "tooltip": "影像的長寬比；必須在 1:4 到 4:1 之間。" }, "control_after_generate": { "name": "生成後控制" }, "guidance": { "name": "引導強度", "tooltip": "影像生成過程的引導強度" }, "input_image": { "name": "輸入影像" }, "prompt": { "name": "提示詞", "tooltip": "影像生成的提示詞 - 指定要編輯的內容和方式。" }, "prompt_upsampling": { "name": "提示詞上採樣", "tooltip": "是否對提示詞執行上採樣。如果啟用，會自動修改提示詞以實現更具創意的生成，但結果具有不確定性（相同種子值不會產生完全相同的結果）。" }, "seed": { "name": "種子值", "tooltip": "用於創建噪聲的隨機種子值。" }, "steps": { "name": "步數", "tooltip": "影像生成過程的步數" } }, "outputs": { "0": { "tooltip": null } } };
const FluxProExpandNode = { "description": "根據提示詞對影像進行外擴。", "display_name": "Flux.1 擴展影像", "inputs": { "bottom": { "name": "下方", "tooltip": "在影像下方擴展的像素數" }, "control_after_generate": { "name": "生成後控制" }, "guidance": { "name": "引導強度", "tooltip": "影像生成過程的引導強度" }, "image": { "name": "影像" }, "left": { "name": "左側", "tooltip": "在影像左側擴展的像素數" }, "prompt": { "name": "提示詞", "tooltip": "用於生成影像的提示詞" }, "prompt_upsampling": { "name": "提示詞向上採樣", "tooltip": "是否對提示詞進行向上採樣。啟用時，會自動修改提示詞以產生更具創意的生成結果，但結果具有不確定性（相同種子不會產生完全相同的結果）。" }, "right": { "name": "右側", "tooltip": "在影像右側擴展的像素數" }, "seed": { "name": "種子", "tooltip": "用於產生雜訊的隨機種子。" }, "steps": { "name": "步驟數", "tooltip": "影像生成過程的步數" }, "top": { "name": "上方", "tooltip": "在影像上方擴展的像素數" } }, "outputs": { "0": { "tooltip": null } } };
const FluxProFillNode = { "description": "根據遮罩與提示詞對影像進行修補。", "display_name": "Flux.1 填充影像", "inputs": { "control_after_generate": { "name": "生成後控制" }, "guidance": { "name": "引導強度", "tooltip": "影像生成過程的引導強度" }, "image": { "name": "影像" }, "mask": { "name": "遮罩" }, "prompt": { "name": "提示詞", "tooltip": "用於生成影像的提示詞" }, "prompt_upsampling": { "name": "提示詞向上採樣", "tooltip": "是否對提示詞進行向上採樣。啟用時，會自動修改提示詞以產生更具創意的結果，但結果具有不確定性（相同種子不會產生完全相同的結果）。" }, "seed": { "name": "種子", "tooltip": "用於產生雜訊的隨機種子。" }, "steps": { "name": "步驟數", "tooltip": "影像生成過程的步數" } }, "outputs": { "0": { "tooltip": null } } };
const FluxProUltraImageNode = { "description": "透過 API 使用 Flux Pro 1.1 Ultra 根據提示詞與解析度產生影像。", "display_name": "Flux 1.1 [pro] Ultra 影像", "inputs": { "aspect_ratio": { "name": "長寬比", "tooltip": "影像的長寬比；必須介於 1:4 與 4:1 之間。" }, "control_after_generate": { "name": "生成後控制" }, "image_prompt": { "name": "影像提示" }, "image_prompt_strength": { "name": "影像提示強度", "tooltip": "提示詞與影像提示之間的混合比例。" }, "prompt": { "name": "提示詞", "tooltip": "用於影像生成的提示詞" }, "prompt_upsampling": { "name": "提示詞向上採樣", "tooltip": "是否對提示詞進行向上採樣。啟用時，會自動修改提示詞以產生更具創意的結果，但結果具有不確定性（相同種子不會產生完全相同的結果）。" }, "raw": { "name": "原始", "tooltip": "若為 True，則產生較少處理、更自然的影像。" }, "seed": { "name": "種子", "tooltip": "用於產生雜訊的隨機種子。" } }, "outputs": { "0": { "tooltip": null } } };
const FreSca = { "description": "對引導應用頻率相關的縮放", "display_name": "FreSca", "inputs": { "freq_cutoff": { "name": "freq_cutoff", "tooltip": "以中心為基準，視為低頻的頻率索引數量" }, "model": { "name": "model" }, "scale_high": { "name": "scale_high", "tooltip": "高頻成分的縮放係數" }, "scale_low": { "name": "scale_low", "tooltip": "低頻成分的縮放係數" } }, "outputs": { "0": { "tooltip": null } } };
const FreeU = { "display_name": "FreeU", "inputs": { "b1": { "name": "b1" }, "b2": { "name": "b2" }, "model": { "name": "model" }, "s1": { "name": "s1" }, "s2": { "name": "s2" } } };
const FreeU_V2 = { "display_name": "FreeU_V2", "inputs": { "b1": { "name": "b1" }, "b2": { "name": "b2" }, "model": { "name": "model" }, "s1": { "name": "s1" }, "s2": { "name": "s2" } } };
const GITSScheduler = { "display_name": "GITSScheduler", "inputs": { "coeff": { "name": "coeff" }, "denoise": { "name": "去雜訊強度" }, "steps": { "name": "步驟數" } }, "outputs": { "0": { "tooltip": null } } };
const GLIGENLoader = { "display_name": "GLIGENLoader", "inputs": { "gligen_name": { "name": "gligen_name" } } };
const GLIGENTextBoxApply = { "display_name": "GLIGENTextBoxApply", "inputs": { "clip": { "name": "clip" }, "conditioning_to": { "name": "conditioning_to" }, "gligen_textbox_model": { "name": "gligen_textbox_model" }, "height": { "name": "高度" }, "text": { "name": "文字" }, "width": { "name": "寬度" }, "x": { "name": "X 座標" }, "y": { "name": "Y 座標" } } };
const GeminiImageNode = { "description": "透過 Google API 同步編輯影像。", "display_name": "Google Gemini 影像", "inputs": { "aspect_ratio": { "name": "長寬比", "tooltip": "預設將輸出影像大小與輸入影像匹配，否則生成 1:1 正方形。" }, "control_after_generate": { "name": "生成後控制" }, "files": { "name": "檔案", "tooltip": "可選的檔案，用作模型的上下文。接受來自 Gemini 生成內容輸入檔案節點的輸入。" }, "images": { "name": "影像", "tooltip": "可選的影像，用作模型的上下文。要包含多個影像，可以使用批次影像節點。" }, "model": { "name": "模型", "tooltip": "用於生成回應的 Gemini 模型。" }, "prompt": { "name": "提示詞", "tooltip": "生成的文字提示詞" }, "seed": { "name": "種子值", "tooltip": "當種子值固定為特定值時，模型會盡力為重複請求提供相同的回應。不保證輸出具有確定性。此外，更改模型或參數設置（例如溫度）即使使用相同的種子值也可能導致回應發生變化。預設情況下，使用隨機種子值。" } }, "outputs": { "0": { "tooltip": null }, "1": { "tooltip": null } } };
const GeminiInputFiles = { "description": "載入並準備輸入檔案，以作為 Gemini LLM 節點的輸入。生成回應時，Gemini 模型將讀取這些檔案。文字檔案的內容會計入令牌限制。🛈 提示：可以與其他 Gemini 輸入檔案節點鏈接在一起。", "display_name": "Gemini 輸入檔案", "inputs": { "GEMINI_INPUT_FILES": { "name": "GEMINI_INPUT_FILES", "tooltip": "可選的附加檔案，可與此節點載入的檔案批次處理。允許串接輸入檔案，使單一訊息可包含多個輸入檔案。" }, "file": { "name": "檔案", "tooltip": "要作為模型上下文包含的輸入檔案。目前僅接受文字 (.txt) 和 PDF (.pdf) 檔案。" } }, "outputs": { "0": { "tooltip": null } } };
const GeminiNode = { "description": "使用 Google 的 Gemini AI 模型生成文字回應。您可以提供多種類型的輸入（文字、圖片、音訊、影片）作為上下文，以生成更相關且有意義的回應。", "display_name": "Google Gemini", "inputs": { "audio": { "name": "音訊", "tooltip": "可選的音訊，用作模型的上下文。" }, "control_after_generate": { "name": "生成後控制" }, "files": { "name": "檔案", "tooltip": "可選的檔案，用作模型的上下文。接受來自 Gemini 生成內容輸入檔案節點的輸入。" }, "images": { "name": "圖片", "tooltip": "可選的圖片，用作模型的上下文。要包含多張圖片，可使用批次圖片節點。" }, "model": { "name": "模型", "tooltip": "用於生成回應的 Gemini 模型。" }, "prompt": { "name": "提示詞", "tooltip": "模型的文字輸入，用於生成回應。您可以包含詳細指令、問題或模型上下文。" }, "seed": { "name": "種子值", "tooltip": "當種子值固定為特定值時，模型會盡力為重複請求提供相同回應。不保證輸出具有確定性。此外，更改模型或參數設定（例如溫度）可能導致回應變化，即使使用相同的種子值。預設使用隨機種子值。" }, "video": { "name": "影片", "tooltip": "可選的影片，用作模型的上下文。" } }, "outputs": { "0": { "tooltip": null } } };
const GetImageSize = { "description": "回傳圖片的寬度和高度，並保持原樣傳遞。", "display_name": "取得圖片尺寸", "inputs": { "image": { "name": "圖片" } }, "outputs": { "0": { "name": "寬度" }, "1": { "name": "高度" }, "2": { "name": "批次大小" } } };
const GetVideoComponents = { "description": "從影片中提取所有元件：影格、音訊與影格率。", "display_name": "取得影片元件", "inputs": { "video": { "name": "影片", "tooltip": "要提取元件的影片。" } }, "outputs": { "0": { "name": "影像", "tooltip": null }, "1": { "name": "音訊", "tooltip": null }, "2": { "name": "每秒影格數", "tooltip": null } } };
const GrowMask = { "display_name": "GrowMask", "inputs": { "expand": { "name": "擴展" }, "mask": { "name": "遮罩" }, "tapered_corners": { "name": "圓角" } } };
const Hunyuan3Dv2Conditioning = { "display_name": "Hunyuan3Dv2Conditioning", "inputs": { "clip_vision_output": { "name": "clip_vision_output" } }, "outputs": { "0": { "name": "正向" }, "1": { "name": "負向" } } };
const Hunyuan3Dv2ConditioningMultiView = { "display_name": "Hunyuan3Dv2ConditioningMultiView", "inputs": { "back": { "name": "後視圖" }, "front": { "name": "前視圖" }, "left": { "name": "左視圖" }, "right": { "name": "右視圖" } }, "outputs": { "0": { "name": "正向" }, "1": { "name": "負向" } } };
const HunyuanImageToVideo = { "display_name": "HunyuanImageToVideo", "inputs": { "batch_size": { "name": "批次大小" }, "guidance_type": { "name": "引導類型" }, "height": { "name": "高度" }, "length": { "name": "長度" }, "positive": { "name": "正向" }, "start_image": { "name": "起始影像" }, "vae": { "name": "vae" }, "width": { "name": "寬度" } }, "outputs": { "0": { "name": "正向", "tooltip": null }, "1": { "name": "潛在空間", "tooltip": null } } };
const HunyuanRefinerLatent = { "display_name": "混元精煉潛空間", "inputs": { "latent": { "name": "潛空間" }, "negative": { "name": "負向提示" }, "noise_augmentation": { "name": "雜訊增強" }, "positive": { "name": "正向提示" } }, "outputs": { "0": { "name": "正向提示", "tooltip": null }, "1": { "name": "負向提示", "tooltip": null }, "2": { "name": "潛空間", "tooltip": null } } };
const HyperTile = { "display_name": "HyperTile", "inputs": { "max_depth": { "name": "最大深度" }, "model": { "name": "model" }, "scale_depth": { "name": "縮放深度" }, "swap_size": { "name": "交換區大小" }, "tile_size": { "name": "切片尺寸" } }, "outputs": { "0": { "tooltip": null } } };
const HypernetworkLoader = { "display_name": "HypernetworkLoader", "inputs": { "hypernetwork_name": { "name": "hypernetwork_name" }, "model": { "name": "model" }, "strength": { "name": "強度" } }, "outputs": { "0": { "tooltip": null } } };
const IdeogramV1 = { "description": "使用 Ideogram V1 模型同步產生影像。\n\n影像連結僅限時有效；如需保留影像，請務必下載。", "display_name": "Ideogram V1", "inputs": { "aspect_ratio": { "name": "長寬比", "tooltip": "影像生成的長寬比。" }, "control_after_generate": { "name": "生成後控制" }, "magic_prompt_option": { "name": "MagicPrompt 選項", "tooltip": "決定生成時是否使用 MagicPrompt" }, "negative_prompt": { "name": "排除提示詞", "tooltip": "描述要從影像中排除的內容" }, "num_images": { "name": "影像數量" }, "prompt": { "name": "提示詞", "tooltip": "用於影像生成的提示詞" }, "seed": { "name": "種子值" }, "turbo": { "name": "加速模式", "tooltip": "是否啟用加速模式（生成速度更快，但品質可能較低）" } }, "outputs": { "0": { "tooltip": null } } };
const IdeogramV2 = { "description": "使用 Ideogram V2 模型同步產生影像。\n\n影像連結僅限時有效；若您想保留影像，請務必下載。", "display_name": "Ideogram V2", "inputs": { "aspect_ratio": { "name": "長寬比", "tooltip": "影像生成的長寬比。若解析度未設為自動，則此設定會被忽略。" }, "control_after_generate": { "name": "生成後控制" }, "magic_prompt_option": { "name": "MagicPrompt 選項", "tooltip": "決定生成時是否使用 MagicPrompt" }, "negative_prompt": { "name": "排除提示詞", "tooltip": "描述影像中要排除的內容" }, "num_images": { "name": "影像數量" }, "prompt": { "name": "提示詞", "tooltip": "用於影像生成的提示詞" }, "resolution": { "name": "解析度", "tooltip": "影像生成的解析度。若未設為自動，將覆蓋長寬比設定。" }, "seed": { "name": "種子值" }, "style_type": { "name": "風格類型", "tooltip": "生成時的風格類型（僅限 V2）" }, "turbo": { "name": "加速模式", "tooltip": "是否啟用加速模式（生成速度更快，但品質可能較低）" } }, "outputs": { "0": { "tooltip": null } } };
const IdeogramV3 = { "description": "使用 Ideogram V3 模型同步產生影像。\n\n支援從文字提示產生一般影像，以及結合 mask 進行影像編輯。\n影像連結僅限時有效；如需保留影像，請務必下載。", "display_name": "Ideogram V3", "inputs": { "aspect_ratio": { "name": "長寬比", "tooltip": "影像生成的長寬比。若解析度未設為自動，則此設定會被忽略。" }, "character_image": { "name": "角色圖片", "tooltip": "用作角色參考的圖片。" }, "character_mask": { "name": "角色遮罩", "tooltip": "角色參考圖片的可選遮罩。" }, "control_after_generate": { "name": "生成後控制" }, "image": { "name": "參考影像", "tooltip": "（選填）用於影像編輯的參考圖片。" }, "magic_prompt_option": { "name": "MagicPrompt 選項", "tooltip": "決定是否在生成時使用 MagicPrompt" }, "mask": { "name": "遮罩", "tooltip": "（選填）用於修補的遮罩（白色區域將被取代）" }, "num_images": { "name": "影像數量" }, "prompt": { "name": "提示詞", "tooltip": "用於影像生成或編輯的提示詞" }, "rendering_speed": { "name": "生成速度", "tooltip": "控制生成速度與品質的取捨" }, "resolution": { "name": "解析度", "tooltip": "影像生成的解析度。若未設為自動，將覆蓋長寬比設定。" }, "seed": { "name": "種子值" } }, "outputs": { "0": { "tooltip": null } } };
const ImageAddNoise = { "display_name": "圖片添加雜訊", "inputs": { "control_after_generate": { "name": "生成後控制" }, "image": { "name": "圖片" }, "seed": { "name": "種子值", "tooltip": "用於創建雜訊的隨機種子值。" }, "strength": { "name": "強度" } } };
const ImageBatch = { "display_name": "批次影像", "inputs": { "image1": { "name": "image1" }, "image2": { "name": "image2" } } };
const ImageBlend = { "display_name": "影像混合", "inputs": { "blend_factor": { "name": "混合係數" }, "blend_mode": { "name": "混合模式" }, "image1": { "name": "image1" }, "image2": { "name": "image2" } }, "outputs": { "0": { "tooltip": null } } };
const ImageBlur = { "display_name": "影像模糊", "inputs": { "blur_radius": { "name": "模糊半徑" }, "image": { "name": "影像" }, "sigma": { "name": "標準差" } }, "outputs": { "0": { "tooltip": null } } };
const ImageColorToMask = { "display_name": "顏色轉遮罩", "inputs": { "color": { "name": "顏色" }, "image": { "name": "圖片" } } };
const ImageCompositeMasked = { "display_name": "影像合成（遮罩）", "inputs": { "destination": { "name": "目標圖像" }, "mask": { "name": "遮罩" }, "resize_source": { "name": "調整來源大小" }, "source": { "name": "來源圖像" }, "x": { "name": "X 座標" }, "y": { "name": "Y 座標" } } };
const ImageCrop = { "display_name": "圖片裁切", "inputs": { "height": { "name": "高度" }, "image": { "name": "影像" }, "width": { "name": "寬度" }, "x": { "name": "X 座標" }, "y": { "name": "Y 座標" } } };
const ImageFlip = { "display_name": "影像翻轉", "inputs": { "flip_method": { "name": "翻轉方式" }, "image": { "name": "影像" } } };
const ImageFromBatch = { "display_name": "從批次擷取影像", "inputs": { "batch_index": { "name": "批次索引" }, "image": { "name": "影像" }, "length": { "name": "長度" } } };
const ImageInvert = { "display_name": "反轉影像", "inputs": { "image": { "name": "影像" } } };
const ImageOnlyCheckpointLoader = { "display_name": "僅影像權重載入器（img2vid 模型）", "inputs": { "ckpt_name": { "name": "ckpt_name" } } };
const ImageOnlyCheckpointSave = { "display_name": "儲存僅影像檢查點", "inputs": { "clip_vision": { "name": "clip_vision" }, "filename_prefix": { "name": "檔名前綴" }, "model": { "name": "model" }, "vae": { "name": "vae" } } };
const ImagePadForOutpaint = { "display_name": "為外繪填充圖片", "inputs": { "bottom": { "name": "下邊" }, "feathering": { "name": "羽化" }, "image": { "name": "影像" }, "left": { "name": "左邊" }, "right": { "name": "右邊" }, "top": { "name": "上邊" } } };
const ImageQuantize = { "display_name": "影像量化", "inputs": { "colors": { "name": "顏色數" }, "dither": { "name": "抖動" }, "image": { "name": "影像" } }, "outputs": { "0": { "tooltip": null } } };
const ImageRGBToYUV = { "display_name": "RGB 轉 YUV", "inputs": { "image": { "name": "影像" } }, "outputs": { "0": { "name": "Y", "tooltip": null }, "1": { "name": "U", "tooltip": null }, "2": { "name": "V", "tooltip": null } } };
const ImageRotate = { "display_name": "影像旋轉", "inputs": { "image": { "name": "影像" }, "rotation": { "name": "旋轉" } } };
const ImageScale = { "display_name": "放大圖片", "inputs": { "crop": { "name": "裁切" }, "height": { "name": "高度" }, "image": { "name": "影像" }, "upscale_method": { "name": "放大方法" }, "width": { "name": "寬度" } } };
const ImageScaleBy = { "display_name": "放大圖片倍率", "inputs": { "image": { "name": "影像" }, "scale_by": { "name": "縮放倍數" }, "upscale_method": { "name": "放大方法" } } };
const ImageScaleToMaxDimension = { "display_name": "影像縮放至最大尺寸", "inputs": { "image": { "name": "影像" }, "largest_size": { "name": "最大尺寸" }, "upscale_method": { "name": "放大方法" } } };
const ImageScaleToTotalPixels = { "display_name": "將影像縮放至總像素數", "inputs": { "image": { "name": "影像" }, "megapixels": { "name": "百萬像素" }, "upscale_method": { "name": "放大方法" } }, "outputs": { "0": { "tooltip": null } } };
const ImageSharpen = { "display_name": "影像銳化", "inputs": { "alpha": { "name": "透明度" }, "image": { "name": "影像" }, "sharpen_radius": { "name": "銳化半徑" }, "sigma": { "name": "西格瑪" } }, "outputs": { "0": { "tooltip": null } } };
const ImageStitch = { "description": "\n將 image2 以指定方向拼接至 image1。\n若未提供 image2，則返回未變更的 image1。\n可在影像之間添加可選間距。\n", "display_name": "影像拼接", "inputs": { "direction": { "name": "方向" }, "image1": { "name": "影像1" }, "image2": { "name": "影像2" }, "match_image_size": { "name": "匹配影像尺寸" }, "spacing_color": { "name": "間距顏色" }, "spacing_width": { "name": "間距寬度" } } };
const ImageToMask = { "display_name": "將圖片轉換為遮罩", "inputs": { "channel": { "name": "通道" }, "image": { "name": "圖片" } } };
const ImageUpscaleWithModel = { "display_name": "圖片放大（使用模型）", "inputs": { "image": { "name": "影像" }, "upscale_model": { "name": "放大模型" } }, "outputs": { "0": { "tooltip": null } } };
const ImageYUVToRGB = { "display_name": "YUV 轉 RGB", "inputs": { "U": { "name": "U" }, "V": { "name": "V" }, "Y": { "name": "Y" } }, "outputs": { "0": { "tooltip": null } } };
const InpaintModelConditioning = { "display_name": "修補模型條件設定", "inputs": { "mask": { "name": "遮罩" }, "negative": { "name": "負向" }, "noise_mask": { "name": "雜訊遮罩", "tooltip": "在潛在空間上加入雜訊遮罩，這樣取樣只會發生在遮罩範圍內。根據模型不同，可能會改善結果，也可能完全失效。" }, "pixels": { "name": "像素" }, "positive": { "name": "正向" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "正向" }, "1": { "name": "負向" }, "2": { "name": "潛在空間" } } };
const InstructPixToPixConditioning = { "display_name": "指令式像素轉像素條件設定", "inputs": { "negative": { "name": "負向" }, "pixels": { "name": "像素" }, "positive": { "name": "正向" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "正向", "tooltip": null }, "1": { "name": "負向", "tooltip": null }, "2": { "name": "潛在空間", "tooltip": null } } };
const InvertMask = { "display_name": "反轉遮罩", "inputs": { "mask": { "name": "遮罩" } } };
const JoinImageWithAlpha = { "display_name": "合併影像與 Alpha", "inputs": { "alpha": { "name": "Alpha" }, "image": { "name": "影像" } }, "outputs": { "0": { "tooltip": null } } };
const KSampler = { "description": "使用提供的模型，以及正向與負向條件來去除潛在空間影像中的雜訊。", "display_name": "KSampler", "inputs": { "cfg": { "name": "cfg", "tooltip": "Classifier-Free Guidance（CFG）比例可平衡創意與提示的貼合度。數值越高，生成的圖片越貼近提示，但過高可能會影響品質。" }, "control_after_generate": { "name": "生成後控制" }, "denoise": { "name": "去雜訊強度", "tooltip": "應用的去噪程度，數值較低時會保留初始影像的結構，適合影像轉影像取樣。" }, "latent_image": { "name": "潛在空間影像", "tooltip": "要去噪的潛在空間影像。" }, "model": { "name": "模型", "tooltip": "用於去除輸入潛在空間雜訊的模型。" }, "negative": { "name": "負向條件", "tooltip": "描述你希望在影像中排除的屬性的條件。" }, "positive": { "name": "正向條件", "tooltip": "描述你希望在影像中包含的屬性的條件。" }, "sampler_name": { "name": "取樣器", "tooltip": "取樣時所使用的演算法，會影響生成結果的品質、速度與風格。" }, "scheduler": { "name": "排程器", "tooltip": "排程器控制雜訊如何逐步移除以形成影像。" }, "seed": { "name": "種子", "tooltip": "用於產生雜訊的隨機種子。" }, "steps": { "name": "步驟數", "tooltip": "去噪過程中所使用的步數。" } }, "outputs": { "0": { "tooltip": "去噪後的潛在空間。" } } };
const KSamplerAdvanced = { "display_name": "KSampler（進階）", "inputs": { "add_noise": { "name": "加入雜訊" }, "cfg": { "name": "cfg" }, "control_after_generate": { "name": "生成後控制" }, "end_at_step": { "name": "結束步數" }, "latent_image": { "name": "潛在空間影像" }, "model": { "name": "模型" }, "negative": { "name": "負向" }, "noise_seed": { "name": "雜訊種子" }, "positive": { "name": "正向" }, "return_with_leftover_noise": { "name": "保留剩餘雜訊" }, "sampler_name": { "name": "取樣器名稱" }, "scheduler": { "name": "排程器" }, "start_at_step": { "name": "起始步數" }, "steps": { "name": "步驟數" } } };
const KSamplerSelect = { "display_name": "K採樣器選擇", "inputs": { "sampler_name": { "name": "取樣器名稱" } } };
const KarrasScheduler = { "display_name": "Karras 排程器", "inputs": { "rho": { "name": "rho" }, "sigma_max": { "name": "最大 sigma" }, "sigma_min": { "name": "最小 sigma" }, "steps": { "name": "步驟數" } } };
const KlingCameraControlI2VNode = { "description": "將靜態圖片轉換為具有專業攝影機運鏡的電影感影片。可模擬真實世界的攝影效果，並控制虛擬攝影機的動作，包括縮放、旋轉、平移、傾斜及第一人稱視角，同時保持對原始圖片的聚焦。", "display_name": "Kling 靜態圖轉影片（攝影機控制）", "inputs": { "aspect_ratio": { "name": "aspect_ratio" }, "camera_control": { "name": "camera_control", "tooltip": "可透過 Kling Camera Controls 節點建立。控制影片生成時的攝影機運動與動作。" }, "cfg_scale": { "name": "cfg_scale" }, "negative_prompt": { "name": "負向提示詞", "tooltip": "負向文字提示" }, "prompt": { "name": "prompt", "tooltip": "正向文字提示" }, "start_frame": { "name": "start_frame", "tooltip": "參考圖片 - 輸入 URL 或 Base64 編碼字串，檔案大小不得超過 10MB，解析度不得低於 300*300 像素，長寬比需介於 1:2.5 ~ 2.5:1。Base64 不需包含 data:image 前綴。" } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "video_id", "tooltip": null }, "2": { "name": "時長", "tooltip": null } } };
const KlingCameraControlT2VNode = { "description": "將文字轉換為具備專業攝影機運鏡的電影級影片，模擬真實世界的攝影效果。可控制虛擬攝影機的動作，包括縮放、旋轉、平移、傾斜及第一人稱視角，同時保持對原始文字的聚焦。", "display_name": "Kling 文字轉影片（攝影機控制）", "inputs": { "aspect_ratio": { "name": "aspect_ratio" }, "camera_control": { "name": "camera_control", "tooltip": "可透過 Kling Camera Controls 節點建立。控制影片生成時的攝影機運動與動作。" }, "cfg_scale": { "name": "cfg_scale" }, "negative_prompt": { "name": "負向提示詞", "tooltip": "負向文字提示" }, "prompt": { "name": "prompt", "tooltip": "正向文字提示" } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "video_id", "tooltip": null }, "2": { "name": "時長", "tooltip": null } } };
const KlingCameraControls = { "description": "允許指定 Kling 攝影機控制與動作控制效果的設定選項。", "display_name": "Kling 攝影機控制", "inputs": { "camera_control_type": { "name": "camera_control_type" }, "horizontal_movement": { "name": "horizontal_movement", "tooltip": "控制攝影機在水平軸（x 軸）上的移動。負值表示向左，正值表示向右。" }, "pan": { "name": "pan", "tooltip": "控制攝影機在垂直平面（x 軸）上的旋轉。負值表示向下旋轉，正值表示向上旋轉。" }, "roll": { "name": "roll", "tooltip": "控制攝影機在 z 軸上的滾動量。負值表示逆時針，正值表示順時針。" }, "tilt": { "name": "tilt", "tooltip": "控制攝影機在水平平面（y 軸）上的旋轉。負值表示向左旋轉，正值表示向右旋轉。" }, "vertical_movement": { "name": "vertical_movement", "tooltip": "控制攝影機在垂直軸（y 軸）上的移動。負值表示向下，正值表示向上。" }, "zoom": { "name": "zoom", "tooltip": "控制攝影機焦距的變化。負值表示視野較窄，正值表示視野較寬。" } }, "outputs": { "0": { "name": "camera_control", "tooltip": null } } };
const KlingDualCharacterVideoEffectNode = { "description": "根據 effect_scene 產生影片時，實現不同的特效。第一張圖片會放在合成畫面的左側，第二張圖片會放在右側。", "display_name": "Kling 雙角色影片特效", "inputs": { "duration": { "name": "時長" }, "effect_scene": { "name": "effect_scene" }, "image_left": { "name": "image_left", "tooltip": "左側圖片" }, "image_right": { "name": "image_right", "tooltip": "右側圖片" }, "mode": { "name": "mode" }, "model_name": { "name": "model_name" } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "時長", "tooltip": null } } };
const KlingImage2VideoNode = { "display_name": "Kling 圖像轉影片", "inputs": { "aspect_ratio": { "name": "aspect_ratio" }, "cfg_scale": { "name": "cfg_scale" }, "duration": { "name": "時長" }, "mode": { "name": "mode" }, "model_name": { "name": "model_name" }, "negative_prompt": { "name": "負向提示詞", "tooltip": "負向文字提示" }, "prompt": { "name": "prompt", "tooltip": "正向文字提示" }, "start_frame": { "name": "start_frame", "tooltip": "參考圖片 - URL 或 Base64 編碼字串，檔案大小不可超過 10MB，解析度不得低於 300*300 像素，長寬比需介於 1:2.5 ~ 2.5:1。Base64 不需包含 data:image 前綴。" } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "video_id", "tooltip": null }, "2": { "name": "時長", "tooltip": null } } };
const KlingImageGenerationNode = { "description": "Kling 圖像生成節點。根據文字提示生成圖像，可選擇性加入參考圖像。", "display_name": "Kling 圖像生成", "inputs": { "aspect_ratio": { "name": "aspect_ratio" }, "human_fidelity": { "name": "human_fidelity", "tooltip": "主體參考相似度" }, "image": { "name": "影像" }, "image_fidelity": { "name": "image_fidelity", "tooltip": "用戶上傳圖像的參考強度" }, "image_type": { "name": "image_type" }, "model_name": { "name": "model_name" }, "n": { "name": "n", "tooltip": "生成圖像數量" }, "negative_prompt": { "name": "負向提示詞", "tooltip": "負向文字提示" }, "prompt": { "name": "prompt", "tooltip": "正向文字提示" } }, "outputs": { "0": { "tooltip": null } } };
const KlingLipSyncAudioToVideoNode = { "description": "Kling 影音口型同步節點。將影片檔案中的嘴型動作與音訊檔案的語音內容同步。", "display_name": "Kling 影音口型同步", "inputs": { "audio": { "name": "音訊" }, "video": { "name": "影片" }, "voice_language": { "name": "語音語言" } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "影片 ID", "tooltip": null }, "2": { "name": "時長", "tooltip": null } } };
const KlingLipSyncTextToVideoNode = { "description": "Kling 文字口型同步節點。將影片中的嘴型動作與文字提示同步。", "display_name": "Kling 文字口型同步影片", "inputs": { "text": { "name": "文字", "tooltip": "用於口型同步影片生成的文字內容。當模式為 text2video 時必填。最長 120 字。" }, "video": { "name": "影片" }, "voice": { "name": "語音" }, "voice_speed": { "name": "語速", "tooltip": "語音速度。有效範圍：0.8~2.0，精確到小數點一位。" } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "影片 ID", "tooltip": null }, "2": { "name": "時長", "tooltip": null } } };
const KlingSingleImageVideoEffectNode = { "description": "根據 effect_scene 產生影片時，實現不同的特殊效果。", "display_name": "Kling 影片特效", "inputs": { "duration": { "name": "時長" }, "effect_scene": { "name": "effect_scene" }, "image": { "name": "影像", "tooltip": "參考圖片。可為 URL 或 Base64 編碼字串（不含 data:image 前綴）。檔案大小不得超過 10MB，解析度不得低於 300*300 像素，長寬比需介於 1:2.5 ~ 2.5:1 之間" }, "model_name": { "name": "model_name" } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "video_id", "tooltip": null }, "2": { "name": "時長", "tooltip": null } } };
const KlingStartEndFrameNode = { "description": "根據您提供的起始與結束影像，產生一段影像序列。此節點會自動生成中間所有影格，讓第一張影像平滑轉換到最後一張影像。", "display_name": "Kling 起始-結束影格轉影片", "inputs": { "aspect_ratio": { "name": "aspect_ratio" }, "cfg_scale": { "name": "cfg_scale" }, "end_frame": { "name": "end_frame", "tooltip": "參考影像 - 結束影格控制。輸入 URL 或 Base64 編碼字串，檔案大小不得超過 10MB，解析度不得低於 300*300 像素。Base64 不需包含 data:image 前綴。" }, "mode": { "name": "mode", "tooltip": "用於影片生成的設定，格式為：mode / duration / model_name。" }, "negative_prompt": { "name": "負向提示詞", "tooltip": "負向文字提示" }, "prompt": { "name": "prompt", "tooltip": "正向文字提示" }, "start_frame": { "name": "start_frame", "tooltip": "參考影像 - 輸入 URL 或 Base64 編碼字串，檔案大小不得超過 10MB，解析度不得低於 300*300 像素，長寬比需介於 1:2.5 ~ 2.5:1。Base64 不需包含 data:image 前綴。" } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "video_id", "tooltip": null }, "2": { "name": "時長", "tooltip": null } } };
const KlingTextToVideoNode = { "description": "Kling 文字轉影片節點", "display_name": "Kling 文字轉影片", "inputs": { "aspect_ratio": { "name": "aspect_ratio" }, "cfg_scale": { "name": "cfg_scale" }, "mode": { "name": "mode", "tooltip": "用於影片生成的設定，格式為：mode / duration / model_name。" }, "negative_prompt": { "name": "負向提示詞", "tooltip": "負向文字提示" }, "prompt": { "name": "prompt", "tooltip": "正向文字提示" } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "video_id", "tooltip": null }, "2": { "name": "時長", "tooltip": null } } };
const KlingVideoExtendNode = { "description": "Kling Video 延伸節點。可延伸由其他 Kling 節點製作的影片。video_id 是透過其他 Kling 節點產生的。", "display_name": "Kling Video 延伸", "inputs": { "cfg_scale": { "name": "cfg_scale" }, "negative_prompt": { "name": "負向提示詞", "tooltip": "用於避免在延伸影片中出現的負向文字提示" }, "prompt": { "name": "prompt", "tooltip": "用於引導影片延伸的正向文字提示" }, "video_id": { "name": "video_id", "tooltip": "要延伸的影片 ID。支援由文字轉影片、圖片轉影片及先前影片延伸操作所產生的影片。延伸後總長度不可超過 3 分鐘。" } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "video_id", "tooltip": null }, "2": { "name": "時長", "tooltip": null } } };
const KlingVirtualTryOnNode = { "description": "Kling 虛擬試穿節點。輸入一張人物圖片和一張服裝圖片，將服裝試穿在人物身上。", "display_name": "Kling 虛擬試穿", "inputs": { "cloth_image": { "name": "cloth_image" }, "human_image": { "name": "human_image" }, "model_name": { "name": "model_name" } }, "outputs": { "0": { "tooltip": null } } };
const LTXVAddGuide = { "display_name": "LTXV 添加引導", "inputs": { "frame_idx": { "name": "起始幀索引", "tooltip": "開始條件化的幀索引。對於單幀影像或 1-8 幀的影片，任何 frame_idx 值皆可。對於 9 幀以上的影片，frame_idx 必須能被 8 整除，否則會自動向下取至最接近的 8 的倍數。負值則從影片結尾倒數計算。" }, "image": { "name": "影像", "tooltip": "用於條件化 latent 視訊的影像或影片。必須為 8*n + 1 幀。如果影片不是 8*n + 1 幀，將會裁切至最接近的 8*n + 1 幀。" }, "latent": { "name": "潛在空間" }, "negative": { "name": "負向" }, "positive": { "name": "正向" }, "strength": { "name": "強度" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "正向", "tooltip": null }, "1": { "name": "負向", "tooltip": null }, "2": { "name": "潛在空間", "tooltip": null } } };
const LTXVConditioning = { "display_name": "LTXV 條件化", "inputs": { "frame_rate": { "name": "影格率" }, "negative": { "name": "負向" }, "positive": { "name": "正向" } }, "outputs": { "0": { "name": "正向", "tooltip": null }, "1": { "name": "負向", "tooltip": null } } };
const LTXVCropGuides = { "display_name": "LTXV 裁剪引導", "inputs": { "latent": { "name": "潛在空間" }, "negative": { "name": "負向" }, "positive": { "name": "正向" } }, "outputs": { "0": { "name": "正向", "tooltip": null }, "1": { "name": "負向", "tooltip": null }, "2": { "name": "潛在空間", "tooltip": null } } };
const LTXVImgToVideo = { "display_name": "LTXV 圖片轉影片", "inputs": { "batch_size": { "name": "批次大小" }, "height": { "name": "高度" }, "image": { "name": "影像" }, "length": { "name": "長度" }, "negative": { "name": "負向" }, "positive": { "name": "正向" }, "strength": { "name": "強度" }, "vae": { "name": "vae" }, "width": { "name": "寬度" } }, "outputs": { "0": { "name": "正向", "tooltip": null }, "1": { "name": "負向", "tooltip": null }, "2": { "name": "潛在空間", "tooltip": null } } };
const LTXVPreprocess = { "display_name": "LTXV 預處理", "inputs": { "image": { "name": "影像" }, "img_compression": { "name": "img_compression", "tooltip": "對影像施加的壓縮程度。" } }, "outputs": { "0": { "name": "output_image", "tooltip": null } } };
const LTXVScheduler = { "display_name": "LTXV 排程器", "inputs": { "base_shift": { "name": "基礎偏移" }, "latent": { "name": "潛在空間" }, "max_shift": { "name": "最大偏移" }, "steps": { "name": "步驟數" }, "stretch": { "name": "拉伸", "tooltip": "將 sigma 拉伸至 [terminal, 1] 的範圍內。" }, "terminal": { "name": "終值", "tooltip": "拉伸後 sigma 的終值。" } }, "outputs": { "0": { "tooltip": null } } };
const LaplaceScheduler = { "display_name": "Laplace 排程器", "inputs": { "beta": { "name": "beta" }, "mu": { "name": "mu" }, "sigma_max": { "name": "最大 sigma" }, "sigma_min": { "name": "最小 sigma" }, "steps": { "name": "步驟數" } } };
const LatentAdd = { "display_name": "潛空間相加", "inputs": { "samples1": { "name": "samples1" }, "samples2": { "name": "samples2" } }, "outputs": { "0": { "tooltip": null } } };
const LatentApplyOperation = { "display_name": "潛空間應用操作", "inputs": { "operation": { "name": "操作" }, "samples": { "name": "樣本" } }, "outputs": { "0": { "tooltip": null } } };
const LatentApplyOperationCFG = { "display_name": "潛空間應用操作 CFG", "inputs": { "model": { "name": "model" }, "operation": { "name": "operation" } }, "outputs": { "0": { "tooltip": null } } };
const LatentBatch = { "display_name": "潛空間批次", "inputs": { "samples1": { "name": "samples1" }, "samples2": { "name": "samples2" } }, "outputs": { "0": { "tooltip": null } } };
const LatentBatchSeedBehavior = { "display_name": "潛空間批次種子行為", "inputs": { "samples": { "name": "樣本" }, "seed_behavior": { "name": "種子行為" } }, "outputs": { "0": { "tooltip": null } } };
const LatentBlend = { "display_name": "Latent 混合", "inputs": { "blend_factor": { "name": "混合係數" }, "samples1": { "name": "samples1" }, "samples2": { "name": "samples2" } } };
const LatentComposite = { "display_name": "潛在合成", "inputs": { "feather": { "name": "羽化" }, "samples_from": { "name": "來源樣本" }, "samples_to": { "name": "目標樣本" }, "x": { "name": "X 座標" }, "y": { "name": "Y 座標" } } };
const LatentCompositeMasked = { "display_name": "潛空間遮罩合成", "inputs": { "destination": { "name": "destination" }, "mask": { "name": "遮罩" }, "resize_source": { "name": "調整來源大小" }, "source": { "name": "source" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const LatentConcat = { "display_name": "潛空間合併", "inputs": { "dim": { "name": "維度" }, "samples1": { "name": "樣本1" }, "samples2": { "name": "樣本2" } }, "outputs": { "0": { "tooltip": null } } };
const LatentCrop = { "display_name": "裁剪 Latent", "inputs": { "height": { "name": "高度" }, "samples": { "name": "樣本" }, "width": { "name": "寬度" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const LatentCut = { "display_name": "潛空間切割", "inputs": { "amount": { "name": "數量" }, "dim": { "name": "維度" }, "index": { "name": "索引" }, "samples": { "name": "樣本" } }, "outputs": { "0": { "tooltip": null } } };
const LatentFlip = { "display_name": "翻轉 Latent", "inputs": { "flip_method": { "name": "翻轉方法" }, "samples": { "name": "樣本" } } };
const LatentFromBatch = { "display_name": "從批次取得 Latent", "inputs": { "batch_index": { "name": "批次索引" }, "length": { "name": "長度" }, "samples": { "name": "樣本" } } };
const LatentInterpolate = { "display_name": "潛空間插值", "inputs": { "ratio": { "name": "比例" }, "samples1": { "name": "samples1" }, "samples2": { "name": "samples2" } }, "outputs": { "0": { "tooltip": null } } };
const LatentMultiply = { "display_name": "潛空間相乘", "inputs": { "multiplier": { "name": "乘數" }, "samples": { "name": "樣本" } }, "outputs": { "0": { "tooltip": null } } };
const LatentOperationSharpen = { "display_name": "潛空間銳化操作", "inputs": { "alpha": { "name": "alpha" }, "sharpen_radius": { "name": "sharpen_radius" }, "sigma": { "name": "sigma" } }, "outputs": { "0": { "tooltip": null } } };
const LatentOperationTonemapReinhard = { "display_name": "潛空間 Reinhard 色調映射", "inputs": { "multiplier": { "name": "乘數" } }, "outputs": { "0": { "tooltip": null } } };
const LatentRotate = { "display_name": "旋轉 latent", "inputs": { "rotation": { "name": "旋轉角度" }, "samples": { "name": "樣本" } } };
const LatentSubtract = { "display_name": "潛空間相減", "inputs": { "samples1": { "name": "samples1" }, "samples2": { "name": "samples2" } }, "outputs": { "0": { "tooltip": null } } };
const LatentUpscale = { "display_name": "放大 latent", "inputs": { "crop": { "name": "裁切" }, "height": { "name": "高度" }, "samples": { "name": "樣本" }, "upscale_method": { "name": "放大方法" }, "width": { "name": "寬度" } } };
const LatentUpscaleBy = { "display_name": "放大 latent 空間", "inputs": { "samples": { "name": "樣本" }, "scale_by": { "name": "放大倍率" }, "upscale_method": { "name": "放大方法" } } };
const LazyCache = { "description": "自製版 EasyCache - 更「簡單」的 EasyCache 實作版本。整體表現不如 EasyCache，但在某些罕見情況下表現更好，且與 ComfyUI 中的所有內容具有通用相容性。", "display_name": "懶快取", "inputs": { "end_percent": { "name": "結束百分比", "tooltip": "結束使用懶快取的相對採樣步驟。" }, "model": { "name": "模型", "tooltip": "要添加懶快取的模型。" }, "reuse_threshold": { "name": "重複使用閾值", "tooltip": "重複使用快取步驟的閾值。" }, "start_percent": { "name": "起始百分比", "tooltip": "開始使用懶快取的相對採樣步驟。" }, "verbose": { "name": "詳細模式", "tooltip": "是否記錄詳細資訊。" } }, "outputs": { "0": { "tooltip": "帶有懶快取的模型。" } } };
const Load3D = { "display_name": "載入 3D", "inputs": { "clear": {}, "height": { "name": "高度" }, "image": { "name": "影像" }, "model_file": { "name": "模型檔案" }, "upload 3d model": {}, "width": { "name": "寬度" } }, "outputs": { "0": { "name": "圖片" }, "1": { "name": "遮罩" }, "2": { "name": "網格路徑" }, "3": { "name": "法線" }, "4": { "name": "線稿" }, "5": { "name": "相機資訊" } } };
const LoadAudio = { "display_name": "載入音訊", "inputs": { "audio": { "name": "音訊" }, "audioUI": { "name": "音訊介面" }, "upload": { "name": "選擇檔案上傳" } } };
const LoadImage = { "display_name": "載入圖片", "inputs": { "image": { "name": "影像" }, "upload": { "name": "選擇要上傳的檔案" } } };
const LoadImageMask = { "display_name": "載入圖片（作為遮罩）", "inputs": { "channel": { "name": "通道" }, "image": { "name": "影像" }, "upload": { "name": "選擇要上傳的檔案" } } };
const LoadImageOutput = { "description": "從輸出資料夾載入圖片。當點擊重新整理按鈕時，節點會更新圖片清單並自動選取第一張圖片，方便進行反覆操作。", "display_name": "載入圖片（來自輸出）", "inputs": { "image": { "name": "影像" }, "refresh": {}, "upload": { "name": "選擇要上傳的檔案" } } };
const LoadLatent = { "display_name": "LoadLatent", "inputs": { "latent": { "name": "潛在空間" } } };
const LoadVideo = { "display_name": "載入影片", "inputs": { "file": { "name": "檔案" }, "upload": { "name": "選擇要上傳的檔案" } }, "outputs": { "0": { "tooltip": null } } };
const LoraLoader = { "description": "LoRA 用於修改 diffusion 和 CLIP 模型，改變 latent 的去噪方式，例如套用風格。多個 LoRA 節點可以串接在一起使用。", "display_name": "載入 LoRA", "inputs": { "clip": { "name": "clip", "tooltip": "LoRA 將套用的 CLIP 模型。" }, "lora_name": { "name": "lora_name", "tooltip": "LoRA 的名稱。" }, "model": { "name": "model", "tooltip": "LoRA 將套用的 diffusion 模型。" }, "strength_clip": { "name": "strength_clip", "tooltip": "調整 CLIP 模型的強度。此值可為負數。" }, "strength_model": { "name": "strength_model", "tooltip": "調整 diffusion 模型的強度。此值可為負數。" } }, "outputs": { "0": { "tooltip": "已修改的 diffusion 模型。" }, "1": { "tooltip": "已修改的 CLIP 模型。" } } };
const LoraLoaderModelOnly = { "description": "LoRA 用於修改 diffusion 和 CLIP 模型，改變 latent 去噪的方式，例如套用風格。多個 LoRA 節點可以串接在一起使用。", "display_name": "LoraLoaderModelOnly", "inputs": { "lora_name": { "name": "lora_name" }, "model": { "name": "model" }, "strength_model": { "name": "strength_model" } }, "outputs": { "0": { "tooltip": "已修改的 diffusion 模型。" } } };
const LoraModelLoader = { "display_name": "載入 LoRA 模型", "inputs": { "lora": { "name": "LoRA 模型", "tooltip": "要應用到擴散模型的 LoRA 模型。" }, "model": { "name": "模型", "tooltip": "LoRA 將應用到的擴散模型。" }, "strength_model": { "name": "模型強度", "tooltip": "修改擴散模型的強度。此值可以為負數。" } }, "outputs": { "0": { "tooltip": "修改後的擴散模型。" } } };
const LoraSave = { "display_name": "提取並儲存Lora", "inputs": { "bias_diff": { "name": "偏差差異" }, "filename_prefix": { "name": "檔名前綴" }, "lora_type": { "name": "lora類型" }, "model_diff": { "name": "模型差異", "tooltip": "要轉換為lora的ModelSubtract輸出。" }, "rank": { "name": "秩(rank)" }, "text_encoder_diff": { "name": "文字編碼器差異", "tooltip": "要轉換為lora的CLIPSubtract輸出。" } } };
const LossGraphNode = { "display_name": "繪製損失圖表", "inputs": { "filename_prefix": { "name": "檔案名稱前綴" }, "loss": { "name": "損失" } } };
const LotusConditioning = { "display_name": "LotusConditioning", "outputs": { "0": { "name": "條件", "tooltip": null } } };
const LtxvApiImageToVideo = { "description": "基於起始圖片，具有可自訂持續時間和解析度的專業級影片。", "display_name": "LTXV 圖片轉影片", "inputs": { "duration": { "name": "持續時間" }, "fps": { "name": "幀率" }, "generate_audio": { "name": "生成音訊", "tooltip": "當為 true 時，生成的影片將包含與場景匹配的 AI 生成音訊。" }, "image": { "name": "圖片", "tooltip": "要用於影片的第一幀。" }, "model": { "name": "模型" }, "prompt": { "name": "提示詞" }, "resolution": { "name": "解析度" } }, "outputs": { "0": { "tooltip": null } } };
const LtxvApiTextToVideo = { "description": "具有可自訂持續時間和解析度的專業級影片。", "display_name": "LTXV 文字轉影片", "inputs": { "duration": { "name": "持續時間" }, "fps": { "name": "幀率" }, "generate_audio": { "name": "生成音訊", "tooltip": "當為 true 時，生成的影片將包含與場景匹配的 AI 生成音訊。" }, "model": { "name": "模型" }, "prompt": { "name": "提示詞" }, "resolution": { "name": "解析度" } }, "outputs": { "0": { "tooltip": null } } };
const LumaConceptsNode = { "description": "包含一個或多個相機概念，可用於 Luma 文字轉影片與 Luma 圖片轉影片節點。", "display_name": "Luma 概念", "inputs": { "concept1": { "name": "concept1" }, "concept2": { "name": "concept2" }, "concept3": { "name": "concept3" }, "concept4": { "name": "concept4" }, "luma_concepts": { "name": "luma_concepts", "tooltip": "可選的相機概念，將會加入到此處選擇的概念中。" } }, "outputs": { "0": { "name": "luma_concepts", "tooltip": null } } };
const LumaImageModifyNode = { "description": "根據提示詞與長寬比同步修改影像。", "display_name": "Luma 影像轉換", "inputs": { "control_after_generate": { "name": "生成後控制" }, "image": { "name": "影像" }, "image_weight": { "name": "影像權重", "tooltip": "影像的權重；越接近 1.0，影像修改幅度越小。" }, "model": { "name": "模型" }, "prompt": { "name": "提示詞", "tooltip": "用於影像生成的提示詞" }, "seed": { "name": "種子值", "tooltip": "決定此節點是否重新執行的種子值；實際結果無論種子值為何都不具決定性。" } }, "outputs": { "0": { "tooltip": null } } };
const LumaImageNode = { "description": "根據提示詞與長寬比同步生成圖像。", "display_name": "Luma 文字轉圖像", "inputs": { "aspect_ratio": { "name": "長寬比" }, "character_image": { "name": "角色參考圖", "tooltip": "角色參考圖像；可為多張批次圖像，最多可考慮 4 張圖像。" }, "control_after_generate": { "name": "生成後控制" }, "image_luma_ref": { "name": "Luma 參考圖", "tooltip": "Luma 參考節點連接，可用輸入圖像影響生成；最多可考慮 4 張圖像。" }, "model": { "name": "模型" }, "prompt": { "name": "提示詞", "tooltip": "用於圖像生成的提示詞" }, "seed": { "name": "種子值", "tooltip": "決定節點是否重新執行的種子值；實際結果無論種子值如何都不具決定性。" }, "style_image": { "name": "風格參考圖", "tooltip": "風格參考圖像；僅會使用 1 張圖像。" }, "style_image_weight": { "name": "風格圖權重", "tooltip": "風格圖像的權重。如果未提供風格圖像則忽略。" } }, "outputs": { "0": { "tooltip": null } } };
const LumaImageToVideoNode = { "description": "根據提示詞、輸入圖片與輸出尺寸同步產生影片。", "display_name": "Luma 圖像轉影片", "inputs": { "control_after_generate": { "name": "生成後控制" }, "duration": { "name": "時長" }, "first_image": { "name": "第一張圖片", "tooltip": "生成影片的第一幀。" }, "last_image": { "name": "最後一張圖片", "tooltip": "生成影片的最後一幀。" }, "loop": { "name": "循環" }, "luma_concepts": { "name": "luma_concepts", "tooltip": "（選填）透過 Luma Concepts 節點指定相機運動的相機概念。" }, "model": { "name": "模型" }, "prompt": { "name": "提示詞", "tooltip": "用於影片生成的提示詞" }, "resolution": { "name": "解析度" }, "seed": { "name": "種子值", "tooltip": "決定此節點是否重新執行的種子值；實際結果無論種子值如何都不具決定性。" } }, "outputs": { "0": { "tooltip": null } } };
const LumaReferenceNode = { "description": "保存一張圖片及其權重，供 Luma 生成圖片節點使用。", "display_name": "Luma 參考", "inputs": { "image": { "name": "影像", "tooltip": "用作參考的圖片。" }, "luma_ref": { "name": "luma_ref" }, "weight": { "name": "權重", "tooltip": "圖片參考的權重。" } }, "outputs": { "0": { "name": "luma_ref", "tooltip": null } } };
const LumaVideoNode = { "description": "根據提示詞與輸出尺寸同步產生影片。", "display_name": "Luma 文字轉影片", "inputs": { "aspect_ratio": { "name": "長寬比" }, "control_after_generate": { "name": "生成後控制" }, "duration": { "name": "時長" }, "loop": { "name": "循環" }, "luma_concepts": { "name": "luma_concepts", "tooltip": "（選填）透過 Luma Concepts 節點指定相機運動的相機概念。" }, "model": { "name": "模型" }, "prompt": { "name": "提示詞", "tooltip": "用於影片生成的提示詞" }, "resolution": { "name": "解析度" }, "seed": { "name": "種子", "tooltip": "決定節點是否重新執行的種子；實際結果無論種子如何都不具決定性。" } }, "outputs": { "0": { "tooltip": null } } };
const Mahiro = { "description": "修改引導方式，讓其更著重於正向提示詞的「方向性」而非正負提示詞之間的差異。", "display_name": "Mahiro 太可愛了，應該要有更好的引導功能!! (。・ω・。)", "inputs": { "model": { "name": "model" } }, "outputs": { "0": { "name": "patched_model", "tooltip": null } } };
const MaskComposite = { "display_name": "遮罩合成", "inputs": { "destination": { "name": "destination" }, "operation": { "name": "操作" }, "source": { "name": "source" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const MaskPreview = { "description": "將輸入影像儲存到您的 ComfyUI 輸出目錄。", "display_name": "MaskPreview", "inputs": { "mask": { "name": "遮罩" } } };
const MaskToImage = { "display_name": "將遮罩轉換為影像", "inputs": { "mask": { "name": "遮罩" } } };
const MinimaxHailuoVideoNode = { "description": "使用新的 MiniMax 海螺-02 模型，從提示詞生成影片，可選起始幀。", "display_name": "MiniMax 海螺影片", "inputs": { "control_after_generate": { "name": "control after generate" }, "duration": { "name": "duration", "tooltip": "輸出影片的長度（單位：秒）。" }, "first_frame_image": { "name": "第一幀圖片", "tooltip": "可選的影像，用作生成影片的第一幀。" }, "prompt_optimizer": { "name": "prompt_optimizer", "tooltip": "需要時優化提示詞以提升生成品質。" }, "prompt_text": { "name": "提示文字", "tooltip": "引導影片生成的文字提示。" }, "resolution": { "name": "resolution", "tooltip": "影片顯示的尺寸。1080p 為 1920x1080，768p 為 1366x768。" }, "seed": { "name": "種子", "tooltip": "用於創建噪聲的隨機種子。" } }, "outputs": { "0": { "tooltip": null } } };
const MinimaxImageToVideoNode = { "description": "使用 MiniMax 的 API，根據圖像與提示生成影片", "display_name": "MiniMax 圖像轉影片", "inputs": { "control_after_generate": { "name": "生成後控制" }, "image": { "name": "圖像", "tooltip": "用作影片生成第一幀的圖像" }, "model": { "name": "模型", "tooltip": "用於影片生成的模型" }, "prompt_text": { "name": "提示文字", "tooltip": "用於引導影片生成的文字提示" }, "seed": { "name": "種子", "tooltip": "用於產生雜訊的隨機種子。" } }, "outputs": { "0": { "tooltip": null } } };
const MinimaxTextToVideoNode = { "description": "使用 MiniMax 的 API 根據提示生成影片", "display_name": "MiniMax 文字轉影片", "inputs": { "control_after_generate": { "name": "生成後控制" }, "model": { "name": "模型", "tooltip": "用於影片生成的模型" }, "prompt_text": { "name": "提示文字", "tooltip": "用於引導影片生成的文字提示" }, "seed": { "name": "種子", "tooltip": "用於產生雜訊的隨機種子。" } }, "outputs": { "0": { "tooltip": null } } };
const ModelComputeDtype = { "display_name": "ModelComputeDtype", "inputs": { "dtype": { "name": "dtype" }, "model": { "name": "model" } } };
const ModelMergeAdd = { "display_name": "ModelMergeAdd", "inputs": { "model1": { "name": "模型 1" }, "model2": { "name": "模型 2" } } };
const ModelMergeAuraflow = { "display_name": "ModelMergeAuraflow", "inputs": { "cond_seq_linear_": { "name": "cond_seq_linear." }, "double_layers_0_": { "name": "double_layers.0." }, "double_layers_1_": { "name": "double_layers.1." }, "double_layers_2_": { "name": "double_layers.2." }, "double_layers_3_": { "name": "double_layers.3." }, "final_linear_": { "name": "final_linear." }, "init_x_linear_": { "name": "init_x_linear." }, "modF_": { "name": "modF." }, "model1": { "name": "模型 1" }, "model2": { "name": "模型 2" }, "positional_encoding": { "name": "positional_encoding" }, "register_tokens": { "name": "register_tokens" }, "single_layers_0_": { "name": "single_layers.0." }, "single_layers_10_": { "name": "single_layers.10." }, "single_layers_11_": { "name": "single_layers.11." }, "single_layers_12_": { "name": "single_layers.12." }, "single_layers_13_": { "name": "single_layers.13." }, "single_layers_14_": { "name": "single_layers.14." }, "single_layers_15_": { "name": "single_layers.15." }, "single_layers_16_": { "name": "single_layers.16." }, "single_layers_17_": { "name": "single_layers.17." }, "single_layers_18_": { "name": "single_layers.18." }, "single_layers_19_": { "name": "single_layers.19." }, "single_layers_1_": { "name": "single_layers.1." }, "single_layers_20_": { "name": "single_layers.20." }, "single_layers_21_": { "name": "single_layers.21." }, "single_layers_22_": { "name": "single_layers.22." }, "single_layers_23_": { "name": "single_layers.23." }, "single_layers_24_": { "name": "single_layers.24." }, "single_layers_25_": { "name": "single_layers.25." }, "single_layers_26_": { "name": "single_layers.26." }, "single_layers_27_": { "name": "single_layers.27." }, "single_layers_28_": { "name": "single_layers.28." }, "single_layers_29_": { "name": "single_layers.29." }, "single_layers_2_": { "name": "single_layers.2." }, "single_layers_30_": { "name": "single_layers.30." }, "single_layers_31_": { "name": "single_layers.31." }, "single_layers_3_": { "name": "single_layers.3." }, "single_layers_4_": { "name": "single_layers.4." }, "single_layers_5_": { "name": "single_layers.5." }, "single_layers_6_": { "name": "single_layers.6." }, "single_layers_7_": { "name": "single_layers.7." }, "single_layers_8_": { "name": "single_layers.8." }, "single_layers_9_": { "name": "single_layers.9." }, "t_embedder_": { "name": "t_embedder." } } };
const ModelMergeBlocks = { "display_name": "ModelMergeBlocks", "inputs": { "input": { "name": "輸入" }, "middle": { "name": "中間" }, "model1": { "name": "模型 1" }, "model2": { "name": "模型 2" }, "out": { "name": "輸出" } } };
const ModelMergeCosmos14B = { "display_name": "ModelMergeCosmos14B", "inputs": { "affline_norm_": { "name": "affline_norm." }, "blocks_block0_": { "name": "blocks.block0." }, "blocks_block10_": { "name": "blocks.block10." }, "blocks_block11_": { "name": "blocks.block11." }, "blocks_block12_": { "name": "blocks.block12." }, "blocks_block13_": { "name": "blocks.block13." }, "blocks_block14_": { "name": "blocks.block14." }, "blocks_block15_": { "name": "blocks.block15." }, "blocks_block16_": { "name": "blocks.block16." }, "blocks_block17_": { "name": "blocks.block17." }, "blocks_block18_": { "name": "blocks.block18." }, "blocks_block19_": { "name": "blocks.block19." }, "blocks_block1_": { "name": "blocks.block1." }, "blocks_block20_": { "name": "blocks.block20." }, "blocks_block21_": { "name": "blocks.block21." }, "blocks_block22_": { "name": "blocks.block22." }, "blocks_block23_": { "name": "blocks.block23." }, "blocks_block24_": { "name": "blocks.block24." }, "blocks_block25_": { "name": "blocks.block25." }, "blocks_block26_": { "name": "blocks.block26." }, "blocks_block27_": { "name": "blocks.block27." }, "blocks_block28_": { "name": "blocks.block28." }, "blocks_block29_": { "name": "blocks.block29." }, "blocks_block2_": { "name": "blocks.block2." }, "blocks_block30_": { "name": "blocks.block30." }, "blocks_block31_": { "name": "blocks.block31." }, "blocks_block32_": { "name": "blocks.block32." }, "blocks_block33_": { "name": "blocks.block33." }, "blocks_block34_": { "name": "blocks.block34." }, "blocks_block35_": { "name": "blocks.block35." }, "blocks_block3_": { "name": "blocks.block3." }, "blocks_block4_": { "name": "blocks.block4." }, "blocks_block5_": { "name": "blocks.block5." }, "blocks_block6_": { "name": "blocks.block6." }, "blocks_block7_": { "name": "blocks.block7." }, "blocks_block8_": { "name": "blocks.block8." }, "blocks_block9_": { "name": "blocks.block9." }, "extra_pos_embedder_": { "name": "extra_pos_embedder." }, "final_layer_": { "name": "final_layer." }, "model1": { "name": "模型 1" }, "model2": { "name": "模型 2" }, "pos_embedder_": { "name": "pos_embedder." }, "t_embedder_": { "name": "t_embedder." }, "x_embedder_": { "name": "x_embedder." } } };
const ModelMergeCosmos7B = { "display_name": "ModelMergeCosmos7B", "inputs": { "affline_norm_": { "name": "affline_norm." }, "blocks_block0_": { "name": "blocks.block0." }, "blocks_block10_": { "name": "blocks.block10." }, "blocks_block11_": { "name": "blocks.block11." }, "blocks_block12_": { "name": "blocks.block12." }, "blocks_block13_": { "name": "blocks.block13." }, "blocks_block14_": { "name": "blocks.block14." }, "blocks_block15_": { "name": "blocks.block15." }, "blocks_block16_": { "name": "blocks.block16." }, "blocks_block17_": { "name": "blocks.block17." }, "blocks_block18_": { "name": "blocks.block18." }, "blocks_block19_": { "name": "blocks.block19." }, "blocks_block1_": { "name": "blocks.block1." }, "blocks_block20_": { "name": "blocks.block20." }, "blocks_block21_": { "name": "blocks.block21." }, "blocks_block22_": { "name": "blocks.block22." }, "blocks_block23_": { "name": "blocks.block23." }, "blocks_block24_": { "name": "blocks.block24." }, "blocks_block25_": { "name": "blocks.block25." }, "blocks_block26_": { "name": "blocks.block26." }, "blocks_block27_": { "name": "blocks.block27." }, "blocks_block2_": { "name": "blocks.block2." }, "blocks_block3_": { "name": "blocks.block3." }, "blocks_block4_": { "name": "blocks.block4." }, "blocks_block5_": { "name": "blocks.block5." }, "blocks_block6_": { "name": "blocks.block6." }, "blocks_block7_": { "name": "blocks.block7." }, "blocks_block8_": { "name": "blocks.block8." }, "blocks_block9_": { "name": "blocks.block9." }, "extra_pos_embedder_": { "name": "extra_pos_embedder." }, "final_layer_": { "name": "final_layer." }, "model1": { "name": "模型 1" }, "model2": { "name": "模型 2" }, "pos_embedder_": { "name": "pos_embedder." }, "t_embedder_": { "name": "t_embedder." }, "x_embedder_": { "name": "x_embedder." } } };
const ModelMergeCosmosPredict2_14B = { "display_name": "ModelMergeCosmosPredict2_14B", "inputs": { "blocks_0_": { "name": "blocks.0." }, "blocks_10_": { "name": "blocks.10." }, "blocks_11_": { "name": "blocks.11." }, "blocks_12_": { "name": "blocks.12." }, "blocks_13_": { "name": "blocks.13." }, "blocks_14_": { "name": "blocks.14." }, "blocks_15_": { "name": "blocks.15." }, "blocks_16_": { "name": "blocks.16." }, "blocks_17_": { "name": "blocks.17." }, "blocks_18_": { "name": "blocks.18." }, "blocks_19_": { "name": "blocks.19." }, "blocks_1_": { "name": "blocks.1." }, "blocks_20_": { "name": "blocks.20." }, "blocks_21_": { "name": "blocks.21." }, "blocks_22_": { "name": "blocks.22." }, "blocks_23_": { "name": "blocks.23." }, "blocks_24_": { "name": "blocks.24." }, "blocks_25_": { "name": "blocks.25." }, "blocks_26_": { "name": "blocks.26." }, "blocks_27_": { "name": "blocks.27." }, "blocks_28_": { "name": "blocks.28." }, "blocks_29_": { "name": "blocks.29." }, "blocks_2_": { "name": "blocks.2." }, "blocks_30_": { "name": "blocks.30." }, "blocks_31_": { "name": "blocks.31." }, "blocks_32_": { "name": "blocks.32." }, "blocks_33_": { "name": "blocks.33." }, "blocks_34_": { "name": "blocks.34." }, "blocks_35_": { "name": "區塊.35." }, "blocks_3_": { "name": "blocks.3." }, "blocks_4_": { "name": "blocks.4." }, "blocks_5_": { "name": "blocks.5." }, "blocks_6_": { "name": "blocks.6." }, "blocks_7_": { "name": "blocks.7." }, "blocks_8_": { "name": "blocks.8." }, "blocks_9_": { "name": "blocks.9." }, "final_layer_": { "name": "最終層." }, "model1": { "name": "model1" }, "model2": { "name": "model2" }, "pos_embedder_": { "name": "pos_embedder." }, "t_embedder_": { "name": "t_embedder." }, "t_embedding_norm_": { "name": "t_embedding_norm." }, "x_embedder_": { "name": "x_embedder." } } };
const ModelMergeCosmosPredict2_2B = { "display_name": "模型合併宇宙預測2_2B", "inputs": { "blocks_0_": { "name": "區塊.0." }, "blocks_10_": { "name": "區塊.10." }, "blocks_11_": { "name": "區塊.11." }, "blocks_12_": { "name": "區塊.12." }, "blocks_13_": { "name": "區塊.13." }, "blocks_14_": { "name": "區塊.14." }, "blocks_15_": { "name": "區塊.15." }, "blocks_16_": { "name": "區塊.16." }, "blocks_17_": { "name": "區塊.17." }, "blocks_18_": { "name": "區塊.18." }, "blocks_19_": { "name": "區塊.19." }, "blocks_1_": { "name": "區塊.1." }, "blocks_20_": { "name": "區塊.20." }, "blocks_21_": { "name": "區塊.21." }, "blocks_22_": { "name": "區塊.22." }, "blocks_23_": { "name": "區塊.23." }, "blocks_24_": { "name": "區塊.24." }, "blocks_25_": { "name": "區塊.25." }, "blocks_26_": { "name": "區塊.26." }, "blocks_27_": { "name": "區塊.27." }, "blocks_2_": { "name": "區塊.2." }, "blocks_3_": { "name": "區塊.3." }, "blocks_4_": { "name": "區塊.4." }, "blocks_5_": { "name": "區塊.5." }, "blocks_6_": { "name": "區塊.6." }, "blocks_7_": { "name": "區塊.7." }, "blocks_8_": { "name": "區塊.8." }, "blocks_9_": { "name": "區塊.9." }, "final_layer_": { "name": "最終層." }, "model1": { "name": "模型1" }, "model2": { "name": "模型2" }, "pos_embedder_": { "name": "位置嵌入器." }, "t_embedder_": { "name": "t嵌入器." }, "t_embedding_norm_": { "name": "t嵌入歸一化." }, "x_embedder_": { "name": "x嵌入器." } } };
const ModelMergeFlux1 = { "display_name": "ModelMergeFlux1", "inputs": { "double_blocks_0_": { "name": "double_blocks.0." }, "double_blocks_10_": { "name": "double_blocks.10." }, "double_blocks_11_": { "name": "double_blocks.11." }, "double_blocks_12_": { "name": "double_blocks.12." }, "double_blocks_13_": { "name": "double_blocks.13." }, "double_blocks_14_": { "name": "double_blocks.14." }, "double_blocks_15_": { "name": "double_blocks.15." }, "double_blocks_16_": { "name": "double_blocks.16." }, "double_blocks_17_": { "name": "double_blocks.17." }, "double_blocks_18_": { "name": "double_blocks.18." }, "double_blocks_1_": { "name": "double_blocks.1." }, "double_blocks_2_": { "name": "double_blocks.2." }, "double_blocks_3_": { "name": "double_blocks.3." }, "double_blocks_4_": { "name": "double_blocks.4." }, "double_blocks_5_": { "name": "double_blocks.5." }, "double_blocks_6_": { "name": "double_blocks.6." }, "double_blocks_7_": { "name": "double_blocks.7." }, "double_blocks_8_": { "name": "double_blocks.8." }, "double_blocks_9_": { "name": "double_blocks.9." }, "final_layer_": { "name": "final_layer." }, "guidance_in": { "name": "guidance_in" }, "img_in_": { "name": "img_in." }, "model1": { "name": "模型 1" }, "model2": { "name": "模型 2" }, "single_blocks_0_": { "name": "single_blocks.0." }, "single_blocks_10_": { "name": "single_blocks.10." }, "single_blocks_11_": { "name": "single_blocks.11." }, "single_blocks_12_": { "name": "single_blocks.12." }, "single_blocks_13_": { "name": "single_blocks.13." }, "single_blocks_14_": { "name": "single_blocks.14." }, "single_blocks_15_": { "name": "single_blocks.15." }, "single_blocks_16_": { "name": "single_blocks.16." }, "single_blocks_17_": { "name": "single_blocks.17." }, "single_blocks_18_": { "name": "single_blocks.18." }, "single_blocks_19_": { "name": "single_blocks.19." }, "single_blocks_1_": { "name": "single_blocks.1." }, "single_blocks_20_": { "name": "single_blocks.20." }, "single_blocks_21_": { "name": "single_blocks.21." }, "single_blocks_22_": { "name": "single_blocks.22." }, "single_blocks_23_": { "name": "single_blocks.23." }, "single_blocks_24_": { "name": "single_blocks.24." }, "single_blocks_25_": { "name": "single_blocks.25." }, "single_blocks_26_": { "name": "single_blocks.26." }, "single_blocks_27_": { "name": "single_blocks.27." }, "single_blocks_28_": { "name": "single_blocks.28." }, "single_blocks_29_": { "name": "single_blocks.29." }, "single_blocks_2_": { "name": "single_blocks.2." }, "single_blocks_30_": { "name": "single_blocks.30." }, "single_blocks_31_": { "name": "single_blocks.31." }, "single_blocks_32_": { "name": "single_blocks.32." }, "single_blocks_33_": { "name": "single_blocks.33." }, "single_blocks_34_": { "name": "single_blocks.34." }, "single_blocks_35_": { "name": "single_blocks.35." }, "single_blocks_36_": { "name": "single_blocks.36." }, "single_blocks_37_": { "name": "single_blocks.37." }, "single_blocks_3_": { "name": "single_blocks.3." }, "single_blocks_4_": { "name": "single_blocks.4." }, "single_blocks_5_": { "name": "single_blocks.5." }, "single_blocks_6_": { "name": "single_blocks.6." }, "single_blocks_7_": { "name": "single_blocks.7." }, "single_blocks_8_": { "name": "single_blocks.8." }, "single_blocks_9_": { "name": "single_blocks.9." }, "time_in_": { "name": "time_in." }, "txt_in_": { "name": "txt_in." }, "vector_in_": { "name": "vector_in." } } };
const ModelMergeLTXV = { "display_name": "模型合併 (LTXV)", "inputs": { "adaln_single_": { "name": "adaln_single." }, "caption_projection_": { "name": "caption_projection." }, "model1": { "name": "模型 1" }, "model2": { "name": "模型 2" }, "patchify_proj_": { "name": "patchify_proj." }, "proj_out_": { "name": "proj_out." }, "scale_shift_table": { "name": "scale_shift_table" }, "transformer_blocks_0_": { "name": "transformer_blocks.0." }, "transformer_blocks_10_": { "name": "transformer_blocks.10." }, "transformer_blocks_11_": { "name": "transformer_blocks.11." }, "transformer_blocks_12_": { "name": "transformer_blocks.12." }, "transformer_blocks_13_": { "name": "transformer_blocks.13." }, "transformer_blocks_14_": { "name": "transformer_blocks.14." }, "transformer_blocks_15_": { "name": "transformer_blocks.15." }, "transformer_blocks_16_": { "name": "transformer_blocks.16." }, "transformer_blocks_17_": { "name": "transformer_blocks.17." }, "transformer_blocks_18_": { "name": "transformer_blocks.18." }, "transformer_blocks_19_": { "name": "transformer_blocks.19." }, "transformer_blocks_1_": { "name": "transformer_blocks.1." }, "transformer_blocks_20_": { "name": "transformer_blocks.20." }, "transformer_blocks_21_": { "name": "transformer_blocks.21." }, "transformer_blocks_22_": { "name": "transformer_blocks.22." }, "transformer_blocks_23_": { "name": "transformer_blocks.23." }, "transformer_blocks_24_": { "name": "transformer_blocks.24." }, "transformer_blocks_25_": { "name": "transformer_blocks.25." }, "transformer_blocks_26_": { "name": "transformer_blocks.26." }, "transformer_blocks_27_": { "name": "transformer_blocks.27." }, "transformer_blocks_2_": { "name": "transformer_blocks.2." }, "transformer_blocks_3_": { "name": "transformer_blocks.3." }, "transformer_blocks_4_": { "name": "transformer_blocks.4." }, "transformer_blocks_5_": { "name": "transformer_blocks.5." }, "transformer_blocks_6_": { "name": "transformer_blocks.6." }, "transformer_blocks_7_": { "name": "transformer_blocks.7." }, "transformer_blocks_8_": { "name": "transformer_blocks.8." }, "transformer_blocks_9_": { "name": "transformer_blocks.9." } } };
const ModelMergeMochiPreview = { "display_name": "模型合併 (Mochi 預覽)", "inputs": { "blocks_0_": { "name": "blocks.0." }, "blocks_10_": { "name": "blocks.10." }, "blocks_11_": { "name": "blocks.11." }, "blocks_12_": { "name": "blocks.12." }, "blocks_13_": { "name": "blocks.13." }, "blocks_14_": { "name": "blocks.14." }, "blocks_15_": { "name": "blocks.15." }, "blocks_16_": { "name": "blocks.16." }, "blocks_17_": { "name": "blocks.17." }, "blocks_18_": { "name": "blocks.18." }, "blocks_19_": { "name": "blocks.19." }, "blocks_1_": { "name": "blocks.1." }, "blocks_20_": { "name": "blocks.20." }, "blocks_21_": { "name": "blocks.21." }, "blocks_22_": { "name": "blocks.22." }, "blocks_23_": { "name": "blocks.23." }, "blocks_24_": { "name": "blocks.24." }, "blocks_25_": { "name": "blocks.25." }, "blocks_26_": { "name": "blocks.26." }, "blocks_27_": { "name": "blocks.27." }, "blocks_28_": { "name": "blocks.28." }, "blocks_29_": { "name": "blocks.29." }, "blocks_2_": { "name": "blocks.2." }, "blocks_30_": { "name": "blocks.30." }, "blocks_31_": { "name": "blocks.31." }, "blocks_32_": { "name": "blocks.32." }, "blocks_33_": { "name": "blocks.33." }, "blocks_34_": { "name": "blocks.34." }, "blocks_35_": { "name": "blocks.35." }, "blocks_36_": { "name": "blocks.36." }, "blocks_37_": { "name": "blocks.37." }, "blocks_38_": { "name": "blocks.38." }, "blocks_39_": { "name": "blocks.39." }, "blocks_3_": { "name": "blocks.3." }, "blocks_40_": { "name": "blocks.40." }, "blocks_41_": { "name": "blocks.41." }, "blocks_42_": { "name": "blocks.42." }, "blocks_43_": { "name": "blocks.43." }, "blocks_44_": { "name": "blocks.44." }, "blocks_45_": { "name": "blocks.45." }, "blocks_46_": { "name": "blocks.46." }, "blocks_47_": { "name": "blocks.47." }, "blocks_4_": { "name": "blocks.4." }, "blocks_5_": { "name": "blocks.5." }, "blocks_6_": { "name": "blocks.6." }, "blocks_7_": { "name": "blocks.7." }, "blocks_8_": { "name": "blocks.8." }, "blocks_9_": { "name": "blocks.9." }, "final_layer_": { "name": "final_layer." }, "model1": { "name": "模型 1" }, "model2": { "name": "模型 2" }, "pos_frequencies_": { "name": "pos_frequencies." }, "t5_y_embedder_": { "name": "t5_y_embedder." }, "t5_yproj_": { "name": "t5_yproj." }, "t_embedder_": { "name": "t_embedder." } } };
const ModelMergeQwenImage = { "display_name": "模型合併Qwen圖像", "inputs": { "img_in_": { "name": "圖像輸入." }, "model1": { "name": "模型1" }, "model2": { "name": "模型2" }, "pos_embeds_": { "name": "位置嵌入." }, "proj_out_": { "name": "proj_out." }, "time_text_embed_": { "name": "時間文字嵌入." }, "transformer_blocks_0_": { "name": "轉換器區塊.0." }, "transformer_blocks_10_": { "name": "transformer_blocks.10." }, "transformer_blocks_11_": { "name": "transformer_blocks.11." }, "transformer_blocks_12_": { "name": "transformer_blocks.12." }, "transformer_blocks_13_": { "name": "transformer_blocks.13." }, "transformer_blocks_14_": { "name": "transformer_blocks.14." }, "transformer_blocks_15_": { "name": "transformer_blocks.15." }, "transformer_blocks_16_": { "name": "transformer_blocks.16." }, "transformer_blocks_17_": { "name": "transformer_blocks.17." }, "transformer_blocks_18_": { "name": "transformer_blocks.18." }, "transformer_blocks_19_": { "name": "transformer_blocks.19." }, "transformer_blocks_1_": { "name": "轉換器區塊.1." }, "transformer_blocks_20_": { "name": "transformer_blocks.20." }, "transformer_blocks_21_": { "name": "transformer_blocks.21." }, "transformer_blocks_22_": { "name": "transformer_blocks.22." }, "transformer_blocks_23_": { "name": "transformer_blocks.23." }, "transformer_blocks_24_": { "name": "transformer_blocks.24." }, "transformer_blocks_25_": { "name": "transformer_blocks.25." }, "transformer_blocks_26_": { "name": "transformer_blocks.26." }, "transformer_blocks_27_": { "name": "transformer_blocks.27." }, "transformer_blocks_28_": { "name": "transformer_blocks.28." }, "transformer_blocks_29_": { "name": "transformer_blocks.29." }, "transformer_blocks_2_": { "name": "轉換器區塊.2." }, "transformer_blocks_30_": { "name": "transformer_blocks.30." }, "transformer_blocks_31_": { "name": "transformer_blocks.31." }, "transformer_blocks_32_": { "name": "transformer_blocks.32." }, "transformer_blocks_33_": { "name": "transformer_blocks.33." }, "transformer_blocks_34_": { "name": "transformer_blocks.34." }, "transformer_blocks_35_": { "name": "transformer_blocks.35." }, "transformer_blocks_36_": { "name": "transformer_blocks.36." }, "transformer_blocks_37_": { "name": "transformer_blocks.37." }, "transformer_blocks_38_": { "name": "transformer_blocks.38." }, "transformer_blocks_39_": { "name": "transformer_blocks.39." }, "transformer_blocks_3_": { "name": "轉換器區塊.3." }, "transformer_blocks_40_": { "name": "transformer_blocks.40." }, "transformer_blocks_41_": { "name": "transformer_blocks.41." }, "transformer_blocks_42_": { "name": "transformer_blocks.42." }, "transformer_blocks_43_": { "name": "transformer_blocks.43." }, "transformer_blocks_44_": { "name": "transformer_blocks.44." }, "transformer_blocks_45_": { "name": "transformer_blocks.45." }, "transformer_blocks_46_": { "name": "transformer_blocks.46." }, "transformer_blocks_47_": { "name": "transformer_blocks.47." }, "transformer_blocks_48_": { "name": "transformer_blocks.48." }, "transformer_blocks_49_": { "name": "transformer_blocks.49." }, "transformer_blocks_4_": { "name": "transformer_blocks.4." }, "transformer_blocks_50_": { "name": "transformer_blocks.50." }, "transformer_blocks_51_": { "name": "transformer_blocks.51." }, "transformer_blocks_52_": { "name": "transformer_blocks.52." }, "transformer_blocks_53_": { "name": "transformer_blocks.53." }, "transformer_blocks_54_": { "name": "transformer_blocks.54." }, "transformer_blocks_55_": { "name": "transformer_blocks.55." }, "transformer_blocks_56_": { "name": "transformer_blocks.56." }, "transformer_blocks_57_": { "name": "transformer_blocks.57." }, "transformer_blocks_58_": { "name": "transformer_blocks.58." }, "transformer_blocks_59_": { "name": "transformer_blocks.59." }, "transformer_blocks_5_": { "name": "transformer_blocks.5." }, "transformer_blocks_6_": { "name": "transformer_blocks.6." }, "transformer_blocks_7_": { "name": "transformer_blocks.7." }, "transformer_blocks_8_": { "name": "transformer_blocks.8." }, "transformer_blocks_9_": { "name": "transformer_blocks.9." }, "txt_in_": { "name": "文字輸入." }, "txt_norm_": { "name": "文字歸一化." } } };
const ModelMergeSD1 = { "display_name": "模型合併 (SD1)", "inputs": { "input_blocks_0_": { "name": "input_blocks.0." }, "input_blocks_10_": { "name": "input_blocks.10." }, "input_blocks_11_": { "name": "input_blocks.11." }, "input_blocks_1_": { "name": "input_blocks.1." }, "input_blocks_2_": { "name": "input_blocks.2." }, "input_blocks_3_": { "name": "input_blocks.3." }, "input_blocks_4_": { "name": "input_blocks.4." }, "input_blocks_5_": { "name": "input_blocks.5." }, "input_blocks_6_": { "name": "input_blocks.6." }, "input_blocks_7_": { "name": "input_blocks.7." }, "input_blocks_8_": { "name": "input_blocks.8." }, "input_blocks_9_": { "name": "input_blocks.9." }, "label_emb_": { "name": "label_emb." }, "middle_block_0_": { "name": "middle_block.0." }, "middle_block_1_": { "name": "middle_block.1." }, "middle_block_2_": { "name": "middle_block.2." }, "model1": { "name": "模型 1" }, "model2": { "name": "模型 2" }, "out_": { "name": "out." }, "output_blocks_0_": { "name": "output_blocks.0." }, "output_blocks_10_": { "name": "output_blocks.10." }, "output_blocks_11_": { "name": "output_blocks.11." }, "output_blocks_1_": { "name": "output_blocks.1." }, "output_blocks_2_": { "name": "output_blocks.2." }, "output_blocks_3_": { "name": "output_blocks.3." }, "output_blocks_4_": { "name": "output_blocks.4." }, "output_blocks_5_": { "name": "output_blocks.5." }, "output_blocks_6_": { "name": "output_blocks.6." }, "output_blocks_7_": { "name": "output_blocks.7." }, "output_blocks_8_": { "name": "output_blocks.8." }, "output_blocks_9_": { "name": "output_blocks.9." }, "time_embed_": { "name": "time_embed." } } };
const ModelMergeSD2 = { "display_name": "模型合併 (SD2)", "inputs": { "input_blocks_0_": { "name": "input_blocks.0." }, "input_blocks_10_": { "name": "input_blocks.10." }, "input_blocks_11_": { "name": "input_blocks.11." }, "input_blocks_1_": { "name": "input_blocks.1." }, "input_blocks_2_": { "name": "input_blocks.2." }, "input_blocks_3_": { "name": "input_blocks.3." }, "input_blocks_4_": { "name": "input_blocks.4." }, "input_blocks_5_": { "name": "input_blocks.5." }, "input_blocks_6_": { "name": "input_blocks.6." }, "input_blocks_7_": { "name": "input_blocks.7." }, "input_blocks_8_": { "name": "input_blocks.8." }, "input_blocks_9_": { "name": "input_blocks.9." }, "label_emb_": { "name": "label_emb." }, "middle_block_0_": { "name": "middle_block.0." }, "middle_block_1_": { "name": "middle_block.1." }, "middle_block_2_": { "name": "middle_block.2." }, "model1": { "name": "模型 1" }, "model2": { "name": "模型 2" }, "out_": { "name": "out." }, "output_blocks_0_": { "name": "output_blocks.0." }, "output_blocks_10_": { "name": "output_blocks.10." }, "output_blocks_11_": { "name": "output_blocks.11." }, "output_blocks_1_": { "name": "output_blocks.1." }, "output_blocks_2_": { "name": "output_blocks.2." }, "output_blocks_3_": { "name": "output_blocks.3." }, "output_blocks_4_": { "name": "output_blocks.4." }, "output_blocks_5_": { "name": "output_blocks.5." }, "output_blocks_6_": { "name": "output_blocks.6." }, "output_blocks_7_": { "name": "output_blocks.7." }, "output_blocks_8_": { "name": "output_blocks.8." }, "output_blocks_9_": { "name": "output_blocks.9." }, "time_embed_": { "name": "time_embed." } } };
const ModelMergeSD35_Large = { "display_name": "模型合併 (SD3.5 Large)", "inputs": { "context_embedder_": { "name": "context_embedder." }, "final_layer_": { "name": "final_layer." }, "joint_blocks_0_": { "name": "joint_blocks.0." }, "joint_blocks_10_": { "name": "joint_blocks.10." }, "joint_blocks_11_": { "name": "joint_blocks.11." }, "joint_blocks_12_": { "name": "joint_blocks.12." }, "joint_blocks_13_": { "name": "joint_blocks.13." }, "joint_blocks_14_": { "name": "joint_blocks.14." }, "joint_blocks_15_": { "name": "joint_blocks.15." }, "joint_blocks_16_": { "name": "joint_blocks.16." }, "joint_blocks_17_": { "name": "joint_blocks.17." }, "joint_blocks_18_": { "name": "joint_blocks.18." }, "joint_blocks_19_": { "name": "joint_blocks.19." }, "joint_blocks_1_": { "name": "joint_blocks.1." }, "joint_blocks_20_": { "name": "joint_blocks.20." }, "joint_blocks_21_": { "name": "joint_blocks.21." }, "joint_blocks_22_": { "name": "joint_blocks.22." }, "joint_blocks_23_": { "name": "joint_blocks.23." }, "joint_blocks_24_": { "name": "joint_blocks.24." }, "joint_blocks_25_": { "name": "joint_blocks.25." }, "joint_blocks_26_": { "name": "joint_blocks.26." }, "joint_blocks_27_": { "name": "joint_blocks.27." }, "joint_blocks_28_": { "name": "joint_blocks.28." }, "joint_blocks_29_": { "name": "joint_blocks.29." }, "joint_blocks_2_": { "name": "joint_blocks.2." }, "joint_blocks_30_": { "name": "joint_blocks.30." }, "joint_blocks_31_": { "name": "joint_blocks.31." }, "joint_blocks_32_": { "name": "joint_blocks.32." }, "joint_blocks_33_": { "name": "joint_blocks.33." }, "joint_blocks_34_": { "name": "joint_blocks.34." }, "joint_blocks_35_": { "name": "joint_blocks.35." }, "joint_blocks_36_": { "name": "joint_blocks.36." }, "joint_blocks_37_": { "name": "joint_blocks.37." }, "joint_blocks_3_": { "name": "joint_blocks.3." }, "joint_blocks_4_": { "name": "joint_blocks.4." }, "joint_blocks_5_": { "name": "joint_blocks.5." }, "joint_blocks_6_": { "name": "joint_blocks.6." }, "joint_blocks_7_": { "name": "joint_blocks.7." }, "joint_blocks_8_": { "name": "joint_blocks.8." }, "joint_blocks_9_": { "name": "joint_blocks.9." }, "model1": { "name": "模型 1" }, "model2": { "name": "模型 2" }, "pos_embed_": { "name": "pos_embed." }, "t_embedder_": { "name": "t_embedder." }, "x_embedder_": { "name": "x_embedder." }, "y_embedder_": { "name": "y_embedder." } } };
const ModelMergeSD3_2B = { "display_name": "模型合併 (SD3 2B)", "inputs": { "context_embedder_": { "name": "context_embedder." }, "final_layer_": { "name": "final_layer." }, "joint_blocks_0_": { "name": "joint_blocks.0." }, "joint_blocks_10_": { "name": "joint_blocks.10." }, "joint_blocks_11_": { "name": "joint_blocks.11." }, "joint_blocks_12_": { "name": "joint_blocks.12." }, "joint_blocks_13_": { "name": "joint_blocks.13." }, "joint_blocks_14_": { "name": "joint_blocks.14." }, "joint_blocks_15_": { "name": "joint_blocks.15." }, "joint_blocks_16_": { "name": "joint_blocks.16." }, "joint_blocks_17_": { "name": "joint_blocks.17." }, "joint_blocks_18_": { "name": "joint_blocks.18." }, "joint_blocks_19_": { "name": "joint_blocks.19." }, "joint_blocks_1_": { "name": "joint_blocks.1." }, "joint_blocks_20_": { "name": "joint_blocks.20." }, "joint_blocks_21_": { "name": "joint_blocks.21." }, "joint_blocks_22_": { "name": "joint_blocks.22." }, "joint_blocks_23_": { "name": "joint_blocks.23." }, "joint_blocks_2_": { "name": "joint_blocks.2." }, "joint_blocks_3_": { "name": "joint_blocks.3." }, "joint_blocks_4_": { "name": "joint_blocks.4." }, "joint_blocks_5_": { "name": "joint_blocks.5." }, "joint_blocks_6_": { "name": "joint_blocks.6." }, "joint_blocks_7_": { "name": "joint_blocks.7." }, "joint_blocks_8_": { "name": "joint_blocks.8." }, "joint_blocks_9_": { "name": "joint_blocks.9." }, "model1": { "name": "模型 1" }, "model2": { "name": "模型 2" }, "pos_embed_": { "name": "pos_embed." }, "t_embedder_": { "name": "t_embedder." }, "x_embedder_": { "name": "x_embedder." }, "y_embedder_": { "name": "y_embedder." } } };
const ModelMergeSDXL = { "display_name": "模型合併 (SDXL)", "inputs": { "input_blocks_0": { "name": "input_blocks.0" }, "input_blocks_1": { "name": "input_blocks.1" }, "input_blocks_2": { "name": "input_blocks.2" }, "input_blocks_3": { "name": "input_blocks.3" }, "input_blocks_4": { "name": "input_blocks.4" }, "input_blocks_5": { "name": "input_blocks.5" }, "input_blocks_6": { "name": "input_blocks.6" }, "input_blocks_7": { "name": "input_blocks.7" }, "input_blocks_8": { "name": "input_blocks.8" }, "label_emb_": { "name": "label_emb." }, "middle_block_0": { "name": "middle_block.0" }, "middle_block_1": { "name": "middle_block.1" }, "middle_block_2": { "name": "middle_block.2" }, "model1": { "name": "模型 1" }, "model2": { "name": "模型 2" }, "out_": { "name": "out." }, "output_blocks_0": { "name": "output_blocks.0" }, "output_blocks_1": { "name": "output_blocks.1" }, "output_blocks_2": { "name": "output_blocks.2" }, "output_blocks_3": { "name": "output_blocks.3" }, "output_blocks_4": { "name": "output_blocks.4" }, "output_blocks_5": { "name": "output_blocks.5" }, "output_blocks_6": { "name": "output_blocks.6" }, "output_blocks_7": { "name": "output_blocks.7" }, "output_blocks_8": { "name": "output_blocks.8" }, "time_embed_": { "name": "time_embed." } } };
const ModelMergeSimple = { "display_name": "簡易模型合併", "inputs": { "model1": { "name": "模型 1" }, "model2": { "name": "模型 2" }, "ratio": { "name": "比例" } } };
const ModelMergeSubtract = { "display_name": "模型合併（減法）", "inputs": { "model1": { "name": "模型 1" }, "model2": { "name": "模型 2" }, "multiplier": { "name": "乘數" } } };
const ModelMergeWAN2_1 = { "description": "1.3B 模型有 30 個區塊，14B 模型有 40 個區塊。影像轉影片模型有額外的 img_emb。", "display_name": "模型合併 (WAN2.1)", "inputs": { "blocks_0_": { "name": "blocks.0." }, "blocks_10_": { "name": "blocks.10." }, "blocks_11_": { "name": "blocks.11." }, "blocks_12_": { "name": "blocks.12." }, "blocks_13_": { "name": "blocks.13." }, "blocks_14_": { "name": "blocks.14." }, "blocks_15_": { "name": "blocks.15." }, "blocks_16_": { "name": "blocks.16." }, "blocks_17_": { "name": "blocks.17." }, "blocks_18_": { "name": "blocks.18." }, "blocks_19_": { "name": "blocks.19." }, "blocks_1_": { "name": "blocks.1." }, "blocks_20_": { "name": "blocks.20." }, "blocks_21_": { "name": "blocks.21." }, "blocks_22_": { "name": "blocks.22." }, "blocks_23_": { "name": "blocks.23." }, "blocks_24_": { "name": "blocks.24." }, "blocks_25_": { "name": "blocks.25." }, "blocks_26_": { "name": "blocks.26." }, "blocks_27_": { "name": "blocks.27." }, "blocks_28_": { "name": "blocks.28." }, "blocks_29_": { "name": "blocks.29." }, "blocks_2_": { "name": "blocks.2." }, "blocks_30_": { "name": "blocks.30." }, "blocks_31_": { "name": "blocks.31." }, "blocks_32_": { "name": "blocks.32." }, "blocks_33_": { "name": "blocks.33." }, "blocks_34_": { "name": "blocks.34." }, "blocks_35_": { "name": "blocks.35." }, "blocks_36_": { "name": "blocks.36." }, "blocks_37_": { "name": "blocks.37." }, "blocks_38_": { "name": "blocks.38." }, "blocks_39_": { "name": "blocks.39." }, "blocks_3_": { "name": "blocks.3." }, "blocks_4_": { "name": "blocks.4." }, "blocks_5_": { "name": "blocks.5." }, "blocks_6_": { "name": "blocks.6." }, "blocks_7_": { "name": "blocks.7." }, "blocks_8_": { "name": "blocks.8." }, "blocks_9_": { "name": "blocks.9." }, "head_": { "name": "head." }, "img_emb_": { "name": "img_emb." }, "model1": { "name": "模型 1" }, "model2": { "name": "模型 2" }, "patch_embedding_": { "name": "patch_embedding." }, "text_embedding_": { "name": "text_embedding." }, "time_embedding_": { "name": "time_embedding." }, "time_projection_": { "name": "time_projection." } } };
const ModelPatchLoader = { "display_name": "模型修補載入器", "inputs": { "name": { "name": "名稱" } } };
const ModelSamplingAuraFlow = { "display_name": "模型取樣 AuraFlow", "inputs": { "model": { "name": "model" }, "shift": { "name": "偏移" } } };
const ModelSamplingContinuousEDM = { "display_name": "模型取樣連續 EDM", "inputs": { "model": { "name": "model" }, "sampling": { "name": "取樣" }, "sigma_max": { "name": "最大 sigma" }, "sigma_min": { "name": "最小 sigma" } } };
const ModelSamplingContinuousV = { "display_name": "模型取樣連續 V", "inputs": { "model": { "name": "model" }, "sampling": { "name": "取樣" }, "sigma_max": { "name": "最大 sigma" }, "sigma_min": { "name": "最小 sigma" } } };
const ModelSamplingDiscrete = { "display_name": "模型取樣離散", "inputs": { "model": { "name": "model" }, "sampling": { "name": "取樣" }, "zsnr": { "name": "zsnr" } } };
const ModelSamplingFlux = { "display_name": "模型取樣 Flux", "inputs": { "base_shift": { "name": "基礎偏移" }, "height": { "name": "高度" }, "max_shift": { "name": "最大偏移" }, "model": { "name": "model" }, "width": { "name": "寬度" } } };
const ModelSamplingLTXV = { "display_name": "模型取樣 LTXV", "inputs": { "base_shift": { "name": "基礎偏移" }, "latent": { "name": "潛在空間" }, "max_shift": { "name": "最大偏移" }, "model": { "name": "model" } }, "outputs": { "0": { "tooltip": null } } };
const ModelSamplingSD3 = { "display_name": "模型取樣 SD3", "inputs": { "model": { "name": "model" }, "shift": { "name": "偏移" } } };
const ModelSamplingStableCascade = { "display_name": "模型取樣 Stable Cascade", "inputs": { "model": { "name": "model" }, "shift": { "name": "偏移" } } };
const ModelSave = { "display_name": "儲存模型", "inputs": { "filename_prefix": { "name": "檔名前綴" }, "model": { "name": "model" } } };
const MoonvalleyImg2VideoNode = { "description": "Moonvalley Marey 圖像轉影片節點", "display_name": "Moonvalley Marey 圖像轉影片", "inputs": { "control_after_generate": { "name": "生成後控制" }, "image": { "name": "圖像", "tooltip": "用於生成影片的參考圖像" }, "negative_prompt": { "name": "負向提示詞", "tooltip": "負向提示詞文字" }, "prompt": { "name": "提示詞" }, "prompt_adherence": { "name": "提示詞遵循度", "tooltip": "生成控制的引導尺度" }, "resolution": { "name": "解析度", "tooltip": "輸出影片的解析度" }, "seed": { "name": "種子值", "tooltip": "隨機種子值" }, "steps": { "name": "步數", "tooltip": "去噪步數" } }, "outputs": { "0": { "tooltip": null } } };
const MoonvalleyTxt2VideoNode = { "display_name": "Moonvalley Marey 文字轉影片", "inputs": { "control_after_generate": { "name": "生成後控制" }, "negative_prompt": { "name": "負向提示詞", "tooltip": "負向提示詞文字" }, "prompt": { "name": "提示詞" }, "prompt_adherence": { "name": "提示詞遵循度", "tooltip": "生成控制的引導尺度" }, "resolution": { "name": "解析度", "tooltip": "輸出影片的解析度" }, "seed": { "name": "種子值", "tooltip": "隨機種子值" }, "steps": { "name": "步數", "tooltip": "推理步數" } }, "outputs": { "0": { "tooltip": null } } };
const MoonvalleyVideo2VideoNode = { "display_name": "Moonvalley Marey 影片轉影片", "inputs": { "control_type": { "name": "控制類型" }, "motion_intensity": { "name": "motion_intensity", "tooltip": "僅在 control_type 為 'Motion Transfer' 時使用" }, "negative_prompt": { "name": "負向提示詞", "tooltip": "負向提示詞文字" }, "prompt": { "name": "提示詞", "tooltip": "描述要生成的影片" }, "seed": { "name": "種子值", "tooltip": "隨機種子值" }, "steps": { "name": "步數", "tooltip": "推理步數" }, "video": { "name": "影片", "tooltip": "用於生成輸出影片的參考影片。必須至少5秒長。超過5秒的影片將自動修剪。僅支援MP4格式。" } }, "outputs": { "0": { "tooltip": null } } };
const Morphology = { "display_name": "ImageMorphology", "inputs": { "image": { "name": "影像" }, "kernel_size": { "name": "核心大小" }, "operation": { "name": "操作" } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIChatConfig = { "description": "允許為 OpenAI 聊天節點指定進階配置選項。", "display_name": "OpenAI ChatGPT 進階選項", "inputs": { "instructions": { "name": "instructions", "tooltip": "模型生成回應的指示說明" }, "max_output_tokens": { "name": "max_output_tokens", "tooltip": "為回應生成的 token 數量的上限，包括可見的輸出 token" }, "truncation": { "name": "truncation", "tooltip": "用於模型回應的截斷策略。auto：如果此回應和先前回應的上下文超過模型的上下文窗口大小，模型將通過丟棄對話中間的輸入項目來截斷回應以適應上下文窗口。disabled：如果模型回應將超過模型的上下文窗口大小，請求將失敗並返回 400 錯誤" } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIChatNode = { "description": "從 OpenAI 模型生成文字回應。", "display_name": "OpenAI ChatGPT", "inputs": { "advanced_options": { "name": "advanced_options", "tooltip": "模型的選項配置。接受來自 OpenAI 聊天進階選項節點的輸入。" }, "files": { "name": "files", "tooltip": "可選的文件，用作模型的上下文。接受來自 OpenAI 聊天輸入文件節點的輸入。" }, "images": { "name": "images", "tooltip": "可選的圖像，用作模型的上下文。要包含多個圖像，可以使用批次圖像節點。" }, "model": { "name": "model", "tooltip": "用於生成回應的模型" }, "persist_context": { "name": "persist_context", "tooltip": "此參數已棄用且無效。" }, "prompt": { "name": "prompt", "tooltip": "模型的文字輸入，用於生成回應。" } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIDalle2 = { "description": "透過 OpenAI 的 DALL·E 2 端點同步產生影像。", "display_name": "OpenAI DALL·E 2", "inputs": { "control_after_generate": { "name": "生成後控制" }, "image": { "name": "參考影像", "tooltip": "可選的參考影像，用於影像編輯。" }, "mask": { "name": "遮罩", "tooltip": "可選的遮罩，用於修補（白色區域將被取代）" }, "n": { "name": "數量", "tooltip": "要產生多少張影像" }, "prompt": { "name": "提示詞", "tooltip": "DALL·E 的文字提示" }, "seed": { "name": "種子", "tooltip": "後端尚未實作" }, "size": { "name": "尺寸", "tooltip": "影像尺寸" } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIDalle3 = { "description": "透過 OpenAI 的 DALL·E 3 端點同步產生影像。", "display_name": "OpenAI DALL·E 3", "inputs": { "control_after_generate": { "name": "生成後控制" }, "prompt": { "name": "提示詞", "tooltip": "DALL·E 的文字提示" }, "quality": { "name": "畫質", "tooltip": "影像品質" }, "seed": { "name": "種子", "tooltip": "後端尚未實作" }, "size": { "name": "尺寸", "tooltip": "影像尺寸" }, "style": { "name": "風格", "tooltip": "「生動」會讓模型傾向產生超現實且戲劇化的影像。「自然」則會讓模型產生較自然、不那麼超現實的影像。" } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIGPTImage1 = { "description": "透過 OpenAI 的 GPT Image 1 端點同步產生影像。", "display_name": "OpenAI GPT Image 1", "inputs": { "background": { "name": "背景", "tooltip": "回傳有或無背景的影像" }, "control_after_generate": { "name": "生成後控制" }, "image": { "name": "參考影像", "tooltip": "可選的參考影像，用於影像編輯。" }, "mask": { "name": "遮罩", "tooltip": "可選的修補遮罩（白色區域將被取代）" }, "n": { "name": "數量", "tooltip": "要產生多少張影像" }, "prompt": { "name": "提示詞", "tooltip": "用於 GPT Image 1 的文字提示" }, "quality": { "name": "品質", "tooltip": "影像品質，會影響費用與生成時間。" }, "seed": { "name": "種子值", "tooltip": "後端尚未實作" }, "size": { "name": "尺寸", "tooltip": "影像尺寸" } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIInputFiles = { "description": "載入並準備輸入文件（文字、pdf 等）以作為 OpenAI 聊天節點的輸入。生成回應時，OpenAI 模型將讀取這些文件。🛈 提示：可以與其他 OpenAI 輸入文件節點鏈接使用。", "display_name": "OpenAI ChatGPT 輸入文件", "inputs": { "OPENAI_INPUT_FILES": { "name": "OPENAI_INPUT_FILES", "tooltip": "可選的額外文件，與從此節點載入的文件批次處理。允許鏈接輸入文件，以便單個訊息可以包含多個輸入文件。" }, "file": { "name": "file", "tooltip": "要作為模型上下文包含的輸入文件。目前僅接受文字 (.txt) 和 PDF (.pdf) 文件。" } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIVideoSora2 = { "description": "OpenAI 影片和音訊生成。", "display_name": "OpenAI Sora - 影片", "inputs": { "control_after_generate": { "name": "control after generate" }, "duration": { "name": "duration" }, "image": { "name": "image" }, "model": { "name": "model" }, "prompt": { "name": "prompt", "tooltip": "引導文字；如果存在輸入圖像，可以為空。" }, "seed": { "name": "seed", "tooltip": "決定節點是否應重新運行的種子；無論種子如何，實際結果都是非確定性的。" }, "size": { "name": "size" } }, "outputs": { "0": { "tooltip": null } } };
const OptimalStepsScheduler = { "display_name": "最佳步數排程器", "inputs": { "denoise": { "name": "去雜訊強度" }, "model_type": { "name": "model_type" }, "steps": { "name": "步驟數" } }, "outputs": { "0": { "tooltip": null } } };
const PairConditioningCombine = { "display_name": "Cond Pair 組合", "inputs": { "negative_A": { "name": "negative_A" }, "negative_B": { "name": "negative_B" }, "positive_A": { "name": "positive_A" }, "positive_B": { "name": "positive_B" } }, "outputs": { "0": { "name": "正向" }, "1": { "name": "負向" } } };
const PairConditioningSetDefaultCombine = { "display_name": "Cond 配對組預設合併", "inputs": { "hooks": { "name": "hooks" }, "negative": { "name": "負向" }, "negative_DEFAULT": { "name": "負向_預設" }, "positive": { "name": "正向" }, "positive_DEFAULT": { "name": "正向_預設" } }, "outputs": { "0": { "name": "正向" }, "1": { "name": "負向" } } };
const PairConditioningSetProperties = { "display_name": "條件配對組屬性", "inputs": { "hooks": { "name": "hooks" }, "mask": { "name": "遮罩" }, "negative_NEW": { "name": "負向_NEW" }, "positive_NEW": { "name": "正向_NEW" }, "set_cond_area": { "name": "設定條件區域" }, "strength": { "name": "強度" }, "timesteps": { "name": "時間步驟" } }, "outputs": { "0": { "name": "正向" }, "1": { "name": "負向" } } };
const PairConditioningSetPropertiesAndCombine = { "display_name": "Cond Pair 設定屬性並合併", "inputs": { "hooks": { "name": "hooks" }, "mask": { "name": "遮罩" }, "negative": { "name": "負向" }, "negative_NEW": { "name": "negative_NEW" }, "positive": { "name": "正向" }, "positive_NEW": { "name": "positive_NEW" }, "set_cond_area": { "name": "設定條件區域" }, "strength": { "name": "強度" }, "timesteps": { "name": "時間步驟" } }, "outputs": { "0": { "name": "正向" }, "1": { "name": "負向" } } };
const PatchModelAddDownscale = { "display_name": "PatchModelAddDownscale（Kohya Deep Shrink）", "inputs": { "block_number": { "name": "區塊編號" }, "downscale_after_skip": { "name": "跳過後縮小" }, "downscale_factor": { "name": "縮小比例" }, "downscale_method": { "name": "縮小方法" }, "end_percent": { "name": "結束百分比" }, "model": { "name": "model" }, "start_percent": { "name": "起始百分比" }, "upscale_method": { "name": "放大方法" } }, "outputs": { "0": { "tooltip": null } } };
const PerpNeg = { "display_name": "Perp-Neg（已被 PerpNegGuider 棄用）", "inputs": { "empty_conditioning": { "name": "empty_conditioning" }, "model": { "name": "model" }, "neg_scale": { "name": "neg_scale" } }, "outputs": { "0": { "tooltip": null } } };
const PerpNegGuider = { "display_name": "垂直負向引導器", "inputs": { "cfg": { "name": "cfg" }, "empty_conditioning": { "name": "空條件" }, "model": { "name": "model" }, "neg_scale": { "name": "負向比例" }, "negative": { "name": "負向" }, "positive": { "name": "正向" } }, "outputs": { "0": { "tooltip": null } } };
const PerturbedAttentionGuidance = { "display_name": "擾動注意力引導", "inputs": { "model": { "name": "模型" }, "scale": { "name": "比例" } }, "outputs": { "0": { "tooltip": null } } };
const PhotoMakerEncode = { "display_name": "PhotoMaker 編碼", "inputs": { "clip": { "name": "clip" }, "image": { "name": "影像" }, "photomaker": { "name": "photomaker" }, "text": { "name": "文字" } }, "outputs": { "0": { "tooltip": null } } };
const PhotoMakerLoader = { "display_name": "PhotoMaker 載入器", "inputs": { "photomaker_model_name": { "name": "photomaker_model_name" } }, "outputs": { "0": { "tooltip": null } } };
const PixverseImageToVideoNode = { "description": "根據提示詞與輸出尺寸同步生成影片。", "display_name": "PixVerse 影像轉影片", "inputs": { "control_after_generate": { "name": "生成後控制" }, "duration_seconds": { "name": "持續秒數" }, "image": { "name": "圖像" }, "motion_mode": { "name": "動作模式" }, "negative_prompt": { "name": "負向提示詞", "tooltip": "可選的文字描述，用於排除不希望出現在圖像中的元素。" }, "pixverse_template": { "name": "PixVerse 樣板", "tooltip": "可選的樣板，由 PixVerse Template 節點建立，用於影響生成風格。" }, "prompt": { "name": "提示詞", "tooltip": "用於影片生成的提示詞" }, "quality": { "name": "品質" }, "seed": { "name": "種子值", "tooltip": "影片生成用的種子值。" } }, "outputs": { "0": { "tooltip": null } } };
const PixverseTemplateNode = { "display_name": "PixVerse 範本", "inputs": { "template": { "name": "範本" } }, "outputs": { "0": { "name": "pixverse_template", "tooltip": null } } };
const PixverseTextToVideoNode = { "description": "根據提示詞與輸出尺寸同步生成影片。", "display_name": "PixVerse 文字轉影片", "inputs": { "aspect_ratio": { "name": "長寬比" }, "control_after_generate": { "name": "生成後控制" }, "duration_seconds": { "name": "影片長度（秒）" }, "motion_mode": { "name": "動作模式" }, "negative_prompt": { "name": "負向提示詞", "tooltip": "可選的文字描述，用於排除不希望出現在影像中的元素。" }, "pixverse_template": { "name": "PixVerse 樣板", "tooltip": "可選的樣板，由 PixVerse Template 節點建立，用於影響生成風格。" }, "prompt": { "name": "提示詞", "tooltip": "用於影片生成的提示詞" }, "quality": { "name": "品質" }, "seed": { "name": "種子值", "tooltip": "用於影片生成的種子值。" } }, "outputs": { "0": { "tooltip": null } } };
const PixverseTransitionVideoNode = { "description": "根據提示詞與輸出尺寸同步生成影片。", "display_name": "PixVerse 轉場影片", "inputs": { "control_after_generate": { "name": "生成後控制" }, "duration_seconds": { "name": "持續秒數" }, "first_frame": { "name": "第一幀" }, "last_frame": { "name": "最後一幀" }, "motion_mode": { "name": "動作模式" }, "negative_prompt": { "name": "負向提示詞", "tooltip": "可選的文字描述，用於排除不希望出現在影像中的元素。" }, "prompt": { "name": "提示詞", "tooltip": "用於影片生成的提示詞" }, "quality": { "name": "品質" }, "seed": { "name": "種子值", "tooltip": "影片生成用的種子值。" } }, "outputs": { "0": { "tooltip": null } } };
const PolyexponentialScheduler = { "display_name": "多指數排程器", "inputs": { "rho": { "name": "rho" }, "sigma_max": { "name": "最大 sigma" }, "sigma_min": { "name": "最小 sigma" }, "steps": { "name": "步驟數" } } };
const PorterDuffImageComposite = { "display_name": "Porter-Duff 影像合成", "inputs": { "destination": { "name": "destination" }, "destination_alpha": { "name": "destination_alpha" }, "mode": { "name": "模式" }, "source": { "name": "source" }, "source_alpha": { "name": "source_alpha" } }, "outputs": { "0": { "tooltip": null }, "1": { "tooltip": null } } };
const Preview3D = { "display_name": "3D 預覽", "inputs": { "camera_info": { "name": "camera_info" }, "image": { "name": "影像" }, "model_file": { "name": "model_file" } } };
const PreviewAny = { "display_name": "預覽任意", "inputs": { "preview": {}, "source": { "name": "來源" } } };
const PreviewAudio = { "display_name": "預覽音訊", "inputs": { "audio": { "name": "音訊" }, "audioUI": { "name": "音訊介面" } } };
const PreviewImage = { "description": "將輸入圖片儲存到您的 ComfyUI 輸出目錄。", "display_name": "預覽圖片", "inputs": { "images": { "name": "圖片" } } };
const PrimitiveBoolean = { "display_name": "布林值", "inputs": { "value": { "name": "值" } }, "outputs": { "0": { "tooltip": null } } };
const PrimitiveFloat = { "display_name": "浮點數", "inputs": { "value": { "name": "數值" } }, "outputs": { "0": { "tooltip": null } } };
const PrimitiveInt = { "display_name": "整數", "inputs": { "control_after_generate": { "name": "生成後控制" }, "value": { "name": "數值" } }, "outputs": { "0": { "tooltip": null } } };
const PrimitiveString = { "display_name": "字串", "inputs": { "value": { "name": "值" } }, "outputs": { "0": { "tooltip": null } } };
const PrimitiveStringMultiline = { "display_name": "字串（多行）", "inputs": { "value": { "name": "值" } }, "outputs": { "0": { "tooltip": null } } };
const QuadrupleCLIPLoader = { "description": "[配方]\n\nhidream: long clip-l、long clip-g、t5xxl、llama_8b_3.1_instruct", "display_name": "QuadrupleCLIPLoader", "inputs": { "clip_name1": { "name": "clip_name1" }, "clip_name2": { "name": "clip_name2" }, "clip_name3": { "name": "clip_name3" }, "clip_name4": { "name": "clip_name4" } }, "outputs": { "0": { "tooltip": null } } };
const QwenImageDiffsynthControlnet = { "display_name": "QwenImageDiffsynthControlnet", "inputs": { "image": { "name": "image" }, "mask": { "name": "mask" }, "model": { "name": "model" }, "model_patch": { "name": "model_patch" }, "strength": { "name": "strength" }, "vae": { "name": "vae" } } };
const RandomNoise = { "display_name": "隨機雜訊", "inputs": { "control_after_generate": { "name": "生成後控制" }, "noise_seed": { "name": "noise_seed" } } };
const RebatchImages = { "display_name": "重新分批影像", "inputs": { "batch_size": { "name": "批次大小" }, "images": { "name": "影像" } }, "outputs": { "0": { "tooltip": null } } };
const RebatchLatents = { "display_name": "重新分批 Latents", "inputs": { "batch_size": { "name": "批次大小" }, "latents": { "name": "latents" } }, "outputs": { "0": { "tooltip": null } } };
const RecordAudio = { "display_name": "錄製音訊", "inputs": { "audio": { "name": "音訊" } } };
const RecraftColorRGB = { "description": "透過選擇特定的 RGB 數值來建立 Recraft 色彩。", "display_name": "Recraft 色彩 RGB", "inputs": { "b": { "name": "b", "tooltip": "色彩的藍色值。" }, "g": { "name": "g", "tooltip": "色彩的綠色值。" }, "r": { "name": "r", "tooltip": "色彩的紅色值。" }, "recraft_color": { "name": "recraft_color" } }, "outputs": { "0": { "name": "recraft_color", "tooltip": null } } };
const RecraftControls = { "description": "建立 Recraft 控制項以自訂 Recraft 生成。", "display_name": "Recraft 控制項", "inputs": { "background_color": { "name": "背景顏色" }, "colors": { "name": "顏色" } }, "outputs": { "0": { "name": "recraft_controls", "tooltip": null } } };
const RecraftCreativeUpscaleNode = { "description": "同步放大影像。\n使用「creative upscale」工具增強所提供的點陣影像，提升解析度，特別強化細節與人臉。", "display_name": "Recraft Creative 影像放大", "inputs": { "image": { "name": "影像" } }, "outputs": { "0": { "tooltip": null } } };
const RecraftCrispUpscaleNode = { "description": "同步放大圖片。\n使用「清晰放大」工具增強所提供的點陣圖，提升解析度，讓圖片更加銳利與乾淨。", "display_name": "Recraft 清晰放大圖片", "inputs": { "image": { "name": "圖片" } }, "outputs": { "0": { "tooltip": null } } };
const RecraftImageInpaintingNode = { "description": "根據提示詞與遮罩修改影像。", "display_name": "Recraft 影像修補", "inputs": { "control_after_generate": { "name": "生成後控制" }, "image": { "name": "影像" }, "mask": { "name": "遮罩" }, "n": { "name": "數量", "tooltip": "要生成的影像數量。" }, "negative_prompt": { "name": "負向提示詞", "tooltip": "可選的文字描述，用於指定影像中不希望出現的元素。" }, "prompt": { "name": "提示詞", "tooltip": "用於影像生成的提示詞。" }, "recraft_style": { "name": "Recraft 風格" }, "seed": { "name": "種子", "tooltip": "決定節點是否重新執行的種子；實際結果無論種子如何都不具決定性。" } }, "outputs": { "0": { "tooltip": null } } };
const RecraftImageToImageNode = { "description": "根據提示詞與強度修改影像。", "display_name": "Recraft 影像轉影像", "inputs": { "control_after_generate": { "name": "生成後控制" }, "image": { "name": "影像" }, "n": { "name": "數量", "tooltip": "要生成的影像數量。" }, "negative_prompt": { "name": "負向提示詞", "tooltip": "可選的文字描述，用於指定影像中不希望出現的元素。" }, "prompt": { "name": "提示詞", "tooltip": "用於生成影像的提示詞。" }, "recraft_controls": { "name": "recraft 控制", "tooltip": "可選的額外控制，透過 Recraft Controls 節點進行生成調整。" }, "recraft_style": { "name": "recraft 風格" }, "seed": { "name": "種子值", "tooltip": "決定此節點是否重新執行的種子值；實際結果無論種子值如何都不具決定性。" }, "strength": { "name": "強度", "tooltip": "定義與原始影像的差異，範圍為 [0, 1]，0 表示幾乎相同，1 表示極大差異。" } }, "outputs": { "0": { "tooltip": null } } };
const RecraftRemoveBackgroundNode = { "description": "從圖片中去除背景，並返回處理後的圖片與遮罩。", "display_name": "Recraft 去背", "inputs": { "image": { "name": "圖片" } }, "outputs": { "0": { "tooltip": null }, "1": { "tooltip": null } } };
const RecraftReplaceBackgroundNode = { "description": "根據提供的提示詞，替換圖片背景。", "display_name": "Recraft 更換背景", "inputs": { "control_after_generate": { "name": "生成後控制" }, "image": { "name": "影像" }, "n": { "name": "生成數量", "tooltip": "要生成的圖片數量。" }, "negative_prompt": { "name": "負向提示詞", "tooltip": "可選的文字描述，用於指定圖片中不希望出現的元素。" }, "prompt": { "name": "提示詞", "tooltip": "用於生成圖片的提示詞。" }, "recraft_style": { "name": "Recraft 風格" }, "seed": { "name": "種子值", "tooltip": "用於決定節點是否重新執行的種子值；實際結果無論種子值如何都不具決定性。" } }, "outputs": { "0": { "tooltip": null } } };
const RecraftStyleV3DigitalIllustration = { "description": "選擇 realistic_image 風格及可選的子風格。", "display_name": "Recraft 風格 - 數位插畫", "inputs": { "substyle": { "name": "子風格" } }, "outputs": { "0": { "name": "recraft_style", "tooltip": null } } };
const RecraftStyleV3InfiniteStyleLibrary = { "description": "根據 Recraft 無限風格庫中已存在的 UUID 選擇風格。", "display_name": "Recraft 風格 - 無限風格庫", "inputs": { "style_id": { "name": "style_id", "tooltip": "來自無限風格庫的風格 UUID。" } }, "outputs": { "0": { "name": "recraft_style", "tooltip": null } } };
const RecraftStyleV3LogoRaster = { "description": "選擇 realistic_image 風格及可選的子風格。", "display_name": "Recraft Style - 標誌點陣圖", "inputs": { "substyle": { "name": "子風格" } }, "outputs": { "0": { "name": "recraft_style", "tooltip": null } } };
const RecraftStyleV3RealisticImage = { "description": "選擇 realistic_image 風格及可選的子風格。", "display_name": "Recraft 風格 - 實景圖像", "inputs": { "substyle": { "name": "子風格" } }, "outputs": { "0": { "name": "recraft_style", "tooltip": null } } };
const RecraftTextToImageNode = { "description": "根據提示詞與解析度同步生成圖像。", "display_name": "Recraft 文字轉圖像", "inputs": { "control_after_generate": { "name": "生成後控制" }, "n": { "name": "數量", "tooltip": "要生成的圖像數量。" }, "negative_prompt": { "name": "負向提示詞", "tooltip": "可選的文字描述，用於指定圖像中不希望出現的元素。" }, "prompt": { "name": "提示詞", "tooltip": "用於圖像生成的提示詞。" }, "recraft_controls": { "name": "Recraft 控制", "tooltip": "透過 Recraft Controls 節點進行額外生成控制（可選）。" }, "recraft_style": { "name": "recraft_style" }, "seed": { "name": "種子", "tooltip": "決定節點是否重新執行的種子；實際結果無論種子如何都不具決定性。" }, "size": { "name": "尺寸", "tooltip": "生成圖像的尺寸。" } }, "outputs": { "0": { "tooltip": null } } };
const RecraftTextToVectorNode = { "description": "根據提示詞與解析度同步產生 SVG。", "display_name": "Recraft 文字轉向量", "inputs": { "control_after_generate": { "name": "生成後控制" }, "n": { "name": "數量", "tooltip": "要生成的圖片數量。" }, "negative_prompt": { "name": "負向提示詞", "tooltip": "可選的文字描述，用於指定圖片中不希望出現的元素。" }, "prompt": { "name": "提示詞", "tooltip": "用於生成圖片的提示詞。" }, "recraft_controls": { "name": "Recraft 控制", "tooltip": "透過 Recraft Controls 節點進行額外生成控制（可選）。" }, "seed": { "name": "種子", "tooltip": "決定節點是否重新執行的種子；實際結果無論種子如何都不具決定性。" }, "size": { "name": "尺寸", "tooltip": "生成圖片的尺寸。" }, "substyle": { "name": "子風格" } }, "outputs": { "0": { "tooltip": null } } };
const RecraftVectorizeImageNode = { "description": "從輸入圖片同步產生 SVG。", "display_name": "Recraft 向量化圖片", "inputs": { "image": { "name": "圖片" } }, "outputs": { "0": { "tooltip": null } } };
const ReferenceLatent = { "description": "此節點為編輯模型設定引導潛在空間。如果模型支援，您可以串聯多個節點來設定多個參考圖像。", "display_name": "參考潛在空間", "inputs": { "conditioning": { "name": "條件設定" }, "latent": { "name": "潛在空間" } }, "outputs": { "0": { "tooltip": null } } };
const RegexExtract = { "display_name": "正則表達式提取", "inputs": { "case_insensitive": { "name": "忽略大小寫" }, "dotall": { "name": "點號匹配所有" }, "group_index": { "name": "群組索引" }, "mode": { "name": "模式" }, "multiline": { "name": "多行模式" }, "regex_pattern": { "name": "正則表達式模式" }, "string": { "name": "字串" } }, "outputs": { "0": { "tooltip": null } } };
const RegexMatch = { "display_name": "正則表達式匹配", "inputs": { "case_insensitive": { "name": "忽略大小寫" }, "dotall": { "name": "點號匹配所有" }, "multiline": { "name": "多行模式" }, "regex_pattern": { "name": "正則表達式模式" }, "string": { "name": "字串" } }, "outputs": { "0": { "name": "匹配結果", "tooltip": null } } };
const RegexReplace = { "description": "使用正則表達式模式尋找並替換文字。", "display_name": "正則表達式替換", "inputs": { "case_insensitive": { "name": "忽略大小寫" }, "count": { "name": "計數", "tooltip": "最大替換次數。設為 0 可替換所有出現（預設值）。設為 1 僅替換第一個匹配，2 替換前兩個匹配，依此類推。" }, "dotall": { "name": "點號匹配所有", "tooltip": "啟用時，點號（.）字符將匹配包括換行符在內的任何字符。停用時，點號不會匹配換行符。" }, "multiline": { "name": "多行模式" }, "regex_pattern": { "name": "正則表達式模式" }, "replace": { "name": "替換內容" }, "string": { "name": "字串" } }, "outputs": { "0": { "tooltip": null } } };
const RenormCFG = { "display_name": "RenormCFG", "inputs": { "cfg_trunc": { "name": "cfg_trunc" }, "model": { "name": "model" }, "renorm_cfg": { "name": "renorm_cfg" } }, "outputs": { "0": { "tooltip": null } } };
const RepeatImageBatch = { "display_name": "RepeatImageBatch", "inputs": { "amount": { "name": "數量" }, "image": { "name": "影像" } } };
const RepeatLatentBatch = { "display_name": "重複 Latent 批次", "inputs": { "amount": { "name": "數量" }, "samples": { "name": "樣本" } } };
const RescaleCFG = { "display_name": "RescaleCFG", "inputs": { "model": { "name": "model" }, "multiplier": { "name": "倍率" } } };
const ResizeAndPadImage = { "display_name": "調整尺寸並填充圖像", "inputs": { "image": { "name": "圖像" }, "interpolation": { "name": "插值方法" }, "padding_color": { "name": "填充顏色" }, "target_height": { "name": "目標高度" }, "target_width": { "name": "目標寬度" } } };
const Rodin3D_Detail = { "description": "使用 Rodin API 生成 3D 資源", "display_name": "Rodin 3D 生成 - 細節生成", "inputs": { "Images": { "name": "圖像" }, "Material_Type": { "name": "材質類型" }, "Polygon_count": { "name": "多邊形數量" }, "Seed": { "name": "種子值" } }, "outputs": { "0": { "name": "3D 模型路徑", "tooltip": null } } };
const Rodin3D_Gen2 = { "description": "使用 Rodin API 生成 3D 資源", "display_name": "Rodin 3D 生成 - Gen-2 生成", "inputs": { "Images": { "name": "圖像" }, "Material_Type": { "name": "材質類型" }, "Polygon_count": { "name": "多邊形數量" }, "Seed": { "name": "種子值" }, "TAPose": { "name": "TAPose" } }, "outputs": { "0": { "name": "3D 模型路徑", "tooltip": null } } };
const Rodin3D_Regular = { "description": "使用 Rodin API 生成 3D 資源", "display_name": "Rodin 3D 生成 - 常規生成", "inputs": { "Images": { "name": "圖片" }, "Material_Type": { "name": "材質類型" }, "Polygon_count": { "name": "多邊形數量" }, "Seed": { "name": "種子值" } }, "outputs": { "0": { "name": "3D 模型路徑", "tooltip": null } } };
const Rodin3D_Sketch = { "description": "使用 Rodin API 生成 3D 資源", "display_name": "Rodin 3D 生成 - 草圖生成", "inputs": { "Images": { "name": "圖片" }, "Seed": { "name": "種子值" } }, "outputs": { "0": { "name": "3D 模型路徑", "tooltip": null } } };
const Rodin3D_Smooth = { "description": "使用 Rodin API 生成 3D 資源", "display_name": "Rodin 3D 生成 - 平滑生成", "inputs": { "Images": { "name": "圖片" }, "Material_Type": { "name": "材質類型" }, "Polygon_count": { "name": "多邊形數量" }, "Seed": { "name": "種子值" } }, "outputs": { "0": { "name": "3D 模型路徑", "tooltip": null } } };
const RunwayFirstLastFrameNode = { "description": "上傳首尾關鍵幀，草擬提示詞，並生成影片。對於較複雜的轉場（例如最後一幀與第一幀完全不同的情況），較長的 10 秒持續時間可能更有利，這能讓生成過程有更多時間在兩個輸入之間平滑過渡。開始前，請先閱讀這些最佳實踐指南，確保您的輸入選擇能為生成成功奠定基礎：https://help.runwayml.com/hc/en-us/articles/34170748696595-Creating-with-Keyframes-on-Gen-3。", "display_name": "Runway 首尾幀轉影片", "inputs": { "control_after_generate": { "name": "生成後控制" }, "duration": { "name": "持續時間" }, "end_frame": { "name": "結束幀", "tooltip": "用於影片的結束幀。僅支援 gen3a_turbo。" }, "prompt": { "name": "提示詞", "tooltip": "生成用的文字提示詞" }, "ratio": { "name": "比例" }, "seed": { "name": "種子值", "tooltip": "生成用的隨機種子值" }, "start_frame": { "name": "起始幀", "tooltip": "用於影片的起始幀" } }, "outputs": { "0": { "tooltip": null } } };
const RunwayImageToVideoNodeGen3a = { "description": "使用 Gen3a Turbo 模型從單一起始幀生成影片。開始前，請先閱讀這些最佳實踐指南，確保您的輸入選擇能為生成成功奠定基礎：https://help.runwayml.com/hc/en-us/articles/33927968552339-Creating-with-Act-One-on-Gen-3-Alpha-and-Turbo。", "display_name": "Runway 圖片轉影片 (Gen3a Turbo)", "inputs": { "control_after_generate": { "name": "生成後控制" }, "duration": { "name": "持續時間" }, "prompt": { "name": "提示詞", "tooltip": "生成用的文字提示詞" }, "ratio": { "name": "比例" }, "seed": { "name": "種子值", "tooltip": "生成用的隨機種子值" }, "start_frame": { "name": "起始幀", "tooltip": "用於影片的起始幀" } }, "outputs": { "0": { "tooltip": null } } };
const RunwayImageToVideoNodeGen4 = { "description": "使用 Gen4 Turbo 模型從單一起始幀生成影片。開始前，請先閱讀這些最佳實踐指南，確保您的輸入選擇能為生成成功奠定基礎：https://help.runwayml.com/hc/en-us/articles/37327109429011-Creating-with-Gen-4-Video。", "display_name": "Runway 圖片轉影片 (Gen4 Turbo)", "inputs": { "control_after_generate": { "name": "control after generate" }, "duration": { "name": "duration" }, "prompt": { "name": "提示詞", "tooltip": "生成用的文字提示詞" }, "ratio": { "name": "ratio" }, "seed": { "name": "seed", "tooltip": "用於生成的隨機種子" }, "start_frame": { "name": "start_frame", "tooltip": "用於影片的起始影格" } }, "outputs": { "0": { "tooltip": null } } };
const RunwayTextToImageNode = { "description": "使用 Runway 的 Gen 4 模型從文字提示生成圖像。您也可以包含參考圖像來引導生成過程。", "display_name": "Runway 文字轉圖像", "inputs": { "prompt": { "name": "prompt", "tooltip": "用於生成的文字提示" }, "ratio": { "name": "ratio" }, "reference_image": { "name": "reference_image", "tooltip": "可選的參考圖像，用於引導生成過程" } }, "outputs": { "0": { "tooltip": null } } };
const SDTurboScheduler = { "display_name": "SDTurboScheduler", "inputs": { "denoise": { "name": "去雜訊強度" }, "model": { "name": "model" }, "steps": { "name": "步驟" } } };
const SD_4XUpscale_Conditioning = { "display_name": "SD_4XUpscale_Conditioning", "inputs": { "images": { "name": "images" }, "negative": { "name": "負向" }, "noise_augmentation": { "name": "雜訊增強" }, "positive": { "name": "正向" }, "scale_ratio": { "name": "縮放比例" } }, "outputs": { "0": { "name": "正向", "tooltip": null }, "1": { "name": "負向", "tooltip": null }, "2": { "name": "潛在空間", "tooltip": null } } };
const SV3D_Conditioning = { "display_name": "SV3D_Conditioning", "inputs": { "clip_vision": { "name": "clip_vision" }, "elevation": { "name": "仰角" }, "height": { "name": "高度" }, "init_image": { "name": "初始影像" }, "vae": { "name": "vae" }, "video_frames": { "name": "影片幀數" }, "width": { "name": "寬度" } }, "outputs": { "0": { "name": "正向", "tooltip": null }, "1": { "name": "負向", "tooltip": null }, "2": { "name": "潛在空間", "tooltip": null } } };
const SVD_img2vid_Conditioning = { "display_name": "SVD_img2vid_Conditioning", "inputs": { "augmentation_level": { "name": "增強等級" }, "clip_vision": { "name": "clip_vision" }, "fps": { "name": "每秒幀數 (FPS)" }, "height": { "name": "高度" }, "init_image": { "name": "初始影像" }, "motion_bucket_id": { "name": "動作分組 ID" }, "vae": { "name": "vae" }, "video_frames": { "name": "影片幀數" }, "width": { "name": "寬度" } }, "outputs": { "0": { "name": "正向" }, "1": { "name": "負向" }, "2": { "name": "潛在空間" } } };
const SamplerCustom = { "display_name": "SamplerCustom", "inputs": { "add_noise": { "name": "加入雜訊" }, "cfg": { "name": "cfg" }, "control_after_generate": { "name": "生成後控制" }, "latent_image": { "name": "latent 影像" }, "model": { "name": "model" }, "negative": { "name": "負向提示" }, "noise_seed": { "name": "雜訊種子" }, "positive": { "name": "正向提示" }, "sampler": { "name": "取樣器" }, "sigmas": { "name": "Sigma 值" } }, "outputs": { "0": { "name": "輸出" }, "1": { "name": "去噪輸出" } } };
const SamplerCustomAdvanced = { "display_name": "SamplerCustomAdvanced", "inputs": { "guider": { "name": "引導器" }, "latent_image": { "name": "latent 影像" }, "noise": { "name": "雜訊" }, "sampler": { "name": "取樣器" }, "sigmas": { "name": "Sigma 值" } }, "outputs": { "0": { "name": "輸出" }, "1": { "name": "去噪輸出" } } };
const SamplerDPMAdaptative = { "display_name": "SamplerDPMAdaptative", "inputs": { "accept_safety": { "name": "accept_safety" }, "atol": { "name": "atol" }, "dcoeff": { "name": "dcoeff" }, "eta": { "name": "eta" }, "h_init": { "name": "h_init" }, "icoeff": { "name": "icoeff" }, "order": { "name": "order" }, "pcoeff": { "name": "pcoeff" }, "rtol": { "name": "rtol" }, "s_noise": { "name": "s_noise" } } };
const SamplerDPMPP_2M_SDE = { "display_name": "SamplerDPMPP_2M_SDE", "inputs": { "eta": { "name": "eta" }, "noise_device": { "name": "noise_device" }, "s_noise": { "name": "s_noise" }, "solver_type": { "name": "solver_type" } } };
const SamplerDPMPP_2S_Ancestral = { "display_name": "SamplerDPMPP_2S_Ancestral", "inputs": { "eta": { "name": "eta" }, "s_noise": { "name": "s_noise" } } };
const SamplerDPMPP_3M_SDE = { "display_name": "SamplerDPMPP_3M_SDE", "inputs": { "eta": { "name": "eta" }, "noise_device": { "name": "noise_device" }, "s_noise": { "name": "s_noise" } } };
const SamplerDPMPP_SDE = { "display_name": "SamplerDPMPP_SDE", "inputs": { "eta": { "name": "eta" }, "noise_device": { "name": "noise_device" }, "r": { "name": "r" }, "s_noise": { "name": "s_noise" } } };
const SamplerER_SDE = { "display_name": "SamplerER_SDE", "inputs": { "eta": { "name": "eta", "tooltip": "反向時間 SDE 的隨機強度。\n當 eta=0 時，它簡化為確定性 ODE。此設定不適用於 ER-SDE 求解器類型。" }, "max_stage": { "name": "max_stage" }, "s_noise": { "name": "s_noise" }, "solver_type": { "name": "solver_type" } } };
const SamplerEulerAncestral = { "display_name": "SamplerEulerAncestral", "inputs": { "eta": { "name": "eta" }, "s_noise": { "name": "s_noise" } } };
const SamplerEulerAncestralCFGPP = { "display_name": "SamplerEulerAncestralCFG++", "inputs": { "eta": { "name": "eta" }, "s_noise": { "name": "s_noise" } } };
const SamplerEulerCFGpp = { "display_name": "SamplerEulerCFG++", "inputs": { "version": { "name": "版本" } }, "outputs": { "0": { "tooltip": null } } };
const SamplerLCMUpscale = { "display_name": "SamplerLCMUpscale", "inputs": { "scale_ratio": { "name": "縮放比例" }, "scale_steps": { "name": "縮放步驟" }, "upscale_method": { "name": "放大方法" } }, "outputs": { "0": { "tooltip": null } } };
const SamplerLMS = { "display_name": "SamplerLMS", "inputs": { "order": { "name": "順序" } } };
const SamplerSASolver = { "display_name": "SamplerSASolver", "inputs": { "corrector_order": { "name": "corrector_order" }, "eta": { "name": "eta" }, "model": { "name": "model" }, "predictor_order": { "name": "predictor_order" }, "s_noise": { "name": "s_noise" }, "sde_end_percent": { "name": "sde_end_percent" }, "sde_start_percent": { "name": "sde_start_percent" }, "simple_order_2": { "name": "simple_order_2" }, "use_pece": { "name": "use_pece" } } };
const SamplingPercentToSigma = { "display_name": "SamplingPercentToSigma", "inputs": { "model": { "name": "model" }, "return_actual_sigma": { "name": "return_actual_sigma", "tooltip": "返回實際的 sigma 值，而非用於區間檢查的值。\n這僅影響 0.0 和 1.0 處的結果。" }, "sampling_percent": { "name": "sampling_percent" } }, "outputs": { "0": { "name": "sigma_value" } } };
const SaveAnimatedPNG = { "display_name": "SaveAnimatedPNG", "inputs": { "compress_level": { "name": "壓縮等級" }, "filename_prefix": { "name": "檔名前綴" }, "fps": { "name": "每秒影格數" }, "images": { "name": "images" } } };
const SaveAnimatedWEBP = { "display_name": "SaveAnimatedWEBP", "inputs": { "filename_prefix": { "name": "檔名前綴" }, "fps": { "name": "每秒影格數" }, "images": { "name": "圖片" }, "lossless": { "name": "無損" }, "method": { "name": "方法" }, "quality": { "name": "品質" } } };
const SaveAudio = { "display_name": "儲存音訊", "inputs": { "audio": { "name": "音訊" }, "audioUI": { "name": "音訊介面" }, "filename_prefix": { "name": "檔名前綴" } } };
const SaveAudioMP3 = { "display_name": "儲存音訊 (MP3)", "inputs": { "audio": { "name": "audio" }, "audioUI": { "name": "audioUI" }, "filename_prefix": { "name": "filename_prefix" }, "quality": { "name": "quality" } } };
const SaveAudioOpus = { "display_name": "儲存音訊 (Opus)", "inputs": { "audio": { "name": "audio" }, "audioUI": { "name": "audioUI" }, "filename_prefix": { "name": "filename_prefix" }, "quality": { "name": "quality" } } };
const SaveGLB = { "display_name": "SaveGLB", "inputs": { "filename_prefix": { "name": "檔名前綴" }, "image": { "name": "影像" }, "mesh": { "name": "mesh" } } };
const SaveImage = { "description": "將輸入的圖片儲存到您的 ComfyUI 輸出目錄。", "display_name": "儲存圖片", "inputs": { "filename_prefix": { "name": "檔名前綴", "tooltip": "要儲存檔案的字首。這可以包含格式化資訊，例如 %date:yyyy-MM-dd% 或 %Empty Latent Image.width%，以便從節點中包含數值。" }, "images": { "name": "影像", "tooltip": "要儲存的圖片。" } } };
const SaveImageWebsocket = { "display_name": "SaveImageWebsocket", "inputs": { "images": { "name": "圖片" } } };
const SaveLatent = { "display_name": "SaveLatent", "inputs": { "filename_prefix": { "name": "檔名前綴" }, "samples": { "name": "samples" } } };
const SaveSVGNode = { "description": "在磁碟上儲存 SVG 檔案。", "display_name": "儲存SVG節點", "inputs": { "filename_prefix": { "name": "檔案名稱前綴", "tooltip": "要儲存檔案的前綴。可包含格式化資訊，例如 %date:yyyy-MM-dd% 或 %Empty Latent Image.width% 以包含來自節點的值。" }, "svg": { "name": "svg" } } };
const SaveVideo = { "description": "將輸入的影像儲存到您的 ComfyUI 輸出目錄。", "display_name": "儲存影片", "inputs": { "codec": { "name": "編碼器", "tooltip": "影片要使用的編碼器。" }, "filename_prefix": { "name": "檔名前綴", "tooltip": "要儲存檔案的字首。這可以包含格式化資訊，例如 %date:yyyy-MM-dd% 或 %Empty Latent Image.width%，以便從節點中包含數值。" }, "format": { "name": "格式", "tooltip": "儲存影片的格式。" }, "video": { "name": "video", "tooltip": "要儲存的影片。" } } };
const SaveWEBM = { "display_name": "SaveWEBM", "inputs": { "codec": { "name": "編碼器" }, "crf": { "name": "CRF", "tooltip": "CRF 值越高，畫質越低但檔案較小；CRF 值越低，畫質越高但檔案較大。" }, "filename_prefix": { "name": "檔名前綴" }, "fps": { "name": "每秒影格數" }, "images": { "name": "images" } } };
const ScaleROPE = { "description": "縮放並平移模型的 ROPE。", "display_name": "縮放ROPE", "inputs": { "model": { "name": "模型" }, "scale_t": { "name": "t軸縮放" }, "scale_x": { "name": "x軸縮放" }, "scale_y": { "name": "y軸縮放" }, "shift_t": { "name": "t軸平移" }, "shift_x": { "name": "x軸平移" }, "shift_y": { "name": "y軸平移" } }, "outputs": { "0": { "tooltip": null } } };
const SelfAttentionGuidance = { "display_name": "自我注意力引導", "inputs": { "blur_sigma": { "name": "模糊標準差" }, "model": { "name": "model" }, "scale": { "name": "強度" } }, "outputs": { "0": { "tooltip": null } } };
const SetClipHooks = { "display_name": "設定 CLIP 掛鉤", "inputs": { "apply_to_conds": { "name": "套用至條件" }, "clip": { "name": "clip" }, "hooks": { "name": "hooks" }, "schedule_clip": { "name": "排程 clip" } } };
const SetFirstSigma = { "display_name": "SetFirstSigma", "inputs": { "sigma": { "name": "sigma" }, "sigmas": { "name": "sigmas" } } };
const SetHookKeyframes = { "display_name": "設定 Hook 關鍵影格", "inputs": { "hook_kf": { "name": "hook_kf" }, "hooks": { "name": "hooks" } } };
const SetLatentNoiseMask = { "display_name": "設定 latent 雜訊遮罩", "inputs": { "mask": { "name": "遮罩" }, "samples": { "name": "樣本" } } };
const SetUnionControlNetType = { "display_name": "SetUnionControlNetType", "inputs": { "control_net": { "name": "control_net" }, "type": { "name": "type" } }, "outputs": { "0": { "tooltip": null } } };
const SkipLayerGuidanceDiT = { "description": "可用於所有 DiT 模型的通用 SkipLayerGuidance 節點版本。", "display_name": "跳過層引導 DiT", "inputs": { "double_layers": { "name": "雙層" }, "end_percent": { "name": "結束百分比" }, "model": { "name": "model" }, "rescaling_scale": { "name": "重新縮放比例" }, "scale": { "name": "縮放" }, "single_layers": { "name": "單層" }, "start_percent": { "name": "起始百分比" } }, "outputs": { "0": { "tooltip": null } } };
const SkipLayerGuidanceDiTSimple = { "description": "僅修改無條件傳遞的 SkipLayerGuidanceDiT 節點簡易版本。", "display_name": "跳層引導DiT簡易版", "inputs": { "double_layers": { "name": "雙層" }, "end_percent": { "name": "結束百分比" }, "model": { "name": "模型" }, "single_layers": { "name": "單層" }, "start_percent": { "name": "起始百分比" } }, "outputs": { "0": { "tooltip": null } } };
const SkipLayerGuidanceSD3 = { "description": "可用於所有 DiT 模型的通用 SkipLayerGuidance 節點版本。", "display_name": "跳過層引導 SD3", "inputs": { "end_percent": { "name": "結束百分比" }, "layers": { "name": "層數" }, "model": { "name": "model" }, "scale": { "name": "縮放" }, "start_percent": { "name": "起始百分比" } }, "outputs": { "0": { "tooltip": null } } };
const SolidMask = { "display_name": "實色遮罩", "inputs": { "height": { "name": "高度" }, "value": { "name": "值" }, "width": { "name": "寬度" } } };
const SplitAudioChannels = { "description": "將音訊分離為左右聲道。", "display_name": "分離音訊聲道", "inputs": { "audio": { "name": "音訊" } }, "outputs": { "0": { "name": "左聲道" }, "1": { "name": "右聲道" } } };
const SplitImageWithAlpha = { "display_name": "以 Alpha 通道分割影像", "inputs": { "image": { "name": "影像" } }, "outputs": { "0": { "tooltip": null }, "1": { "tooltip": null } } };
const SplitSigmas = { "display_name": "分割 Sigmas", "inputs": { "sigmas": { "name": "sigmas" }, "step": { "name": "步驟" } }, "outputs": { "0": { "name": "高 sigmas" }, "1": { "name": "低 sigmas" } } };
const SplitSigmasDenoise = { "display_name": "分割 Sigmas（去噪）", "inputs": { "denoise": { "name": "去雜訊強度" }, "sigmas": { "name": "sigmas" } }, "outputs": { "0": { "name": "高 sigmas" }, "1": { "name": "低 sigmas" } } };
const StabilityAudioInpaint = { "description": "使用文字指令轉換現有音訊樣本的部分內容。", "display_name": "Stability AI 音訊修補", "inputs": { "audio": { "name": "音訊", "tooltip": "音訊長度必須介於 6 到 190 秒之間。" }, "control_after_generate": { "name": "生成後控制" }, "duration": { "name": "持續時間", "tooltip": "控制生成音訊的持續時間（秒）。" }, "mask_end": { "name": "遮罩結束" }, "mask_start": { "name": "遮罩開始" }, "model": { "name": "模型" }, "prompt": { "name": "提示詞" }, "seed": { "name": "種子", "tooltip": "用於生成的隨機種子。" }, "steps": { "name": "步數", "tooltip": "控制取樣步數。" } }, "outputs": { "0": { "tooltip": null } } };
const StabilityAudioToAudio = { "description": "使用文字指令將現有音訊樣本轉換為新的高品質作品。", "display_name": "Stability AI 音訊轉音訊", "inputs": { "audio": { "name": "音訊", "tooltip": "音訊長度必須介於 6 到 190 秒之間。" }, "control_after_generate": { "name": "生成後控制" }, "duration": { "name": "持續時間", "tooltip": "控制生成音訊的持續時間（單位：秒）。" }, "model": { "name": "模型" }, "prompt": { "name": "提示詞" }, "seed": { "name": "種子值", "tooltip": "用於生成的隨機種子。" }, "steps": { "name": "採樣步數", "tooltip": "控制採樣步驟的數量。" }, "strength": { "name": "強度", "tooltip": "參數控制音訊參數對生成音訊的影響程度。" } }, "outputs": { "0": { "tooltip": null } } };
const StabilityStableImageSD_3_5Node = { "description": "根據提示詞與解析度同步生成圖像。", "display_name": "Stability AI Stable Diffusion 3.5 圖像", "inputs": { "aspect_ratio": { "name": "長寬比", "tooltip": "生成圖像的長寬比。" }, "cfg_scale": { "name": "cfg_scale", "tooltip": "擴散過程對提示詞文本的遵循程度（數值越高，圖像越貼近您的提示詞）" }, "control_after_generate": { "name": "生成後控制" }, "image": { "name": "影像" }, "image_denoise": { "name": "image_denoise", "tooltip": "輸入圖像的去噪程度；0.0 代表與輸入圖像完全相同，1.0 則如同未提供任何圖像。" }, "model": { "name": "model" }, "negative_prompt": { "name": "負向提示詞", "tooltip": "您不希望在輸出圖像中出現的關鍵字。這是進階功能。" }, "prompt": { "name": "prompt", "tooltip": "您希望在輸出圖像中看到的內容。明確且具體描述元素、顏色與主題的強力提示詞，將帶來更佳的結果。" }, "seed": { "name": "種子", "tooltip": "用於產生雜訊的隨機種子。" }, "style_preset": { "name": "style_preset", "tooltip": "可選的圖像風格。" } }, "outputs": { "0": { "tooltip": null } } };
const StabilityStableImageUltraNode = { "description": "根據提示詞與解析度同步生成影像。", "display_name": "Stability AI Stable Image Ultra", "inputs": { "aspect_ratio": { "name": "長寬比", "tooltip": "生成影像的長寬比。" }, "control_after_generate": { "name": "生成後控制" }, "image": { "name": "影像" }, "image_denoise": { "name": "image_denoise", "tooltip": "輸入影像的去噪程度；0.0 代表與輸入影像完全相同，1.0 則如同未提供任何影像。" }, "negative_prompt": { "name": "負向提示詞", "tooltip": "描述您不希望在輸出影像中出現內容的文字。這是進階功能。" }, "prompt": { "name": "prompt", "tooltip": "您希望在輸出影像中看到的內容。強而有力且具體的提示詞，能清楚定義元素、顏色與主題，將帶來更佳的結果。若要控制特定詞語的權重，請使用格式 `(word:weight)`，其中 `word` 是您想控制權重的詞語，`weight` 是介於 0 到 1 之間的數值。例如：`The sky was a crisp (blue:0.3) and (green:0.8)` 代表天空同時有藍色與綠色，但綠色比例高於藍色。" }, "seed": { "name": "種子", "tooltip": "用於產生雜訊的隨機種子。" }, "style_preset": { "name": "style_preset", "tooltip": "（選填）希望生成影像的風格。" } }, "outputs": { "0": { "tooltip": null } } };
const StabilityTextToAudio = { "description": "從文字描述生成高品質音樂和音效。", "display_name": "Stability AI 文字轉音訊", "inputs": { "control_after_generate": { "name": "生成後控制" }, "duration": { "name": "持續時間", "tooltip": "控制生成音訊的持續時間（單位：秒）。" }, "model": { "name": "模型" }, "prompt": { "name": "提示詞" }, "seed": { "name": "種子值", "tooltip": "用於生成的隨機種子。" }, "steps": { "name": "採樣步數", "tooltip": "控制採樣步驟的數量。" } }, "outputs": { "0": { "tooltip": null } } };
const StabilityUpscaleConservativeNode = { "description": "將影像以最小變動放大至 4K 解析度。", "display_name": "Stability AI 保守放大", "inputs": { "control_after_generate": { "name": "生成後控制" }, "creativity": { "name": "創意度", "tooltip": "控制產生未受初始影像強烈影響的額外細節的可能性。" }, "image": { "name": "影像" }, "negative_prompt": { "name": "負向提示詞", "tooltip": "您不希望在輸出影像中看到的關鍵字。這是進階功能。" }, "prompt": { "name": "提示詞", "tooltip": "您希望在輸出影像中看到什麼。明確且具描述性的提示詞，能清楚定義元素、顏色與主題，將帶來更佳的結果。" }, "seed": { "name": "種子", "tooltip": "用於產生雜訊的隨機種子。" } }, "outputs": { "0": { "tooltip": null } } };
const StabilityUpscaleCreativeNode = { "description": "將影像以最小變動放大至 4K 解析度。", "display_name": "Stability AI 創意放大", "inputs": { "control_after_generate": { "name": "生成後控制" }, "creativity": { "name": "創意度", "tooltip": "控制產生未受初始影像強烈限制的額外細節的可能性。" }, "image": { "name": "影像" }, "negative_prompt": { "name": "負向提示詞", "tooltip": "您不希望在輸出影像中出現的關鍵字。這是進階功能。" }, "prompt": { "name": "提示詞", "tooltip": "您希望在輸出影像中看到什麼。明確描述元素、顏色與主題的強烈提示詞將帶來更佳效果。" }, "seed": { "name": "種子", "tooltip": "用於產生雜訊的隨機種子。" }, "style_preset": { "name": "風格預設", "tooltip": "可選擇產生影像的期望風格。" } }, "outputs": { "0": { "tooltip": null } } };
const StabilityUpscaleFastNode = { "description": "透過 Stability API 快速將影像放大至原始尺寸的 4 倍；適用於提升低品質或壓縮影像的解析度。", "display_name": "Stability AI 快速放大", "inputs": { "image": { "name": "影像" } }, "outputs": { "0": { "tooltip": null } } };
const StableCascade_EmptyLatentImage = { "display_name": "StableCascade 空白潛在影像", "inputs": { "batch_size": { "name": "批次大小" }, "compression": { "name": "壓縮" }, "height": { "name": "高度" }, "width": { "name": "寬度" } }, "outputs": { "0": { "name": "stage_c", "tooltip": null }, "1": { "name": "stage_b", "tooltip": null } } };
const StableCascade_StageB_Conditioning = { "display_name": "StableCascade 階段 B 條件設定", "inputs": { "conditioning": { "name": "條件設定" }, "stage_c": { "name": "stage_c" } }, "outputs": { "0": { "tooltip": null } } };
const StableCascade_StageC_VAEEncode = { "display_name": "StableCascade 階段 C VAE 編碼", "inputs": { "compression": { "name": "壓縮" }, "image": { "name": "影像" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "stage_c", "tooltip": null }, "1": { "name": "stage_b", "tooltip": null } } };
const StableCascade_SuperResolutionControlnet = { "display_name": "StableCascade 超解析度 ControlNet", "inputs": { "image": { "name": "影像" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "controlnet_input", "tooltip": null }, "1": { "name": "stage_c", "tooltip": null }, "2": { "name": "stage_b", "tooltip": null } } };
const StableZero123_Conditioning = { "display_name": "StableZero123 條件設定", "inputs": { "azimuth": { "name": "方位角" }, "batch_size": { "name": "批次大小" }, "clip_vision": { "name": "clip_vision" }, "elevation": { "name": "仰角" }, "height": { "name": "高度" }, "init_image": { "name": "初始影像" }, "vae": { "name": "vae" }, "width": { "name": "寬度" } }, "outputs": { "0": { "name": "正向", "tooltip": null }, "1": { "name": "負向", "tooltip": null }, "2": { "name": "潛在空間", "tooltip": null } } };
const StableZero123_Conditioning_Batched = { "display_name": "StableZero123 條件設定（批次）", "inputs": { "azimuth": { "name": "方位角" }, "azimuth_batch_increment": { "name": "方位角批次遞增" }, "batch_size": { "name": "批次大小" }, "clip_vision": { "name": "clip_vision" }, "elevation": { "name": "仰角" }, "elevation_batch_increment": { "name": "仰角批次遞增" }, "height": { "name": "高度" }, "init_image": { "name": "初始影像" }, "vae": { "name": "vae" }, "width": { "name": "寬度" } }, "outputs": { "0": { "name": "正向", "tooltip": null }, "1": { "name": "負向", "tooltip": null }, "2": { "name": "潛在空間", "tooltip": null } } };
const StringCompare = { "display_name": "比較", "inputs": { "case_sensitive": { "name": "區分大小寫" }, "mode": { "name": "模式" }, "string_a": { "name": "字串_a" }, "string_b": { "name": "字串_b" } }, "outputs": { "0": { "tooltip": null } } };
const StringConcatenate = { "display_name": "串接", "inputs": { "delimiter": { "name": "分隔符" }, "string_a": { "name": "字串_a" }, "string_b": { "name": "字串_b" } }, "outputs": { "0": { "tooltip": null } } };
const StringContains = { "display_name": "包含", "inputs": { "case_sensitive": { "name": "區分大小寫" }, "string": { "name": "字串" }, "substring": { "name": "子字串" } }, "outputs": { "0": { "name": "包含", "tooltip": null } } };
const StringLength = { "display_name": "長度", "inputs": { "string": { "name": "字串" } }, "outputs": { "0": { "name": "長度", "tooltip": null } } };
const StringReplace = { "display_name": "取代", "inputs": { "find": { "name": "尋找" }, "replace": { "name": "取代" }, "string": { "name": "字串" } }, "outputs": { "0": { "tooltip": null } } };
const StringSubstring = { "display_name": "子字串", "inputs": { "end": { "name": "結束" }, "start": { "name": "開始" }, "string": { "name": "字串" } }, "outputs": { "0": { "tooltip": null } } };
const StringTrim = { "display_name": "修剪", "inputs": { "mode": { "name": "模式" }, "string": { "name": "字串" } }, "outputs": { "0": { "tooltip": null } } };
const StyleModelApply = { "display_name": "套用風格模型", "inputs": { "clip_vision_output": { "name": "clip_vision_output" }, "conditioning": { "name": "條件設定" }, "strength": { "name": "強度" }, "strength_type": { "name": "強度類型" }, "style_model": { "name": "style_model" } } };
const StyleModelLoader = { "display_name": "載入風格模型", "inputs": { "style_model_name": { "name": "style_model_name" } } };
const T5TokenizerOptions = { "display_name": "T5 分詞器選項", "inputs": { "clip": { "name": "clip" }, "min_length": { "name": "最小長度" }, "min_padding": { "name": "最小填充" } }, "outputs": { "0": { "tooltip": null } } };
const TCFG = { "description": "TCFG – 切向阻尼 CFG (2503.18137)\n\n精煉無條件（負向）提示以對齊有條件（正向）提示，從而提升品質。", "display_name": "切向阻尼 CFG", "inputs": { "model": { "name": "模型" } }, "outputs": { "0": { "name": "修補後模型", "tooltip": null } } };
const TemporalScoreRescaling = { "description": "[後 CFG 函數]\nTSR - 時間分數重新縮放 (2510.01184)\n\n重新縮放模型的分數或噪聲以引導採樣多樣性。", "display_name": "TSR - 時間分數重新縮放", "inputs": { "model": { "name": "模型" }, "tsr_k": { "name": "tsr_k", "tooltip": "控制重新縮放強度。\n較低的 k 值產生更詳細的結果；較高的 k 值在圖像生成中產生更平滑的結果。設定 k = 1 可停用重新縮放。" }, "tsr_sigma": { "name": "tsr_sigma", "tooltip": "控制重新縮放何時生效。\n較大的值會更早生效。" } }, "outputs": { "0": { "name": "修補後模型", "tooltip": null } } };
const TextEncodeAceStepAudio = { "display_name": "TextEncodeAceStepAudio", "inputs": { "clip": { "name": "clip" }, "lyrics": { "name": "歌詞" }, "lyrics_strength": { "name": "歌詞強度" }, "tags": { "name": "標籤" } }, "outputs": { "0": { "tooltip": null } } };
const TextEncodeHunyuanVideo_ImageToVideo = { "display_name": "文字編碼 HunyuanVideo 影像轉影片", "inputs": { "clip": { "name": "clip" }, "clip_vision_output": { "name": "clip_vision_output" }, "image_interleave": { "name": "影像交錯", "tooltip": "影像對結果的影響程度，相較於文字提示。數值越高，代表文字提示的影響越大。" }, "prompt": { "name": "提示詞" } }, "outputs": { "0": { "tooltip": null } } };
const TextEncodeQwenImageEdit = { "display_name": "TextEncodeQwenImageEdit", "inputs": { "clip": { "name": "clip" }, "image": { "name": "圖像" }, "prompt": { "name": "提示詞" }, "vae": { "name": "vae" } }, "outputs": { "0": { "tooltip": null } } };
const TextEncodeQwenImageEditPlus = { "display_name": "TextEncodeQwenImageEditPlus", "inputs": { "clip": { "name": "clip" }, "image1": { "name": "圖像1" }, "image2": { "name": "圖像2" }, "image3": { "name": "圖像3" }, "prompt": { "name": "提示詞" }, "vae": { "name": "vae" } }, "outputs": { "0": { "tooltip": null } } };
const ThresholdMask = { "display_name": "闾值遮罩", "inputs": { "mask": { "name": "遮罩" }, "value": { "name": "數值" } } };
const TomePatchModel = { "display_name": "Tome 修補模型", "inputs": { "model": { "name": "model" }, "ratio": { "name": "比例" } }, "outputs": { "0": { "tooltip": null } } };
const TorchCompileModel = { "display_name": "Torch 編譯模型", "inputs": { "backend": { "name": "backend" }, "model": { "name": "model" } }, "outputs": { "0": { "tooltip": null } } };
const TrainLoraNode = { "display_name": "訓練 LoRA", "inputs": { "algorithm": { "name": "演算法", "tooltip": "訓練時使用的演算法。" }, "batch_size": { "name": "批次大小", "tooltip": "用於訓練的批次大小。" }, "control_after_generate": { "name": "生成後控制" }, "existing_lora": { "name": "現有 LoRA", "tooltip": "要附加到的現有 LoRA。設為 None 表示創建新的 LoRA。" }, "grad_accumulation_steps": { "name": "梯度累積步數", "tooltip": "用於訓練的梯度累積步數。" }, "gradient_checkpointing": { "name": "梯度檢查點", "tooltip": "訓練時使用梯度檢查點。" }, "latents": { "name": "潛在變量", "tooltip": "用於訓練的潛在變量，作為模型的資料集/輸入。" }, "learning_rate": { "name": "學習率", "tooltip": "訓練時使用的學習率。" }, "lora_dtype": { "name": "LoRA 資料類型", "tooltip": "LoRA 使用的資料類型。" }, "loss_function": { "name": "損失函數", "tooltip": "訓練時使用的損失函數。" }, "model": { "name": "模型", "tooltip": "用於訓練 LoRA 的模型。" }, "optimizer": { "name": "優化器", "tooltip": "訓練時使用的優化器。" }, "positive": { "name": "正向條件", "tooltip": "用於訓練的正向條件。" }, "rank": { "name": "秩", "tooltip": "LoRA 層的秩。" }, "seed": { "name": "種子值", "tooltip": "訓練時使用的種子值（用於 LoRA 權重初始化和噪聲採樣的生成器）" }, "steps": { "name": "步數", "tooltip": "訓練 LoRA 的步數。" }, "training_dtype": { "name": "訓練資料類型", "tooltip": "訓練時使用的資料類型。" } }, "outputs": { "0": { "name": "含 LoRA 的模型" }, "1": { "name": "LoRA" }, "2": { "name": "損失" }, "3": { "name": "步數" } } };
const TrimAudioDuration = { "description": "將音訊張量修剪至選定的時間範圍。", "display_name": "修剪音訊時長", "inputs": { "audio": { "name": "音訊" }, "duration": { "name": "持續時間", "tooltip": "持續時間（秒）" }, "start_index": { "name": "起始索引", "tooltip": "開始時間（秒），可為負數表示從末尾計算（支援小數秒）。" } } };
const TrimVideoLatent = { "display_name": "裁剪影片潛在空間", "inputs": { "samples": { "name": "samples" }, "trim_amount": { "name": "裁剪量" } }, "outputs": { "0": { "tooltip": null } } };
const TripleCLIPLoader = { "description": "[配方]\n\nsd3：clip-l、clip-g、t5", "display_name": "載入三重 CLIP", "inputs": { "clip_name1": { "name": "clip_name1" }, "clip_name2": { "name": "clip_name2" }, "clip_name3": { "name": "clip_name3" } }, "outputs": { "0": { "tooltip": null } } };
const TripoConversionNode = { "display_name": "Tripo：轉換模型", "inputs": { "face_limit": { "name": "面數限制" }, "format": { "name": "格式" }, "original_model_task_id": { "name": "原始模型任務ID" }, "quad": { "name": "四邊形" }, "texture_format": { "name": "紋理格式" }, "texture_size": { "name": "紋理尺寸" } } };
const TripoImageToModelNode = { "display_name": "Tripo：圖像轉模型", "inputs": { "face_limit": { "name": "面數限制" }, "image": { "name": "圖像" }, "model_seed": { "name": "模型種子" }, "model_version": { "name": "模型版本", "tooltip": "用於生成的模型版本" }, "orientation": { "name": "方向" }, "pbr": { "name": "PBR" }, "quad": { "name": "四邊形" }, "style": { "name": "風格" }, "texture": { "name": "紋理" }, "texture_alignment": { "name": "紋理對齊" }, "texture_quality": { "name": "紋理品質" }, "texture_seed": { "name": "紋理種子" } }, "outputs": { "0": { "name": "模型檔案", "tooltip": null }, "1": { "name": "模型任務ID", "tooltip": null } } };
const TripoMultiviewToModelNode = { "display_name": "Tripo：多視角轉模型", "inputs": { "face_limit": { "name": "face_limit" }, "image": { "name": "圖像" }, "image_back": { "name": "後方圖像" }, "image_left": { "name": "左側圖像" }, "image_right": { "name": "右側圖像" }, "model_seed": { "name": "model_seed" }, "model_version": { "name": "model_version", "tooltip": "用於生成的模型版本" }, "orientation": { "name": "orientation" }, "pbr": { "name": "pbr" }, "quad": { "name": "quad" }, "texture": { "name": "texture" }, "texture_alignment": { "name": "texture_alignment" }, "texture_quality": { "name": "texture_quality" }, "texture_seed": { "name": "texture_seed" } }, "outputs": { "0": { "name": "model_file", "tooltip": null }, "1": { "name": "model task_id", "tooltip": null } } };
const TripoRefineNode = { "description": "僅精修由 v1.4 Tripo 模型建立的草稿模型。", "display_name": "Tripo: 精修草稿模型", "inputs": { "model_task_id": { "name": "model_task_id", "tooltip": "必須是 v1.4 Tripo 模型" } }, "outputs": { "0": { "name": "model_file", "tooltip": null }, "1": { "name": "model task_id", "tooltip": null } } };
const TripoRetargetNode = { "display_name": "Tripo: 重新定位骨架模型", "inputs": { "animation": { "name": "animation" }, "original_model_task_id": { "name": "original_model_task_id" } }, "outputs": { "0": { "name": "model_file", "tooltip": null }, "1": { "name": "retarget task_id", "tooltip": null } } };
const TripoRigNode = { "display_name": "Tripo: 骨架模型", "inputs": { "original_model_task_id": { "name": "原始模型任務ID" } }, "outputs": { "0": { "name": "模型檔案", "tooltip": null }, "1": { "name": "綁定任務ID", "tooltip": null } } };
const TripoTextToModelNode = { "display_name": "Tripo：文字轉模型", "inputs": { "face_limit": { "name": "面數限制" }, "image_seed": { "name": "圖片種子" }, "model_seed": { "name": "模型種子" }, "model_version": { "name": "模型版本" }, "negative_prompt": { "name": "負向提示詞" }, "pbr": { "name": "PBR材質" }, "prompt": { "name": "提示詞" }, "quad": { "name": "四邊形" }, "style": { "name": "風格" }, "texture": { "name": "紋理" }, "texture_quality": { "name": "紋理品質" }, "texture_seed": { "name": "紋理種子" } }, "outputs": { "0": { "name": "模型檔案", "tooltip": null }, "1": { "name": "模型任務ID", "tooltip": null } } };
const TripoTextureNode = { "display_name": "Tripo：紋理模型", "inputs": { "model_task_id": { "name": "模型任務ID" }, "pbr": { "name": "PBR材質" }, "texture": { "name": "紋理" }, "texture_alignment": { "name": "紋理對齊" }, "texture_quality": { "name": "紋理品質" }, "texture_seed": { "name": "紋理種子" } }, "outputs": { "0": { "name": "模型檔案", "tooltip": null }, "1": { "name": "模型任務ID", "tooltip": null } } };
const UNETLoader = { "display_name": "載入擴散模型", "inputs": { "unet_name": { "name": "unet_name" }, "weight_dtype": { "name": "weight_dtype" } } };
const UNetCrossAttentionMultiply = { "display_name": "UNet 交叉注意力倍增", "inputs": { "k": { "name": "k" }, "model": { "name": "model" }, "out": { "name": "out" }, "q": { "name": "q" }, "v": { "name": "v" } }, "outputs": { "0": { "tooltip": null } } };
const UNetSelfAttentionMultiply = { "display_name": "UNet 自注意力倍增", "inputs": { "k": { "name": "k" }, "model": { "name": "model" }, "out": { "name": "out" }, "q": { "name": "q" }, "v": { "name": "v" } }, "outputs": { "0": { "tooltip": null } } };
const UNetTemporalAttentionMultiply = { "display_name": "UNet 時間注意力倍增", "inputs": { "cross_structural": { "name": "交叉結構" }, "cross_temporal": { "name": "交叉時間" }, "model": { "name": "model" }, "self_structural": { "name": "自我結構" }, "self_temporal": { "name": "自我時間" } }, "outputs": { "0": { "tooltip": null } } };
const USOStyleReference = { "display_name": "USO風格參考", "inputs": { "clip_vision_output": { "name": "CLIP視覺輸出" }, "model": { "name": "模型" }, "model_patch": { "name": "模型修補" } } };
const UpscaleModelLoader = { "display_name": "載入放大模型", "inputs": { "model_name": { "name": "model_name" } }, "outputs": { "0": { "tooltip": null } } };
const VAEDecode = { "description": "將 latent 影像解碼回像素空間影像。", "display_name": "VAE 解碼", "inputs": { "samples": { "name": "samples", "tooltip": "要解碼的 latent。" }, "vae": { "name": "vae", "tooltip": "用於解碼 latent 的 VAE 模型。" } }, "outputs": { "0": { "tooltip": "解碼後的影像。" } } };
const VAEDecodeAudio = { "display_name": "VAE 解碼音訊", "inputs": { "samples": { "name": "samples" }, "vae": { "name": "vae" } } };
const VAEDecodeHunyuan3D = { "display_name": "VAE 解碼 Hunyuan3D", "inputs": { "num_chunks": { "name": "分塊數量" }, "octree_resolution": { "name": "八叉樹解析度" }, "samples": { "name": "樣本" }, "vae": { "name": "vae" } } };
const VAEDecodeTiled = { "display_name": "VAE 解碼（分割區塊）", "inputs": { "overlap": { "name": "重疊" }, "samples": { "name": "樣本" }, "temporal_overlap": { "name": "時間重疊", "tooltip": "僅用於影片 VAE：重疊的影格數量。" }, "temporal_size": { "name": "時間區塊大小", "tooltip": "僅用於影片 VAE：每次解碼的影格數量。" }, "tile_size": { "name": "區塊大小" }, "vae": { "name": "vae" } } };
const VAEEncode = { "display_name": "VAE 編碼", "inputs": { "pixels": { "name": "像素" }, "vae": { "name": "vae" } } };
const VAEEncodeAudio = { "display_name": "VAE 編碼音訊", "inputs": { "audio": { "name": "音訊" }, "vae": { "name": "vae" } } };
const VAEEncodeForInpaint = { "display_name": "VAE 編碼（用於修補）", "inputs": { "grow_mask_by": { "name": "擴展遮罩範圍" }, "mask": { "name": "遮罩" }, "pixels": { "name": "pixels" }, "vae": { "name": "vae" } } };
const VAEEncodeTiled = { "display_name": "VAE 編碼（分割區塊）", "inputs": { "overlap": { "name": "重疊" }, "pixels": { "name": "像素" }, "temporal_overlap": { "name": "時間重疊", "tooltip": "僅用於影片 VAE：重疊的影格數量。" }, "temporal_size": { "name": "時間區塊大小", "tooltip": "僅用於影片 VAE：每次編碼的影格數量。" }, "tile_size": { "name": "區塊大小" }, "vae": { "name": "vae" } } };
const VAELoader = { "display_name": "載入 VAE", "inputs": { "vae_name": { "name": "vae_name" } } };
const VAESave = { "display_name": "儲存 VAE", "inputs": { "filename_prefix": { "name": "檔名前綴" }, "vae": { "name": "vae" } } };
const VPScheduler = { "display_name": "VP 調度器", "inputs": { "beta_d": { "name": "beta_d" }, "beta_min": { "name": "beta_min" }, "eps_s": { "name": "eps_s" }, "steps": { "name": "步驟數" } } };
const Veo3VideoGenerationNode = { "description": "使用Google Veo 3 API從文字提示生成影片", "display_name": "Google Veo 3 影片生成", "inputs": { "aspect_ratio": { "name": "長寬比", "tooltip": "輸出影片的長寬比例" }, "control_after_generate": { "name": "生成後控制" }, "duration_seconds": { "name": "持續時間（秒）", "tooltip": "輸出影片的持續時間（秒）（Veo 3僅支援8秒）" }, "enhance_prompt": { "name": "增強提示詞", "tooltip": "是否使用AI輔助增強提示詞" }, "generate_audio": { "name": "generate_audio", "tooltip": "為影片生成音訊。所有 Veo 3 模型均支援此功能。" }, "image": { "name": "圖片", "tooltip": "引導影片生成的選用參考圖片" }, "model": { "name": "模型", "tooltip": "用於影片生成的 Veo 3 模型" }, "negative_prompt": { "name": "負向提示詞", "tooltip": "引導影片應避免內容的負向文字提示" }, "person_generation": { "name": "人物生成", "tooltip": "是否允許在影片中生成人物" }, "prompt": { "name": "提示詞", "tooltip": "影片的文字描述" }, "seed": { "name": "種子值", "tooltip": "影片生成的種子值（0表示隨機）" } }, "outputs": { "0": { "tooltip": null } } };
const VeoVideoGenerationNode = { "description": "使用 Google 的 Veo API 根據文字提示生成影片", "display_name": "Google Veo2 影片生成", "inputs": { "aspect_ratio": { "name": "長寬比", "tooltip": "輸出影片的長寬比" }, "control_after_generate": { "name": "生成後控制" }, "duration_seconds": { "name": "持續秒數", "tooltip": "輸出影片的秒數" }, "enhance_prompt": { "name": "增強提示詞", "tooltip": "是否使用 AI 協助增強提示詞" }, "image": { "name": "影像", "tooltip": "可選的參考圖片，用於引導影片生成" }, "model": { "name": "model", "tooltip": "用於影片生成的 Veo 2 模型" }, "negative_prompt": { "name": "負向提示詞", "tooltip": "用於引導影片中應避免內容的負面文字提示" }, "person_generation": { "name": "生成人物", "tooltip": "是否允許在影片中生成人物" }, "prompt": { "name": "提示詞", "tooltip": "影片的文字描述" }, "seed": { "name": "種子", "tooltip": "影片生成的種子（0 為隨機）" } }, "outputs": { "0": { "tooltip": null } } };
const VideoLinearCFGGuidance = { "display_name": "影片線性 CFG 引導", "inputs": { "min_cfg": { "name": "最小 cfg" }, "model": { "name": "model" } } };
const VideoTriangleCFGGuidance = { "display_name": "影片三角 CFG 引導", "inputs": { "min_cfg": { "name": "min_cfg" }, "model": { "name": "model" } } };
const ViduImageToVideoNode = { "description": "從圖像和可選提示生成影片", "display_name": "Vidu 圖像轉影片生成", "inputs": { "control_after_generate": { "name": "生成後控制" }, "duration": { "name": "duration", "tooltip": "輸出影片的持續時間（以秒為單位）" }, "image": { "name": "image", "tooltip": "用作生成影片起始畫面的圖像" }, "model": { "name": "model", "tooltip": "模型名稱" }, "movement_amplitude": { "name": "movement_amplitude", "tooltip": "畫面中物體的移動幅度" }, "prompt": { "name": "prompt", "tooltip": "用於影片生成的文字描述" }, "resolution": { "name": "resolution", "tooltip": "支援的值可能因模型和持續時間而異" }, "seed": { "name": "seed", "tooltip": "影片生成的種子值（0 表示隨機）" } }, "outputs": { "0": { "tooltip": null } } };
const ViduReferenceVideoNode = { "description": "從多張圖像和提示生成影片", "display_name": "Vidu 參考圖像轉影片生成", "inputs": { "aspect_ratio": { "name": "aspect_ratio", "tooltip": "輸出影片的長寬比" }, "control_after_generate": { "name": "control after generate" }, "duration": { "name": "duration", "tooltip": "輸出影片的持續時間（秒）" }, "images": { "name": "images", "tooltip": "用作參考以生成具有一致主題的影片的圖像（最多 7 張圖像）。" }, "model": { "name": "model", "tooltip": "模型名稱" }, "movement_amplitude": { "name": "movement_amplitude", "tooltip": "畫面中物體的移動幅度" }, "prompt": { "name": "prompt", "tooltip": "用於影片生成的文字描述" }, "resolution": { "name": "resolution", "tooltip": "支援的值可能因模型和持續時間而異" }, "seed": { "name": "seed", "tooltip": "影片生成的種子值（0 表示隨機）" } }, "outputs": { "0": { "tooltip": null } } };
const ViduStartEndToVideoNode = { "description": "從起始和結束畫面及提示生成影片", "display_name": "Vidu 起始結束至影片生成", "inputs": { "control_after_generate": { "name": "生成後控制" }, "duration": { "name": "持續時間", "tooltip": "輸出影片的持續時間（單位：秒）" }, "end_frame": { "name": "end_frame", "tooltip": "結束畫面" }, "first_frame": { "name": "first_frame", "tooltip": "起始畫面" }, "model": { "name": "model", "tooltip": "模型名稱" }, "movement_amplitude": { "name": "移動幅度", "tooltip": "畫面中物體的移動幅度" }, "prompt": { "name": "提示詞", "tooltip": "用於影片生成的文字描述" }, "resolution": { "name": "解析度", "tooltip": "支援的數值可能因模型和持續時間而異" }, "seed": { "name": "種子值", "tooltip": "影片生成的種子值（0 表示隨機）" } }, "outputs": { "0": { "tooltip": null } } };
const ViduTextToVideoNode = { "description": "從文字提示詞生成影片", "display_name": "Vidu 文字轉影片生成", "inputs": { "aspect_ratio": { "name": "長寬比", "tooltip": "輸出影片的長寬比" }, "control_after_generate": { "name": "生成後控制" }, "duration": { "name": "持續時間", "tooltip": "輸出影片的持續時間（單位：秒）" }, "model": { "name": "模型", "tooltip": "模型名稱" }, "movement_amplitude": { "name": "移動幅度", "tooltip": "畫面中物體的移動幅度" }, "prompt": { "name": "提示詞", "tooltip": "用於影片生成的文字描述" }, "resolution": { "name": "解析度", "tooltip": "支援的數值可能因模型和持續時間而異" }, "seed": { "name": "種子值", "tooltip": "影片生成的種子值（0 表示隨機）" } }, "outputs": { "0": { "tooltip": null } } };
const VoxelToMesh = { "display_name": "體素轉網格", "inputs": { "algorithm": { "name": "演算法" }, "threshold": { "name": "臨界值" }, "voxel": { "name": "voxel" } } };
const VoxelToMeshBasic = { "display_name": "體素轉網格（基礎）", "inputs": { "threshold": { "name": "臨界值" }, "voxel": { "name": "voxel" } } };
const Wan22FunControlToVideo = { "display_name": "Wan22FunControlToVideo", "inputs": { "batch_size": { "name": "批次大小" }, "control_video": { "name": "控制影片" }, "height": { "name": "高度" }, "length": { "name": "長度" }, "negative": { "name": "負面提示詞" }, "positive": { "name": "正面提示詞" }, "ref_image": { "name": "參考圖像" }, "vae": { "name": "VAE" }, "width": { "name": "寬度" } }, "outputs": { "0": { "name": "正面提示詞", "tooltip": null }, "1": { "name": "負面提示詞", "tooltip": null }, "2": { "name": "潛在空間", "tooltip": null } } };
const Wan22ImageToVideoLatent = { "display_name": "Wan22ImageToVideoLatent", "inputs": { "batch_size": { "name": "批次大小" }, "height": { "name": "高度" }, "length": { "name": "長度" }, "start_image": { "name": "起始圖像" }, "vae": { "name": "VAE" }, "width": { "name": "寬度" } }, "outputs": { "0": { "tooltip": null } } };
const WanAnimateToVideo = { "display_name": "WanAnimateToVideo", "inputs": { "background_video": { "name": "背景影片" }, "batch_size": { "name": "批次大小" }, "character_mask": { "name": "角色遮罩" }, "clip_vision_output": { "name": "CLIP視覺輸出" }, "continue_motion": { "name": "連續動作" }, "continue_motion_max_frames": { "name": "連續動作最大幀數" }, "face_video": { "name": "臉部影片" }, "height": { "name": "高度" }, "length": { "name": "長度" }, "negative": { "name": "負面提示" }, "pose_video": { "name": "姿勢影片" }, "positive": { "name": "正面提示詞" }, "reference_image": { "name": "參考圖像" }, "vae": { "name": "VAE" }, "video_frame_offset": { "name": "影片幀偏移", "tooltip": "在所有輸入影片中要跳過的幀數。用於通過分塊生成更長的影片。連接到前一個節點的 video_frame_offset 輸出以擴展影片。" }, "width": { "name": "寬度" } }, "outputs": { "0": { "name": "正面提示", "tooltip": null }, "1": { "name": "負面提示", "tooltip": null }, "2": { "name": "潛在空間", "tooltip": null }, "3": { "name": "修剪潛在空間", "tooltip": null }, "4": { "name": "修剪圖像", "tooltip": null }, "5": { "name": "影片幀偏移", "tooltip": null } } };
const WanCameraEmbedding = { "display_name": "WanCamera嵌入", "inputs": { "camera_pose": { "name": "相機姿勢" }, "cx": { "name": "cx" }, "cy": { "name": "cy" }, "fx": { "name": "fx" }, "fy": { "name": "fy" }, "height": { "name": "高度" }, "length": { "name": "長度" }, "speed": { "name": "速度" }, "width": { "name": "寬度" } }, "outputs": { "0": { "name": "攝影機嵌入", "tooltip": null }, "1": { "name": "寬度", "tooltip": null }, "2": { "name": "高度", "tooltip": null }, "3": { "name": "長度", "tooltip": null } } };
const WanCameraImageToVideo = { "display_name": "Wan攝影機圖像轉影片", "inputs": { "batch_size": { "name": "批次大小" }, "camera_conditions": { "name": "攝影機條件" }, "clip_vision_output": { "name": "CLIP視覺輸出" }, "height": { "name": "高度" }, "length": { "name": "長度" }, "negative": { "name": "負面提示詞" }, "positive": { "name": "正面提示詞" }, "start_image": { "name": "起始圖像" }, "vae": { "name": "VAE" }, "width": { "name": "寬度" } }, "outputs": { "0": { "name": "正面提示詞", "tooltip": null }, "1": { "name": "負面提示詞", "tooltip": null }, "2": { "name": "潛在空間", "tooltip": null } } };
const WanContextWindowsManual = { "description": "手動設定WAN類模型的上下文窗口（維度=2）。", "display_name": "WAN上下文窗口（手動）", "inputs": { "closed_loop": { "name": "閉環", "tooltip": "是否關閉上下文窗口循環；僅適用於循環排程。" }, "context_length": { "name": "上下文長度", "tooltip": "上下文窗口的長度。" }, "context_overlap": { "name": "上下文重疊", "tooltip": "上下文窗口的重疊量。" }, "context_schedule": { "name": "上下文排程", "tooltip": "上下文窗口的步幅。" }, "context_stride": { "name": "上下文步幅", "tooltip": "上下文窗口的步幅；僅適用於均勻排程。" }, "fuse_method": { "name": "融合方法", "tooltip": "用於融合上下文窗口的方法。" }, "model": { "name": "模型", "tooltip": "在採樣期間應用上下文窗口的模型。" } }, "outputs": { "0": { "tooltip": "在採樣期間應用上下文窗口的模型。" } } };
const WanFirstLastFrameToVideo = { "display_name": "Wan 首尾影格轉影片", "inputs": { "batch_size": { "name": "批次大小" }, "clip_vision_end_image": { "name": "clip 視覺結束影像" }, "clip_vision_start_image": { "name": "clip 視覺起始影像" }, "end_image": { "name": "結束影像" }, "height": { "name": "高度" }, "length": { "name": "長度" }, "negative": { "name": "負向" }, "positive": { "name": "正向" }, "start_image": { "name": "起始影像" }, "vae": { "name": "vae" }, "width": { "name": "寬度" } }, "outputs": { "0": { "name": "正向", "tooltip": null }, "1": { "name": "負向", "tooltip": null }, "2": { "name": "潛在空間", "tooltip": null } } };
const WanFunControlToVideo = { "display_name": "WanFun 控制轉影片", "inputs": { "batch_size": { "name": "批次大小" }, "clip_vision_output": { "name": "clip_vision_output" }, "control_video": { "name": "控制影片" }, "height": { "name": "高度" }, "length": { "name": "長度" }, "negative": { "name": "負向" }, "positive": { "name": "正向" }, "start_image": { "name": "起始影像" }, "vae": { "name": "vae" }, "width": { "name": "寬度" } }, "outputs": { "0": { "name": "正向", "tooltip": null }, "1": { "name": "負向", "tooltip": null }, "2": { "name": "潛在空間", "tooltip": null } } };
const WanFunInpaintToVideo = { "display_name": "WanFun 修補轉影片", "inputs": { "batch_size": { "name": "批次大小" }, "clip_vision_output": { "name": "clip_vision_output" }, "end_image": { "name": "結束圖片" }, "height": { "name": "高度" }, "length": { "name": "長度" }, "negative": { "name": "負向" }, "positive": { "name": "正向" }, "start_image": { "name": "起始影像" }, "vae": { "name": "vae" }, "width": { "name": "寬度" } }, "outputs": { "0": { "name": "正向", "tooltip": null }, "1": { "name": "負向", "tooltip": null }, "2": { "name": "潛在空間", "tooltip": null } } };
const WanHuMoImageToVideo = { "display_name": "WanHuMo圖像轉影片", "inputs": { "audio_encoder_output": { "name": "音訊編碼器輸出" }, "batch_size": { "name": "批次大小" }, "height": { "name": "高度" }, "length": { "name": "長度" }, "negative": { "name": "負面提示詞" }, "positive": { "name": "正面提示詞" }, "ref_image": { "name": "參考圖像" }, "vae": { "name": "VAE" }, "width": { "name": "寬度" } }, "outputs": { "0": { "name": "正面提示", "tooltip": null }, "1": { "name": "負面提示", "tooltip": null }, "2": { "name": "潛在空間", "tooltip": null } } };
const WanImageToImageApi = { "description": "根據一或兩張輸入圖像和文字提示生成圖像。輸出圖像目前固定為160萬像素；其長寬比與輸入圖像匹配。", "display_name": "萬圖生圖", "inputs": { "control_after_generate": { "name": "生成後控制" }, "image": { "name": "圖像", "tooltip": "單圖編輯或多圖融合，最多2張圖像。" }, "model": { "name": "模型", "tooltip": "要使用的模型。" }, "negative_prompt": { "name": "負面提示詞", "tooltip": "引導避免內容的負面文字提示。" }, "prompt": { "name": "提示詞", "tooltip": "用於描述元素和視覺特徵的提示詞，支援英文/中文。" }, "seed": { "name": "種子值", "tooltip": "用於生成的種子值。" }, "watermark": { "name": "浮水印", "tooltip": "是否在結果中添加「AI生成」浮水印。" } }, "outputs": { "0": { "tooltip": null } } };
const WanImageToVideo = { "display_name": "WAN 影像轉影片", "inputs": { "batch_size": { "name": "批次大小" }, "clip_vision_output": { "name": "clip_vision_output" }, "height": { "name": "高度" }, "length": { "name": "長度" }, "negative": { "name": "負向" }, "positive": { "name": "正向" }, "start_image": { "name": "起始影像" }, "vae": { "name": "vae" }, "width": { "name": "寬度" } }, "outputs": { "0": { "name": "正向", "tooltip": null }, "1": { "name": "負向", "tooltip": null }, "2": { "name": "潛在空間", "tooltip": null } } };
const WanImageToVideoApi = { "description": "根據首幀圖像和文字提示生成影片。", "display_name": "萬圖生影片", "inputs": { "audio": { "name": "音訊", "tooltip": "音訊必須包含清晰、響亮的人聲，無雜音和背景音樂。" }, "control_after_generate": { "name": "生成後控制" }, "duration": { "name": "持續時間", "tooltip": "可用持續時間：5秒和10秒" }, "generate_audio": { "name": "生成音訊", "tooltip": "若無音訊輸入，則自動生成音訊。" }, "image": { "name": "圖像" }, "model": { "name": "模型", "tooltip": "要使用的模型。" }, "negative_prompt": { "name": "負面提示詞", "tooltip": "引導避免內容的負面文字提示。" }, "prompt": { "name": "提示詞", "tooltip": "用於描述元素和視覺特徵的提示詞，支援英文/中文。" }, "prompt_extend": { "name": "提示詞擴展", "tooltip": "是否透過AI輔助增強提示詞。" }, "resolution": { "name": "解析度" }, "seed": { "name": "種子值", "tooltip": "用於生成的種子值。" }, "watermark": { "name": "浮水印", "tooltip": "是否在結果中添加「AI生成」浮水印。" } }, "outputs": { "0": { "tooltip": null } } };
const WanPhantomSubjectToVideo = { "display_name": "萬幻影主體轉影片", "inputs": { "batch_size": { "name": "批次大小" }, "height": { "name": "高度" }, "images": { "name": "圖片" }, "length": { "name": "長度" }, "negative": { "name": "負面提示" }, "positive": { "name": "正面提示" }, "vae": { "name": "VAE" }, "width": { "name": "寬度" } }, "outputs": { "0": { "name": "正面提示", "tooltip": null }, "1": { "name": "負面文字", "tooltip": null }, "2": { "name": "負面圖片文字", "tooltip": null }, "3": { "name": "潛在空間", "tooltip": null } } };
const WanSoundImageToVideo = { "display_name": "萬聲圖像轉影片", "inputs": { "audio_encoder_output": { "name": "音訊編碼器輸出" }, "batch_size": { "name": "批次大小" }, "control_video": { "name": "控制影片" }, "height": { "name": "高度" }, "length": { "name": "長度" }, "negative": { "name": "負面提示" }, "positive": { "name": "正面提示" }, "ref_image": { "name": "參考圖片" }, "ref_motion": { "name": "參考動作" }, "vae": { "name": "VAE" }, "width": { "name": "寬度" } }, "outputs": { "0": { "name": "正面提示", "tooltip": null }, "1": { "name": "負面提示", "tooltip": null }, "2": { "name": "潛在空間", "tooltip": null } } };
const WanSoundImageToVideoExtend = { "display_name": "萬聲圖像轉影片擴展", "inputs": { "audio_encoder_output": { "name": "音訊編碼器輸出" }, "control_video": { "name": "控制影片" }, "length": { "name": "長度" }, "negative": { "name": "負面提示" }, "positive": { "name": "正面提示" }, "ref_image": { "name": "參考圖片" }, "vae": { "name": "VAE" }, "video_latent": { "name": "影片潛在空間" } }, "outputs": { "0": { "name": "正面提示", "tooltip": null }, "1": { "name": "負面提示", "tooltip": null }, "2": { "name": "潛在空間", "tooltip": null } } };
const WanTextToImageApi = { "description": "根據文字提示生成圖像。", "display_name": "萬文字轉圖像", "inputs": { "control_after_generate": { "name": "生成後控制" }, "height": { "name": "高度" }, "model": { "name": "模型", "tooltip": "要使用的模型。" }, "negative_prompt": { "name": "負面提示詞", "tooltip": "用於指導應避免內容的負面文字提示。" }, "prompt": { "name": "提示詞", "tooltip": "用於描述元素和視覺特徵的提示詞，支援英文/中文。" }, "prompt_extend": { "name": "提示詞擴展", "tooltip": "是否使用AI輔助增強提示詞。" }, "seed": { "name": "種子值", "tooltip": "用於生成的種子值。" }, "watermark": { "name": "浮水印", "tooltip": "是否在結果中添加「AI生成」浮水印。" }, "width": { "name": "寬度" } }, "outputs": { "0": { "tooltip": null } } };
const WanTextToVideoApi = { "description": "根據文字提示生成影片。", "display_name": "Wan 文字轉影片", "inputs": { "audio": { "name": "音訊", "tooltip": "音訊必須包含清晰、響亮的語音，無雜音和背景音樂。" }, "control_after_generate": { "name": "生成後控制" }, "duration": { "name": "持續時間", "tooltip": "可用持續時間：5 秒和 10 秒" }, "generate_audio": { "name": "生成音訊", "tooltip": "若無音訊輸入，則自動生成音訊。" }, "model": { "name": "模型", "tooltip": "要使用的模型。" }, "negative_prompt": { "name": "負向提示詞", "tooltip": "引導應避免內容的負向文字提示。" }, "prompt": { "name": "提示詞", "tooltip": "用於描述元素和視覺特徵的提示詞，支援英文/中文。" }, "prompt_extend": { "name": "提示詞擴展", "tooltip": "是否使用 AI 輔助增強提示詞。" }, "seed": { "name": "種子值", "tooltip": "用於生成的種子值。" }, "size": { "name": "尺寸" }, "watermark": { "name": "浮水印", "tooltip": "是否在結果中添加「AI 生成」浮水印。" } }, "outputs": { "0": { "tooltip": null } } };
const WanTrackToVideo = { "display_name": "Wan 追蹤轉影片", "inputs": { "batch_size": { "name": "批次大小" }, "clip_vision_output": { "name": "CLIP 視覺輸出" }, "height": { "name": "高度" }, "length": { "name": "長度" }, "negative": { "name": "負向" }, "positive": { "name": "正向" }, "start_image": { "name": "起始影像" }, "temperature": { "name": "溫度" }, "topk": { "name": "TopK" }, "tracks": { "name": "追蹤" }, "vae": { "name": "VAE" }, "width": { "name": "寬度" } }, "outputs": { "0": { "name": "正向", "tooltip": null }, "1": { "name": "負向", "tooltip": null }, "2": { "name": "潛在變數", "tooltip": null } } };
const WanVaceToVideo = { "display_name": "WAN 人臉轉影片", "inputs": { "batch_size": { "name": "批次大小" }, "control_masks": { "name": "控制遮罩" }, "control_video": { "name": "控制影片" }, "height": { "name": "高度" }, "length": { "name": "長度" }, "negative": { "name": "負向" }, "positive": { "name": "正向" }, "reference_image": { "name": "參考影像" }, "strength": { "name": "強度" }, "vae": { "name": "vae" }, "width": { "name": "寬度" } }, "outputs": { "0": { "name": "正向", "tooltip": null }, "1": { "name": "負向", "tooltip": null }, "2": { "name": "潛在空間", "tooltip": null }, "3": { "name": "裁剪潛空間", "tooltip": null } } };
const WebcamCapture = { "display_name": "網路攝影機擷取", "inputs": { "capture_on_queue": { "name": "排隊時擷取" }, "height": { "name": "高度" }, "image": { "name": "影像" }, "waiting for camera___": {}, "width": { "name": "寬度" } } };
const unCLIPCheckpointLoader = { "display_name": "unCLIP 檢查點載入器", "inputs": { "ckpt_name": { "name": "ckpt_name" } } };
const unCLIPConditioning = { "display_name": "unCLIP 條件化", "inputs": { "clip_vision_output": { "name": "clip_vision_output" }, "conditioning": { "name": "條件設定" }, "noise_augmentation": { "name": "雜訊增強" }, "strength": { "name": "強度" } } };
const nodeDefs = {
  APG,
  AddNoise,
  AlignYourStepsScheduler,
  AudioAdjustVolume,
  AudioConcat,
  AudioEncoderEncode,
  AudioEncoderLoader,
  AudioMerge,
  BasicGuider,
  BasicScheduler,
  BetaSamplingScheduler,
  ByteDanceFirstLastFrameNode,
  ByteDanceImageEditNode,
  ByteDanceImageNode,
  ByteDanceImageReferenceNode,
  ByteDanceImageToVideoNode,
  ByteDanceSeedreamNode,
  ByteDanceTextToVideoNode,
  CFGGuider,
  CFGNorm,
  CFGZeroStar,
  CLIPAttentionMultiply,
  CLIPLoader,
  CLIPMergeAdd,
  CLIPMergeSimple,
  CLIPMergeSubtract,
  CLIPSave,
  CLIPSetLastLayer,
  CLIPTextEncode,
  CLIPTextEncodeControlnet,
  CLIPTextEncodeFlux,
  CLIPTextEncodeHiDream,
  CLIPTextEncodeHunyuanDiT,
  CLIPTextEncodeLumina2,
  CLIPTextEncodePixArtAlpha,
  CLIPTextEncodeSD3,
  CLIPTextEncodeSDXL,
  CLIPTextEncodeSDXLRefiner,
  CLIPVisionEncode,
  CLIPVisionLoader,
  Canny,
  CaseConverter,
  CheckpointLoader,
  CheckpointLoaderSimple,
  CheckpointSave,
  ChromaRadianceOptions,
  CombineHooks2,
  CombineHooks4,
  CombineHooks8,
  ConditioningAverage,
  ConditioningCombine,
  ConditioningConcat,
  ConditioningSetArea,
  ConditioningSetAreaPercentage,
  ConditioningSetAreaPercentageVideo,
  ConditioningSetAreaStrength,
  ConditioningSetDefaultCombine,
  ConditioningSetMask,
  ConditioningSetProperties,
  ConditioningSetPropertiesAndCombine,
  ConditioningSetTimestepRange,
  ConditioningStableAudio,
  ConditioningTimestepsRange,
  ConditioningZeroOut,
  ContextWindowsManual,
  ControlNetApply,
  ControlNetApplyAdvanced,
  ControlNetApplySD3,
  ControlNetInpaintingAliMamaApply,
  ControlNetLoader,
  CosmosImageToVideoLatent,
  CosmosPredict2ImageToVideoLatent,
  CreateHookKeyframe,
  CreateHookKeyframesFromFloats,
  CreateHookKeyframesInterpolated,
  CreateHookLora,
  CreateHookLoraModelOnly,
  CreateHookModelAsLora,
  CreateHookModelAsLoraModelOnly,
  CreateVideo,
  CropMask,
  DiffControlNetLoader,
  DifferentialDiffusion,
  DiffusersLoader,
  DisableNoise,
  DualCFGGuider,
  DualCLIPLoader,
  EasyCache,
  EmptyAceStepLatentAudio,
  EmptyAudio,
  EmptyChromaRadianceLatentImage,
  EmptyCosmosLatentVideo,
  EmptyHunyuanImageLatent,
  EmptyHunyuanLatentVideo,
  EmptyImage,
  EmptyLTXVLatentVideo,
  EmptyLatentAudio,
  EmptyLatentHunyuan3Dv2,
  EmptyLatentImage,
  EmptyMochiLatentVideo,
  EmptySD3LatentImage,
  "Epsilon Scaling": { "display_name": "Epsilon縮放", "inputs": { "model": { "name": "模型" }, "scaling_factor": { "name": "縮放係數" } }, "outputs": { "0": { "tooltip": null } } },
  ExponentialScheduler,
  ExtendIntermediateSigmas,
  FeatherMask,
  FlipSigmas,
  FluxDisableGuidance,
  FluxGuidance,
  FluxKontextImageScale,
  FluxKontextMaxImageNode,
  FluxKontextMultiReferenceLatentMethod,
  FluxKontextProImageNode,
  FluxProExpandNode,
  FluxProFillNode,
  FluxProUltraImageNode,
  FreSca,
  FreeU,
  FreeU_V2,
  GITSScheduler,
  GLIGENLoader,
  GLIGENTextBoxApply,
  GeminiImageNode,
  GeminiInputFiles,
  GeminiNode,
  GetImageSize,
  GetVideoComponents,
  GrowMask,
  Hunyuan3Dv2Conditioning,
  Hunyuan3Dv2ConditioningMultiView,
  HunyuanImageToVideo,
  HunyuanRefinerLatent,
  HyperTile,
  HypernetworkLoader,
  IdeogramV1,
  IdeogramV2,
  IdeogramV3,
  ImageAddNoise,
  ImageBatch,
  ImageBlend,
  ImageBlur,
  ImageColorToMask,
  ImageCompositeMasked,
  ImageCrop,
  ImageFlip,
  ImageFromBatch,
  ImageInvert,
  ImageOnlyCheckpointLoader,
  ImageOnlyCheckpointSave,
  ImagePadForOutpaint,
  ImageQuantize,
  ImageRGBToYUV,
  ImageRotate,
  ImageScale,
  ImageScaleBy,
  ImageScaleToMaxDimension,
  ImageScaleToTotalPixels,
  ImageSharpen,
  ImageStitch,
  ImageToMask,
  ImageUpscaleWithModel,
  ImageYUVToRGB,
  InpaintModelConditioning,
  InstructPixToPixConditioning,
  InvertMask,
  JoinImageWithAlpha,
  KSampler,
  KSamplerAdvanced,
  KSamplerSelect,
  KarrasScheduler,
  KlingCameraControlI2VNode,
  KlingCameraControlT2VNode,
  KlingCameraControls,
  KlingDualCharacterVideoEffectNode,
  KlingImage2VideoNode,
  KlingImageGenerationNode,
  KlingLipSyncAudioToVideoNode,
  KlingLipSyncTextToVideoNode,
  KlingSingleImageVideoEffectNode,
  KlingStartEndFrameNode,
  KlingTextToVideoNode,
  KlingVideoExtendNode,
  KlingVirtualTryOnNode,
  LTXVAddGuide,
  LTXVConditioning,
  LTXVCropGuides,
  LTXVImgToVideo,
  LTXVPreprocess,
  LTXVScheduler,
  LaplaceScheduler,
  LatentAdd,
  LatentApplyOperation,
  LatentApplyOperationCFG,
  LatentBatch,
  LatentBatchSeedBehavior,
  LatentBlend,
  LatentComposite,
  LatentCompositeMasked,
  LatentConcat,
  LatentCrop,
  LatentCut,
  LatentFlip,
  LatentFromBatch,
  LatentInterpolate,
  LatentMultiply,
  LatentOperationSharpen,
  LatentOperationTonemapReinhard,
  LatentRotate,
  LatentSubtract,
  LatentUpscale,
  LatentUpscaleBy,
  LazyCache,
  Load3D,
  LoadAudio,
  LoadImage,
  LoadImageMask,
  LoadImageOutput,
  LoadLatent,
  LoadVideo,
  LoraLoader,
  LoraLoaderModelOnly,
  LoraModelLoader,
  LoraSave,
  LossGraphNode,
  LotusConditioning,
  LtxvApiImageToVideo,
  LtxvApiTextToVideo,
  LumaConceptsNode,
  LumaImageModifyNode,
  LumaImageNode,
  LumaImageToVideoNode,
  LumaReferenceNode,
  LumaVideoNode,
  Mahiro,
  MaskComposite,
  MaskPreview,
  MaskToImage,
  MinimaxHailuoVideoNode,
  MinimaxImageToVideoNode,
  MinimaxTextToVideoNode,
  ModelComputeDtype,
  ModelMergeAdd,
  ModelMergeAuraflow,
  ModelMergeBlocks,
  ModelMergeCosmos14B,
  ModelMergeCosmos7B,
  ModelMergeCosmosPredict2_14B,
  ModelMergeCosmosPredict2_2B,
  ModelMergeFlux1,
  ModelMergeLTXV,
  ModelMergeMochiPreview,
  ModelMergeQwenImage,
  ModelMergeSD1,
  ModelMergeSD2,
  ModelMergeSD35_Large,
  ModelMergeSD3_2B,
  ModelMergeSDXL,
  ModelMergeSimple,
  ModelMergeSubtract,
  ModelMergeWAN2_1,
  ModelPatchLoader,
  ModelSamplingAuraFlow,
  ModelSamplingContinuousEDM,
  ModelSamplingContinuousV,
  ModelSamplingDiscrete,
  ModelSamplingFlux,
  ModelSamplingLTXV,
  ModelSamplingSD3,
  ModelSamplingStableCascade,
  ModelSave,
  MoonvalleyImg2VideoNode,
  MoonvalleyTxt2VideoNode,
  MoonvalleyVideo2VideoNode,
  Morphology,
  OpenAIChatConfig,
  OpenAIChatNode,
  OpenAIDalle2,
  OpenAIDalle3,
  OpenAIGPTImage1,
  OpenAIInputFiles,
  OpenAIVideoSora2,
  OptimalStepsScheduler,
  PairConditioningCombine,
  PairConditioningSetDefaultCombine,
  PairConditioningSetProperties,
  PairConditioningSetPropertiesAndCombine,
  PatchModelAddDownscale,
  PerpNeg,
  PerpNegGuider,
  PerturbedAttentionGuidance,
  PhotoMakerEncode,
  PhotoMakerLoader,
  PixverseImageToVideoNode,
  PixverseTemplateNode,
  PixverseTextToVideoNode,
  PixverseTransitionVideoNode,
  PolyexponentialScheduler,
  PorterDuffImageComposite,
  Preview3D,
  PreviewAny,
  PreviewAudio,
  PreviewImage,
  PrimitiveBoolean,
  PrimitiveFloat,
  PrimitiveInt,
  PrimitiveString,
  PrimitiveStringMultiline,
  QuadrupleCLIPLoader,
  QwenImageDiffsynthControlnet,
  RandomNoise,
  RebatchImages,
  RebatchLatents,
  RecordAudio,
  RecraftColorRGB,
  RecraftControls,
  RecraftCreativeUpscaleNode,
  RecraftCrispUpscaleNode,
  RecraftImageInpaintingNode,
  RecraftImageToImageNode,
  RecraftRemoveBackgroundNode,
  RecraftReplaceBackgroundNode,
  RecraftStyleV3DigitalIllustration,
  RecraftStyleV3InfiniteStyleLibrary,
  RecraftStyleV3LogoRaster,
  RecraftStyleV3RealisticImage,
  RecraftTextToImageNode,
  RecraftTextToVectorNode,
  RecraftVectorizeImageNode,
  ReferenceLatent,
  RegexExtract,
  RegexMatch,
  RegexReplace,
  RenormCFG,
  RepeatImageBatch,
  RepeatLatentBatch,
  RescaleCFG,
  ResizeAndPadImage,
  Rodin3D_Detail,
  Rodin3D_Gen2,
  Rodin3D_Regular,
  Rodin3D_Sketch,
  Rodin3D_Smooth,
  RunwayFirstLastFrameNode,
  RunwayImageToVideoNodeGen3a,
  RunwayImageToVideoNodeGen4,
  RunwayTextToImageNode,
  SDTurboScheduler,
  SD_4XUpscale_Conditioning,
  SV3D_Conditioning,
  SVD_img2vid_Conditioning,
  SamplerCustom,
  SamplerCustomAdvanced,
  SamplerDPMAdaptative,
  SamplerDPMPP_2M_SDE,
  SamplerDPMPP_2S_Ancestral,
  SamplerDPMPP_3M_SDE,
  SamplerDPMPP_SDE,
  SamplerER_SDE,
  SamplerEulerAncestral,
  SamplerEulerAncestralCFGPP,
  SamplerEulerCFGpp,
  SamplerLCMUpscale,
  SamplerLMS,
  SamplerSASolver,
  SamplingPercentToSigma,
  SaveAnimatedPNG,
  SaveAnimatedWEBP,
  SaveAudio,
  SaveAudioMP3,
  SaveAudioOpus,
  SaveGLB,
  SaveImage,
  SaveImageWebsocket,
  SaveLatent,
  SaveSVGNode,
  SaveVideo,
  SaveWEBM,
  ScaleROPE,
  SelfAttentionGuidance,
  SetClipHooks,
  SetFirstSigma,
  SetHookKeyframes,
  SetLatentNoiseMask,
  SetUnionControlNetType,
  SkipLayerGuidanceDiT,
  SkipLayerGuidanceDiTSimple,
  SkipLayerGuidanceSD3,
  SolidMask,
  SplitAudioChannels,
  SplitImageWithAlpha,
  SplitSigmas,
  SplitSigmasDenoise,
  StabilityAudioInpaint,
  StabilityAudioToAudio,
  StabilityStableImageSD_3_5Node,
  StabilityStableImageUltraNode,
  StabilityTextToAudio,
  StabilityUpscaleConservativeNode,
  StabilityUpscaleCreativeNode,
  StabilityUpscaleFastNode,
  StableCascade_EmptyLatentImage,
  StableCascade_StageB_Conditioning,
  StableCascade_StageC_VAEEncode,
  StableCascade_SuperResolutionControlnet,
  StableZero123_Conditioning,
  StableZero123_Conditioning_Batched,
  StringCompare,
  StringConcatenate,
  StringContains,
  StringLength,
  StringReplace,
  StringSubstring,
  StringTrim,
  StyleModelApply,
  StyleModelLoader,
  T5TokenizerOptions,
  TCFG,
  TemporalScoreRescaling,
  TextEncodeAceStepAudio,
  TextEncodeHunyuanVideo_ImageToVideo,
  TextEncodeQwenImageEdit,
  TextEncodeQwenImageEditPlus,
  ThresholdMask,
  TomePatchModel,
  TorchCompileModel,
  TrainLoraNode,
  TrimAudioDuration,
  TrimVideoLatent,
  TripleCLIPLoader,
  TripoConversionNode,
  TripoImageToModelNode,
  TripoMultiviewToModelNode,
  TripoRefineNode,
  TripoRetargetNode,
  TripoRigNode,
  TripoTextToModelNode,
  TripoTextureNode,
  UNETLoader,
  UNetCrossAttentionMultiply,
  UNetSelfAttentionMultiply,
  UNetTemporalAttentionMultiply,
  USOStyleReference,
  UpscaleModelLoader,
  VAEDecode,
  VAEDecodeAudio,
  VAEDecodeHunyuan3D,
  VAEDecodeTiled,
  VAEEncode,
  VAEEncodeAudio,
  VAEEncodeForInpaint,
  VAEEncodeTiled,
  VAELoader,
  VAESave,
  VPScheduler,
  Veo3VideoGenerationNode,
  VeoVideoGenerationNode,
  VideoLinearCFGGuidance,
  VideoTriangleCFGGuidance,
  ViduImageToVideoNode,
  ViduReferenceVideoNode,
  ViduStartEndToVideoNode,
  ViduTextToVideoNode,
  VoxelToMesh,
  VoxelToMeshBasic,
  Wan22FunControlToVideo,
  Wan22ImageToVideoLatent,
  WanAnimateToVideo,
  WanCameraEmbedding,
  WanCameraImageToVideo,
  WanContextWindowsManual,
  WanFirstLastFrameToVideo,
  WanFunControlToVideo,
  WanFunInpaintToVideo,
  WanHuMoImageToVideo,
  WanImageToImageApi,
  WanImageToVideo,
  WanImageToVideoApi,
  WanPhantomSubjectToVideo,
  WanSoundImageToVideo,
  WanSoundImageToVideoExtend,
  WanTextToImageApi,
  WanTextToVideoApi,
  WanTrackToVideo,
  WanVaceToVideo,
  WebcamCapture,
  unCLIPCheckpointLoader,
  unCLIPConditioning
};
export {
  APG,
  AddNoise,
  AlignYourStepsScheduler,
  AudioAdjustVolume,
  AudioConcat,
  AudioEncoderEncode,
  AudioEncoderLoader,
  AudioMerge,
  BasicGuider,
  BasicScheduler,
  BetaSamplingScheduler,
  ByteDanceFirstLastFrameNode,
  ByteDanceImageEditNode,
  ByteDanceImageNode,
  ByteDanceImageReferenceNode,
  ByteDanceImageToVideoNode,
  ByteDanceSeedreamNode,
  ByteDanceTextToVideoNode,
  CFGGuider,
  CFGNorm,
  CFGZeroStar,
  CLIPAttentionMultiply,
  CLIPLoader,
  CLIPMergeAdd,
  CLIPMergeSimple,
  CLIPMergeSubtract,
  CLIPSave,
  CLIPSetLastLayer,
  CLIPTextEncode,
  CLIPTextEncodeControlnet,
  CLIPTextEncodeFlux,
  CLIPTextEncodeHiDream,
  CLIPTextEncodeHunyuanDiT,
  CLIPTextEncodeLumina2,
  CLIPTextEncodePixArtAlpha,
  CLIPTextEncodeSD3,
  CLIPTextEncodeSDXL,
  CLIPTextEncodeSDXLRefiner,
  CLIPVisionEncode,
  CLIPVisionLoader,
  Canny,
  CaseConverter,
  CheckpointLoader,
  CheckpointLoaderSimple,
  CheckpointSave,
  ChromaRadianceOptions,
  CombineHooks2,
  CombineHooks4,
  CombineHooks8,
  ConditioningAverage,
  ConditioningCombine,
  ConditioningConcat,
  ConditioningSetArea,
  ConditioningSetAreaPercentage,
  ConditioningSetAreaPercentageVideo,
  ConditioningSetAreaStrength,
  ConditioningSetDefaultCombine,
  ConditioningSetMask,
  ConditioningSetProperties,
  ConditioningSetPropertiesAndCombine,
  ConditioningSetTimestepRange,
  ConditioningStableAudio,
  ConditioningTimestepsRange,
  ConditioningZeroOut,
  ContextWindowsManual,
  ControlNetApply,
  ControlNetApplyAdvanced,
  ControlNetApplySD3,
  ControlNetInpaintingAliMamaApply,
  ControlNetLoader,
  CosmosImageToVideoLatent,
  CosmosPredict2ImageToVideoLatent,
  CreateHookKeyframe,
  CreateHookKeyframesFromFloats,
  CreateHookKeyframesInterpolated,
  CreateHookLora,
  CreateHookLoraModelOnly,
  CreateHookModelAsLora,
  CreateHookModelAsLoraModelOnly,
  CreateVideo,
  CropMask,
  DiffControlNetLoader,
  DifferentialDiffusion,
  DiffusersLoader,
  DisableNoise,
  DualCFGGuider,
  DualCLIPLoader,
  EasyCache,
  EmptyAceStepLatentAudio,
  EmptyAudio,
  EmptyChromaRadianceLatentImage,
  EmptyCosmosLatentVideo,
  EmptyHunyuanImageLatent,
  EmptyHunyuanLatentVideo,
  EmptyImage,
  EmptyLTXVLatentVideo,
  EmptyLatentAudio,
  EmptyLatentHunyuan3Dv2,
  EmptyLatentImage,
  EmptyMochiLatentVideo,
  EmptySD3LatentImage,
  ExponentialScheduler,
  ExtendIntermediateSigmas,
  FeatherMask,
  FlipSigmas,
  FluxDisableGuidance,
  FluxGuidance,
  FluxKontextImageScale,
  FluxKontextMaxImageNode,
  FluxKontextMultiReferenceLatentMethod,
  FluxKontextProImageNode,
  FluxProExpandNode,
  FluxProFillNode,
  FluxProUltraImageNode,
  FreSca,
  FreeU,
  FreeU_V2,
  GITSScheduler,
  GLIGENLoader,
  GLIGENTextBoxApply,
  GeminiImageNode,
  GeminiInputFiles,
  GeminiNode,
  GetImageSize,
  GetVideoComponents,
  GrowMask,
  Hunyuan3Dv2Conditioning,
  Hunyuan3Dv2ConditioningMultiView,
  HunyuanImageToVideo,
  HunyuanRefinerLatent,
  HyperTile,
  HypernetworkLoader,
  IdeogramV1,
  IdeogramV2,
  IdeogramV3,
  ImageAddNoise,
  ImageBatch,
  ImageBlend,
  ImageBlur,
  ImageColorToMask,
  ImageCompositeMasked,
  ImageCrop,
  ImageFlip,
  ImageFromBatch,
  ImageInvert,
  ImageOnlyCheckpointLoader,
  ImageOnlyCheckpointSave,
  ImagePadForOutpaint,
  ImageQuantize,
  ImageRGBToYUV,
  ImageRotate,
  ImageScale,
  ImageScaleBy,
  ImageScaleToMaxDimension,
  ImageScaleToTotalPixels,
  ImageSharpen,
  ImageStitch,
  ImageToMask,
  ImageUpscaleWithModel,
  ImageYUVToRGB,
  InpaintModelConditioning,
  InstructPixToPixConditioning,
  InvertMask,
  JoinImageWithAlpha,
  KSampler,
  KSamplerAdvanced,
  KSamplerSelect,
  KarrasScheduler,
  KlingCameraControlI2VNode,
  KlingCameraControlT2VNode,
  KlingCameraControls,
  KlingDualCharacterVideoEffectNode,
  KlingImage2VideoNode,
  KlingImageGenerationNode,
  KlingLipSyncAudioToVideoNode,
  KlingLipSyncTextToVideoNode,
  KlingSingleImageVideoEffectNode,
  KlingStartEndFrameNode,
  KlingTextToVideoNode,
  KlingVideoExtendNode,
  KlingVirtualTryOnNode,
  LTXVAddGuide,
  LTXVConditioning,
  LTXVCropGuides,
  LTXVImgToVideo,
  LTXVPreprocess,
  LTXVScheduler,
  LaplaceScheduler,
  LatentAdd,
  LatentApplyOperation,
  LatentApplyOperationCFG,
  LatentBatch,
  LatentBatchSeedBehavior,
  LatentBlend,
  LatentComposite,
  LatentCompositeMasked,
  LatentConcat,
  LatentCrop,
  LatentCut,
  LatentFlip,
  LatentFromBatch,
  LatentInterpolate,
  LatentMultiply,
  LatentOperationSharpen,
  LatentOperationTonemapReinhard,
  LatentRotate,
  LatentSubtract,
  LatentUpscale,
  LatentUpscaleBy,
  LazyCache,
  Load3D,
  LoadAudio,
  LoadImage,
  LoadImageMask,
  LoadImageOutput,
  LoadLatent,
  LoadVideo,
  LoraLoader,
  LoraLoaderModelOnly,
  LoraModelLoader,
  LoraSave,
  LossGraphNode,
  LotusConditioning,
  LtxvApiImageToVideo,
  LtxvApiTextToVideo,
  LumaConceptsNode,
  LumaImageModifyNode,
  LumaImageNode,
  LumaImageToVideoNode,
  LumaReferenceNode,
  LumaVideoNode,
  Mahiro,
  MaskComposite,
  MaskPreview,
  MaskToImage,
  MinimaxHailuoVideoNode,
  MinimaxImageToVideoNode,
  MinimaxTextToVideoNode,
  ModelComputeDtype,
  ModelMergeAdd,
  ModelMergeAuraflow,
  ModelMergeBlocks,
  ModelMergeCosmos14B,
  ModelMergeCosmos7B,
  ModelMergeCosmosPredict2_14B,
  ModelMergeCosmosPredict2_2B,
  ModelMergeFlux1,
  ModelMergeLTXV,
  ModelMergeMochiPreview,
  ModelMergeQwenImage,
  ModelMergeSD1,
  ModelMergeSD2,
  ModelMergeSD35_Large,
  ModelMergeSD3_2B,
  ModelMergeSDXL,
  ModelMergeSimple,
  ModelMergeSubtract,
  ModelMergeWAN2_1,
  ModelPatchLoader,
  ModelSamplingAuraFlow,
  ModelSamplingContinuousEDM,
  ModelSamplingContinuousV,
  ModelSamplingDiscrete,
  ModelSamplingFlux,
  ModelSamplingLTXV,
  ModelSamplingSD3,
  ModelSamplingStableCascade,
  ModelSave,
  MoonvalleyImg2VideoNode,
  MoonvalleyTxt2VideoNode,
  MoonvalleyVideo2VideoNode,
  Morphology,
  OpenAIChatConfig,
  OpenAIChatNode,
  OpenAIDalle2,
  OpenAIDalle3,
  OpenAIGPTImage1,
  OpenAIInputFiles,
  OpenAIVideoSora2,
  OptimalStepsScheduler,
  PairConditioningCombine,
  PairConditioningSetDefaultCombine,
  PairConditioningSetProperties,
  PairConditioningSetPropertiesAndCombine,
  PatchModelAddDownscale,
  PerpNeg,
  PerpNegGuider,
  PerturbedAttentionGuidance,
  PhotoMakerEncode,
  PhotoMakerLoader,
  PixverseImageToVideoNode,
  PixverseTemplateNode,
  PixverseTextToVideoNode,
  PixverseTransitionVideoNode,
  PolyexponentialScheduler,
  PorterDuffImageComposite,
  Preview3D,
  PreviewAny,
  PreviewAudio,
  PreviewImage,
  PrimitiveBoolean,
  PrimitiveFloat,
  PrimitiveInt,
  PrimitiveString,
  PrimitiveStringMultiline,
  QuadrupleCLIPLoader,
  QwenImageDiffsynthControlnet,
  RandomNoise,
  RebatchImages,
  RebatchLatents,
  RecordAudio,
  RecraftColorRGB,
  RecraftControls,
  RecraftCreativeUpscaleNode,
  RecraftCrispUpscaleNode,
  RecraftImageInpaintingNode,
  RecraftImageToImageNode,
  RecraftRemoveBackgroundNode,
  RecraftReplaceBackgroundNode,
  RecraftStyleV3DigitalIllustration,
  RecraftStyleV3InfiniteStyleLibrary,
  RecraftStyleV3LogoRaster,
  RecraftStyleV3RealisticImage,
  RecraftTextToImageNode,
  RecraftTextToVectorNode,
  RecraftVectorizeImageNode,
  ReferenceLatent,
  RegexExtract,
  RegexMatch,
  RegexReplace,
  RenormCFG,
  RepeatImageBatch,
  RepeatLatentBatch,
  RescaleCFG,
  ResizeAndPadImage,
  Rodin3D_Detail,
  Rodin3D_Gen2,
  Rodin3D_Regular,
  Rodin3D_Sketch,
  Rodin3D_Smooth,
  RunwayFirstLastFrameNode,
  RunwayImageToVideoNodeGen3a,
  RunwayImageToVideoNodeGen4,
  RunwayTextToImageNode,
  SDTurboScheduler,
  SD_4XUpscale_Conditioning,
  SV3D_Conditioning,
  SVD_img2vid_Conditioning,
  SamplerCustom,
  SamplerCustomAdvanced,
  SamplerDPMAdaptative,
  SamplerDPMPP_2M_SDE,
  SamplerDPMPP_2S_Ancestral,
  SamplerDPMPP_3M_SDE,
  SamplerDPMPP_SDE,
  SamplerER_SDE,
  SamplerEulerAncestral,
  SamplerEulerAncestralCFGPP,
  SamplerEulerCFGpp,
  SamplerLCMUpscale,
  SamplerLMS,
  SamplerSASolver,
  SamplingPercentToSigma,
  SaveAnimatedPNG,
  SaveAnimatedWEBP,
  SaveAudio,
  SaveAudioMP3,
  SaveAudioOpus,
  SaveGLB,
  SaveImage,
  SaveImageWebsocket,
  SaveLatent,
  SaveSVGNode,
  SaveVideo,
  SaveWEBM,
  ScaleROPE,
  SelfAttentionGuidance,
  SetClipHooks,
  SetFirstSigma,
  SetHookKeyframes,
  SetLatentNoiseMask,
  SetUnionControlNetType,
  SkipLayerGuidanceDiT,
  SkipLayerGuidanceDiTSimple,
  SkipLayerGuidanceSD3,
  SolidMask,
  SplitAudioChannels,
  SplitImageWithAlpha,
  SplitSigmas,
  SplitSigmasDenoise,
  StabilityAudioInpaint,
  StabilityAudioToAudio,
  StabilityStableImageSD_3_5Node,
  StabilityStableImageUltraNode,
  StabilityTextToAudio,
  StabilityUpscaleConservativeNode,
  StabilityUpscaleCreativeNode,
  StabilityUpscaleFastNode,
  StableCascade_EmptyLatentImage,
  StableCascade_StageB_Conditioning,
  StableCascade_StageC_VAEEncode,
  StableCascade_SuperResolutionControlnet,
  StableZero123_Conditioning,
  StableZero123_Conditioning_Batched,
  StringCompare,
  StringConcatenate,
  StringContains,
  StringLength,
  StringReplace,
  StringSubstring,
  StringTrim,
  StyleModelApply,
  StyleModelLoader,
  T5TokenizerOptions,
  TCFG,
  TemporalScoreRescaling,
  TextEncodeAceStepAudio,
  TextEncodeHunyuanVideo_ImageToVideo,
  TextEncodeQwenImageEdit,
  TextEncodeQwenImageEditPlus,
  ThresholdMask,
  TomePatchModel,
  TorchCompileModel,
  TrainLoraNode,
  TrimAudioDuration,
  TrimVideoLatent,
  TripleCLIPLoader,
  TripoConversionNode,
  TripoImageToModelNode,
  TripoMultiviewToModelNode,
  TripoRefineNode,
  TripoRetargetNode,
  TripoRigNode,
  TripoTextToModelNode,
  TripoTextureNode,
  UNETLoader,
  UNetCrossAttentionMultiply,
  UNetSelfAttentionMultiply,
  UNetTemporalAttentionMultiply,
  USOStyleReference,
  UpscaleModelLoader,
  VAEDecode,
  VAEDecodeAudio,
  VAEDecodeHunyuan3D,
  VAEDecodeTiled,
  VAEEncode,
  VAEEncodeAudio,
  VAEEncodeForInpaint,
  VAEEncodeTiled,
  VAELoader,
  VAESave,
  VPScheduler,
  Veo3VideoGenerationNode,
  VeoVideoGenerationNode,
  VideoLinearCFGGuidance,
  VideoTriangleCFGGuidance,
  ViduImageToVideoNode,
  ViduReferenceVideoNode,
  ViduStartEndToVideoNode,
  ViduTextToVideoNode,
  VoxelToMesh,
  VoxelToMeshBasic,
  Wan22FunControlToVideo,
  Wan22ImageToVideoLatent,
  WanAnimateToVideo,
  WanCameraEmbedding,
  WanCameraImageToVideo,
  WanContextWindowsManual,
  WanFirstLastFrameToVideo,
  WanFunControlToVideo,
  WanFunInpaintToVideo,
  WanHuMoImageToVideo,
  WanImageToImageApi,
  WanImageToVideo,
  WanImageToVideoApi,
  WanPhantomSubjectToVideo,
  WanSoundImageToVideo,
  WanSoundImageToVideoExtend,
  WanTextToImageApi,
  WanTextToVideoApi,
  WanTrackToVideo,
  WanVaceToVideo,
  WebcamCapture,
  nodeDefs as default,
  unCLIPCheckpointLoader,
  unCLIPConditioning
};
//# sourceMappingURL=nodeDefs-CCEXtYfM.js.map
