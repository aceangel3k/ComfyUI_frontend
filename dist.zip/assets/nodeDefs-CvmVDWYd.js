const APG = { "display_name": "Адаптивное проекционное управление", "inputs": { "eta": { "name": "эта", "tooltip": "Управляет масштабом вектора параллельного управления. Стандартное поведение CFG при значении 1." }, "model": { "name": "модель" }, "momentum": { "name": "импульс", "tooltip": "Управляет скользящим средним управления во время диффузии, отключено при значении 0." }, "norm_threshold": { "name": "порог_нормализации", "tooltip": "Нормализовать вектор управления до этого значения, нормализация отключена при значении 0." } }, "outputs": { "0": { "tooltip": null } } };
const AddNoise = { "display_name": "Добавить шум", "inputs": { "latent_image": { "name": "латентное_изображение" }, "model": { "name": "модель" }, "noise": { "name": "шум" }, "sigmas": { "name": "сигмы" } } };
const AlignYourStepsScheduler = { "display_name": "Scheduler выравнивания шагов", "inputs": { "denoise": { "name": "шумоподавление" }, "model_type": { "name": "тип_модели" }, "steps": { "name": "шаги" } }, "outputs": { "0": { "tooltip": null } } };
const AudioAdjustVolume = { "display_name": "Аудио - Настроить громкость", "inputs": { "audio": { "name": "аудио" }, "volume": { "name": "громкость", "tooltip": "Корректировка громкости в децибелах (дБ). 0 = без изменений, +6 = удвоение, -6 = половина и т.д." } } };
const AudioConcat = { "description": "Соединяет audio1 с audio2 в указанном направлении.", "display_name": "Аудио - Конкатенация", "inputs": { "audio1": { "name": "audio1" }, "audio2": { "name": "audio2" }, "direction": { "name": "направление", "tooltip": "Добавлять audio2 после или перед audio1." } } };
const AudioEncoderEncode = { "display_name": "Аудиоэнкодер - Кодирование", "inputs": { "audio": { "name": "аудио" }, "audio_encoder": { "name": "аудио_энкодер" } }, "outputs": { "0": { "tooltip": null } } };
const AudioEncoderLoader = { "display_name": "Аудиоэнкодер - Загрузчик", "inputs": { "audio_encoder_name": { "name": "имя_аудио_энкодера" } }, "outputs": { "0": { "tooltip": null } } };
const AudioMerge = { "description": "Объединить две аудиодорожки путем наложения их волновых форм.", "display_name": "Аудио - Слияние", "inputs": { "audio1": { "name": "audio1" }, "audio2": { "name": "audio2" }, "merge_method": { "name": "метод_слияния", "tooltip": "Метод, используемый для объединения аудиоволн." } } };
const BasicGuider = { "display_name": "Основной гид", "inputs": { "conditioning": { "name": "кондиционирование" }, "model": { "name": "модель" } } };
const BasicScheduler = { "display_name": "Основной scheduler", "inputs": { "denoise": { "name": "шумоподавление" }, "model": { "name": "модель" }, "scheduler": { "name": "scheduler" }, "steps": { "name": "шаги" } } };
const BetaSamplingScheduler = { "display_name": "Scheduler выборки Бета", "inputs": { "alpha": { "name": "альфа" }, "beta": { "name": "бета" }, "model": { "name": "модель" }, "steps": { "name": "шаги" } } };
const ByteDanceFirstLastFrameNode = { "description": "Создать видео с использованием промпта и первого и последнего кадров.", "display_name": "ByteDance - Преобразование первого-последнего кадра в видео", "inputs": { "aspect_ratio": { "name": "aspect_ratio", "tooltip": "Соотношение сторон выходного видео." }, "camera_fixed": { "name": "camera_fixed", "tooltip": "Определяет, следует ли фиксировать камеру. Платформа добавляет инструкцию по фиксации камеры к вашему промпту, но не гарантирует фактический эффект." }, "control_after_generate": { "name": "control after generate" }, "duration": { "name": "duration", "tooltip": "Продолжительность выходного видео в секундах." }, "first_frame": { "name": "first_frame", "tooltip": "Первый кадр, который будет использоваться для видео." }, "last_frame": { "name": "last_frame", "tooltip": "Последний кадр, который будет использоваться для видео." }, "model": { "name": "модель" }, "prompt": { "name": "промпт", "tooltip": "Текстовый промпт, используемый для создания видео." }, "resolution": { "name": "resolution", "tooltip": "Разрешение выходного видео." }, "seed": { "name": "seed", "tooltip": "Сид для использования при генерации." }, "watermark": { "name": "watermark", "tooltip": 'Добавлять ли водяной знак "Сгенерировано ИИ" на видео.' } }, "outputs": { "0": { "tooltip": null } } };
const ByteDanceImageEditNode = { "description": "Редактирование изображений с использованием моделей ByteDance через API на основе промпта", "display_name": "Редактирование изображений ByteDance", "inputs": { "control_after_generate": { "name": "control after generate" }, "guidance_scale": { "name": "guidance_scale", "tooltip": "Более высокое значение заставляет изображение точнее следовать промпту" }, "image": { "name": "image", "tooltip": "Базовое изображение для редактирования" }, "model": { "name": "model" }, "prompt": { "name": "prompt", "tooltip": "Инструкция для редактирования изображения" }, "seed": { "name": "seed", "tooltip": "Сид для использования при генерации" }, "watermark": { "name": "watermark", "tooltip": 'Добавлять ли водяной знак "Сгенерировано ИИ" на изображение' } }, "outputs": { "0": { "tooltip": null } } };
const ByteDanceImageNode = { "description": "Генерация изображений с использованием моделей ByteDance через API на основе промпта", "display_name": "Изображение ByteDance", "inputs": { "control_after_generate": { "name": "управление после генерации" }, "guidance_scale": { "name": "коэффициент_направленности", "tooltip": "Более высокое значение заставляет изображение точнее следовать промпту" }, "height": { "name": "высота", "tooltip": "Пользовательская высота изображения. Значение работает только если `размер_пресет` установлен в `Пользовательский`" }, "model": { "name": "model" }, "prompt": { "name": "промпт", "tooltip": "Текстовый промпт, используемый для генерации изображения" }, "seed": { "name": "сид", "tooltip": "Сид для использования при генерации" }, "size_preset": { "name": "размер_пресет", "tooltip": "Выберите рекомендуемый размер. Выберите 'Пользовательский', чтобы использовать ширину и высоту ниже" }, "watermark": { "name": "водяной_знак", "tooltip": 'Добавлять ли водяной знак "Сгенерировано ИИ" на изображение' }, "width": { "name": "ширина", "tooltip": "Пользовательская ширина изображения. Значение работает только если `размер_пресет` установлен в `Пользовательский`" } }, "outputs": { "0": { "tooltip": null } } };
const ByteDanceImageReferenceNode = { "description": "Сгенерировать видео с использованием промпта и референсных изображений.", "display_name": "ByteDance Reference Images to Video", "inputs": { "aspect_ratio": { "name": "соотношение_сторон", "tooltip": "Соотношение сторон выходного видео." }, "control_after_generate": { "name": "управление после генерации" }, "duration": { "name": "длительность", "tooltip": "Длительность выходного видео в секундах." }, "images": { "name": "изображения", "tooltip": "От одного до четырёх изображений." }, "model": { "name": "модель" }, "prompt": { "name": "промпт", "tooltip": "Текстовый промпт, используемый для генерации видео." }, "resolution": { "name": "разрешение", "tooltip": "Разрешение выходного видео." }, "seed": { "name": "сид", "tooltip": "Сид для использования при генерации." }, "watermark": { "name": "водяной_знак", "tooltip": 'Добавлять ли водяной знак "Сгенерировано ИИ" на видео.' } }, "outputs": { "0": { "tooltip": null } } };
const ByteDanceImageToVideoNode = { "description": "Создание видео с использованием моделей ByteDance через API на основе изображения и промпта", "display_name": "ByteDance Image to Video", "inputs": { "aspect_ratio": { "name": "aspect_ratio", "tooltip": "Соотношение сторон выходного видео." }, "camera_fixed": { "name": "camera_fixed", "tooltip": "Определяет, следует ли фиксировать камеру. Платформа добавляет инструкцию по фиксации камеры к вашему промпту, но не гарантирует фактический эффект." }, "control_after_generate": { "name": "control after generate" }, "duration": { "name": "duration", "tooltip": "Продолжительность видео в секундах." }, "image": { "name": "image", "tooltip": "Первый кадр, который будет использоваться для видео." }, "model": { "name": "model" }, "prompt": { "name": "prompt", "tooltip": "Текстовый промпт, используемый для создания видео." }, "resolution": { "name": "resolution", "tooltip": "Разрешение выходного видео." }, "seed": { "name": "seed", "tooltip": "Сид для использования при генерации." }, "watermark": { "name": "watermark", "tooltip": 'Добавлять ли водяной знак "Создано ИИ" на видео.' } }, "outputs": { "0": { "tooltip": null } } };
const ByteDanceSeedreamNode = { "description": "Унифицированная генерация изображений из текста и точное редактирование одним предложением с разрешением до 4K.", "display_name": "ByteDance Seedream 4", "inputs": { "control_after_generate": { "name": "управление после генерации" }, "fail_on_partial": { "name": "прерывать_при_частичном", "tooltip": "Если включено, прерывать выполнение при отсутствии любых запрошенных изображений или ошибке." }, "height": { "name": "height", "tooltip": "Пользовательская высота изображения. Значение работает только если `size_preset` установлен в `Custom`" }, "image": { "name": "image", "tooltip": "Входные изображения для генерации из изображения в изображение. Список из 1-10 изображений для одиночной или многократной генерации." }, "max_images": { "name": "максимум_изображений", "tooltip": "Максимальное количество изображений для генерации при sequential_image_generation='auto'. Общее количество изображений (входные + сгенерированные) не может превышать 15." }, "model": { "name": "model", "tooltip": "Название модели" }, "prompt": { "name": "prompt", "tooltip": "Текстовый промпт для создания или редактирования изображения." }, "seed": { "name": "сид", "tooltip": "Сид для использования при генерации." }, "sequential_image_generation": { "name": "последовательная_генерация_изображений", "tooltip": "Режим групповой генерации изображений. 'disabled' создаёт одно изображение. 'auto' позволяет модели решить, генерировать ли несколько связанных изображений (например, сцены истории, вариации персонажей)." }, "size_preset": { "name": "size_preset", "tooltip": 'Выберите рекомендуемый размер. Выберите "Custom", чтобы использовать ширину и высоту ниже.' }, "watermark": { "name": "водяной_знак", "tooltip": 'Добавлять ли водяной знак "Сгенерировано ИИ" на изображение.' }, "width": { "name": "width", "tooltip": "Пользовательская ширина изображения. Значение работает только если `size_preset` установлен в `Custom`" } }, "outputs": { "0": { "tooltip": null } } };
const ByteDanceTextToVideoNode = { "description": "Создать видео с использованием моделей ByteDance через API на основе промпта", "display_name": "ByteDance Текст в Видео", "inputs": { "aspect_ratio": { "name": "соотношение_сторон", "tooltip": "Соотношение сторон выходного видео." }, "camera_fixed": { "name": "камера_зафиксирована", "tooltip": "Определяет, следует ли фиксировать камеру. Платформа добавляет инструкцию по фиксации камеры к вашему промпту, но не гарантирует фактический эффект." }, "control_after_generate": { "name": "управление после генерации" }, "duration": { "name": "длительность", "tooltip": "Длительность выходного видео в секундах." }, "model": { "name": "модель" }, "prompt": { "name": "промпт", "tooltip": "Текстовый промпт, используемый для генерации видео." }, "resolution": { "name": "разрешение", "tooltip": "Разрешение выходного видео." }, "seed": { "name": "сид", "tooltip": "Сид для использования при генерации." }, "watermark": { "name": "водяной_знак", "tooltip": 'Добавлять ли водяной знак "Сгенерировано ИИ" на видео.' } }, "outputs": { "0": { "tooltip": null } } };
const CFGGuider = { "display_name": "CFG Гид", "inputs": { "cfg": { "name": "cfg" }, "model": { "name": "модель" }, "negative": { "name": "отрицательный" }, "positive": { "name": "положительный" } } };
const CFGNorm = { "display_name": "CFGNorm", "inputs": { "model": { "name": "модель" }, "strength": { "name": "интенсивность" } }, "outputs": { "0": { "name": "исправленная_модель", "tooltip": null } } };
const CFGZeroStar = { "display_name": "CFGZeroStar", "inputs": { "model": { "name": "model" } }, "outputs": { "0": { "name": "patched_model", "tooltip": null } } };
const CLIPAttentionMultiply = { "display_name": "Умножение внимания CLIP", "inputs": { "clip": { "name": "clip" }, "k": { "name": "k" }, "out": { "name": "выход" }, "q": { "name": "q" }, "v": { "name": "v" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPLoader = { "description": "[Рецепты]\n\nstable_diffusion: clip-l\nstable_cascade: clip-g\nsd3: t5 / clip-g / clip-l\nstable_audio: t5\nmochi: t5\ncosmos: old t5 xxl", "display_name": "Загрузить CLIP", "inputs": { "clip_name": { "name": "название_clip" }, "device": { "name": "устройство" }, "type": { "name": "тип" } } };
const CLIPMergeAdd = { "display_name": "Сложение CLIP", "inputs": { "clip1": { "name": "clip1" }, "clip2": { "name": "clip2" } } };
const CLIPMergeSimple = { "display_name": "Простое слияние CLIP", "inputs": { "clip1": { "name": "clip1" }, "clip2": { "name": "clip2" }, "ratio": { "name": "соотношение" } } };
const CLIPMergeSubtract = { "display_name": "Вычитание CLIP", "inputs": { "clip1": { "name": "clip1" }, "clip2": { "name": "clip2" }, "multiplier": { "name": "множитель" } } };
const CLIPSave = { "display_name": "Сохранить CLIP", "inputs": { "clip": { "name": "clip" }, "filename_prefix": { "name": "префикс_названия_файла" } } };
const CLIPSetLastLayer = { "display_name": "Установить последний слой CLIP", "inputs": { "clip": { "name": "clip" }, "stop_at_clip_layer": { "name": "остановиться_на_clip_слое" } } };
const CLIPTextEncode = { "description": "Кодирует текстовый запрос с помощью модели CLIP в вектор, который можно использовать для управления моделью диффузии для генерации конкретных изображений.", "display_name": "Кодирование текста CLIP (Запрос)", "inputs": { "clip": { "name": "clip", "tooltip": "Модель CLIP, используемая для кодирования текста." }, "text": { "name": "текст", "tooltip": "Текст для кодирования." } }, "outputs": { "0": { "tooltip": "Условие, содержащее встроенный текст, используемое для управления моделью диффузии." } } };
const CLIPTextEncodeControlnet = { "display_name": "Кодирование текста CLIP для Controlnet", "inputs": { "clip": { "name": "clip" }, "conditioning": { "name": "кондиционирование" }, "text": { "name": "текст" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeFlux = { "display_name": "Кодирование текста CLIP Flux", "inputs": { "clip": { "name": "clip" }, "clip_l": { "name": "clip_l" }, "guidance": { "name": "руководство" }, "t5xxl": { "name": "t5xxl" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeHiDream = { "display_name": "CLIPTextEncodeHiDream", "inputs": { "clip": { "name": "clip" }, "clip_g": { "name": "clip_g" }, "clip_l": { "name": "clip_l" }, "llama": { "name": "llama" }, "t5xxl": { "name": "t5xxl" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeHunyuanDiT = { "display_name": "Кодирование текста CLIP HunyuanDiT", "inputs": { "bert": { "name": "bert" }, "clip": { "name": "clip" }, "mt5xl": { "name": "mt5xl" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeLumina2 = { "description": "Кодирует системный запрос и запрос пользователя с помощью модели CLIP во встраиваемый элемент, который можно использовать для направления модели диффузии на генерацию конкретных изображений.", "display_name": "CLIP Text Encode для Lumina2", "inputs": { "clip": { "name": "clip", "tooltip": "Модель CLIP, используемая для кодирования текста." }, "system_prompt": { "name": "system_prompt", "tooltip": "Lumina2 предоставляет два типа системных запросов: Высший: Вы - помощник, разработанный для генерации высококачественных изображений с наивысшей степенью соответствия текста и изображения на основе текстовых запросов или запросов пользователя. Соответствие: Вы - помощник, разработанный для генерации высококачественных изображений с наивысшей степенью соответствия текста и изображения на основе текстовых запросов." }, "user_prompt": { "name": "user_prompt", "tooltip": "Текст для кодирования." } }, "outputs": { "0": { "tooltip": "Условие, содержащее встроенный текст, используемый для направления модели диффузии." } } };
const CLIPTextEncodePixArtAlpha = { "description": "Кодирует текст и устанавливает условие разрешения для PixArt Alpha. Не применяется к PixArt Sigma.", "display_name": "CLIPTextEncodePixArtAlpha", "inputs": { "clip": { "name": "clip" }, "height": { "name": "высота" }, "text": { "name": "текст" }, "width": { "name": "ширина" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeSD3 = { "display_name": "Кодирование текста CLIP SD3", "inputs": { "clip": { "name": "clip" }, "clip_g": { "name": "clip_g" }, "clip_l": { "name": "clip_l" }, "empty_padding": { "name": "пустое_заполнение" }, "t5xxl": { "name": "t5xxl" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeSDXL = { "display_name": "Кодирование текста CLIP SDXL", "inputs": { "clip": { "name": "clip" }, "crop_h": { "name": "обрезка_высоты" }, "crop_w": { "name": "обрезка_ширины" }, "height": { "name": "высота" }, "target_height": { "name": "целевая_высота" }, "target_width": { "name": "целевая_ширина" }, "text_g": { "name": "текст_g" }, "text_l": { "name": "текст_l" }, "width": { "name": "ширина" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeSDXLRefiner = { "display_name": "Кодирование текста CLIP SDXL Refinement", "inputs": { "ascore": { "name": "ascore" }, "clip": { "name": "clip" }, "height": { "name": "высота" }, "text": { "name": "текст" }, "width": { "name": "ширина" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPVisionEncode = { "display_name": "Кодирование видения CLIP", "inputs": { "clip_vision": { "name": "clip_vision" }, "crop": { "name": "обрезка" }, "image": { "name": "изображение" } } };
const CLIPVisionLoader = { "display_name": "Загрузить видение CLIP", "inputs": { "clip_name": { "name": "название_clip" } } };
const Canny = { "display_name": "Canny", "inputs": { "high_threshold": { "name": "верхний_порог" }, "image": { "name": "изображение" }, "low_threshold": { "name": "нижний_порог" } }, "outputs": { "0": { "tooltip": null } } };
const CaseConverter = { "display_name": "Конвертер регистра", "inputs": { "mode": { "name": "режим" }, "string": { "name": "строка" } }, "outputs": { "0": { "tooltip": null } } };
const CheckpointLoader = { "display_name": "Загрузить сheckpoint с конфигурацией (УСТАРЕЛО)", "inputs": { "ckpt_name": { "name": "название_точки_проверки" }, "config_name": { "name": "название_конфигурации" } } };
const CheckpointLoaderSimple = { "description": "Загружает сheckpoint-модели диффузии, модели диффузии используются для удаления шума из латентов.", "display_name": "Загрузить сheckpoint", "inputs": { "ckpt_name": { "name": "название_точки_проверки", "tooltip": "Название сheckpoint (модели) для загрузки." } }, "outputs": { "0": { "tooltip": "Модель, используемая для шумоподавления латентов." }, "1": { "tooltip": "Модель CLIP, используемая для кодирования текстовых подсказок." }, "2": { "tooltip": "Модель VAE, используемая для кодирования и декодирования изображений из и в латентное пространство." } } };
const CheckpointSave = { "display_name": "Сохранить сheckpoint", "inputs": { "clip": { "name": "clip" }, "filename_prefix": { "name": "префикс_названия_файла" }, "model": { "name": "модель" }, "vae": { "name": "vae" } } };
const ChromaRadianceOptions = { "description": "Позволяет задать расширенные настройки для модели Chroma Radiance.", "display_name": "ChromaRadianceOptions", "inputs": { "end_sigma": { "name": "конечная_сигма", "tooltip": "Последняя сигма, для которой эти настройки вступят в силу." }, "model": { "name": "модель" }, "nerf_tile_size": { "name": "размер_плитки_nerf", "tooltip": "Позволяет переопределить размер плитки NeRF по умолчанию. -1 означает использование значения по умолчанию (32). 0 означает использование режима без разбиения на плитки (может потребовать много видеопамяти)." }, "preserve_wrapper": { "name": "сохранить_обёртку", "tooltip": "При включении делегирует существующей обёртке функции модели, если она существует. Обычно следует оставлять включённым." }, "start_sigma": { "name": "начальная_сигма", "tooltip": "Первая сигма, для которой эти настройки вступят в силу." } }, "outputs": { "0": { "tooltip": null } } };
const CombineHooks2 = { "display_name": "Объединить хуки [2]", "inputs": { "hooks_A": { "name": "hooks_A" }, "hooks_B": { "name": "hooks_B" } } };
const CombineHooks4 = { "display_name": "Объединить хуки [4]", "inputs": { "hooks_A": { "name": "hooks_A" }, "hooks_B": { "name": "hooks_B" }, "hooks_C": { "name": "hooks_C" }, "hooks_D": { "name": "hooks_D" } } };
const CombineHooks8 = { "display_name": "Объединить хуки [8]", "inputs": { "hooks_A": { "name": "hooks_A" }, "hooks_B": { "name": "hooks_B" }, "hooks_C": { "name": "hooks_C" }, "hooks_D": { "name": "hooks_D" }, "hooks_E": { "name": "hooks_E" }, "hooks_F": { "name": "hooks_F" }, "hooks_G": { "name": "hooks_G" }, "hooks_H": { "name": "hooks_H" } } };
const ConditioningAverage = { "display_name": "Среднее кондиционирование", "inputs": { "conditioning_from": { "name": "условие_от" }, "conditioning_to": { "name": "условие_к" }, "conditioning_to_strength": { "name": "сила_условия_к" } } };
const ConditioningCombine = { "display_name": "Кондиционирование (Объединение)", "inputs": { "conditioning_1": { "name": "условие_1" }, "conditioning_2": { "name": "условие_2" } } };
const ConditioningConcat = { "display_name": "Кондиционирование (Конкатенация)", "inputs": { "conditioning_from": { "name": "условие_от" }, "conditioning_to": { "name": "условие_к" } } };
const ConditioningSetArea = { "display_name": "Кондиционирование (Установить область)", "inputs": { "conditioning": { "name": "условие" }, "height": { "name": "высота" }, "strength": { "name": "сила" }, "width": { "name": "ширина" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const ConditioningSetAreaPercentage = { "display_name": "Кондиционирование (Установить область с процентом)", "inputs": { "conditioning": { "name": "условие" }, "height": { "name": "высота" }, "strength": { "name": "сила" }, "width": { "name": "ширина" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const ConditioningSetAreaPercentageVideo = { "display_name": "УсловныйНаборПроцентПлощадиВидео", "inputs": { "conditioning": { "name": "условие" }, "height": { "name": "высота" }, "strength": { "name": "сила" }, "temporal": { "name": "временной" }, "width": { "name": "ширина" }, "x": { "name": "x" }, "y": { "name": "y" }, "z": { "name": "z" } } };
const ConditioningSetAreaStrength = { "display_name": "Сила установки области кондиционирования", "inputs": { "conditioning": { "name": "условие" }, "strength": { "name": "сила" } } };
const ConditioningSetDefaultCombine = { "display_name": "Установить значение по умолчанию для объединения кондиционирования", "inputs": { "cond": { "name": "условие" }, "cond_DEFAULT": { "name": "условие_ПО_УМОЛЧАНИЮ" }, "hooks": { "name": "hooks" } } };
const ConditioningSetMask = { "display_name": "Кондиционирование (Установить маску)", "inputs": { "conditioning": { "name": "условие" }, "mask": { "name": "маска" }, "set_cond_area": { "name": "установить_область_условия" }, "strength": { "name": "сила" } } };
const ConditioningSetProperties = { "display_name": "Установить свойства кондиционирования", "inputs": { "cond_NEW": { "name": "новое_условие" }, "hooks": { "name": "хуки" }, "mask": { "name": "маска" }, "set_cond_area": { "name": "установить_область_условия" }, "strength": { "name": "сила" }, "timesteps": { "name": "временные_шаги" } } };
const ConditioningSetPropertiesAndCombine = { "display_name": "Установить свойства кондиционирования и объединить", "inputs": { "cond": { "name": "условие" }, "cond_NEW": { "name": "новое_условие" }, "hooks": { "name": "хуки" }, "mask": { "name": "маска" }, "set_cond_area": { "name": "установить_область_условия" }, "strength": { "name": "сила" }, "timesteps": { "name": "временные_шаги" } } };
const ConditioningSetTimestepRange = { "display_name": "Установить диапазон временных шагов кондиционирования", "inputs": { "conditioning": { "name": "условие" }, "end": { "name": "конец" }, "start": { "name": "начало" } } };
const ConditioningStableAudio = { "display_name": "ConditioningStableAudio", "inputs": { "negative": { "name": "отрицательный" }, "positive": { "name": "положительный" }, "seconds_start": { "name": "секунды_начала" }, "seconds_total": { "name": "всего_секунд" } }, "outputs": { "0": { "name": "положительный" }, "1": { "name": "отрицательный" } } };
const ConditioningTimestepsRange = { "display_name": "Диапазон временных шагов", "inputs": { "end_percent": { "name": "процент_конца" }, "start_percent": { "name": "процент_начала" } }, "outputs": { "1": { "name": "ДО_ДИАПАЗОНА" }, "2": { "name": "ПОСЛЕ_ДИАПАЗОНА" } } };
const ConditioningZeroOut = { "display_name": "Обнуление кондиционирования", "inputs": { "conditioning": { "name": "условие" } } };
const ContextWindowsManual = { "description": "Ручная установка контекстных окон.", "display_name": "Контекстные окна (Ручная настройка)", "inputs": { "closed_loop": { "name": "замкнутый_цикл", "tooltip": "Замыкать ли цикл контекстного окна; применимо только к циклическим расписаниям." }, "context_length": { "name": "длина_контекста", "tooltip": "Длина контекстного окна." }, "context_overlap": { "name": "перекрытие_контекста", "tooltip": "Перекрытие контекстных окон." }, "context_schedule": { "name": "расписание_контекста", "tooltip": "Шаг контекстного окна." }, "context_stride": { "name": "шаг_контекста", "tooltip": "Шаг контекстного окна; применимо только к равномерным расписаниям." }, "dim": { "name": "измерение", "tooltip": "Измерение, к которому применяются контекстные окна." }, "fuse_method": { "name": "метод_объединения", "tooltip": "Метод объединения контекстных окон." }, "model": { "name": "модель", "tooltip": "Модель, к которой применяются контекстные окна во время сэмплирования." } }, "outputs": { "0": { "tooltip": "Модель с применёнными контекстными окнами во время сэмплирования." } } };
const ControlNetApply = { "display_name": "Применить ControlNet (УСТАРЕЛО)", "inputs": { "conditioning": { "name": "условие" }, "control_net": { "name": "control_net" }, "image": { "name": "изображение" }, "strength": { "name": "сила" } } };
const ControlNetApplyAdvanced = { "display_name": "Применить ControlNet", "inputs": { "control_net": { "name": "control_net" }, "end_percent": { "name": "процент_конца" }, "image": { "name": "изображение" }, "negative": { "name": "отрицательный" }, "positive": { "name": "положительный" }, "start_percent": { "name": "процент_начала" }, "strength": { "name": "сила" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "положительный" }, "1": { "name": "отрицательный" } } };
const ControlNetApplySD3 = { "display_name": "Применить ControlNet с VAE", "inputs": { "control_net": { "name": "control_net" }, "end_percent": { "name": "процент_конца" }, "image": { "name": "изображение" }, "negative": { "name": "отрицательный" }, "positive": { "name": "положительный" }, "start_percent": { "name": "процент_начала" }, "strength": { "name": "сила" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "положительный", "tooltip": null }, "1": { "name": "отрицательный", "tooltip": null } } };
const ControlNetInpaintingAliMamaApply = { "display_name": "Применить ControlNet для инпейнтинга AliMama", "inputs": { "control_net": { "name": "control_net" }, "end_percent": { "name": "процент_конца" }, "image": { "name": "изображение" }, "mask": { "name": "маска" }, "negative": { "name": "отрицательный" }, "positive": { "name": "положительный" }, "start_percent": { "name": "процент_начала" }, "strength": { "name": "сила" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "положительный", "tooltip": null }, "1": { "name": "отрицательный", "tooltip": null } } };
const ControlNetLoader = { "display_name": "Загрузить модель ControlNet", "inputs": { "control_net_name": { "name": "название_control_net" } } };
const CosmosImageToVideoLatent = { "display_name": "CosmosImageToVideoLatent", "inputs": { "batch_size": { "name": "размер_пакета" }, "end_image": { "name": "конечное_изображение" }, "height": { "name": "высота" }, "length": { "name": "длина" }, "start_image": { "name": "начальное_изображение" }, "vae": { "name": "vae" }, "width": { "name": "ширина" } }, "outputs": { "0": { "tooltip": null } } };
const CosmosPredict2ImageToVideoLatent = { "display_name": "CosmosPredict2ImageToVideoLatent", "inputs": { "batch_size": { "name": "размер_пакета" }, "end_image": { "name": "конечное_изображение" }, "height": { "name": "высота" }, "length": { "name": "длина" }, "start_image": { "name": "начальное_изображение" }, "vae": { "name": "vae" }, "width": { "name": "ширина" } }, "outputs": { "0": { "tooltip": null } } };
const CreateHookKeyframe = { "display_name": "Создать ключевой кадр хука", "inputs": { "prev_hook_kf": { "name": "предыдущий_hook_kf" }, "start_percent": { "name": "процент_начала" }, "strength_mult": { "name": "множитель_силы" } }, "outputs": { "0": { "name": "КЛЮЧЕВОЙ_КАДР" } } };
const CreateHookKeyframesFromFloats = { "display_name": "Создать ключевые кадры хука из чисел с плавающей запятой", "inputs": { "end_percent": { "name": "процент_конца" }, "floats_strength": { "name": "сила_в_виде_чисел" }, "prev_hook_kf": { "name": "предыдущий_hook_kf" }, "print_keyframes": { "name": "печать_ключевых_кадров" }, "start_percent": { "name": "процент_начала" } }, "outputs": { "0": { "name": "КЛЮЧЕВОЙ_КАДР" } } };
const CreateHookKeyframesInterpolated = { "display_name": "Создать интерполированные ключевые кадры хука", "inputs": { "end_percent": { "name": "конечный_процент" }, "interpolation": { "name": "интерполяция" }, "keyframes_count": { "name": "количество_ключевых_кадров" }, "prev_hook_kf": { "name": "предыдущий_хук_kf" }, "print_keyframes": { "name": "печать_ключевых_кадров" }, "start_percent": { "name": "начальный_процент" }, "strength_end": { "name": "конечная_сила" }, "strength_start": { "name": "начальная_сила" } }, "outputs": { "0": { "name": "КЛЮЧЕВОЙ_КАДР" } } };
const CreateHookLora = { "display_name": "Создать хук LoRA", "inputs": { "lora_name": { "name": "название_lora" }, "prev_hooks": { "name": "предыдущие_хуки" }, "strength_clip": { "name": "сила_клипа" }, "strength_model": { "name": "сила_модели" } } };
const CreateHookLoraModelOnly = { "display_name": "Создать хук LoRA (Только модель)", "inputs": { "lora_name": { "name": "название_lora" }, "prev_hooks": { "name": "предыдущие_хуки" }, "strength_model": { "name": "сила_модели" } } };
const CreateHookModelAsLora = { "display_name": "Создать хук модели как LoRA", "inputs": { "ckpt_name": { "name": "название_ckpt" }, "prev_hooks": { "name": "предыдущие_хуки" }, "strength_clip": { "name": "сила_клипа" }, "strength_model": { "name": "сила_модели" } } };
const CreateHookModelAsLoraModelOnly = { "display_name": "Создать хук модели как LoRA (Только модель)", "inputs": { "ckpt_name": { "name": "название_ckpt" }, "prev_hooks": { "name": "предыдущие_хуки" }, "strength_model": { "name": "сила_модели" } } };
const CreateVideo = { "description": "Создайте видео из изображений.", "display_name": "Создать видео", "inputs": { "audio": { "name": "аудио", "tooltip": "Аудио, которое будет добавлено к видео." }, "fps": { "name": "кадров в секунду" }, "images": { "name": "изображения", "tooltip": "Изображения, из которых будет создано видео." } }, "outputs": { "0": { "tooltip": null } } };
const CropMask = { "display_name": "Обрезать маску", "inputs": { "height": { "name": "высота" }, "mask": { "name": "маска" }, "width": { "name": "ширина" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const DiffControlNetLoader = { "display_name": "Загрузить модель ControlNet (дифф)", "inputs": { "control_net_name": { "name": "название_control_net" }, "model": { "name": "модель" } } };
const DifferentialDiffusion = { "display_name": "Дифференциальная диффузия", "inputs": { "model": { "name": "модель" }, "strength": { "name": "интенсивность" } }, "outputs": { "0": { "tooltip": null } } };
const DiffusersLoader = { "display_name": "Загрузчик диффузоров", "inputs": { "model_path": { "name": "путь_модели" } } };
const DisableNoise = { "display_name": "Отключить шум" };
const DualCFGGuider = { "display_name": "Двойной CFG Гид", "inputs": { "cfg_cond2_negative": { "name": "cfg_cond2_negative" }, "cfg_conds": { "name": "cfg_conds" }, "cond1": { "name": "cond1" }, "cond2": { "name": "cond2" }, "model": { "name": "модель" }, "negative": { "name": "отрицательный" }, "style": { "name": "стиль" } } };
const DualCLIPLoader = { "description": "[Рецепты]\n\nsdxl: clip-l, clip-g\nsd3: clip-l, clip-g / clip-l, t5 / clip-g, t5\nflux: clip-l, t5", "display_name": "Двойной загрузчик CLIP", "inputs": { "clip_name1": { "name": "clip_name1" }, "clip_name2": { "name": "clip_name2" }, "device": { "name": "устройство" }, "type": { "name": "тип" } } };
const EasyCache = { "description": "Нативная реализация EasyCache.", "display_name": "EasyCache", "inputs": { "end_percent": { "name": "конечный_процент", "tooltip": "Относительный шаг выборки для завершения использования EasyCache." }, "model": { "name": "модель", "tooltip": "Модель, к которой добавляется EasyCache." }, "reuse_threshold": { "name": "порог_повторного_использования", "tooltip": "Порог для повторного использования кэшированных шагов." }, "start_percent": { "name": "начальный_процент", "tooltip": "Относительный шаг выборки для начала использования EasyCache." }, "verbose": { "name": "подробный", "tooltip": "Следует ли выводить подробную информацию." } }, "outputs": { "0": { "tooltip": "Модель с EasyCache." } } };
const EmptyAceStepLatentAudio = { "display_name": "EmptyAceStepLatentAudio", "inputs": { "batch_size": { "name": "размер_пакета", "tooltip": "Количество скрытых изображений в пакете." }, "seconds": { "name": "секунды" } }, "outputs": { "0": { "tooltip": null } } };
const EmptyAudio = { "display_name": "Пустой аудио", "inputs": { "channels": { "name": "каналы", "tooltip": "Количество аудиоканалов (1 для моно, 2 для стерео)." }, "duration": { "name": "длительность", "tooltip": "Длительность пустого аудиоклипа в секундах." }, "sample_rate": { "name": "частота_дискретизации", "tooltip": "Частота дискретизации пустого аудиоклипа." } } };
const EmptyChromaRadianceLatentImage = { "display_name": "EmptyChromaRadianceLatentImage", "inputs": { "batch_size": { "name": "размер_пакета" }, "height": { "name": "высота" }, "width": { "name": "ширина" } }, "outputs": { "0": { "tooltip": null } } };
const EmptyCosmosLatentVideo = { "display_name": "EmptyCosmosLatentVideo", "inputs": { "batch_size": { "name": "размер_пакета" }, "height": { "name": "высота" }, "length": { "name": "длина" }, "width": { "name": "ширина" } }, "outputs": { "0": { "tooltip": null } } };
const EmptyHunyuanImageLatent = { "display_name": "EmptyHunyuanImageLatent", "inputs": { "batch_size": { "name": "размер_пакета" }, "height": { "name": "высота" }, "width": { "name": "ширина" } }, "outputs": { "0": { "tooltip": null } } };
const EmptyHunyuanLatentVideo = { "display_name": "Пустой HunyuanLatentVideo", "inputs": { "batch_size": { "name": "размер_пакета" }, "height": { "name": "высота" }, "length": { "name": "длина" }, "width": { "name": "ширина" } }, "outputs": { "0": { "tooltip": null } } };
const EmptyImage = { "display_name": "Пустое изображение", "inputs": { "batch_size": { "name": "размер_пакета" }, "color": { "name": "цвет" }, "height": { "name": "высота" }, "width": { "name": "ширина" } } };
const EmptyLTXVLatentVideo = { "display_name": "Пустой LTXVLatentVideo", "inputs": { "batch_size": { "name": "размер_пакета" }, "height": { "name": "высота" }, "length": { "name": "длина" }, "width": { "name": "ширина" } }, "outputs": { "0": { "tooltip": null } } };
const EmptyLatentAudio = { "display_name": "Пустой LatentAudio", "inputs": { "batch_size": { "name": "размер_пакета", "tooltip": "Количество латентных изображений в партии." }, "seconds": { "name": "секунды" } } };
const EmptyLatentHunyuan3Dv2 = { "display_name": "EmptyLatentHunyuan3Dv2", "inputs": { "batch_size": { "name": "размер_пакета", "tooltip": "Количество скрытых изображений в пакете." }, "resolution": { "name": "разрешение" } } };
const EmptyLatentImage = { "description": "Создаёт новую партию пустых латентных изображений для удаления шума через выборку.", "display_name": "Пустое латентное изображение", "inputs": { "batch_size": { "name": "размер_пакета", "tooltip": "Количество латентных изображений в партии." }, "height": { "name": "высота", "tooltip": "Высота латентных изображений в пикселях." }, "width": { "name": "ширина", "tooltip": "Ширина латентных изображений в пикселях." } }, "outputs": { "0": { "tooltip": "Пустая партия латентных изображений." } } };
const EmptyMochiLatentVideo = { "display_name": "Пустой MochiLatentVideo", "inputs": { "batch_size": { "name": "размер_пакета" }, "height": { "name": "высота" }, "length": { "name": "длина" }, "width": { "name": "ширина" } }, "outputs": { "0": { "tooltip": null } } };
const EmptySD3LatentImage = { "display_name": "Пустой SD3LatentImage", "inputs": { "batch_size": { "name": "размер_пакета" }, "height": { "name": "высота" }, "width": { "name": "ширина" } }, "outputs": { "0": { "tooltip": null } } };
const ExponentialScheduler = { "display_name": "Экспоненциальный scheduler", "inputs": { "sigma_max": { "name": "sigma_max" }, "sigma_min": { "name": "sigma_min" }, "steps": { "name": "шаги" } } };
const ExtendIntermediateSigmas = { "display_name": "ExtendIntermediateSigmas", "inputs": { "end_at_sigma": { "name": "закончить_на_sigma" }, "sigmas": { "name": "sigmas" }, "spacing": { "name": "интервал" }, "start_at_sigma": { "name": "начать_с_sigma" }, "steps": { "name": "шаги" } } };
const FeatherMask = { "display_name": "Пернатая маска", "inputs": { "bottom": { "name": "снизу" }, "left": { "name": "слева" }, "mask": { "name": "маска" }, "right": { "name": "справа" }, "top": { "name": "сверху" } } };
const FlipSigmas = { "display_name": "Перевернуть сигмы", "inputs": { "sigmas": { "name": "sigmas" } } };
const FluxDisableGuidance = { "description": "Этот узел полностью отключает встраиваемое руководство на Flux и подобных моделях Flux", "display_name": "FluxDisableGuidance", "inputs": { "conditioning": { "name": "conditioning" } }, "outputs": { "0": { "tooltip": null } } };
const FluxGuidance = { "display_name": "Направление Flux", "inputs": { "conditioning": { "name": "условие" }, "guidance": { "name": "руководство" } }, "outputs": { "0": { "tooltip": null } } };
const FluxKontextImageScale = { "description": "Этот узел изменяет размер изображения до более оптимального для flux kontext.", "display_name": "FluxKontextImageScale", "inputs": { "image": { "name": "изображение" } }, "outputs": { "0": { "tooltip": null } } };
const FluxKontextMaxImageNode = { "description": "Редактирует изображения с помощью Flux.1 Kontext [max] через API на основе промпта и соотношения сторон.", "display_name": "Flux.1 Kontext [max] Изображение", "inputs": { "aspect_ratio": { "name": "соотношение_сторон", "tooltip": "Соотношение сторон изображения; должно быть между 1:4 и 4:1." }, "control_after_generate": { "name": "управление после генерации" }, "guidance": { "name": "направление", "tooltip": "Сила направленности для процесса генерации изображения" }, "input_image": { "name": "входное_изображение" }, "prompt": { "name": "промпт", "tooltip": "Промпт для генерации изображения - укажите что и как редактировать." }, "prompt_upsampling": { "name": "апсемплинг_промпта", "tooltip": "Выполнять ли апсемплинг промпта. Если активно, автоматически модифицирует промпт для более креативной генерации, но результаты недетерминированы (одинаковый сид не даст точно такого же результата)." }, "seed": { "name": "сид", "tooltip": "Случайное начальное значение, используемое для создания шума." }, "steps": { "name": "шаги", "tooltip": "Количество шагов для процесса генерации изображения" } }, "outputs": { "0": { "tooltip": null } } };
const FluxKontextMultiReferenceLatentMethod = { "display_name": "FluxKontextMultiReferenceLatentMethod", "inputs": { "conditioning": { "name": "кондиционирование" }, "reference_latents_method": { "name": "метод_референтных_латентов" } }, "outputs": { "0": { "tooltip": null } } };
const FluxKontextProImageNode = { "description": "Редактирует изображения с помощью Flux.1 Kontext [pro] через API на основе промпта и соотношения сторон.", "display_name": "Flux.1 Kontext [pro] Изображение", "inputs": { "aspect_ratio": { "name": "соотношение_сторон", "tooltip": "Соотношение сторон изображения; должно быть между 1:4 и 4:1." }, "control_after_generate": { "name": "управление после генерации" }, "guidance": { "name": "guidance", "tooltip": "Сила направляющего воздействия для процесса генерации изображения" }, "input_image": { "name": "input_image" }, "prompt": { "name": "промпт", "tooltip": "Промпт для генерации изображения - укажите что и как редактировать." }, "prompt_upsampling": { "name": "prompt_upsampling", "tooltip": "Выполнять ли апсемплинг промпта. Если активно, автоматически модифицирует промпт для более креативной генерации, но результаты недетерминированы (тот же сид не даст точно такого же результата)." }, "seed": { "name": "seed", "tooltip": "Случайное начальное значение, используемое для создания шума." }, "steps": { "name": "steps", "tooltip": "Количество шагов для процесса генерации изображения" } }, "outputs": { "0": { "tooltip": null } } };
const FluxProExpandNode = { "description": "Дорисовывает изображение на основе запроса.", "display_name": "Flux.1 Расширить изображение", "inputs": { "bottom": { "name": "низ", "tooltip": "Количество пикселей для расширения снизу изображения" }, "control_after_generate": { "name": "контроль после генерации" }, "guidance": { "name": "направление", "tooltip": "Сила направляющего сигнала для процесса генерации изображения" }, "image": { "name": "изображение" }, "left": { "name": "слева", "tooltip": "Количество пикселей для расширения слева изображения" }, "prompt": { "name": "запрос", "tooltip": "Запрос для генерации изображения" }, "prompt_upsampling": { "name": "апсемплинг запроса", "tooltip": "Выполнять ли апсемплинг запроса. Если включено, запрос автоматически модифицируется для более креативной генерации, но результаты будут недетерминированными (одинаковое зерно не даст точно такой же результат)." }, "right": { "name": "справа", "tooltip": "Количество пикселей для расширения справа изображения" }, "seed": { "name": "seed", "tooltip": "Случайное зерно, используемое для создания шума." }, "steps": { "name": "шаги", "tooltip": "Количество шагов для процесса генерации изображения" }, "top": { "name": "верх", "tooltip": "Количество пикселей для расширения сверху изображения" } }, "outputs": { "0": { "tooltip": null } } };
const FluxProFillNode = { "description": "Дорисовывает изображение на основе mask и prompt.", "display_name": "Flux.1 Заполнение изображения", "inputs": { "control_after_generate": { "name": "контроль после генерации" }, "guidance": { "name": "направление", "tooltip": "Сила направляющего сигнала для процесса генерации изображения" }, "image": { "name": "image" }, "mask": { "name": "mask" }, "prompt": { "name": "prompt", "tooltip": "Промпт для генерации изображения" }, "prompt_upsampling": { "name": "повышение разрешения промпта", "tooltip": "Выполнять ли повышение разрешения промпта. Если активно, автоматически изменяет промпт для более креативной генерации, но результаты будут недетерминированными (одинаковое значение seed не даст точно такой же результат)." }, "seed": { "name": "seed", "tooltip": "Случайное значение seed, используемое для создания шума." }, "steps": { "name": "шаги", "tooltip": "Количество шагов для процесса генерации изображения" } }, "outputs": { "0": { "tooltip": null } } };
const FluxProUltraImageNode = { "description": "Генерирует изображения с помощью Flux Pro 1.1 Ultra через API на основе запроса и разрешения.", "display_name": "Flux 1.1 [pro] Ultra Image", "inputs": { "aspect_ratio": { "name": "aspect_ratio", "tooltip": "Соотношение сторон изображения; должно быть между 1:4 и 4:1." }, "control_after_generate": { "name": "control after generate" }, "image_prompt": { "name": "image_prompt" }, "image_prompt_strength": { "name": "image_prompt_strength", "tooltip": "Смешивание между текстовым запросом и image prompt." }, "prompt": { "name": "prompt", "tooltip": "Запрос для генерации изображения" }, "prompt_upsampling": { "name": "prompt_upsampling", "tooltip": "Выполнять ли апсемплинг запроса. Если включено, автоматически изменяет запрос для более креативной генерации, но результаты будут недетерминированными (одинаковое зерно не даст точно такой же результат)." }, "raw": { "name": "raw", "tooltip": "Если True, генерирует менее обработанные, более естественные изображения." }, "seed": { "name": "seed", "tooltip": "Случайное зерно, используемое для создания шума." } }, "outputs": { "0": { "tooltip": null } } };
const FreSca = { "description": "Применяет масштабирование, зависящее от частоты, к управлению", "display_name": "FreSca", "inputs": { "freq_cutoff": { "name": "freq_cutoff", "tooltip": "Количество частотных индексов вокруг центра, считающихся низкочастотными" }, "model": { "name": "model" }, "scale_high": { "name": "scale_high", "tooltip": "Масштабный коэффициент для высокочастотных компонентов" }, "scale_low": { "name": "scale_low", "tooltip": "Масштабный коэффициент для низкочастотных компонентов" } }, "outputs": { "0": { "tooltip": null } } };
const FreeU = { "display_name": "FreeU", "inputs": { "b1": { "name": "b1" }, "b2": { "name": "b2" }, "model": { "name": "модель" }, "s1": { "name": "s1" }, "s2": { "name": "s2" } } };
const FreeU_V2 = { "display_name": "FreeU_V2", "inputs": { "b1": { "name": "b1" }, "b2": { "name": "b2" }, "model": { "name": "модель" }, "s1": { "name": "s1" }, "s2": { "name": "s2" } } };
const GITSScheduler = { "display_name": "GITSScheduler", "inputs": { "coeff": { "name": "коэфф" }, "denoise": { "name": "шумоподавление" }, "steps": { "name": "шаги" } }, "outputs": { "0": { "tooltip": null } } };
const GLIGENLoader = { "display_name": "Загрузчик GLIGEN", "inputs": { "gligen_name": { "name": "название_gligen" } } };
const GLIGENTextBoxApply = { "display_name": "Применить текстовое поле GLIGEN", "inputs": { "clip": { "name": "clip" }, "conditioning_to": { "name": "условие_для" }, "gligen_textbox_model": { "name": "модель_текстового_поля_gligen" }, "height": { "name": "высота" }, "text": { "name": "текст" }, "width": { "name": "ширина" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const GeminiImageNode = { "description": "Редактировать изображения синхронно через Google API.", "display_name": "Google Gemini Image", "inputs": { "aspect_ratio": { "name": "aspect_ratio", "tooltip": "По умолчанию соответствует размеру выходного изображения размеру входного изображения, в противном случае генерирует квадраты 1:1." }, "control_after_generate": { "name": "control after generate" }, "files": { "name": "files", "tooltip": "Опциональный файл(ы) для использования в качестве контекста для модели. Принимает входные данные из узла Gemini Generate Content Input Files." }, "images": { "name": "images", "tooltip": "Опциональное изображение(я) для использования в качестве контекста для модели. Чтобы включить несколько изображений, можно использовать узел Batch Images." }, "model": { "name": "model", "tooltip": "Модель Gemini для генерации ответов." }, "prompt": { "name": "prompt", "tooltip": "Текстовый промпт для генерации" }, "seed": { "name": "seed", "tooltip": "Когда сид зафиксирован на определённом значении, модель прилагает все усилия, чтобы предоставить одинаковый ответ при повторных запросах. Детерминированный вывод не гарантируется. Также изменение модели или параметров, таких как температура, может вызвать вариации в ответе даже при использовании того же значения сида. По умолчанию используется случайное значение сида." } }, "outputs": { "0": { "tooltip": null }, "1": { "tooltip": null } } };
const GeminiInputFiles = { "description": "Загружает и подготавливает входные файлы для включения в качестве входных данных для узлов Gemini LLM. Файлы будут прочитаны моделью Gemini при генерации ответа. Содержимое текстового файла учитывается в лимите токенов. 🛈 СОВЕТ: Можно объединять в цепочку с другими узлами Gemini Input File.", "display_name": "Gemini Input Files", "inputs": { "GEMINI_INPUT_FILES": { "name": "GEMINI_INPUT_FILES", "tooltip": "Опциональный дополнительный файл(ы) для объединения в пакет с файлом, загруженным из этого узла. Позволяет объединять входные файлы в цепочку, чтобы одно сообщение могло включать несколько входных файлов." }, "file": { "name": "file", "tooltip": "Входные файлы для включения в качестве контекста для модели. Пока принимаются только текстовые (.txt) и PDF (.pdf) файлы." } }, "outputs": { "0": { "tooltip": null } } };
const GeminiNode = { "description": "Генерируйте текстовые ответы с помощью модели ИИ Google Gemini. Вы можете предоставить несколько типов входных данных (текст, изображения, аудио, видео) в качестве контекста для генерации более релевантных и осмысленных ответов.", "display_name": "Google Gemini", "inputs": { "audio": { "name": "аудио", "tooltip": "Необязательное аудио для использования в качестве контекста для модели." }, "control_after_generate": { "name": "управление после генерации" }, "files": { "name": "файлы", "tooltip": "Необязательные файлы для использования в качестве контекста для модели. Принимает входные данные из узла Gemini Generate Content Input Files." }, "images": { "name": "изображения", "tooltip": "Необязательные изображения для использования в качестве контекста для модели. Чтобы включить несколько изображений, можно использовать узел Batch Images." }, "model": { "name": "модель", "tooltip": "Модель Gemini для генерации ответов." }, "prompt": { "name": "prompt", "tooltip": "Текстовые входные данные для модели, используемые для генерации ответа. Вы можете включить подробные инструкции, вопросы или контекст для модели." }, "seed": { "name": "сид", "tooltip": "Когда сид зафиксирован на определённом значении, модель прилагает все усилия, чтобы предоставить одинаковый ответ для повторных запросов. Детерминированный вывод не гарантируется. Также изменение модели или параметров, таких как температура, может вызвать вариации в ответе даже при использовании того же значения сида. По умолчанию используется случайное значение сида." }, "video": { "name": "видео", "tooltip": "Необязательное видео для использования в качестве контекста для модели." } }, "outputs": { "0": { "tooltip": null } } };
const GetImageSize = { "description": "Возвращает ширину и высоту изображения и передаёт его без изменений.", "display_name": "Получить размер изображения", "inputs": { "image": { "name": "изображение" } }, "outputs": { "0": { "name": "ширина" }, "1": { "name": "высота" }, "2": { "name": "размер_пакета" } } };
const GetVideoComponents = { "description": "Извлекает все компоненты из видео: кадры, аудио и частоту кадров.", "display_name": "Извлечь компоненты видео", "inputs": { "video": { "name": "видео", "tooltip": "Видео, из которого нужно извлечь компоненты." } }, "outputs": { "0": { "name": "изображения", "tooltip": null }, "1": { "name": "аудио", "tooltip": null }, "2": { "name": "fps", "tooltip": null } } };
const GrowMask = { "display_name": "Увеличить маску", "inputs": { "expand": { "name": "расширить" }, "mask": { "name": "маска" }, "tapered_corners": { "name": "заостренные_углы" } } };
const Hunyuan3Dv2Conditioning = { "display_name": "Hunyuan3Dv2Conditioning", "inputs": { "clip_vision_output": { "name": "выход_clip_vision" } }, "outputs": { "0": { "name": "положительный" }, "1": { "name": "отрицательный" } } };
const Hunyuan3Dv2ConditioningMultiView = { "display_name": "Hunyuan3Dv2ConditioningMultiView", "inputs": { "back": { "name": "сзади" }, "front": { "name": "фронт" }, "left": { "name": "слева" }, "right": { "name": "справа" } }, "outputs": { "0": { "name": "положительный" }, "1": { "name": "отрицательный" } } };
const HunyuanImageToVideo = { "display_name": "HunyuanImageToVideo", "inputs": { "batch_size": { "name": "размер пакета" }, "guidance_type": { "name": "тип руководства" }, "height": { "name": "высота" }, "length": { "name": "длина" }, "positive": { "name": "положительный" }, "start_image": { "name": "начальное изображение" }, "vae": { "name": "vae" }, "width": { "name": "ширина" } }, "outputs": { "0": { "name": "положительный", "tooltip": null }, "1": { "name": "скрытое пространство", "tooltip": null } } };
const HunyuanRefinerLatent = { "display_name": "HunyuanRefinerLatent", "inputs": { "latent": { "name": "латент" }, "negative": { "name": "негатив" }, "noise_augmentation": { "name": "шумовое_усиление" }, "positive": { "name": "позитив" } }, "outputs": { "0": { "name": "позитив", "tooltip": null }, "1": { "name": "негатив", "tooltip": null }, "2": { "name": "латент", "tooltip": null } } };
const HyperTile = { "display_name": "Гиперплитка", "inputs": { "max_depth": { "name": "максимальная_глубина" }, "model": { "name": "модель" }, "scale_depth": { "name": "масштаб_глубины" }, "swap_size": { "name": "размер_замены" }, "tile_size": { "name": "размер_плитки" } }, "outputs": { "0": { "tooltip": null } } };
const HypernetworkLoader = { "display_name": "Загрузчик hypernetwork", "inputs": { "hypernetwork_name": { "name": "название_hypernetwork" }, "model": { "name": "модель" }, "strength": { "name": "сила" } }, "outputs": { "0": { "tooltip": null } } };
const IdeogramV1 = { "description": "Генерирует изображения синхронно с использованием модели Ideogram V1.\n\nСсылки на изображения доступны ограниченное время; если вы хотите сохранить изображение, его необходимо скачать.", "display_name": "Ideogram V1", "inputs": { "aspect_ratio": { "name": "aspect_ratio", "tooltip": "Соотношение сторон для генерации изображения." }, "control_after_generate": { "name": "control after generate" }, "magic_prompt_option": { "name": "magic_prompt_option", "tooltip": "Определяет, использовать ли MagicPrompt при генерации" }, "negative_prompt": { "name": "negative_prompt", "tooltip": "Описание того, что нужно исключить из изображения" }, "num_images": { "name": "num_images" }, "prompt": { "name": "prompt", "tooltip": "Запрос для генерации изображения" }, "seed": { "name": "seed" }, "turbo": { "name": "turbo", "tooltip": "Использовать ли turbo-режим (более быстрая генерация, возможно, с пониженным качеством)" } }, "outputs": { "0": { "tooltip": null } } };
const IdeogramV2 = { "description": "Генерирует изображения синхронно с использованием модели Ideogram V2.\n\nСсылки на изображения доступны ограниченное время; если вы хотите сохранить изображение, его необходимо скачать.", "display_name": "Ideogram V2", "inputs": { "aspect_ratio": { "name": "aspect_ratio", "tooltip": "Соотношение сторон для генерации изображения. Игнорируется, если разрешение не установлено в AUTO." }, "control_after_generate": { "name": "control after generate" }, "magic_prompt_option": { "name": "magic_prompt_option", "tooltip": "Определяет, использовать ли MagicPrompt при генерации" }, "negative_prompt": { "name": "negative_prompt", "tooltip": "Описание того, что следует исключить из изображения" }, "num_images": { "name": "num_images" }, "prompt": { "name": "prompt", "tooltip": "Запрос для генерации изображения" }, "resolution": { "name": "resolution", "tooltip": "Разрешение для генерации изображения. Если не установлено в AUTO, этот параметр переопределяет настройку aspect_ratio." }, "seed": { "name": "seed" }, "style_type": { "name": "style_type", "tooltip": "Тип стиля для генерации (только для V2)" }, "turbo": { "name": "turbo", "tooltip": "Использовать ли turbo-режим (более быстрая генерация, возможно, с пониженным качеством)" } }, "outputs": { "0": { "tooltip": null } } };
const IdeogramV3 = { "description": "Генерирует изображения синхронно с использованием модели Ideogram V3.\n\nПоддерживает как обычную генерацию изображений по текстовым подсказкам, так и редактирование изображений с маской.\nСсылки на изображения доступны ограниченное время; если вы хотите сохранить изображение, его необходимо скачать.", "display_name": "Ideogram V3", "inputs": { "aspect_ratio": { "name": "aspect_ratio", "tooltip": "Соотношение сторон для генерации изображения. Игнорируется, если разрешение не установлено в Авто." }, "character_image": { "name": "изображение_персонажа", "tooltip": "Изображение для использования в качестве референса персонажа." }, "character_mask": { "name": "маска_персонажа", "tooltip": "Необязательная маска для референсного изображения персонажа." }, "control_after_generate": { "name": "control after generate" }, "image": { "name": "image", "tooltip": "Необязательное референсное изображение для редактирования." }, "magic_prompt_option": { "name": "magic_prompt_option", "tooltip": "Определяет, использовать ли MagicPrompt при генерации" }, "mask": { "name": "mask", "tooltip": "Необязательная маска для дорисовки (белые области будут заменены)" }, "num_images": { "name": "num_images" }, "prompt": { "name": "prompt", "tooltip": "Подсказка для генерации или редактирования изображения" }, "rendering_speed": { "name": "rendering_speed", "tooltip": "Управляет балансом между скоростью генерации и качеством" }, "resolution": { "name": "resolution", "tooltip": "Разрешение для генерации изображения. Если не установлено в Авто, этот параметр переопределяет aspect_ratio." }, "seed": { "name": "seed" } }, "outputs": { "0": { "tooltip": null } } };
const ImageAddNoise = { "display_name": "ImageAddNoise", "inputs": { "control_after_generate": { "name": "управление после генерации" }, "image": { "name": "изображение" }, "seed": { "name": "сид", "tooltip": "Случайный сид, используемый для создания шума." }, "strength": { "name": "сила" } } };
const ImageBatch = { "display_name": "Партия изображений", "inputs": { "image1": { "name": "изображение1" }, "image2": { "name": "изображение2" } } };
const ImageBlend = { "display_name": "Смешивание изображений", "inputs": { "blend_factor": { "name": "фактор_смешивания" }, "blend_mode": { "name": "режим_смешивания" }, "image1": { "name": "изображение1" }, "image2": { "name": "изображение2" } }, "outputs": { "0": { "tooltip": null } } };
const ImageBlur = { "display_name": "Размытие изображения", "inputs": { "blur_radius": { "name": "радиус_размытия" }, "image": { "name": "изображение" }, "sigma": { "name": "сигма" } }, "outputs": { "0": { "tooltip": null } } };
const ImageColorToMask = { "display_name": "Цвет изображения в маску", "inputs": { "color": { "name": "цвет" }, "image": { "name": "изображение" } } };
const ImageCompositeMasked = { "display_name": "Составное изображение с маской", "inputs": { "destination": { "name": "назначение" }, "mask": { "name": "маска" }, "resize_source": { "name": "изменить_размер_источника" }, "source": { "name": "источник" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const ImageCrop = { "display_name": "Обрезка изображения", "inputs": { "height": { "name": "высота" }, "image": { "name": "изображение" }, "width": { "name": "ширина" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const ImageFlip = { "display_name": "Переворот изображения", "inputs": { "flip_method": { "name": "метод переворота" }, "image": { "name": "изображение" } } };
const ImageFromBatch = { "display_name": "Изображение из партии", "inputs": { "batch_index": { "name": "индекс_пакета" }, "image": { "name": "изображение" }, "length": { "name": "длина" } } };
const ImageInvert = { "display_name": "Инвертировать изображение", "inputs": { "image": { "name": "изображение" } } };
const ImageOnlyCheckpointLoader = { "display_name": "Загрузчик checkpoint только для изображения (модель img2vid)", "inputs": { "ckpt_name": { "name": "название_ckpt" } } };
const ImageOnlyCheckpointSave = { "display_name": "Сохранить только checkpoint изображения", "inputs": { "clip_vision": { "name": "clip_vision" }, "filename_prefix": { "name": "префикс_названия_файла" }, "model": { "name": "модель" }, "vae": { "name": "vae" } } };
const ImagePadForOutpaint = { "display_name": "Добавить поля к изображению для выкрашивания", "inputs": { "bottom": { "name": "снизу" }, "feathering": { "name": "смягчение" }, "image": { "name": "изображение" }, "left": { "name": "слева" }, "right": { "name": "справа" }, "top": { "name": "сверху" } } };
const ImageQuantize = { "display_name": "Квантизация изображения", "inputs": { "colors": { "name": "цвета" }, "dither": { "name": "дизеринг" }, "image": { "name": "изображение" } }, "outputs": { "0": { "tooltip": null } } };
const ImageRGBToYUV = { "display_name": "ImageRGBToYUV", "inputs": { "image": { "name": "изображение" } }, "outputs": { "0": { "name": "Y", "tooltip": null }, "1": { "name": "U", "tooltip": null }, "2": { "name": "V", "tooltip": null } } };
const ImageRotate = { "display_name": "Поворот изображения", "inputs": { "image": { "name": "изображение" }, "rotation": { "name": "вращение" } } };
const ImageScale = { "display_name": "Масштабировать изображение", "inputs": { "crop": { "name": "обрезка" }, "height": { "name": "высота" }, "image": { "name": "изображение" }, "upscale_method": { "name": "метод_увеличения" }, "width": { "name": "ширина" } } };
const ImageScaleBy = { "display_name": "Масштабировать изображение на", "inputs": { "image": { "name": "изображение" }, "scale_by": { "name": "увеличить_на" }, "upscale_method": { "name": "метод_апскейла" } } };
const ImageScaleToMaxDimension = { "display_name": "Масштабирование до максимального размера", "inputs": { "image": { "name": "изображение" }, "largest_size": { "name": "максимальный размер" }, "upscale_method": { "name": "метод увеличения" } } };
const ImageScaleToTotalPixels = { "display_name": "Масштабировать изображение до общего количества пикселей", "inputs": { "image": { "name": "изображение" }, "megapixels": { "name": "мегапиксели" }, "upscale_method": { "name": "метод_апскейла" } }, "outputs": { "0": { "tooltip": null } } };
const ImageSharpen = { "display_name": "Резкость изображения", "inputs": { "alpha": { "name": "альфа" }, "image": { "name": "изображение" }, "sharpen_radius": { "name": "радиус_резкости" }, "sigma": { "name": "сигма" } }, "outputs": { "0": { "tooltip": null } } };
const ImageStitch = { "description": "\nСшивает image2 с image1 в указанном направлении.\nЕсли image2 не предоставлено, возвращает image1 без изменений.\nМежду изображениями можно добавить отступ.\n", "display_name": "Сшивание изображений", "inputs": { "direction": { "name": "направление" }, "image1": { "name": "изображение1" }, "image2": { "name": "изображение2" }, "match_image_size": { "name": "совпадение размера изображения" }, "spacing_color": { "name": "цвет отступа" }, "spacing_width": { "name": "ширина отступа" } } };
const ImageToMask = { "display_name": "Преобразовать изображение в маску", "inputs": { "channel": { "name": "канал" }, "image": { "name": "изображение" } } };
const ImageUpscaleWithModel = { "display_name": "Апскейл изображения (с использованием модели)", "inputs": { "image": { "name": "изображение" }, "upscale_model": { "name": "модель_апскейла" } }, "outputs": { "0": { "tooltip": null } } };
const ImageYUVToRGB = { "display_name": "ImageYUVToRGB", "inputs": { "U": { "name": "U" }, "V": { "name": "V" }, "Y": { "name": "Y" } }, "outputs": { "0": { "tooltip": null } } };
const InpaintModelConditioning = { "display_name": "Кондиционирование модели инпейнтинга", "inputs": { "mask": { "name": "маска" }, "negative": { "name": "отрицательный" }, "noise_mask": { "name": "шумовая_маска", "tooltip": "Добавьте маску шума к латентному изображению, чтобы выборка происходила только в пределах маски. Это может улучшить результаты или полностью испортить их в зависимости от модели." }, "pixels": { "name": "пиксели" }, "positive": { "name": "положительный" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "положительный" }, "1": { "name": "отрицательный" }, "2": { "name": "латентный" } } };
const InstructPixToPixConditioning = { "display_name": "Кондиционирование PixToPix", "inputs": { "negative": { "name": "отрицательный" }, "pixels": { "name": "пиксели" }, "positive": { "name": "положительный" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "положительный", "tooltip": null }, "1": { "name": "отрицательный", "tooltip": null }, "2": { "name": "латентный", "tooltip": null } } };
const InvertMask = { "display_name": "Инвертировать маску", "inputs": { "mask": { "name": "маска" } } };
const JoinImageWithAlpha = { "display_name": "Объединить изображение с альфа-каналом", "inputs": { "alpha": { "name": "альфа" }, "image": { "name": "изображение" } }, "outputs": { "0": { "tooltip": null } } };
const KSampler = { "description": "Использует предоставленную модель, положительное и отрицательное кондиционирование для удаления шума из латентного изображения.", "display_name": "KSampler", "inputs": { "cfg": { "name": "cfg", "tooltip": "Масштаб без классификатора балансирует креативность и соблюдение запроса. Более высокие значения приводят к изображениям, более точно соответствующим запросу, однако слишком высокие значения негативно скажутся на качестве." }, "control_after_generate": { "name": "control after generate" }, "denoise": { "name": "шумоподавление", "tooltip": "Количество уменьшения шума, более низкие значения сохранят структуру начального изображения, позволяя выборку изображений." }, "latent_image": { "name": "латентное_изображение", "tooltip": "Латентное изображение для уменьшения шума." }, "model": { "name": "модель", "tooltip": "Модель, используемая для уменьшения шума входного латентного изображения." }, "negative": { "name": "отрицательный", "tooltip": "Условие, описывающее атрибуты, которые вы хотите исключить из изображения." }, "positive": { "name": "положительный", "tooltip": "Условие, описывающее атрибуты, которые вы хотите включить в изображение." }, "sampler_name": { "name": "название_сэмплера", "tooltip": "Алгоритм, используемый при выборке, это может повлиять на качество, скорость и стиль сгенерированного вывода." }, "scheduler": { "name": "scheduler", "tooltip": "Scheduler контролирует, как шум постепенно удаляется для формирования изображения." }, "seed": { "name": "сид", "tooltip": "Случайный сид, используемый для создания шума." }, "steps": { "name": "шаги", "tooltip": "Количество шагов, используемых в процессе уменьшения шума." } }, "outputs": { "0": { "tooltip": "шумоподавленный латент." } } };
const KSamplerAdvanced = { "display_name": "KSampler (Расширенный)", "inputs": { "add_noise": { "name": "добавить_шум" }, "cfg": { "name": "cfg" }, "control_after_generate": { "name": "control after generate" }, "end_at_step": { "name": "закончить_на_шаге" }, "latent_image": { "name": "латентное_изображение" }, "model": { "name": "модель" }, "negative": { "name": "отрицательный" }, "noise_seed": { "name": "сид_шума" }, "positive": { "name": "положительный" }, "return_with_leftover_noise": { "name": "вернуться_с_оставшимся_шумом" }, "sampler_name": { "name": "название_сэмплера" }, "scheduler": { "name": "scheduler" }, "start_at_step": { "name": "начать_с_шага" }, "steps": { "name": "шаги" } } };
const KSamplerSelect = { "display_name": "Выбор KSampler", "inputs": { "sampler_name": { "name": "название_сэмплера" } } };
const KarrasScheduler = { "display_name": "Scheduler Карраса", "inputs": { "rho": { "name": "ро" }, "sigma_max": { "name": "максимальное_сигма" }, "sigma_min": { "name": "минимальное_сигма" }, "steps": { "name": "шаги" } } };
const KlingCameraControlI2VNode = { "description": "Преобразуйте статичные изображения в кинематографичные видео с профессиональными движениями камеры, имитирующими реальную кинематографию. Управляйте виртуальными действиями камеры, включая зум, вращение, панорамирование, наклон и вид от первого лица, сохраняя фокус на исходном изображении.", "display_name": "Kling Image to Video (Управление камерой)", "inputs": { "aspect_ratio": { "name": "aspect_ratio" }, "camera_control": { "name": "camera_control", "tooltip": "Может быть создан с помощью узла Kling Camera Controls. Управляет движением и перемещением камеры во время генерации видео." }, "cfg_scale": { "name": "cfg_scale" }, "negative_prompt": { "name": "negative_prompt", "tooltip": "Негативный текстовый промпт" }, "prompt": { "name": "prompt", "tooltip": "Положительный текстовый промпт" }, "start_frame": { "name": "start_frame", "tooltip": "Референсное изображение — URL или строка в формате Base64, размер не более 10 МБ, разрешение не менее 300*300 пикселей, соотношение сторон от 1:2.5 до 2.5:1. В Base64 не должно быть префикса data:image." } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "video_id", "tooltip": null }, "2": { "name": "duration", "tooltip": null } } };
const KlingCameraControlT2VNode = { "description": "Преобразуйте текст в кинематографические видео с профессиональными движениями камеры, имитирующими реальную кинематографию. Управляйте виртуальными действиями камеры, включая зум, вращение, панорамирование, наклон и вид от первого лица, сохраняя при этом фокус на исходном тексте.", "display_name": "Kling Текст в Видео (Управление Камерой)", "inputs": { "aspect_ratio": { "name": "aspect_ratio" }, "camera_control": { "name": "camera_control", "tooltip": "Может быть создан с помощью узла Kling Camera Controls. Управляет движением и перемещением камеры во время генерации видео." }, "cfg_scale": { "name": "cfg_scale" }, "negative_prompt": { "name": "negative_prompt", "tooltip": "Отрицательный текстовый запрос" }, "prompt": { "name": "prompt", "tooltip": "Положительный текстовый запрос" } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "video_id", "tooltip": null }, "2": { "name": "duration", "tooltip": null } } };
const KlingCameraControls = { "description": "Позволяет указывать параметры конфигурации для управления камерой Kling и эффектами управления движением.", "display_name": "Управление камерой Kling", "inputs": { "camera_control_type": { "name": "camera_control_type" }, "horizontal_movement": { "name": "horizontal_movement", "tooltip": "Управляет движением камеры по горизонтальной оси (ось x). Отрицательное значение — влево, положительное — вправо." }, "pan": { "name": "pan", "tooltip": "Управляет вращением камеры в вертикальной плоскости (ось x). Отрицательное значение — вращение вниз, положительное — вращение вверх." }, "roll": { "name": "roll", "tooltip": "Управляет степенью наклона камеры (ось z). Отрицательное значение — против часовой стрелки, положительное — по часовой стрелке." }, "tilt": { "name": "tilt", "tooltip": "Управляет вращением камеры в горизонтальной плоскости (ось y). Отрицательное значение — вращение влево, положительное — вращение вправо." }, "vertical_movement": { "name": "vertical_movement", "tooltip": "Управляет движением камеры по вертикальной оси (ось y). Отрицательное значение — вниз, положительное — вверх." }, "zoom": { "name": "zoom", "tooltip": "Управляет изменением фокусного расстояния камеры. Отрицательное значение — более узкий угол обзора, положительное — более широкий угол обзора." } }, "outputs": { "0": { "name": "camera_control", "tooltip": null } } };
const KlingDualCharacterVideoEffectNode = { "description": "Достигайте различных спецэффектов при генерации видео на основе effect_scene. Первое изображение будет размещено слева, второе — справа в композиции.", "display_name": "Kling: Видеоэффекты с двумя персонажами", "inputs": { "duration": { "name": "duration" }, "effect_scene": { "name": "effect_scene" }, "image_left": { "name": "image_left", "tooltip": "Изображение слева" }, "image_right": { "name": "image_right", "tooltip": "Изображение справа" }, "mode": { "name": "mode" }, "model_name": { "name": "model_name" } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "duration", "tooltip": null } } };
const KlingImage2VideoNode = { "display_name": "Kling Image to Video", "inputs": { "aspect_ratio": { "name": "aspect_ratio" }, "cfg_scale": { "name": "cfg_scale" }, "duration": { "name": "duration" }, "mode": { "name": "mode" }, "model_name": { "name": "model_name" }, "negative_prompt": { "name": "negative_prompt", "tooltip": "Негативный текстовый запрос" }, "prompt": { "name": "prompt", "tooltip": "Положительный текстовый запрос" }, "start_frame": { "name": "start_frame", "tooltip": "Референсное изображение — URL или строка в формате Base64, не более 10 МБ, разрешение не менее 300×300 пикселей, соотношение сторон от 1:2.5 до 2.5:1. В Base64 не должно быть префикса data:image." } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "video_id", "tooltip": null }, "2": { "name": "duration", "tooltip": null } } };
const KlingImageGenerationNode = { "description": "Узел генерации изображений Kling. Генерирует изображение по текстовому запросу с необязательным референсным изображением.", "display_name": "Генерация изображений Kling", "inputs": { "aspect_ratio": { "name": "aspect_ratio" }, "human_fidelity": { "name": "human_fidelity", "tooltip": "Сходство с референсом субъекта" }, "image": { "name": "image" }, "image_fidelity": { "name": "image_fidelity", "tooltip": "Интенсивность референса для загруженных пользователем изображений" }, "image_type": { "name": "image_type" }, "model_name": { "name": "model_name" }, "n": { "name": "n", "tooltip": "Количество сгенерированных изображений" }, "negative_prompt": { "name": "negative_prompt", "tooltip": "Отрицательный текстовый запрос" }, "prompt": { "name": "prompt", "tooltip": "Положительный текстовый запрос" } }, "outputs": { "0": { "tooltip": null } } };
const KlingLipSyncAudioToVideoNode = { "description": "Узел Kling Lip Sync Audio to Video. Синхронизирует движения рта на видео с аудиосодержимым аудиофайла.", "display_name": "Kling синхронизация губ в видео с аудио", "inputs": { "audio": { "name": "аудио" }, "video": { "name": "видео" }, "voice_language": { "name": "язык голоса" } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "video_id", "tooltip": null }, "2": { "name": "длительность", "tooltip": null } } };
const KlingLipSyncTextToVideoNode = { "description": "Узел Kling Lip Sync Text to Video. Синхронизирует движения рта в видеофайле с текстовой подсказкой.", "display_name": "Kling Синхронизация губ в видео с текстом", "inputs": { "text": { "name": "текст", "tooltip": "Текст для генерации видео с синхронизацией губ. Обязательно при режиме text2video. Максимальная длина — 120 символов." }, "video": { "name": "видео" }, "voice": { "name": "голос" }, "voice_speed": { "name": "скорость_голоса", "tooltip": "Скорость речи. Допустимый диапазон: 0.8~2.0, с точностью до одной десятой." } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "video_id", "tooltip": null }, "2": { "name": "длительность", "tooltip": null } } };
const KlingSingleImageVideoEffectNode = { "description": "Достигайте различных спецэффектов при генерации видео на основе effect_scene.", "display_name": "Kling Видеоэффекты", "inputs": { "duration": { "name": "duration" }, "effect_scene": { "name": "effect_scene" }, "image": { "name": "image", "tooltip": "Референсное изображение. URL или строка в формате Base64 (без префикса data:image). Размер файла не должен превышать 10 МБ, разрешение не менее 300*300 пикселей, соотношение сторон от 1:2.5 до 2.5:1" }, "model_name": { "name": "model_name" } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "video_id", "tooltip": null }, "2": { "name": "duration", "tooltip": null } } };
const KlingStartEndFrameNode = { "description": "Создайте видеопоследовательность, плавно переходящую между заданными начальными и конечными изображениями. Узел генерирует все промежуточные кадры, обеспечивая плавную трансформацию от первого кадра к последнему.", "display_name": "Kling: Кадры начала и конца в видео", "inputs": { "aspect_ratio": { "name": "aspect_ratio" }, "cfg_scale": { "name": "cfg_scale" }, "end_frame": { "name": "end_frame", "tooltip": "Референсное изображение — контроль конечного кадра. URL или строка в формате Base64, не более 10 МБ, разрешение не менее 300×300 пикселей. В Base64 не должно быть префикса data:image." }, "mode": { "name": "mode", "tooltip": "Конфигурация для генерации видео в формате: режим / длительность / model_name." }, "negative_prompt": { "name": "negative_prompt", "tooltip": "Негативный текстовый промпт" }, "prompt": { "name": "prompt", "tooltip": "Положительный текстовый промпт" }, "start_frame": { "name": "start_frame", "tooltip": "Референсное изображение — URL или строка в формате Base64, не более 10 МБ, разрешение не менее 300×300 пикселей, соотношение сторон от 1:2.5 до 2.5:1. В Base64 не должно быть префикса data:image." } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "video_id", "tooltip": null }, "2": { "name": "duration", "tooltip": null } } };
const KlingTextToVideoNode = { "description": "Узел Kling: текст в видео", "display_name": "Kling: текст в видео", "inputs": { "aspect_ratio": { "name": "aspect_ratio" }, "cfg_scale": { "name": "cfg_scale" }, "mode": { "name": "mode", "tooltip": "Конфигурация для генерации видео в формате: режим / длительность / имя_модели." }, "negative_prompt": { "name": "negative_prompt", "tooltip": "Отрицательный текстовый запрос" }, "prompt": { "name": "prompt", "tooltip": "Положительный текстовый запрос" } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "video_id", "tooltip": null }, "2": { "name": "duration", "tooltip": null } } };
const KlingVideoExtendNode = { "description": "Узел Kling Video Extend. Расширяет видео, созданные другими узлами Kling. video_id создаётся с помощью других узлов Kling.", "display_name": "Kling Video Extend", "inputs": { "cfg_scale": { "name": "cfg_scale" }, "negative_prompt": { "name": "negative_prompt", "tooltip": "Отрицательный текстовый запрос для указания элементов, которых следует избегать в расширенном видео" }, "prompt": { "name": "prompt", "tooltip": "Положительный текстовый запрос для управления расширением видео" }, "video_id": { "name": "video_id", "tooltip": "ID видео, которое нужно расширить. Поддерживаются видео, созданные с помощью text-to-video, image-to-video и предыдущих операций расширения видео. Общая продолжительность после расширения не может превышать 3 минуты." } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "video_id", "tooltip": null }, "2": { "name": "duration", "tooltip": null } } };
const KlingVirtualTryOnNode = { "description": "Узел Kling Виртуальная Примерка. Введите изображение человека и изображение одежды, чтобы примерить одежду на человеке.", "display_name": "Kling Виртуальная Примерка", "inputs": { "cloth_image": { "name": "cloth_image" }, "human_image": { "name": "human_image" }, "model_name": { "name": "model_name" } }, "outputs": { "0": { "tooltip": null } } };
const LTXVAddGuide = { "display_name": "LTXVAddGuide", "inputs": { "frame_idx": { "name": "индекс кадра", "tooltip": "Индекс кадра для начала условия. Для однокадровых изображений или видео с 1-8 кадрами любое значение frame_idx приемлемо. Для видео с 9+ кадрами, frame_idx должен быть кратен 8, в противном случае он будет округлен вниз до ближайшего кратного 8. Отрицательные значения считаются с конца видео." }, "image": { "name": "изображение", "tooltip": "Изображение или видео для условия скрытого видео. Должно быть 8*n + 1 кадров. Если видео не 8*n + 1 кадров, оно будет обрезано до ближайших 8*n + 1 кадров." }, "latent": { "name": "скрытое пространство" }, "negative": { "name": "отрицательный" }, "positive": { "name": "положительный" }, "strength": { "name": "сила" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "положительный", "tooltip": null }, "1": { "name": "отрицательный", "tooltip": null }, "2": { "name": "скрытое пространство", "tooltip": null } } };
const LTXVConditioning = { "display_name": "Кондиционирование LTXV", "inputs": { "frame_rate": { "name": "частота_кадров" }, "negative": { "name": "отрицательный" }, "positive": { "name": "положительный" } }, "outputs": { "0": { "name": "положительный", "tooltip": null }, "1": { "name": "отрицательный", "tooltip": null } } };
const LTXVCropGuides = { "display_name": "LTXVCropGuides", "inputs": { "latent": { "name": "скрытое пространство" }, "negative": { "name": "отрицательный" }, "positive": { "name": "положительный" } }, "outputs": { "0": { "name": "положительный", "tooltip": null }, "1": { "name": "отрицательный", "tooltip": null }, "2": { "name": "скрытое пространство", "tooltip": null } } };
const LTXVImgToVideo = { "display_name": "LTXVImgToVideo", "inputs": { "batch_size": { "name": "размер_пакета" }, "height": { "name": "высота" }, "image": { "name": "изображение" }, "length": { "name": "длина" }, "negative": { "name": "отрицательный" }, "positive": { "name": "положительный" }, "strength": { "name": "интенсивность" }, "vae": { "name": "vae" }, "width": { "name": "ширина" } }, "outputs": { "0": { "name": "положительный", "tooltip": null }, "1": { "name": "отрицательный", "tooltip": null }, "2": { "name": "латентный", "tooltip": null } } };
const LTXVPreprocess = { "display_name": "LTXVPreprocess", "inputs": { "image": { "name": "изображение" }, "img_compression": { "name": "сжатие изображения", "tooltip": "Степень сжатия, применяемая к изображению." } }, "outputs": { "0": { "name": "выходное изображение", "tooltip": null } } };
const LTXVScheduler = { "display_name": "Scheduler LTXV", "inputs": { "base_shift": { "name": "базовое_смещение" }, "latent": { "name": "скрытый" }, "max_shift": { "name": "максимальное_смещение" }, "steps": { "name": "шаги" }, "stretch": { "name": "растяжение", "tooltip": "Растянуть сигмы, чтобы они находились в диапазоне [terminal, 1]." }, "terminal": { "name": "терминал", "tooltip": "Конечное значение сигм после растяжения." } }, "outputs": { "0": { "tooltip": null } } };
const LaplaceScheduler = { "display_name": "Scheduler Лапласа", "inputs": { "beta": { "name": "бета" }, "mu": { "name": "мю" }, "sigma_max": { "name": "максимальное_сигма" }, "sigma_min": { "name": "минимальное_сигма" }, "steps": { "name": "шаги" } } };
const LatentAdd = { "display_name": "Добавить латент", "inputs": { "samples1": { "name": "образцы1" }, "samples2": { "name": "образцы2" } }, "outputs": { "0": { "tooltip": null } } };
const LatentApplyOperation = { "display_name": "Применить операцию к латенту", "inputs": { "operation": { "name": "операция" }, "samples": { "name": "образцы" } }, "outputs": { "0": { "tooltip": null } } };
const LatentApplyOperationCFG = { "display_name": "Применить операцию к латенту CFG", "inputs": { "model": { "name": "модель" }, "operation": { "name": "операция" } }, "outputs": { "0": { "tooltip": null } } };
const LatentBatch = { "display_name": "Партия латентов", "inputs": { "samples1": { "name": "образцы1" }, "samples2": { "name": "образцы2" } }, "outputs": { "0": { "tooltip": null } } };
const LatentBatchSeedBehavior = { "display_name": "Поведение сида партии латентов", "inputs": { "samples": { "name": "образцы" }, "seed_behavior": { "name": "поведение_сида" } }, "outputs": { "0": { "tooltip": null } } };
const LatentBlend = { "display_name": "Смешивание латентов", "inputs": { "blend_factor": { "name": "фактор_смешивания" }, "samples1": { "name": "образцы1" }, "samples2": { "name": "образцы2" } } };
const LatentComposite = { "display_name": "Составной латент", "inputs": { "feather": { "name": "перо" }, "samples_from": { "name": "образцы_из" }, "samples_to": { "name": "образцы_для" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const LatentCompositeMasked = { "display_name": "Составной латент с маской", "inputs": { "destination": { "name": "назначение" }, "mask": { "name": "маска" }, "resize_source": { "name": "изменить_размер_источника" }, "source": { "name": "источник" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const LatentConcat = { "display_name": "Объединение латентов", "inputs": { "dim": { "name": "измерение" }, "samples1": { "name": "сэмплы1" }, "samples2": { "name": "сэмплы2" } }, "outputs": { "0": { "tooltip": null } } };
const LatentCrop = { "display_name": "Обрезка латента", "inputs": { "height": { "name": "высота" }, "samples": { "name": "образцы" }, "width": { "name": "ширина" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const LatentCut = { "display_name": "Разрез латента", "inputs": { "amount": { "name": "количество" }, "dim": { "name": "измерение" }, "index": { "name": "индекс" }, "samples": { "name": "сэмплы" } }, "outputs": { "0": { "tooltip": null } } };
const LatentFlip = { "display_name": "Перевернуть латент", "inputs": { "flip_method": { "name": "метод_отражения" }, "samples": { "name": "образцы" } } };
const LatentFromBatch = { "display_name": "Латент из партии", "inputs": { "batch_index": { "name": "индекс_пакета" }, "length": { "name": "длина" }, "samples": { "name": "образцы" } } };
const LatentInterpolate = { "display_name": "Интерполяция латента", "inputs": { "ratio": { "name": "соотношение" }, "samples1": { "name": "образцы1" }, "samples2": { "name": "образцы2" } }, "outputs": { "0": { "tooltip": null } } };
const LatentMultiply = { "display_name": "Умножить латент", "inputs": { "multiplier": { "name": "множитель" }, "samples": { "name": "образцы" } }, "outputs": { "0": { "tooltip": null } } };
const LatentOperationSharpen = { "display_name": "Операция латента: резкость", "inputs": { "alpha": { "name": "альфа" }, "sharpen_radius": { "name": "радиус_резкости" }, "sigma": { "name": "сигма" } }, "outputs": { "0": { "tooltip": null } } };
const LatentOperationTonemapReinhard = { "display_name": "Операция латента: тональная карта Рейнхарда", "inputs": { "multiplier": { "name": "множитель" } }, "outputs": { "0": { "tooltip": null } } };
const LatentRotate = { "display_name": "Повернуть латент", "inputs": { "rotation": { "name": "вращение" }, "samples": { "name": "образцы" } } };
const LatentSubtract = { "display_name": "Вычесть латент", "inputs": { "samples1": { "name": "образцы1" }, "samples2": { "name": "образцы2" } }, "outputs": { "0": { "tooltip": null } } };
const LatentUpscale = { "display_name": "Увеличить латент", "inputs": { "crop": { "name": "обрезка" }, "height": { "name": "высота" }, "samples": { "name": "образцы" }, "upscale_method": { "name": "метод_апскейла" }, "width": { "name": "ширина" } } };
const LatentUpscaleBy = { "display_name": "Увеличить латент на", "inputs": { "samples": { "name": "образцы" }, "scale_by": { "name": "масштабировать_по" }, "upscale_method": { "name": "метод_апскейла" } } };
const LazyCache = { "description": "Самодельная версия EasyCache - ещё более 'простая' версия EasyCache для реализации. В целом работает хуже, чем EasyCache, но лучше в некоторых редких случаях И имеет универсальную совместимость со всем в ComfyUI.", "display_name": "Ленивый кэш", "inputs": { "end_percent": { "name": "end_percent", "tooltip": "Относительный шаг сэмплирования для завершения использования LazyCache." }, "model": { "name": "модель", "tooltip": "Модель, к которой добавляется Ленивый кэш." }, "reuse_threshold": { "name": "порог повторного использования", "tooltip": "Порог для повторного использования кэшированных шагов." }, "start_percent": { "name": "start_percent", "tooltip": "Относительный шаг сэмплирования для начала использования LazyCache." }, "verbose": { "name": "verbose", "tooltip": "Включить ли вывод подробной информации." } }, "outputs": { "0": { "tooltip": "Модель с LazyCache." } } };
const Load3D = { "display_name": "Загрузить 3D", "inputs": { "clear": {}, "height": { "name": "высота" }, "image": { "name": "изображение" }, "model_file": { "name": "файл модели" }, "upload 3d model": {}, "width": { "name": "ширина" } }, "outputs": { "0": { "name": "изображение" }, "1": { "name": "mask" }, "2": { "name": "путь к mesh" }, "3": { "name": "нормаль" }, "4": { "name": "линейный рисунок" }, "5": { "name": "информация о камере" } } };
const LoadAudio = { "display_name": "Загрузить аудио", "inputs": { "audio": { "name": "аудио" }, "audioUI": { "name": "audioUI" }, "upload": { "name": "выберите файл для загрузки" } } };
const LoadImage = { "display_name": "Загрузить изображение", "inputs": { "image": { "name": "изображение" }, "upload": { "name": "выберите файл для загрузки" } } };
const LoadImageMask = { "display_name": "Загрузить изображение (как маску)", "inputs": { "channel": { "name": "канал" }, "image": { "name": "изображение" }, "upload": { "name": "выберите файл для загрузки" } } };
const LoadImageOutput = { "description": "Загрузите изображение из папки вывода. При нажатии кнопки обновления, узел обновит список изображений и автоматически выберет первое изображение, что позволяет легко итерировать.", "display_name": "Загрузить изображение (из выходных данных)", "inputs": { "image": { "name": "изображение" }, "refresh": {}, "upload": { "name": "выберите файл для загрузки" } } };
const LoadLatent = { "display_name": "Загрузить латент", "inputs": { "latent": { "name": "скрытый" } } };
const LoadVideo = { "display_name": "Загрузить видео", "inputs": { "file": { "name": "файл" }, "upload": { "name": "выберите файл для загрузки" } }, "outputs": { "0": { "tooltip": null } } };
const LoraLoader = { "description": "LoRA используются для изменения моделей диффузии и CLIP, изменяя способ, которым латенты удаляются от шума, например, применяя стили. Несколько нод LoRA могут быть связаны вместе.", "display_name": "Загрузить LoRA", "inputs": { "clip": { "name": "клип", "tooltip": "Модель CLIP, к которой будет применена LoRA." }, "lora_name": { "name": "название_lora", "tooltip": "Название LoRA." }, "model": { "name": "модель", "tooltip": "Диффузионная модель, к которой будет применена LoRA." }, "strength_clip": { "name": "сила_клипа", "tooltip": "Насколько сильно модифицировать модель CLIP. Это значение может быть отрицательным." }, "strength_model": { "name": "сила_модели", "tooltip": "Насколько сильно модифицировать диффузионную модель. Это значение может быть отрицательным." } }, "outputs": { "0": { "tooltip": "Модифицированная модель диффузии." }, "1": { "tooltip": "Модифицированная модель CLIP." } } };
const LoraLoaderModelOnly = { "description": "LoRA используются для изменения моделей диффузии и CLIP, изменяя способ, которым латенты удаляются от шума, например, применяя стили. Несколько нод LoRA могут быть связаны вместе.", "display_name": "Загрузчик LoRA (Только модель)", "inputs": { "lora_name": { "name": "название_lora" }, "model": { "name": "модель" }, "strength_model": { "name": "сила_модели" } }, "outputs": { "0": { "tooltip": "Модифицированная модель диффузии." } } };
const LoraModelLoader = { "display_name": "Загрузить модель LoRA", "inputs": { "lora": { "name": "lora", "tooltip": "Модель LoRA для применения к диффузионной модели." }, "model": { "name": "model", "tooltip": "Диффузионная модель, к которой будет применена LoRA." }, "strength_model": { "name": "strength_model", "tooltip": "Степень модификации диффузионной модели. Это значение может быть отрицательным." } }, "outputs": { "0": { "tooltip": "Модифицированная диффузионная модель." } } };
const LoraSave = { "display_name": "Извлечь и сохранить LoRA", "inputs": { "bias_diff": { "name": "разница_смещения" }, "filename_prefix": { "name": "префикс_названия_файла" }, "lora_type": { "name": "тип_lora" }, "model_diff": { "name": "разница_модели", "tooltip": "Вывод ModelSubtract, который будет преобразован в lora." }, "rank": { "name": "ранг" }, "text_encoder_diff": { "name": "разница_текстового_кодировщика", "tooltip": "Вывод CLIPSubtract, который будет преобразован в lora." } } };
const LossGraphNode = { "display_name": "Построить график потерь", "inputs": { "filename_prefix": { "name": "префикс_имени_файла" }, "loss": { "name": "потери" } } };
const LotusConditioning = { "display_name": "LotusConditioning", "outputs": { "0": { "name": "условие", "tooltip": null } } };
const LtxvApiImageToVideo = { "description": "Видео профессионального качества с настраиваемой длительностью и разрешением на основе начального изображения.", "display_name": "LTXV Изображение в Видео", "inputs": { "duration": { "name": "длительность" }, "fps": { "name": "кадров_в_секунду" }, "generate_audio": { "name": "генерировать_аудио", "tooltip": "Если включено, сгенерированное видео будет включать ИИ-сгенерированный звук, соответствующий сцене." }, "image": { "name": "изображение", "tooltip": "Первый кадр, который будет использоваться для видео." }, "model": { "name": "модель" }, "prompt": { "name": "промпт" }, "resolution": { "name": "разрешение" } }, "outputs": { "0": { "tooltip": null } } };
const LtxvApiTextToVideo = { "description": "Видео профессионального качества с настраиваемой длительностью и разрешением.", "display_name": "LTXV Текст в Видео", "inputs": { "duration": { "name": "длительность" }, "fps": { "name": "кадров_в_секунду" }, "generate_audio": { "name": "генерировать_аудио", "tooltip": "Если включено, сгенерированное видео будет включать ИИ-сгенерированный звук, соответствующий сцене." }, "model": { "name": "модель" }, "prompt": { "name": "промпт" }, "resolution": { "name": "разрешение" } }, "outputs": { "0": { "tooltip": null } } };
const LumaConceptsNode = { "description": "Содержит одну или несколько концепций камеры для использования с узлами Luma Text to Video и Luma Image to Video.", "display_name": "Luma Концепции", "inputs": { "concept1": { "name": "concept1" }, "concept2": { "name": "concept2" }, "concept3": { "name": "concept3" }, "concept4": { "name": "concept4" }, "luma_concepts": { "name": "luma_concepts", "tooltip": "Необязательные концепции камеры для добавления к выбранным здесь." } }, "outputs": { "0": { "name": "luma_concepts", "tooltip": null } } };
const LumaImageModifyNode = { "description": "Синхронно изменяет изображения на основе запроса и соотношения сторон.", "display_name": "Luma Image to Image", "inputs": { "control_after_generate": { "name": "контроль после генерации" }, "image": { "name": "изображение" }, "image_weight": { "name": "вес изображения", "tooltip": "Вес изображения; чем ближе к 1.0, тем меньше будет изменено изображение." }, "model": { "name": "модель" }, "prompt": { "name": "промпт", "tooltip": "Промпт для генерации изображения" }, "seed": { "name": "seed", "tooltip": "Seed для определения необходимости повторного запуска узла; фактические результаты недетерминированы независимо от seed." } }, "outputs": { "0": { "tooltip": null } } };
const LumaImageNode = { "description": "Синхронно генерирует изображения на основе запроса и соотношения сторон.", "display_name": "Luma Текст в изображение", "inputs": { "aspect_ratio": { "name": "aspect_ratio" }, "character_image": { "name": "character_image", "tooltip": "Референсные изображения персонажей; может быть пакет из нескольких, учитывается до 4 изображений." }, "control_after_generate": { "name": "control after generate" }, "image_luma_ref": { "name": "image_luma_ref", "tooltip": "Подключение к Luma Reference для влияния на генерацию с помощью входных изображений; может быть учтено до 4 изображений." }, "model": { "name": "model" }, "prompt": { "name": "prompt", "tooltip": "Запрос для генерации изображения" }, "seed": { "name": "seed", "tooltip": "Сид для определения необходимости повторного запуска узла; фактические результаты не являются детерминированными независимо от сида." }, "style_image": { "name": "style_image", "tooltip": "Референсное изображение стиля; будет использовано только 1 изображение." }, "style_image_weight": { "name": "style_image_weight", "tooltip": "Вес изображения стиля. Игнорируется, если style_image не предоставлено." } }, "outputs": { "0": { "tooltip": null } } };
const LumaImageToVideoNode = { "description": "Генерирует видео синхронно на основе запроса, входных изображений и output_size.", "display_name": "Luma Image to Video", "inputs": { "control_after_generate": { "name": "контроль после генерации" }, "duration": { "name": "длительность" }, "first_image": { "name": "первое_изображение", "tooltip": "Первый кадр сгенерированного видео." }, "last_image": { "name": "последнее_изображение", "tooltip": "Последний кадр сгенерированного видео." }, "loop": { "name": "зацикливание" }, "luma_concepts": { "name": "luma_concepts", "tooltip": "Необязательные Camera Concepts для управления движением камеры через узел Luma Concepts." }, "model": { "name": "model" }, "prompt": { "name": "prompt", "tooltip": "Запрос для генерации видео" }, "resolution": { "name": "разрешение" }, "seed": { "name": "seed", "tooltip": "Seed для определения необходимости повторного запуска узла; фактические результаты недетерминированы независимо от seed." } }, "outputs": { "0": { "tooltip": null } } };
const LumaReferenceNode = { "description": "Содержит изображение и вес для использования с узлом Luma Generate Image.", "display_name": "Luma Reference", "inputs": { "image": { "name": "image", "tooltip": "Изображение для использования в качестве эталона." }, "luma_ref": { "name": "luma_ref" }, "weight": { "name": "weight", "tooltip": "Вес эталонного изображения." } }, "outputs": { "0": { "name": "luma_ref", "tooltip": null } } };
const LumaVideoNode = { "description": "Синхронно генерирует видео на основе запроса и output_size.", "display_name": "Luma Текст в Видео", "inputs": { "aspect_ratio": { "name": "aspect_ratio" }, "control_after_generate": { "name": "control after generate" }, "duration": { "name": "duration" }, "loop": { "name": "loop" }, "luma_concepts": { "name": "luma_concepts", "tooltip": "Необязательные Camera Concepts для управления движением камеры через узел Luma Concepts." }, "model": { "name": "model" }, "prompt": { "name": "prompt", "tooltip": "Запрос для генерации видео" }, "resolution": { "name": "resolution" }, "seed": { "name": "seed", "tooltip": "Seed для определения, нужно ли повторно запускать узел; фактические результаты всегда недетерминированы, независимо от seed." } }, "outputs": { "0": { "tooltip": null } } };
const Mahiro = { "description": "Измените руководство, чтобы оно больше масштабировалось в «направлении» положительной подсказки, а не разницы между отрицательной подсказкой.", "display_name": "Mahiro настолько мила, что заслуживает лучшей функции руководства!! (。・ω・。)", "inputs": { "model": { "name": "модель" } }, "outputs": { "0": { "name": "исправленная_модель", "tooltip": null } } };
const MaskComposite = { "display_name": "Составная маска", "inputs": { "destination": { "name": "назначение" }, "operation": { "name": "операция" }, "source": { "name": "источник" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const MaskPreview = { "description": "Сохраняет входные изображения в ваш выходной каталог ComfyUI.", "display_name": "MaskPreview", "inputs": { "mask": { "name": "mask" } } };
const MaskToImage = { "display_name": "Преобразовать маску в изображение", "inputs": { "mask": { "name": "маска" } } };
const MinimaxHailuoVideoNode = { "description": "Создает видео из промпта с возможностью использования начального кадра с помощью новой модели MiniMax Hailuo-02.", "display_name": "MiniMax Hailuo Видео", "inputs": { "control_after_generate": { "name": "управление после генерации" }, "duration": { "name": "длительность", "tooltip": "Длина выходного видео в секундах." }, "first_frame_image": { "name": "изображение_первого_кадра", "tooltip": "Необязательное изображение для использования в качестве первого кадра при генерации видео." }, "prompt_optimizer": { "name": "оптимизатор_промпта", "tooltip": "Оптимизировать промпт для улучшения качества генерации при необходимости." }, "prompt_text": { "name": "текстовый_промпт", "tooltip": "Текстовый промпт для управления генерацией видео." }, "resolution": { "name": "разрешение", "tooltip": "Размеры видеоизображения. 1080p — это 1920x1080, 768p — это 1366x768." }, "seed": { "name": "сид", "tooltip": "Случайное начальное значение, используемое для создания шума." } }, "outputs": { "0": { "tooltip": null } } };
const MinimaxImageToVideoNode = { "description": "Генерирует видео из изображения и подсказок с помощью API MiniMax", "display_name": "MiniMax: изображение в видео", "inputs": { "control_after_generate": { "name": "контроль после генерации" }, "image": { "name": "изображение", "tooltip": "Изображение, используемое в качестве первого кадра для генерации видео" }, "model": { "name": "модель", "tooltip": "Модель, используемая для генерации видео" }, "prompt_text": { "name": "текстовый промпт", "tooltip": "Текстовая подсказка для управления генерацией видео" }, "seed": { "name": "seed", "tooltip": "Случайное зерно, используемое для создания шума." } }, "outputs": { "0": { "tooltip": null } } };
const MinimaxTextToVideoNode = { "description": "Генерирует видео по подсказкам с помощью API MiniMax", "display_name": "MiniMax: текст в видео", "inputs": { "control_after_generate": { "name": "control after generate" }, "model": { "name": "model", "tooltip": "Модель для генерации видео" }, "prompt_text": { "name": "prompt_text", "tooltip": "Текстовая подсказка для управления генерацией видео" }, "seed": { "name": "seed", "tooltip": "Случайное зерно, используемое для создания шума." } }, "outputs": { "0": { "tooltip": null } } };
const ModelComputeDtype = { "display_name": "ModelComputeDtype", "inputs": { "dtype": { "name": "dtype" }, "model": { "name": "модель" } } };
const ModelMergeAdd = { "display_name": "Слияние моделей", "inputs": { "model1": { "name": "модель1" }, "model2": { "name": "модель2" } } };
const ModelMergeAuraflow = { "display_name": "Слияние моделей Auraflow", "inputs": { "cond_seq_linear_": { "name": "cond_seq_linear." }, "double_layers_0_": { "name": "double_layers.0." }, "double_layers_1_": { "name": "double_layers.1." }, "double_layers_2_": { "name": "double_layers.2." }, "double_layers_3_": { "name": "double_layers.3." }, "final_linear_": { "name": "final_linear." }, "init_x_linear_": { "name": "init_x_linear." }, "modF_": { "name": "modF." }, "model1": { "name": "модель1" }, "model2": { "name": "модель2" }, "positional_encoding": { "name": "позиционное кодирование" }, "register_tokens": { "name": "регистрация токенов" }, "single_layers_0_": { "name": "single_layers.0." }, "single_layers_10_": { "name": "single_layers.10." }, "single_layers_11_": { "name": "single_layers.11." }, "single_layers_12_": { "name": "single_layers.12." }, "single_layers_13_": { "name": "single_layers.13." }, "single_layers_14_": { "name": "single_layers.14." }, "single_layers_15_": { "name": "single_layers.15." }, "single_layers_16_": { "name": "single_layers.16." }, "single_layers_17_": { "name": "single_layers.17." }, "single_layers_18_": { "name": "single_layers.18." }, "single_layers_19_": { "name": "single_layers.19." }, "single_layers_1_": { "name": "single_layers.1." }, "single_layers_20_": { "name": "single_layers.20." }, "single_layers_21_": { "name": "single_layers.21." }, "single_layers_22_": { "name": "single_layers.22." }, "single_layers_23_": { "name": "single_layers.23." }, "single_layers_24_": { "name": "single_layers.24." }, "single_layers_25_": { "name": "single_layers.25." }, "single_layers_26_": { "name": "single_layers.26." }, "single_layers_27_": { "name": "single_layers.27." }, "single_layers_28_": { "name": "single_layers.28." }, "single_layers_29_": { "name": "single_layers.29." }, "single_layers_2_": { "name": "single_layers.2." }, "single_layers_30_": { "name": "single_layers.30." }, "single_layers_31_": { "name": "single_layers.31." }, "single_layers_3_": { "name": "single_layers.3." }, "single_layers_4_": { "name": "single_layers.4." }, "single_layers_5_": { "name": "single_layers.5." }, "single_layers_6_": { "name": "single_layers.6." }, "single_layers_7_": { "name": "single_layers.7." }, "single_layers_8_": { "name": "single_layers.8." }, "single_layers_9_": { "name": "single_layers.9." }, "t_embedder_": { "name": "t_embedder." } } };
const ModelMergeBlocks = { "display_name": "Слияние блоков моделей", "inputs": { "input": { "name": "вход" }, "middle": { "name": "середина" }, "model1": { "name": "модель1" }, "model2": { "name": "модель2" }, "out": { "name": "выход" } } };
const ModelMergeCosmos14B = { "display_name": "ModelMergeCosmos14B", "inputs": { "affline_norm_": { "name": "affline_norm." }, "blocks_block0_": { "name": "blocks.block0." }, "blocks_block10_": { "name": "blocks.block10." }, "blocks_block11_": { "name": "blocks.block11." }, "blocks_block12_": { "name": "blocks.block12." }, "blocks_block13_": { "name": "blocks.block13." }, "blocks_block14_": { "name": "blocks.block14." }, "blocks_block15_": { "name": "blocks.block15." }, "blocks_block16_": { "name": "blocks.block16." }, "blocks_block17_": { "name": "blocks.block17." }, "blocks_block18_": { "name": "blocks.block18." }, "blocks_block19_": { "name": "blocks.block19." }, "blocks_block1_": { "name": "blocks.block1." }, "blocks_block20_": { "name": "blocks.block20." }, "blocks_block21_": { "name": "blocks.block21." }, "blocks_block22_": { "name": "blocks.block22." }, "blocks_block23_": { "name": "blocks.block23." }, "blocks_block24_": { "name": "blocks.block24." }, "blocks_block25_": { "name": "blocks.block25." }, "blocks_block26_": { "name": "blocks.block26." }, "blocks_block27_": { "name": "blocks.block27." }, "blocks_block28_": { "name": "blocks.block28." }, "blocks_block29_": { "name": "blocks.block29." }, "blocks_block2_": { "name": "blocks.block2." }, "blocks_block30_": { "name": "blocks.block30." }, "blocks_block31_": { "name": "blocks.block31." }, "blocks_block32_": { "name": "blocks.block32." }, "blocks_block33_": { "name": "blocks.block33." }, "blocks_block34_": { "name": "blocks.block34." }, "blocks_block35_": { "name": "blocks.block35." }, "blocks_block3_": { "name": "blocks.block3." }, "blocks_block4_": { "name": "blocks.block4." }, "blocks_block5_": { "name": "blocks.block5." }, "blocks_block6_": { "name": "blocks.block6." }, "blocks_block7_": { "name": "blocks.block7." }, "blocks_block8_": { "name": "blocks.block8." }, "blocks_block9_": { "name": "blocks.block9." }, "extra_pos_embedder_": { "name": "extra_pos_embedder." }, "final_layer_": { "name": "final_layer." }, "model1": { "name": "модель1" }, "model2": { "name": "модель2" }, "pos_embedder_": { "name": "pos_embedder." }, "t_embedder_": { "name": "t_embedder." }, "x_embedder_": { "name": "x_embedder." } } };
const ModelMergeCosmos7B = { "display_name": "ModelMergeCosmos7B", "inputs": { "affline_norm_": { "name": "affline_norm." }, "blocks_block0_": { "name": "blocks.block0." }, "blocks_block10_": { "name": "blocks.block10." }, "blocks_block11_": { "name": "blocks.block11." }, "blocks_block12_": { "name": "blocks.block12." }, "blocks_block13_": { "name": "blocks.block13." }, "blocks_block14_": { "name": "blocks.block14." }, "blocks_block15_": { "name": "blocks.block15." }, "blocks_block16_": { "name": "blocks.block16." }, "blocks_block17_": { "name": "blocks.block17." }, "blocks_block18_": { "name": "blocks.block18." }, "blocks_block19_": { "name": "blocks.block19." }, "blocks_block1_": { "name": "blocks.block1." }, "blocks_block20_": { "name": "blocks.block20." }, "blocks_block21_": { "name": "blocks.block21." }, "blocks_block22_": { "name": "blocks.block22." }, "blocks_block23_": { "name": "blocks.block23." }, "blocks_block24_": { "name": "blocks.block24." }, "blocks_block25_": { "name": "blocks.block25." }, "blocks_block26_": { "name": "blocks.block26." }, "blocks_block27_": { "name": "blocks.block27." }, "blocks_block2_": { "name": "blocks.block2." }, "blocks_block3_": { "name": "blocks.block3." }, "blocks_block4_": { "name": "blocks.block4." }, "blocks_block5_": { "name": "blocks.block5." }, "blocks_block6_": { "name": "blocks.block6." }, "blocks_block7_": { "name": "blocks.block7." }, "blocks_block8_": { "name": "blocks.block8." }, "blocks_block9_": { "name": "blocks.block9." }, "extra_pos_embedder_": { "name": "extra_pos_embedder." }, "final_layer_": { "name": "final_layer." }, "model1": { "name": "model1" }, "model2": { "name": "model2" }, "pos_embedder_": { "name": "pos_embedder." }, "t_embedder_": { "name": "t_embedder." }, "x_embedder_": { "name": "x_embedder." } } };
const ModelMergeCosmosPredict2_14B = { "display_name": "ModelMergeCosmosPredict2_14B", "inputs": { "blocks_0_": { "name": "blocks.0." }, "blocks_10_": { "name": "blocks.10." }, "blocks_11_": { "name": "blocks.11." }, "blocks_12_": { "name": "blocks.12." }, "blocks_13_": { "name": "blocks.13." }, "blocks_14_": { "name": "blocks.14." }, "blocks_15_": { "name": "blocks.15." }, "blocks_16_": { "name": "blocks.16." }, "blocks_17_": { "name": "blocks.17." }, "blocks_18_": { "name": "blocks.18." }, "blocks_19_": { "name": "blocks.19." }, "blocks_1_": { "name": "blocks.1." }, "blocks_20_": { "name": "blocks.20." }, "blocks_21_": { "name": "blocks.21." }, "blocks_22_": { "name": "blocks.22." }, "blocks_23_": { "name": "blocks.23." }, "blocks_24_": { "name": "blocks.24." }, "blocks_25_": { "name": "блоки.25." }, "blocks_26_": { "name": "блоки.26." }, "blocks_27_": { "name": "блоки.27." }, "blocks_28_": { "name": "блоки.28." }, "blocks_29_": { "name": "блоки.29." }, "blocks_2_": { "name": "blocks.2." }, "blocks_30_": { "name": "блоки.30." }, "blocks_31_": { "name": "блоки.31." }, "blocks_32_": { "name": "блоки.32." }, "blocks_33_": { "name": "блоки.33." }, "blocks_34_": { "name": "блоки.34." }, "blocks_35_": { "name": "блоки.35." }, "blocks_3_": { "name": "blocks.3." }, "blocks_4_": { "name": "blocks.4." }, "blocks_5_": { "name": "blocks.5." }, "blocks_6_": { "name": "blocks.6." }, "blocks_7_": { "name": "blocks.7." }, "blocks_8_": { "name": "blocks.8." }, "blocks_9_": { "name": "blocks.9." }, "final_layer_": { "name": "финальный_слой." }, "model1": { "name": "модель1" }, "model2": { "name": "модель2" }, "pos_embedder_": { "name": "pos_embedder." }, "t_embedder_": { "name": "t_embedder." }, "t_embedding_norm_": { "name": "t_embedding_norm." }, "x_embedder_": { "name": "x_embedder." } } };
const ModelMergeCosmosPredict2_2B = { "display_name": "ModelMergeCosmosPredict2_2B", "inputs": { "blocks_0_": { "name": "блоки.0." }, "blocks_10_": { "name": "блоки.10." }, "blocks_11_": { "name": "блоки.11." }, "blocks_12_": { "name": "блоки.12." }, "blocks_13_": { "name": "блоки.13." }, "blocks_14_": { "name": "блоки.14." }, "blocks_15_": { "name": "блоки.15." }, "blocks_16_": { "name": "блоки.16." }, "blocks_17_": { "name": "блоки.17." }, "blocks_18_": { "name": "блоки.18." }, "blocks_19_": { "name": "блоки.19." }, "blocks_1_": { "name": "блоки.1." }, "blocks_20_": { "name": "блоки.20." }, "blocks_21_": { "name": "блоки.21." }, "blocks_22_": { "name": "блоки.22." }, "blocks_23_": { "name": "блоки.23." }, "blocks_24_": { "name": "блоки.24." }, "blocks_25_": { "name": "блоки.25." }, "blocks_26_": { "name": "блоки.26." }, "blocks_27_": { "name": "блоки.27." }, "blocks_2_": { "name": "блоки.2." }, "blocks_3_": { "name": "блоки.3." }, "blocks_4_": { "name": "блоки.4." }, "blocks_5_": { "name": "блоки.5." }, "blocks_6_": { "name": "блоки.6." }, "blocks_7_": { "name": "блоки.7." }, "blocks_8_": { "name": "блоки.8." }, "blocks_9_": { "name": "блоки.9." }, "final_layer_": { "name": "финальный_слой." }, "model1": { "name": "модель1" }, "model2": { "name": "модель2" }, "pos_embedder_": { "name": "pos_embedder." }, "t_embedder_": { "name": "t_embedder." }, "t_embedding_norm_": { "name": "t_embedding_norm." }, "x_embedder_": { "name": "x_embedder." } } };
const ModelMergeFlux1 = { "display_name": "Слияние моделей Flux1", "inputs": { "double_blocks_0_": { "name": "double_blocks.0." }, "double_blocks_10_": { "name": "double_blocks.10." }, "double_blocks_11_": { "name": "double_blocks.11." }, "double_blocks_12_": { "name": "double_blocks.12." }, "double_blocks_13_": { "name": "double_blocks.13." }, "double_blocks_14_": { "name": "double_blocks.14." }, "double_blocks_15_": { "name": "double_blocks.15." }, "double_blocks_16_": { "name": "double_blocks.16." }, "double_blocks_17_": { "name": "double_blocks.17." }, "double_blocks_18_": { "name": "double_blocks.18." }, "double_blocks_1_": { "name": "double_blocks.1." }, "double_blocks_2_": { "name": "double_blocks.2." }, "double_blocks_3_": { "name": "double_blocks.3." }, "double_blocks_4_": { "name": "double_blocks.4." }, "double_blocks_5_": { "name": "double_blocks.5." }, "double_blocks_6_": { "name": "double_blocks.6." }, "double_blocks_7_": { "name": "double_blocks.7." }, "double_blocks_8_": { "name": "double_blocks.8." }, "double_blocks_9_": { "name": "double_blocks.9." }, "final_layer_": { "name": "final_layer." }, "guidance_in": { "name": "guidance_in" }, "img_in_": { "name": "img_in." }, "model1": { "name": "модель1" }, "model2": { "name": "модель2" }, "single_blocks_0_": { "name": "single_blocks.0." }, "single_blocks_10_": { "name": "single_blocks.10." }, "single_blocks_11_": { "name": "single_blocks.11." }, "single_blocks_12_": { "name": "single_blocks.12." }, "single_blocks_13_": { "name": "single_blocks.13." }, "single_blocks_14_": { "name": "single_blocks.14." }, "single_blocks_15_": { "name": "single_blocks.15." }, "single_blocks_16_": { "name": "single_blocks.16." }, "single_blocks_17_": { "name": "single_blocks.17." }, "single_blocks_18_": { "name": "single_blocks.18." }, "single_blocks_19_": { "name": "single_blocks.19." }, "single_blocks_1_": { "name": "single_blocks.1." }, "single_blocks_20_": { "name": "single_blocks.20." }, "single_blocks_21_": { "name": "single_blocks.21." }, "single_blocks_22_": { "name": "single_blocks.22." }, "single_blocks_23_": { "name": "single_blocks.23." }, "single_blocks_24_": { "name": "single_blocks.24." }, "single_blocks_25_": { "name": "single_blocks.25." }, "single_blocks_26_": { "name": "single_blocks.26." }, "single_blocks_27_": { "name": "single_blocks.27." }, "single_blocks_28_": { "name": "single_blocks.28." }, "single_blocks_29_": { "name": "single_blocks.29." }, "single_blocks_2_": { "name": "single_blocks.2." }, "single_blocks_30_": { "name": "single_blocks.30." }, "single_blocks_31_": { "name": "single_blocks.31." }, "single_blocks_32_": { "name": "single_blocks.32." }, "single_blocks_33_": { "name": "single_blocks.33." }, "single_blocks_34_": { "name": "single_blocks.34." }, "single_blocks_35_": { "name": "single_blocks.35." }, "single_blocks_36_": { "name": "single_blocks.36." }, "single_blocks_37_": { "name": "single_blocks.37." }, "single_blocks_3_": { "name": "single_blocks.3." }, "single_blocks_4_": { "name": "single_blocks.4." }, "single_blocks_5_": { "name": "single_blocks.5." }, "single_blocks_6_": { "name": "single_blocks.6." }, "single_blocks_7_": { "name": "single_blocks.7." }, "single_blocks_8_": { "name": "single_blocks.8." }, "single_blocks_9_": { "name": "single_blocks.9." }, "time_in_": { "name": "time_in." }, "txt_in_": { "name": "txt_in." }, "vector_in_": { "name": "vector_in." } } };
const ModelMergeLTXV = { "display_name": "Слияние моделей LTXV", "inputs": { "adaln_single_": { "name": "adaln_single." }, "caption_projection_": { "name": "caption_projection." }, "model1": { "name": "модель1" }, "model2": { "name": "модель2" }, "patchify_proj_": { "name": "patchify_proj." }, "proj_out_": { "name": "proj_out." }, "scale_shift_table": { "name": "scale_shift_table" }, "transformer_blocks_0_": { "name": "transformer_blocks.0." }, "transformer_blocks_10_": { "name": "transformer_blocks.10." }, "transformer_blocks_11_": { "name": "transformer_blocks.11." }, "transformer_blocks_12_": { "name": "transformer_blocks.12." }, "transformer_blocks_13_": { "name": "transformer_blocks.13." }, "transformer_blocks_14_": { "name": "transformer_blocks.14." }, "transformer_blocks_15_": { "name": "transformer_blocks.15." }, "transformer_blocks_16_": { "name": "transformer_blocks.16." }, "transformer_blocks_17_": { "name": "transformer_blocks.17." }, "transformer_blocks_18_": { "name": "transformer_blocks.18." }, "transformer_blocks_19_": { "name": "transformer_blocks.19." }, "transformer_blocks_1_": { "name": "transformer_blocks.1." }, "transformer_blocks_20_": { "name": "transformer_blocks.20." }, "transformer_blocks_21_": { "name": "transformer_blocks.21." }, "transformer_blocks_22_": { "name": "transformer_blocks.22." }, "transformer_blocks_23_": { "name": "transformer_blocks.23." }, "transformer_blocks_24_": { "name": "transformer_blocks.24." }, "transformer_blocks_25_": { "name": "transformer_blocks.25." }, "transformer_blocks_26_": { "name": "transformer_blocks.26." }, "transformer_blocks_27_": { "name": "transformer_blocks.27." }, "transformer_blocks_2_": { "name": "transformer_blocks.2." }, "transformer_blocks_3_": { "name": "transformer_blocks.3." }, "transformer_blocks_4_": { "name": "transformer_blocks.4." }, "transformer_blocks_5_": { "name": "transformer_blocks.5." }, "transformer_blocks_6_": { "name": "transformer_blocks.6." }, "transformer_blocks_7_": { "name": "transformer_blocks.7." }, "transformer_blocks_8_": { "name": "transformer_blocks.8." }, "transformer_blocks_9_": { "name": "transformer_blocks.9." } } };
const ModelMergeMochiPreview = { "display_name": "Предварительный просмотр слияния моделей Mochi", "inputs": { "blocks_0_": { "name": "blocks.0." }, "blocks_10_": { "name": "blocks.10." }, "blocks_11_": { "name": "blocks.11." }, "blocks_12_": { "name": "blocks.12." }, "blocks_13_": { "name": "blocks.13." }, "blocks_14_": { "name": "blocks.14." }, "blocks_15_": { "name": "blocks.15." }, "blocks_16_": { "name": "blocks.16." }, "blocks_17_": { "name": "blocks.17." }, "blocks_18_": { "name": "blocks.18." }, "blocks_19_": { "name": "blocks.19." }, "blocks_1_": { "name": "blocks.1." }, "blocks_20_": { "name": "blocks.20." }, "blocks_21_": { "name": "blocks.21." }, "blocks_22_": { "name": "blocks.22." }, "blocks_23_": { "name": "blocks.23." }, "blocks_24_": { "name": "blocks.24." }, "blocks_25_": { "name": "blocks.25." }, "blocks_26_": { "name": "blocks.26." }, "blocks_27_": { "name": "blocks.27." }, "blocks_28_": { "name": "blocks.28." }, "blocks_29_": { "name": "blocks.29." }, "blocks_2_": { "name": "blocks.2." }, "blocks_30_": { "name": "blocks.30." }, "blocks_31_": { "name": "blocks.31." }, "blocks_32_": { "name": "blocks.32." }, "blocks_33_": { "name": "blocks.33." }, "blocks_34_": { "name": "blocks.34." }, "blocks_35_": { "name": "blocks.35." }, "blocks_36_": { "name": "blocks.36." }, "blocks_37_": { "name": "blocks.37." }, "blocks_38_": { "name": "blocks.38." }, "blocks_39_": { "name": "blocks.39." }, "blocks_3_": { "name": "blocks.3." }, "blocks_40_": { "name": "blocks.40." }, "blocks_41_": { "name": "blocks.41." }, "blocks_42_": { "name": "blocks.42." }, "blocks_43_": { "name": "blocks.43." }, "blocks_44_": { "name": "blocks.44." }, "blocks_45_": { "name": "blocks.45." }, "blocks_46_": { "name": "blocks.46." }, "blocks_47_": { "name": "blocks.47." }, "blocks_4_": { "name": "blocks.4." }, "blocks_5_": { "name": "blocks.5." }, "blocks_6_": { "name": "blocks.6." }, "blocks_7_": { "name": "blocks.7." }, "blocks_8_": { "name": "blocks.8." }, "blocks_9_": { "name": "blocks.9." }, "final_layer_": { "name": "final_layer." }, "model1": { "name": "модель1" }, "model2": { "name": "модель2" }, "pos_frequencies_": { "name": "pos_frequencies." }, "t5_y_embedder_": { "name": "t5_y_embedder." }, "t5_yproj_": { "name": "t5_yproj." }, "t_embedder_": { "name": "t_embedder." } } };
const ModelMergeQwenImage = { "display_name": "СлияниеМоделейQwenImage", "inputs": { "img_in_": { "name": "изображение_вход." }, "model1": { "name": "модель1" }, "model2": { "name": "модель2" }, "pos_embeds_": { "name": "позиционные_эмбеддинги." }, "proj_out_": { "name": "proj_out." }, "time_text_embed_": { "name": "временной_текст_эмбеддинг." }, "transformer_blocks_0_": { "name": "трансформер_блоки.0." }, "transformer_blocks_10_": { "name": "трансформер_блоки.10." }, "transformer_blocks_11_": { "name": "трансформер_блоки.11." }, "transformer_blocks_12_": { "name": "трансформер_блоки.12." }, "transformer_blocks_13_": { "name": "трансформер_блоки.13." }, "transformer_blocks_14_": { "name": "transformer_blocks.14." }, "transformer_blocks_15_": { "name": "transformer_blocks.15." }, "transformer_blocks_16_": { "name": "transformer_blocks.16." }, "transformer_blocks_17_": { "name": "transformer_blocks.17." }, "transformer_blocks_18_": { "name": "transformer_blocks.18." }, "transformer_blocks_19_": { "name": "transformer_blocks.19." }, "transformer_blocks_1_": { "name": "трансформер_блоки.1." }, "transformer_blocks_20_": { "name": "transformer_blocks.20." }, "transformer_blocks_21_": { "name": "transformer_blocks.21." }, "transformer_blocks_22_": { "name": "transformer_blocks.22." }, "transformer_blocks_23_": { "name": "transformer_blocks.23." }, "transformer_blocks_24_": { "name": "transformer_blocks.24." }, "transformer_blocks_25_": { "name": "transformer_blocks.25." }, "transformer_blocks_26_": { "name": "transformer_blocks.26." }, "transformer_blocks_27_": { "name": "transformer_blocks.27." }, "transformer_blocks_28_": { "name": "transformer_blocks.28." }, "transformer_blocks_29_": { "name": "transformer_blocks.29." }, "transformer_blocks_2_": { "name": "трансформер_блоки.2." }, "transformer_blocks_30_": { "name": "transformer_blocks.30." }, "transformer_blocks_31_": { "name": "transformer_blocks.31." }, "transformer_blocks_32_": { "name": "transformer_blocks.32." }, "transformer_blocks_33_": { "name": "transformer_blocks.33." }, "transformer_blocks_34_": { "name": "transformer_blocks.34." }, "transformer_blocks_35_": { "name": "transformer_blocks.35." }, "transformer_blocks_36_": { "name": "transformer_blocks.36." }, "transformer_blocks_37_": { "name": "transformer_blocks.37." }, "transformer_blocks_38_": { "name": "transformer_blocks.38." }, "transformer_blocks_39_": { "name": "transformer_blocks.39." }, "transformer_blocks_3_": { "name": "трансформер_блоки.3." }, "transformer_blocks_40_": { "name": "transformer_blocks.40." }, "transformer_blocks_41_": { "name": "transformer_blocks.41." }, "transformer_blocks_42_": { "name": "transformer_blocks.42." }, "transformer_blocks_43_": { "name": "transformer_blocks.43." }, "transformer_blocks_44_": { "name": "transformer_blocks.44." }, "transformer_blocks_45_": { "name": "transformer_blocks.45." }, "transformer_blocks_46_": { "name": "transformer_blocks.46." }, "transformer_blocks_47_": { "name": "transformer_blocks.47." }, "transformer_blocks_48_": { "name": "transformer_blocks.48." }, "transformer_blocks_49_": { "name": "transformer_blocks.49." }, "transformer_blocks_4_": { "name": "трансформер_блоки.4." }, "transformer_blocks_50_": { "name": "transformer_blocks.50." }, "transformer_blocks_51_": { "name": "transformer_blocks.51." }, "transformer_blocks_52_": { "name": "transformer_blocks.52." }, "transformer_blocks_53_": { "name": "transformer_blocks.53." }, "transformer_blocks_54_": { "name": "transformer_blocks.54." }, "transformer_blocks_55_": { "name": "transformer_blocks.55." }, "transformer_blocks_56_": { "name": "transformer_blocks.56." }, "transformer_blocks_57_": { "name": "transformer_blocks.57." }, "transformer_blocks_58_": { "name": "transformer_blocks.58." }, "transformer_blocks_59_": { "name": "transformer_blocks.59." }, "transformer_blocks_5_": { "name": "трансформер_блоки.5." }, "transformer_blocks_6_": { "name": "трансформер_блоки.6." }, "transformer_blocks_7_": { "name": "трансформер_блоки.7." }, "transformer_blocks_8_": { "name": "трансформер_блоки.8." }, "transformer_blocks_9_": { "name": "трансформер_блоки.9." }, "txt_in_": { "name": "текст_вход." }, "txt_norm_": { "name": "текст_нормализация." } } };
const ModelMergeSD1 = { "display_name": "Слияние моделей SD1", "inputs": { "input_blocks_0_": { "name": "input_blocks.0." }, "input_blocks_10_": { "name": "input_blocks.10." }, "input_blocks_11_": { "name": "input_blocks.11." }, "input_blocks_1_": { "name": "input_blocks.1." }, "input_blocks_2_": { "name": "input_blocks.2." }, "input_blocks_3_": { "name": "input_blocks.3." }, "input_blocks_4_": { "name": "input_blocks.4." }, "input_blocks_5_": { "name": "input_blocks.5." }, "input_blocks_6_": { "name": "input_blocks.6." }, "input_blocks_7_": { "name": "input_blocks.7." }, "input_blocks_8_": { "name": "input_blocks.8." }, "input_blocks_9_": { "name": "input_blocks.9." }, "label_emb_": { "name": "label_emb." }, "middle_block_0_": { "name": "middle_block.0." }, "middle_block_1_": { "name": "middle_block.1." }, "middle_block_2_": { "name": "middle_block.2." }, "model1": { "name": "модель1" }, "model2": { "name": "модель2" }, "out_": { "name": "out." }, "output_blocks_0_": { "name": "output_blocks.0." }, "output_blocks_10_": { "name": "output_blocks.10." }, "output_blocks_11_": { "name": "output_blocks.11." }, "output_blocks_1_": { "name": "output_blocks.1." }, "output_blocks_2_": { "name": "output_blocks.2." }, "output_blocks_3_": { "name": "output_blocks.3." }, "output_blocks_4_": { "name": "output_blocks.4." }, "output_blocks_5_": { "name": "output_blocks.5." }, "output_blocks_6_": { "name": "output_blocks.6." }, "output_blocks_7_": { "name": "output_blocks.7." }, "output_blocks_8_": { "name": "output_blocks.8." }, "output_blocks_9_": { "name": "output_blocks.9." }, "time_embed_": { "name": "time_embed." } } };
const ModelMergeSD2 = { "display_name": "Слияние моделей SD2", "inputs": { "input_blocks_0_": { "name": "input_blocks.0." }, "input_blocks_10_": { "name": "input_blocks.10." }, "input_blocks_11_": { "name": "input_blocks.11." }, "input_blocks_1_": { "name": "input_blocks.1." }, "input_blocks_2_": { "name": "input_blocks.2." }, "input_blocks_3_": { "name": "input_blocks.3." }, "input_blocks_4_": { "name": "input_blocks.4." }, "input_blocks_5_": { "name": "input_blocks.5." }, "input_blocks_6_": { "name": "input_blocks.6." }, "input_blocks_7_": { "name": "input_blocks.7." }, "input_blocks_8_": { "name": "input_blocks.8." }, "input_blocks_9_": { "name": "input_blocks.9." }, "label_emb_": { "name": "label_emb." }, "middle_block_0_": { "name": "middle_block.0." }, "middle_block_1_": { "name": "middle_block.1." }, "middle_block_2_": { "name": "middle_block.2." }, "model1": { "name": "модель1" }, "model2": { "name": "модель2" }, "out_": { "name": "out." }, "output_blocks_0_": { "name": "output_blocks.0." }, "output_blocks_10_": { "name": "output_blocks.10." }, "output_blocks_11_": { "name": "output_blocks.11." }, "output_blocks_1_": { "name": "output_blocks.1." }, "output_blocks_2_": { "name": "output_blocks.2." }, "output_blocks_3_": { "name": "output_blocks.3." }, "output_blocks_4_": { "name": "output_blocks.4." }, "output_blocks_5_": { "name": "output_blocks.5." }, "output_blocks_6_": { "name": "output_blocks.6." }, "output_blocks_7_": { "name": "output_blocks.7." }, "output_blocks_8_": { "name": "output_blocks.8." }, "output_blocks_9_": { "name": "output_blocks.9." }, "time_embed_": { "name": "time_embed." } } };
const ModelMergeSD35_Large = { "display_name": "Слияние моделей SD35_Large", "inputs": { "context_embedder_": { "name": "context_embedder." }, "final_layer_": { "name": "final_layer." }, "joint_blocks_0_": { "name": "joint_blocks.0." }, "joint_blocks_10_": { "name": "joint_blocks.10." }, "joint_blocks_11_": { "name": "joint_blocks.11." }, "joint_blocks_12_": { "name": "joint_blocks.12." }, "joint_blocks_13_": { "name": "joint_blocks.13." }, "joint_blocks_14_": { "name": "joint_blocks.14." }, "joint_blocks_15_": { "name": "joint_blocks.15." }, "joint_blocks_16_": { "name": "joint_blocks.16." }, "joint_blocks_17_": { "name": "joint_blocks.17." }, "joint_blocks_18_": { "name": "joint_blocks.18." }, "joint_blocks_19_": { "name": "joint_blocks.19." }, "joint_blocks_1_": { "name": "joint_blocks.1." }, "joint_blocks_20_": { "name": "joint_blocks.20." }, "joint_blocks_21_": { "name": "joint_blocks.21." }, "joint_blocks_22_": { "name": "joint_blocks.22." }, "joint_blocks_23_": { "name": "joint_blocks.23." }, "joint_blocks_24_": { "name": "joint_blocks.24." }, "joint_blocks_25_": { "name": "joint_blocks.25." }, "joint_blocks_26_": { "name": "joint_blocks.26." }, "joint_blocks_27_": { "name": "joint_blocks.27." }, "joint_blocks_28_": { "name": "joint_blocks.28." }, "joint_blocks_29_": { "name": "joint_blocks.29." }, "joint_blocks_2_": { "name": "joint_blocks.2." }, "joint_blocks_30_": { "name": "joint_blocks.30." }, "joint_blocks_31_": { "name": "joint_blocks.31." }, "joint_blocks_32_": { "name": "joint_blocks.32." }, "joint_blocks_33_": { "name": "joint_blocks.33." }, "joint_blocks_34_": { "name": "joint_blocks.34." }, "joint_blocks_35_": { "name": "joint_blocks.35." }, "joint_blocks_36_": { "name": "joint_blocks.36." }, "joint_blocks_37_": { "name": "joint_blocks.37." }, "joint_blocks_3_": { "name": "joint_blocks.3." }, "joint_blocks_4_": { "name": "joint_blocks.4." }, "joint_blocks_5_": { "name": "joint_blocks.5." }, "joint_blocks_6_": { "name": "joint_blocks.6." }, "joint_blocks_7_": { "name": "joint_blocks.7." }, "joint_blocks_8_": { "name": "joint_blocks.8." }, "joint_blocks_9_": { "name": "joint_blocks.9." }, "model1": { "name": "модель1" }, "model2": { "name": "модель2" }, "pos_embed_": { "name": "pos_embed." }, "t_embedder_": { "name": "t_embedder." }, "x_embedder_": { "name": "x_embedder." }, "y_embedder_": { "name": "y_embedder." } } };
const ModelMergeSD3_2B = { "display_name": "Слияние моделей SD3_2B", "inputs": { "context_embedder_": { "name": "context_embedder." }, "final_layer_": { "name": "final_layer." }, "joint_blocks_0_": { "name": "joint_blocks.0." }, "joint_blocks_10_": { "name": "joint_blocks.10." }, "joint_blocks_11_": { "name": "joint_blocks.11." }, "joint_blocks_12_": { "name": "joint_blocks.12." }, "joint_blocks_13_": { "name": "joint_blocks.13." }, "joint_blocks_14_": { "name": "joint_blocks.14." }, "joint_blocks_15_": { "name": "joint_blocks.15." }, "joint_blocks_16_": { "name": "joint_blocks.16." }, "joint_blocks_17_": { "name": "joint_blocks.17." }, "joint_blocks_18_": { "name": "joint_blocks.18." }, "joint_blocks_19_": { "name": "joint_blocks.19." }, "joint_blocks_1_": { "name": "joint_blocks.1." }, "joint_blocks_20_": { "name": "joint_blocks.20." }, "joint_blocks_21_": { "name": "joint_blocks.21." }, "joint_blocks_22_": { "name": "joint_blocks.22." }, "joint_blocks_23_": { "name": "joint_blocks.23." }, "joint_blocks_2_": { "name": "joint_blocks.2." }, "joint_blocks_3_": { "name": "joint_blocks.3." }, "joint_blocks_4_": { "name": "joint_blocks.4." }, "joint_blocks_5_": { "name": "joint_blocks.5." }, "joint_blocks_6_": { "name": "joint_blocks.6." }, "joint_blocks_7_": { "name": "joint_blocks.7." }, "joint_blocks_8_": { "name": "joint_blocks.8." }, "joint_blocks_9_": { "name": "joint_blocks.9." }, "model1": { "name": "модель1" }, "model2": { "name": "модель2" }, "pos_embed_": { "name": "pos_embed." }, "t_embedder_": { "name": "t_embedder." }, "x_embedder_": { "name": "x_embedder." }, "y_embedder_": { "name": "y_embedder." } } };
const ModelMergeSDXL = { "display_name": "Слияние моделей SDXL", "inputs": { "input_blocks_0": { "name": "input_blocks.0" }, "input_blocks_1": { "name": "input_blocks.1" }, "input_blocks_2": { "name": "input_blocks.2" }, "input_blocks_3": { "name": "input_blocks.3" }, "input_blocks_4": { "name": "input_blocks.4" }, "input_blocks_5": { "name": "input_blocks.5" }, "input_blocks_6": { "name": "input_blocks.6" }, "input_blocks_7": { "name": "input_blocks.7" }, "input_blocks_8": { "name": "input_blocks.8" }, "label_emb_": { "name": "label_emb." }, "middle_block_0": { "name": "middle_block.0" }, "middle_block_1": { "name": "middle_block.1" }, "middle_block_2": { "name": "middle_block.2" }, "model1": { "name": "модель1" }, "model2": { "name": "модель2" }, "out_": { "name": "out." }, "output_blocks_0": { "name": "output_blocks.0" }, "output_blocks_1": { "name": "output_blocks.1" }, "output_blocks_2": { "name": "output_blocks.2" }, "output_blocks_3": { "name": "output_blocks.3" }, "output_blocks_4": { "name": "output_blocks.4" }, "output_blocks_5": { "name": "output_blocks.5" }, "output_blocks_6": { "name": "output_blocks.6" }, "output_blocks_7": { "name": "output_blocks.7" }, "output_blocks_8": { "name": "output_blocks.8" }, "time_embed_": { "name": "time_embed." } } };
const ModelMergeSimple = { "display_name": "Простое слияние моделей", "inputs": { "model1": { "name": "модель1" }, "model2": { "name": "модель2" }, "ratio": { "name": "соотношение" } } };
const ModelMergeSubtract = { "display_name": "Вычитание моделей", "inputs": { "model1": { "name": "модель1" }, "model2": { "name": "модель2" }, "multiplier": { "name": "множитель" } } };
const ModelMergeWAN2_1 = { "description": "Модель 1.3B имеет 30 блоков, модель 14B — 40 блоков. Модель для преобразования изображения в видео имеет дополнительный img_emb.", "display_name": "ModelMergeWAN2_1", "inputs": { "blocks_0_": { "name": "blocks.0." }, "blocks_10_": { "name": "blocks.10." }, "blocks_11_": { "name": "blocks.11." }, "blocks_12_": { "name": "blocks.12." }, "blocks_13_": { "name": "blocks.13." }, "blocks_14_": { "name": "blocks.14." }, "blocks_15_": { "name": "blocks.15." }, "blocks_16_": { "name": "blocks.16." }, "blocks_17_": { "name": "blocks.17." }, "blocks_18_": { "name": "blocks.18." }, "blocks_19_": { "name": "blocks.19." }, "blocks_1_": { "name": "blocks.1." }, "blocks_20_": { "name": "blocks.20." }, "blocks_21_": { "name": "blocks.21." }, "blocks_22_": { "name": "blocks.22." }, "blocks_23_": { "name": "blocks.23." }, "blocks_24_": { "name": "blocks.24." }, "blocks_25_": { "name": "blocks.25." }, "blocks_26_": { "name": "blocks.26." }, "blocks_27_": { "name": "blocks.27." }, "blocks_28_": { "name": "blocks.28." }, "blocks_29_": { "name": "blocks.29." }, "blocks_2_": { "name": "blocks.2." }, "blocks_30_": { "name": "blocks.30." }, "blocks_31_": { "name": "blocks.31." }, "blocks_32_": { "name": "blocks.32." }, "blocks_33_": { "name": "blocks.33." }, "blocks_34_": { "name": "blocks.34." }, "blocks_35_": { "name": "blocks.35." }, "blocks_36_": { "name": "blocks.36." }, "blocks_37_": { "name": "blocks.37." }, "blocks_38_": { "name": "blocks.38." }, "blocks_39_": { "name": "blocks.39." }, "blocks_3_": { "name": "blocks.3." }, "blocks_4_": { "name": "blocks.4." }, "blocks_5_": { "name": "blocks.5." }, "blocks_6_": { "name": "blocks.6." }, "blocks_7_": { "name": "blocks.7." }, "blocks_8_": { "name": "blocks.8." }, "blocks_9_": { "name": "blocks.9." }, "head_": { "name": "head." }, "img_emb_": { "name": "img_emb." }, "model1": { "name": "model1" }, "model2": { "name": "model2" }, "patch_embedding_": { "name": "patch_embedding." }, "text_embedding_": { "name": "text_embedding." }, "time_embedding_": { "name": "time_embedding." }, "time_projection_": { "name": "time_projection." } } };
const ModelPatchLoader = { "display_name": "ModelPatchLoader", "inputs": { "name": { "name": "название" } } };
const ModelSamplingAuraFlow = { "display_name": "Выборка модели AuraFlow", "inputs": { "model": { "name": "модель" }, "shift": { "name": "сдвиг" } } };
const ModelSamplingContinuousEDM = { "display_name": "Выборка модели Continuous EDM", "inputs": { "model": { "name": "модель" }, "sampling": { "name": "выборка" }, "sigma_max": { "name": "sigma_max" }, "sigma_min": { "name": "sigma_min" } } };
const ModelSamplingContinuousV = { "display_name": "Выборка модели Continuous V", "inputs": { "model": { "name": "модель" }, "sampling": { "name": "выборка" }, "sigma_max": { "name": "sigma_max" }, "sigma_min": { "name": "sigma_min" } } };
const ModelSamplingDiscrete = { "display_name": "Дискретная выборка модели", "inputs": { "model": { "name": "модель" }, "sampling": { "name": "выборка" }, "zsnr": { "name": "zsnr" } } };
const ModelSamplingFlux = { "display_name": "Выборка модели Flux", "inputs": { "base_shift": { "name": "базовый_сдвиг" }, "height": { "name": "высота" }, "max_shift": { "name": "макс_сдвиг" }, "model": { "name": "модель" }, "width": { "name": "ширина" } } };
const ModelSamplingLTXV = { "display_name": "Выборка модели LTXV", "inputs": { "base_shift": { "name": "базовый_сдвиг" }, "latent": { "name": "скрытый" }, "max_shift": { "name": "макс_сдвиг" }, "model": { "name": "модель" } }, "outputs": { "0": { "tooltip": null } } };
const ModelSamplingSD3 = { "display_name": "Выборка модели SD3", "inputs": { "model": { "name": "модель" }, "shift": { "name": "сдвиг" } } };
const ModelSamplingStableCascade = { "display_name": "Выборка модели Stable Cascade", "inputs": { "model": { "name": "модель" }, "shift": { "name": "сдвиг" } } };
const ModelSave = { "display_name": "Сохранить модель", "inputs": { "filename_prefix": { "name": "префикс_названия_файла" }, "model": { "name": "модель" } } };
const MoonvalleyImg2VideoNode = { "description": "Узел Moonvalley Marey: Изображение в видео", "display_name": "Moonvalley Marey: Изображение в видео", "inputs": { "control_after_generate": { "name": "управление после генерации" }, "image": { "name": "изображение", "tooltip": "Эталонное изображение, используемое для генерации видео" }, "negative_prompt": { "name": "негативный_промпт", "tooltip": "Текст негативного промпта" }, "prompt": { "name": "промпт" }, "prompt_adherence": { "name": "следование_промпту", "tooltip": "Коэффициент управления генерацией" }, "resolution": { "name": "разрешение", "tooltip": "Разрешение выходного видео" }, "seed": { "name": "сид", "tooltip": "Значение случайного сида" }, "steps": { "name": "шаги", "tooltip": "Количество шагов денизинга" } }, "outputs": { "0": { "tooltip": null } } };
const MoonvalleyTxt2VideoNode = { "display_name": "Moonvalley Marey: Текст в видео", "inputs": { "control_after_generate": { "name": "управление после генерации" }, "negative_prompt": { "name": "негативный_промпт", "tooltip": "Текст негативного промпта" }, "prompt": { "name": "промпт" }, "prompt_adherence": { "name": "следование_запросу", "tooltip": "Коэффициент управления генерацией" }, "resolution": { "name": "разрешение", "tooltip": "Разрешение выходного видео" }, "seed": { "name": "сид", "tooltip": "Случайное значение сида" }, "steps": { "name": "шаги", "tooltip": "Шаги вывода" } }, "outputs": { "0": { "tooltip": null } } };
const MoonvalleyVideo2VideoNode = { "display_name": "Moonvalley Marey Video to Video", "inputs": { "control_type": { "name": "тип_управления" }, "motion_intensity": { "name": "интенсивность_движения", "tooltip": "Используется только если тип_управления 'Передача движения'" }, "negative_prompt": { "name": "негативный_запрос", "tooltip": "Текст негативного запроса" }, "prompt": { "name": "запрос", "tooltip": "Описывает видео для генерации" }, "seed": { "name": "сид", "tooltip": "Случайное значение сида" }, "steps": { "name": "шаги", "tooltip": "Количество шагов вывода" }, "video": { "name": "видео", "tooltip": "Эталонное видео, используемое для генерации выходного видео. Должно быть длиной не менее 5 секунд. Видео длиннее 5 секунд будут автоматически обрезаны. Поддерживается только формат MP4." } }, "outputs": { "0": { "tooltip": null } } };
const Morphology = { "display_name": "Морфология изображения", "inputs": { "image": { "name": "изображение" }, "kernel_size": { "name": "размер_ядра" }, "operation": { "name": "операция" } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIChatConfig = { "description": "Позволяет задать расширенные параметры конфигурации для узлов OpenAI Chat.", "display_name": "Расширенные настройки OpenAI ChatGPT", "inputs": { "instructions": { "name": "инструкции", "tooltip": "Инструкции для модели по генерации ответа" }, "max_output_tokens": { "name": "макс_выходные_токены", "tooltip": "Верхняя граница количества токенов, которые могут быть сгенерированы для ответа, включая видимые выходные токены" }, "truncation": { "name": "усечение", "tooltip": "Стратегия усечения для ответа модели. auto: Если контекст этого ответа и предыдущих превышает размер контекстного окна модели, модель усечет ответ, чтобы он поместился в контекстное окно, удаляя элементы ввода в середине разговора. disabled: Если ответ модели превысит размер контекстного окна, запрос завершится ошибкой 400" } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIChatNode = { "description": "Генерация текстовых ответов от модели OpenAI.", "display_name": "OpenAI ChatGPT", "inputs": { "advanced_options": { "name": "расширенные_настройки", "tooltip": "Опциональная конфигурация для модели. Принимает входные данные из узла Расширенные настройки чата OpenAI." }, "files": { "name": "файлы", "tooltip": "Опциональные файлы для использования в качестве контекста для модели. Принимает входные данные из узла Файлы ввода чата OpenAI." }, "images": { "name": "изображения", "tooltip": "Опциональные изображения для использования в качестве контекста для модели. Чтобы включить несколько изображений, вы можете использовать узел Пакетные изображения." }, "model": { "name": "модель", "tooltip": "Модель, используемая для генерации ответа" }, "persist_context": { "name": "сохранять_контекст", "tooltip": "Этот параметр устарел и не оказывает никакого эффекта." }, "prompt": { "name": "запрос", "tooltip": "Текстовые входные данные для модели, используемые для генерации ответа." } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIDalle2 = { "description": "Генерирует изображения синхронно через конечную точку DALL·E 2 от OpenAI.", "display_name": "OpenAI DALL·E 2", "inputs": { "control_after_generate": { "name": "control after generate" }, "image": { "name": "image", "tooltip": "Необязательное референсное изображение для редактирования." }, "mask": { "name": "mask", "tooltip": "Необязательная маска для дорисовки (белые области будут заменены)" }, "n": { "name": "n", "tooltip": "Сколько изображений сгенерировать" }, "prompt": { "name": "prompt", "tooltip": "Текстовый запрос для DALL·E" }, "seed": { "name": "seed", "tooltip": "ещё не реализовано на сервере" }, "size": { "name": "size", "tooltip": "Размер изображения" } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIDalle3 = { "description": "Генерирует изображения синхронно через конечную точку DALL·E 3 от OpenAI.", "display_name": "OpenAI DALL·E 3", "inputs": { "control_after_generate": { "name": "дополнительное управление" }, "prompt": { "name": "prompt", "tooltip": "Текстовый запрос для DALL·E" }, "quality": { "name": "качество", "tooltip": "Качество изображения" }, "seed": { "name": "seed", "tooltip": "ещё не реализовано на сервере" }, "size": { "name": "размер", "tooltip": "Размер изображения" }, "style": { "name": "стиль", "tooltip": "Яркий стиль заставляет модель создавать более гиперреалистичные и драматичные изображения. Натуральный стиль приводит к более естественным, менее гиперреалистичным изображениям." } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIGPTImage1 = { "description": "Генерирует изображения синхронно через конечную точку OpenAI GPT Image 1.", "display_name": "OpenAI GPT Image 1", "inputs": { "background": { "name": "background", "tooltip": "Возвращать изображение с фоном или без него" }, "control_after_generate": { "name": "control after generate" }, "image": { "name": "image", "tooltip": "Необязательное референсное изображение для редактирования." }, "mask": { "name": "mask", "tooltip": "Необязательная маска для дорисовки (белые области будут заменены)" }, "n": { "name": "n", "tooltip": "Сколько изображений сгенерировать" }, "prompt": { "name": "prompt", "tooltip": "Текстовый запрос для GPT Image 1" }, "quality": { "name": "quality", "tooltip": "Качество изображения, влияет на стоимость и время генерации." }, "seed": { "name": "seed", "tooltip": "ещё не реализовано на сервере" }, "size": { "name": "size", "tooltip": "Размер изображения" } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIInputFiles = { "description": "Загружает и подготавливает входные файлы (текст, pdf и т.д.) для включения в качестве входных данных для узла Чат OpenAI. Файлы будут прочитаны моделью OpenAI при генерации ответа. 🛈 СОВЕТ: Может быть объединен в цепочку с другими узлами Входных файлов OpenAI.", "display_name": "Файлы ввода OpenAI ChatGPT", "inputs": { "OPENAI_INPUT_FILES": { "name": "OPENAI_INPUT_FILES", "tooltip": "Опциональный дополнительный файл(ы) для объединения в пакет с файлом, загруженным из этого узла. Позволяет объединять входные файлы в цепочку, чтобы одно сообщение могло включать несколько входных файлов." }, "file": { "name": "файл", "tooltip": "Входные файлы для включения в качестве контекста для модели. Пока принимает только текстовые (.txt) и PDF (.pdf) файлы." } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIVideoSora2 = { "description": "Генерация видео и аудио OpenAI.", "display_name": "OpenAI Sora - Видео", "inputs": { "control_after_generate": { "name": "управление после генерации" }, "duration": { "name": "длительность" }, "image": { "name": "изображение" }, "model": { "name": "модель" }, "prompt": { "name": "промпт", "tooltip": "Направляющий текст; может быть пустым, если присутствует входное изображение." }, "seed": { "name": "сид", "tooltip": "Сид для определения, должен ли узел перезапускаться; фактические результаты недетерминированы независимо от сида." }, "size": { "name": "размер" } }, "outputs": { "0": { "tooltip": null } } };
const OptimalStepsScheduler = { "display_name": "OptimalStepsScheduler", "inputs": { "denoise": { "name": "шумоподавление" }, "model_type": { "name": "model_type" }, "steps": { "name": "шаги" } }, "outputs": { "0": { "tooltip": null } } };
const PairConditioningCombine = { "display_name": "Объединение пар кондиционирования", "inputs": { "negative_A": { "name": "отрицательный_A" }, "negative_B": { "name": "отрицательный_B" }, "positive_A": { "name": "положительный_A" }, "positive_B": { "name": "положительный_B" } }, "outputs": { "0": { "name": "положительный" }, "1": { "name": "отрицательный" } } };
const PairConditioningSetDefaultCombine = { "display_name": "Установить значение по умолчанию для объединения пар кондиционирования", "inputs": { "hooks": { "name": "хуки" }, "negative": { "name": "отрицательный" }, "negative_DEFAULT": { "name": "отрицательный_ПО_УМОЛЧАНИЮ" }, "positive": { "name": "положительный" }, "positive_DEFAULT": { "name": "положительный_ПО_УМОЛЧАНИЮ" } }, "outputs": { "0": { "name": "положительный" }, "1": { "name": "отрицательный" } } };
const PairConditioningSetProperties = { "display_name": "Установить свойства пар кондиционирования", "inputs": { "hooks": { "name": "хуки" }, "mask": { "name": "маска" }, "negative_NEW": { "name": "отрицательный_НОВЫЙ" }, "positive_NEW": { "name": "положительный_НОВЫЙ" }, "set_cond_area": { "name": "установить_область_условия" }, "strength": { "name": "сила" }, "timesteps": { "name": "временные_шаги" } }, "outputs": { "0": { "name": "положительный" }, "1": { "name": "отрицательный" } } };
const PairConditioningSetPropertiesAndCombine = { "display_name": "Установить свойства пар кондиционирования и объединить", "inputs": { "hooks": { "name": "хуки" }, "mask": { "name": "маска" }, "negative": { "name": "отрицательный" }, "negative_NEW": { "name": "отрицательный_НОВЫЙ" }, "positive": { "name": "положительный" }, "positive_NEW": { "name": "положительный_НОВЫЙ" }, "set_cond_area": { "name": "установить_область_условия" }, "strength": { "name": "сила" }, "timesteps": { "name": "временные_шаги" } }, "outputs": { "0": { "name": "положительный" }, "1": { "name": "отрицательный" } } };
const PatchModelAddDownscale = { "display_name": "Добавить уменьшение модели патча (Kohya Deep Shrink)", "inputs": { "block_number": { "name": "номер_блока" }, "downscale_after_skip": { "name": "уменьшение_после_пропуска" }, "downscale_factor": { "name": "коэффициент_уменьшения" }, "downscale_method": { "name": "метод_уменьшения" }, "end_percent": { "name": "конечный_процент" }, "model": { "name": "модель" }, "start_percent": { "name": "начальный_процент" }, "upscale_method": { "name": "метод_увеличения" } }, "outputs": { "0": { "tooltip": null } } };
const PerpNeg = { "display_name": "PerpNeg (УСТАРЕЛО из-за PerpNegGuider)", "inputs": { "empty_conditioning": { "name": "пустое_условие" }, "model": { "name": "модель" }, "neg_scale": { "name": "масштаб_отриц" } }, "outputs": { "0": { "tooltip": null } } };
const PerpNegGuider = { "display_name": "PerpNegGuider", "inputs": { "cfg": { "name": "cfg" }, "empty_conditioning": { "name": "пустое_условие" }, "model": { "name": "модель" }, "neg_scale": { "name": "масштаб_отриц" }, "negative": { "name": "отрицательный" }, "positive": { "name": "положительный" } }, "outputs": { "0": { "tooltip": null } } };
const PerturbedAttentionGuidance = { "display_name": "Направление с учётом возмущений", "inputs": { "model": { "name": "модель" }, "scale": { "name": "масштаб" } }, "outputs": { "0": { "tooltip": null } } };
const PhotoMakerEncode = { "display_name": "Кодирование PhotoMaker", "inputs": { "clip": { "name": "clip" }, "image": { "name": "изображение" }, "photomaker": { "name": "photomaker" }, "text": { "name": "текст" } }, "outputs": { "0": { "tooltip": null } } };
const PhotoMakerLoader = { "display_name": "Загрузчик PhotoMaker", "inputs": { "photomaker_model_name": { "name": "название_модели_photomaker" } }, "outputs": { "0": { "tooltip": null } } };
const PixverseImageToVideoNode = { "description": "Синхронно генерирует видео на основе запроса и размера вывода.", "display_name": "PixVerse: изображение в видео", "inputs": { "control_after_generate": { "name": "контроль после генерации" }, "duration_seconds": { "name": "длительность_секунды" }, "image": { "name": "изображение" }, "motion_mode": { "name": "режим движения" }, "negative_prompt": { "name": "негативный промпт", "tooltip": "Необязательное текстовое описание нежелательных элементов на изображении." }, "pixverse_template": { "name": "pixverse_template", "tooltip": "Необязательный шаблон для влияния на стиль генерации, созданный узлом PixVerse Template." }, "prompt": { "name": "промпт", "tooltip": "Промпт для генерации видео" }, "quality": { "name": "качество" }, "seed": { "name": "seed", "tooltip": "Seed для генерации видео." } }, "outputs": { "0": { "tooltip": null } } };
const PixverseTemplateNode = { "display_name": "Шаблон PixVerse", "inputs": { "template": { "name": "шаблон" } }, "outputs": { "0": { "name": "pixverse_template", "tooltip": null } } };
const PixverseTextToVideoNode = { "description": "Синхронно генерирует видео на основе запроса и размера вывода.", "display_name": "PixVerse: текст в видео", "inputs": { "aspect_ratio": { "name": "aspect_ratio" }, "control_after_generate": { "name": "control after generate" }, "duration_seconds": { "name": "duration_seconds" }, "motion_mode": { "name": "motion_mode" }, "negative_prompt": { "name": "negative_prompt", "tooltip": "Необязательное текстовое описание нежелательных элементов на изображении." }, "pixverse_template": { "name": "pixverse_template", "tooltip": "Необязательный шаблон для влияния на стиль генерации, созданный узлом PixVerse Template." }, "prompt": { "name": "prompt", "tooltip": "Запрос для генерации видео" }, "quality": { "name": "quality" }, "seed": { "name": "seed", "tooltip": "Сид для генерации видео." } }, "outputs": { "0": { "tooltip": null } } };
const PixverseTransitionVideoNode = { "description": "Синхронно генерирует видео на основе запроса и размера вывода.", "display_name": "PixVerse Переходное Видео", "inputs": { "control_after_generate": { "name": "контроль после генерации" }, "duration_seconds": { "name": "длительность (секунды)" }, "first_frame": { "name": "первый кадр" }, "last_frame": { "name": "последний кадр" }, "motion_mode": { "name": "режим движения" }, "negative_prompt": { "name": "негативный промпт", "tooltip": "Необязательное текстовое описание нежелательных элементов на изображении." }, "prompt": { "name": "промпт", "tooltip": "Промпт для генерации видео" }, "quality": { "name": "качество" }, "seed": { "name": "seed", "tooltip": "Seed для генерации видео." } }, "outputs": { "0": { "tooltip": null } } };
const PolyexponentialScheduler = { "display_name": "Полиэкспоненциальный scheduler", "inputs": { "rho": { "name": "ро" }, "sigma_max": { "name": "макс_сигма" }, "sigma_min": { "name": "мин_сигма" }, "steps": { "name": "шаги" } } };
const PorterDuffImageComposite = { "display_name": "Составное изображение Портера-Даффа", "inputs": { "destination": { "name": "назначение" }, "destination_alpha": { "name": "альфа_назначения" }, "mode": { "name": "режим" }, "source": { "name": "источник" }, "source_alpha": { "name": "альфа_источника" } }, "outputs": { "0": { "tooltip": null }, "1": { "tooltip": null } } };
const Preview3D = { "display_name": "Предварительный просмотр 3D", "inputs": { "camera_info": { "name": "информация_камеры" }, "image": { "name": "изображение" }, "model_file": { "name": "файл_модели" } } };
const PreviewAny = { "display_name": "Предпросмотр любого", "inputs": { "preview": {}, "source": { "name": "источник" } } };
const PreviewAudio = { "display_name": "Предварительное прослушивание аудио", "inputs": { "audio": { "name": "аудио" }, "audioUI": { "name": "audioUI" } } };
const PreviewImage = { "description": "Сохраняет входные изображения в вашу директорию вывода ComfyUI.", "display_name": "Предварительный просмотр изображения", "inputs": { "images": { "name": "изображения" } } };
const PrimitiveBoolean = { "display_name": "Булево значение", "inputs": { "value": { "name": "значение" } }, "outputs": { "0": { "tooltip": null } } };
const PrimitiveFloat = { "display_name": "Число с плавающей запятой", "inputs": { "value": { "name": "значение" } }, "outputs": { "0": { "tooltip": null } } };
const PrimitiveInt = { "display_name": "Int", "inputs": { "control_after_generate": { "name": "контроль после генерации" }, "value": { "name": "значение" } }, "outputs": { "0": { "tooltip": null } } };
const PrimitiveString = { "display_name": "Строка", "inputs": { "value": { "name": "значение" } }, "outputs": { "0": { "tooltip": null } } };
const PrimitiveStringMultiline = { "display_name": "Строка (многострочная)", "inputs": { "value": { "name": "значение" } }, "outputs": { "0": { "tooltip": null } } };
const QuadrupleCLIPLoader = { "description": "[Рецепты]\n\nhidream: long clip-l, long clip-g, t5xxl, llama_8b_3.1_instruct", "display_name": "QuadrupleCLIPLoader", "inputs": { "clip_name1": { "name": "clip_name1" }, "clip_name2": { "name": "clip_name2" }, "clip_name3": { "name": "clip_name3" }, "clip_name4": { "name": "clip_name4" } }, "outputs": { "0": { "tooltip": null } } };
const QwenImageDiffsynthControlnet = { "display_name": "QwenImageDiffsynthControlnet", "inputs": { "image": { "name": "изображение" }, "mask": { "name": "маска" }, "model": { "name": "модель" }, "model_patch": { "name": "патч_модели" }, "strength": { "name": "интенсивность" }, "vae": { "name": "vae" } } };
const RandomNoise = { "display_name": "Случайный шум", "inputs": { "control_after_generate": { "name": "контроль_после_генерации" }, "noise_seed": { "name": "сид_шума" } } };
const RebatchImages = { "display_name": "Перепаковать изображения", "inputs": { "batch_size": { "name": "размер_пакета" }, "images": { "name": "изображения" } }, "outputs": { "0": { "tooltip": null } } };
const RebatchLatents = { "display_name": "Перепаковать латенты", "inputs": { "batch_size": { "name": "размер_пакета" }, "latents": { "name": "латенты" } }, "outputs": { "0": { "tooltip": null } } };
const RecordAudio = { "display_name": "Запись аудио", "inputs": { "audio": { "name": "аудио" } } };
const RecraftColorRGB = { "description": "Создайте Recraft Color, выбрав определённые значения RGB.", "display_name": "Recraft Color RGB", "inputs": { "b": { "name": "b", "tooltip": "Значение синего цвета." }, "g": { "name": "g", "tooltip": "Значение зелёного цвета." }, "r": { "name": "r", "tooltip": "Значение красного цвета." }, "recraft_color": { "name": "recraft_color" } }, "outputs": { "0": { "name": "recraft_color", "tooltip": null } } };
const RecraftControls = { "description": "Создайте Recraft Controls для настройки генерации Recraft.", "display_name": "Recraft Controls", "inputs": { "background_color": { "name": "background_color" }, "colors": { "name": "colors" } }, "outputs": { "0": { "name": "recraft_controls", "tooltip": null } } };
const RecraftCreativeUpscaleNode = { "description": "Масштабирует изображение синхронно.\nУлучшает заданное растровое изображение с помощью инструмента «creative upscale», повышая разрешение с акцентом на детализацию мелких элементов и лиц.", "display_name": "Recraft Creative Upscale Image", "inputs": { "image": { "name": "изображение" } }, "outputs": { "0": { "tooltip": null } } };
const RecraftCrispUpscaleNode = { "description": "Увеличивает изображение синхронно.\nУлучшает заданное растровое изображение с помощью инструмента «четкое увеличение», повышая разрешение, делая изображение более резким и чистым.", "display_name": "Recraft Четкое Увеличение Изображения", "inputs": { "image": { "name": "изображение" } }, "outputs": { "0": { "tooltip": null } } };
const RecraftImageInpaintingNode = { "description": "Изменить изображение на основе запроса и маски.", "display_name": "Восстановление изображения Recraft", "inputs": { "control_after_generate": { "name": "контроль после генерации" }, "image": { "name": "изображение" }, "mask": { "name": "mask" }, "n": { "name": "n", "tooltip": "Количество изображений для генерации." }, "negative_prompt": { "name": "негативный запрос", "tooltip": "Необязательное текстовое описание нежелательных элементов на изображении." }, "prompt": { "name": "запрос", "tooltip": "Запрос для генерации изображения." }, "recraft_style": { "name": "recraft_style" }, "seed": { "name": "seed", "tooltip": "Сид для определения необходимости повторного запуска узла; фактические результаты недетерминированы независимо от сида." } }, "outputs": { "0": { "tooltip": null } } };
const RecraftImageToImageNode = { "description": "Изменить изображение на основе запроса и степени изменения.", "display_name": "Recraft: Изображение в изображение", "inputs": { "control_after_generate": { "name": "управление после генерации" }, "image": { "name": "изображение" }, "n": { "name": "n", "tooltip": "Количество изображений для генерации." }, "negative_prompt": { "name": "негативный запрос", "tooltip": "Необязательное текстовое описание нежелательных элементов на изображении." }, "prompt": { "name": "запрос", "tooltip": "Запрос для генерации изображения." }, "recraft_controls": { "name": "recraft_controls", "tooltip": "Необязательные дополнительные параметры управления генерацией через узел Recraft Controls." }, "recraft_style": { "name": "recraft_style" }, "seed": { "name": "seed", "tooltip": "Seed для определения необходимости повторного запуска узла; фактические результаты недетерминированы независимо от seed." }, "strength": { "name": "степень изменения", "tooltip": "Определяет различие с оригинальным изображением, должно быть в диапазоне [0, 1], где 0 — почти идентично, а 1 — минимальное сходство." } }, "outputs": { "0": { "tooltip": null } } };
const RecraftRemoveBackgroundNode = { "description": "Удаляет фон с изображения и возвращает обработанное изображение и маску.", "display_name": "Recraft Remove Background", "inputs": { "image": { "name": "изображение" } }, "outputs": { "0": { "tooltip": null }, "1": { "tooltip": null } } };
const RecraftReplaceBackgroundNode = { "description": "Заменить фон на изображении на основе заданного промпта.", "display_name": "Recraft Замена Фона", "inputs": { "control_after_generate": { "name": "контроль после генерации" }, "image": { "name": "изображение" }, "n": { "name": "n", "tooltip": "Количество изображений для генерации." }, "negative_prompt": { "name": "негативный_промпт", "tooltip": "Необязательное текстовое описание нежелательных элементов на изображении." }, "prompt": { "name": "промпт", "tooltip": "Промпт для генерации изображения." }, "recraft_style": { "name": "recraft_style" }, "seed": { "name": "seed", "tooltip": "Сид для определения необходимости повторного запуска узла; фактические результаты недетерминированы независимо от сида." } }, "outputs": { "0": { "tooltip": null } } };
const RecraftStyleV3DigitalIllustration = { "description": "Выберите стиль realistic_image и необязательный подстиль.", "display_name": "Recraft Стиль - Цифровая иллюстрация", "inputs": { "substyle": { "name": "подстиль" } }, "outputs": { "0": { "name": "recraft_style", "tooltip": null } } };
const RecraftStyleV3InfiniteStyleLibrary = { "description": "Выберите стиль на основе существующего UUID из Infinite Style Library Recraft.", "display_name": "Recraft Style - Infinite Style Library", "inputs": { "style_id": { "name": "style_id", "tooltip": "UUID стиля из Infinite Style Library." } }, "outputs": { "0": { "name": "recraft_style", "tooltip": null } } };
const RecraftStyleV3LogoRaster = { "description": "Выберите стиль realistic_image и дополнительный подстиль (опционально).", "display_name": "Recraft Style - Логотип Растр", "inputs": { "substyle": { "name": "подстиль" } }, "outputs": { "0": { "name": "recraft_style", "tooltip": null } } };
const RecraftStyleV3RealisticImage = { "description": "Выберите стиль realistic_image и необязательный подстиль.", "display_name": "Recraft Style - Реалистичное изображение", "inputs": { "substyle": { "name": "подстиль" } }, "outputs": { "0": { "name": "recraft_style", "tooltip": null } } };
const RecraftTextToImageNode = { "description": "Синхронно генерирует изображения на основе запроса и разрешения.", "display_name": "Recraft: текст в изображение", "inputs": { "control_after_generate": { "name": "control after generate" }, "n": { "name": "n", "tooltip": "Количество изображений для генерации." }, "negative_prompt": { "name": "negative_prompt", "tooltip": "Необязательное текстовое описание нежелательных элементов на изображении." }, "prompt": { "name": "prompt", "tooltip": "Запрос для генерации изображения." }, "recraft_controls": { "name": "recraft_controls", "tooltip": "Необязательные дополнительные параметры управления генерацией через узел Recraft Controls." }, "recraft_style": { "name": "recraft_style" }, "seed": { "name": "seed", "tooltip": "Сид для определения необходимости повторного запуска узла; фактические результаты не являются детерминированными независимо от сида." }, "size": { "name": "size", "tooltip": "Размер сгенерированного изображения." } }, "outputs": { "0": { "tooltip": null } } };
const RecraftTextToVectorNode = { "description": "Синхронно генерирует SVG на основе запроса и разрешения.", "display_name": "Recraft: Текст в вектор", "inputs": { "control_after_generate": { "name": "control after generate" }, "n": { "name": "n", "tooltip": "Количество изображений для генерации." }, "negative_prompt": { "name": "negative_prompt", "tooltip": "Необязательное текстовое описание нежелательных элементов на изображении." }, "prompt": { "name": "prompt", "tooltip": "Запрос для генерации изображения." }, "recraft_controls": { "name": "recraft_controls", "tooltip": "Необязательные дополнительные параметры управления генерацией через узел Recraft Controls." }, "seed": { "name": "seed", "tooltip": "Сид для определения необходимости повторного запуска узла; фактические результаты не являются детерминированными независимо от сида." }, "size": { "name": "size", "tooltip": "Размер сгенерированного изображения." }, "substyle": { "name": "substyle" } }, "outputs": { "0": { "tooltip": null } } };
const RecraftVectorizeImageNode = { "description": "Генерирует SVG синхронно из входного изображения.", "display_name": "Recraft Векторизация Изображения", "inputs": { "image": { "name": "изображение" } }, "outputs": { "0": { "tooltip": null } } };
const ReferenceLatent = { "description": "Этот узел устанавливает направляющий латент для модели редактирования. Если модель поддерживает это, вы можете объединить несколько узлов для установки нескольких эталонных изображений.", "display_name": "Эталонный латент", "inputs": { "conditioning": { "name": "кондиционирование" }, "latent": { "name": "латент" } }, "outputs": { "0": { "tooltip": null } } };
const RegexExtract = { "display_name": "Извлечение по регулярному выражению", "inputs": { "case_insensitive": { "name": "без_учета_регистра" }, "dotall": { "name": "dotall" }, "group_index": { "name": "индекс_группы" }, "mode": { "name": "режим" }, "multiline": { "name": "многострочный" }, "regex_pattern": { "name": "регулярное_выражение" }, "string": { "name": "строка" } }, "outputs": { "0": { "tooltip": null } } };
const RegexMatch = { "display_name": "Совпадение по регулярному выражению", "inputs": { "case_insensitive": { "name": "без_учета_регистра" }, "dotall": { "name": "dotall" }, "multiline": { "name": "многострочный" }, "regex_pattern": { "name": "регулярное_выражение" }, "string": { "name": "строка" } }, "outputs": { "0": { "name": "совпадения", "tooltip": null } } };
const RegexReplace = { "description": "Поиск и замена текста с использованием регулярных выражений.", "display_name": "Замена по регулярному выражению", "inputs": { "case_insensitive": { "name": "без_учета_регистра" }, "count": { "name": "количество", "tooltip": "Максимальное количество замен для выполнения. Установите 0 для замены всех вхождений (по умолчанию). Установите 1 для замены только первого совпадения, 2 для первых двух совпадений и т.д." }, "dotall": { "name": "dotall", "tooltip": "Если включено, символ точки (.) будет соответствовать любому символу, включая символы новой строки. Если отключено, точки не будут соответствовать символам новой строки." }, "multiline": { "name": "многострочный" }, "regex_pattern": { "name": "регулярное_выражение" }, "replace": { "name": "замена" }, "string": { "name": "строка" } }, "outputs": { "0": { "tooltip": null } } };
const RenormCFG = { "display_name": "RenormCFG", "inputs": { "cfg_trunc": { "name": "cfg_trunc" }, "model": { "name": "модель" }, "renorm_cfg": { "name": "renorm_cfg" } }, "outputs": { "0": { "tooltip": null } } };
const RepeatImageBatch = { "display_name": "Повторить партию изображений", "inputs": { "amount": { "name": "количество" }, "image": { "name": "изображение" } } };
const RepeatLatentBatch = { "display_name": "Повторить партию латентов", "inputs": { "amount": { "name": "количество" }, "samples": { "name": "образцы" } } };
const RescaleCFG = { "display_name": "Масштабировать CFG", "inputs": { "model": { "name": "модель" }, "multiplier": { "name": "множитель" } } };
const ResizeAndPadImage = { "display_name": "Изменение размера и заполнение изображения", "inputs": { "image": { "name": "изображение" }, "interpolation": { "name": "интерполяция" }, "padding_color": { "name": "цвет_заполнения" }, "target_height": { "name": "целевая_высота" }, "target_width": { "name": "целевая_ширина" } } };
const Rodin3D_Detail = { "description": "Создание 3D-объектов с помощью Rodin API", "display_name": "Rodin 3D Generate - Детальная генерация", "inputs": { "Images": { "name": "Изображения" }, "Material_Type": { "name": "Тип_материала" }, "Polygon_count": { "name": "Количество_полигонов" }, "Seed": { "name": "Сид" } }, "outputs": { "0": { "name": "Путь к 3D-модели", "tooltip": null } } };
const Rodin3D_Gen2 = { "description": "Создание 3D-объектов с помощью Rodin API", "display_name": "Rodin 3D Generate - Gen-2 генерация", "inputs": { "Images": { "name": "Изображения" }, "Material_Type": { "name": "Тип_материала" }, "Polygon_count": { "name": "Количество_полигонов" }, "Seed": { "name": "Сид" }, "TAPose": { "name": "TAPose" } }, "outputs": { "0": { "name": "Путь к 3D-модели", "tooltip": null } } };
const Rodin3D_Regular = { "description": "Создание 3D-объектов с помощью Rodin API", "display_name": "Rodin 3D Generate - Обычная генерация", "inputs": { "Images": { "name": "Изображения" }, "Material_Type": { "name": "Тип_материала" }, "Polygon_count": { "name": "Количество_полигонов" }, "Seed": { "name": "Сид" } }, "outputs": { "0": { "name": "Путь к 3D-модели", "tooltip": null } } };
const Rodin3D_Sketch = { "description": "Создание 3D-объектов с помощью Rodin API", "display_name": "Rodin 3D Generate - Эскизная генерация", "inputs": { "Images": { "name": "Изображения" }, "Seed": { "name": "Сид" } }, "outputs": { "0": { "name": "Путь к 3D-модели", "tooltip": null } } };
const Rodin3D_Smooth = { "description": "Создание 3D-объектов с помощью Rodin API", "display_name": "Rodin 3D Generate - Сглаженная генерация", "inputs": { "Images": { "name": "Изображения" }, "Material_Type": { "name": "Тип_материала" }, "Polygon_count": { "name": "Количество_полигонов" }, "Seed": { "name": "Сид" } }, "outputs": { "0": { "name": "Путь к 3D-модели", "tooltip": null } } };
const RunwayFirstLastFrameNode = { "description": "Загрузите первый и последний ключевые кадры, составьте промпт и создайте видео. Более сложные переходы, например, когда последний кадр полностью отличается от первого, могут выиграть от более длительной продолжительности в 10 секунд. Это даст генерации больше времени для плавного перехода между двумя входными данными. Прежде чем начать, ознакомьтесь с лучшими практиками, чтобы убедиться, что ваши входные данные обеспечат успешный результат: https://help.runwayml.com/hc/en-us/articles/34170748696595-Creating-with-Keyframes-on-Gen-3.", "display_name": "Runway: Первый-Последний кадр в видео", "inputs": { "control_after_generate": { "name": "управление после генерации" }, "duration": { "name": "продолжительность" }, "end_frame": { "name": "конечный_кадр", "tooltip": "Конечный кадр для использования в видео. Поддерживается только для gen3a_turbo." }, "prompt": { "name": "промпт", "tooltip": "Текстовый промпт для генерации" }, "ratio": { "name": "соотношение" }, "seed": { "name": "сид", "tooltip": "Случайное начальное значение для генерации" }, "start_frame": { "name": "начальный_кадр", "tooltip": "Начальный кадр для использования в видео" } }, "outputs": { "0": { "tooltip": null } } };
const RunwayImageToVideoNodeGen3a = { "description": "Создайте видео из одного начального кадра с использованием модели Gen3a Turbo. Прежде чем начать, ознакомьтесь с лучшими практиками, чтобы убедиться, что ваши входные данные обеспечат успешный результат: https://help.runwayml.com/hc/en-us/articles/33927968552339-Creating-with-Act-One-on-Gen-3-Alpha-and-Turbo.", "display_name": "Runway: Изображение в видео (Gen3a Turbo)", "inputs": { "control_after_generate": { "name": "управление после генерации" }, "duration": { "name": "продолжительность" }, "prompt": { "name": "промпт", "tooltip": "Текстовый промпт для генерации" }, "ratio": { "name": "соотношение" }, "seed": { "name": "сид", "tooltip": "Случайное начальное значение для генерации" }, "start_frame": { "name": "начальный_кадр", "tooltip": "Начальный кадр для использования в видео" } }, "outputs": { "0": { "tooltip": null } } };
const RunwayImageToVideoNodeGen4 = { "description": "Создайте видео из одного начального кадра с использованием модели Gen4 Turbo. Прежде чем начать, ознакомьтесь с лучшими практиками, чтобы убедиться, что ваши входные данные обеспечат успешный результат: https://help.runwayml.com/hc/en-us/articles/37327109429011-Creating-with-Gen-4-Video.", "display_name": "Runway: Изображение в видео (Gen4 Turbo)", "inputs": { "control_after_generate": { "name": "управление после генерации" }, "duration": { "name": "продолжительность" }, "prompt": { "name": "промпт", "tooltip": "Текстовый промпт для генерации" }, "ratio": { "name": "соотношение" }, "seed": { "name": "сид", "tooltip": "Случайное начальное значение для генерации" }, "start_frame": { "name": "начальный_кадр", "tooltip": "Начальный кадр для использования в видео" } }, "outputs": { "0": { "tooltip": null } } };
const RunwayTextToImageNode = { "description": "Создайте изображение из текстового запроса с использованием модели Gen 4 от Runway. Вы также можете включить эталонное изображение для направления генерации.", "display_name": "Runway Текст в изображение", "inputs": { "prompt": { "name": "запрос", "tooltip": "Текстовый запрос для генерации" }, "ratio": { "name": "соотношение" }, "reference_image": { "name": "эталонное_изображение", "tooltip": "Опциональное эталонное изображение для направления генерации" } }, "outputs": { "0": { "tooltip": null } } };
const SDTurboScheduler = { "display_name": "Scheduler SDTurbo", "inputs": { "denoise": { "name": "шумоподавление" }, "model": { "name": "модель" }, "steps": { "name": "шаги" } } };
const SD_4XUpscale_Conditioning = { "display_name": "SD_4XUpscale_Conditioning", "inputs": { "images": { "name": "изображения" }, "negative": { "name": "отрицательный" }, "noise_augmentation": { "name": "шумовое_увеличение" }, "positive": { "name": "положительный" }, "scale_ratio": { "name": "коэффициент_масштабирования" } }, "outputs": { "0": { "name": "положительный", "tooltip": null }, "1": { "name": "отрицательный", "tooltip": null }, "2": { "name": "латентный", "tooltip": null } } };
const SV3D_Conditioning = { "display_name": "SV3D_Кондиционирование", "inputs": { "clip_vision": { "name": "clip_vision" }, "elevation": { "name": "высота" }, "height": { "name": "высота" }, "init_image": { "name": "начальное_изображение" }, "vae": { "name": "vae" }, "video_frames": { "name": "кадры_видео" }, "width": { "name": "ширина" } }, "outputs": { "0": { "name": "положительный", "tooltip": null }, "1": { "name": "отрицательный", "tooltip": null }, "2": { "name": "латентный", "tooltip": null } } };
const SVD_img2vid_Conditioning = { "display_name": "SVD_img2vid_Кондиционирование", "inputs": { "augmentation_level": { "name": "уровень_аугментации" }, "clip_vision": { "name": "clip_vision" }, "fps": { "name": "fps" }, "height": { "name": "высота" }, "init_image": { "name": "init_image" }, "motion_bucket_id": { "name": "id_корзины_движения" }, "vae": { "name": "vae" }, "video_frames": { "name": "кадры_видео" }, "width": { "name": "ширина" } }, "outputs": { "0": { "name": "положительный" }, "1": { "name": "отрицательный" }, "2": { "name": "латентный" } } };
const SamplerCustom = { "display_name": "Пользовательский выборщик", "inputs": { "add_noise": { "name": "добавить_шум" }, "cfg": { "name": "cfg" }, "control_after_generate": { "name": "контроль после генерации" }, "latent_image": { "name": "латентное_изображение" }, "model": { "name": "модель" }, "negative": { "name": "отрицательный" }, "noise_seed": { "name": "сид_шума" }, "positive": { "name": "положительный" }, "sampler": { "name": "сэмплер" }, "sigmas": { "name": "сигмы" } }, "outputs": { "0": { "name": "выход" }, "1": { "name": "очищенный_выход" } } };
const SamplerCustomAdvanced = { "display_name": "Пользовательский сэмплер (Расширенный)", "inputs": { "guider": { "name": "гид" }, "latent_image": { "name": "латентное_изображение" }, "noise": { "name": "шум" }, "sampler": { "name": "сэмплер" }, "sigmas": { "name": "сигмы" } }, "outputs": { "0": { "name": "выход" }, "1": { "name": "очищенный_выход" } } };
const SamplerDPMAdaptative = { "display_name": "Адаптивный сэмплер DPM", "inputs": { "accept_safety": { "name": "accept_safety" }, "atol": { "name": "atol" }, "dcoeff": { "name": "dcoeff" }, "eta": { "name": "eta" }, "h_init": { "name": "h_init" }, "icoeff": { "name": "icoeff" }, "order": { "name": "порядок" }, "pcoeff": { "name": "pcoeff" }, "rtol": { "name": "rtol" }, "s_noise": { "name": "s_noise" } } };
const SamplerDPMPP_2M_SDE = { "display_name": "Сэмплер DPMPP_2M_SDE", "inputs": { "eta": { "name": "eta" }, "noise_device": { "name": "устройство_шума" }, "s_noise": { "name": "s_noise" }, "solver_type": { "name": "тип_решателя" } } };
const SamplerDPMPP_2S_Ancestral = { "display_name": "Сэмплер DPMPP_2S_Ancestral", "inputs": { "eta": { "name": "eta" }, "s_noise": { "name": "s_noise" } } };
const SamplerDPMPP_3M_SDE = { "display_name": "Сэмплер DPMPP_3M_SDE", "inputs": { "eta": { "name": "eta" }, "noise_device": { "name": "устройство_шума" }, "s_noise": { "name": "s_noise" } } };
const SamplerDPMPP_SDE = { "display_name": "Сэмплер DPMPP_SDE", "inputs": { "eta": { "name": "eta" }, "noise_device": { "name": "устройство_шума" }, "r": { "name": "r" }, "s_noise": { "name": "s_noise" } } };
const SamplerER_SDE = { "display_name": "SamplerER_SDE", "inputs": { "eta": { "name": "эта", "tooltip": "Стохастическая сила обратно-временного СДУ.\nКогда eta=0, сводится к детерминированному ОДУ. Эта настройка не применяется к типу решателя ER-SDE." }, "max_stage": { "name": "макс_этап" }, "s_noise": { "name": "s_шум" }, "solver_type": { "name": "тип_решателя" } } };
const SamplerEulerAncestral = { "display_name": "Сэмплер Эйлера (Анастр.)", "inputs": { "eta": { "name": "eta" }, "s_noise": { "name": "s_noise" } } };
const SamplerEulerAncestralCFGPP = { "display_name": "Сэмплер Эйлера (Анастр.) CFG++", "inputs": { "eta": { "name": "eta" }, "s_noise": { "name": "s_noise" } } };
const SamplerEulerCFGpp = { "display_name": "Сэмплер Эйлера CFG++", "inputs": { "version": { "name": "версия" } }, "outputs": { "0": { "tooltip": null } } };
const SamplerLCMUpscale = { "display_name": "Сэмплер LCM Upscale", "inputs": { "scale_ratio": { "name": "коэффициент_масштабирования" }, "scale_steps": { "name": "шаги_масштабирования" }, "upscale_method": { "name": "метод_масштабирования" } }, "outputs": { "0": { "tooltip": null } } };
const SamplerLMS = { "display_name": "Сэмплер LMS", "inputs": { "order": { "name": "порядок" } } };
const SamplerSASolver = { "display_name": "SamplerSASolver", "inputs": { "corrector_order": { "name": "порядок_корректора" }, "eta": { "name": "эта" }, "model": { "name": "модель" }, "predictor_order": { "name": "порядок_предиктора" }, "s_noise": { "name": "s_шум" }, "sde_end_percent": { "name": "процент_окончания_sde" }, "sde_start_percent": { "name": "процент_начала_sde" }, "simple_order_2": { "name": "простой_порядок_2" }, "use_pece": { "name": "использовать_pece" } } };
const SamplingPercentToSigma = { "display_name": "SamplingPercentToSigma", "inputs": { "model": { "name": "модель" }, "return_actual_sigma": { "name": "возвращать_фактическую_сигму", "tooltip": "Возвращать фактическое значение сигмы вместо значения, используемого для проверки интервалов.\nЭто влияет только на результаты при 0.0 и 1.0." }, "sampling_percent": { "name": "процент_дискретизации" } }, "outputs": { "0": { "name": "значение_сигмы" } } };
const SaveAnimatedPNG = { "display_name": "Сохранить анимированный PNG", "inputs": { "compress_level": { "name": "уровень_сжатия" }, "filename_prefix": { "name": "префикс_названия_файла" }, "fps": { "name": "fps" }, "images": { "name": "изображения" } } };
const SaveAnimatedWEBP = { "display_name": "Сохранить анимированный WEBP", "inputs": { "filename_prefix": { "name": "префикс_названия_файла" }, "fps": { "name": "fps" }, "images": { "name": "изображения" }, "lossless": { "name": "без_потерь" }, "method": { "name": "метод" }, "quality": { "name": "качество" } } };
const SaveAudio = { "display_name": "Сохранить аудио", "inputs": { "audio": { "name": "аудио" }, "audioUI": { "name": "audioUI" }, "filename_prefix": { "name": "префикс_названия_файла" } } };
const SaveAudioMP3 = { "display_name": "Сохранить аудио (MP3)", "inputs": { "audio": { "name": "аудио" }, "audioUI": { "name": "audioUI" }, "filename_prefix": { "name": "префикс_имени_файла" }, "quality": { "name": "качество" } } };
const SaveAudioOpus = { "display_name": "Сохранить аудио (Opus)", "inputs": { "audio": { "name": "audio" }, "audioUI": { "name": "audioUI" }, "filename_prefix": { "name": "префикс_имени_файла" }, "quality": { "name": "качество" } } };
const SaveGLB = { "display_name": "SaveGLB", "inputs": { "filename_prefix": { "name": "префикс_имени_файла" }, "image": { "name": "изображение" }, "mesh": { "name": "сетка" } } };
const SaveImage = { "description": "Сохраняет входные изображения в вашу директорию вывода ComfyUI.", "display_name": "Сохранить изображение", "inputs": { "filename_prefix": { "name": "префикс_названия_файла", "tooltip": "Префикс для файла, который нужно сохранить. Это может включать информацию о форматировании, такую как %date:yyyy-MM-dd% или %Empty Latent Image.width%, чтобы включить значения из нод." }, "images": { "name": "изображения", "tooltip": "Изображения_для_сохранения." } } };
const SaveImageWebsocket = { "display_name": "Сохранить изображение через веб-сокет", "inputs": { "images": { "name": "изображения" } } };
const SaveLatent = { "display_name": "Сохранить латент", "inputs": { "filename_prefix": { "name": "префикс_названия_файла" }, "samples": { "name": "образцы" } } };
const SaveSVGNode = { "description": "Сохранить SVG файлы на диске.", "display_name": "SaveSVGNode", "inputs": { "filename_prefix": { "name": "префикс_имени_файла", "tooltip": "Префикс для сохраняемого файла. Может включать информацию о форматировании, такую как %date:yyyy-MM-dd% или %Empty Latent Image.width% для включения значений из узлов." }, "svg": { "name": "svg" } } };
const SaveVideo = { "description": "Сохраняет входные изображения в вашу папку вывода ComfyUI.", "display_name": "Сохранить видео", "inputs": { "codec": { "name": "кодек", "tooltip": "Кодек для видео." }, "filename_prefix": { "name": "префикс_имени_файла", "tooltip": "Префикс для сохраняемого файла. Может включать информацию о форматировании, такую как %date:yyyy-MM-dd% или %Empty Latent Image.width% для включения значений из узлов." }, "format": { "name": "формат", "tooltip": "Формат, в котором сохранить видео." }, "video": { "name": "видео", "tooltip": "Видео для сохранения." } } };
const SaveWEBM = { "display_name": "SaveWEBM", "inputs": { "codec": { "name": "кодек" }, "crf": { "name": "crf", "tooltip": "Большее значение crf означает нижнее качество с меньшим размером файла, меньшее значение crf означает высшее качество большего размера файла." }, "filename_prefix": { "name": "префикс_имени_файла" }, "fps": { "name": "fps" }, "images": { "name": "изображения" } } };
const ScaleROPE = { "description": "Масштабировать и сдвинуть ROPE модели.", "display_name": "ScaleROPE", "inputs": { "model": { "name": "model" }, "scale_t": { "name": "масштаб_t" }, "scale_x": { "name": "масштаб_x" }, "scale_y": { "name": "масштаб_y" }, "shift_t": { "name": "сдвиг_t" }, "shift_x": { "name": "сдвиг_x" }, "shift_y": { "name": "сдвиг_y" } }, "outputs": { "0": { "tooltip": null } } };
const SelfAttentionGuidance = { "display_name": "Направление самовнимания", "inputs": { "blur_sigma": { "name": "сигма_размытия" }, "model": { "name": "модель" }, "scale": { "name": "масштаб" } }, "outputs": { "0": { "tooltip": null } } };
const SetClipHooks = { "display_name": "Установить хуки CLIP", "inputs": { "apply_to_conds": { "name": "применить_к_условиям" }, "clip": { "name": "клип" }, "hooks": { "name": "хуки" }, "schedule_clip": { "name": "schedule_clip" } } };
const SetFirstSigma = { "display_name": "SetFirstSigma", "inputs": { "sigma": { "name": "сигма" }, "sigmas": { "name": "сигмы" } } };
const SetHookKeyframes = { "display_name": "Установить ключевые кадры хука", "inputs": { "hook_kf": { "name": "ключевые_кадры_хука" }, "hooks": { "name": "хуки" } } };
const SetLatentNoiseMask = { "display_name": "Установить маску шума латента", "inputs": { "mask": { "name": "маска" }, "samples": { "name": "образцы" } } };
const SetUnionControlNetType = { "display_name": "Установить тип объединенного ControlNet", "inputs": { "control_net": { "name": "control_net" }, "type": { "name": "тип" } }, "outputs": { "0": { "tooltip": null } } };
const SkipLayerGuidanceDiT = { "description": "Универсальная версия ноды SkipLayerGuidance, которую можно использовать на любой модели DiT.", "display_name": "Пропустить руководство по слоям DiT", "inputs": { "double_layers": { "name": "двойные_слои" }, "end_percent": { "name": "конечный_процент" }, "model": { "name": "модель" }, "rescaling_scale": { "name": "масштаб_перемасштабирования" }, "scale": { "name": "масштаб" }, "single_layers": { "name": "одиночные_слои" }, "start_percent": { "name": "начальный_процент" } }, "outputs": { "0": { "tooltip": null } } };
const SkipLayerGuidanceDiTSimple = { "description": "Упрощенная версия узла SkipLayerGuidanceDiT, которая изменяет только проход без условий.", "display_name": "SkipLayerGuidanceDiTSimple", "inputs": { "double_layers": { "name": "двойные_слои" }, "end_percent": { "name": "конечный_процент" }, "model": { "name": "model" }, "single_layers": { "name": "одиночные_слои" }, "start_percent": { "name": "начальный_процент" } }, "outputs": { "0": { "tooltip": null } } };
const SkipLayerGuidanceSD3 = { "description": "Универсальная версия ноды SkipLayerGuidance, которую можно использовать на любой модели DiT.", "display_name": "Пропустить руководство по слоям SD3", "inputs": { "end_percent": { "name": "конечный_процент" }, "layers": { "name": "слои" }, "model": { "name": "модель" }, "scale": { "name": "масштаб" }, "start_percent": { "name": "начальный_процент" } }, "outputs": { "0": { "tooltip": null } } };
const SolidMask = { "display_name": "Сплошная маска", "inputs": { "height": { "name": "высота" }, "value": { "name": "значение" }, "width": { "name": "ширина" } } };
const SplitAudioChannels = { "description": "Разделяет аудио на левый и правый каналы.", "display_name": "Разделить аудиоканалы", "inputs": { "audio": { "name": "аудио" } }, "outputs": { "0": { "name": "левый" }, "1": { "name": "правый" } } };
const SplitImageWithAlpha = { "display_name": "Разделить изображение с альфа-каналом", "inputs": { "image": { "name": "изображение" } }, "outputs": { "0": { "tooltip": null }, "1": { "tooltip": null } } };
const SplitSigmas = { "display_name": "Разделить сигмы", "inputs": { "sigmas": { "name": "сигмы" }, "step": { "name": "шаг" } }, "outputs": { "0": { "name": "высокие_сигмы" }, "1": { "name": "низкие_сигмы" } } };
const SplitSigmasDenoise = { "display_name": "Разделить сигмы для удаления шума", "inputs": { "denoise": { "name": "шумоподавление" }, "sigmas": { "name": "сигмы" } }, "outputs": { "0": { "name": "высокие_сигмы" }, "1": { "name": "низкие_сигмы" } } };
const StabilityAudioInpaint = { "description": "Преобразует часть существующего аудиосэмпла с использованием текстовых инструкций.", "display_name": "Stability AI Audio Inpaint", "inputs": { "audio": { "name": "аудио", "tooltip": "Длительность аудио должна быть от 6 до 190 секунд." }, "control_after_generate": { "name": "управление после генерации" }, "duration": { "name": "длительность", "tooltip": "Определяет длительность генерируемого аудио в секундах." }, "mask_end": { "name": "конец_маски" }, "mask_start": { "name": "начало_маски" }, "model": { "name": "модель" }, "prompt": { "name": "промпт" }, "seed": { "name": "сид", "tooltip": "Случайное начальное значение, используемое для генерации." }, "steps": { "name": "шаги", "tooltip": "Определяет количество шагов сэмплирования." } }, "outputs": { "0": { "tooltip": null } } };
const StabilityAudioToAudio = { "description": "Преобразует существующие аудиосэмплы в новые высококачественные композиции с использованием текстовых инструкций.", "display_name": "Stability AI Audio To Audio", "inputs": { "audio": { "name": "аудио", "tooltip": "Длительность аудио должна быть от 6 до 190 секунд." }, "control_after_generate": { "name": "управление после генерации" }, "duration": { "name": "длительность", "tooltip": "Определяет длительность генерируемого аудио в секундах." }, "model": { "name": "модель" }, "prompt": { "name": "промпт" }, "seed": { "name": "сид", "tooltip": "Случайное начальное значение, используемое для генерации." }, "steps": { "name": "шаги", "tooltip": "Определяет количество шагов сэмплирования." }, "strength": { "name": "интенсивность", "tooltip": "Параметр определяет степень влияния аудиопараметра на генерируемое аудио." } }, "outputs": { "0": { "tooltip": null } } };
const StabilityStableImageSD_3_5Node = { "description": "Генерирует изображения синхронно на основе запроса и разрешения.", "display_name": "Stability AI Stable Diffusion 3.5 Image", "inputs": { "aspect_ratio": { "name": "aspect_ratio", "tooltip": "Соотношение сторон сгенерированного изображения." }, "cfg_scale": { "name": "cfg_scale", "tooltip": "Насколько строго процесс диффузии следует тексту запроса (более высокие значения делают изображение ближе к вашему запросу)" }, "control_after_generate": { "name": "control after generate" }, "image": { "name": "image" }, "image_denoise": { "name": "image_denoise", "tooltip": "Уровень удаления шума исходного изображения; 0.0 — изображение идентично входному, 1.0 — как если бы изображение не было предоставлено вовсе." }, "model": { "name": "model" }, "negative_prompt": { "name": "negative_prompt", "tooltip": "Ключевые слова того, что вы не хотите видеть на выходном изображении. Это расширенная функция." }, "prompt": { "name": "prompt", "tooltip": "Что вы хотите увидеть на выходном изображении. Сильный, описательный запрос, который чётко определяет элементы, цвета и объекты, приведёт к лучшим результатам." }, "seed": { "name": "seed", "tooltip": "Случайное зерно, используемое для создания шума." }, "style_preset": { "name": "style_preset", "tooltip": "Необязательный желаемый стиль сгенерированного изображения." } }, "outputs": { "0": { "tooltip": null } } };
const StabilityStableImageUltraNode = { "description": "Генерирует изображения синхронно на основе запроса и разрешения.", "display_name": "Stability AI Stable Image Ultra", "inputs": { "aspect_ratio": { "name": "aspect_ratio", "tooltip": "Соотношение сторон генерируемого изображения." }, "control_after_generate": { "name": "control after generate" }, "image": { "name": "image" }, "image_denoise": { "name": "image_denoise", "tooltip": "Уровень удаления шума с входного изображения; 0.0 даст изображение, идентичное входному, 1.0 — как если бы изображение не было предоставлено вовсе." }, "negative_prompt": { "name": "negative_prompt", "tooltip": "Текст, описывающий, что вы НЕ хотите видеть на выходном изображении. Это расширенная функция." }, "prompt": { "name": "prompt", "tooltip": "Что вы хотите увидеть на выходном изображении. Сильный, описательный запрос, который чётко определяет элементы, цвета и объекты, приведёт к лучшим результатам. Чтобы управлять весом определённого слова, используйте формат `(word:weight)`, где `word` — это слово, вес которого вы хотите изменить, а `weight` — значение от 0 до 1. Например: `The sky was a crisp (blue:0.3) and (green:0.8)` будет означать, что небо было синим и зелёным, но больше зелёным, чем синим." }, "seed": { "name": "seed", "tooltip": "Случайное зерно, используемое для создания шума." }, "style_preset": { "name": "style_preset", "tooltip": "Необязательный желаемый стиль генерируемого изображения." } }, "outputs": { "0": { "tooltip": null } } };
const StabilityTextToAudio = { "description": "Генерирует высококачественную музыку и звуковые эффекты по текстовым описаниям.", "display_name": "Stability AI Text To Audio", "inputs": { "control_after_generate": { "name": "управление после генерации" }, "duration": { "name": "длительность", "tooltip": "Управляет продолжительностью генерируемого аудио в секундах." }, "model": { "name": "модель" }, "prompt": { "name": "промпт" }, "seed": { "name": "сид", "tooltip": "Случайное начальное значение, используемое для генерации." }, "steps": { "name": "шаги", "tooltip": "Управляет количеством шагов сэмплирования." } }, "outputs": { "0": { "tooltip": null } } };
const StabilityUpscaleConservativeNode = { "description": "Увеличивает изображение до 4K с минимальными изменениями.", "display_name": "Stability AI Увеличение (Консервативное)", "inputs": { "control_after_generate": { "name": "контроль после генерации" }, "creativity": { "name": "креативность", "tooltip": "Управляет вероятностью создания дополнительных деталей, не сильно обусловленных исходным изображением." }, "image": { "name": "изображение" }, "negative_prompt": { "name": "негативный промпт", "tooltip": "Ключевые слова того, что вы не хотите видеть на выходном изображении. Это расширенная функция." }, "prompt": { "name": "промпт", "tooltip": "Что вы хотите видеть на выходном изображении. Сильный, описательный промпт, чётко определяющий элементы, цвета и объекты, приведёт к лучшим результатам." }, "seed": { "name": "seed", "tooltip": "Случайное значение seed, используемое для создания шума." } }, "outputs": { "0": { "tooltip": null } } };
const StabilityUpscaleCreativeNode = { "description": "Увеличение изображения до 4K разрешения с минимальными изменениями.", "display_name": "Stability AI Upscale Creative", "inputs": { "control_after_generate": { "name": "контроль после генерации" }, "creativity": { "name": "креативность", "tooltip": "Управляет вероятностью создания дополнительных деталей, не сильно обусловленных исходным изображением." }, "image": { "name": "изображение" }, "negative_prompt": { "name": "негативный промпт", "tooltip": "Ключевые слова того, что вы не хотите видеть на выходном изображении. Это расширенная функция." }, "prompt": { "name": "промпт", "tooltip": "Что вы хотите видеть на выходном изображении. Сильный, описательный промпт, чётко определяющий элементы, цвета и объекты, приведёт к лучшим результатам." }, "seed": { "name": "seed", "tooltip": "Случайное значение, используемое для создания шума." }, "style_preset": { "name": "стиль", "tooltip": "Необязательный желаемый стиль сгенерированного изображения." } }, "outputs": { "0": { "tooltip": null } } };
const StabilityUpscaleFastNode = { "description": "Быстро увеличивает изображение через Stability API до 4x от исходного размера; предназначено для увеличения изображений низкого качества или сжатых изображений.", "display_name": "Stability AI Быстрое Увеличение", "inputs": { "image": { "name": "изображение" } }, "outputs": { "0": { "tooltip": null } } };
const StableCascade_EmptyLatentImage = { "display_name": "StableCascade_Пустое латентное изображение", "inputs": { "batch_size": { "name": "размер_пакета" }, "compression": { "name": "сжатие" }, "height": { "name": "высота" }, "width": { "name": "ширина" } }, "outputs": { "0": { "name": "этап_c", "tooltip": null }, "1": { "name": "этап_b", "tooltip": null } } };
const StableCascade_StageB_Conditioning = { "display_name": "StableCascade_Этап B_Кондиционирование", "inputs": { "conditioning": { "name": "кондиционирование" }, "stage_c": { "name": "стадия_c" } }, "outputs": { "0": { "tooltip": null } } };
const StableCascade_StageC_VAEEncode = { "display_name": "StableCascade_Этап C_VAE Кодирование", "inputs": { "compression": { "name": "сжатие" }, "image": { "name": "изображение" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "этап_c", "tooltip": null }, "1": { "name": "этап_b", "tooltip": null } } };
const StableCascade_SuperResolutionControlnet = { "display_name": "StableCascade_Суперразрешение Controlnet", "inputs": { "image": { "name": "изображение" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "вход_controlnet", "tooltip": null }, "1": { "name": "этап_c", "tooltip": null }, "2": { "name": "этап_b", "tooltip": null } } };
const StableZero123_Conditioning = { "display_name": "StableZero123_Кондиционирование", "inputs": { "azimuth": { "name": "азимут" }, "batch_size": { "name": "размер_пакета" }, "clip_vision": { "name": "clip_vision" }, "elevation": { "name": "высота" }, "height": { "name": "высота" }, "init_image": { "name": "начальное_изображение" }, "vae": { "name": "vae" }, "width": { "name": "ширина" } }, "outputs": { "0": { "name": "положительный", "tooltip": null }, "1": { "name": "отрицательный", "tooltip": null }, "2": { "name": "латентный", "tooltip": null } } };
const StableZero123_Conditioning_Batched = { "display_name": "StableZero123_Кондиционирование_Пакетное", "inputs": { "azimuth": { "name": "азимут" }, "azimuth_batch_increment": { "name": "инкремент_азимута_пакета" }, "batch_size": { "name": "размер_пакета" }, "clip_vision": { "name": "clip_vision" }, "elevation": { "name": "высота" }, "elevation_batch_increment": { "name": "инкремент_высоты_пакета" }, "height": { "name": "высота" }, "init_image": { "name": "начальное_изображение" }, "vae": { "name": "vae" }, "width": { "name": "ширина" } }, "outputs": { "0": { "name": "положительный", "tooltip": null }, "1": { "name": "отрицательный", "tooltip": null }, "2": { "name": "латентный", "tooltip": null } } };
const StringCompare = { "display_name": "Сравнить", "inputs": { "case_sensitive": { "name": "с_учетом_регистра" }, "mode": { "name": "режим" }, "string_a": { "name": "строка_a" }, "string_b": { "name": "строка_b" } }, "outputs": { "0": { "tooltip": null } } };
const StringConcatenate = { "display_name": "Объединить", "inputs": { "delimiter": { "name": "разделитель" }, "string_a": { "name": "строка_a" }, "string_b": { "name": "строка_b" } }, "outputs": { "0": { "tooltip": null } } };
const StringContains = { "display_name": "Содержит", "inputs": { "case_sensitive": { "name": "с_учетом_регистра" }, "string": { "name": "строка" }, "substring": { "name": "подстрока" } }, "outputs": { "0": { "name": "содержит", "tooltip": null } } };
const StringLength = { "display_name": "Длина", "inputs": { "string": { "name": "строка" } }, "outputs": { "0": { "name": "длина", "tooltip": null } } };
const StringReplace = { "display_name": "Заменить", "inputs": { "find": { "name": "найти" }, "replace": { "name": "заменить" }, "string": { "name": "строка" } }, "outputs": { "0": { "tooltip": null } } };
const StringSubstring = { "display_name": "Подстрока", "inputs": { "end": { "name": "конец" }, "start": { "name": "начало" }, "string": { "name": "строка" } }, "outputs": { "0": { "tooltip": null } } };
const StringTrim = { "display_name": "Обрезать", "inputs": { "mode": { "name": "режим" }, "string": { "name": "строка" } }, "outputs": { "0": { "tooltip": null } } };
const StyleModelApply = { "display_name": "Применить модель стиля", "inputs": { "clip_vision_output": { "name": "выход_clip_vision" }, "conditioning": { "name": "кондиционирование" }, "strength": { "name": "сила" }, "strength_type": { "name": "тип_силы" }, "style_model": { "name": "модель_стиля" } } };
const StyleModelLoader = { "display_name": "Загрузить модель стиля", "inputs": { "style_model_name": { "name": "название_модели_стиля" } } };
const T5TokenizerOptions = { "display_name": "T5TokenizerOptions", "inputs": { "clip": { "name": "clip" }, "min_length": { "name": "минимальная_длина" }, "min_padding": { "name": "минимальное_дополнение" } }, "outputs": { "0": { "tooltip": null } } };
const TCFG = { "description": "TCFG – Тангенциальное демпфирование CFG (2503.18137)\n\nУточняет негативное условие для согласования с позитивным для улучшения качества.", "display_name": "Тангенциальное демпфирование CFG", "inputs": { "model": { "name": "модель" } }, "outputs": { "0": { "name": "исправленная_модель", "tooltip": null } } };
const TemporalScoreRescaling = { "description": "[Функция после CFG]\nTSR - Временное перемасштабирование оценки (2510.01184)\n\nПеремасштабирование оценки или шума модели для управления разнообразием сэмплирования.", "display_name": "TSR - Временное перемасштабирование оценки", "inputs": { "model": { "name": "модель" }, "tsr_k": { "name": "tsr_k", "tooltip": "Управляет силой перемасштабирования.\nМеньшее значение k дает более детализированные результаты; большее значение k дает более гладкие результаты при генерации изображений. Установка k = 1 отключает перемасштабирование." }, "tsr_sigma": { "name": "tsr_sigma", "tooltip": "Управляет тем, насколько рано начинает действовать перемасштабирование.\nБольшие значения вступают в силу раньше." } }, "outputs": { "0": { "name": "исправленная_модель", "tooltip": null } } };
const TextEncodeAceStepAudio = { "display_name": "TextEncodeAceStepAudio", "inputs": { "clip": { "name": "clip" }, "lyrics": { "name": "текст_песни" }, "lyrics_strength": { "name": "сила_текста_песни" }, "tags": { "name": "теги" } }, "outputs": { "0": { "tooltip": null } } };
const TextEncodeHunyuanVideo_ImageToVideo = { "display_name": "TextEncodeHunyuanVideo_ImageToVideo", "inputs": { "clip": { "name": "clip" }, "clip_vision_output": { "name": "выход clip_vision" }, "image_interleave": { "name": "перемежение изображения", "tooltip": "Насколько сильно изображение влияет на текстовую подсказку. Чем выше число, тем больше влияние от текстовой подсказки." }, "prompt": { "name": "подсказка" } }, "outputs": { "0": { "tooltip": null } } };
const TextEncodeQwenImageEdit = { "display_name": "TextEncodeQwenImageEdit", "inputs": { "clip": { "name": "clip" }, "image": { "name": "изображение" }, "prompt": { "name": "промпт" }, "vae": { "name": "vae" } }, "outputs": { "0": { "tooltip": null } } };
const TextEncodeQwenImageEditPlus = { "display_name": "TextEncodeQwenImageEditPlus", "inputs": { "clip": { "name": "clip" }, "image1": { "name": "изображение1" }, "image2": { "name": "изображение2" }, "image3": { "name": "изображение3" }, "prompt": { "name": "промпт" }, "vae": { "name": "vae" } }, "outputs": { "0": { "tooltip": null } } };
const ThresholdMask = { "display_name": "Пороговая маска", "inputs": { "mask": { "name": "маска" }, "value": { "name": "значение" } } };
const TomePatchModel = { "display_name": "Модель патча Tome", "inputs": { "model": { "name": "модель" }, "ratio": { "name": "соотношение" } }, "outputs": { "0": { "tooltip": null } } };
const TorchCompileModel = { "display_name": "Скомпилировать модель Torch", "inputs": { "backend": { "name": "бэкенд" }, "model": { "name": "модель" } }, "outputs": { "0": { "tooltip": null } } };
const TrainLoraNode = { "display_name": "Обучить LoRA", "inputs": { "algorithm": { "name": "алгоритм", "tooltip": "Алгоритм, используемый для обучения." }, "batch_size": { "name": "размер пакета", "tooltip": "Размер пакета, используемый для обучения." }, "control_after_generate": { "name": "управление после генерации" }, "existing_lora": { "name": "существующая lora", "tooltip": "Существующая LoRA для добавления. Установите None для новой LoRA." }, "grad_accumulation_steps": { "name": "шаги накопления градиента", "tooltip": "Количество шагов накопления градиента, используемых для обучения." }, "gradient_checkpointing": { "name": "чекпоинтинг градиента", "tooltip": "Использовать чекпоинтинг градиента для обучения." }, "latents": { "name": "латентные представления", "tooltip": "Латентные представления, используемые для обучения, служат набором данных/входными данными модели." }, "learning_rate": { "name": "скорость обучения", "tooltip": "Скорость обучения, используемая для тренировки." }, "lora_dtype": { "name": "тип данных lora", "tooltip": "Тип данных, используемый для LoRA." }, "loss_function": { "name": "функция потерь", "tooltip": "Функция потерь, используемая для обучения." }, "model": { "name": "модель", "tooltip": "Модель для обучения LoRA." }, "optimizer": { "name": "оптимизатор", "tooltip": "Оптимизатор, используемый для обучения." }, "positive": { "name": "позитивное условие", "tooltip": "Позитивное условие, используемое для обучения." }, "rank": { "name": "ранг", "tooltip": "Ранг слоёв LoRA." }, "seed": { "name": "зерно", "tooltip": "Зерно, используемое для обучения (применяется в генераторе для инициализации весов LoRA и выборки шума)." }, "steps": { "name": "шаги", "tooltip": "Количество шагов для обучения LoRA." }, "training_dtype": { "name": "тип данных обучения", "tooltip": "Тип данных, используемый для обучения." } }, "outputs": { "0": { "name": "модель с lora" }, "1": { "name": "lora" }, "2": { "name": "потери" }, "3": { "name": "шаги" } } };
const TrimAudioDuration = { "description": "Обрезать аудио тензор в выбранном временном диапазоне.", "display_name": "Обрезка длительности аудио", "inputs": { "audio": { "name": "аудио" }, "duration": { "name": "duration", "tooltip": "Длительность в секундах" }, "start_index": { "name": "start_index", "tooltip": "Время начала в секундах, может быть отрицательным для отсчёта с конца (поддерживает доли секунд)." } } };
const TrimVideoLatent = { "display_name": "TrimVideoLatent", "inputs": { "samples": { "name": "samples" }, "trim_amount": { "name": "обрезать_на" } }, "outputs": { "0": { "tooltip": null } } };
const TripleCLIPLoader = { "description": "[Рецепты]\n\nsd3: clip-l, clip-g, t5", "display_name": "Тройной загрузчик CLIP", "inputs": { "clip_name1": { "name": "clip_name1" }, "clip_name2": { "name": "clip_name2" }, "clip_name3": { "name": "clip_name3" } }, "outputs": { "0": { "tooltip": null } } };
const TripoConversionNode = { "display_name": "Tripo: Конвертировать модель", "inputs": { "face_limit": { "name": "face_limit" }, "format": { "name": "format" }, "original_model_task_id": { "name": "original_model_task_id" }, "quad": { "name": "quad" }, "texture_format": { "name": "texture_format" }, "texture_size": { "name": "texture_size" } } };
const TripoImageToModelNode = { "display_name": "Tripo: Изображение в модель", "inputs": { "face_limit": { "name": "face_limit" }, "image": { "name": "image" }, "model_seed": { "name": "model_seed" }, "model_version": { "name": "model_version", "tooltip": "Версия модели для использования при генерации" }, "orientation": { "name": "orientation" }, "pbr": { "name": "pbr" }, "quad": { "name": "quad" }, "style": { "name": "style" }, "texture": { "name": "texture" }, "texture_alignment": { "name": "texture_alignment" }, "texture_quality": { "name": "texture_quality" }, "texture_seed": { "name": "texture_seed" } }, "outputs": { "0": { "name": "model_file", "tooltip": null }, "1": { "name": "model task_id", "tooltip": null } } };
const TripoMultiviewToModelNode = { "display_name": "Tripo: Мультивью в модель", "inputs": { "face_limit": { "name": "лимит_лиц" }, "image": { "name": "image" }, "image_back": { "name": "image_back" }, "image_left": { "name": "image_left" }, "image_right": { "name": "image_right" }, "model_seed": { "name": "сид_модели" }, "model_version": { "name": "версия_модели", "tooltip": "Версия модели для использования при генерации" }, "orientation": { "name": "ориентация" }, "pbr": { "name": "PBR" }, "quad": { "name": "квад" }, "texture": { "name": "текстура" }, "texture_alignment": { "name": "выравнивание_текстуры" }, "texture_quality": { "name": "качество_текстуры" }, "texture_seed": { "name": "сид_текстуры" } }, "outputs": { "0": { "name": "файл_модели", "tooltip": null }, "1": { "name": "идентификатор_задачи_модели", "tooltip": null } } };
const TripoRefineNode = { "description": "Уточнение черновой модели, созданной только моделями Tripo v1.4.", "display_name": "Tripo: Уточнение черновой модели", "inputs": { "model_task_id": { "name": "идентификатор_задачи_модели", "tooltip": "Должна быть модель Tripo v1.4" } }, "outputs": { "0": { "name": "файл_модели", "tooltip": null }, "1": { "name": "идентификатор_задачи_модели", "tooltip": null } } };
const TripoRetargetNode = { "display_name": "Tripo: Перепривязка ригнутой модели", "inputs": { "animation": { "name": "анимация" }, "original_model_task_id": { "name": "идентификатор_задачи_исходной_модели" } }, "outputs": { "0": { "name": "файл_модели", "tooltip": null }, "1": { "name": "идентификатор_задачи_перепривязки", "tooltip": null } } };
const TripoRigNode = { "display_name": "Tripo: Риггинг модели", "inputs": { "original_model_task_id": { "name": "идентификатор_задачи_исходной_модели" } }, "outputs": { "0": { "name": "файл_модели", "tooltip": null }, "1": { "name": "идентификатор_задачи_риггинга", "tooltip": null } } };
const TripoTextToModelNode = { "display_name": "Tripo: Текст в модель", "inputs": { "face_limit": { "name": "face_limit" }, "image_seed": { "name": "image_seed" }, "model_seed": { "name": "model_seed" }, "model_version": { "name": "версия_модели" }, "negative_prompt": { "name": "негативный_промпт" }, "pbr": { "name": "PBR" }, "prompt": { "name": "промпт" }, "quad": { "name": "quad" }, "style": { "name": "стиль" }, "texture": { "name": "текстура" }, "texture_quality": { "name": "texture_quality" }, "texture_seed": { "name": "texture_seed" } }, "outputs": { "0": { "name": "model_file", "tooltip": null }, "1": { "name": "model task_id", "tooltip": null } } };
const TripoTextureNode = { "display_name": "Tripo: Модель текстур", "inputs": { "model_task_id": { "name": "model_task_id" }, "pbr": { "name": "pbr" }, "texture": { "name": "texture" }, "texture_alignment": { "name": "texture_alignment" }, "texture_quality": { "name": "texture_quality" }, "texture_seed": { "name": "texture_seed" } }, "outputs": { "0": { "name": "model_file", "tooltip": null }, "1": { "name": "model task_id", "tooltip": null } } };
const UNETLoader = { "display_name": "Загрузить модель диффузии", "inputs": { "unet_name": { "name": "название_unet" }, "weight_dtype": { "name": "тип_данных_веса" } } };
const UNetCrossAttentionMultiply = { "display_name": "Умножение перекрёстного внимания UNet", "inputs": { "k": { "name": "k" }, "model": { "name": "модель" }, "out": { "name": "выход" }, "q": { "name": "q" }, "v": { "name": "v" } }, "outputs": { "0": { "tooltip": null } } };
const UNetSelfAttentionMultiply = { "display_name": "Умножение самовнимания UNet", "inputs": { "k": { "name": "k" }, "model": { "name": "модель" }, "out": { "name": "выход" }, "q": { "name": "q" }, "v": { "name": "v" } }, "outputs": { "0": { "tooltip": null } } };
const UNetTemporalAttentionMultiply = { "display_name": "Умножение временного внимания UNet", "inputs": { "cross_structural": { "name": "кросс-структурный" }, "cross_temporal": { "name": "кросс-временной" }, "model": { "name": "модель" }, "self_structural": { "name": "самоструктурный" }, "self_temporal": { "name": "самовременный" } }, "outputs": { "0": { "tooltip": null } } };
const USOStyleReference = { "display_name": "USOStyleReference", "inputs": { "clip_vision_output": { "name": "clip_vision_output" }, "model": { "name": "model" }, "model_patch": { "name": "model_patch" } } };
const UpscaleModelLoader = { "display_name": "Загрузить модель апскейла", "inputs": { "model_name": { "name": "название_модели" } }, "outputs": { "0": { "tooltip": null } } };
const VAEDecode = { "description": "Декодирует латентные изображения обратно в изображения в пиксельном пространстве.", "display_name": "Декодировать VAE", "inputs": { "samples": { "name": "образцы", "tooltip": "Латентное изображение для декодирования." }, "vae": { "name": "vae", "tooltip": "Модель VAE, используемая для декодирования латентного изображения." } }, "outputs": { "0": { "tooltip": "Декодированное изображение." } } };
const VAEDecodeAudio = { "display_name": "Декодировать аудио VAE", "inputs": { "samples": { "name": "образцы" }, "vae": { "name": "vae" } } };
const VAEDecodeHunyuan3D = { "display_name": "VAEDecodeHunyuan3D", "inputs": { "num_chunks": { "name": "количество_частей" }, "octree_resolution": { "name": "разрешение_октодерева" }, "samples": { "name": "образцы" }, "vae": { "name": "vae" } } };
const VAEDecodeTiled = { "display_name": "Декодировать VAE (плитками)", "inputs": { "overlap": { "name": "перекрытие" }, "samples": { "name": "образцы" }, "temporal_overlap": { "name": "temporal_overlap", "tooltip": "Используется только для видео VAE: количество кадров для перекрытия." }, "temporal_size": { "name": "temporal_size", "tooltip": "Используется только для видео VAE: количество кадров для декодирования за раз." }, "tile_size": { "name": "размер_плитки" }, "vae": { "name": "vae" } } };
const VAEEncode = { "display_name": "Кодировать VAE", "inputs": { "pixels": { "name": "пиксели" }, "vae": { "name": "vae" } } };
const VAEEncodeAudio = { "display_name": "Кодировать аудио VAE", "inputs": { "audio": { "name": "аудио" }, "vae": { "name": "vae" } } };
const VAEEncodeForInpaint = { "display_name": "Кодировать VAE (для инпейнтинга)", "inputs": { "grow_mask_by": { "name": "увеличить_маску_на" }, "mask": { "name": "маска" }, "pixels": { "name": "пиксели" }, "vae": { "name": "vae" } } };
const VAEEncodeTiled = { "display_name": "Кодировать VAE (плитками)", "inputs": { "overlap": { "name": "перекрытие" }, "pixels": { "name": "пиксели" }, "temporal_overlap": { "name": "temporal_overlap", "tooltip": "Используется только для видео VAEs: количество кадров для перекрытия." }, "temporal_size": { "name": "temporal_size", "tooltip": "Используется только для видео VAEs: количество кадров для кодирования за один раз." }, "tile_size": { "name": "размер_плитки" }, "vae": { "name": "vae" } } };
const VAELoader = { "display_name": "Загрузить VAE", "inputs": { "vae_name": { "name": "название_vae" } } };
const VAESave = { "display_name": "Сохранить VAE", "inputs": { "filename_prefix": { "name": "префикс_названия_файла" }, "vae": { "name": "vae" } } };
const VPScheduler = { "display_name": "VPScheduler", "inputs": { "beta_d": { "name": "beta_d" }, "beta_min": { "name": "beta_min" }, "eps_s": { "name": "eps_s" }, "steps": { "name": "шаги" } } };
const Veo3VideoGenerationNode = { "description": "Создает видео из текстовых описаний с использованием API Google Veo 3", "display_name": "Генерация видео Google Veo 3", "inputs": { "aspect_ratio": { "name": "aspect_ratio", "tooltip": "Соотношение сторон выходного видео" }, "control_after_generate": { "name": "control after generate" }, "duration_seconds": { "name": "duration_seconds", "tooltip": "Длительность выходного видео в секундах (Veo 3 поддерживает только 8 секунд)" }, "enhance_prompt": { "name": "enhance_prompt", "tooltip": "Улучшать ли описание с помощью ИИ" }, "generate_audio": { "name": "generate_audio", "tooltip": "Сгенерировать аудио для видео. Поддерживается всеми моделями Veo 3." }, "image": { "name": "image", "tooltip": "Опорное изображение для направления генерации видео (необязательно)" }, "model": { "name": "model", "tooltip": "Модель Veo 3 для генерации видео" }, "negative_prompt": { "name": "negative_prompt", "tooltip": "Негативное текстовое описание для указания, чего следует избегать в видео" }, "person_generation": { "name": "person_generation", "tooltip": "Разрешать ли генерацию людей в видео" }, "prompt": { "name": "prompt", "tooltip": "Текстовое описание видео" }, "seed": { "name": "seed", "tooltip": "Сид для генерации видео (0 для случайного)" } }, "outputs": { "0": { "tooltip": null } } };
const VeoVideoGenerationNode = { "description": "Генерирует видео по текстовым подсказкам с помощью Google Veo API", "display_name": "Google Veo2 Генерация видео", "inputs": { "aspect_ratio": { "name": "aspect_ratio", "tooltip": "Соотношение сторон выходного видео" }, "control_after_generate": { "name": "control after generate" }, "duration_seconds": { "name": "duration_seconds", "tooltip": "Длительность выходного видео в секундах" }, "enhance_prompt": { "name": "enhance_prompt", "tooltip": "Улучшать ли подсказку с помощью ИИ" }, "image": { "name": "image", "tooltip": "Необязательное референсное изображение для направления генерации видео" }, "model": { "name": "model", "tooltip": "Модель Veo 2 для генерации видео" }, "negative_prompt": { "name": "negative_prompt", "tooltip": "Негативная текстовая подсказка для указания, чего избегать в видео" }, "person_generation": { "name": "person_generation", "tooltip": "Разрешить ли генерацию людей в видео" }, "prompt": { "name": "prompt", "tooltip": "Текстовое описание видео" }, "seed": { "name": "seed", "tooltip": "Сид для генерации видео (0 — случайный)" } }, "outputs": { "0": { "tooltip": null } } };
const VideoLinearCFGGuidance = { "display_name": "Направление Video Linear CFG", "inputs": { "min_cfg": { "name": "мин_cfg" }, "model": { "name": "модель" } } };
const VideoTriangleCFGGuidance = { "display_name": "Направление Video Triangle CFG", "inputs": { "min_cfg": { "name": "мин_cfg" }, "model": { "name": "модель" } } };
const ViduImageToVideoNode = { "description": "Генерация видео из изображения и необязательного промпта", "display_name": "Vidu Image To Video Generation", "inputs": { "control_after_generate": { "name": "control after generate" }, "duration": { "name": "duration", "tooltip": "Длительность выходного видео в секундах" }, "image": { "name": "image", "tooltip": "Изображение, используемое в качестве начального кадра генерируемого видео" }, "model": { "name": "model", "tooltip": "Название модели" }, "movement_amplitude": { "name": "movement_amplitude", "tooltip": "Амплитуда движения объектов в кадре" }, "prompt": { "name": "prompt", "tooltip": "Текстовое описание для генерации видео" }, "resolution": { "name": "resolution", "tooltip": "Поддерживаемые значения могут различаться в зависимости от модели и длительности" }, "seed": { "name": "seed", "tooltip": "Сид для генерации видео (0 для случайного)" } }, "outputs": { "0": { "tooltip": null } } };
const ViduReferenceVideoNode = { "description": "Генерация видео из нескольких изображений и промпта", "display_name": "Vidu Reference To Video Generation", "inputs": { "aspect_ratio": { "name": "соотношение сторон", "tooltip": "Соотношение сторон выходного видео" }, "control_after_generate": { "name": "управление после генерации" }, "duration": { "name": "длительность", "tooltip": "Длительность выходного видео в секундах" }, "images": { "name": "images", "tooltip": "Изображения для использования в качестве референсов для генерации видео с согласованными объектами (максимум 7 изображений)." }, "model": { "name": "model", "tooltip": "Название модели" }, "movement_amplitude": { "name": "амплитуда движения", "tooltip": "Амплитуда движения объектов в кадре" }, "prompt": { "name": "prompt", "tooltip": "Текстовое описание для генерации видео" }, "resolution": { "name": "разрешение", "tooltip": "Поддерживаемые значения могут различаться в зависимости от модели и длительности" }, "seed": { "name": "сид", "tooltip": "Сид для генерации видео (0 для случайного)" } }, "outputs": { "0": { "tooltip": null } } };
const ViduStartEndToVideoNode = { "description": "Сгенерировать видео из начального и конечного кадров с описанием", "display_name": "Генерация видео Vidu от начала до конца", "inputs": { "control_after_generate": { "name": "управление после генерации" }, "duration": { "name": "длительность", "tooltip": "Длительность выходного видео в секундах" }, "end_frame": { "name": "конечный кадр", "tooltip": "Конечный кадр" }, "first_frame": { "name": "первый кадр", "tooltip": "Начальный кадр" }, "model": { "name": "модель", "tooltip": "Название модели" }, "movement_amplitude": { "name": "амплитуда движения", "tooltip": "Амплитуда движения объектов в кадре" }, "prompt": { "name": "описание", "tooltip": "Текстовое описание для генерации видео" }, "resolution": { "name": "разрешение", "tooltip": "Поддерживаемые значения могут различаться в зависимости от модели и длительности" }, "seed": { "name": "сид", "tooltip": "Сид для генерации видео (0 для случайного)" } }, "outputs": { "0": { "tooltip": null } } };
const ViduTextToVideoNode = { "description": "Сгенерировать видео из текстового описания", "display_name": "Генерация видео Vidu из текста", "inputs": { "aspect_ratio": { "name": "aspect_ratio", "tooltip": "Соотношение сторон выходного видео" }, "control_after_generate": { "name": "control after generate" }, "duration": { "name": "duration", "tooltip": "Длительность выходного видео в секундах" }, "model": { "name": "модель", "tooltip": "Название модели" }, "movement_amplitude": { "name": "movement_amplitude", "tooltip": "Амплитуда движения объектов в кадре" }, "prompt": { "name": "prompt", "tooltip": "Текстовое описание для генерации видео" }, "resolution": { "name": "resolution", "tooltip": "Поддерживаемые значения могут различаться в зависимости от модели и длительности" }, "seed": { "name": "seed", "tooltip": "Сид для генерации видео (0 для случайного)" } }, "outputs": { "0": { "tooltip": null } } };
const VoxelToMesh = { "display_name": "VoxelToMesh", "inputs": { "algorithm": { "name": "алгоритм" }, "threshold": { "name": "порог" }, "voxel": { "name": "voxel" } } };
const VoxelToMeshBasic = { "display_name": "VoxelToMeshBasic", "inputs": { "threshold": { "name": "порог" }, "voxel": { "name": "воксель" } } };
const Wan22FunControlToVideo = { "display_name": "Wan22FunControlToVideo", "inputs": { "batch_size": { "name": "batch_size" }, "control_video": { "name": "control_video" }, "height": { "name": "height" }, "length": { "name": "length" }, "negative": { "name": "negative" }, "positive": { "name": "positive" }, "ref_image": { "name": "ref_image" }, "vae": { "name": "vae" }, "width": { "name": "width" } }, "outputs": { "0": { "name": "positive", "tooltip": null }, "1": { "name": "negative", "tooltip": null }, "2": { "name": "latent", "tooltip": null } } };
const Wan22ImageToVideoLatent = { "display_name": "Wan22ImageToVideoLatent", "inputs": { "batch_size": { "name": "batch_size" }, "height": { "name": "height" }, "length": { "name": "length" }, "start_image": { "name": "start_image" }, "vae": { "name": "vae" }, "width": { "name": "width" } }, "outputs": { "0": { "tooltip": null } } };
const WanAnimateToVideo = { "display_name": "WanAnimateToVideo", "inputs": { "background_video": { "name": "фоновое_видео" }, "batch_size": { "name": "размер_пакета" }, "character_mask": { "name": "маска_персонажа" }, "clip_vision_output": { "name": "выход_clip_vision" }, "continue_motion": { "name": "продолжение_движения" }, "continue_motion_max_frames": { "name": "максимум_кадров_продолжения_движения" }, "face_video": { "name": "видео_лица" }, "height": { "name": "высота" }, "length": { "name": "длина" }, "negative": { "name": "негативный" }, "pose_video": { "name": "видео_позы" }, "positive": { "name": "positive" }, "reference_image": { "name": "эталонное_изображение" }, "vae": { "name": "VAE" }, "video_frame_offset": { "name": "смещение_кадров_видео", "tooltip": "Количество кадров для пропуска во всех входных видео. Используется для генерации более длинных видео по частям. Подключите к выходу video_frame_offset предыдущего узла для расширения видео." }, "width": { "name": "ширина" } }, "outputs": { "0": { "name": "позитивный", "tooltip": null }, "1": { "name": "негативный", "tooltip": null }, "2": { "name": "латентный", "tooltip": null }, "3": { "name": "обрезка_латентного", "tooltip": null }, "4": { "name": "обрезка_изображения", "tooltip": null }, "5": { "name": "смещение_кадров_видео", "tooltip": null } } };
const WanCameraEmbedding = { "display_name": "WanCameraEmbedding", "inputs": { "camera_pose": { "name": "поза_камеры" }, "cx": { "name": "cx" }, "cy": { "name": "cy" }, "fx": { "name": "fx" }, "fy": { "name": "fy" }, "height": { "name": "высота" }, "length": { "name": "длина" }, "speed": { "name": "скорость" }, "width": { "name": "ширина" } }, "outputs": { "0": { "name": "вложение_камеры", "tooltip": null }, "1": { "name": "ширина", "tooltip": null }, "2": { "name": "высота", "tooltip": null }, "3": { "name": "длина", "tooltip": null } } };
const WanCameraImageToVideo = { "display_name": "WanCameraImageToVideo", "inputs": { "batch_size": { "name": "размер_пакета" }, "camera_conditions": { "name": "условия_камеры" }, "clip_vision_output": { "name": "выход_clip_vision" }, "height": { "name": "высота" }, "length": { "name": "длина" }, "negative": { "name": "негативный" }, "positive": { "name": "позитивный" }, "start_image": { "name": "начальное_изображение" }, "vae": { "name": "VAE" }, "width": { "name": "ширина" } }, "outputs": { "0": { "name": "позитивный", "tooltip": null }, "1": { "name": "негативный", "tooltip": null }, "2": { "name": "латентный", "tooltip": null } } };
const WanContextWindowsManual = { "description": "Ручная настройка контекстных окон для моделей типа WAN (dim=2).", "display_name": "Контекстные окна WAN (ручная настройка)", "inputs": { "closed_loop": { "name": "замкнутый_цикл", "tooltip": "Замыкать ли цикл контекстного окна; применимо только к циклическим расписаниям." }, "context_length": { "name": "длина_контекста", "tooltip": "Длина контекстного окна." }, "context_overlap": { "name": "перекрытие_контекста", "tooltip": "Перекрытие контекстных окон." }, "context_schedule": { "name": "расписание_контекста", "tooltip": "Шаг контекстного окна." }, "context_stride": { "name": "шаг_контекста", "tooltip": "Шаг контекстного окна; применимо только к равномерным расписаниям." }, "fuse_method": { "name": "метод_объединения", "tooltip": "Метод объединения контекстных окон." }, "model": { "name": "модель", "tooltip": "Модель, к которой применяются контекстные окна во время сэмплирования." } }, "outputs": { "0": { "tooltip": "Модель с применёнными контекстными окнами во время сэмплирования." } } };
const WanFirstLastFrameToVideo = { "display_name": "WanFirstLastFrameToVideo", "inputs": { "batch_size": { "name": "размер_пакета" }, "clip_vision_end_image": { "name": "clip_vision_end_image" }, "clip_vision_start_image": { "name": "clip_vision_start_image" }, "end_image": { "name": "конечное_изображение" }, "height": { "name": "высота" }, "length": { "name": "длина" }, "negative": { "name": "отрицательный" }, "positive": { "name": "положительный" }, "start_image": { "name": "начальное_изображение" }, "vae": { "name": "vae" }, "width": { "name": "ширина" } }, "outputs": { "0": { "name": "положительный", "tooltip": null }, "1": { "name": "отрицательный", "tooltip": null }, "2": { "name": "latent", "tooltip": null } } };
const WanFunControlToVideo = { "display_name": "WanFunControlToVideo", "inputs": { "batch_size": { "name": "размер_пакета" }, "clip_vision_output": { "name": "clip_vision_output" }, "control_video": { "name": "control_video" }, "height": { "name": "высота" }, "length": { "name": "длина" }, "negative": { "name": "негативный" }, "positive": { "name": "позитивный" }, "start_image": { "name": "стартовое_изображение" }, "vae": { "name": "vae" }, "width": { "name": "ширина" } }, "outputs": { "0": { "name": "позитивный", "tooltip": null }, "1": { "name": "негативный", "tooltip": null }, "2": { "name": "латентный", "tooltip": null } } };
const WanFunInpaintToVideo = { "display_name": "WanFunInpaintToVideo", "inputs": { "batch_size": { "name": "размер_пакета" }, "clip_vision_output": { "name": "clip_vision_output" }, "end_image": { "name": "конечное_изображение" }, "height": { "name": "высота" }, "length": { "name": "длина" }, "negative": { "name": "негативный" }, "positive": { "name": "позитивный" }, "start_image": { "name": "начальное_изображение" }, "vae": { "name": "vae" }, "width": { "name": "ширина" } }, "outputs": { "0": { "name": "позитивный", "tooltip": null }, "1": { "name": "негативный", "tooltip": null }, "2": { "name": "latent", "tooltip": null } } };
const WanHuMoImageToVideo = { "display_name": "WanHuMoImageToVideo", "inputs": { "audio_encoder_output": { "name": "выход_аудиокодера" }, "batch_size": { "name": "размер_пакета" }, "height": { "name": "высота" }, "length": { "name": "длина" }, "negative": { "name": "негативный" }, "positive": { "name": "позитивный" }, "ref_image": { "name": "опорное_изображение" }, "vae": { "name": "VAE" }, "width": { "name": "ширина" } }, "outputs": { "0": { "name": "позитивный", "tooltip": null }, "1": { "name": "негативный", "tooltip": null }, "2": { "name": "латентный", "tooltip": null } } };
const WanImageToImageApi = { "description": "Генерирует изображение из одного или двух входных изображений и текстового промпта. Выходное изображение в настоящее время фиксировано в 1,6 МП; его соотношение сторон соответствует входному изображению(ям).", "display_name": "Wan Image to Image", "inputs": { "control_after_generate": { "name": "управление_после_генерации" }, "image": { "name": "изображение", "tooltip": "Редактирование одного изображения или слияние нескольких изображений, максимум 2 изображения." }, "model": { "name": "модель", "tooltip": "Используемая модель." }, "negative_prompt": { "name": "негативный_промпт", "tooltip": "Негативный текстовый промпт, указывающий, чего следует избегать." }, "prompt": { "name": "промпт", "tooltip": "Промпт, используемый для описания элементов и визуальных особенностей, поддерживает английский/китайский языки." }, "seed": { "name": "сид", "tooltip": "Сид для использования при генерации." }, "watermark": { "name": "водяной_знак", "tooltip": 'Добавлять ли водяной знак "Сгенерировано ИИ" к результату.' } }, "outputs": { "0": { "tooltip": null } } };
const WanImageToVideo = { "display_name": "WanИзображениеВВидео", "inputs": { "batch_size": { "name": "размер_пакета" }, "clip_vision_output": { "name": "clip_vision_output" }, "height": { "name": "высота" }, "length": { "name": "длина" }, "negative": { "name": "отрицательный" }, "positive": { "name": "положительный" }, "start_image": { "name": "начальное_изображение" }, "vae": { "name": "vae" }, "width": { "name": "ширина" } }, "outputs": { "0": { "name": "положительный", "tooltip": null }, "1": { "name": "отрицательный", "tooltip": null }, "2": { "name": "latent", "tooltip": null } } };
const WanImageToVideoApi = { "description": "Генерирует видео на основе первого кадра и текстового промпта.", "display_name": "Wan Image to Video", "inputs": { "audio": { "name": "аудио", "tooltip": "Аудио должно содержать чёткий, громкий голос без посторонних шумов и фоновой музыки." }, "control_after_generate": { "name": "управление после генерации" }, "duration": { "name": "длительность", "tooltip": "Доступные длительности: 5 и 10 секунд" }, "generate_audio": { "name": "сгенерировать_аудио", "tooltip": "Если аудиовход отсутствует, автоматически сгенерировать аудио." }, "image": { "name": "изображение" }, "model": { "name": "модель", "tooltip": "Используемая модель." }, "negative_prompt": { "name": "негативный_промпт", "tooltip": "Негативный текстовый промпт, указывающий, чего следует избегать." }, "prompt": { "name": "промпт", "tooltip": "Промпт, используемый для описания элементов и визуальных особенностей, поддерживает английский/китайский языки." }, "prompt_extend": { "name": "расширить_промпт", "tooltip": "Улучшить ли промпт с помощью ИИ-ассистента." }, "resolution": { "name": "разрешение" }, "seed": { "name": "сид", "tooltip": "Сид для использования при генерации." }, "watermark": { "name": "водяной_знак", "tooltip": 'Добавлять ли водяной знак "Сгенерировано ИИ" к результату.' } }, "outputs": { "0": { "tooltip": null } } };
const WanPhantomSubjectToVideo = { "display_name": "WanPhantomSubjectToVideo", "inputs": { "batch_size": { "name": "размер_пакета" }, "height": { "name": "высота" }, "images": { "name": "изображения" }, "length": { "name": "длина" }, "negative": { "name": "негативный" }, "positive": { "name": "позитивный" }, "vae": { "name": "vae" }, "width": { "name": "ширина" } }, "outputs": { "0": { "name": "позитивный", "tooltip": null }, "1": { "name": "негативный_текст", "tooltip": null }, "2": { "name": "негативный_изображение_текст", "tooltip": null }, "3": { "name": "латентный", "tooltip": null } } };
const WanSoundImageToVideo = { "display_name": "WanSoundImageToVideo", "inputs": { "audio_encoder_output": { "name": "выход_аудиокодера" }, "batch_size": { "name": "размер_пакета" }, "control_video": { "name": "control_video" }, "height": { "name": "высота" }, "length": { "name": "длина" }, "negative": { "name": "негативный" }, "positive": { "name": "позитивный" }, "ref_image": { "name": "ref_image" }, "ref_motion": { "name": "ref_motion" }, "vae": { "name": "vae" }, "width": { "name": "ширина" } }, "outputs": { "0": { "name": "positive", "tooltip": null }, "1": { "name": "negative", "tooltip": null }, "2": { "name": "latent", "tooltip": null } } };
const WanSoundImageToVideoExtend = { "display_name": "WanSoundImageToVideoExtend", "inputs": { "audio_encoder_output": { "name": "audio_encoder_output" }, "control_video": { "name": "control_video" }, "length": { "name": "length" }, "negative": { "name": "negative" }, "positive": { "name": "positive" }, "ref_image": { "name": "ref_image" }, "vae": { "name": "vae" }, "video_latent": { "name": "video_latent" } }, "outputs": { "0": { "name": "positive", "tooltip": null }, "1": { "name": "negative", "tooltip": null }, "2": { "name": "latent", "tooltip": null } } };
const WanTextToImageApi = { "description": "Генерирует изображение на основе текстового промпта.", "display_name": "Wan Текст в изображение", "inputs": { "control_after_generate": { "name": "control after generate" }, "height": { "name": "height" }, "model": { "name": "model", "tooltip": "Модель для использования." }, "negative_prompt": { "name": "negative_prompt", "tooltip": "Негативный текстовый промпт для указания, чего следует избегать." }, "prompt": { "name": "prompt", "tooltip": "Промпт для описания элементов и визуальных особенностей, поддерживает английский/китайский." }, "prompt_extend": { "name": "prompt_extend", "tooltip": "Усилить ли промпт с помощью ИИ-помощника." }, "seed": { "name": "seed", "tooltip": "Сид для использования при генерации." }, "watermark": { "name": "watermark", "tooltip": 'Добавлять ли водяной знак "Сгенерировано ИИ" к результату.' }, "width": { "name": "width" } }, "outputs": { "0": { "tooltip": null } } };
const WanTextToVideoApi = { "description": "Создаёт видео на основе текстового промпта.", "display_name": "Wan Text to Video", "inputs": { "audio": { "name": "audio", "tooltip": "Аудио должно содержать чёткий, громкий голос без посторонних шумов и фоновой музыки." }, "control_after_generate": { "name": "control after generate" }, "duration": { "name": "duration", "tooltip": "Доступные длительности: 5 и 10 секунд" }, "generate_audio": { "name": "generate_audio", "tooltip": "Если аудиовход отсутствует, автоматически сгенерировать аудио." }, "model": { "name": "model", "tooltip": "Используемая модель." }, "negative_prompt": { "name": "negative_prompt", "tooltip": "Негативный текстовый промпт для указания, чего следует избегать." }, "prompt": { "name": "prompt", "tooltip": "Промпт для описания элементов и визуальных особенностей, поддерживает английский/китайский." }, "prompt_extend": { "name": "prompt_extend", "tooltip": "Усилить ли промпт с помощью ИИ-ассистента." }, "seed": { "name": "seed", "tooltip": "Сид для генерации." }, "size": { "name": "size" }, "watermark": { "name": "watermark", "tooltip": 'Добавлять ли водяной знак "Сгенерировано ИИ" к результату.' } }, "outputs": { "0": { "tooltip": null } } };
const WanTrackToVideo = { "display_name": "WanTrackToVideo", "inputs": { "batch_size": { "name": "batch_size" }, "clip_vision_output": { "name": "clip_vision_output" }, "height": { "name": "height" }, "length": { "name": "length" }, "negative": { "name": "negative" }, "positive": { "name": "positive" }, "start_image": { "name": "start_image" }, "temperature": { "name": "temperature" }, "topk": { "name": "topk" }, "tracks": { "name": "tracks" }, "vae": { "name": "vae" }, "width": { "name": "width" } }, "outputs": { "0": { "name": "позитивный", "tooltip": null }, "1": { "name": "негативный", "tooltip": null }, "2": { "name": "латентный", "tooltip": null } } };
const WanVaceToVideo = { "display_name": "WanVaceToVideo", "inputs": { "batch_size": { "name": "размер_пакета" }, "control_masks": { "name": "control_masks" }, "control_video": { "name": "control_video" }, "height": { "name": "высота" }, "length": { "name": "длина" }, "negative": { "name": "негативный" }, "positive": { "name": "позитивный" }, "reference_image": { "name": "референсное_изображение" }, "strength": { "name": "интенсивность" }, "vae": { "name": "vae" }, "width": { "name": "ширина" } }, "outputs": { "0": { "name": "позитивный", "tooltip": null }, "1": { "name": "негативный", "tooltip": null }, "2": { "name": "latent", "tooltip": null }, "3": { "name": "обрезанный_latent", "tooltip": null } } };
const WebcamCapture = { "display_name": "Захват с веб-камеры", "inputs": { "capture_on_queue": { "name": "захват_в_очереди" }, "height": { "name": "высота" }, "image": { "name": "изображение" }, "waiting for camera___": {}, "width": { "name": "ширина" } } };
const unCLIPCheckpointLoader = { "display_name": "Загрузчик контрольной точки unCLIP", "inputs": { "ckpt_name": { "name": "название_ckpt" } } };
const unCLIPConditioning = { "display_name": "unCLIP кондиционирование", "inputs": { "clip_vision_output": { "name": "выход_clip_vision" }, "conditioning": { "name": "условие" }, "noise_augmentation": { "name": "аугментация_шума" }, "strength": { "name": "сила" } } };
const nodeDefs = {
  APG,
  AddNoise,
  AlignYourStepsScheduler,
  AudioAdjustVolume,
  AudioConcat,
  AudioEncoderEncode,
  AudioEncoderLoader,
  AudioMerge,
  BasicGuider,
  BasicScheduler,
  BetaSamplingScheduler,
  ByteDanceFirstLastFrameNode,
  ByteDanceImageEditNode,
  ByteDanceImageNode,
  ByteDanceImageReferenceNode,
  ByteDanceImageToVideoNode,
  ByteDanceSeedreamNode,
  ByteDanceTextToVideoNode,
  CFGGuider,
  CFGNorm,
  CFGZeroStar,
  CLIPAttentionMultiply,
  CLIPLoader,
  CLIPMergeAdd,
  CLIPMergeSimple,
  CLIPMergeSubtract,
  CLIPSave,
  CLIPSetLastLayer,
  CLIPTextEncode,
  CLIPTextEncodeControlnet,
  CLIPTextEncodeFlux,
  CLIPTextEncodeHiDream,
  CLIPTextEncodeHunyuanDiT,
  CLIPTextEncodeLumina2,
  CLIPTextEncodePixArtAlpha,
  CLIPTextEncodeSD3,
  CLIPTextEncodeSDXL,
  CLIPTextEncodeSDXLRefiner,
  CLIPVisionEncode,
  CLIPVisionLoader,
  Canny,
  CaseConverter,
  CheckpointLoader,
  CheckpointLoaderSimple,
  CheckpointSave,
  ChromaRadianceOptions,
  CombineHooks2,
  CombineHooks4,
  CombineHooks8,
  ConditioningAverage,
  ConditioningCombine,
  ConditioningConcat,
  ConditioningSetArea,
  ConditioningSetAreaPercentage,
  ConditioningSetAreaPercentageVideo,
  ConditioningSetAreaStrength,
  ConditioningSetDefaultCombine,
  ConditioningSetMask,
  ConditioningSetProperties,
  ConditioningSetPropertiesAndCombine,
  ConditioningSetTimestepRange,
  ConditioningStableAudio,
  ConditioningTimestepsRange,
  ConditioningZeroOut,
  ContextWindowsManual,
  ControlNetApply,
  ControlNetApplyAdvanced,
  ControlNetApplySD3,
  ControlNetInpaintingAliMamaApply,
  ControlNetLoader,
  CosmosImageToVideoLatent,
  CosmosPredict2ImageToVideoLatent,
  CreateHookKeyframe,
  CreateHookKeyframesFromFloats,
  CreateHookKeyframesInterpolated,
  CreateHookLora,
  CreateHookLoraModelOnly,
  CreateHookModelAsLora,
  CreateHookModelAsLoraModelOnly,
  CreateVideo,
  CropMask,
  DiffControlNetLoader,
  DifferentialDiffusion,
  DiffusersLoader,
  DisableNoise,
  DualCFGGuider,
  DualCLIPLoader,
  EasyCache,
  EmptyAceStepLatentAudio,
  EmptyAudio,
  EmptyChromaRadianceLatentImage,
  EmptyCosmosLatentVideo,
  EmptyHunyuanImageLatent,
  EmptyHunyuanLatentVideo,
  EmptyImage,
  EmptyLTXVLatentVideo,
  EmptyLatentAudio,
  EmptyLatentHunyuan3Dv2,
  EmptyLatentImage,
  EmptyMochiLatentVideo,
  EmptySD3LatentImage,
  "Epsilon Scaling": { "display_name": "Масштабирование эпсилон", "inputs": { "model": { "name": "модель" }, "scaling_factor": { "name": "коэффициент_масштабирования" } }, "outputs": { "0": { "tooltip": null } } },
  ExponentialScheduler,
  ExtendIntermediateSigmas,
  FeatherMask,
  FlipSigmas,
  FluxDisableGuidance,
  FluxGuidance,
  FluxKontextImageScale,
  FluxKontextMaxImageNode,
  FluxKontextMultiReferenceLatentMethod,
  FluxKontextProImageNode,
  FluxProExpandNode,
  FluxProFillNode,
  FluxProUltraImageNode,
  FreSca,
  FreeU,
  FreeU_V2,
  GITSScheduler,
  GLIGENLoader,
  GLIGENTextBoxApply,
  GeminiImageNode,
  GeminiInputFiles,
  GeminiNode,
  GetImageSize,
  GetVideoComponents,
  GrowMask,
  Hunyuan3Dv2Conditioning,
  Hunyuan3Dv2ConditioningMultiView,
  HunyuanImageToVideo,
  HunyuanRefinerLatent,
  HyperTile,
  HypernetworkLoader,
  IdeogramV1,
  IdeogramV2,
  IdeogramV3,
  ImageAddNoise,
  ImageBatch,
  ImageBlend,
  ImageBlur,
  ImageColorToMask,
  ImageCompositeMasked,
  ImageCrop,
  ImageFlip,
  ImageFromBatch,
  ImageInvert,
  ImageOnlyCheckpointLoader,
  ImageOnlyCheckpointSave,
  ImagePadForOutpaint,
  ImageQuantize,
  ImageRGBToYUV,
  ImageRotate,
  ImageScale,
  ImageScaleBy,
  ImageScaleToMaxDimension,
  ImageScaleToTotalPixels,
  ImageSharpen,
  ImageStitch,
  ImageToMask,
  ImageUpscaleWithModel,
  ImageYUVToRGB,
  InpaintModelConditioning,
  InstructPixToPixConditioning,
  InvertMask,
  JoinImageWithAlpha,
  KSampler,
  KSamplerAdvanced,
  KSamplerSelect,
  KarrasScheduler,
  KlingCameraControlI2VNode,
  KlingCameraControlT2VNode,
  KlingCameraControls,
  KlingDualCharacterVideoEffectNode,
  KlingImage2VideoNode,
  KlingImageGenerationNode,
  KlingLipSyncAudioToVideoNode,
  KlingLipSyncTextToVideoNode,
  KlingSingleImageVideoEffectNode,
  KlingStartEndFrameNode,
  KlingTextToVideoNode,
  KlingVideoExtendNode,
  KlingVirtualTryOnNode,
  LTXVAddGuide,
  LTXVConditioning,
  LTXVCropGuides,
  LTXVImgToVideo,
  LTXVPreprocess,
  LTXVScheduler,
  LaplaceScheduler,
  LatentAdd,
  LatentApplyOperation,
  LatentApplyOperationCFG,
  LatentBatch,
  LatentBatchSeedBehavior,
  LatentBlend,
  LatentComposite,
  LatentCompositeMasked,
  LatentConcat,
  LatentCrop,
  LatentCut,
  LatentFlip,
  LatentFromBatch,
  LatentInterpolate,
  LatentMultiply,
  LatentOperationSharpen,
  LatentOperationTonemapReinhard,
  LatentRotate,
  LatentSubtract,
  LatentUpscale,
  LatentUpscaleBy,
  LazyCache,
  Load3D,
  LoadAudio,
  LoadImage,
  LoadImageMask,
  LoadImageOutput,
  LoadLatent,
  LoadVideo,
  LoraLoader,
  LoraLoaderModelOnly,
  LoraModelLoader,
  LoraSave,
  LossGraphNode,
  LotusConditioning,
  LtxvApiImageToVideo,
  LtxvApiTextToVideo,
  LumaConceptsNode,
  LumaImageModifyNode,
  LumaImageNode,
  LumaImageToVideoNode,
  LumaReferenceNode,
  LumaVideoNode,
  Mahiro,
  MaskComposite,
  MaskPreview,
  MaskToImage,
  MinimaxHailuoVideoNode,
  MinimaxImageToVideoNode,
  MinimaxTextToVideoNode,
  ModelComputeDtype,
  ModelMergeAdd,
  ModelMergeAuraflow,
  ModelMergeBlocks,
  ModelMergeCosmos14B,
  ModelMergeCosmos7B,
  ModelMergeCosmosPredict2_14B,
  ModelMergeCosmosPredict2_2B,
  ModelMergeFlux1,
  ModelMergeLTXV,
  ModelMergeMochiPreview,
  ModelMergeQwenImage,
  ModelMergeSD1,
  ModelMergeSD2,
  ModelMergeSD35_Large,
  ModelMergeSD3_2B,
  ModelMergeSDXL,
  ModelMergeSimple,
  ModelMergeSubtract,
  ModelMergeWAN2_1,
  ModelPatchLoader,
  ModelSamplingAuraFlow,
  ModelSamplingContinuousEDM,
  ModelSamplingContinuousV,
  ModelSamplingDiscrete,
  ModelSamplingFlux,
  ModelSamplingLTXV,
  ModelSamplingSD3,
  ModelSamplingStableCascade,
  ModelSave,
  MoonvalleyImg2VideoNode,
  MoonvalleyTxt2VideoNode,
  MoonvalleyVideo2VideoNode,
  Morphology,
  OpenAIChatConfig,
  OpenAIChatNode,
  OpenAIDalle2,
  OpenAIDalle3,
  OpenAIGPTImage1,
  OpenAIInputFiles,
  OpenAIVideoSora2,
  OptimalStepsScheduler,
  PairConditioningCombine,
  PairConditioningSetDefaultCombine,
  PairConditioningSetProperties,
  PairConditioningSetPropertiesAndCombine,
  PatchModelAddDownscale,
  PerpNeg,
  PerpNegGuider,
  PerturbedAttentionGuidance,
  PhotoMakerEncode,
  PhotoMakerLoader,
  PixverseImageToVideoNode,
  PixverseTemplateNode,
  PixverseTextToVideoNode,
  PixverseTransitionVideoNode,
  PolyexponentialScheduler,
  PorterDuffImageComposite,
  Preview3D,
  PreviewAny,
  PreviewAudio,
  PreviewImage,
  PrimitiveBoolean,
  PrimitiveFloat,
  PrimitiveInt,
  PrimitiveString,
  PrimitiveStringMultiline,
  QuadrupleCLIPLoader,
  QwenImageDiffsynthControlnet,
  RandomNoise,
  RebatchImages,
  RebatchLatents,
  RecordAudio,
  RecraftColorRGB,
  RecraftControls,
  RecraftCreativeUpscaleNode,
  RecraftCrispUpscaleNode,
  RecraftImageInpaintingNode,
  RecraftImageToImageNode,
  RecraftRemoveBackgroundNode,
  RecraftReplaceBackgroundNode,
  RecraftStyleV3DigitalIllustration,
  RecraftStyleV3InfiniteStyleLibrary,
  RecraftStyleV3LogoRaster,
  RecraftStyleV3RealisticImage,
  RecraftTextToImageNode,
  RecraftTextToVectorNode,
  RecraftVectorizeImageNode,
  ReferenceLatent,
  RegexExtract,
  RegexMatch,
  RegexReplace,
  RenormCFG,
  RepeatImageBatch,
  RepeatLatentBatch,
  RescaleCFG,
  ResizeAndPadImage,
  Rodin3D_Detail,
  Rodin3D_Gen2,
  Rodin3D_Regular,
  Rodin3D_Sketch,
  Rodin3D_Smooth,
  RunwayFirstLastFrameNode,
  RunwayImageToVideoNodeGen3a,
  RunwayImageToVideoNodeGen4,
  RunwayTextToImageNode,
  SDTurboScheduler,
  SD_4XUpscale_Conditioning,
  SV3D_Conditioning,
  SVD_img2vid_Conditioning,
  SamplerCustom,
  SamplerCustomAdvanced,
  SamplerDPMAdaptative,
  SamplerDPMPP_2M_SDE,
  SamplerDPMPP_2S_Ancestral,
  SamplerDPMPP_3M_SDE,
  SamplerDPMPP_SDE,
  SamplerER_SDE,
  SamplerEulerAncestral,
  SamplerEulerAncestralCFGPP,
  SamplerEulerCFGpp,
  SamplerLCMUpscale,
  SamplerLMS,
  SamplerSASolver,
  SamplingPercentToSigma,
  SaveAnimatedPNG,
  SaveAnimatedWEBP,
  SaveAudio,
  SaveAudioMP3,
  SaveAudioOpus,
  SaveGLB,
  SaveImage,
  SaveImageWebsocket,
  SaveLatent,
  SaveSVGNode,
  SaveVideo,
  SaveWEBM,
  ScaleROPE,
  SelfAttentionGuidance,
  SetClipHooks,
  SetFirstSigma,
  SetHookKeyframes,
  SetLatentNoiseMask,
  SetUnionControlNetType,
  SkipLayerGuidanceDiT,
  SkipLayerGuidanceDiTSimple,
  SkipLayerGuidanceSD3,
  SolidMask,
  SplitAudioChannels,
  SplitImageWithAlpha,
  SplitSigmas,
  SplitSigmasDenoise,
  StabilityAudioInpaint,
  StabilityAudioToAudio,
  StabilityStableImageSD_3_5Node,
  StabilityStableImageUltraNode,
  StabilityTextToAudio,
  StabilityUpscaleConservativeNode,
  StabilityUpscaleCreativeNode,
  StabilityUpscaleFastNode,
  StableCascade_EmptyLatentImage,
  StableCascade_StageB_Conditioning,
  StableCascade_StageC_VAEEncode,
  StableCascade_SuperResolutionControlnet,
  StableZero123_Conditioning,
  StableZero123_Conditioning_Batched,
  StringCompare,
  StringConcatenate,
  StringContains,
  StringLength,
  StringReplace,
  StringSubstring,
  StringTrim,
  StyleModelApply,
  StyleModelLoader,
  T5TokenizerOptions,
  TCFG,
  TemporalScoreRescaling,
  TextEncodeAceStepAudio,
  TextEncodeHunyuanVideo_ImageToVideo,
  TextEncodeQwenImageEdit,
  TextEncodeQwenImageEditPlus,
  ThresholdMask,
  TomePatchModel,
  TorchCompileModel,
  TrainLoraNode,
  TrimAudioDuration,
  TrimVideoLatent,
  TripleCLIPLoader,
  TripoConversionNode,
  TripoImageToModelNode,
  TripoMultiviewToModelNode,
  TripoRefineNode,
  TripoRetargetNode,
  TripoRigNode,
  TripoTextToModelNode,
  TripoTextureNode,
  UNETLoader,
  UNetCrossAttentionMultiply,
  UNetSelfAttentionMultiply,
  UNetTemporalAttentionMultiply,
  USOStyleReference,
  UpscaleModelLoader,
  VAEDecode,
  VAEDecodeAudio,
  VAEDecodeHunyuan3D,
  VAEDecodeTiled,
  VAEEncode,
  VAEEncodeAudio,
  VAEEncodeForInpaint,
  VAEEncodeTiled,
  VAELoader,
  VAESave,
  VPScheduler,
  Veo3VideoGenerationNode,
  VeoVideoGenerationNode,
  VideoLinearCFGGuidance,
  VideoTriangleCFGGuidance,
  ViduImageToVideoNode,
  ViduReferenceVideoNode,
  ViduStartEndToVideoNode,
  ViduTextToVideoNode,
  VoxelToMesh,
  VoxelToMeshBasic,
  Wan22FunControlToVideo,
  Wan22ImageToVideoLatent,
  WanAnimateToVideo,
  WanCameraEmbedding,
  WanCameraImageToVideo,
  WanContextWindowsManual,
  WanFirstLastFrameToVideo,
  WanFunControlToVideo,
  WanFunInpaintToVideo,
  WanHuMoImageToVideo,
  WanImageToImageApi,
  WanImageToVideo,
  WanImageToVideoApi,
  WanPhantomSubjectToVideo,
  WanSoundImageToVideo,
  WanSoundImageToVideoExtend,
  WanTextToImageApi,
  WanTextToVideoApi,
  WanTrackToVideo,
  WanVaceToVideo,
  WebcamCapture,
  unCLIPCheckpointLoader,
  unCLIPConditioning
};
export {
  APG,
  AddNoise,
  AlignYourStepsScheduler,
  AudioAdjustVolume,
  AudioConcat,
  AudioEncoderEncode,
  AudioEncoderLoader,
  AudioMerge,
  BasicGuider,
  BasicScheduler,
  BetaSamplingScheduler,
  ByteDanceFirstLastFrameNode,
  ByteDanceImageEditNode,
  ByteDanceImageNode,
  ByteDanceImageReferenceNode,
  ByteDanceImageToVideoNode,
  ByteDanceSeedreamNode,
  ByteDanceTextToVideoNode,
  CFGGuider,
  CFGNorm,
  CFGZeroStar,
  CLIPAttentionMultiply,
  CLIPLoader,
  CLIPMergeAdd,
  CLIPMergeSimple,
  CLIPMergeSubtract,
  CLIPSave,
  CLIPSetLastLayer,
  CLIPTextEncode,
  CLIPTextEncodeControlnet,
  CLIPTextEncodeFlux,
  CLIPTextEncodeHiDream,
  CLIPTextEncodeHunyuanDiT,
  CLIPTextEncodeLumina2,
  CLIPTextEncodePixArtAlpha,
  CLIPTextEncodeSD3,
  CLIPTextEncodeSDXL,
  CLIPTextEncodeSDXLRefiner,
  CLIPVisionEncode,
  CLIPVisionLoader,
  Canny,
  CaseConverter,
  CheckpointLoader,
  CheckpointLoaderSimple,
  CheckpointSave,
  ChromaRadianceOptions,
  CombineHooks2,
  CombineHooks4,
  CombineHooks8,
  ConditioningAverage,
  ConditioningCombine,
  ConditioningConcat,
  ConditioningSetArea,
  ConditioningSetAreaPercentage,
  ConditioningSetAreaPercentageVideo,
  ConditioningSetAreaStrength,
  ConditioningSetDefaultCombine,
  ConditioningSetMask,
  ConditioningSetProperties,
  ConditioningSetPropertiesAndCombine,
  ConditioningSetTimestepRange,
  ConditioningStableAudio,
  ConditioningTimestepsRange,
  ConditioningZeroOut,
  ContextWindowsManual,
  ControlNetApply,
  ControlNetApplyAdvanced,
  ControlNetApplySD3,
  ControlNetInpaintingAliMamaApply,
  ControlNetLoader,
  CosmosImageToVideoLatent,
  CosmosPredict2ImageToVideoLatent,
  CreateHookKeyframe,
  CreateHookKeyframesFromFloats,
  CreateHookKeyframesInterpolated,
  CreateHookLora,
  CreateHookLoraModelOnly,
  CreateHookModelAsLora,
  CreateHookModelAsLoraModelOnly,
  CreateVideo,
  CropMask,
  DiffControlNetLoader,
  DifferentialDiffusion,
  DiffusersLoader,
  DisableNoise,
  DualCFGGuider,
  DualCLIPLoader,
  EasyCache,
  EmptyAceStepLatentAudio,
  EmptyAudio,
  EmptyChromaRadianceLatentImage,
  EmptyCosmosLatentVideo,
  EmptyHunyuanImageLatent,
  EmptyHunyuanLatentVideo,
  EmptyImage,
  EmptyLTXVLatentVideo,
  EmptyLatentAudio,
  EmptyLatentHunyuan3Dv2,
  EmptyLatentImage,
  EmptyMochiLatentVideo,
  EmptySD3LatentImage,
  ExponentialScheduler,
  ExtendIntermediateSigmas,
  FeatherMask,
  FlipSigmas,
  FluxDisableGuidance,
  FluxGuidance,
  FluxKontextImageScale,
  FluxKontextMaxImageNode,
  FluxKontextMultiReferenceLatentMethod,
  FluxKontextProImageNode,
  FluxProExpandNode,
  FluxProFillNode,
  FluxProUltraImageNode,
  FreSca,
  FreeU,
  FreeU_V2,
  GITSScheduler,
  GLIGENLoader,
  GLIGENTextBoxApply,
  GeminiImageNode,
  GeminiInputFiles,
  GeminiNode,
  GetImageSize,
  GetVideoComponents,
  GrowMask,
  Hunyuan3Dv2Conditioning,
  Hunyuan3Dv2ConditioningMultiView,
  HunyuanImageToVideo,
  HunyuanRefinerLatent,
  HyperTile,
  HypernetworkLoader,
  IdeogramV1,
  IdeogramV2,
  IdeogramV3,
  ImageAddNoise,
  ImageBatch,
  ImageBlend,
  ImageBlur,
  ImageColorToMask,
  ImageCompositeMasked,
  ImageCrop,
  ImageFlip,
  ImageFromBatch,
  ImageInvert,
  ImageOnlyCheckpointLoader,
  ImageOnlyCheckpointSave,
  ImagePadForOutpaint,
  ImageQuantize,
  ImageRGBToYUV,
  ImageRotate,
  ImageScale,
  ImageScaleBy,
  ImageScaleToMaxDimension,
  ImageScaleToTotalPixels,
  ImageSharpen,
  ImageStitch,
  ImageToMask,
  ImageUpscaleWithModel,
  ImageYUVToRGB,
  InpaintModelConditioning,
  InstructPixToPixConditioning,
  InvertMask,
  JoinImageWithAlpha,
  KSampler,
  KSamplerAdvanced,
  KSamplerSelect,
  KarrasScheduler,
  KlingCameraControlI2VNode,
  KlingCameraControlT2VNode,
  KlingCameraControls,
  KlingDualCharacterVideoEffectNode,
  KlingImage2VideoNode,
  KlingImageGenerationNode,
  KlingLipSyncAudioToVideoNode,
  KlingLipSyncTextToVideoNode,
  KlingSingleImageVideoEffectNode,
  KlingStartEndFrameNode,
  KlingTextToVideoNode,
  KlingVideoExtendNode,
  KlingVirtualTryOnNode,
  LTXVAddGuide,
  LTXVConditioning,
  LTXVCropGuides,
  LTXVImgToVideo,
  LTXVPreprocess,
  LTXVScheduler,
  LaplaceScheduler,
  LatentAdd,
  LatentApplyOperation,
  LatentApplyOperationCFG,
  LatentBatch,
  LatentBatchSeedBehavior,
  LatentBlend,
  LatentComposite,
  LatentCompositeMasked,
  LatentConcat,
  LatentCrop,
  LatentCut,
  LatentFlip,
  LatentFromBatch,
  LatentInterpolate,
  LatentMultiply,
  LatentOperationSharpen,
  LatentOperationTonemapReinhard,
  LatentRotate,
  LatentSubtract,
  LatentUpscale,
  LatentUpscaleBy,
  LazyCache,
  Load3D,
  LoadAudio,
  LoadImage,
  LoadImageMask,
  LoadImageOutput,
  LoadLatent,
  LoadVideo,
  LoraLoader,
  LoraLoaderModelOnly,
  LoraModelLoader,
  LoraSave,
  LossGraphNode,
  LotusConditioning,
  LtxvApiImageToVideo,
  LtxvApiTextToVideo,
  LumaConceptsNode,
  LumaImageModifyNode,
  LumaImageNode,
  LumaImageToVideoNode,
  LumaReferenceNode,
  LumaVideoNode,
  Mahiro,
  MaskComposite,
  MaskPreview,
  MaskToImage,
  MinimaxHailuoVideoNode,
  MinimaxImageToVideoNode,
  MinimaxTextToVideoNode,
  ModelComputeDtype,
  ModelMergeAdd,
  ModelMergeAuraflow,
  ModelMergeBlocks,
  ModelMergeCosmos14B,
  ModelMergeCosmos7B,
  ModelMergeCosmosPredict2_14B,
  ModelMergeCosmosPredict2_2B,
  ModelMergeFlux1,
  ModelMergeLTXV,
  ModelMergeMochiPreview,
  ModelMergeQwenImage,
  ModelMergeSD1,
  ModelMergeSD2,
  ModelMergeSD35_Large,
  ModelMergeSD3_2B,
  ModelMergeSDXL,
  ModelMergeSimple,
  ModelMergeSubtract,
  ModelMergeWAN2_1,
  ModelPatchLoader,
  ModelSamplingAuraFlow,
  ModelSamplingContinuousEDM,
  ModelSamplingContinuousV,
  ModelSamplingDiscrete,
  ModelSamplingFlux,
  ModelSamplingLTXV,
  ModelSamplingSD3,
  ModelSamplingStableCascade,
  ModelSave,
  MoonvalleyImg2VideoNode,
  MoonvalleyTxt2VideoNode,
  MoonvalleyVideo2VideoNode,
  Morphology,
  OpenAIChatConfig,
  OpenAIChatNode,
  OpenAIDalle2,
  OpenAIDalle3,
  OpenAIGPTImage1,
  OpenAIInputFiles,
  OpenAIVideoSora2,
  OptimalStepsScheduler,
  PairConditioningCombine,
  PairConditioningSetDefaultCombine,
  PairConditioningSetProperties,
  PairConditioningSetPropertiesAndCombine,
  PatchModelAddDownscale,
  PerpNeg,
  PerpNegGuider,
  PerturbedAttentionGuidance,
  PhotoMakerEncode,
  PhotoMakerLoader,
  PixverseImageToVideoNode,
  PixverseTemplateNode,
  PixverseTextToVideoNode,
  PixverseTransitionVideoNode,
  PolyexponentialScheduler,
  PorterDuffImageComposite,
  Preview3D,
  PreviewAny,
  PreviewAudio,
  PreviewImage,
  PrimitiveBoolean,
  PrimitiveFloat,
  PrimitiveInt,
  PrimitiveString,
  PrimitiveStringMultiline,
  QuadrupleCLIPLoader,
  QwenImageDiffsynthControlnet,
  RandomNoise,
  RebatchImages,
  RebatchLatents,
  RecordAudio,
  RecraftColorRGB,
  RecraftControls,
  RecraftCreativeUpscaleNode,
  RecraftCrispUpscaleNode,
  RecraftImageInpaintingNode,
  RecraftImageToImageNode,
  RecraftRemoveBackgroundNode,
  RecraftReplaceBackgroundNode,
  RecraftStyleV3DigitalIllustration,
  RecraftStyleV3InfiniteStyleLibrary,
  RecraftStyleV3LogoRaster,
  RecraftStyleV3RealisticImage,
  RecraftTextToImageNode,
  RecraftTextToVectorNode,
  RecraftVectorizeImageNode,
  ReferenceLatent,
  RegexExtract,
  RegexMatch,
  RegexReplace,
  RenormCFG,
  RepeatImageBatch,
  RepeatLatentBatch,
  RescaleCFG,
  ResizeAndPadImage,
  Rodin3D_Detail,
  Rodin3D_Gen2,
  Rodin3D_Regular,
  Rodin3D_Sketch,
  Rodin3D_Smooth,
  RunwayFirstLastFrameNode,
  RunwayImageToVideoNodeGen3a,
  RunwayImageToVideoNodeGen4,
  RunwayTextToImageNode,
  SDTurboScheduler,
  SD_4XUpscale_Conditioning,
  SV3D_Conditioning,
  SVD_img2vid_Conditioning,
  SamplerCustom,
  SamplerCustomAdvanced,
  SamplerDPMAdaptative,
  SamplerDPMPP_2M_SDE,
  SamplerDPMPP_2S_Ancestral,
  SamplerDPMPP_3M_SDE,
  SamplerDPMPP_SDE,
  SamplerER_SDE,
  SamplerEulerAncestral,
  SamplerEulerAncestralCFGPP,
  SamplerEulerCFGpp,
  SamplerLCMUpscale,
  SamplerLMS,
  SamplerSASolver,
  SamplingPercentToSigma,
  SaveAnimatedPNG,
  SaveAnimatedWEBP,
  SaveAudio,
  SaveAudioMP3,
  SaveAudioOpus,
  SaveGLB,
  SaveImage,
  SaveImageWebsocket,
  SaveLatent,
  SaveSVGNode,
  SaveVideo,
  SaveWEBM,
  ScaleROPE,
  SelfAttentionGuidance,
  SetClipHooks,
  SetFirstSigma,
  SetHookKeyframes,
  SetLatentNoiseMask,
  SetUnionControlNetType,
  SkipLayerGuidanceDiT,
  SkipLayerGuidanceDiTSimple,
  SkipLayerGuidanceSD3,
  SolidMask,
  SplitAudioChannels,
  SplitImageWithAlpha,
  SplitSigmas,
  SplitSigmasDenoise,
  StabilityAudioInpaint,
  StabilityAudioToAudio,
  StabilityStableImageSD_3_5Node,
  StabilityStableImageUltraNode,
  StabilityTextToAudio,
  StabilityUpscaleConservativeNode,
  StabilityUpscaleCreativeNode,
  StabilityUpscaleFastNode,
  StableCascade_EmptyLatentImage,
  StableCascade_StageB_Conditioning,
  StableCascade_StageC_VAEEncode,
  StableCascade_SuperResolutionControlnet,
  StableZero123_Conditioning,
  StableZero123_Conditioning_Batched,
  StringCompare,
  StringConcatenate,
  StringContains,
  StringLength,
  StringReplace,
  StringSubstring,
  StringTrim,
  StyleModelApply,
  StyleModelLoader,
  T5TokenizerOptions,
  TCFG,
  TemporalScoreRescaling,
  TextEncodeAceStepAudio,
  TextEncodeHunyuanVideo_ImageToVideo,
  TextEncodeQwenImageEdit,
  TextEncodeQwenImageEditPlus,
  ThresholdMask,
  TomePatchModel,
  TorchCompileModel,
  TrainLoraNode,
  TrimAudioDuration,
  TrimVideoLatent,
  TripleCLIPLoader,
  TripoConversionNode,
  TripoImageToModelNode,
  TripoMultiviewToModelNode,
  TripoRefineNode,
  TripoRetargetNode,
  TripoRigNode,
  TripoTextToModelNode,
  TripoTextureNode,
  UNETLoader,
  UNetCrossAttentionMultiply,
  UNetSelfAttentionMultiply,
  UNetTemporalAttentionMultiply,
  USOStyleReference,
  UpscaleModelLoader,
  VAEDecode,
  VAEDecodeAudio,
  VAEDecodeHunyuan3D,
  VAEDecodeTiled,
  VAEEncode,
  VAEEncodeAudio,
  VAEEncodeForInpaint,
  VAEEncodeTiled,
  VAELoader,
  VAESave,
  VPScheduler,
  Veo3VideoGenerationNode,
  VeoVideoGenerationNode,
  VideoLinearCFGGuidance,
  VideoTriangleCFGGuidance,
  ViduImageToVideoNode,
  ViduReferenceVideoNode,
  ViduStartEndToVideoNode,
  ViduTextToVideoNode,
  VoxelToMesh,
  VoxelToMeshBasic,
  Wan22FunControlToVideo,
  Wan22ImageToVideoLatent,
  WanAnimateToVideo,
  WanCameraEmbedding,
  WanCameraImageToVideo,
  WanContextWindowsManual,
  WanFirstLastFrameToVideo,
  WanFunControlToVideo,
  WanFunInpaintToVideo,
  WanHuMoImageToVideo,
  WanImageToImageApi,
  WanImageToVideo,
  WanImageToVideoApi,
  WanPhantomSubjectToVideo,
  WanSoundImageToVideo,
  WanSoundImageToVideoExtend,
  WanTextToImageApi,
  WanTextToVideoApi,
  WanTrackToVideo,
  WanVaceToVideo,
  WebcamCapture,
  nodeDefs as default,
  unCLIPCheckpointLoader,
  unCLIPConditioning
};
//# sourceMappingURL=nodeDefs-CvmVDWYd.js.map
