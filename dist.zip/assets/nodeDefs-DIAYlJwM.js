const APG = { "display_name": "自适应投影引导", "inputs": { "eta": { "name": "预计到达时间", "tooltip": "控制平行引导向量的缩放比例。默认 CFG 行为设置为 1。" }, "model": { "name": "模型" }, "momentum": { "name": "动量", "tooltip": "控制扩散过程中的引导运行平均值，设置为0时禁用。" }, "norm_threshold": { "name": "向量归一化", "tooltip": "将引导向量归一化到此值，设置为 0 时禁用归一化。" } }, "outputs": { "0": { "tooltip": null } } };
const AddNoise = { "display_name": "添加噪波", "inputs": { "latent_image": { "name": "Latent" }, "model": { "name": "模型" }, "noise": { "name": "噪波" }, "sigmas": { "name": "Sigmas" } } };
const AlignYourStepsScheduler = { "display_name": "AlignYourSteps调度器", "inputs": { "denoise": { "name": "降噪" }, "model_type": { "name": "模型类型" }, "steps": { "name": "步数" } }, "outputs": { "0": { "tooltip": null } } };
const AudioAdjustVolume = { "display_name": "音频调整音量", "inputs": { "audio": { "name": "音频" }, "volume": { "name": "音量", "tooltip": "音量调整，单位为分贝 (dB)。0 = 无变化，+6 = 加倍，-6 = 减半，等等" } } };
const AudioConcat = { "description": "将 音频1 与 音频2 按指定方向连接。", "display_name": "音频拼接", "inputs": { "audio1": { "name": "音频1" }, "audio2": { "name": "音频2" }, "direction": { "name": "方向", "tooltip": "音频2 在 音频1 之前或之后。" } } };
const AudioEncoderEncode = { "display_name": "音频编码器编码", "inputs": { "audio": { "name": "音频" }, "audio_encoder": { "name": "音频编码器" } }, "outputs": { "0": { "tooltip": null } } };
const AudioEncoderLoader = { "display_name": "加载音频编码器", "inputs": { "audio_encoder_name": { "name": "音频编码器" } }, "outputs": { "0": { "tooltip": null } } };
const AudioMerge = { "description": "叠加 音频1 和 音频2 轨道的波形。", "display_name": "音频合并", "inputs": { "audio1": { "name": "音频1" }, "audio2": { "name": "音频2" }, "merge_method": { "name": "合并方法", "tooltip": "用于组合音频波形的方法。" } } };
const BasicGuider = { "display_name": "基本引导器", "inputs": { "conditioning": { "name": "条件" }, "model": { "name": "模型" } } };
const BasicScheduler = { "display_name": "基本调度器", "inputs": { "denoise": { "name": "降噪" }, "model": { "name": "模型" }, "scheduler": { "name": "调度器" }, "steps": { "name": "步数" } } };
const BetaSamplingScheduler = { "display_name": "Beta采样调度器", "inputs": { "alpha": { "name": "alpha" }, "beta": { "name": "beta" }, "model": { "name": "模型" }, "steps": { "name": "步数" } } };
const ByteDanceFirstLastFrameNode = { "description": "使用提示词和首尾帧生成视频。", "display_name": "字节跳动首尾帧转视频", "inputs": { "aspect_ratio": { "name": "宽高比", "tooltip": "输出视频的宽高比。" }, "camera_fixed": { "name": "相机固定", "tooltip": "指定是否固定相机。平台会在您的提示词中附加固定相机的指令，但不保证实际效果。" }, "control_after_generate": { "name": "生成后控制" }, "duration": { "name": "时长", "tooltip": "输出视频的时长（以秒为单位）。" }, "first_frame": { "name": "第一帧", "tooltip": "用于视频的第一帧。" }, "last_frame": { "name": "最后一帧", "tooltip": "用于视频的最后一帧。" }, "model": { "name": "模型" }, "prompt": { "name": "提示", "tooltip": "用于生成视频的文本提示。" }, "resolution": { "name": "分辨率", "tooltip": "输出视频的分辨率。" }, "seed": { "name": "种子", "tooltip": "用于生成的种子。" }, "watermark": { "name": "水印", "tooltip": "是否在视频中添加“AI 生成”水印。" } }, "outputs": { "0": { "tooltip": null } } };
const ByteDanceImageEditNode = { "description": "通过基于提示的API使用字节跳动模型编辑图像", "display_name": "字节跳动图片编辑", "inputs": { "control_after_generate": { "name": "生成后控制" }, "guidance_scale": { "name": "引导尺度", "tooltip": "数值越高，图像越紧密地遵循提示" }, "image": { "name": "图片", "tooltip": "要编辑的基础图像" }, "model": { "name": "模型" }, "prompt": { "name": "提示", "tooltip": "编辑图像的指令" }, "seed": { "name": "种子", "tooltip": "用于生成的种子" }, "watermark": { "name": "水印", "tooltip": "是否在图像上添加“AI生成”水印" } }, "outputs": { "0": { "tooltip": null } } };
const ByteDanceImageNode = { "description": "通过基于提示的API使用字节跳动模型生成图像", "display_name": "字节跳动图片", "inputs": { "control_after_generate": { "name": "生成后控制" }, "guidance_scale": { "name": "引导尺度", "tooltip": "数值越高，图像越紧密地遵循提示" }, "height": { "name": "高度", "tooltip": "图像的自定义高度。仅当 `size_preset` 设置为 `Custom` 时该值才生效" }, "model": { "name": "模型" }, "prompt": { "name": "提示", "tooltip": "用于生成图像的文本提示" }, "seed": { "name": "种子", "tooltip": "用于生成的种子" }, "size_preset": { "name": "尺寸预设", "tooltip": "选择一个推荐尺寸。选择自定义以使用下方的宽度和高度" }, "watermark": { "name": "水印", "tooltip": "是否在图像上添加“AI生成”水印" }, "width": { "name": "宽度", "tooltip": "图像的自定义宽度。仅当 `size_preset` 设置为 `Custom` 时该值才生效" } }, "outputs": { "0": { "tooltip": null } } };
const ByteDanceImageReferenceNode = { "description": "使用提示和参考图像生成视频。", "display_name": "字节跳动参考图像转视频", "inputs": { "aspect_ratio": { "name": "宽高比", "tooltip": "输出视频的宽高比。" }, "control_after_generate": { "name": "生成后控制" }, "duration": { "name": "时长", "tooltip": "输出视频的时长（以秒为单位）。" }, "images": { "name": "图片", "tooltip": "一到四张图片。" }, "model": { "name": "模型" }, "prompt": { "name": "提示", "tooltip": "用于生成视频的文本提示。" }, "resolution": { "name": "分辨率", "tooltip": "输出视频的分辨率。" }, "seed": { "name": "种子", "tooltip": "用于生成的种子。" }, "watermark": { "name": "水印", "tooltip": "是否在视频中添加“AI 生成”水印。" } }, "outputs": { "0": { "tooltip": null } } };
const ByteDanceImageToVideoNode = { "description": "通过API基于图像和提示使用字节跳动模型生成视频", "display_name": "字节跳动图片转视频", "inputs": { "aspect_ratio": { "name": "宽高比", "tooltip": "输出视频的宽高比。" }, "camera_fixed": { "name": "摄像头已固定", "tooltip": "指定是否固定相机。平台会在您的提示词中附加固定相机的指令，但不保证实际效果。" }, "control_after_generate": { "name": "生成后控制" }, "duration": { "name": "时长", "tooltip": "输出视频的时长（以秒为单位）。" }, "image": { "name": "图片", "tooltip": "用于视频的第一帧。" }, "model": { "name": "模型" }, "prompt": { "name": "提示", "tooltip": "用于生成视频的文本提示。" }, "resolution": { "name": "分辨率", "tooltip": "输出视频的分辨率。" }, "seed": { "name": "种子", "tooltip": "用于生成的种子。" }, "watermark": { "name": "水印", "tooltip": "是否在视频中添加“AI生成”水印。" } }, "outputs": { "0": { "tooltip": null } } };
const ByteDanceSeedreamNode = { "description": "统一文本到图像生成，支持高达4K分辨率的精确单句编辑。", "display_name": "字节跳动Seedream 4", "inputs": { "control_after_generate": { "name": "生成后控制" }, "fail_on_partial": { "name": "部分失败时停止", "tooltip": "如果启用，当任何请求的图像缺失或返回错误时，将中止执行。" }, "height": { "name": "高度", "tooltip": "图像的自定义高度。仅当 `size_preset` 设置为 `Custom` 时该值生效" }, "image": { "name": "图像", "tooltip": "用于图像到图像生成的输入图像。用于单参考或多参考生成的1-10张图像列表。" }, "max_images": { "name": "最大图片数", "tooltip": "当 sequential_image_generation='auto' 时生成图像的最大数量。总图像数（输入+生成）不能超过 15。" }, "model": { "name": "模型", "tooltip": "模型名称" }, "prompt": { "name": "提示", "tooltip": "用于创建或编辑图像的文本提示。" }, "seed": { "name": "种子", "tooltip": "用于生成的种子。" }, "sequential_image_generation": { "name": "顺序图像生成", "tooltip": "分组图像生成模式。'disabled' 生成单张图像。'auto' 由模型决定是否生成多张相关图像（例如故事场景、角色变体）。" }, "size_preset": { "name": "尺寸预设", "tooltip": "选择一个推荐尺寸。选择“自定义”以使用下面的宽度和高度。" }, "watermark": { "name": "水印", "tooltip": "是否在图像上添加“AI 生成”水印。" }, "width": { "name": "宽度", "tooltip": "图像的自定义宽度。仅当 `size_preset` 设置为 `Custom` 时该值生效" } }, "outputs": { "0": { "tooltip": null } } };
const ByteDanceTextToVideoNode = { "description": "通过API基于提示使用字节跳动模型生成视频", "display_name": "字节跳动文生视频", "inputs": { "aspect_ratio": { "name": "宽高比", "tooltip": "输出视频的宽高比。" }, "camera_fixed": { "name": "固定相机", "tooltip": "指定是否固定相机。平台会在您的提示后附加固定相机的指令，但不保证实际效果。" }, "control_after_generate": { "name": "生成后控制" }, "duration": { "name": "时长", "tooltip": "输出视频的时长（秒）。" }, "model": { "name": "模型" }, "prompt": { "name": "提示", "tooltip": "用于生成视频的文本提示。" }, "resolution": { "name": "分辨率", "tooltip": "输出视频的分辨率。" }, "seed": { "name": "种子", "tooltip": "用于生成的种子值。" }, "watermark": { "name": "水印", "tooltip": "是否在视频中添加“AI生成”水印。" } }, "outputs": { "0": { "tooltip": null } } };
const CFGGuider = { "display_name": "CFG引导器", "inputs": { "cfg": { "name": "CFG" }, "model": { "name": "模型" }, "negative": { "name": "负面条件" }, "positive": { "name": "正面条件" } } };
const CFGNorm = { "display_name": "CFG归一化", "inputs": { "model": { "name": "模型" }, "strength": { "name": "强度" } }, "outputs": { "0": { "name": "模型", "tooltip": null } } };
const CFGZeroStar = { "display_name": "CFGZeroStar", "inputs": { "model": { "name": "模型" } }, "outputs": { "0": { "name": "模型", "tooltip": null } } };
const CLIPAttentionMultiply = { "display_name": "CLIP注意力相乘", "inputs": { "clip": { "name": "CLIP" }, "k": { "name": "k" }, "out": { "name": "输出" }, "q": { "name": "q" }, "v": { "name": "v" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPLoader = { "description": "[配方]\n\nStable Diffusion：clip-l\nStable Cascade：clip-g\nSD3：t5 / clip-g / clip-l\nStable Audio：t5\nMochi：t5\ncosmos：old t5 xxl", "display_name": "加载CLIP", "inputs": { "clip_name": { "name": "CLIP名称" }, "device": { "name": "设备" }, "type": { "name": "类型" } } };
const CLIPMergeAdd = { "display_name": "CLIP相加", "inputs": { "clip1": { "name": "clip1" }, "clip2": { "name": "clip2" } } };
const CLIPMergeSimple = { "display_name": "CLIP融合简易", "inputs": { "clip1": { "name": "clip1" }, "clip2": { "name": "clip2" }, "ratio": { "name": "比例" } } };
const CLIPMergeSubtract = { "display_name": "CLIP相减", "inputs": { "clip1": { "name": "clip1" }, "clip2": { "name": "clip2" }, "multiplier": { "name": "乘数" } } };
const CLIPSave = { "display_name": "CLIP保存", "inputs": { "clip": { "name": "clip" }, "filename_prefix": { "name": "文件名前缀" } } };
const CLIPSetLastLayer = { "display_name": "设置CLIP最后一层", "inputs": { "clip": { "name": "clip" }, "stop_at_clip_layer": { "name": "停止在CLIP层" } } };
const CLIPTextEncode = { "description": "使用 CLIP 模型将文本编码成嵌入组（embedding），用于引导扩散模型生成图像。", "display_name": "CLIP文本编码", "inputs": { "clip": { "name": "clip", "tooltip": "用于编码文本的 CLIP 模型。" }, "text": { "name": "文本", "tooltip": "要编码的文本。" } }, "outputs": { "0": { "tooltip": "包含嵌入文本的条件，用于引导扩散模型。" } } };
const CLIPTextEncodeControlnet = { "display_name": "CLIP文本编码ControlNet", "inputs": { "clip": { "name": "clip" }, "conditioning": { "name": "条件" }, "text": { "name": "文本" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeFlux = { "display_name": "CLIP文本编码Flux", "inputs": { "clip": { "name": "clip" }, "clip_l": { "name": "clip_l" }, "guidance": { "name": "引导" }, "t5xxl": { "name": "t5xxl" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeHiDream = { "display_name": "CLIP文本编码HiDream", "inputs": { "clip": { "name": "clip" }, "clip_g": { "name": "clip_g" }, "clip_l": { "name": "clip_l" }, "llama": { "name": "llama" }, "t5xxl": { "name": "t5xxl" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeHunyuanDiT = { "display_name": "CLIP文本编码混元DiT", "inputs": { "bert": { "name": "bert" }, "clip": { "name": "clip" }, "mt5xl": { "name": "mt5xl" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeLumina2 = { "description": "使用CLIP模型将系统提示和用户提示编码成可以用来引导扩散模型生成特定图像的嵌入。", "display_name": "CLIP文本编码Lumina2", "inputs": { "clip": { "name": "clip", "tooltip": "用于编码文本的CLIP模型。" }, "system_prompt": { "name": "系统提示词", "tooltip": "Lumina2提供两种类型的系统提示：优越：你是一个设计来根据文本提示或用户提示生成优越图像的助手，这些图像具有基于文本提示的优越度的图像-文本对齐。对齐：你是一个设计来根据文本提示生成高质量图像的助手，这些图像具有基于文本提示的最高度的图像-文本对齐。" }, "user_prompt": { "name": "提示词", "tooltip": "需要编码的文本。" } }, "outputs": { "0": { "tooltip": "包含用于引导扩散模型的嵌入文本的条件。" } } };
const CLIPTextEncodePixArtAlpha = { "description": "编码文本并设置PixArt Alpha的分辨率条件。不适用于PixArt Sigma。", "display_name": "CLIP文本编码PixArtAlpha", "inputs": { "clip": { "name": "剪辑" }, "height": { "name": "高度" }, "text": { "name": "文本" }, "width": { "name": "宽度" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeSD3 = { "display_name": "CLIP文本编码SD3", "inputs": { "clip": { "name": "clip" }, "clip_g": { "name": "clip_g" }, "clip_l": { "name": "clip_l" }, "empty_padding": { "name": "空白填充" }, "t5xxl": { "name": "t5xxl" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeSDXL = { "display_name": "CLIP文本编码SDXL", "inputs": { "clip": { "name": "clip" }, "crop_h": { "name": "裁剪高" }, "crop_w": { "name": "裁剪宽" }, "height": { "name": "高度" }, "target_height": { "name": "目标高度" }, "target_width": { "name": "目标宽度" }, "text_g": { "name": "文本_g" }, "text_l": { "name": "文本_l" }, "width": { "name": "宽度" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeSDXLRefiner = { "display_name": "CLIP文本编码SDXL精炼器", "inputs": { "ascore": { "name": "美学分数" }, "clip": { "name": "clip" }, "height": { "name": "高度" }, "text": { "name": "文本" }, "width": { "name": "宽度" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPVisionEncode = { "display_name": "CLIP视觉编码", "inputs": { "clip_vision": { "name": "clip视觉" }, "crop": { "name": "裁剪" }, "image": { "name": "图像" } } };
const CLIPVisionLoader = { "display_name": "加载CLIP视觉", "inputs": { "clip_name": { "name": "clip名称" } } };
const Canny = { "display_name": "Canny边缘检测", "inputs": { "high_threshold": { "name": "高阈值" }, "image": { "name": "图像" }, "low_threshold": { "name": "低阈值" } }, "outputs": { "0": { "tooltip": null } } };
const CaseConverter = { "display_name": "大小写转换器", "inputs": { "mode": { "name": "模式" }, "string": { "name": "字符串" } }, "outputs": { "0": { "tooltip": null } } };
const CheckpointLoader = { "display_name": "Ckeckpoint加载器（已弃用）", "inputs": { "ckpt_name": { "name": "Checkpoint名称" }, "config_name": { "name": "配置名称" } } };
const CheckpointLoaderSimple = { "description": "加载扩散模型 Checkpoint，用于去除 Latent 噪波。", "display_name": "Checkpoint加载器（简易）", "inputs": { "ckpt_name": { "name": "Checkpoint名称", "tooltip": "要加载的Checkpoint模型的名称。" } }, "outputs": { "0": { "tooltip": "用于去除 Latent 噪波的模型。" }, "1": { "tooltip": "用于编码文本提示的 CLIP 模型。" }, "2": { "tooltip": "用于将图像编码和解码到 Latent 的 VAE 模型。" } } };
const CheckpointSave = { "display_name": "保存Checkpoint", "inputs": { "clip": { "name": "clip" }, "filename_prefix": { "name": "文件名前缀" }, "model": { "name": "模型" }, "vae": { "name": "vae" } } };
const ChromaRadianceOptions = { "description": "允许为Chroma Radiance模型设置高级选项。", "display_name": "ChromaRadiance选项", "inputs": { "end_sigma": { "name": "结束sigma", "tooltip": "这些选项生效的最后一个sigma值。" }, "model": { "name": "模型" }, "nerf_tile_size": { "name": "NeRF瓦片大小", "tooltip": "允许覆盖默认的NeRF瓦片大小。-1表示使用默认值（32）。0表示使用非平铺模式（可能需要大量显存）。" }, "preserve_wrapper": { "name": "保留包装器", "tooltip": "启用时，如果存在现有模型函数包装器，将委托给该包装器。通常应保持启用状态。" }, "start_sigma": { "name": "起始sigma", "tooltip": "这些选项生效的第一个sigma值。" } }, "outputs": { "0": { "tooltip": null } } };
const CombineHooks2 = { "display_name": "组合约束 [2]", "inputs": { "hooks_A": { "name": "约束_A" }, "hooks_B": { "name": "约束_B" } } };
const CombineHooks4 = { "display_name": "组合约束 [4]", "inputs": { "hooks_A": { "name": "约束_A" }, "hooks_B": { "name": "约束_B" }, "hooks_C": { "name": "约束_C" }, "hooks_D": { "name": "约束_D" } } };
const CombineHooks8 = { "display_name": "组合约束 [8]", "inputs": { "hooks_A": { "name": "约束_A" }, "hooks_B": { "name": "约束_B" }, "hooks_C": { "name": "约束_C" }, "hooks_D": { "name": "约束_D" }, "hooks_E": { "name": "约束_E" }, "hooks_F": { "name": "约束_F" }, "hooks_G": { "name": "约束_G" }, "hooks_H": { "name": "约束_H" } } };
const ConditioningAverage = { "display_name": "条件平均", "inputs": { "conditioning_from": { "name": "条件从" }, "conditioning_to": { "name": "条件到" }, "conditioning_to_strength": { "name": "条件到强度" } } };
const ConditioningCombine = { "display_name": "条件合并", "inputs": { "conditioning_1": { "name": "条件_1" }, "conditioning_2": { "name": "条件_2" } } };
const ConditioningConcat = { "display_name": "条件连接", "inputs": { "conditioning_from": { "name": "条件从" }, "conditioning_to": { "name": "条件到" } } };
const ConditioningSetArea = { "display_name": "条件采样区域", "inputs": { "conditioning": { "name": "条件" }, "height": { "name": "高度" }, "strength": { "name": "强度" }, "width": { "name": "宽度" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const ConditioningSetAreaPercentage = { "display_name": "条件采样区域（系数）", "inputs": { "conditioning": { "name": "条件化" }, "height": { "name": "高度" }, "strength": { "name": "强度" }, "width": { "name": "宽度" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const ConditioningSetAreaPercentageVideo = { "display_name": "调节设置区域百分比视频", "inputs": { "conditioning": { "name": "调节" }, "height": { "name": "高度" }, "strength": { "name": "强度" }, "temporal": { "name": "时间" }, "width": { "name": "宽度" }, "x": { "name": "x" }, "y": { "name": "y" }, "z": { "name": "z" } } };
const ConditioningSetAreaStrength = { "display_name": "条件采样区域强度", "inputs": { "conditioning": { "name": "条件化" }, "strength": { "name": "强度" } } };
const ConditioningSetDefaultCombine = { "display_name": "条件设置默认合并", "inputs": { "cond": { "name": "条件" }, "cond_DEFAULT": { "name": "默认条件" }, "hooks": { "name": "约束" } } };
const ConditioningSetMask = { "display_name": "条件遮罩", "inputs": { "conditioning": { "name": "条件化" }, "mask": { "name": "遮罩" }, "set_cond_area": { "name": "设置条件区域" }, "strength": { "name": "强度" } } };
const ConditioningSetProperties = { "display_name": "条件设置属性", "inputs": { "cond_NEW": { "name": "新条件" }, "hooks": { "name": "约束" }, "mask": { "name": "遮罩" }, "set_cond_area": { "name": "设置条件区域" }, "strength": { "name": "强度" }, "timesteps": { "name": "间隔" } } };
const ConditioningSetPropertiesAndCombine = { "display_name": "条件设置属性合并", "inputs": { "cond": { "name": "条件" }, "cond_NEW": { "name": "新条件" }, "hooks": { "name": "约束" }, "mask": { "name": "遮罩" }, "set_cond_area": { "name": "设置条件区域" }, "strength": { "name": "强度" }, "timesteps": { "name": "间隔" } } };
const ConditioningSetTimestepRange = { "display_name": "设置条件时间", "inputs": { "conditioning": { "name": "条件" }, "end": { "name": "结束" }, "start": { "name": "开始" } } };
const ConditioningStableAudio = { "display_name": "StableAudio条件", "inputs": { "negative": { "name": "负面条件" }, "positive": { "name": "正面条件" }, "seconds_start": { "name": "开始秒数" }, "seconds_total": { "name": "总秒数" } }, "outputs": { "0": { "name": "正面条件" }, "1": { "name": "负面条件" } } };
const ConditioningTimestepsRange = { "display_name": "条件间隔范围", "inputs": { "end_percent": { "name": "结束百分比" }, "start_percent": { "name": "开始百分比" } }, "outputs": { "1": { "name": "范围前" }, "2": { "name": "范围后" } } };
const ConditioningZeroOut = { "display_name": "条件零化", "inputs": { "conditioning": { "name": "条件" } } };
const ContextWindowsManual = { "description": "手动设置上下文窗口。", "display_name": "上下文窗口（手动）", "inputs": { "closed_loop": { "name": "闭环", "tooltip": "是否闭合上下文窗口循环；仅适用于循环调度。" }, "context_length": { "name": "上下文长度", "tooltip": "上下文窗口的长度。" }, "context_overlap": { "name": "上下文重叠", "tooltip": "上下文窗口的重叠量。" }, "context_schedule": { "name": "上下文调度", "tooltip": "上下文窗口的步长。" }, "context_stride": { "name": "上下文步幅", "tooltip": "上下文窗口的步幅；仅适用于均匀调度。" }, "dim": { "name": "维度", "tooltip": "应用上下文窗口的维度。" }, "fuse_method": { "name": "融合方法", "tooltip": "用于融合上下文窗口的方法。" }, "model": { "name": "模型", "tooltip": "在采样期间应用上下文窗口的模型。" } }, "outputs": { "0": { "tooltip": "在采样过程中应用上下文窗口的模型。" } } };
const ControlNetApply = { "display_name": "应用ControlNet（旧版）", "inputs": { "conditioning": { "name": "条件" }, "control_net": { "name": "ControlNet" }, "image": { "name": "图像" }, "strength": { "name": "强度" } } };
const ControlNetApplyAdvanced = { "display_name": "应用ControlNet（旧版高级）", "inputs": { "control_net": { "name": "ControlNet" }, "end_percent": { "name": "结束百分比" }, "image": { "name": "图像" }, "negative": { "name": "负面条件" }, "positive": { "name": "正面条件" }, "start_percent": { "name": "开始百分比" }, "strength": { "name": "强度" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "正面条件" }, "1": { "name": "负面条件" } } };
const ControlNetApplySD3 = { "display_name": "应用ControlNet", "inputs": { "control_net": { "name": "ControlNet" }, "end_percent": { "name": "结束百分比" }, "image": { "name": "图像" }, "negative": { "name": "负面条件" }, "positive": { "name": "正面条件" }, "start_percent": { "name": "开始百分比" }, "strength": { "name": "强度" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "正面条件", "tooltip": null }, "1": { "name": "负面条件", "tooltip": null } } };
const ControlNetInpaintingAliMamaApply = { "display_name": "应用ControlNet（阿里妈妈局部重绘）", "inputs": { "control_net": { "name": "ControlNet" }, "end_percent": { "name": "结束百分比" }, "image": { "name": "图像" }, "mask": { "name": "遮罩" }, "negative": { "name": "负面条件" }, "positive": { "name": "正面条件" }, "start_percent": { "name": "开始百分比" }, "strength": { "name": "强度" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "正面条件", "tooltip": null }, "1": { "name": "负面条件", "tooltip": null } } };
const ControlNetLoader = { "display_name": "加载ControlNet模型", "inputs": { "control_net_name": { "name": "ControlNet名称" } } };
const CosmosImageToVideoLatent = { "display_name": "Cosmos图像到视频潜在", "inputs": { "batch_size": { "name": "批量大小" }, "end_image": { "name": "结束图像" }, "height": { "name": "高度" }, "length": { "name": "长度" }, "start_image": { "name": "开始图像" }, "vae": { "name": "vae" }, "width": { "name": "宽度" } }, "outputs": { "0": { "tooltip": null } } };
const CosmosPredict2ImageToVideoLatent = { "display_name": "CosmosPredict2图像到视频Latent", "inputs": { "batch_size": { "name": "批次大小" }, "end_image": { "name": "结束图像" }, "height": { "name": "高度" }, "length": { "name": "长度" }, "start_image": { "name": "起始图像" }, "vae": { "name": "vae" }, "width": { "name": "宽度" } }, "outputs": { "0": { "tooltip": null } } };
const CreateHookKeyframe = { "display_name": "创建约束关键帧", "inputs": { "prev_hook_kf": { "name": "前一个约束关键帧" }, "start_percent": { "name": "开始百分比" }, "strength_mult": { "name": "强度倍数" } }, "outputs": { "0": { "name": "约束关键帧" } } };
const CreateHookKeyframesFromFloats = { "display_name": "从浮点数创建约束关键帧", "inputs": { "end_percent": { "name": "结束百分比" }, "floats_strength": { "name": "浮点强度" }, "prev_hook_kf": { "name": "前一个约束关键帧" }, "print_keyframes": { "name": "打印关键帧" }, "start_percent": { "name": "开始百分比" } }, "outputs": { "0": { "name": "约束关键帧" } } };
const CreateHookKeyframesInterpolated = { "display_name": "创建约束关键帧插值", "inputs": { "end_percent": { "name": "结束百分比" }, "interpolation": { "name": "插值" }, "keyframes_count": { "name": "关键帧数量" }, "prev_hook_kf": { "name": "前一个约束关键帧" }, "print_keyframes": { "name": "打印关键帧" }, "start_percent": { "name": "开始百分比" }, "strength_end": { "name": "结束强度" }, "strength_start": { "name": "开始强度" } }, "outputs": { "0": { "name": "约束关键帧" } } };
const CreateHookLora = { "display_name": "创建约束LoRA", "inputs": { "lora_name": { "name": "LoRA名称" }, "prev_hooks": { "name": "前一个约束" }, "strength_clip": { "name": "CLIP强度" }, "strength_model": { "name": "模型强度" } } };
const CreateHookLoraModelOnly = { "display_name": "创建约束LoRA（仅模型）", "inputs": { "lora_name": { "name": "LoRA名称" }, "prev_hooks": { "name": "前一个约束" }, "strength_model": { "name": "模型强度" } } };
const CreateHookModelAsLora = { "display_name": "创建约束模型为LoRA", "inputs": { "ckpt_name": { "name": "Checkpoint名称" }, "prev_hooks": { "name": "前一个约束" }, "strength_clip": { "name": "CLIP强度" }, "strength_model": { "name": "模型强度" } } };
const CreateHookModelAsLoraModelOnly = { "display_name": "创建约束模型为LoRA（仅模型）", "inputs": { "ckpt_name": { "name": "Checkpoint名称" }, "prev_hooks": { "name": "前一个约束" }, "strength_model": { "name": "模型强度" } } };
const CreateVideo = { "description": "从图像创建视频。", "display_name": "创建视频", "inputs": { "audio": { "name": "音频", "tooltip": "要添加到视频中的音频。" }, "fps": { "name": "帧率" }, "images": { "name": "图像", "tooltip": "用于创建视频的图像。" } }, "outputs": { "0": { "tooltip": null } } };
const CropMask = { "display_name": "裁剪遮罩", "inputs": { "height": { "name": "高度" }, "mask": { "name": "遮罩" }, "width": { "name": "宽度" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const DiffControlNetLoader = { "display_name": "加载ControlNet模型（diff）", "inputs": { "control_net_name": { "name": "ControlNet名称" }, "model": { "name": "模型" } } };
const DifferentialDiffusion = { "display_name": "差异扩散DifferentialDiffusion", "inputs": { "model": { "name": "模型" }, "strength": { "name": "强度" } }, "outputs": { "0": { "tooltip": null } } };
const DiffusersLoader = { "display_name": "Diffusers加载器", "inputs": { "model_path": { "name": "模型路径" } } };
const DisableNoise = { "display_name": "禁用噪波" };
const DualCFGGuider = { "display_name": "双CFG引导器", "inputs": { "cfg_cond2_negative": { "name": "cfg_条件2_负面" }, "cfg_conds": { "name": "cfg_条件1" }, "cond1": { "name": "条件1" }, "cond2": { "name": "条件2" }, "model": { "name": "模型" }, "negative": { "name": "负面条件" }, "style": { "name": "样式" } } };
const DualCLIPLoader = { "description": "[配方]\n\nSDXL：clip-l，clip-g\nSD3：clip-l，clip-g / clip-l，t5 / clip-g，t5\nFlux：clip-l，t5", "display_name": "双CLIP加载器", "inputs": { "clip_name1": { "name": "CLIP名称1" }, "clip_name2": { "name": "CLIP名称2" }, "device": { "name": "设备" }, "type": { "name": "类型" } } };
const EasyCache = { "description": "原生 EasyCache 实现。", "display_name": "EasyCache", "inputs": { "end_percent": { "name": "结束位置", "tooltip": "结束使用 EasyCache 的相对采样步数。" }, "model": { "name": "模型", "tooltip": "要添加 EasyCache 的模型。" }, "reuse_threshold": { "name": "重用阈值", "tooltip": "重用缓存步骤的阈值。" }, "start_percent": { "name": "开始位置", "tooltip": "开始使用 EasyCache 的相对采样步数。" }, "verbose": { "name": "调试信息", "tooltip": "是否记录详细信息。" } }, "outputs": { "0": { "tooltip": "带有 EasyCache 的模型。" } } };
const EmptyAceStepLatentAudio = { "display_name": "空Latent音频（AceStep）", "inputs": { "batch_size": { "name": "批次大小", "tooltip": "批次中的 Latent 数量。" }, "seconds": { "name": "秒数" } }, "outputs": { "0": { "tooltip": null } } };
const EmptyAudio = { "display_name": "空音频", "inputs": { "channels": { "name": "通道", "tooltip": "音频通道数（1 为单声道，2 为立体声）。" }, "duration": { "name": "长度", "tooltip": "空音频片段的持续时间（秒）" }, "sample_rate": { "name": "采样率", "tooltip": "空音频片段的采样率。" } } };
const EmptyChromaRadianceLatentImage = { "display_name": "空Latent图像（ChromaRadiance）", "inputs": { "batch_size": { "name": "批次大小" }, "height": { "name": "高度" }, "width": { "name": "宽度" } }, "outputs": { "0": { "tooltip": null } } };
const EmptyCosmosLatentVideo = { "display_name": "空的Cosmos潜在视频", "inputs": { "batch_size": { "name": "批量大小" }, "height": { "name": "高度" }, "length": { "name": "长度" }, "width": { "name": "宽度" } }, "outputs": { "0": { "tooltip": null } } };
const EmptyHunyuanImageLatent = { "display_name": "空Latent图像", "inputs": { "batch_size": { "name": "批次大小" }, "height": { "name": "高度" }, "width": { "name": "宽度" } }, "outputs": { "0": { "tooltip": null } } };
const EmptyHunyuanLatentVideo = { "display_name": "空Latent视频（Hunyuan）", "inputs": { "batch_size": { "name": "批量大小" }, "height": { "name": "高度" }, "length": { "name": "长度" }, "width": { "name": "宽度" } }, "outputs": { "0": { "tooltip": null } } };
const EmptyHunyuanVideo15Latent = { "display_name": "空Latent视频（Hunyuan1.5）", "inputs": { "batch_size": { "name": "批次大小" }, "height": { "name": "高度" }, "length": { "name": "时长" }, "width": { "name": "宽度" } }, "outputs": { "0": { "tooltip": null } } };
const EmptyImage = { "display_name": "空图像", "inputs": { "batch_size": { "name": "批量大小" }, "color": { "name": "颜色" }, "height": { "name": "高度" }, "width": { "name": "宽度" } } };
const EmptyLTXVLatentVideo = { "display_name": "空Latent视频（LTXV）", "inputs": { "batch_size": { "name": "批量大小" }, "height": { "name": "高度" }, "length": { "name": "长度" }, "width": { "name": "宽度" } }, "outputs": { "0": { "tooltip": null } } };
const EmptyLatentAudio = { "display_name": "空Latent音频", "inputs": { "batch_size": { "name": "批量大小", "tooltip": "批次中的Latent数量。" }, "seconds": { "name": "秒" } } };
const EmptyLatentHunyuan3Dv2 = { "display_name": "空Latent图像（Hunyuan3Dv2）", "inputs": { "batch_size": { "name": "批次大小", "tooltip": "批次中的Latent数量。" }, "resolution": { "name": "分辨率" } } };
const EmptyLatentImage = { "description": "创建一批新的空Latent图像，以通过采样进行降噪。", "display_name": "空Latent图像", "inputs": { "batch_size": { "name": "批量大小", "tooltip": "批次中的Latent数量。" }, "height": { "name": "高度", "tooltip": "Latent图像的高度（像素）。" }, "width": { "name": "宽度", "tooltip": "Latent图像的宽度（像素）。" } }, "outputs": { "0": { "tooltip": "空Latent图像批次。" } } };
const EmptyMochiLatentVideo = { "display_name": "空Latent视频（Mochi）", "inputs": { "batch_size": { "name": "批量大小" }, "height": { "name": "高度" }, "length": { "name": "长度" }, "width": { "name": "宽度" } }, "outputs": { "0": { "tooltip": null } } };
const EmptySD3LatentImage = { "display_name": "空Latent图像（SD3）", "inputs": { "batch_size": { "name": "批量大小" }, "height": { "name": "高度" }, "width": { "name": "宽度" } }, "outputs": { "0": { "tooltip": null } } };
const ExponentialScheduler = { "display_name": "Exponential调度器", "inputs": { "sigma_max": { "name": "最大Sigma" }, "sigma_min": { "name": "最新Sigma" }, "steps": { "name": "步数" } } };
const ExtendIntermediateSigmas = { "display_name": "插值扩展Sigmas", "inputs": { "end_at_sigma": { "name": "结束 sigma" }, "sigmas": { "name": "sigmas" }, "spacing": { "name": "间距方式" }, "start_at_sigma": { "name": "起始 sigma" }, "steps": { "name": "步数" } } };
const FeatherMask = { "display_name": "羽化遮罩", "inputs": { "bottom": { "name": "底" }, "left": { "name": "左" }, "mask": { "name": "遮罩" }, "right": { "name": "右" }, "top": { "name": "顶" } } };
const FlipSigmas = { "display_name": "翻转Sigma", "inputs": { "sigmas": { "name": "sigmas" } } };
const FluxDisableGuidance = { "description": "此节点完全禁用Flux和类似Flux模型上的指导嵌入", "display_name": "Flux禁用指导", "inputs": { "conditioning": { "name": "条件" } }, "outputs": { "0": { "tooltip": null } } };
const FluxGuidance = { "display_name": "Flux引导", "inputs": { "conditioning": { "name": "条件" }, "guidance": { "name": "引导" } }, "outputs": { "0": { "tooltip": null } } };
const FluxKontextImageScale = { "description": "此节点将图像调整为更适合 flux kontext 的尺寸。", "display_name": "图像缩放为FluxKontext", "inputs": { "image": { "name": "图像" } }, "outputs": { "0": { "tooltip": null } } };
const FluxKontextMaxImageNode = { "description": "使用Flux.1 Kontext [max]通过API基于提示词和宽高比编辑图像。", "display_name": "Flux.1 Kontext [max] 图像", "inputs": { "aspect_ratio": { "name": "宽高比", "tooltip": "图像宽高比；必须在1:4和4:1之间。" }, "control_after_generate": { "name": "生成后控制" }, "guidance": { "name": "引导强度", "tooltip": "图像生成过程的引导强度" }, "input_image": { "name": "输入图像" }, "prompt": { "name": "提示词", "tooltip": "图像生成的提示词 - 指定编辑内容和方式。" }, "prompt_upsampling": { "name": "提示词上采样", "tooltip": "是否对提示词执行上采样。如果启用，会自动修改提示词以获得更具创意的生成结果，但结果具有不确定性（相同种子不会产生完全相同的结果）。" }, "seed": { "name": "种子", "tooltip": "用于创建噪声的随机种子。" }, "steps": { "name": "步数", "tooltip": "图像生成过程的步数" } }, "outputs": { "0": { "tooltip": null } } };
const FluxKontextMultiReferenceLatentMethod = { "display_name": "FluxKontext多参考潜在方法", "inputs": { "conditioning": { "name": "条件化" }, "reference_latents_method": { "name": "参考潜在方法" } }, "outputs": { "0": { "tooltip": null } } };
const FluxKontextProImageNode = { "description": "使用Flux.1 Kontext [pro]通过API基于提示词和宽高比编辑图像。", "display_name": "Flux.1 Kontext [pro] 图像", "inputs": { "aspect_ratio": { "name": "宽高比", "tooltip": "图像宽高比；必须在1:4到4:1之间。" }, "control_after_generate": { "name": "生成后控制" }, "guidance": { "name": "引导强度", "tooltip": "图像生成过程的引导强度" }, "input_image": { "name": "输入图像" }, "prompt": { "name": "提示词", "tooltip": "图像生成的提示词 - 指定编辑内容和方式。" }, "prompt_upsampling": { "name": "提示词上采样", "tooltip": "是否对提示词执行上采样。如果启用，会自动修改提示词以获得更具创意的生成结果，但结果具有不确定性（相同种子不会产生完全相同的结果）。" }, "seed": { "name": "种子", "tooltip": "用于创建噪声的随机种子。" }, "steps": { "name": "步数", "tooltip": "图像生成过程的步数" } }, "outputs": { "0": { "tooltip": null } } };
const FluxProExpandNode = { "description": "根据提示词对图像进行外扩。", "display_name": "Flux.1 扩展图像", "inputs": { "bottom": { "name": "下方扩展", "tooltip": "在图像底部扩展的像素数" }, "control_after_generate": { "name": "生成后控制" }, "guidance": { "name": "引导强度", "tooltip": "图像生成过程中的引导强度" }, "image": { "name": "图像" }, "left": { "name": "左侧扩展", "tooltip": "在图像左侧扩展的像素数" }, "prompt": { "name": "提示词", "tooltip": "用于生成图像的提示词" }, "prompt_upsampling": { "name": "提示词上采样", "tooltip": "是否对提示词进行上采样。启用后会自动修改提示词以获得更具创意的生成效果，但结果具有不确定性（相同种子不会产生完全相同的结果）。" }, "right": { "name": "右侧扩展", "tooltip": "在图像右侧扩展的像素数" }, "seed": { "name": "种子", "tooltip": "用于生成噪声的随机种子。" }, "steps": { "name": "步数", "tooltip": "图像生成过程的步数" }, "top": { "name": "上方扩展", "tooltip": "在图像顶部扩展的像素数" } }, "outputs": { "0": { "tooltip": null } } };
const FluxProFillNode = { "description": "根据 mask 和提示词对图像进行修复填充。", "display_name": "Flux.1 填充图像", "inputs": { "control_after_generate": { "name": "生成后控制" }, "guidance": { "name": "引导强度", "tooltip": "图像生成过程中的引导强度" }, "image": { "name": "图像" }, "mask": { "name": "遮罩" }, "prompt": { "name": "提示词", "tooltip": "用于图像生成的提示词" }, "prompt_upsampling": { "name": "提示词上采样", "tooltip": "是否对提示词进行上采样。启用后会自动修改提示词以获得更具创意的生成效果，但结果具有不确定性（相同种子不会产生完全相同的结果）。" }, "seed": { "name": "种子", "tooltip": "用于生成噪声的随机种子。" }, "steps": { "name": "步数", "tooltip": "图像生成过程的步数" } }, "outputs": { "0": { "tooltip": null } } };
const FluxProUltraImageNode = { "description": "通过 API 使用 Flux Pro 1.1 Ultra 根据提示词和分辨率生成图像。", "display_name": "Flux 1.1 [pro] Ultra Image", "inputs": { "aspect_ratio": { "name": "宽高比", "tooltip": "图像的宽高比；必须在 1:4 到 4:1 之间。" }, "control_after_generate": { "name": "生成后控制" }, "image_prompt": { "name": "图像提示词" }, "image_prompt_strength": { "name": "图像提示词强度", "tooltip": "在提示词和图像提示词之间进行混合。" }, "prompt": { "name": "提示词", "tooltip": "用于图像生成的提示词" }, "prompt_upsampling": { "name": "提示词上采样", "tooltip": "是否对提示词进行上采样。启用时，会自动修改提示词以获得更具创意的生成效果，但结果是非确定性的（相同种子不会产生完全相同的结果）。" }, "raw": { "name": "原始", "tooltip": "为 True 时，生成更少处理、更自然的图像。" }, "seed": { "name": "种子", "tooltip": "用于生成噪声的随机种子。" } }, "outputs": { "0": { "tooltip": null } } };
const FreSca = { "description": "对引导应用频率相关的缩放", "display_name": "FreSca", "inputs": { "freq_cutoff": { "name": "低频阈值", "tooltip": "围绕中心被视为低频的频率索引数量" }, "model": { "name": "模型" }, "scale_high": { "name": "高频缩放", "tooltip": "高频分量的缩放因子" }, "scale_low": { "name": "低频缩放", "tooltip": "低频分量的缩放因子" } }, "outputs": { "0": { "tooltip": null } } };
const FreeU = { "display_name": "FreeU", "inputs": { "b1": { "name": "b1" }, "b2": { "name": "b2" }, "model": { "name": "模型" }, "s1": { "name": "s1" }, "s2": { "name": "s2" } } };
const FreeU_V2 = { "display_name": "FreeU_V2", "inputs": { "b1": { "name": "b1" }, "b2": { "name": "b2" }, "model": { "name": "模型" }, "s1": { "name": "s1" }, "s2": { "name": "s2" } } };
const GITSScheduler = { "display_name": "GITS调度器", "inputs": { "coeff": { "name": "系数" }, "denoise": { "name": "降噪" }, "steps": { "name": "步数" } }, "outputs": { "0": { "tooltip": null } } };
const GLIGENLoader = { "display_name": "GLIGEN加载器", "inputs": { "gligen_name": { "name": "gligen名称" } } };
const GLIGENTextBoxApply = { "display_name": "GLIGEN文本框应用", "inputs": { "clip": { "name": "CLIP" }, "conditioning_to": { "name": "条件到" }, "gligen_textbox_model": { "name": "GLIGEN文本框模型" }, "height": { "name": "高度" }, "text": { "name": "文本" }, "width": { "name": "宽度" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const GeminiImage2Node = { "description": "通过Google API编辑图像。", "display_name": "Nano Banana Pro（Google Gemini 图像）", "inputs": { "aspect_ratio": { "name": "宽高比", "tooltip": "自动：会自动匹配输入图像的宽高比，或如果没有提供图像，则生成1:1的正方形。" }, "control_after_generate": { "name": "生成后控制" }, "files": { "name": "文件", "tooltip": "模型上下文文件。接受来自 Gemini输入文件 节点的输入。" }, "images": { "name": "图像", "tooltip": "参考图像。如果要使用多个参考图，使用 图像批次 节点（最多14张）。" }, "model": { "name": "模型" }, "prompt": { "name": "提示词", "tooltip": "使用文本描述要生成的图像或要应用的编辑的内容。包括模型应该遵循的任何约束、样式或细节。" }, "resolution": { "name": "分辨率", "tooltip": "目标分辨率。2K/4K 会使用 Gemini 放大生成。" }, "response_modalities": { "name": "响应模态", "tooltip": "选择 图像 仅生成图像，选择 图像+文本 会生成图像和文本。" }, "seed": { "name": "随机种", "tooltip": "为特定值时，模型将尽可能提供相同的结果。但不保证确定一致的输出。此外，即使使用相同的种子值，更改模型或参数设置（例如温度）也会导致结果变化。默认使用随机值。" } }, "outputs": { "0": { "tooltip": null }, "1": { "tooltip": null } } };
const GeminiImageNode = { "description": "通过Google API同步编辑图像。", "display_name": "Nano Banana （Google Gemini 图像）", "inputs": { "aspect_ratio": { "name": "宽高比", "tooltip": "默认匹配输入图像的输出尺寸，否则生成1:1正方形。" }, "control_after_generate": { "name": "生成后控制" }, "files": { "name": "文件", "tooltip": "可选文件，用作模型的上下文。接受来自Gemini生成内容输入文件节点的输入。" }, "images": { "name": "图像", "tooltip": "可选图像，用作模型的上下文。要包含多个图像，可以使用批量图像节点。" }, "model": { "name": "模型", "tooltip": "用于生成响应的Gemini模型。" }, "prompt": { "name": "提示词", "tooltip": "用于生成的文本提示词" }, "seed": { "name": "种子", "tooltip": "当种子固定为特定值时，模型会尽力为重复请求提供相同的响应。不能保证确定性输出。此外，更改模型或参数设置（如温度）即使使用相同的种子值也可能导致响应变化。默认使用随机种子值。" } }, "outputs": { "0": { "tooltip": null }, "1": { "tooltip": null } } };
const GeminiInputFiles = { "description": "加载并准备输入文件，作为 Gemini LLM 节点的输入。文件将在生成响应时由 Gemini 模型读取。文本文件的内容计入令牌限制。🛈 提示：可与其他 Gemini 输入文件节点链式连接。", "display_name": "Gemini 输入文件", "inputs": { "GEMINI_INPUT_FILES": { "name": "Gemini 输入文件", "tooltip": "与此节点加载的文件批量组合的可选附加文件。允许链式连接输入文件，以便单个消息可包含多个输入文件。" }, "file": { "name": "文件", "tooltip": "作为模型上下文包含的输入文件。目前仅接受文本 (.txt) 和 PDF (.pdf) 文件。" } }, "outputs": { "0": { "tooltip": null } } };
const GeminiNode = { "description": "使用 Google 的 Gemini AI 模型生成文本响应。您可以提供多种类型的输入（文本、图像、音频、视频）作为上下文，以生成更相关和有意义的响应。", "display_name": "Google Gemini", "inputs": { "audio": { "name": "音频", "tooltip": "用作模型上下文的可选音频。" }, "control_after_generate": { "name": "生成后控制" }, "files": { "name": "文件", "tooltip": "用作模型上下文的可选文件。接受来自 Gemini 生成内容输入文件节点的输入。" }, "images": { "name": "图像", "tooltip": "用作模型上下文的可选图像。要包含多个图像，可使用批处理图像节点。" }, "model": { "name": "模型", "tooltip": "用于生成响应的 Gemini 模型。" }, "prompt": { "name": "提示", "tooltip": "模型的文本输入，用于生成响应。您可以包含详细的指令、问题或模型上下文。" }, "seed": { "name": "种子", "tooltip": "当种子固定为特定值时，模型会尽力为重复请求提供相同的响应。不保证确定性输出。此外，更改模型或参数设置（如温度）即使使用相同的种子值也可能导致响应变化。默认使用随机种子值。" }, "video": { "name": "视频", "tooltip": "用作模型上下文的可选视频。" } }, "outputs": { "0": { "tooltip": null } } };
const GetImageSize = { "description": "返回图像的宽度和高度，并原样传递图像。", "display_name": "获取图像尺寸", "inputs": { "image": { "name": "图像" } }, "outputs": { "0": { "name": "宽度" }, "1": { "name": "高度" }, "2": { "name": "批处理大小" } } };
const GetVideoComponents = { "description": "提取视频中的所有组件：帧、音频和帧率。", "display_name": "获取视频组件", "inputs": { "video": { "name": "视频", "tooltip": "要提取组件的视频。" } }, "outputs": { "0": { "name": "图像", "tooltip": null }, "1": { "name": "音频", "tooltip": null }, "2": { "name": "帧率", "tooltip": null } } };
const GrowMask = { "display_name": "扩展遮罩", "inputs": { "expand": { "name": "扩展" }, "mask": { "name": "遮罩" }, "tapered_corners": { "name": "倒角" } } };
const Hunyuan3Dv2Conditioning = { "display_name": "Hunyuan3Dv2条件", "inputs": { "clip_vision_output": { "name": "clip视觉输出" } }, "outputs": { "0": { "name": "正向" }, "1": { "name": "反向" } } };
const Hunyuan3Dv2ConditioningMultiView = { "display_name": "Hunyuan3Dv2条件多视角", "inputs": { "back": { "name": "后" }, "front": { "name": "前" }, "left": { "name": "左" }, "right": { "name": "右" } }, "outputs": { "0": { "name": "正向" }, "1": { "name": "反向" } } };
const HunyuanImageToVideo = { "display_name": "Hunyuan图像到视频", "inputs": { "batch_size": { "name": "批量大小" }, "guidance_type": { "name": "指导类型" }, "height": { "name": "高度" }, "length": { "name": "长度" }, "positive": { "name": "正向" }, "start_image": { "name": "起始图像" }, "vae": { "name": "vae" }, "width": { "name": "宽度" } }, "outputs": { "0": { "name": "正向", "tooltip": null }, "1": { "name": "Latent", "tooltip": null } } };
const HunyuanRefinerLatent = { "display_name": "HunyuanRefinerLatent", "inputs": { "latent": { "name": "Latent" }, "negative": { "name": "负面" }, "noise_augmentation": { "name": "噪声增强" }, "positive": { "name": "正面" } }, "outputs": { "0": { "name": "正面", "tooltip": null }, "1": { "name": "负面", "tooltip": null }, "2": { "name": "潜在", "tooltip": null } } };
const HunyuanVideo15ImageToVideo = { "display_name": "Hunyuan Video 15 图像到视频", "inputs": { "batch_size": { "name": "批次大小" }, "clip_vision_output": { "name": "CLIP视觉输出" }, "height": { "name": "高度" }, "length": { "name": "帧数" }, "negative": { "name": "负面条件" }, "positive": { "name": "正面条件" }, "start_image": { "name": "图像" }, "vae": { "name": "vae" }, "width": { "name": "宽度" } }, "outputs": { "0": { "name": "正面条件", "tooltip": null }, "1": { "name": "负面条件", "tooltip": null }, "2": { "name": "latent", "tooltip": null } } };
const HunyuanVideo15LatentUpscaleWithModel = { "display_name": "Hunyuan Video 15 Latent 使用模型放大", "inputs": { "crop": { "name": "裁剪" }, "height": { "name": "高度" }, "model": { "name": "模型" }, "samples": { "name": "Latent" }, "upscale_method": { "name": "放大方法" }, "width": { "name": "宽度" } }, "outputs": { "0": { "tooltip": null } } };
const HunyuanVideo15SuperResolution = { "display_name": "Hunyuan Video 15超分辨率", "inputs": { "clip_vision_output": { "name": "CLIP视觉输出" }, "latent": { "name": "latent" }, "negative": { "name": "负面条件" }, "noise_augmentation": { "name": "噪波增强" }, "positive": { "name": "正面条件" }, "start_image": { "name": "图像" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "正面条件", "tooltip": null }, "1": { "name": "负面条件", "tooltip": null }, "2": { "name": "Latent", "tooltip": null } } };
const HyperTile = { "display_name": "超分块HyperTile", "inputs": { "max_depth": { "name": "最大深度" }, "model": { "name": "模型" }, "scale_depth": { "name": "规模深度" }, "swap_size": { "name": "分割尺寸" }, "tile_size": { "name": "分块尺寸" } }, "outputs": { "0": { "tooltip": null } } };
const HypernetworkLoader = { "display_name": "超网络加载器", "inputs": { "hypernetwork_name": { "name": "HyperNetwork名称" }, "model": { "name": "模型" }, "strength": { "name": "强度" } }, "outputs": { "0": { "tooltip": null } } };
const IdeogramV1 = { "description": "使用 Ideogram V1 模型同步生成图像。\n\n图片链接仅在有限时间内有效；如果您想保留图片，请务必下载。", "display_name": "Ideogram V1", "inputs": { "aspect_ratio": { "name": "宽高比", "tooltip": "图像生成的宽高比。" }, "control_after_generate": { "name": "生成后控制" }, "magic_prompt_option": { "name": "Magic Prompt", "tooltip": "确定生成时是否使用 MagicPrompt" }, "negative_prompt": { "name": "负面提示词", "tooltip": "描述需要从图像中排除的内容" }, "num_images": { "name": "图像数量" }, "prompt": { "name": "提示词", "tooltip": "用于图像生成的提示词" }, "seed": { "name": "随机种" }, "turbo": { "name": "turbo", "tooltip": "是否启用 turbo 模式（生成更快，但可能质量较低）" } }, "outputs": { "0": { "tooltip": null } } };
const IdeogramV2 = { "description": "使用 Ideogram V2 模型同步生成图像。\n\n图像链接仅在有限时间内有效；如果您想保留图像，请务必下载。", "display_name": "Ideogram V2", "inputs": { "aspect_ratio": { "name": "宽高比", "tooltip": "图像生成的宽高比。如果分辨率未设置为 AUTO，则此项无效。" }, "control_after_generate": { "name": "生成后控制" }, "magic_prompt_option": { "name": "Magic Prompt", "tooltip": "确定生成时是否使用 MagicPrompt" }, "negative_prompt": { "name": "负面提示词", "tooltip": "描述图像中需要排除的内容" }, "num_images": { "name": "图像数量" }, "prompt": { "name": "提示词", "tooltip": "用于图像生成的提示词" }, "resolution": { "name": "分辨率", "tooltip": "图像生成的分辨率。如果未设置为 AUTO，则会覆盖 aspect_ratio 设置。" }, "seed": { "name": "随机种" }, "style_type": { "name": "风格", "tooltip": "生成的风格类型（仅限 V2）" }, "turbo": { "name": "turbo", "tooltip": "是否启用 turbo 模式（生成更快，质量可能略低）" } }, "outputs": { "0": { "tooltip": null } } };
const IdeogramV3 = { "description": "使用 Ideogram V3 模型同步生成图像。\n\n支持从文本提示生成常规图像，也支持使用 mask 进行图像编辑。\n图片链接仅在有限时间内有效；如需保留图片，请务必下载。", "display_name": "Ideogram V3", "inputs": { "aspect_ratio": { "name": "宽高比", "tooltip": "图像生成的宽高比。如果分辨率未设置为自动，则忽略此项。" }, "character_image": { "name": "角色图像", "tooltip": "用作角色参考的图像。" }, "character_mask": { "name": "角色遮罩", "tooltip": "角色参考图像的可选遮罩。" }, "control_after_generate": { "name": "生成后控制" }, "image": { "name": "图像", "tooltip": "用于图像编辑的可选参考图片。" }, "magic_prompt_option": { "name": "Magic Prompt", "tooltip": "决定生成时是否使用 MagicPrompt" }, "mask": { "name": "遮罩", "tooltip": "用于修复的可选 mask（白色区域将被替换）" }, "num_images": { "name": "图像数量" }, "prompt": { "name": "提示词", "tooltip": "用于图像生成或编辑的提示词" }, "rendering_speed": { "name": "生成速度", "tooltip": "控制生成速度与质量之间的权衡" }, "resolution": { "name": "分辨率", "tooltip": "图像生成的分辨率。如果未设置为自动，则覆盖 aspect_ratio 设置。" }, "seed": { "name": "随机种" } }, "outputs": { "0": { "tooltip": null } } };
const ImageAddNoise = { "display_name": "图像添加噪声", "inputs": { "control_after_generate": { "name": "生成后控制" }, "image": { "name": "图像" }, "seed": { "name": "种子", "tooltip": "用于创建噪声的随机种子。" }, "strength": { "name": "强度" } } };
const ImageBatch = { "display_name": "组合图像批次", "inputs": { "image1": { "name": "图像1" }, "image2": { "name": "图像2" } } };
const ImageBlend = { "display_name": "混合图像", "inputs": { "blend_factor": { "name": "系数" }, "blend_mode": { "name": "混合模式" }, "image1": { "name": "图像1" }, "image2": { "name": "图像2" } }, "outputs": { "0": { "tooltip": null } } };
const ImageBlur = { "display_name": "模糊图像", "inputs": { "blur_radius": { "name": "模糊半径" }, "image": { "name": "图像" }, "sigma": { "name": "西格玛" } }, "outputs": { "0": { "tooltip": null } } };
const ImageColorToMask = { "display_name": "图像颜色到遮罩", "inputs": { "color": { "name": "颜色" }, "image": { "name": "图像" } } };
const ImageCompositeMasked = { "display_name": "合成图像（遮罩）", "inputs": { "destination": { "name": "目标图像" }, "mask": { "name": "遮罩" }, "resize_source": { "name": "缩放来源图像" }, "source": { "name": "来源图像" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const ImageCrop = { "display_name": "裁剪图像", "inputs": { "height": { "name": "高度" }, "image": { "name": "图像" }, "width": { "name": "宽度" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const ImageFlip = { "display_name": "图像翻转", "inputs": { "flip_method": { "name": "翻转方法" }, "image": { "name": "图像" } } };
const ImageFromBatch = { "display_name": "从批次获取图像", "inputs": { "batch_index": { "name": "批次索引" }, "image": { "name": "图像" }, "length": { "name": "长度" } } };
const ImageInvert = { "display_name": "反转图像", "inputs": { "image": { "name": "图像" } } };
const ImageOnlyCheckpointLoader = { "display_name": "Checkpoint加载器（仅图像）", "inputs": { "ckpt_name": { "name": "Checkpoint名称" } } };
const ImageOnlyCheckpointSave = { "display_name": "保存Checkpoint（仅图像）", "inputs": { "clip_vision": { "name": "clip视觉" }, "filename_prefix": { "name": "文件名前缀" }, "model": { "name": "模型" }, "vae": { "name": "vae" } } };
const ImagePadForOutpaint = { "display_name": "外补画板", "inputs": { "bottom": { "name": "下" }, "feathering": { "name": "羽化" }, "image": { "name": "图像" }, "left": { "name": "左" }, "right": { "name": "右" }, "top": { "name": "上" } } };
const ImageQuantize = { "display_name": "量化图像", "inputs": { "colors": { "name": "颜色" }, "dither": { "name": "抖动" }, "image": { "name": "图像" } }, "outputs": { "0": { "tooltip": null } } };
const ImageRGBToYUV = { "display_name": "图像RGB到YUV", "inputs": { "image": { "name": "图像" } }, "outputs": { "0": { "name": "Y", "tooltip": null }, "1": { "name": "U", "tooltip": null }, "2": { "name": "V", "tooltip": null } } };
const ImageRotate = { "display_name": "图像旋转", "inputs": { "image": { "name": "图像" }, "rotation": { "name": "旋转" } } };
const ImageScale = { "display_name": "缩放图像", "inputs": { "crop": { "name": "裁剪" }, "height": { "name": "高度" }, "image": { "name": "图像" }, "upscale_method": { "name": "缩放算法" }, "width": { "name": "宽度" } } };
const ImageScaleBy = { "display_name": "缩放图像（比例）", "inputs": { "image": { "name": "图像" }, "scale_by": { "name": "缩放系数" }, "upscale_method": { "name": "缩放算法" } } };
const ImageScaleToMaxDimension = { "display_name": "图像缩放到最大尺寸", "inputs": { "image": { "name": "图像" }, "largest_size": { "name": "最大尺寸" }, "upscale_method": { "name": "放大方法" } } };
const ImageScaleToTotalPixels = { "display_name": "缩放图像（像素）", "inputs": { "image": { "name": "图像" }, "megapixels": { "name": "像素数量" }, "upscale_method": { "name": "缩放算法" } }, "outputs": { "0": { "tooltip": null } } };
const ImageSharpen = { "display_name": "锐化图像", "inputs": { "alpha": { "name": "alpha" }, "image": { "name": "图像" }, "sharpen_radius": { "name": "锐化半径" }, "sigma": { "name": "Sigma" } }, "outputs": { "0": { "tooltip": null } } };
const ImageStitch = { "description": "\n将 image2 按指定方向拼接到 image1 上。\n如果未提供 image2，则返回未更改的 image1。\n可以在图像之间添加可选间距。\n", "display_name": "图像拼接", "inputs": { "direction": { "name": "方向" }, "image1": { "name": "图像1" }, "image2": { "name": "图像2" }, "match_image_size": { "name": "匹配图像尺寸" }, "spacing_color": { "name": "间距颜色" }, "spacing_width": { "name": "间距宽度" } } };
const ImageToMask = { "display_name": "图像转换为遮罩", "inputs": { "channel": { "name": "通道" }, "image": { "name": "图像" } } };
const ImageUpscaleWithModel = { "display_name": "使用模型放大图像", "inputs": { "image": { "name": "图像" }, "upscale_model": { "name": "放大模型" } }, "outputs": { "0": { "tooltip": null } } };
const ImageYUVToRGB = { "display_name": "图像YUV到RGB", "inputs": { "U": { "name": "U" }, "V": { "name": "V" }, "Y": { "name": "Y" } }, "outputs": { "0": { "tooltip": null } } };
const InpaintModelConditioning = { "display_name": "内补模型条件", "inputs": { "mask": { "name": "遮罩" }, "negative": { "name": "负面条件" }, "noise_mask": { "name": "噪波遮罩", "tooltip": "向Latent图像添加遮罩，采样仅在遮罩内进行。根据模型的不同，可能会改善结果或完全破坏效果。" }, "pixels": { "name": "像素" }, "positive": { "name": "正面条件" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "正面条件" }, "1": { "name": "负面条件" }, "2": { "name": "Latent" } } };
const InstructPixToPixConditioning = { "display_name": "InstructPixToPix条件", "inputs": { "negative": { "name": "负面条件" }, "pixels": { "name": "像素" }, "positive": { "name": "正面条件" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "正面条件", "tooltip": null }, "1": { "name": "负面条件", "tooltip": null }, "2": { "name": "Latent", "tooltip": null } } };
const InvertMask = { "display_name": "反转遮罩", "inputs": { "mask": { "name": "遮罩" } } };
const JoinImageWithAlpha = { "display_name": "合并图像Alpha", "inputs": { "alpha": { "name": "阿尔法" }, "image": { "name": "图像" } }, "outputs": { "0": { "tooltip": null } } };
const KSampler = { "description": "使用提供的模型、正面条件和负面条件条件降噪Latent图像。", "display_name": "K采样器", "inputs": { "cfg": { "name": "cfg", "tooltip": "用于平衡随机性和提示词服从性。提高该值会使结果更加符合提示词，但过高会导致图像质量下降。" }, "control_after_generate": { "name": "生成后的控制" }, "denoise": { "name": "降噪", "tooltip": "降噪的强度，降低该值会保留原图的大部分内容从而实现图生图。" }, "latent_image": { "name": "Latent图像", "tooltip": "要降噪的 Latent 图像。" }, "model": { "name": "模型", "tooltip": "用于降噪输入 Latent 图像的模型。" }, "negative": { "name": "负面条件", "tooltip": "描述不包含在图像中的内容的条件。" }, "positive": { "name": "正面条件", "tooltip": "描述包含在图像中的内容的条件。" }, "sampler_name": { "name": "采样器名称", "tooltip": "采样算法，会影响结果质量、生成速度、风格样式。" }, "scheduler": { "name": "调度器", "tooltip": "控制逐渐移除噪波的方法。" }, "seed": { "name": "种子", "tooltip": "生成噪波的随机种。" }, "steps": { "name": "步数", "tooltip": "降噪的步数。" } }, "outputs": { "0": { "tooltip": "降噪后的 Latent。" } } };
const KSamplerAdvanced = { "display_name": "K采样器（高级）", "inputs": { "add_noise": { "name": "添加噪波" }, "cfg": { "name": "cfg" }, "control_after_generate": { "name": "生成后的控制" }, "end_at_step": { "name": "结束步数" }, "latent_image": { "name": "Latent图像" }, "model": { "name": "模型" }, "negative": { "name": "负面条件" }, "noise_seed": { "name": "随机种" }, "positive": { "name": "正面条件" }, "return_with_leftover_noise": { "name": "返回剩余噪波" }, "sampler_name": { "name": "采样器名称" }, "scheduler": { "name": "调度器" }, "start_at_step": { "name": "开始步数" }, "steps": { "name": "步数" } } };
const KSamplerSelect = { "display_name": "K采样器选择", "inputs": { "sampler_name": { "name": "采样器名称" } } };
const KarrasScheduler = { "display_name": "Karras调度器", "inputs": { "rho": { "name": "rho" }, "sigma_max": { "name": "最大Sigma" }, "sigma_min": { "name": "最小Sigma" }, "steps": { "name": "步数" } } };
const KlingCameraControlI2VNode = { "description": "将静态图像转化为具有专业摄像机运动的电影级视频，模拟真实世界的电影摄影。可控制虚拟摄像机的缩放、旋转、平移、俯仰和第一人称视角，同时保持对原始图像的聚焦。", "display_name": "Kling 图像转视频（摄像机控制）", "inputs": { "aspect_ratio": { "name": "宽高比" }, "camera_control": { "name": "镜头控制", "tooltip": "可通过 Kling Camera Controls 节点创建。控制视频生成过程中的摄像机运动和动作。" }, "cfg_scale": { "name": "CFG" }, "negative_prompt": { "name": "负面提示词", "tooltip": "反向文本提示" }, "prompt": { "name": "提示词", "tooltip": "正向文本提示" }, "start_frame": { "name": "起始帧", "tooltip": "参考图像 - URL 或 Base64 编码字符串，不能超过 10MB，分辨率不低于 300*300 像素，宽高比在 1:2.5 ~ 2.5:1 之间。Base64 不应包含 data:image 前缀。" } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "视频ID", "tooltip": null }, "2": { "name": "时长", "tooltip": null } } };
const KlingCameraControlT2VNode = { "description": "将文本转化为具有专业摄像机运动的电影级视频，模拟真实世界的电影摄影。可控制虚拟摄像机的动作，包括缩放、旋转、平移、俯仰和第一人称视角，同时保持对原始文本的聚焦。", "display_name": "Kling 文本转视频（摄像机控制）", "inputs": { "aspect_ratio": { "name": "宽高比" }, "camera_control": { "name": "镜头控制", "tooltip": "可通过 Kling Camera Controls 节点创建。控制视频生成过程中的摄像机运动和移动。" }, "cfg_scale": { "name": "CFG" }, "negative_prompt": { "name": "负面提示词", "tooltip": "反向文本提示" }, "prompt": { "name": "提示词", "tooltip": "正向文本提示" } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "视频ID", "tooltip": null }, "2": { "name": "时长", "tooltip": null } } };
const KlingCameraControls = { "description": "允许指定 Kling 相机控制和运动控制效果的配置选项。", "display_name": "Kling 相机控制", "inputs": { "camera_control_type": { "name": "镜头类型" }, "horizontal_movement": { "name": "水平移动", "tooltip": "控制相机在水平轴（x 轴）上的移动。负值表示向左，正值表示向右。" }, "pan": { "name": "垂直旋转", "tooltip": "控制相机在垂直平面（x 轴）上的旋转。负值表示向下旋转，正值表示向上旋转。" }, "roll": { "name": "滚转", "tooltip": "控制相机的滚转量（z 轴）。负值表示逆时针，正值表示顺时针。" }, "tilt": { "name": "水平旋转", "tooltip": "控制相机在水平平面（y 轴）上的旋转。负值表示向左旋转，正值表示向右旋转。" }, "vertical_movement": { "name": "垂直移动", "tooltip": "控制相机在垂直轴（y 轴）上的移动。负值表示向下，正值表示向上。" }, "zoom": { "name": "变焦", "tooltip": "控制相机焦距的变化。负值表示视野变窄，正值表示视野变宽。" } }, "outputs": { "0": { "name": "镜头控制", "tooltip": null } } };
const KlingDualCharacterVideoEffectNode = { "description": "根据 效果 在生成视频时实现不同的特效。第一张图片将被放置在合成画面的左侧，第二张图片在右侧。", "display_name": "Kling 双角色视频特效", "inputs": { "duration": { "name": "时长" }, "effect_scene": { "name": "效果" }, "image_left": { "name": "左侧图像", "tooltip": "左侧图片" }, "image_right": { "name": "右侧图像", "tooltip": "右侧图片" }, "mode": { "name": "模式" }, "model_name": { "name": "模型" } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "时长", "tooltip": null } } };
const KlingImage2VideoNode = { "display_name": "Kling 图像转视频", "inputs": { "aspect_ratio": { "name": "宽高比" }, "cfg_scale": { "name": "CFG" }, "duration": { "name": "时长" }, "mode": { "name": "模式" }, "model_name": { "name": "模型" }, "negative_prompt": { "name": "负面提示词", "tooltip": "反向文本提示" }, "prompt": { "name": "提示词", "tooltip": "正向文本提示" }, "start_frame": { "name": "起始帧", "tooltip": "参考图像 - URL 或 Base64 编码字符串，不能超过 10MB，分辨率不少于 300*300 像素，宽高比在 1:2.5 ~ 2.5:1 之间。Base64 不应包含 data:image 前缀。" } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "视频ID", "tooltip": null }, "2": { "name": "时长", "tooltip": null } } };
const KlingImageGenerationNode = { "description": "Kling 图像生成节点。通过文本提示生成图像，可选参考图像。", "display_name": "Kling 图像生成", "inputs": { "aspect_ratio": { "name": "宽高比" }, "human_fidelity": { "name": "主体参考强度", "tooltip": "主体参考相似度" }, "image": { "name": "图像" }, "image_fidelity": { "name": "图像参考强度", "tooltip": "用户上传图像的参考强度" }, "image_type": { "name": "图像类型" }, "model_name": { "name": "模型" }, "n": { "name": "图像数量", "tooltip": "生成图像数量" }, "negative_prompt": { "name": "负面提示词", "tooltip": "反向文本提示" }, "prompt": { "name": "提示词", "tooltip": "正向文本提示" } }, "outputs": { "0": { "tooltip": null } } };
const KlingLipSyncAudioToVideoNode = { "description": "Kling 音频驱动视频口型同步节点。将视频文件中的嘴部动作与音频文件的音频内容进行同步。", "display_name": "Kling 音频驱动视频口型同步", "inputs": { "audio": { "name": "音频" }, "video": { "name": "视频" }, "voice_language": { "name": "语音语言" } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "视频ID", "tooltip": null }, "2": { "name": "时长", "tooltip": null } } };
const KlingLipSyncTextToVideoNode = { "description": "Kling 文字驱动口型同步节点。将视频文件中的嘴部动作与文本提示同步。", "display_name": "Kling 文字驱动口型同步视频", "inputs": { "text": { "name": "文本", "tooltip": "用于口型同步视频生成的文本内容。当模式为 text2video 时必填。最大长度为 120 个字符。" }, "video": { "name": "视频" }, "voice": { "name": "语音" }, "voice_speed": { "name": "语速", "tooltip": "语音速率。有效范围：0.8~2.0，精确到小数点后一位。" } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "视频ID", "tooltip": null }, "2": { "name": "时长", "tooltip": null } } };
const KlingSingleImageVideoEffectNode = { "description": "根据 效果 在生成视频时实现不同的特效。", "display_name": "Kling 视频特效", "inputs": { "duration": { "name": "时长" }, "effect_scene": { "name": "效果" }, "image": { "name": "图像3", "tooltip": "参考图片。URL 或 Base64 编码字符串（不含 data:image 前缀）。文件大小不得超过 10MB，分辨率不低于 300*300 像素，宽高比在 1:2.5 ~ 2.5:1 之间。" }, "model_name": { "name": "模型" } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "视频ID", "tooltip": null }, "2": { "name": "时长", "tooltip": null } } };
const KlingStartEndFrameNode = { "description": "生成一个在起始图像和结束图像之间过渡的视频序列。该节点会创建所有中间帧，实现从第一帧到最后一帧的平滑变换。", "display_name": "Kling 起止帧生成视频", "inputs": { "aspect_ratio": { "name": "宽高比" }, "cfg_scale": { "name": "CFG" }, "end_frame": { "name": "end_frame", "tooltip": "参考图像 - 结束帧控制。URL 或 Base64 编码字符串，不能超过 10MB，分辨率不低于 300*300 像素。Base64 不应包含 data:image 前缀。" }, "mode": { "name": "模式", "tooltip": "用于视频生成的配置，格式为：mode / duration / model_name。" }, "negative_prompt": { "name": "负面提示词", "tooltip": "反向文本提示" }, "prompt": { "name": "提示词", "tooltip": "正向文本提示" }, "start_frame": { "name": "起始帧", "tooltip": "参考图像 - URL 或 Base64 编码字符串，不能超过 10MB，分辨率不低于 300*300 像素，宽高比在 1:2.5 ~ 2.5:1 之间。Base64 不应包含 data:image 前缀。" } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "视频ID", "tooltip": null }, "2": { "name": "时长", "tooltip": null } } };
const KlingTextToVideoNode = { "description": "Kling 文本转视频节点", "display_name": "Kling 文本转视频", "inputs": { "aspect_ratio": { "name": "宽高比" }, "cfg_scale": { "name": "CFG" }, "mode": { "name": "模式", "tooltip": "用于视频生成的配置，格式为：mode / duration / model_name。" }, "negative_prompt": { "name": "负面提示词", "tooltip": "反向文本提示" }, "prompt": { "name": "提示词", "tooltip": "正向文本提示" } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "视频ID", "tooltip": null }, "2": { "name": "时长", "tooltip": null } } };
const KlingVideoExtendNode = { "description": "Kling 视频扩展节点。扩展由其他 Kling 节点生成的视频。video_id 由其他 Kling 节点生成。", "display_name": "Kling 视频扩展", "inputs": { "cfg_scale": { "name": "CFG" }, "negative_prompt": { "name": "负面提示词", "tooltip": "用于在扩展视频中避免出现的元素的负向文本提示" }, "prompt": { "name": "提示词", "tooltip": "用于引导视频扩展的正向文本提示" }, "video_id": { "name": "视频ID", "tooltip": "要扩展的视频 ID。支持由文本转视频、图像转视频以及之前的视频扩展操作生成的视频。扩展后总时长不能超过 3 分钟。" } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "视频ID", "tooltip": null }, "2": { "name": "时长", "tooltip": null } } };
const KlingVirtualTryOnNode = { "description": "Kling 虚拟试穿节点。输入一张人物图片和一张服装图片，将服装试穿到人物身上。", "display_name": "Kling 虚拟试穿", "inputs": { "cloth_image": { "name": "服装" }, "human_image": { "name": "主体" }, "model_name": { "name": "模型" } }, "outputs": { "0": { "tooltip": null } } };
const LTXVAddGuide = { "display_name": "LTXV添加指导", "inputs": { "frame_idx": { "name": "帧索引", "tooltip": "开始调节的帧索引。对于单帧图像或1-8帧的视频，任何帧索引值都可以接受。对于9+帧的视频，帧索引必须能被8整除，否则它将被向下取整到最接近的8的倍数。负值从视频的末尾开始计算。" }, "image": { "name": "图像", "tooltip": "用于调节潜在视频的图像或视频。必须是8*n + 1帧。如果视频不是8*n + 1帧，它将被裁剪到最接近的8*n + 1帧。" }, "latent": { "name": "潜在空间" }, "negative": { "name": "负向" }, "positive": { "name": "正向" }, "strength": { "name": "强度" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "正向", "tooltip": null }, "1": { "name": "负向", "tooltip": null }, "2": { "name": "潜在空间", "tooltip": null } } };
const LTXVConditioning = { "display_name": "LTXV条件", "inputs": { "frame_rate": { "name": "帧率" }, "negative": { "name": "负面条件" }, "positive": { "name": "正面条件" } }, "outputs": { "0": { "name": "正面条件", "tooltip": null }, "1": { "name": "负面条件", "tooltip": null } } };
const LTXVCropGuides = { "display_name": "LTXV裁剪指导", "inputs": { "latent": { "name": "潜在空间" }, "negative": { "name": "负向" }, "positive": { "name": "正向" } }, "outputs": { "0": { "name": "正向", "tooltip": null }, "1": { "name": "负向", "tooltip": null }, "2": { "name": "潜在空间", "tooltip": null } } };
const LTXVImgToVideo = { "display_name": "LTXV图像到视频", "inputs": { "batch_size": { "name": "批量大小" }, "height": { "name": "高度" }, "image": { "name": "图像" }, "length": { "name": "长度" }, "negative": { "name": "负面条件" }, "positive": { "name": "正面条件" }, "strength": { "name": "强度" }, "vae": { "name": "vae" }, "width": { "name": "宽度" } }, "outputs": { "0": { "name": "正面条件", "tooltip": null }, "1": { "name": "负面条件", "tooltip": null }, "2": { "name": "Latent", "tooltip": null } } };
const LTXVPreprocess = { "display_name": "LTXV预处理", "inputs": { "image": { "name": "图像" }, "img_compression": { "name": "图像压缩", "tooltip": "应用于图像的压缩量。" } }, "outputs": { "0": { "name": "输出图像", "tooltip": null } } };
const LTXVScheduler = { "display_name": "LTXV调度器", "inputs": { "base_shift": { "name": "基础移位" }, "latent": { "name": "Latent" }, "max_shift": { "name": "最大移位" }, "steps": { "name": "步数" }, "stretch": { "name": "拉伸", "tooltip": "将 sigma 拉伸到范围 [终值, 1]。" }, "terminal": { "name": "终值", "tooltip": "拉伸后 sigma 的终值。" } }, "outputs": { "0": { "tooltip": null } } };
const LaplaceScheduler = { "display_name": "Laplace调度器", "inputs": { "beta": { "name": "beta" }, "mu": { "name": "mu" }, "sigma_max": { "name": "sigma_max" }, "sigma_min": { "name": "sigma_min" }, "steps": { "name": "步数" } } };
const LatentAdd = { "display_name": "Latent相加", "inputs": { "samples1": { "name": "Latent1" }, "samples2": { "name": "Latent2" } }, "outputs": { "0": { "tooltip": null } } };
const LatentApplyOperation = { "display_name": "Latent应用操作", "inputs": { "operation": { "name": "操作" }, "samples": { "name": "Latent" } }, "outputs": { "0": { "tooltip": null } } };
const LatentApplyOperationCFG = { "display_name": "Latent应用操作CFG", "inputs": { "model": { "name": "模型" }, "operation": { "name": "操作" } }, "outputs": { "0": { "tooltip": null } } };
const LatentBatch = { "display_name": "组合Latent批次", "inputs": { "samples1": { "name": "Latent1" }, "samples2": { "name": "Latent2" } }, "outputs": { "0": { "tooltip": null } } };
const LatentBatchSeedBehavior = { "display_name": "Latent批处理随机种行为", "inputs": { "samples": { "name": "Latent" }, "seed_behavior": { "name": "随机种行为" } }, "outputs": { "0": { "tooltip": null } } };
const LatentBlend = { "display_name": "混合Latent", "inputs": { "blend_factor": { "name": "系数" }, "samples1": { "name": "Latent1" }, "samples2": { "name": "Latent2" } } };
const LatentComposite = { "display_name": "合成Latent", "inputs": { "feather": { "name": "羽化" }, "samples_from": { "name": "Latent从" }, "samples_to": { "name": "Latent到" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const LatentCompositeMasked = { "display_name": "合成Latent遮罩", "inputs": { "destination": { "name": "目标Latent" }, "mask": { "name": "遮罩" }, "resize_source": { "name": "调整来源大小" }, "source": { "name": "来源Latent" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const LatentConcat = { "display_name": "潜在空间拼接", "inputs": { "dim": { "name": "维度" }, "samples1": { "name": "样本1" }, "samples2": { "name": "样本2" } }, "outputs": { "0": { "tooltip": null } } };
const LatentCrop = { "display_name": "裁剪Latent", "inputs": { "height": { "name": "高度" }, "samples": { "name": "Latent" }, "width": { "name": "宽度" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const LatentCut = { "display_name": "潜在空间切割", "inputs": { "amount": { "name": "数量" }, "dim": { "name": "维度" }, "index": { "name": "索引" }, "samples": { "name": "样本" } }, "outputs": { "0": { "tooltip": null } } };
const LatentFlip = { "display_name": "翻转Latent", "inputs": { "flip_method": { "name": "翻转方法" }, "samples": { "name": "Latent" } } };
const LatentFromBatch = { "display_name": "从批次获取Latent", "inputs": { "batch_index": { "name": "批次索引" }, "length": { "name": "长度" }, "samples": { "name": "Latent" } } };
const LatentInterpolate = { "display_name": "Latent插值", "inputs": { "ratio": { "name": "比率" }, "samples1": { "name": "Latent1" }, "samples2": { "name": "Latent2" } }, "outputs": { "0": { "tooltip": null } } };
const LatentMultiply = { "display_name": "Latent相乘", "inputs": { "multiplier": { "name": "乘数" }, "samples": { "name": "Latent" } }, "outputs": { "0": { "tooltip": null } } };
const LatentOperationSharpen = { "display_name": "Latent操作锐化", "inputs": { "alpha": { "name": "阿尔法" }, "sharpen_radius": { "name": "锐化半径" }, "sigma": { "name": "西格玛" } }, "outputs": { "0": { "tooltip": null } } };
const LatentOperationTonemapReinhard = { "display_name": "Latent操作色调映射Reinhard", "inputs": { "multiplier": { "name": "乘数" } }, "outputs": { "0": { "tooltip": null } } };
const LatentRotate = { "display_name": "旋转Latent", "inputs": { "rotation": { "name": "旋转" }, "samples": { "name": "Latent" } } };
const LatentSubtract = { "display_name": "Latent相减", "inputs": { "samples1": { "name": "Latent1" }, "samples2": { "name": "Latent2" } }, "outputs": { "0": { "tooltip": null } } };
const LatentUpscale = { "display_name": "缩放Latent", "inputs": { "crop": { "name": "裁剪" }, "height": { "name": "高度" }, "samples": { "name": "Latent" }, "upscale_method": { "name": "缩放算法" }, "width": { "name": "宽度" } } };
const LatentUpscaleBy = { "display_name": "缩放Latent（比例）", "inputs": { "samples": { "name": "Latent" }, "scale_by": { "name": "缩放比例" }, "upscale_method": { "name": "缩放算法" } } };
const LatentUpscaleModelLoader = { "display_name": "加载Latent放大模型", "inputs": { "model_name": { "name": "模型" } }, "outputs": { "0": { "tooltip": null } } };
const LazyCache = { "description": "EasyCache 的自制版本 - 更'简单'的 EasyCache 实现。总体效果不如 EasyCache，但在某些罕见情况下表现更好，并且与 ComfyUI 中的所有内容具有通用兼容性。", "display_name": "惰性缓存", "inputs": { "end_percent": { "name": "结束百分比", "tooltip": "结束使用惰性缓存的相对采样步骤。" }, "model": { "name": "模型", "tooltip": "要添加惰性缓存的模型。" }, "reuse_threshold": { "name": "重用阈值", "tooltip": "重用缓存步骤的阈值。" }, "start_percent": { "name": "起始百分比", "tooltip": "开始使用惰性缓存的相对采样步骤。" }, "verbose": { "name": "详细模式", "tooltip": "是否记录详细信息。" } }, "outputs": { "0": { "tooltip": "带有惰性缓存的模型。" } } };
const Load3D = { "display_name": "加载3D", "inputs": { "clear": {}, "height": { "name": "高度" }, "image": { "name": "图像" }, "model_file": { "name": "模型文件" }, "upload 3d model": {}, "width": { "name": "宽度" } }, "outputs": { "0": { "name": "图像" }, "1": { "name": "遮罩" }, "2": { "name": "网格路径" }, "3": { "name": "法向" }, "4": { "name": "线条" }, "5": { "name": "相机信息" } } };
const LoadAudio = { "display_name": "加载音频", "inputs": { "audio": { "name": "音频" }, "audioUI": { "name": "音频UI" }, "upload": { "name": "选择文件上传" } } };
const LoadImage = { "display_name": "加载图像", "inputs": { "image": { "name": "图像" }, "upload": { "name": "选择文件上传" } } };
const LoadImageMask = { "display_name": "加载图像（作为遮罩）", "inputs": { "channel": { "name": "通道" }, "image": { "name": "图像" }, "upload": { "name": "选择文件上传" } } };
const LoadImageOutput = { "description": "从输出文件夹加载图像。当点击刷新按钮时，节点将更新图像列表并自动选择第一张图像，便于轻松迭代。", "display_name": "加载图像（来自输出）", "inputs": { "image": { "name": "图像" }, "refresh": {}, "upload": { "name": "选择文件上传" } } };
const LoadLatent = { "display_name": "加载Latent", "inputs": { "latent": { "name": "Latent" } } };
const LoadVideo = { "display_name": "加载视频", "inputs": { "file": { "name": "文件" }, "upload": { "name": "选择要上传的文件" } }, "outputs": { "0": { "tooltip": null } } };
const LoraLoader = { "description": "LoRA用于修改扩散和CLIP模型，改变Latent图像的降噪方式，例如应用风格。多个LoRA节点可以链接在一起。", "display_name": "加载LoRA", "inputs": { "clip": { "name": "CLIP", "tooltip": "LoRA 将应用于的 CLIP 模型。" }, "lora_name": { "name": "LoRA名称", "tooltip": "LoRA 的名称。" }, "model": { "name": "模型", "tooltip": "LoRA 将应用于的扩散模型。" }, "strength_clip": { "name": "CLIP强度", "tooltip": "修改 CLIP 模型的强度。此值可以为负。" }, "strength_model": { "name": "模型强度", "tooltip": "修改扩散模型的强度。此值可以为负。" } }, "outputs": { "0": { "tooltip": "修改后的扩散模型。" }, "1": { "tooltip": "修改后的CLIP模型。" } } };
const LoraLoaderModelOnly = { "description": "LoRA用于修改扩散和CLIP模型，改变Latent图像的降噪方式，例如应用风格。多个LoRA节点可以链接在一起。", "display_name": "LoRA加载器（仅模型）", "inputs": { "lora_name": { "name": "LoRA名称" }, "model": { "name": "模型" }, "strength_model": { "name": "模型强度" } }, "outputs": { "0": { "tooltip": "修改后的扩散模型。" } } };
const LoraModelLoader = { "display_name": "加载 LoRA 模型", "inputs": { "lora": { "name": "lora", "tooltip": "要应用于扩散模型的 LoRA 模型。" }, "model": { "name": "模型", "tooltip": "LoRA 将应用于的扩散模型。" }, "strength_model": { "name": "模型强度", "tooltip": "修改扩散模型的强度。此值可以为负数。" } }, "outputs": { "0": { "tooltip": "修改后的扩散模型。" } } };
const LoraSave = { "display_name": "保存LoRA", "inputs": { "bias_diff": { "name": "偏差差异" }, "filename_prefix": { "name": "文件名前缀" }, "lora_type": { "name": "lora类型" }, "model_diff": { "name": "模型差异", "tooltip": "要转换为 LoRA 的模型差异输出。" }, "rank": { "name": "排名" }, "text_encoder_diff": { "name": "文本编码器差异", "tooltip": "要转换为 LoRA 的CLIP差异输出。" } } };
const LossGraphNode = { "display_name": "绘制损失图", "inputs": { "filename_prefix": { "name": "文件名前缀" }, "loss": { "name": "损失" } } };
const LotusConditioning = { "display_name": "Lotus条件", "outputs": { "0": { "name": "条件", "tooltip": null } } };
const LtxvApiImageToVideo = { "description": "基于起始图像生成专业品质视频，可自定义时长和分辨率。", "display_name": "LTXV 图像转视频", "inputs": { "duration": { "name": "时长" }, "fps": { "name": "帧率" }, "generate_audio": { "name": "生成音频", "tooltip": "为 true 时，生成的视频将包含与场景匹配的 AI 生成音频。" }, "image": { "name": "图像", "tooltip": "用于视频的第一帧图像。" }, "model": { "name": "模型" }, "prompt": { "name": "提示词" }, "resolution": { "name": "分辨率" } }, "outputs": { "0": { "tooltip": null } } };
const LtxvApiTextToVideo = { "description": "可自定义时长和分辨率的专业品质视频。", "display_name": "LTXV 文本转视频", "inputs": { "duration": { "name": "时长" }, "fps": { "name": "帧率" }, "generate_audio": { "name": "生成音频", "tooltip": "为 true 时，生成的视频将包含与场景匹配的 AI 生成音频。" }, "model": { "name": "模型" }, "prompt": { "name": "提示词" }, "resolution": { "name": "分辨率" } }, "outputs": { "0": { "tooltip": null } } };
const LumaConceptsNode = { "description": "包含一个或多个相机概念，可用于 Luma 文本转视频和 Luma 图像转视频节点。", "display_name": "Luma 概念", "inputs": { "concept1": { "name": "概念1" }, "concept2": { "name": "概念2" }, "concept3": { "name": "概念3" }, "concept4": { "name": "概念4" }, "luma_concepts": { "name": "Luma概念", "tooltip": "可选的相机概念，将添加到此处选择的概念中。" } }, "outputs": { "0": { "name": "Luma概念", "tooltip": null } } };
const LumaImageModifyNode = { "description": "根据提示词和宽高比同步修改图像。", "display_name": "Luma 图像到图像", "inputs": { "control_after_generate": { "name": "生成后控制" }, "image": { "name": "图像" }, "image_weight": { "name": "图像权重", "tooltip": "图像权重；越接近 1.0，图像被修改的程度越小。" }, "model": { "name": "模型" }, "prompt": { "name": "提示词", "tooltip": "用于图像生成的提示词" }, "seed": { "name": "随机种", "tooltip": "用于决定节点是否重新运行的种子；无论种子如何，实际结果都是非确定性的。" } }, "outputs": { "0": { "tooltip": null } } };
const LumaImageNode = { "description": "根据提示词和宽高比同步生成图像。", "display_name": "Luma 文生图", "inputs": { "aspect_ratio": { "name": "宽高比" }, "character_image": { "name": "角色参考图", "tooltip": "角色参考图像；可为多张批量输入，最多可考虑 4 张图像。" }, "control_after_generate": { "name": "生成后控制" }, "image_luma_ref": { "name": "Luma 参考图", "tooltip": "Luma 参考节点连接，可用输入图像影响生成；最多可考虑 4 张图像。" }, "model": { "name": "模型" }, "prompt": { "name": "提示词", "tooltip": "用于图像生成的提示词" }, "seed": { "name": "种子", "tooltip": "用于决定节点是否重新运行的种子；无论种子如何，实际结果都是非确定性的。" }, "style_image": { "name": "风格参考图", "tooltip": "风格参考图像；仅使用 1 张图像。" }, "style_image_weight": { "name": "风格图权重", "tooltip": "风格图像的权重。如果未提供风格图像则忽略。" } }, "outputs": { "0": { "tooltip": null } } };
const LumaImageToVideoNode = { "description": "根据提示词、输入图像和输出尺寸同步生成视频。", "display_name": "Luma 图像转视频", "inputs": { "control_after_generate": { "name": "生成后控制" }, "duration": { "name": "时长" }, "first_image": { "name": "首帧图像", "tooltip": "生成视频的第一帧。" }, "last_image": { "name": "末帧图像", "tooltip": "生成视频的最后一帧。" }, "loop": { "name": "循环" }, "luma_concepts": { "name": "Luma概念", "tooltip": "可选的 Camera Concepts，通过 Luma Concepts 节点控制相机运动。" }, "model": { "name": "模型" }, "prompt": { "name": "提示词", "tooltip": "用于视频生成的提示词" }, "resolution": { "name": "分辨率" }, "seed": { "name": "种子", "tooltip": "用于决定节点是否重新运行的种子；无论种子如何，实际结果都是非确定性的。" } }, "outputs": { "0": { "tooltip": null } } };
const LumaReferenceNode = { "description": "用于 Luma 生成图像节点，包含一张图片和权重。", "display_name": "Luma 参考", "inputs": { "image": { "name": "图片", "tooltip": "用作参考的图片。" }, "luma_ref": { "name": "Luma参考" }, "weight": { "name": "权重", "tooltip": "图片参考的权重。" } }, "outputs": { "0": { "name": "Luma参考", "tooltip": null } } };
const LumaVideoNode = { "description": "根据提示词和输出尺寸同步生成视频。", "display_name": "Luma 文本转视频", "inputs": { "aspect_ratio": { "name": "宽高比" }, "control_after_generate": { "name": "生成后控制" }, "duration": { "name": "时长" }, "loop": { "name": "循环" }, "luma_concepts": { "name": "Luma概念", "tooltip": "可选的相机概念，通过 Luma Concepts 节点控制相机运动。" }, "model": { "name": "模型" }, "prompt": { "name": "提示词", "tooltip": "用于视频生成的提示词" }, "resolution": { "name": "分辨率" }, "seed": { "name": "种子", "tooltip": "用于决定节点是否重新运行的种子；无论种子如何，实际结果都是非确定性的。" } }, "outputs": { "0": { "tooltip": null } } };
const Mahiro = { "description": "修改引导以更多地侧重于正面条件提示的'方向'，而不是负面条件提示之间的差异。", "display_name": "真寻太可爱了，她应该有个更好的引导功能！！(。・ω・。)", "inputs": { "model": { "name": "模型" } }, "outputs": { "0": { "name": "修补后的模型", "tooltip": null } } };
const MaskComposite = { "display_name": "合成遮罩", "inputs": { "destination": { "name": "目标" }, "operation": { "name": "操作" }, "source": { "name": "源" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const MaskPreview = { "description": "将输入图像保存到您的 ComfyUI 输出目录。", "display_name": "预览遮罩", "inputs": { "mask": { "name": "遮罩" } } };
const MaskToImage = { "display_name": "遮罩转换为图像", "inputs": { "mask": { "name": "遮罩" } } };
const MinimaxHailuoVideoNode = { "description": "使用新的 MiniMax Hailuo-02 模型从提示词生成视频，可选择起始帧。", "display_name": "MiniMax 海螺视频", "inputs": { "control_after_generate": { "name": "生成后控制" }, "duration": { "name": "时长", "tooltip": "输出视频的长度（秒）。" }, "first_frame_image": { "name": "第一帧图像", "tooltip": "可选图像，用作生成视频的第一帧。" }, "prompt_optimizer": { "name": "提示优化器", "tooltip": "需要时优化提示词以提高生成质量。" }, "prompt_text": { "name": "提示文本", "tooltip": "指导视频生成的文本提示。" }, "resolution": { "name": "分辨率", "tooltip": "视频显示的尺寸。1080p为1920x1080，768p为1366x768。" }, "seed": { "name": "种子", "tooltip": "用于创建噪声的随机种子。" } }, "outputs": { "0": { "tooltip": null } } };
const MinimaxImageToVideoNode = { "description": "使用 MiniMax 的 API 根据图像和提示生成视频", "display_name": "MiniMax 图像转视频", "inputs": { "control_after_generate": { "name": "生成后控制" }, "image": { "name": "图像", "tooltip": "用于视频生成首帧的图像" }, "model": { "name": "模型", "tooltip": "用于视频生成的模型" }, "prompt_text": { "name": "提示词", "tooltip": "用于引导视频生成的文本提示" }, "seed": { "name": "随机种", "tooltip": "用于生成噪声的随机种子。" } }, "outputs": { "0": { "tooltip": null } } };
const MinimaxTextToVideoNode = { "description": "使用 MiniMax 的 API 根据提示生成视频", "display_name": "MiniMax 文本转视频", "inputs": { "control_after_generate": { "name": "生成后控制" }, "model": { "name": "模型", "tooltip": "用于视频生成的模型" }, "prompt_text": { "name": "提示词", "tooltip": "用于引导视频生成的文本提示" }, "seed": { "name": "随机种", "tooltip": "用于生成噪声的随机种子。" } }, "outputs": { "0": { "tooltip": null } } };
const ModelComputeDtype = { "display_name": "模型计算Dtype", "inputs": { "dtype": { "name": "dtype" }, "model": { "name": "模型" } } };
const ModelMergeAdd = { "display_name": "模型相加", "inputs": { "model1": { "name": "模型1" }, "model2": { "name": "模型2" } } };
const ModelMergeAuraflow = { "display_name": "模型融合（Auraflow ）", "inputs": { "cond_seq_linear_": { "name": "条件序列线性." }, "double_layers_0_": { "name": "双层.0." }, "double_layers_1_": { "name": "双层.1." }, "double_layers_2_": { "name": "双层.2." }, "double_layers_3_": { "name": "双层.3." }, "final_linear_": { "name": "最终线性." }, "init_x_linear_": { "name": "初始x线性." }, "modF_": { "name": "modF." }, "model1": { "name": "模型1" }, "model2": { "name": "模型2" }, "positional_encoding": { "name": "位置编码" }, "register_tokens": { "name": "注册令牌" }, "single_layers_0_": { "name": "单层.0." }, "single_layers_10_": { "name": "单层.10." }, "single_layers_11_": { "name": "单层.11." }, "single_layers_12_": { "name": "单层.12." }, "single_layers_13_": { "name": "单层.13." }, "single_layers_14_": { "name": "单层.14." }, "single_layers_15_": { "name": "单层.15." }, "single_layers_16_": { "name": "单层.16." }, "single_layers_17_": { "name": "单层.17." }, "single_layers_18_": { "name": "单层.18." }, "single_layers_19_": { "name": "单层.19." }, "single_layers_1_": { "name": "单层.1." }, "single_layers_20_": { "name": "单层.20." }, "single_layers_21_": { "name": "单层.21." }, "single_layers_22_": { "name": "单层.22." }, "single_layers_23_": { "name": "单层.23." }, "single_layers_24_": { "name": "单层.24." }, "single_layers_25_": { "name": "单层.25." }, "single_layers_26_": { "name": "单层.26." }, "single_layers_27_": { "name": "单层.27." }, "single_layers_28_": { "name": "单层.28." }, "single_layers_29_": { "name": "单层.29." }, "single_layers_2_": { "name": "单层.2." }, "single_layers_30_": { "name": "单层.30." }, "single_layers_31_": { "name": "单层.31." }, "single_layers_3_": { "name": "单层.3." }, "single_layers_4_": { "name": "单层.4." }, "single_layers_5_": { "name": "单层.5." }, "single_layers_6_": { "name": "单层.6." }, "single_layers_7_": { "name": "单层.7." }, "single_layers_8_": { "name": "单层.8." }, "single_layers_9_": { "name": "单层.9." }, "t_embedder_": { "name": "t嵌入器." } } };
const ModelMergeBlocks = { "display_name": "模型融合（分块）", "inputs": { "input": { "name": "输入" }, "middle": { "name": "中间" }, "model1": { "name": "模型1" }, "model2": { "name": "模型2" }, "out": { "name": "输出" } } };
const ModelMergeCosmos14B = { "display_name": "模型融合（Cosmos14B）", "inputs": { "affline_norm_": { "name": "仿射规范化." }, "blocks_block0_": { "name": "blocks.block0." }, "blocks_block10_": { "name": "blocks.block10." }, "blocks_block11_": { "name": "blocks.block11." }, "blocks_block12_": { "name": "blocks.block12." }, "blocks_block13_": { "name": "blocks.block13." }, "blocks_block14_": { "name": "blocks.block14." }, "blocks_block15_": { "name": "blocks.block15." }, "blocks_block16_": { "name": "blocks.block16." }, "blocks_block17_": { "name": "blocks.block17." }, "blocks_block18_": { "name": "blocks.block18." }, "blocks_block19_": { "name": "blocks.block19." }, "blocks_block1_": { "name": "blocks.block1." }, "blocks_block20_": { "name": "blocks.block20." }, "blocks_block21_": { "name": "blocks.block21." }, "blocks_block22_": { "name": "blocks.block22." }, "blocks_block23_": { "name": "blocks.block23." }, "blocks_block24_": { "name": "blocks.block24." }, "blocks_block25_": { "name": "blocks.block25." }, "blocks_block26_": { "name": "blocks.block26." }, "blocks_block27_": { "name": "blocks.block27." }, "blocks_block28_": { "name": "blocks.block28." }, "blocks_block29_": { "name": "blocks.block29." }, "blocks_block2_": { "name": "blocks.block2." }, "blocks_block30_": { "name": "blocks.block30." }, "blocks_block31_": { "name": "blocks.block31." }, "blocks_block32_": { "name": "blocks.block32." }, "blocks_block33_": { "name": "blocks.block33." }, "blocks_block34_": { "name": "blocks.block34." }, "blocks_block35_": { "name": "blocks.block35." }, "blocks_block3_": { "name": "blocks.block3." }, "blocks_block4_": { "name": "blocks.block4." }, "blocks_block5_": { "name": "blocks.block5." }, "blocks_block6_": { "name": "blocks.block6." }, "blocks_block7_": { "name": "blocks.block7." }, "blocks_block8_": { "name": "blocks.block8." }, "blocks_block9_": { "name": "blocks.block9." }, "extra_pos_embedder_": { "name": "额外位置嵌入器." }, "final_layer_": { "name": "最终层." }, "model1": { "name": "模型1" }, "model2": { "name": "模型2" }, "pos_embedder_": { "name": "位置嵌入器." }, "t_embedder_": { "name": "t嵌入器." }, "x_embedder_": { "name": "x嵌入器." } } };
const ModelMergeCosmos7B = { "display_name": "模型融合（COsmos7B）", "inputs": { "affline_norm_": { "name": "仿射规范化." }, "blocks_block0_": { "name": "blocks.block0." }, "blocks_block10_": { "name": "blocks.block10." }, "blocks_block11_": { "name": "blocks.block11." }, "blocks_block12_": { "name": "blocks.block12." }, "blocks_block13_": { "name": "blocks.block13." }, "blocks_block14_": { "name": "blocks.block14." }, "blocks_block15_": { "name": "blocks.block15." }, "blocks_block16_": { "name": "blocks.block16." }, "blocks_block17_": { "name": "blocks.block17." }, "blocks_block18_": { "name": "blocks.block18." }, "blocks_block19_": { "name": "blocks.block19." }, "blocks_block1_": { "name": "blocks.block1." }, "blocks_block20_": { "name": "blocks.block20." }, "blocks_block21_": { "name": "blocks.block21." }, "blocks_block22_": { "name": "blocks.block22." }, "blocks_block23_": { "name": "blocks.block23." }, "blocks_block24_": { "name": "blocks.block24." }, "blocks_block25_": { "name": "blocks.block25." }, "blocks_block26_": { "name": "blocks.block26." }, "blocks_block27_": { "name": "blocks.block27." }, "blocks_block2_": { "name": "blocks.block2." }, "blocks_block3_": { "name": "blocks.block3." }, "blocks_block4_": { "name": "blocks.block4." }, "blocks_block5_": { "name": "blocks.block5." }, "blocks_block6_": { "name": "blocks.block6." }, "blocks_block7_": { "name": "blocks.block7." }, "blocks_block8_": { "name": "blocks.block8." }, "blocks_block9_": { "name": "blocks.block9." }, "extra_pos_embedder_": { "name": "额外位置嵌入器." }, "final_layer_": { "name": "最终层." }, "model1": { "name": "模型1" }, "model2": { "name": "模型2" }, "pos_embedder_": { "name": "位置嵌入器." }, "t_embedder_": { "name": "t嵌入器." }, "x_embedder_": { "name": "x嵌入器." } } };
const ModelMergeCosmosPredict2_14B = { "display_name": "模型融合（CosmosPredict2_14B）", "inputs": { "blocks_0_": { "name": "块0。" }, "blocks_10_": { "name": "块10。" }, "blocks_11_": { "name": "块11。" }, "blocks_12_": { "name": "块12。" }, "blocks_13_": { "name": "块13。" }, "blocks_14_": { "name": "块14。" }, "blocks_15_": { "name": "块15。" }, "blocks_16_": { "name": "块16。" }, "blocks_17_": { "name": "块17。" }, "blocks_18_": { "name": "块18。" }, "blocks_19_": { "name": "块19。" }, "blocks_1_": { "name": "块1。" }, "blocks_20_": { "name": "块20。" }, "blocks_21_": { "name": "块21。" }, "blocks_22_": { "name": "块22。" }, "blocks_23_": { "name": "块23。" }, "blocks_24_": { "name": "块24。" }, "blocks_25_": { "name": "块25。" }, "blocks_26_": { "name": "块26。" }, "blocks_27_": { "name": "块27。" }, "blocks_28_": { "name": "块28。" }, "blocks_29_": { "name": "块29。" }, "blocks_2_": { "name": "块2。" }, "blocks_30_": { "name": "块30。" }, "blocks_31_": { "name": "块31。" }, "blocks_32_": { "name": "块32。" }, "blocks_33_": { "name": "块33。" }, "blocks_34_": { "name": "块34。" }, "blocks_35_": { "name": "块35。" }, "blocks_3_": { "name": "块3。" }, "blocks_4_": { "name": "块4。" }, "blocks_5_": { "name": "块5。" }, "blocks_6_": { "name": "块6。" }, "blocks_7_": { "name": "块7。" }, "blocks_8_": { "name": "块8。" }, "blocks_9_": { "name": "块9。" }, "final_layer_": { "name": "最终层。" }, "model1": { "name": "模型1" }, "model2": { "name": "模型2" }, "pos_embedder_": { "name": "位置嵌入器。" }, "t_embedder_": { "name": "t嵌入器。" }, "t_embedding_norm_": { "name": "t嵌入归一化。" }, "x_embedder_": { "name": "x嵌入器。" } } };
const ModelMergeCosmosPredict2_2B = { "display_name": "模型融合（CosmosPredict2_2B）", "inputs": { "blocks_0_": { "name": "块.0." }, "blocks_10_": { "name": "块.10." }, "blocks_11_": { "name": "块.11." }, "blocks_12_": { "name": "块.12." }, "blocks_13_": { "name": "块.13." }, "blocks_14_": { "name": "块.14." }, "blocks_15_": { "name": "块.15." }, "blocks_16_": { "name": "块.16." }, "blocks_17_": { "name": "块.17." }, "blocks_18_": { "name": "块.18." }, "blocks_19_": { "name": "块.19." }, "blocks_1_": { "name": "块.1." }, "blocks_20_": { "name": "块.20." }, "blocks_21_": { "name": "块.21." }, "blocks_22_": { "name": "块.22." }, "blocks_23_": { "name": "块.23." }, "blocks_24_": { "name": "块.24." }, "blocks_25_": { "name": "块.25." }, "blocks_26_": { "name": "块.26." }, "blocks_27_": { "name": "块.27." }, "blocks_2_": { "name": "块.2." }, "blocks_3_": { "name": "块.3." }, "blocks_4_": { "name": "块.4." }, "blocks_5_": { "name": "块.5." }, "blocks_6_": { "name": "块.6." }, "blocks_7_": { "name": "块.7." }, "blocks_8_": { "name": "块.8." }, "blocks_9_": { "name": "块.9." }, "final_layer_": { "name": "最终层。" }, "model1": { "name": "模型1" }, "model2": { "name": "模型2" }, "pos_embedder_": { "name": "位置嵌入器。" }, "t_embedder_": { "name": "t_嵌入器。" }, "t_embedding_norm_": { "name": "t_嵌入归一化。" }, "x_embedder_": { "name": "x_嵌入器。" } } };
const ModelMergeFlux1 = { "display_name": "模型融合（Flux1）", "inputs": { "double_blocks_0_": { "name": "双块.0." }, "double_blocks_10_": { "name": "双块.10." }, "double_blocks_11_": { "name": "双块.11." }, "double_blocks_12_": { "name": "双块.12." }, "double_blocks_13_": { "name": "双块.13." }, "double_blocks_14_": { "name": "双块.14." }, "double_blocks_15_": { "name": "双块.15." }, "double_blocks_16_": { "name": "双块.16." }, "double_blocks_17_": { "name": "双块.17." }, "double_blocks_18_": { "name": "双块.18." }, "double_blocks_1_": { "name": "双块.1." }, "double_blocks_2_": { "name": "双块.2." }, "double_blocks_3_": { "name": "双块.3." }, "double_blocks_4_": { "name": "双块.4." }, "double_blocks_5_": { "name": "双块.5." }, "double_blocks_6_": { "name": "双块.6." }, "double_blocks_7_": { "name": "双块.7." }, "double_blocks_8_": { "name": "双块.8." }, "double_blocks_9_": { "name": "双块.9." }, "final_layer_": { "name": "最终层." }, "guidance_in": { "name": "输入引导" }, "img_in_": { "name": "输入图像." }, "model1": { "name": "模型1" }, "model2": { "name": "模型2" }, "single_blocks_0_": { "name": "单块.0." }, "single_blocks_10_": { "name": "单块.10." }, "single_blocks_11_": { "name": "单块.11." }, "single_blocks_12_": { "name": "单块.12." }, "single_blocks_13_": { "name": "单块.13." }, "single_blocks_14_": { "name": "单块.14." }, "single_blocks_15_": { "name": "单块.15." }, "single_blocks_16_": { "name": "单块.16." }, "single_blocks_17_": { "name": "单块.17." }, "single_blocks_18_": { "name": "单块.18." }, "single_blocks_19_": { "name": "单块.19." }, "single_blocks_1_": { "name": "单块.1." }, "single_blocks_20_": { "name": "单块.20." }, "single_blocks_21_": { "name": "单块.21." }, "single_blocks_22_": { "name": "单块.22." }, "single_blocks_23_": { "name": "单块.23." }, "single_blocks_24_": { "name": "单块.24." }, "single_blocks_25_": { "name": "单块.25." }, "single_blocks_26_": { "name": "单块.26." }, "single_blocks_27_": { "name": "单块.27." }, "single_blocks_28_": { "name": "单块.28." }, "single_blocks_29_": { "name": "单块.29." }, "single_blocks_2_": { "name": "单块.2." }, "single_blocks_30_": { "name": "单块.30." }, "single_blocks_31_": { "name": "单块.31." }, "single_blocks_32_": { "name": "单块.32." }, "single_blocks_33_": { "name": "单块.33." }, "single_blocks_34_": { "name": "单块.34." }, "single_blocks_35_": { "name": "单块.35." }, "single_blocks_36_": { "name": "单块.36." }, "single_blocks_37_": { "name": "单块.37." }, "single_blocks_3_": { "name": "单块.3." }, "single_blocks_4_": { "name": "单块.4." }, "single_blocks_5_": { "name": "单块.5." }, "single_blocks_6_": { "name": "单块.6." }, "single_blocks_7_": { "name": "单块.7." }, "single_blocks_8_": { "name": "单块.8." }, "single_blocks_9_": { "name": "单块.9." }, "time_in_": { "name": "输入时间." }, "txt_in_": { "name": "输入文本." }, "vector_in_": { "name": "输入向量." } } };
const ModelMergeLTXV = { "display_name": "模型融合（LTXV）", "inputs": { "adaln_single_": { "name": "adaln_single." }, "caption_projection_": { "name": "caption_projection." }, "model1": { "name": "模型1" }, "model2": { "name": "模型2" }, "patchify_proj_": { "name": "patchify_proj." }, "proj_out_": { "name": "proj_out." }, "scale_shift_table": { "name": "scale_shift_table" }, "transformer_blocks_0_": { "name": "transformer_blocks.0." }, "transformer_blocks_10_": { "name": "transformer_blocks.10." }, "transformer_blocks_11_": { "name": "transformer_blocks.11." }, "transformer_blocks_12_": { "name": "transformer_blocks.12." }, "transformer_blocks_13_": { "name": "transformer_blocks.13." }, "transformer_blocks_14_": { "name": "transformer_blocks.14." }, "transformer_blocks_15_": { "name": "transformer_blocks.15." }, "transformer_blocks_16_": { "name": "transformer_blocks.16." }, "transformer_blocks_17_": { "name": "transformer_blocks.17." }, "transformer_blocks_18_": { "name": "transformer_blocks.18." }, "transformer_blocks_19_": { "name": "transformer_blocks.19." }, "transformer_blocks_1_": { "name": "transformer_blocks.1." }, "transformer_blocks_20_": { "name": "transformer_blocks.20." }, "transformer_blocks_21_": { "name": "transformer_blocks.21." }, "transformer_blocks_22_": { "name": "transformer_blocks.22." }, "transformer_blocks_23_": { "name": "transformer_blocks.23." }, "transformer_blocks_24_": { "name": "transformer_blocks.24." }, "transformer_blocks_25_": { "name": "transformer_blocks.25." }, "transformer_blocks_26_": { "name": "transformer_blocks.26." }, "transformer_blocks_27_": { "name": "transformer_blocks.27." }, "transformer_blocks_2_": { "name": "transformer_blocks.2." }, "transformer_blocks_3_": { "name": "transformer_blocks.3." }, "transformer_blocks_4_": { "name": "transformer_blocks.4." }, "transformer_blocks_5_": { "name": "transformer_blocks.5." }, "transformer_blocks_6_": { "name": "transformer_blocks.6." }, "transformer_blocks_7_": { "name": "transformer_blocks.7." }, "transformer_blocks_8_": { "name": "transformer_blocks.8." }, "transformer_blocks_9_": { "name": "transformer_blocks.9." } } };
const ModelMergeMochiPreview = { "display_name": "模型融合（Mochi预览）", "inputs": { "blocks_0_": { "name": "blocks.0." }, "blocks_10_": { "name": "blocks.10." }, "blocks_11_": { "name": "blocks.11." }, "blocks_12_": { "name": "blocks.12." }, "blocks_13_": { "name": "blocks.13." }, "blocks_14_": { "name": "blocks.14." }, "blocks_15_": { "name": "blocks.15." }, "blocks_16_": { "name": "blocks.16." }, "blocks_17_": { "name": "blocks.17." }, "blocks_18_": { "name": "blocks.18." }, "blocks_19_": { "name": "blocks.19." }, "blocks_1_": { "name": "blocks.1." }, "blocks_20_": { "name": "blocks.20." }, "blocks_21_": { "name": "blocks.21." }, "blocks_22_": { "name": "blocks.22." }, "blocks_23_": { "name": "blocks.23." }, "blocks_24_": { "name": "blocks.24." }, "blocks_25_": { "name": "blocks.25." }, "blocks_26_": { "name": "blocks.26." }, "blocks_27_": { "name": "blocks.27." }, "blocks_28_": { "name": "blocks.28." }, "blocks_29_": { "name": "blocks.29." }, "blocks_2_": { "name": "blocks.2." }, "blocks_30_": { "name": "blocks.30." }, "blocks_31_": { "name": "blocks.31." }, "blocks_32_": { "name": "blocks.32." }, "blocks_33_": { "name": "blocks.33." }, "blocks_34_": { "name": "blocks.34." }, "blocks_35_": { "name": "blocks.35." }, "blocks_36_": { "name": "blocks.36." }, "blocks_37_": { "name": "blocks.37." }, "blocks_38_": { "name": "blocks.38." }, "blocks_39_": { "name": "blocks.39." }, "blocks_3_": { "name": "blocks.3." }, "blocks_40_": { "name": "blocks.40." }, "blocks_41_": { "name": "blocks.41." }, "blocks_42_": { "name": "blocks.42." }, "blocks_43_": { "name": "blocks.43." }, "blocks_44_": { "name": "blocks.44." }, "blocks_45_": { "name": "blocks.45." }, "blocks_46_": { "name": "blocks.46." }, "blocks_47_": { "name": "blocks.47." }, "blocks_4_": { "name": "blocks.4." }, "blocks_5_": { "name": "blocks.5." }, "blocks_6_": { "name": "blocks.6." }, "blocks_7_": { "name": "blocks.7." }, "blocks_8_": { "name": "blocks.8." }, "blocks_9_": { "name": "blocks.9." }, "final_layer_": { "name": "final_layer." }, "model1": { "name": "模型1" }, "model2": { "name": "模型2" }, "pos_frequencies_": { "name": "pos_frequencies." }, "t5_y_embedder_": { "name": "t5_y_embedder." }, "t5_yproj_": { "name": "t5_yproj." }, "t_embedder_": { "name": "t_embedder." } } };
const ModelMergeQwenImage = { "display_name": "模型融合Qwen图像", "inputs": { "img_in_": { "name": "图像输入。" }, "model1": { "name": "模型1" }, "model2": { "name": "模型2" }, "pos_embeds_": { "name": "位置嵌入。" }, "proj_out_": { "name": "proj_out." }, "time_text_embed_": { "name": "时间文本嵌入。" }, "transformer_blocks_0_": { "name": "变换器块.0." }, "transformer_blocks_10_": { "name": "transformer_blocks.10." }, "transformer_blocks_11_": { "name": "transformer_blocks.11." }, "transformer_blocks_12_": { "name": "transformer_blocks.12." }, "transformer_blocks_13_": { "name": "transformer_blocks.13." }, "transformer_blocks_14_": { "name": "transformer_blocks.14." }, "transformer_blocks_15_": { "name": "transformer_blocks.15." }, "transformer_blocks_16_": { "name": "transformer_blocks.16." }, "transformer_blocks_17_": { "name": "transformer_blocks.17." }, "transformer_blocks_18_": { "name": "transformer_blocks.18." }, "transformer_blocks_19_": { "name": "transformer_blocks.19." }, "transformer_blocks_1_": { "name": "变换器块.1." }, "transformer_blocks_20_": { "name": "transformer_blocks.20." }, "transformer_blocks_21_": { "name": "transformer_blocks.21." }, "transformer_blocks_22_": { "name": "transformer_blocks.22." }, "transformer_blocks_23_": { "name": "transformer_blocks.23." }, "transformer_blocks_24_": { "name": "transformer_blocks.24." }, "transformer_blocks_25_": { "name": "transformer_blocks.25." }, "transformer_blocks_26_": { "name": "transformer_blocks.26." }, "transformer_blocks_27_": { "name": "transformer_blocks.27." }, "transformer_blocks_28_": { "name": "transformer_blocks.28." }, "transformer_blocks_29_": { "name": "transformer_blocks.29." }, "transformer_blocks_2_": { "name": "变换器块.2." }, "transformer_blocks_30_": { "name": "transformer_blocks.30." }, "transformer_blocks_31_": { "name": "transformer_blocks.31." }, "transformer_blocks_32_": { "name": "transformer_blocks.32." }, "transformer_blocks_33_": { "name": "transformer_blocks.33." }, "transformer_blocks_34_": { "name": "transformer_blocks.34." }, "transformer_blocks_35_": { "name": "transformer_blocks.35." }, "transformer_blocks_36_": { "name": "transformer_blocks.36." }, "transformer_blocks_37_": { "name": "transformer_blocks.37." }, "transformer_blocks_38_": { "name": "transformer_blocks.38." }, "transformer_blocks_39_": { "name": "transformer_blocks.39." }, "transformer_blocks_3_": { "name": "变换器块.3." }, "transformer_blocks_40_": { "name": "transformer_blocks.40." }, "transformer_blocks_41_": { "name": "transformer_blocks.41." }, "transformer_blocks_42_": { "name": "transformer_blocks.42." }, "transformer_blocks_43_": { "name": "transformer_blocks.43." }, "transformer_blocks_44_": { "name": "transformer_blocks.44." }, "transformer_blocks_45_": { "name": "transformer_blocks.45." }, "transformer_blocks_46_": { "name": "transformer_blocks.46." }, "transformer_blocks_47_": { "name": "transformer_blocks.47." }, "transformer_blocks_48_": { "name": "transformer_blocks.48." }, "transformer_blocks_49_": { "name": "transformer_blocks.49." }, "transformer_blocks_4_": { "name": "变换器块.4." }, "transformer_blocks_50_": { "name": "transformer_blocks.50." }, "transformer_blocks_51_": { "name": "transformer_blocks.51." }, "transformer_blocks_52_": { "name": "transformer_blocks.52." }, "transformer_blocks_53_": { "name": "transformer_blocks.53." }, "transformer_blocks_54_": { "name": "transformer_blocks.54." }, "transformer_blocks_55_": { "name": "transformer_blocks.55." }, "transformer_blocks_56_": { "name": "transformer_blocks.56." }, "transformer_blocks_57_": { "name": "transformer_blocks.57." }, "transformer_blocks_58_": { "name": "transformer_blocks.58." }, "transformer_blocks_59_": { "name": "transformer_blocks.59." }, "transformer_blocks_5_": { "name": "变换器块.5." }, "transformer_blocks_6_": { "name": "变换器块.6." }, "transformer_blocks_7_": { "name": "变换器块.7." }, "transformer_blocks_8_": { "name": "变换器块.8." }, "transformer_blocks_9_": { "name": "变换器块.9." }, "txt_in_": { "name": "文本输入。" }, "txt_norm_": { "name": "文本归一化。" } } };
const ModelMergeSD1 = { "display_name": "模型融合（SD1）", "inputs": { "input_blocks_0_": { "name": "输入块.0." }, "input_blocks_10_": { "name": "输入块.10." }, "input_blocks_11_": { "name": "输入块.11." }, "input_blocks_1_": { "name": "输入块.1." }, "input_blocks_2_": { "name": "输入块.2." }, "input_blocks_3_": { "name": "输入块.3." }, "input_blocks_4_": { "name": "输入块.4." }, "input_blocks_5_": { "name": "输入块.5." }, "input_blocks_6_": { "name": "输入块.6." }, "input_blocks_7_": { "name": "输入块.7." }, "input_blocks_8_": { "name": "输入块.8." }, "input_blocks_9_": { "name": "输入块.9." }, "label_emb_": { "name": "标签嵌入." }, "middle_block_0_": { "name": "中间块.0." }, "middle_block_1_": { "name": "中间块.1." }, "middle_block_2_": { "name": "中间块.2." }, "model1": { "name": "模型1" }, "model2": { "name": "模型2" }, "out_": { "name": "出." }, "output_blocks_0_": { "name": "输出块.0." }, "output_blocks_10_": { "name": "输出块.10." }, "output_blocks_11_": { "name": "输出块.11." }, "output_blocks_1_": { "name": "输出块.1." }, "output_blocks_2_": { "name": "输出块.2." }, "output_blocks_3_": { "name": "输出块.3." }, "output_blocks_4_": { "name": "输出块.4." }, "output_blocks_5_": { "name": "输出块.5." }, "output_blocks_6_": { "name": "输出块.6." }, "output_blocks_7_": { "name": "输出块.7." }, "output_blocks_8_": { "name": "输出块.8." }, "output_blocks_9_": { "name": "输出块.9." }, "time_embed_": { "name": "时间嵌入." } } };
const ModelMergeSD2 = { "display_name": "模型融合（SD2）", "inputs": { "input_blocks_0_": { "name": "输入块.0." }, "input_blocks_10_": { "name": "输入块.10." }, "input_blocks_11_": { "name": "输入块.11." }, "input_blocks_1_": { "name": "输入块.1." }, "input_blocks_2_": { "name": "输入块.2." }, "input_blocks_3_": { "name": "输入块.3." }, "input_blocks_4_": { "name": "输入块.4." }, "input_blocks_5_": { "name": "输入块.5." }, "input_blocks_6_": { "name": "输入块.6." }, "input_blocks_7_": { "name": "输入块.7." }, "input_blocks_8_": { "name": "输入块.8." }, "input_blocks_9_": { "name": "输入块.9." }, "label_emb_": { "name": "标签嵌入." }, "middle_block_0_": { "name": "中间块.0." }, "middle_block_1_": { "name": "中间块.1." }, "middle_block_2_": { "name": "中间块.2." }, "model1": { "name": "模型1" }, "model2": { "name": "模型2" }, "out_": { "name": "出." }, "output_blocks_0_": { "name": "输出块.0." }, "output_blocks_10_": { "name": "输出块.10." }, "output_blocks_11_": { "name": "输出块.11." }, "output_blocks_1_": { "name": "输出块.1." }, "output_blocks_2_": { "name": "输出块.2." }, "output_blocks_3_": { "name": "输出块.3." }, "output_blocks_4_": { "name": "输出块.4." }, "output_blocks_5_": { "name": "输出块.5." }, "output_blocks_6_": { "name": "输出块.6." }, "output_blocks_7_": { "name": "输出块.7." }, "output_blocks_8_": { "name": "输出块.8." }, "output_blocks_9_": { "name": "输出块.9." }, "time_embed_": { "name": "时间嵌入." } } };
const ModelMergeSD35_Large = { "display_name": "模型融合（SD35_大）", "inputs": { "context_embedder_": { "name": "上下文嵌入器." }, "final_layer_": { "name": "最终层." }, "joint_blocks_0_": { "name": "联合块.0." }, "joint_blocks_10_": { "name": "联合块.10." }, "joint_blocks_11_": { "name": "联合块.11." }, "joint_blocks_12_": { "name": "联合块.12." }, "joint_blocks_13_": { "name": "联合块.13." }, "joint_blocks_14_": { "name": "联合块.14." }, "joint_blocks_15_": { "name": "联合块.15." }, "joint_blocks_16_": { "name": "联合块.16." }, "joint_blocks_17_": { "name": "联合块.17." }, "joint_blocks_18_": { "name": "联合块.18." }, "joint_blocks_19_": { "name": "联合块.19." }, "joint_blocks_1_": { "name": "联合块.1." }, "joint_blocks_20_": { "name": "联合块.20." }, "joint_blocks_21_": { "name": "联合块.21." }, "joint_blocks_22_": { "name": "联合块.22." }, "joint_blocks_23_": { "name": "联合块.23." }, "joint_blocks_24_": { "name": "联合块.24." }, "joint_blocks_25_": { "name": "联合块.25." }, "joint_blocks_26_": { "name": "联合块.26." }, "joint_blocks_27_": { "name": "联合块.27." }, "joint_blocks_28_": { "name": "联合块.28." }, "joint_blocks_29_": { "name": "联合块.29." }, "joint_blocks_2_": { "name": "联合块.2." }, "joint_blocks_30_": { "name": "联合块.30." }, "joint_blocks_31_": { "name": "联合块.31." }, "joint_blocks_32_": { "name": "联合块.32." }, "joint_blocks_33_": { "name": "联合块.33." }, "joint_blocks_34_": { "name": "联合块.34." }, "joint_blocks_35_": { "name": "联合块.35." }, "joint_blocks_36_": { "name": "联合块.36." }, "joint_blocks_37_": { "name": "联合块.37." }, "joint_blocks_3_": { "name": "联合块.3." }, "joint_blocks_4_": { "name": "联合块.4." }, "joint_blocks_5_": { "name": "联合块.5." }, "joint_blocks_6_": { "name": "联合块.6." }, "joint_blocks_7_": { "name": "联合块.7." }, "joint_blocks_8_": { "name": "联合块.8." }, "joint_blocks_9_": { "name": "联合块.9." }, "model1": { "name": "模型1" }, "model2": { "name": "模型2" }, "pos_embed_": { "name": "位置嵌入." }, "t_embedder_": { "name": "t嵌入器." }, "x_embedder_": { "name": "x嵌入器." }, "y_embedder_": { "name": "y嵌入器." } } };
const ModelMergeSD3_2B = { "display_name": "模型融合（SD3_2B）", "inputs": { "context_embedder_": { "name": "上下文嵌入器." }, "final_layer_": { "name": "最终层." }, "joint_blocks_0_": { "name": "联合块.0." }, "joint_blocks_10_": { "name": "联合块.10." }, "joint_blocks_11_": { "name": "联合块.11." }, "joint_blocks_12_": { "name": "联合块.12." }, "joint_blocks_13_": { "name": "联合块.13." }, "joint_blocks_14_": { "name": "联合块.14." }, "joint_blocks_15_": { "name": "联合块.15." }, "joint_blocks_16_": { "name": "联合块.16." }, "joint_blocks_17_": { "name": "联合块.17." }, "joint_blocks_18_": { "name": "联合块.18." }, "joint_blocks_19_": { "name": "联合块.19." }, "joint_blocks_1_": { "name": "联合块.1." }, "joint_blocks_20_": { "name": "联合块.20." }, "joint_blocks_21_": { "name": "联合块.21." }, "joint_blocks_22_": { "name": "联合块.22." }, "joint_blocks_23_": { "name": "联合块.23." }, "joint_blocks_2_": { "name": "联合块.2." }, "joint_blocks_3_": { "name": "联合块.3." }, "joint_blocks_4_": { "name": "联合块.4." }, "joint_blocks_5_": { "name": "联合块.5." }, "joint_blocks_6_": { "name": "联合块.6." }, "joint_blocks_7_": { "name": "联合块.7." }, "joint_blocks_8_": { "name": "联合块.8." }, "joint_blocks_9_": { "name": "联合块.9." }, "model1": { "name": "模型1" }, "model2": { "name": "模型2" }, "pos_embed_": { "name": "位置嵌入." }, "t_embedder_": { "name": "t嵌入器." }, "x_embedder_": { "name": "x嵌入器." }, "y_embedder_": { "name": "y嵌入器." } } };
const ModelMergeSDXL = { "display_name": "模型融合（SDXL）", "inputs": { "input_blocks_0": { "name": "输入块.0" }, "input_blocks_1": { "name": "输入块.1" }, "input_blocks_2": { "name": "输入块.2" }, "input_blocks_3": { "name": "输入块.3" }, "input_blocks_4": { "name": "输入块.4" }, "input_blocks_5": { "name": "输入块.5" }, "input_blocks_6": { "name": "输入块.6" }, "input_blocks_7": { "name": "输入块.7" }, "input_blocks_8": { "name": "输入块.8" }, "label_emb_": { "name": "标签嵌入." }, "middle_block_0": { "name": "中间块.0" }, "middle_block_1": { "name": "中间块.1" }, "middle_block_2": { "name": "中间块.2" }, "model1": { "name": "模型1" }, "model2": { "name": "模型2" }, "out_": { "name": "输出." }, "output_blocks_0": { "name": "输出块.0" }, "output_blocks_1": { "name": "输出块.1" }, "output_blocks_2": { "name": "输出块.2" }, "output_blocks_3": { "name": "输出块.3" }, "output_blocks_4": { "name": "输出块.4" }, "output_blocks_5": { "name": "输出块.5" }, "output_blocks_6": { "name": "输出块.6" }, "output_blocks_7": { "name": "输出块.7" }, "output_blocks_8": { "name": "输出块.8" }, "time_embed_": { "name": "时间嵌入." } } };
const ModelMergeSimple = { "display_name": "模型融合（简易）", "inputs": { "model1": { "name": "模型1" }, "model2": { "name": "模型2" }, "ratio": { "name": "比例" } } };
const ModelMergeSubtract = { "display_name": "模型相减", "inputs": { "model1": { "name": "模型1" }, "model2": { "name": "模型2" }, "multiplier": { "name": "乘数" } } };
const ModelMergeWAN2_1 = { "description": "1.3B模型有30个模块，14B模型有40个模块。图像转视频模型有额外的img_emb。", "display_name": "模型融合（WAN2.1）", "inputs": { "blocks_0_": { "name": "blocks.0." }, "blocks_10_": { "name": "blocks.10." }, "blocks_11_": { "name": "blocks.11." }, "blocks_12_": { "name": "blocks.12." }, "blocks_13_": { "name": "blocks.13." }, "blocks_14_": { "name": "blocks.14." }, "blocks_15_": { "name": "blocks.15." }, "blocks_16_": { "name": "blocks.16." }, "blocks_17_": { "name": "blocks.17." }, "blocks_18_": { "name": "blocks.18." }, "blocks_19_": { "name": "blocks.19." }, "blocks_1_": { "name": "blocks.1." }, "blocks_20_": { "name": "blocks.20." }, "blocks_21_": { "name": "blocks.21." }, "blocks_22_": { "name": "blocks.22." }, "blocks_23_": { "name": "blocks.23." }, "blocks_24_": { "name": "blocks.24." }, "blocks_25_": { "name": "blocks.25." }, "blocks_26_": { "name": "blocks.26." }, "blocks_27_": { "name": "blocks.27." }, "blocks_28_": { "name": "blocks.28." }, "blocks_29_": { "name": "blocks.29." }, "blocks_2_": { "name": "blocks.2." }, "blocks_30_": { "name": "blocks.30." }, "blocks_31_": { "name": "blocks.31." }, "blocks_32_": { "name": "blocks.32." }, "blocks_33_": { "name": "blocks.33." }, "blocks_34_": { "name": "blocks.34." }, "blocks_35_": { "name": "blocks.35." }, "blocks_36_": { "name": "blocks.36." }, "blocks_37_": { "name": "blocks.37." }, "blocks_38_": { "name": "blocks.38." }, "blocks_39_": { "name": "blocks.39." }, "blocks_3_": { "name": "blocks.3." }, "blocks_4_": { "name": "blocks.4." }, "blocks_5_": { "name": "blocks.5." }, "blocks_6_": { "name": "blocks.6." }, "blocks_7_": { "name": "blocks.7." }, "blocks_8_": { "name": "blocks.8." }, "blocks_9_": { "name": "blocks.9." }, "head_": { "name": "head." }, "img_emb_": { "name": "img_emb." }, "model1": { "name": "模型1" }, "model2": { "name": "模型2" }, "patch_embedding_": { "name": "patch_embedding." }, "text_embedding_": { "name": "text_embedding." }, "time_embedding_": { "name": "time_embedding." }, "time_projection_": { "name": "time_projection." } } };
const ModelPatchLoader = { "display_name": "加载模型补丁", "inputs": { "name": { "name": "名称" } } };
const ModelSamplingAuraFlow = { "display_name": "采样算法（AuraFlow）", "inputs": { "model": { "name": "模型" }, "shift": { "name": "移位" } } };
const ModelSamplingContinuousEDM = { "display_name": "采样算法（连续EDM）", "inputs": { "model": { "name": "模型" }, "sampling": { "name": "采样" }, "sigma_max": { "name": "最大西格玛" }, "sigma_min": { "name": "最小西格玛" } } };
const ModelSamplingContinuousV = { "display_name": "采样算法（连续V）", "inputs": { "model": { "name": "模型" }, "sampling": { "name": "采样" }, "sigma_max": { "name": "最大西格玛" }, "sigma_min": { "name": "最小西格玛" } } };
const ModelSamplingDiscrete = { "display_name": "采样算法（离散）", "inputs": { "model": { "name": "模型" }, "sampling": { "name": "采样" }, "zsnr": { "name": "zsnr" } } };
const ModelSamplingFlux = { "display_name": "采样算法（Flux）", "inputs": { "base_shift": { "name": "基础移位" }, "height": { "name": "高度" }, "max_shift": { "name": "最大移位" }, "model": { "name": "模型" }, "width": { "name": "宽度" } } };
const ModelSamplingLTXV = { "display_name": "采样算法（LTXV）", "inputs": { "base_shift": { "name": "基础移位" }, "latent": { "name": "Latent" }, "max_shift": { "name": "最大移位" }, "model": { "name": "模型" } }, "outputs": { "0": { "tooltip": null } } };
const ModelSamplingSD3 = { "display_name": "采样算法（SD3）", "inputs": { "model": { "name": "模型" }, "shift": { "name": "移位" } } };
const ModelSamplingStableCascade = { "display_name": "采样算法（Stable Cascade）", "inputs": { "model": { "name": "模型" }, "shift": { "name": "移位" } } };
const ModelSave = { "display_name": "保存模型", "inputs": { "filename_prefix": { "name": "文件名前缀" }, "model": { "name": "模型" } } };
const MoonvalleyImg2VideoNode = { "description": "Moonvalry Marey 图像转视频节点", "display_name": "Moonvalry Marey 图像转视频", "inputs": { "control_after_generate": { "name": "生成后控制" }, "image": { "name": "图像", "tooltip": "用于生成视频的参考图像" }, "negative_prompt": { "name": "负面提示词", "tooltip": "负面提示词文本" }, "prompt": { "name": "提示词" }, "prompt_adherence": { "name": "提示词遵循度", "tooltip": "用于生成控制的引导尺度" }, "resolution": { "name": "分辨率", "tooltip": "输出视频的分辨率" }, "seed": { "name": "种子", "tooltip": "随机种子值" }, "steps": { "name": "步数", "tooltip": "去噪步数" } }, "outputs": { "0": { "tooltip": null } } };
const MoonvalleyTxt2VideoNode = { "display_name": "Moonvalry Marey 文本转视频", "inputs": { "control_after_generate": { "name": "生成后控制" }, "negative_prompt": { "name": "负面提示词", "tooltip": "负面提示词文本" }, "prompt": { "name": "提示词" }, "prompt_adherence": { "name": "提示词遵循度", "tooltip": "用于生成控制的引导尺度" }, "resolution": { "name": "分辨率", "tooltip": "输出视频的分辨率" }, "seed": { "name": "种子", "tooltip": "随机种子值" }, "steps": { "name": "步数", "tooltip": "推理步数" } }, "outputs": { "0": { "tooltip": null } } };
const MoonvalleyVideo2VideoNode = { "display_name": "Moonvalry Marey 视频转视频", "inputs": { "control_type": { "name": "控制类型" }, "motion_intensity": { "name": "运动强度", "tooltip": "仅在控制类型为'运动转移'时使用" }, "negative_prompt": { "name": "负面提示词", "tooltip": "负面提示词文本" }, "prompt": { "name": "提示词", "tooltip": "描述要生成的视频" }, "seed": { "name": "种子", "tooltip": "随机种子值" }, "steps": { "name": "步数", "tooltip": "推理步数" }, "video": { "name": "视频", "tooltip": "用于生成输出视频的参考视频。必须至少5秒长。超过5秒的视频将被自动裁剪。仅支持MP4格式。" } }, "outputs": { "0": { "tooltip": null } } };
const Morphology = { "display_name": "图像形态学", "inputs": { "image": { "name": "图像" }, "kernel_size": { "name": "核心大小" }, "operation": { "name": "操作" } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIChatConfig = { "description": "允许为OpenAI聊天节点指定高级配置选项。", "display_name": "OpenAI ChatGPT 高级选项", "inputs": { "instructions": { "name": "指令", "tooltip": "指导模型如何生成响应的指令" }, "max_output_tokens": { "name": "Token输出上限", "tooltip": "生成响应时可生成token数量的上限，包括可见输出token" }, "truncation": { "name": "截断", "tooltip": "用于模型响应的截断策略。auto：如果此响应和先前响应的上下文超过模型的上下文窗口大小，模型将通过丢弃对话中间部分的输入项来截断响应以适应上下文窗口。disabled：如果模型响应将超过模型的上下文窗口大小，请求将失败并返回400错误。" } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIChatNode = { "description": "从OpenAI模型生成文本响应。", "display_name": "OpenAI ChatGPT", "inputs": { "advanced_options": { "name": "高级设置", "tooltip": "模型的可选配置。接受来自OpenAI聊天高级选项节点的输入。" }, "files": { "name": "文件", "tooltip": "可选文件，用作模型的上下文。接受来自OpenAI聊天输入文件节点的输入。" }, "images": { "name": "图像", "tooltip": "可选图像，用作模型的上下文。要包含多张图像，可使用批处理图像节点。" }, "model": { "name": "模型", "tooltip": "用于生成响应的模型" }, "persist_context": { "name": "保持上下文", "tooltip": "此参数已弃用，无任何效果。" }, "prompt": { "name": "提示词", "tooltip": "模型的文本输入，用于生成响应。" } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIDalle2 = { "description": "通过 OpenAI 的 DALL·E 2 接口同步生成图像。", "display_name": "OpenAI DALL·E 2", "inputs": { "control_after_generate": { "name": "生成后控制" }, "image": { "name": "参考图像", "tooltip": "用于图像编辑的可选参考图像。" }, "mask": { "name": "掩码", "tooltip": "用于修复的可选掩码（白色区域将被替换）" }, "n": { "name": "数量", "tooltip": "生成的图像数量" }, "prompt": { "name": "提示词", "tooltip": "用于 DALL·E 的文本提示" }, "seed": { "name": "种子", "tooltip": "后端尚未实现" }, "size": { "name": "尺寸", "tooltip": "图像尺寸" } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIDalle3 = { "description": "通过 OpenAI 的 DALL·E 3 接口同步生成图像。", "display_name": "OpenAI DALL·E 3", "inputs": { "control_after_generate": { "name": "生成后控制" }, "prompt": { "name": "提示词", "tooltip": "DALL·E 的文本提示" }, "quality": { "name": "质量", "tooltip": "图像质量" }, "seed": { "name": "种子", "tooltip": "后端尚未实现" }, "size": { "name": "尺寸", "tooltip": "图像尺寸" }, "style": { "name": "风格", "tooltip": "“生动”会让模型倾向于生成超现实和戏剧性的图像。“自然”会让模型生成更自然、较少超现实感的图像。" } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIGPTImage1 = { "description": "通过 OpenAI 的 GPT Image 1 端点同步生成图像。", "display_name": "OpenAI GPT Image 1", "inputs": { "background": { "name": "背景", "tooltip": "返回带有或不带背景的图像" }, "control_after_generate": { "name": "生成后控制" }, "image": { "name": "参考图像", "tooltip": "用于图像编辑的可选参考图像。" }, "mask": { "name": "遮罩", "tooltip": "用于修复的可选 mask（白色区域将被替换）" }, "n": { "name": "数量", "tooltip": "生成多少张图像" }, "prompt": { "name": "提示词", "tooltip": "用于 GPT Image 1 的文本提示" }, "quality": { "name": "质量", "tooltip": "图像质量，影响成本和生成时间。" }, "seed": { "name": "种子", "tooltip": "后端尚未实现" }, "size": { "name": "尺寸", "tooltip": "图像尺寸" } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIInputFiles = { "description": "加载并准备输入文件（文本、PDF等）作为OpenAI聊天节点的输入。生成响应时，OpenAI模型将读取这些文件。🛈 提示：可与其他OpenAI输入文件节点链式连接。", "display_name": "OpenAI ChatGPT Input Files", "inputs": { "OPENAI_INPUT_FILES": { "name": "OpenAI输入文件", "tooltip": "可选的附加文件，与此节点加载的文件一起批处理。允许链式连接输入文件，以便单个消息可包含多个输入文件。" }, "file": { "name": "文件", "tooltip": "作为模型上下文的输入文件。目前仅接受文本(.txt)和PDF(.pdf)文件。" } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIVideoSora2 = { "description": "OpenAI视频和音频生成。", "display_name": "OpenAI Sora - Video", "inputs": { "control_after_generate": { "name": "生成后控制" }, "duration": { "name": "时长" }, "image": { "name": "图像" }, "model": { "name": "模型" }, "prompt": { "name": "提示词", "tooltip": "引导文本；如果存在输入图像，可为空。" }, "seed": { "name": "随机种", "tooltip": "确定节点是否应重新运行的种子；无论种子如何，实际结果都是非确定性的。" }, "size": { "name": "尺寸" } }, "outputs": { "0": { "tooltip": null } } };
const OptimalStepsScheduler = { "display_name": "OptimalSteps调度器", "inputs": { "denoise": { "name": "去噪" }, "model_type": { "name": "模型" }, "steps": { "name": "步数" } }, "outputs": { "0": { "tooltip": null } } };
const PairConditioningCombine = { "display_name": "条件对合并", "inputs": { "negative_A": { "name": "负面条件_A" }, "negative_B": { "name": "负面条件_B" }, "positive_A": { "name": "正面条件_A" }, "positive_B": { "name": "正面条件_B" } }, "outputs": { "0": { "name": "正面条件" }, "1": { "name": "负面条件" } } };
const PairConditioningSetDefaultCombine = { "display_name": "条件对设置默认合并", "inputs": { "hooks": { "name": "约束" }, "negative": { "name": "负面条件" }, "negative_DEFAULT": { "name": "默认负面条件" }, "positive": { "name": "正面条件" }, "positive_DEFAULT": { "name": "默认正面条件" } }, "outputs": { "0": { "name": "正面条件" }, "1": { "name": "负面条件" } } };
const PairConditioningSetProperties = { "display_name": "条件对设置属性", "inputs": { "hooks": { "name": "约束" }, "mask": { "name": "遮罩" }, "negative_NEW": { "name": "新负面条件" }, "positive_NEW": { "name": "新正面条件" }, "set_cond_area": { "name": "设置条件区域" }, "strength": { "name": "强度" }, "timesteps": { "name": "间隔" } }, "outputs": { "0": { "name": "正面条件" }, "1": { "name": "负面条件" } } };
const PairConditioningSetPropertiesAndCombine = { "display_name": "条件对设置属性合并", "inputs": { "hooks": { "name": "约束" }, "mask": { "name": "遮罩" }, "negative": { "name": "负面条件" }, "negative_NEW": { "name": "新负面条件" }, "positive": { "name": "正面条件" }, "positive_NEW": { "name": "新正面条件" }, "set_cond_area": { "name": "设置条件区域" }, "strength": { "name": "强度" }, "timesteps": { "name": "间隔" } }, "outputs": { "0": { "name": "正面条件" }, "1": { "name": "负面条件" } } };
const PatchModelAddDownscale = { "display_name": "收缩模型UNET（Kohya Deep Shrink）", "inputs": { "block_number": { "name": "层编号" }, "downscale_after_skip": { "name": "跳过后收缩" }, "downscale_factor": { "name": "收缩系数" }, "downscale_method": { "name": "收缩算法" }, "end_percent": { "name": "结束百分比" }, "model": { "name": "模型" }, "start_percent": { "name": "开始百分比" }, "upscale_method": { "name": "放大方法" } }, "outputs": { "0": { "tooltip": null } } };
const PerpNeg = { "display_name": "Perp-Neg（已弃用，使用PerpNegGuider）", "inputs": { "empty_conditioning": { "name": "空条件" }, "model": { "name": "模型" }, "neg_scale": { "name": "负面缩放" } }, "outputs": { "0": { "tooltip": null } } };
const PerpNegGuider = { "display_name": "PerpNeg引导器", "inputs": { "cfg": { "name": "cfg" }, "empty_conditioning": { "name": "空条件" }, "model": { "name": "模型" }, "neg_scale": { "name": "负面缩放" }, "negative": { "name": "负面条件" }, "positive": { "name": "正面条件" } }, "outputs": { "0": { "tooltip": null } } };
const PerturbedAttentionGuidance = { "display_name": "PAG注意力引导", "inputs": { "model": { "name": "模型" }, "scale": { "name": "规模" } }, "outputs": { "0": { "tooltip": null } } };
const PhotoMakerEncode = { "display_name": "PhotoMaker编码", "inputs": { "clip": { "name": "clip" }, "image": { "name": "图像" }, "photomaker": { "name": "photomaker" }, "text": { "name": "文本" } }, "outputs": { "0": { "tooltip": null } } };
const PhotoMakerLoader = { "display_name": "PhotoMaker加载器", "inputs": { "photomaker_model_name": { "name": "photomaker模型名称" } }, "outputs": { "0": { "tooltip": null } } };
const PixverseImageToVideoNode = { "description": "根据提示词和输出尺寸同步生成视频。", "display_name": "PixVerse 图像转视频", "inputs": { "control_after_generate": { "name": "生成后控制" }, "duration_seconds": { "name": "时长（秒）" }, "image": { "name": "图像" }, "motion_mode": { "name": "运动模式" }, "negative_prompt": { "name": "反向提示词", "tooltip": "可选的文本描述，用于指定图像中不希望出现的元素。" }, "pixverse_template": { "name": "PixVerse 模板", "tooltip": "可选模板，由 PixVerse Template 节点创建，用于影响生成风格。" }, "prompt": { "name": "提示词", "tooltip": "用于视频生成的提示词" }, "quality": { "name": "质量" }, "seed": { "name": "种子", "tooltip": "用于视频生成的种子。" } }, "outputs": { "0": { "tooltip": null } } };
const PixverseTemplateNode = { "display_name": "PixVerse 模板", "inputs": { "template": { "name": "模板" } }, "outputs": { "0": { "name": "Pixverse模板", "tooltip": null } } };
const PixverseTextToVideoNode = { "description": "根据提示词和输出尺寸同步生成视频。", "display_name": "PixVerse 文本转视频", "inputs": { "aspect_ratio": { "name": "宽高比" }, "control_after_generate": { "name": "生成后控制" }, "duration_seconds": { "name": "时长（秒）" }, "motion_mode": { "name": "运动模式" }, "negative_prompt": { "name": "反向提示词", "tooltip": "用于描述图像中不希望出现元素的可选文本。" }, "pixverse_template": { "name": "PixVerse 模板", "tooltip": "可选模板，用于影响生成风格，由 PixVerse Template 节点创建。" }, "prompt": { "name": "提示词", "tooltip": "用于视频生成的提示词" }, "quality": { "name": "质量" }, "seed": { "name": "种子", "tooltip": "用于视频生成的种子。" } }, "outputs": { "0": { "tooltip": null } } };
const PixverseTransitionVideoNode = { "description": "根据提示词和输出尺寸同步生成视频。", "display_name": "PixVerse 转场视频", "inputs": { "control_after_generate": { "name": "生成后控制" }, "duration_seconds": { "name": "时长（秒）" }, "first_frame": { "name": "首帧" }, "last_frame": { "name": "末帧" }, "motion_mode": { "name": "运动模式" }, "negative_prompt": { "name": "反向提示词", "tooltip": "用于描述图像中不希望出现元素的可选文本。" }, "prompt": { "name": "提示词", "tooltip": "用于视频生成的提示词" }, "quality": { "name": "质量" }, "seed": { "name": "种子", "tooltip": "用于视频生成的种子。" } }, "outputs": { "0": { "tooltip": null } } };
const PolyexponentialScheduler = { "display_name": "Polyexponential调度器", "inputs": { "rho": { "name": "rho" }, "sigma_max": { "name": "sigma最大值" }, "sigma_min": { "name": "sigma最小值" }, "steps": { "name": "步数" } } };
const PorterDuffImageComposite = { "display_name": "Porter-Duff图像合成", "inputs": { "destination": { "name": "目标图像" }, "destination_alpha": { "name": "目标图像alpha" }, "mode": { "name": "模式" }, "source": { "name": "来源图像" }, "source_alpha": { "name": "来源图像alpha" } }, "outputs": { "0": { "tooltip": null }, "1": { "tooltip": null } } };
const Preview3D = { "display_name": "预览3D", "inputs": { "camera_info": { "name": "相机信息" }, "image": { "name": "图像" }, "model_file": { "name": "模型文件" } } };
const PreviewAny = { "display_name": "预览任意", "inputs": { "preview": {}, "source": { "name": "源" } } };
const PreviewAudio = { "display_name": "预览音频", "inputs": { "audio": { "name": "音频" }, "audioUI": { "name": "音频UI" } } };
const PreviewImage = { "description": "将输入图像保存到您的ComfyUI临时目录。", "display_name": "预览图像", "inputs": { "images": { "name": "图像" } } };
const PrimitiveBoolean = { "display_name": "布尔值", "inputs": { "value": { "name": "值" } }, "outputs": { "0": { "tooltip": null } } };
const PrimitiveFloat = { "display_name": "浮点数", "inputs": { "value": { "name": "值" } }, "outputs": { "0": { "tooltip": null } } };
const PrimitiveInt = { "display_name": "整数", "inputs": { "control_after_generate": { "name": "生成后控制" }, "value": { "name": "数值" } }, "outputs": { "0": { "tooltip": null } } };
const PrimitiveString = { "display_name": "字符串", "inputs": { "value": { "name": "值" } }, "outputs": { "0": { "tooltip": null } } };
const PrimitiveStringMultiline = { "display_name": "字符串（多行）", "inputs": { "value": { "name": "值" } }, "outputs": { "0": { "tooltip": null } } };
const QuadrupleCLIPLoader = { "description": "[配方]\n\nhidream: long clip-l, long clip-g, t5xxl, llama_8b_3.1_instruct", "display_name": "四重CLIP加载器", "inputs": { "clip_name1": { "name": "clip_name1" }, "clip_name2": { "name": "clip_name2" }, "clip_name3": { "name": "clip_name3" }, "clip_name4": { "name": "clip_name4" } }, "outputs": { "0": { "tooltip": null } } };
const QwenImageDiffsynthControlnet = { "display_name": "QwenImageDiffsynthControlnet", "inputs": { "image": { "name": "图像" }, "mask": { "name": "遮罩" }, "model": { "name": "模型" }, "model_patch": { "name": "模型补丁" }, "strength": { "name": "强度" }, "vae": { "name": "vae" } } };
const RandomNoise = { "display_name": "随机噪波", "inputs": { "control_after_generate": { "name": "生成后控制" }, "noise_seed": { "name": "噪波随机种" } } };
const RebatchImages = { "display_name": "重设图像批次", "inputs": { "batch_size": { "name": "批量大小" }, "images": { "name": "图像" } }, "outputs": { "0": { "tooltip": null } } };
const RebatchLatents = { "display_name": "重设Latent批次", "inputs": { "batch_size": { "name": "批量大小" }, "latents": { "name": "Latent因素" } }, "outputs": { "0": { "tooltip": null } } };
const RecordAudio = { "display_name": "录制音频", "inputs": { "audio": { "name": "音频" } } };
const RecraftColorRGB = { "description": "通过选择特定的 RGB 值来创建 Recraft 颜色。", "display_name": "Recraft 颜色 RGB", "inputs": { "b": { "name": "b", "tooltip": "颜色的蓝色值。" }, "g": { "name": "g", "tooltip": "颜色的绿色值。" }, "r": { "name": "r", "tooltip": "颜色的红色值。" }, "recraft_color": { "name": "Recraft色彩" } }, "outputs": { "0": { "name": "Recraft色彩", "tooltip": null } } };
const RecraftControls = { "description": "创建 Recraft 控件以自定义 Recraft 生成。", "display_name": "Recraft 控件", "inputs": { "background_color": { "name": "背景色" }, "colors": { "name": "色彩" } }, "outputs": { "0": { "name": "Recraft控制", "tooltip": null } } };
const RecraftCreativeUpscaleNode = { "description": "同步放大图像。\n使用“创意放大”工具增强给定的光栅图像，提升分辨率，重点优化细节和人脸。", "display_name": "Recraft 创意放大图像", "inputs": { "image": { "name": "图像" } }, "outputs": { "0": { "tooltip": null } } };
const RecraftCrispUpscaleNode = { "description": "同步放大图像。\n使用“清晰放大”工具增强给定的光栅图像，提高图像分辨率，使图像更加锐利和干净。", "display_name": "Recraft 清晰放大图像", "inputs": { "image": { "name": "图像" } }, "outputs": { "0": { "tooltip": null } } };
const RecraftImageInpaintingNode = { "description": "根据提示词和 mask 修改图像。", "display_name": "Recraft 图像修复", "inputs": { "control_after_generate": { "name": "生成后控制" }, "image": { "name": "图像" }, "mask": { "name": "遮罩" }, "n": { "name": "数量", "tooltip": "要生成的图像数量。" }, "negative_prompt": { "name": "反向提示词", "tooltip": "对图像中不希望出现元素的可选文本描述。" }, "prompt": { "name": "提示词", "tooltip": "用于图像生成的提示词。" }, "recraft_style": { "name": "Recraft风格" }, "seed": { "name": "种子", "tooltip": "用于决定节点是否重新运行的种子；无论种子如何，实际结果都是非确定性的。" } }, "outputs": { "0": { "tooltip": null } } };
const RecraftImageToImageNode = { "description": "根据提示词和强度修改图像。", "display_name": "Recraft 图像到图像", "inputs": { "control_after_generate": { "name": "生成后控制" }, "image": { "name": "图像" }, "n": { "name": "数量", "tooltip": "要生成的图像数量。" }, "negative_prompt": { "name": "反向提示词", "tooltip": "可选的文本描述，用于指定图像中不希望出现的元素。" }, "prompt": { "name": "提示词", "tooltip": "用于生成图像的提示词。" }, "recraft_controls": { "name": "Recraft控制", "tooltip": "通过 Recraft Controls 节点对生成过程进行可选的附加控制。" }, "recraft_style": { "name": "Recraft风格" }, "seed": { "name": "种子", "tooltip": "用于决定节点是否重新运行的种子；无论种子如何，实际结果都是非确定性的。" }, "strength": { "name": "强度", "tooltip": "定义与原始图像的差异，范围为[0, 1]，0表示几乎相同，1表示极大不同。" } }, "outputs": { "0": { "tooltip": null } } };
const RecraftRemoveBackgroundNode = { "description": "从图像中移除背景，返回处理后的图像和 mask。", "display_name": "Recraft 移除背景", "inputs": { "image": { "name": "图像" } }, "outputs": { "0": { "tooltip": null }, "1": { "tooltip": null } } };
const RecraftReplaceBackgroundNode = { "description": "根据提供的提示词替换图像背景。", "display_name": "Recraft 更换背景", "inputs": { "control_after_generate": { "name": "生成后控制" }, "image": { "name": "图像" }, "n": { "name": "数量", "tooltip": "要生成的图像数量。" }, "negative_prompt": { "name": "反向提示词", "tooltip": "对图像中不希望出现元素的可选文本描述。" }, "prompt": { "name": "提示词", "tooltip": "用于图像生成的提示词。" }, "recraft_style": { "name": "recraft 风格" }, "seed": { "name": "种子", "tooltip": "用于决定节点是否重新运行的种子；无论种子如何，实际结果都是非确定性的。" } }, "outputs": { "0": { "tooltip": null } } };
const RecraftStyleV3DigitalIllustration = { "description": "选择 realistic_image 风格和可选的子风格。", "display_name": "Recraft 风格 - 数字插画", "inputs": { "substyle": { "name": "子风格" } }, "outputs": { "0": { "name": "Recraft风格", "tooltip": null } } };
const RecraftStyleV3InfiniteStyleLibrary = { "description": "根据 Recraft 的无限风格库中已有的 UUID 选择风格。", "display_name": "Recraft 风格 - 无限风格库", "inputs": { "style_id": { "name": "风格ID", "tooltip": "来自无限风格库的风格 UUID。" } }, "outputs": { "0": { "name": "Recraft风格", "tooltip": null } } };
const RecraftStyleV3LogoRaster = { "description": "选择 realistic_image 风格和可选的子风格。", "display_name": "Recraft 风格 - 标志光栅图", "inputs": { "substyle": { "name": "子风格" } }, "outputs": { "0": { "name": "Recraft风格", "tooltip": null } } };
const RecraftStyleV3RealisticImage = { "description": "选择 realistic_image 风格和可选的子风格。", "display_name": "Recraft 风格 - 真实图像", "inputs": { "substyle": { "name": "子风格" } }, "outputs": { "0": { "name": "Recraft风格", "tooltip": null } } };
const RecraftTextToImageNode = { "description": "根据提示词和分辨率同步生成图像。", "display_name": "Recraft 文本转图像", "inputs": { "control_after_generate": { "name": "生成后控制" }, "n": { "name": "n", "tooltip": "要生成的图像数量。" }, "negative_prompt": { "name": "负面提示词", "tooltip": "对图像中不希望出现元素的可选文本描述。" }, "prompt": { "name": "提示词", "tooltip": "用于图像生成的提示词。" }, "recraft_controls": { "name": "Recraft控制", "tooltip": "通过 Recraft Controls 节点对生成过程的可选附加控制。" }, "recraft_style": { "name": "Recraft风格" }, "seed": { "name": "随机种", "tooltip": "用于决定节点是否重新运行的种子；无论种子如何，实际结果都是非确定性的。" }, "size": { "name": "尺寸", "tooltip": "生成图像的尺寸。" } }, "outputs": { "0": { "tooltip": null } } };
const RecraftTextToVectorNode = { "description": "根据提示词和分辨率同步生成 SVG。", "display_name": "Recraft 文本转矢量", "inputs": { "control_after_generate": { "name": "生成后控制" }, "n": { "name": "数量", "tooltip": "要生成的图像数量。" }, "negative_prompt": { "name": "反向提示词", "tooltip": "对图像中不希望出现元素的可选文本描述。" }, "prompt": { "name": "提示词", "tooltip": "用于生成图像的提示词。" }, "recraft_controls": { "name": "Recraft 控制", "tooltip": "通过 Recraft Controls 节点对生成过程的可选附加控制。" }, "seed": { "name": "种子", "tooltip": "用于决定节点是否重新运行的种子；无论种子如何，实际结果都是非确定性的。" }, "size": { "name": "尺寸", "tooltip": "生成图像的尺寸。" }, "substyle": { "name": "子风格" } }, "outputs": { "0": { "tooltip": null } } };
const RecraftVectorizeImageNode = { "description": "从输入图像同步生成 SVG。", "display_name": "Recraft 矢量化图像", "inputs": { "image": { "name": "图像" } }, "outputs": { "0": { "tooltip": null } } };
const ReferenceLatent = { "description": "此节点为编辑模型设置引导潜在空间。如果模型支持，您可以链式连接多个以设置多个参考图像。", "display_name": "参考Latent", "inputs": { "conditioning": { "name": "条件" }, "latent": { "name": "Latent" } }, "outputs": { "0": { "tooltip": null } } };
const RegexExtract = { "display_name": "正则表达式提取", "inputs": { "case_insensitive": { "name": "忽略大小写" }, "dotall": { "name": "点号匹配所有" }, "group_index": { "name": "分组索引" }, "mode": { "name": "模式" }, "multiline": { "name": "多行模式" }, "regex_pattern": { "name": "正则表达式模式" }, "string": { "name": "字符串" } }, "outputs": { "0": { "tooltip": null } } };
const RegexMatch = { "display_name": "正则表达式匹配", "inputs": { "case_insensitive": { "name": "忽略大小写" }, "dotall": { "name": "点号匹配所有" }, "multiline": { "name": "多行模式" }, "regex_pattern": { "name": "正则表达式模式" }, "string": { "name": "字符串" } }, "outputs": { "0": { "name": "匹配结果", "tooltip": null } } };
const RegexReplace = { "description": "使用正则表达式模式查找和替换文本。", "display_name": "正则表达式替换", "inputs": { "case_insensitive": { "name": "忽略大小写" }, "count": { "name": "计数", "tooltip": "最大替换次数。设置为0可替换所有匹配项（默认）。设置为1仅替换第一个匹配项，2替换前两个匹配项，依此类推。" }, "dotall": { "name": "点号匹配所有", "tooltip": "启用时，点号（.）字符将匹配包括换行符在内的任何字符。禁用时，点号不会匹配换行符。" }, "multiline": { "name": "多行模式" }, "regex_pattern": { "name": "正则表达式模式" }, "replace": { "name": "替换内容" }, "string": { "name": "字符串" } }, "outputs": { "0": { "tooltip": null } } };
const RenormCFG = { "display_name": "RenormCFG", "inputs": { "cfg_trunc": { "name": "cfg_trunc" }, "model": { "name": "模型" }, "renorm_cfg": { "name": "renorm_cfg" } }, "outputs": { "0": { "tooltip": null } } };
const RepeatImageBatch = { "display_name": "复制图像批次", "inputs": { "amount": { "name": "数量" }, "image": { "name": "图像" } } };
const RepeatLatentBatch = { "display_name": "复制Latent批次", "inputs": { "amount": { "name": "数量" }, "samples": { "name": "Latent" } } };
const RescaleCFG = { "display_name": "缩放CFG", "inputs": { "model": { "name": "模型" }, "multiplier": { "name": "乘数" } } };
const ResizeAndPadImage = { "display_name": "调整尺寸并填充图像", "inputs": { "image": { "name": "图像" }, "interpolation": { "name": "插值方法" }, "padding_color": { "name": "填充颜色" }, "target_height": { "name": "目标高度" }, "target_width": { "name": "目标宽度" } } };
const Rodin3D_Detail = { "description": "使用Rodin API生成3D资源", "display_name": "Rodin 3D生成 - 细节生成", "inputs": { "Images": { "name": "图像" }, "Material_Type": { "name": "材质类型" }, "Polygon_count": { "name": "多边形数量" }, "Seed": { "name": "种子" } }, "outputs": { "0": { "name": "3D模型路径", "tooltip": null } } };
const Rodin3D_Gen2 = { "description": "使用Rodin API生成3D资源", "display_name": "Rodin 3D生成 - Gen-2生成", "inputs": { "Images": { "name": "图像" }, "Material_Type": { "name": "材质类型" }, "Polygon_count": { "name": "多边形数量" }, "Seed": { "name": "种子" }, "TAPose": { "name": "TAPose" } }, "outputs": { "0": { "name": "3D模型路径", "tooltip": null } } };
const Rodin3D_Regular = { "description": "使用Rodin API生成3D资源", "display_name": "Rodin 3D生成 - 常规生成", "inputs": { "Images": { "name": "图像" }, "Material_Type": { "name": "材质类型" }, "Polygon_count": { "name": "多边形数量" }, "Seed": { "name": "种子" } }, "outputs": { "0": { "name": "3D模型路径", "tooltip": null } } };
const Rodin3D_Sketch = { "description": "使用Rodin API生成3D资源", "display_name": "Rodin 3D生成 - 草图生成", "inputs": { "Images": { "name": "图像" }, "Seed": { "name": "种子" } }, "outputs": { "0": { "name": "3D模型路径", "tooltip": null } } };
const Rodin3D_Smooth = { "description": "使用Rodin API生成3D资源", "display_name": "Rodin 3D生成 - 平滑生成", "inputs": { "Images": { "name": "图像" }, "Material_Type": { "name": "材质类型" }, "Polygon_count": { "name": "多边形数量" }, "Seed": { "name": "种子" } }, "outputs": { "0": { "name": "3D模型路径", "tooltip": null } } };
const RunwayFirstLastFrameNode = { "description": "上传首尾关键帧，草拟提示词，生成视频。对于更复杂的过渡（例如尾帧与首帧完全不同的情况），较长的10秒时长可能更有利，这能为生成过程提供更多时间在两个输入之间平滑过渡。开始前，请查看这些最佳实践以确保您的输入选择能为生成成功奠定基础：https://help.runwayml.com/hc/en-us/articles/34170748696595-Creating-with-Keyframes-on-Gen-3。", "display_name": "Runway首尾帧转视频", "inputs": { "control_after_generate": { "name": "生成后控制" }, "duration": { "name": "时长" }, "end_frame": { "name": "结束帧", "tooltip": "用于视频的结束帧。仅支持gen3a_turbo。" }, "prompt": { "name": "提示词", "tooltip": "生成的文本提示词" }, "ratio": { "name": "比例" }, "seed": { "name": "种子", "tooltip": "生成的随机种子" }, "start_frame": { "name": "起始帧", "tooltip": "用于视频的起始帧" } }, "outputs": { "0": { "tooltip": null } } };
const RunwayImageToVideoNodeGen3a = { "description": "使用Gen3a Turbo模型从单个起始帧生成视频。开始前，请查看这些最佳实践以确保您的输入选择能为生成成功奠定基础：https://help.runwayml.com/hc/en-us/articles/33927968552339-Creating-with-Act-One-on-Gen-3-Alpha-and-Turbo。", "display_name": "Runway图像转视频（Gen3a Turbo）", "inputs": { "control_after_generate": { "name": "生成后控制" }, "duration": { "name": "时长" }, "prompt": { "name": "提示词", "tooltip": "生成的文本提示词" }, "ratio": { "name": "比例" }, "seed": { "name": "种子", "tooltip": "生成的随机种子" }, "start_frame": { "name": "起始帧", "tooltip": "用于视频的起始帧" } }, "outputs": { "0": { "tooltip": null } } };
const RunwayImageToVideoNodeGen4 = { "description": "使用Gen4 Turbo模型从单个起始帧生成视频。开始前，请查看这些最佳实践以确保您的输入选择能为生成成功奠定基础：https://help.runwayml.com/hc/en-us/articles/37327109429011-Creating-with-Gen-4-Video。", "display_name": "Runway图像转视频（Gen4 Turbo）", "inputs": { "control_after_generate": { "name": "生成后控制" }, "duration": { "name": "时长" }, "prompt": { "name": "提示词", "tooltip": "生成的文本提示词" }, "ratio": { "name": "比例" }, "seed": { "name": "种子", "tooltip": "生成的随机种子" }, "start_frame": { "name": "起始帧", "tooltip": "用于视频的起始帧" } }, "outputs": { "0": { "tooltip": null } } };
const RunwayTextToImageNode = { "description": "使用 Runway 的 Gen 4 模型从文本提示生成图像。您还可以包含参考图像来引导生成过程。", "display_name": "Runway 文生图", "inputs": { "prompt": { "name": "提示词", "tooltip": "用于生成的文本提示" }, "ratio": { "name": "比例" }, "reference_image": { "name": "参考图像", "tooltip": "用于引导生成的可选参考图像" } }, "outputs": { "0": { "tooltip": null } } };
const SDTurboScheduler = { "display_name": "SDTurbo调度器", "inputs": { "denoise": { "name": "降噪" }, "model": { "name": "模型" }, "steps": { "name": "步数" } } };
const SD_4XUpscale_Conditioning = { "display_name": "SD_4X放大条件", "inputs": { "images": { "name": "图片" }, "negative": { "name": "负面条件" }, "noise_augmentation": { "name": "噪波增强" }, "positive": { "name": "正面条件" }, "scale_ratio": { "name": "缩放比例" } }, "outputs": { "0": { "name": "正面条件", "tooltip": null }, "1": { "name": "负面条件", "tooltip": null }, "2": { "name": "Latent", "tooltip": null } } };
const SV3D_Conditioning = { "display_name": "SV3D条件", "inputs": { "clip_vision": { "name": "clip视觉" }, "elevation": { "name": "俯仰角" }, "height": { "name": "高度" }, "init_image": { "name": "初始图像" }, "vae": { "name": "vae" }, "video_frames": { "name": "帧数" }, "width": { "name": "宽度" } }, "outputs": { "0": { "name": "正面条件", "tooltip": null }, "1": { "name": "负面条件", "tooltip": null }, "2": { "name": "Latent", "tooltip": null } } };
const SVD_img2vid_Conditioning = { "display_name": "SVD_img2vid条件", "inputs": { "augmentation_level": { "name": "增强" }, "clip_vision": { "name": "clip视觉" }, "fps": { "name": "帧率" }, "height": { "name": "高度" }, "init_image": { "name": "初始图像" }, "motion_bucket_id": { "name": "动态bucketID" }, "vae": { "name": "vae" }, "video_frames": { "name": "帧数" }, "width": { "name": "宽度" } }, "outputs": { "0": { "name": "正面条件" }, "1": { "name": "负面条件" }, "2": { "name": "Latent" } } };
const SamplerCustom = { "display_name": "自定义采样器", "inputs": { "add_noise": { "name": "添加噪波" }, "cfg": { "name": "cfg" }, "control_after_generate": { "name": "生成后的控制" }, "latent_image": { "name": "Latent" }, "model": { "name": "模型" }, "negative": { "name": "负面条件" }, "noise_seed": { "name": "噪波种子" }, "positive": { "name": "正面条件" }, "sampler": { "name": "采样器" }, "sigmas": { "name": "Sigmas" } }, "outputs": { "0": { "name": "Latent" }, "1": { "name": "降噪Latent" } } };
const SamplerCustomAdvanced = { "display_name": "自定义采样器（高级）", "inputs": { "guider": { "name": "引导器" }, "latent_image": { "name": "Latent图像" }, "noise": { "name": "噪波" }, "sampler": { "name": "采样器" }, "sigmas": { "name": "西格玛" } }, "outputs": { "0": { "name": "Latent" }, "1": { "name": "降噪Latent" } } };
const SamplerDPMAdaptative = { "display_name": "DPMAdaptative采样器", "inputs": { "accept_safety": { "name": "accept_safety" }, "atol": { "name": "atol" }, "dcoeff": { "name": "dcoeff" }, "eta": { "name": "eta" }, "h_init": { "name": "h_init" }, "icoeff": { "name": "icoeff" }, "order": { "name": "order" }, "pcoeff": { "name": "pcoeff" }, "rtol": { "name": "rtol" }, "s_noise": { "name": "s_noise" } } };
const SamplerDPMPP_2M_SDE = { "display_name": "DPMPP_2M_SDE采样器", "inputs": { "eta": { "name": "eta" }, "noise_device": { "name": "设备" }, "s_noise": { "name": "s_noise" }, "solver_type": { "name": "求解器类型" } } };
const SamplerDPMPP_2S_Ancestral = { "display_name": "DPMPP_2S_Ancestral采样器", "inputs": { "eta": { "name": "eta" }, "s_noise": { "name": "s_noise" } } };
const SamplerDPMPP_3M_SDE = { "display_name": "DPMPP_3M_SDE采样器", "inputs": { "eta": { "name": "eta" }, "noise_device": { "name": "设备" }, "s_noise": { "name": "s_noise" } } };
const SamplerDPMPP_SDE = { "display_name": "DPMPP_SDE采样器", "inputs": { "eta": { "name": "eta" }, "noise_device": { "name": "设备" }, "r": { "name": "r" }, "s_noise": { "name": "s_noise" } } };
const SamplerER_SDE = { "display_name": "SamplerER_SDE", "inputs": { "eta": { "name": "eta", "tooltip": "反向时间 SDE 的随机强度。\n当 eta=0 时，简化为确定性 ODE。此设置不适用于 ER-SDE 求解器类型。" }, "max_stage": { "name": "最大阶段" }, "s_noise": { "name": "s_noise" }, "solver_type": { "name": "求解器类型" } } };
const SamplerEulerAncestral = { "display_name": "EulerAncestral采样器", "inputs": { "eta": { "name": "eta" }, "s_noise": { "name": "s噪波" } } };
const SamplerEulerAncestralCFGPP = { "display_name": "EulerAncestralCFG++采样器", "inputs": { "eta": { "name": "eta" }, "s_noise": { "name": "s噪波" } } };
const SamplerEulerCFGpp = { "display_name": "EuleCFG++采样器", "inputs": { "version": { "name": "版本" } }, "outputs": { "0": { "tooltip": null } } };
const SamplerLCMUpscale = { "display_name": "LCM缩放采样器", "inputs": { "scale_ratio": { "name": "缩放比例" }, "scale_steps": { "name": "缩放步数" }, "upscale_method": { "name": "缩放方法" } }, "outputs": { "0": { "tooltip": null } } };
const SamplerLMS = { "display_name": "LMS采样器", "inputs": { "order": { "name": "顺序" } } };
const SamplerSASolver = { "display_name": "SASolver采样器", "inputs": { "corrector_order": { "name": "校正器阶数" }, "eta": { "name": "eta" }, "model": { "name": "模型" }, "predictor_order": { "name": "预测器阶数" }, "s_noise": { "name": "s_noise" }, "sde_end_percent": { "name": "SDE 结束百分比" }, "sde_start_percent": { "name": "SDE 起始百分比" }, "simple_order_2": { "name": "简单二阶" }, "use_pece": { "name": "使用 PECE" } } };
const SamplingPercentToSigma = { "display_name": "采样比到Sigma", "inputs": { "model": { "name": "模型" }, "return_actual_sigma": { "name": "返回实际 sigma 值", "tooltip": "返回实际的 sigma 值而不是用于区间检查的值。\n这仅影响 0.0 和 1.0 处的结果。" }, "sampling_percent": { "name": "采样百分比" } }, "outputs": { "0": { "name": "sigma 值" } } };
const SaveAnimatedPNG = { "display_name": "保存动画（APNG）", "inputs": { "compress_level": { "name": "压缩级别" }, "filename_prefix": { "name": "文件名前缀" }, "fps": { "name": "帧率" }, "images": { "name": "图片" } } };
const SaveAnimatedWEBP = { "display_name": "保存动画（WEBP）", "inputs": { "filename_prefix": { "name": "文件名前缀" }, "fps": { "name": "帧率" }, "images": { "name": "图片" }, "lossless": { "name": "无损" }, "method": { "name": "方法" }, "quality": { "name": "质量" } } };
const SaveAudio = { "display_name": "保存音频", "inputs": { "audio": { "name": "音频" }, "audioUI": { "name": "音频UI" }, "filename_prefix": { "name": "文件名前缀" } } };
const SaveAudioMP3 = { "display_name": "保存音频 (MP3)", "inputs": { "audio": { "name": "音频" }, "audioUI": { "name": "audioUI" }, "filename_prefix": { "name": "文件名前缀" }, "quality": { "name": "质量" } } };
const SaveAudioOpus = { "display_name": "保存音频 (Opus)", "inputs": { "audio": { "name": "音频" }, "audioUI": { "name": "audioUI" }, "filename_prefix": { "name": "文件名前缀" }, "quality": { "name": "质量" } } };
const SaveGLB = { "display_name": "保存GLB", "inputs": { "filename_prefix": { "name": "文件名前缀" }, "image": { "name": "图像" }, "mesh": { "name": "网格" } } };
const SaveImage = { "description": "将输入图像保存到您的ComfyUI输出目录。", "display_name": "保存图像", "inputs": { "filename_prefix": { "name": "文件名前缀", "tooltip": "保存文件的文件名的前缀。可使用格式信息如 %date:yyyy-MM-dd% 或 %空Latent.width%，以包含来自工作流内的信息。" }, "images": { "name": "图片", "tooltip": "要保存的图像。" } } };
const SaveImageWebsocket = { "display_name": "保存图像（网络接口）", "inputs": { "images": { "name": "图片" } } };
const SaveLatent = { "display_name": "保存Latent", "inputs": { "filename_prefix": { "name": "文件名前缀" }, "samples": { "name": "Latent" } } };
const SaveSVGNode = { "description": "在磁盘上保存 SVG 文件。", "display_name": "保存SVG", "inputs": { "filename_prefix": { "name": "文件名前缀", "tooltip": "保存文件的前缀。可包含格式化信息，如 %date:yyyy-MM-dd% 或 %Empty Latent Image.width% 以包含节点中的值。" }, "svg": { "name": "svg" } } };
const SaveVideo = { "description": "将输入图像保存到您的 ComfyUI 输出目录。", "display_name": "保存视频", "inputs": { "codec": { "name": "编码器", "tooltip": "用于视频的编码器。" }, "filename_prefix": { "name": "文件名前缀", "tooltip": "要保存文件的前缀。可以包含格式化信息，如 %date:yyyy-MM-dd% 或 %Empty Latent Image.width%，以包含来自节点的值。" }, "format": { "name": "格式", "tooltip": "保存视频的格式。" }, "video": { "name": "视频", "tooltip": "要保存的视频。" } } };
const SaveWEBM = { "display_name": "保存WEBM", "inputs": { "codec": { "name": "编解码器" }, "crf": { "name": "crf", "tooltip": "更高的crf意味着更低的质量和更小的文件大小，更低的crf意味着更高的质量和更大的文件大小。" }, "filename_prefix": { "name": "文件名前缀" }, "fps": { "name": "帧率" }, "images": { "name": "图像" } } };
const ScaleROPE = { "description": "缩放和偏移模型的ROPE。", "display_name": "缩放ROPE", "inputs": { "model": { "name": "模型" }, "scale_t": { "name": "scale_t" }, "scale_x": { "name": "scale_x" }, "scale_y": { "name": "scale_y" }, "shift_t": { "name": "shift_t" }, "shift_x": { "name": "shift_x" }, "shift_y": { "name": "shift_y" } }, "outputs": { "0": { "tooltip": null } } };
const SelfAttentionGuidance = { "display_name": "SAG自注意力引导", "inputs": { "blur_sigma": { "name": "模糊Sigma" }, "model": { "name": "模型" }, "scale": { "name": "缩放" } }, "outputs": { "0": { "tooltip": null } } };
const SetClipHooks = { "display_name": "设置CLIP约束", "inputs": { "apply_to_conds": { "name": "应用于条件" }, "clip": { "name": "clip" }, "hooks": { "name": "约束" }, "schedule_clip": { "name": "安排clip" } } };
const SetFirstSigma = { "display_name": "设置第一个Sigma", "inputs": { "sigma": { "name": "sigma" }, "sigmas": { "name": "sigmas" } } };
const SetHookKeyframes = { "display_name": "设置约束关键帧", "inputs": { "hook_kf": { "name": "约束关键帧" }, "hooks": { "name": "约束" } } };
const SetLatentNoiseMask = { "display_name": "设置Latent噪波遮罩", "inputs": { "mask": { "name": "遮罩" }, "samples": { "name": "Latent" } } };
const SetUnionControlNetType = { "display_name": "设置UnionControlNet类型", "inputs": { "control_net": { "name": "ControlNet" }, "type": { "name": "类型" } }, "outputs": { "0": { "tooltip": null } } };
const SkipLayerGuidanceDiT = { "description": "通用的跳过层引导节点，可用于每个DiT模型。", "display_name": "跳过层引导（DiT）", "inputs": { "double_layers": { "name": "双层" }, "end_percent": { "name": "结束百分比" }, "model": { "name": "模型" }, "rescaling_scale": { "name": "重新缩放比例" }, "scale": { "name": "缩放" }, "single_layers": { "name": "单层" }, "start_percent": { "name": "开始百分比" } }, "outputs": { "0": { "tooltip": null } } };
const SkipLayerGuidanceDiTSimple = { "description": "跳过层引导（DiT）节点的简化版本，仅修改无条件传递。", "display_name": "跳过层引导（DiT简化）", "inputs": { "double_layers": { "name": "双层" }, "end_percent": { "name": "结束百分比" }, "model": { "name": "模型" }, "single_layers": { "name": "单层" }, "start_percent": { "name": "开始百分比" } }, "outputs": { "0": { "tooltip": null } } };
const SkipLayerGuidanceSD3 = { "description": "通用版本的跳过层引导节点，可用于每个DiT模型。", "display_name": "跳过层引导（SD3）", "inputs": { "end_percent": { "name": "结束百分比" }, "layers": { "name": "层" }, "model": { "name": "模型" }, "scale": { "name": "缩放" }, "start_percent": { "name": "开始百分比" } }, "outputs": { "0": { "tooltip": null } } };
const SolidMask = { "display_name": "纯块遮罩", "inputs": { "height": { "name": "高度" }, "value": { "name": "明度" }, "width": { "name": "宽度" } } };
const SplitAudioChannels = { "description": "将音频分离为左右声道。", "display_name": "分离音频通道", "inputs": { "audio": { "name": "音频" } }, "outputs": { "0": { "name": "左声道" }, "1": { "name": "右声道" } } };
const SplitImageWithAlpha = { "display_name": "分离图像Alpha", "inputs": { "image": { "name": "图片" } }, "outputs": { "0": { "tooltip": null }, "1": { "tooltip": null } } };
const SplitSigmas = { "display_name": "分离Sigma", "inputs": { "sigmas": { "name": "Sigmas" }, "step": { "name": "步数" } }, "outputs": { "0": { "name": "高方差" }, "1": { "name": "低方差" } } };
const SplitSigmasDenoise = { "display_name": "分离Sigma降噪", "inputs": { "denoise": { "name": "降噪" }, "sigmas": { "name": "Sigmas" } }, "outputs": { "0": { "name": "高方差" }, "1": { "name": "低方差" } } };
const StabilityAudioInpaint = { "description": "使用文本指令转换现有音频样本的部分内容。", "display_name": "Stability AI 音频重绘", "inputs": { "audio": { "name": "音频", "tooltip": "音频长度必须在6到190秒之间。" }, "control_after_generate": { "name": "生成后控制" }, "duration": { "name": "时长", "tooltip": "控制生成音频的时长（秒）。" }, "mask_end": { "name": "结束遮罩" }, "mask_start": { "name": "开始遮罩" }, "model": { "name": "模型" }, "prompt": { "name": "提示词" }, "seed": { "name": "随机种", "tooltip": "用于生成的随机种子。" }, "steps": { "name": "步数", "tooltip": "控制采样步数。" } }, "outputs": { "0": { "tooltip": null } } };
const StabilityAudioToAudio = { "description": "使用文本指令将现有音频样本转换为新的高质量作品。", "display_name": "Stability AI 音频到音频", "inputs": { "audio": { "name": "音频", "tooltip": "音频长度必须在6到190秒之间。" }, "control_after_generate": { "name": "生成后控制" }, "duration": { "name": "时长", "tooltip": "控制生成音频的时长（秒）。" }, "model": { "name": "模型" }, "prompt": { "name": "提示词" }, "seed": { "name": "随机种", "tooltip": "用于生成的随机种子。" }, "steps": { "name": "步数", "tooltip": "控制采样步数。" }, "strength": { "name": "强度", "tooltip": "参数控制音频参数对生成音频的影响程度。" } }, "outputs": { "0": { "tooltip": null } } };
const StabilityStableImageSD_3_5Node = { "description": "根据提示词和分辨率同步生成图像。", "display_name": "Stability AI Stable Diffusion 3.5 图像", "inputs": { "aspect_ratio": { "name": "宽高比", "tooltip": "生成图像的宽高比。" }, "cfg_scale": { "name": "CFG", "tooltip": "扩散过程对提示词文本的遵循程度（数值越高，生成的图像越接近你的提示词）" }, "control_after_generate": { "name": "生成后控制" }, "image": { "name": "图像" }, "image_denoise": { "name": "图像降噪", "tooltip": "输入图像的去噪程度；0.0 表示与输入图像完全相同，1.0 表示完全不使用输入图像。" }, "model": { "name": "模型" }, "negative_prompt": { "name": "负面提示词", "tooltip": "你不希望在输出图像中出现的关键词。此为高级功能。" }, "prompt": { "name": "提示词", "tooltip": "你希望在输出图像中看到的内容。强有力且描述清晰的提示词，能够明确定义元素、颜色和主题，将带来更好的结果。" }, "seed": { "name": "随机种", "tooltip": "用于生成噪声的随机种子。" }, "style_preset": { "name": "风格预设", "tooltip": "可选，生成图像的期望风格。" } }, "outputs": { "0": { "tooltip": null } } };
const StabilityStableImageUltraNode = { "description": "根据提示词和分辨率同步生成图像。", "display_name": "Stability AI Stable 图像 Ultra", "inputs": { "aspect_ratio": { "name": "宽高比", "tooltip": "生成图像的宽高比。" }, "control_after_generate": { "name": "生成后控制" }, "image": { "name": "图像" }, "image_denoise": { "name": "降噪", "tooltip": "输入图像的去噪强度；0.0 表示与输入图像完全相同，1.0 表示完全不参考输入图像。" }, "negative_prompt": { "name": "负面提示词", "tooltip": "描述你不希望在输出图像中出现内容的文本。这是一个高级功能。" }, "prompt": { "name": "提示词", "tooltip": "你希望在输出图像中看到的内容。一个强有力且描述清晰的提示词，能够明确界定元素、颜色和主题，将带来更好的结果。要控制某个词的权重，请使用格式 `(word:weight)`，其中 `word` 是你想要控制权重的词，`weight` 是介于 0 到 1 之间的数值。例如：`The sky was a crisp (blue:0.3) and (green:0.8)` 表示天空是蓝色和绿色，但绿色多于蓝色。" }, "seed": { "name": "随机种", "tooltip": "用于生成噪声的随机种子。" }, "style_preset": { "name": "风格预设", "tooltip": "可选的生成图像风格。" } }, "outputs": { "0": { "tooltip": null } } };
const StabilityTextToAudio = { "description": "根据文本描述生成高质量音乐和音效。", "display_name": "Stability AI 文本转音频", "inputs": { "control_after_generate": { "name": "生成后控制" }, "duration": { "name": "时长", "tooltip": "控制生成音频的时长（秒）。" }, "model": { "name": "模型" }, "prompt": { "name": "提示词" }, "seed": { "name": "种子", "tooltip": "用于生成的随机种子。" }, "steps": { "name": "步数", "tooltip": "控制采样步数。" } }, "outputs": { "0": { "tooltip": null } } };
const StabilityUpscaleConservativeNode = { "description": "以最小改动将图像放大至 4K 分辨率。", "display_name": "Stability AI 保守放大", "inputs": { "control_after_generate": { "name": "生成后控制" }, "creativity": { "name": "创造性", "tooltip": "控制生成与初始图像不强相关的额外细节的可能性。" }, "image": { "name": "图像" }, "negative_prompt": { "name": "反向提示词", "tooltip": "你不希望在输出图像中出现的关键词。此为高级功能。" }, "prompt": { "name": "提示词", "tooltip": "你希望在输出图像中看到什么。强有力且描述清晰的提示词，能更好地定义元素、颜色和主题，从而获得更佳效果。" }, "seed": { "name": "种子", "tooltip": "用于生成噪声的随机种子。" } }, "outputs": { "0": { "tooltip": null } } };
const StabilityUpscaleCreativeNode = { "description": "以最小改动将图像放大至4K分辨率。", "display_name": "Stability AI 创意放大", "inputs": { "control_after_generate": { "name": "生成后控制" }, "creativity": { "name": "创造性", "tooltip": "控制生成不受初始图像强烈约束的额外细节的可能性。" }, "image": { "name": "图像" }, "negative_prompt": { "name": "反向提示词", "tooltip": "你不希望在输出图像中出现的关键词。此为高级功能。" }, "prompt": { "name": "提示词", "tooltip": "你希望在输出图像中看到什么。强有力且描述清晰的提示词，明确元素、颜色和主题，将获得更好的结果。" }, "seed": { "name": "随机种子", "tooltip": "用于生成噪声的随机种子。" }, "style_preset": { "name": "风格预设", "tooltip": "可选，生成图像的期望风格。" } }, "outputs": { "0": { "tooltip": null } } };
const StabilityUpscaleFastNode = { "description": "通过 Stability API 快速将图像放大至原始尺寸的 4 倍；适用于低质量或压缩图像的放大。", "display_name": "Stability AI 极速放大", "inputs": { "image": { "name": "图像" } }, "outputs": { "0": { "tooltip": null } } };
const StableCascade_EmptyLatentImage = { "display_name": "空Latent图像（Stable Cascade）", "inputs": { "batch_size": { "name": "批量大小" }, "compression": { "name": "压缩" }, "height": { "name": "高度" }, "width": { "name": "宽度" } }, "outputs": { "0": { "name": "阶段C", "tooltip": null }, "1": { "name": "阶段B", "tooltip": null } } };
const StableCascade_StageB_Conditioning = { "display_name": "Stable Cascade_B阶段_条件", "inputs": { "conditioning": { "name": "条件" }, "stage_c": { "name": "阶段c" } }, "outputs": { "0": { "tooltip": null } } };
const StableCascade_StageC_VAEEncode = { "display_name": "Stable Cascade_C阶段_VAE编码", "inputs": { "compression": { "name": "压缩" }, "image": { "name": "图像" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "阶段C", "tooltip": null }, "1": { "name": "阶段B", "tooltip": null } } };
const StableCascade_SuperResolutionControlnet = { "display_name": "Stable Cascade_超分辨率ControlNet", "inputs": { "image": { "name": "图像" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "ControlNet", "tooltip": null }, "1": { "name": "阶段C", "tooltip": null }, "2": { "name": "阶段B", "tooltip": null } } };
const StableZero123_Conditioning = { "display_name": "StableZero123条件", "inputs": { "azimuth": { "name": "方位角" }, "batch_size": { "name": "批量大小" }, "clip_vision": { "name": "clip视觉" }, "elevation": { "name": "俯仰角" }, "height": { "name": "高度" }, "init_image": { "name": "初始图像" }, "vae": { "name": "vae" }, "width": { "name": "宽度" } }, "outputs": { "0": { "name": "正面条件", "tooltip": null }, "1": { "name": "负面条件", "tooltip": null }, "2": { "name": "Latent", "tooltip": null } } };
const StableZero123_Conditioning_Batched = { "display_name": "StableZero123条件_批处理", "inputs": { "azimuth": { "name": "方位角" }, "azimuth_batch_increment": { "name": "方位角增量" }, "batch_size": { "name": "批量大小" }, "clip_vision": { "name": "clip视觉" }, "elevation": { "name": "俯仰角" }, "elevation_batch_increment": { "name": "俯仰角增量" }, "height": { "name": "高度" }, "init_image": { "name": "初始图像" }, "vae": { "name": "vae" }, "width": { "name": "宽度" } }, "outputs": { "0": { "name": "正面条件", "tooltip": null }, "1": { "name": "负面条件", "tooltip": null }, "2": { "name": "Latent", "tooltip": null } } };
const StringCompare = { "display_name": "比较", "inputs": { "case_sensitive": { "name": "区分大小写" }, "mode": { "name": "模式" }, "string_a": { "name": "字符串A" }, "string_b": { "name": "字符串B" } }, "outputs": { "0": { "tooltip": null } } };
const StringConcatenate = { "display_name": "连接", "inputs": { "delimiter": { "name": "分隔符" }, "string_a": { "name": "字符串A" }, "string_b": { "name": "字符串B" } }, "outputs": { "0": { "tooltip": null } } };
const StringContains = { "display_name": "包含", "inputs": { "case_sensitive": { "name": "区分大小写" }, "string": { "name": "字符串" }, "substring": { "name": "子字符串" } }, "outputs": { "0": { "name": "包含", "tooltip": null } } };
const StringLength = { "display_name": "长度", "inputs": { "string": { "name": "字符串" } }, "outputs": { "0": { "name": "长度", "tooltip": null } } };
const StringReplace = { "display_name": "替换", "inputs": { "find": { "name": "查找" }, "replace": { "name": "替换" }, "string": { "name": "字符串" } }, "outputs": { "0": { "tooltip": null } } };
const StringSubstring = { "display_name": "子字符串", "inputs": { "end": { "name": "结束" }, "start": { "name": "起始" }, "string": { "name": "字符串" } }, "outputs": { "0": { "tooltip": null } } };
const StringTrim = { "display_name": "修剪", "inputs": { "mode": { "name": "模式" }, "string": { "name": "字符串" } }, "outputs": { "0": { "tooltip": null } } };
const StyleModelApply = { "display_name": "应用风格模型", "inputs": { "clip_vision_output": { "name": "clip视觉输出" }, "conditioning": { "name": "条件" }, "strength": { "name": "强度" }, "strength_type": { "name": "强度类型" }, "style_model": { "name": "风格模型" } } };
const StyleModelLoader = { "display_name": "加载风格模型", "inputs": { "style_model_name": { "name": "风格模型名称" } } };
const T5TokenizerOptions = { "display_name": "T5Tokenizer设置", "inputs": { "clip": { "name": "clip" }, "min_length": { "name": "最小长度" }, "min_padding": { "name": "最小填充" } }, "outputs": { "0": { "tooltip": null } } };
const TCFG = { "description": "TCFG – 切向阻尼CFG (2503.18137)\n\n优化无条件（负向）以与有条件（正向）对齐，从而提高质量。", "display_name": "切向阻尼CFG", "inputs": { "model": { "name": "模型" } }, "outputs": { "0": { "name": "模型", "tooltip": null } } };
const TemporalScoreRescaling = { "description": "[后CFG函数]\nTSR - 时序分数重缩放 (2510.01184)\n\n重缩放模型的分数或噪声以引导采样多样性。", "display_name": "TSR - 时序分数重缩放", "inputs": { "model": { "name": "模型" }, "tsr_k": { "name": "TSR_K", "tooltip": "控制重缩放强度。\n较低的 k 值会产生更详细的结果；较高的 k 值在图像生成中会产生更平滑的结果。设置 k = 1 将禁用重缩放。" }, "tsr_sigma": { "name": "tsr_sigma", "tooltip": "控制重缩放何时生效。\n数值越大生效越早。" } }, "outputs": { "0": { "name": "模型", "tooltip": null } } };
const TextEncodeAceStepAudio = { "display_name": "文本音频编码（AceStep）", "inputs": { "clip": { "name": "clip" }, "lyrics": { "name": "歌词" }, "lyrics_strength": { "name": "歌词强度" }, "tags": { "name": "标签" } }, "outputs": { "0": { "tooltip": null } } };
const TextEncodeHunyuanVideo_ImageToVideo = { "display_name": "文本编码（Hunyuan视频_图像到视频）", "inputs": { "clip": { "name": "clip" }, "clip_vision_output": { "name": "clip视觉输出" }, "image_interleave": { "name": "图像交错", "tooltip": "图像与文本提示的影响程度。数字越高，文本提示的影响越大。" }, "prompt": { "name": "提示" } }, "outputs": { "0": { "tooltip": null } } };
const TextEncodeQwenImageEdit = { "display_name": "文本编码（QwenImageEdit）", "inputs": { "clip": { "name": "clip" }, "image": { "name": "图像" }, "prompt": { "name": "提示词" }, "vae": { "name": "vae" } }, "outputs": { "0": { "tooltip": null } } };
const TextEncodeQwenImageEditPlus = { "display_name": "文本编码（QwenImageEditPlus）", "inputs": { "clip": { "name": "clip" }, "image1": { "name": "图像1" }, "image2": { "name": "图像2" }, "image3": { "name": "图像3" }, "prompt": { "name": "提示词" }, "vae": { "name": "vae" } }, "outputs": { "0": { "tooltip": null } } };
const ThresholdMask = { "display_name": "遮罩阈值", "inputs": { "mask": { "name": "遮罩" }, "value": { "name": "值" } } };
const TomePatchModel = { "display_name": "Tome合并模型Token", "inputs": { "model": { "name": "模型" }, "ratio": { "name": "比率" } }, "outputs": { "0": { "tooltip": null } } };
const TopazImageEnhance = { "description": "专业级放大和图像增强。", "display_name": "Topaz 图像增强", "inputs": { "color_preservation": { "name": "固定色彩", "tooltip": "保证色彩一致性。" }, "creativity": { "name": "多样性" }, "crop_to_fill": { "name": "裁剪", "tooltip": "默认情况下，当输出宽高比不同时，图像会带有边框。启用后会裁剪图像填充输出尺寸。" }, "face_enhancement": { "name": "面部增强", "tooltip": "优化面部（如果存在）。" }, "face_enhancement_creativity": { "name": "面部增强多样性", "tooltip": "设置面部增强时的多样性。" }, "face_enhancement_strength": { "name": "面部增强强度", "tooltip": "控制面部相对于背景的锐度。" }, "face_preservation": { "name": "固定面部", "tooltip": "保证主体面部一致性。" }, "image": { "name": "图像" }, "model": { "name": "模型" }, "output_height": { "name": "输出高度", "tooltip": "0为自动（一般情况下和输入图像相同）。" }, "output_width": { "name": "输出宽度", "tooltip": "0为自动（一般情况下和输入图像相同）。" }, "prompt": { "name": "提示词", "tooltip": "用于引导放大" }, "subject_detection": { "name": "物体检测" } }, "outputs": { "0": { "tooltip": null } } };
const TopazVideoEnhance = { "description": "通过强大的放大和修复技术，为视频注入新的生命。", "display_name": "Topaz 视频增强", "inputs": { "dynamic_compression_level": { "name": "动态压缩", "tooltip": "CQP 等级." }, "interpolation_duplicate": { "name": "补帧重复帧", "tooltip": "分析原视频，移除重复的帧。" }, "interpolation_duplicate_threshold": { "name": "补帧重复帧阈值", "tooltip": "判断为重复帧的阈值。" }, "interpolation_enabled": { "name": "补帧" }, "interpolation_frame_rate": { "name": "补帧帧率", "tooltip": "输出帧率" }, "interpolation_model": { "name": "补帧模型" }, "interpolation_slowmo": { "name": "补帧慢动作", "tooltip": "使用慢动作补帧。例如，设为 2 会让视频变慢到 0.5 倍，持续时间增加到 2 倍。" }, "upscaler_creativity": { "name": "放大多样性", "tooltip": "多样等级（仅适用 Starlight (Astra) Creative 模型）." }, "upscaler_enabled": { "name": "放大" }, "upscaler_model": { "name": "放大模型" }, "upscaler_resolution": { "name": "放大分辨率" }, "video": { "name": "视频" } }, "outputs": { "0": { "tooltip": null } } };
const TorchCompileModel = { "display_name": "Torch编译模型", "inputs": { "backend": { "name": "后端" }, "model": { "name": "模型" } }, "outputs": { "0": { "tooltip": null } } };
const TrainLoraNode = { "display_name": "训练 LoRA", "inputs": { "algorithm": { "name": "算法", "tooltip": "用于训练的算法。" }, "batch_size": { "name": "批次大小", "tooltip": "用于训练的批次大小。" }, "control_after_generate": { "name": "生成后控制" }, "existing_lora": { "name": "现有LoRA", "tooltip": "要附加到的现有LoRA。设置为None以创建新LoRA。" }, "grad_accumulation_steps": { "name": "梯度累积步数", "tooltip": "用于训练的梯度累积步数。" }, "gradient_checkpointing": { "name": "梯度检查点", "tooltip": "训练时使用梯度检查点。" }, "latents": { "name": "潜变量", "tooltip": "用于训练的潜变量，作为模型的数据集/输入。" }, "learning_rate": { "name": "学习率", "tooltip": "用于训练的学习率。" }, "lora_dtype": { "name": "LoRA 数据类型", "tooltip": "用于 LoRA 的数据类型。" }, "loss_function": { "name": "损失函数", "tooltip": "用于训练的损失函数。" }, "model": { "name": "模型", "tooltip": "用于训练 LoRA 的模型。" }, "optimizer": { "name": "优化器", "tooltip": "用于训练的优化器。" }, "positive": { "name": "正向条件", "tooltip": "用于训练的正向条件。" }, "rank": { "name": "秩", "tooltip": "LoRA 层的秩。" }, "seed": { "name": "种子", "tooltip": "用于训练的种子（用于 LoRA 权重初始化和噪声采样的生成器）" }, "steps": { "name": "步数", "tooltip": "训练 LoRA 的步数。" }, "training_dtype": { "name": "训练数据类型", "tooltip": "用于训练的数据类型。" } }, "outputs": { "0": { "name": "带LoRA的模型" }, "1": { "name": "LoRA" }, "2": { "name": "损失" }, "3": { "name": "步数" } } };
const TrimAudioDuration = { "description": "将音频张量修剪到选定的时间范围。", "display_name": "修剪音频时长", "inputs": { "audio": { "name": "音频" }, "duration": { "name": "时长", "tooltip": "持续时间（秒）" }, "start_index": { "name": "起始索引", "tooltip": "开始时间（秒），可为负数表示从末尾开始计数（支持小数秒）。" } } };
const TrimVideoLatent = { "display_name": "修剪视频Latent", "inputs": { "samples": { "name": "Latent" }, "trim_amount": { "name": "修剪数量" } }, "outputs": { "0": { "tooltip": null } } };
const TripleCLIPLoader = { "description": "[配方]\n\nSD3：clip-l，clip-g，t5", "display_name": "三重CLIP加载器", "inputs": { "clip_name1": { "name": "CLIP名称1" }, "clip_name2": { "name": "CLIP名称2" }, "clip_name3": { "name": "CLIP名称3" } }, "outputs": { "0": { "tooltip": null } } };
const TripoConversionNode = { "display_name": "Tripo：转换模型", "inputs": { "face_limit": { "name": "面数限制" }, "format": { "name": "格式" }, "original_model_task_id": { "name": "原始模型任务ID" }, "quad": { "name": "四边形" }, "texture_format": { "name": "纹理格式" }, "texture_size": { "name": "纹理大小" } } };
const TripoImageToModelNode = { "display_name": "Tripo：图像转模型", "inputs": { "face_limit": { "name": "面数限制" }, "image": { "name": "图像" }, "model_seed": { "name": "模型种子" }, "model_version": { "name": "模型版本", "tooltip": "用于生成的模型版本" }, "orientation": { "name": "朝向" }, "pbr": { "name": "PBR" }, "quad": { "name": "四边形" }, "style": { "name": "风格" }, "texture": { "name": "纹理" }, "texture_alignment": { "name": "纹理对齐" }, "texture_quality": { "name": "纹理质量" }, "texture_seed": { "name": "纹理种子" } }, "outputs": { "0": { "name": "模型文件", "tooltip": null }, "1": { "name": "模型任务ID", "tooltip": null } } };
const TripoMultiviewToModelNode = { "display_name": "Tripo：多视图转模型", "inputs": { "face_limit": { "name": "面数限制" }, "image": { "name": "图像" }, "image_back": { "name": "背面图像" }, "image_left": { "name": "左侧图像" }, "image_right": { "name": "右侧图像" }, "model_seed": { "name": "模型种子" }, "model_version": { "name": "模型版本", "tooltip": "用于生成的模型版本" }, "orientation": { "name": "朝向" }, "pbr": { "name": "PBR" }, "quad": { "name": "四边形" }, "texture": { "name": "纹理" }, "texture_alignment": { "name": "纹理对齐" }, "texture_quality": { "name": "纹理质量" }, "texture_seed": { "name": "纹理种子" } }, "outputs": { "0": { "name": "模型文件", "tooltip": null }, "1": { "name": "模型任务ID", "tooltip": null } } };
const TripoRefineNode = { "description": "仅精修由v1.4 Tripo模型创建的草稿模型。", "display_name": "Tripo: 精修草稿模型", "inputs": { "model_task_id": { "name": "模型任务ID", "tooltip": "必须是v1.4 Tripo模型" } }, "outputs": { "0": { "name": "模型文件", "tooltip": null }, "1": { "name": "模型任务ID", "tooltip": null } } };
const TripoRetargetNode = { "display_name": "Tripo: 重定向绑定模型", "inputs": { "animation": { "name": "动画" }, "original_model_task_id": { "name": "原始模型任务ID" } }, "outputs": { "0": { "name": "模型文件", "tooltip": null }, "1": { "name": "重定向任务ID", "tooltip": null } } };
const TripoRigNode = { "display_name": "Tripo: 绑定模型", "inputs": { "original_model_task_id": { "name": "原始模型任务ID" } }, "outputs": { "0": { "name": "模型文件", "tooltip": null }, "1": { "name": "绑定任务ID", "tooltip": null } } };
const TripoTextToModelNode = { "display_name": "Tripo: 文本转模型", "inputs": { "face_limit": { "name": "面数限制" }, "image_seed": { "name": "图像种子" }, "model_seed": { "name": "模型种子" }, "model_version": { "name": "模型版本" }, "negative_prompt": { "name": "负面提示词" }, "pbr": { "name": "PBR" }, "prompt": { "name": "提示词" }, "quad": { "name": "四边形" }, "style": { "name": "风格" }, "texture": { "name": "纹理" }, "texture_quality": { "name": "纹理质量" }, "texture_seed": { "name": "纹理种子" } }, "outputs": { "0": { "name": "模型文件", "tooltip": null }, "1": { "name": "模型任务ID", "tooltip": null } } };
const TripoTextureNode = { "display_name": "Tripo: 纹理化模型", "inputs": { "model_task_id": { "name": "模型任务ID" }, "pbr": { "name": "PBR" }, "texture": { "name": "纹理" }, "texture_alignment": { "name": "纹理对齐" }, "texture_quality": { "name": "纹理质量" }, "texture_seed": { "name": "纹理种子" } }, "outputs": { "0": { "name": "模型文件", "tooltip": null }, "1": { "name": "模型任务ID", "tooltip": null } } };
const UNETLoader = { "display_name": "UNet加载器", "inputs": { "unet_name": { "name": "UNet名称" }, "weight_dtype": { "name": "数据类型" } } };
const UNetCrossAttentionMultiply = { "display_name": "UNet交叉注意力乘数", "inputs": { "k": { "name": "k" }, "model": { "name": "模型" }, "out": { "name": "输出" }, "q": { "name": "q" }, "v": { "name": "v" } }, "outputs": { "0": { "tooltip": null } } };
const UNetSelfAttentionMultiply = { "display_name": "UNet自注意力乘数", "inputs": { "k": { "name": "k" }, "model": { "name": "模型" }, "out": { "name": "输出" }, "q": { "name": "q" }, "v": { "name": "v" } }, "outputs": { "0": { "tooltip": null } } };
const UNetTemporalAttentionMultiply = { "display_name": "UNet时间注意力乘数", "inputs": { "cross_structural": { "name": "交叉结构" }, "cross_temporal": { "name": "交叉时间" }, "model": { "name": "模型" }, "self_structural": { "name": "自我结构" }, "self_temporal": { "name": "自我时间" } }, "outputs": { "0": { "tooltip": null } } };
const USOStyleReference = { "display_name": "USO风格参考", "inputs": { "clip_vision_output": { "name": "CLIP视觉输出" }, "model": { "name": "模型" }, "model_patch": { "name": "模型补丁" } } };
const UpscaleModelLoader = { "display_name": "加载放大模型", "inputs": { "model_name": { "name": "模型名称" } }, "outputs": { "0": { "tooltip": null } } };
const VAEDecode = { "description": "将 Latent 图像解码为像素空间的图像。", "display_name": "VAE解码", "inputs": { "samples": { "name": "Latent", "tooltip": "要解码的 Latent 图像。" }, "vae": { "name": "vae", "tooltip": "用于解码 Latent 图像的 VAE 模型。" } }, "outputs": { "0": { "tooltip": "解码后的图像。" } } };
const VAEDecodeAudio = { "display_name": "VAE解码（音频）", "inputs": { "samples": { "name": "Latent" }, "vae": { "name": "vae" } } };
const VAEDecodeHunyuan3D = { "display_name": "VAE解码（Hunyuan3D）", "inputs": { "num_chunks": { "name": "块数" }, "octree_resolution": { "name": "八叉树分辨率" }, "samples": { "name": "样本" }, "vae": { "name": "vae" } } };
const VAEDecodeTiled = { "display_name": "VAE解码（分块）", "inputs": { "overlap": { "name": "重叠" }, "samples": { "name": "Latent" }, "temporal_overlap": { "name": "时间重叠", "tooltip": "仅用于视频VAE：重叠的帧数。" }, "temporal_size": { "name": "时间尺寸", "tooltip": "仅用于视频VAE：一次解码的帧数。" }, "tile_size": { "name": "分块尺寸" }, "vae": { "name": "vae" } } };
const VAEEncode = { "display_name": "VAE编码", "inputs": { "pixels": { "name": "像素" }, "vae": { "name": "vae" } } };
const VAEEncodeAudio = { "display_name": "VAE编码（音频）", "inputs": { "audio": { "name": "音频" }, "vae": { "name": "vae" } } };
const VAEEncodeForInpaint = { "display_name": "VAE编码（局部重绘）", "inputs": { "grow_mask_by": { "name": "扩展遮罩" }, "mask": { "name": "遮罩" }, "pixels": { "name": "像素" }, "vae": { "name": "vae" } } };
const VAEEncodeTiled = { "display_name": "VAE编码分块）", "inputs": { "overlap": { "name": "重叠" }, "pixels": { "name": "像素" }, "temporal_overlap": { "name": "时间重叠", "tooltip": "仅用于视频VAE：重叠的帧数。" }, "temporal_size": { "name": "时间尺寸", "tooltip": "仅用于视频VAE：一次编码的帧数。" }, "tile_size": { "name": "分块尺寸" }, "vae": { "name": "vae" } } };
const VAELoader = { "display_name": "加载VAE", "inputs": { "vae_name": { "name": "vae名称" } } };
const VAESave = { "display_name": "保存VAE", "inputs": { "filename_prefix": { "name": "文件名前缀" }, "vae": { "name": "vae" } } };
const VPScheduler = { "display_name": "VPS调度器", "inputs": { "beta_d": { "name": "beta_d" }, "beta_min": { "name": "beta_min" }, "eps_s": { "name": "eps_s" }, "steps": { "name": "步数" } } };
const Veo3VideoGenerationNode = { "description": "使用 Google Veo 3 API 从文本提示生成视频", "display_name": "Google Veo 3 视频生成", "inputs": { "aspect_ratio": { "name": "宽高比", "tooltip": "输出视频的宽高比" }, "control_after_generate": { "name": "生成后控制" }, "duration_seconds": { "name": "时长", "tooltip": "输出视频的时长（秒）（Veo 3 仅支持 8 秒）" }, "enhance_prompt": { "name": "优化提示词", "tooltip": "是否使用 AI 辅助增强提示" }, "generate_audio": { "name": "生成音频", "tooltip": "为视频生成音频。所有 Veo 3 模型均支持此功能。" }, "image": { "name": "图像", "tooltip": "用于指导视频生成的可选参考图像" }, "model": { "name": "模型", "tooltip": "用于视频生成的 Veo 3 模型" }, "negative_prompt": { "name": "负面提示词", "tooltip": "负面文本提示，指导视频中应避免的内容" }, "person_generation": { "name": "生成人类", "tooltip": "是否允许在视频中生成人物" }, "prompt": { "name": "提示词", "tooltip": "视频的文本描述" }, "seed": { "name": "随机种", "tooltip": "视频生成的种子值（0 表示随机）" } }, "outputs": { "0": { "tooltip": null } } };
const VeoVideoGenerationNode = { "description": "使用 Google 的 Veo API 根据文本提示生成视频", "display_name": "Google Veo2 视频生成", "inputs": { "aspect_ratio": { "name": "宽高比", "tooltip": "输出视频的宽高比" }, "control_after_generate": { "name": "生成后控制" }, "duration_seconds": { "name": "时长", "tooltip": "输出视频的时长（秒）" }, "enhance_prompt": { "name": "优化提示词", "tooltip": "是否使用 AI 辅助增强提示词" }, "image": { "name": "图像", "tooltip": "可选的参考图像，用于引导视频生成" }, "model": { "name": "模型", "tooltip": "用于视频生成的 Veo 2 模型" }, "negative_prompt": { "name": "负面提示词", "tooltip": "用于指导视频中应避免内容的负面文本提示" }, "person_generation": { "name": "生成人类", "tooltip": "是否允许在视频中生成人物" }, "prompt": { "name": "提示词", "tooltip": "视频的文本描述" }, "seed": { "name": "随机种", "tooltip": "视频生成的种子（0 表示随机）" } }, "outputs": { "0": { "tooltip": null } } };
const VideoLinearCFGGuidance = { "display_name": "视频线性CFG引导", "inputs": { "min_cfg": { "name": "最小配置" }, "model": { "name": "模型" } } };
const VideoTriangleCFGGuidance = { "display_name": "视频三角形CFG引导", "inputs": { "min_cfg": { "name": "最小配置" }, "model": { "name": "模型" } } };
const ViduImageToVideoNode = { "description": "从图像和可选提示生成视频", "display_name": "Vidu 图像转视频生成", "inputs": { "control_after_generate": { "name": "生成后控制" }, "duration": { "name": "时长", "tooltip": "输出视频的时长（秒）" }, "image": { "name": "图像", "tooltip": "用作生成视频起始帧的图像" }, "model": { "name": "模型", "tooltip": "模型名称" }, "movement_amplitude": { "name": "运动幅度", "tooltip": "画面中对象的运动幅度" }, "prompt": { "name": "提示词", "tooltip": "用于视频生成的文本描述" }, "resolution": { "name": "分辨率", "tooltip": "支持的值可能因模型和时长而异" }, "seed": { "name": "随机种", "tooltip": "视频生成的种子值（0 表示随机）" } }, "outputs": { "0": { "tooltip": null } } };
const ViduReferenceVideoNode = { "description": "从多张图像和提示生成视频", "display_name": "Vidu 参考转视频生成", "inputs": { "aspect_ratio": { "name": "宽高比", "tooltip": "输出视频的宽高比" }, "control_after_generate": { "name": "生成后控制" }, "duration": { "name": "时长", "tooltip": "输出视频的时长（秒）" }, "images": { "name": "图像", "tooltip": "用作参考以生成具有一致主体的图像（最多 7 张图像）" }, "model": { "name": "模型", "tooltip": "模型名称" }, "movement_amplitude": { "name": "运动幅度", "tooltip": "画面中物体的运动幅度" }, "prompt": { "name": "提示词", "tooltip": "用于视频生成的文本描述" }, "resolution": { "name": "分辨率", "tooltip": "支持的值可能因模型和时长而异" }, "seed": { "name": "种子", "tooltip": "视频生成的种子值（0表示随机）" } }, "outputs": { "0": { "tooltip": null } } };
const ViduStartEndToVideoNode = { "description": "根据起始帧、结束帧和提示词生成视频", "display_name": "Vidu 起始结束帧转视频生成", "inputs": { "control_after_generate": { "name": "生成后控制" }, "duration": { "name": "时长", "tooltip": "输出视频的时长（秒）" }, "end_frame": { "name": "结束帧", "tooltip": "结束帧" }, "first_frame": { "name": "起始帧", "tooltip": "开始帧" }, "model": { "name": "模型", "tooltip": "模型名称" }, "movement_amplitude": { "name": "运动幅度", "tooltip": "画面中物体的运动幅度" }, "prompt": { "name": "提示词", "tooltip": "用于视频生成的文本描述" }, "resolution": { "name": "分辨率", "tooltip": "支持的值可能因模型和时长而异" }, "seed": { "name": "种子", "tooltip": "视频生成的种子值（0表示随机）" } }, "outputs": { "0": { "tooltip": null } } };
const ViduTextToVideoNode = { "description": "根据文本提示词生成视频", "display_name": "Vidu 文本转视频生成", "inputs": { "aspect_ratio": { "name": "宽高比", "tooltip": "输出视频的宽高比" }, "control_after_generate": { "name": "生成后控制" }, "duration": { "name": "时长", "tooltip": "输出视频的时长（秒）" }, "model": { "name": "模型", "tooltip": "模型名称" }, "movement_amplitude": { "name": "运动幅度", "tooltip": "画面中物体的运动幅度" }, "prompt": { "name": "提示词", "tooltip": "用于视频生成的文本描述" }, "resolution": { "name": "分辨率", "tooltip": "支持的值可能因模型和时长而异" }, "seed": { "name": "种子", "tooltip": "视频生成的种子值（0表示随机）" } }, "outputs": { "0": { "tooltip": null } } };
const VoxelToMesh = { "display_name": "体素到网格", "inputs": { "algorithm": { "name": "算法" }, "threshold": { "name": "阈值" }, "voxel": { "name": "体素" } } };
const VoxelToMeshBasic = { "display_name": "体素到网格（基础）", "inputs": { "threshold": { "name": "阈值" }, "voxel": { "name": "体素" } } };
const Wan22FunControlToVideo = { "display_name": "Wan22FunControl视频", "inputs": { "batch_size": { "name": "批次大小" }, "control_video": { "name": "控制视频" }, "height": { "name": "高度" }, "length": { "name": "长度" }, "negative": { "name": "负面提示词" }, "positive": { "name": "正面提示词" }, "ref_image": { "name": "参考图像" }, "vae": { "name": "VAE" }, "width": { "name": "宽度" } }, "outputs": { "0": { "name": "正向提示", "tooltip": null }, "1": { "name": "负向提示", "tooltip": null }, "2": { "name": "潜变量", "tooltip": null } } };
const Wan22ImageToVideoLatent = { "display_name": "Wan22图像转视频潜变量", "inputs": { "batch_size": { "name": "批次大小" }, "height": { "name": "高度" }, "length": { "name": "长度" }, "start_image": { "name": "起始图像" }, "vae": { "name": "VAE" }, "width": { "name": "宽度" } }, "outputs": { "0": { "tooltip": null } } };
const WanAnimateToVideo = { "display_name": "Wan动画转视频", "inputs": { "background_video": { "name": "背景视频" }, "batch_size": { "name": "批次大小" }, "character_mask": { "name": "角色遮罩" }, "clip_vision_output": { "name": "CLIP视觉输出" }, "continue_motion": { "name": "继续运动" }, "continue_motion_max_frames": { "name": "继续运动最大帧数" }, "face_video": { "name": "面部视频" }, "height": { "name": "高度" }, "length": { "name": "长度" }, "negative": { "name": "负向提示" }, "pose_video": { "name": "姿态视频" }, "positive": { "name": "正向提示" }, "reference_image": { "name": "参考图像" }, "vae": { "name": "VAE" }, "video_frame_offset": { "name": "视频帧偏移", "tooltip": "在所有输入视频中跳过的帧数。用于通过分块生成更长的视频。连接到上一个节点的video_frame_offset输出以扩展视频。" }, "width": { "name": "宽度" } }, "outputs": { "0": { "name": "正向提示", "tooltip": null }, "1": { "name": "负向提示", "tooltip": null }, "2": { "name": "潜变量", "tooltip": null }, "3": { "name": "修剪潜变量", "tooltip": null }, "4": { "name": "修剪图像", "tooltip": null }, "5": { "name": "视频帧偏移", "tooltip": null } } };
const WanCameraEmbedding = { "display_name": "Wan相机嵌入", "inputs": { "camera_pose": { "name": "相机姿态" }, "cx": { "name": "cx" }, "cy": { "name": "cy" }, "fx": { "name": "fx" }, "fy": { "name": "fy" }, "height": { "name": "高度" }, "length": { "name": "长度" }, "speed": { "name": "速度" }, "width": { "name": "宽度" } }, "outputs": { "0": { "name": "相机嵌入", "tooltip": null }, "1": { "name": "宽度", "tooltip": null }, "2": { "name": "高度", "tooltip": null }, "3": { "name": "长度", "tooltip": null } } };
const WanCameraImageToVideo = { "display_name": "万相机图像转视频", "inputs": { "batch_size": { "name": "批次大小" }, "camera_conditions": { "name": "相机条件" }, "clip_vision_output": { "name": "CLIP视觉输出" }, "height": { "name": "高度" }, "length": { "name": "长度" }, "negative": { "name": "负面提示词" }, "positive": { "name": "正面提示词" }, "start_image": { "name": "起始图像" }, "vae": { "name": "VAE" }, "width": { "name": "宽度" } }, "outputs": { "0": { "name": "正面提示词", "tooltip": null }, "1": { "name": "负面提示词", "tooltip": null }, "2": { "name": "潜空间", "tooltip": null } } };
const WanContextWindowsManual = { "description": "手动设置类WAN模型的上下文窗口（维度=2）。", "display_name": "WAN上下文窗口（手动）", "inputs": { "closed_loop": { "name": "闭环", "tooltip": "是否关闭上下文窗口循环；仅适用于循环调度。" }, "context_length": { "name": "上下文长度", "tooltip": "上下文窗口的长度。" }, "context_overlap": { "name": "上下文重叠", "tooltip": "上下文窗口的重叠量。" }, "context_schedule": { "name": "上下文调度", "tooltip": "上下文窗口的步长；仅适用于均匀调度。" }, "context_stride": { "name": "上下文步长", "tooltip": "上下文窗口的步长；仅适用于均匀调度。" }, "fuse_method": { "name": "融合方法", "tooltip": "用于融合上下文窗口的方法。" }, "model": { "name": "模型", "tooltip": "在采样过程中应用上下文窗口的模型。" } }, "outputs": { "0": { "tooltip": "在采样过程中应用了上下文窗口的模型。" } } };
const WanFirstLastFrameToVideo = { "display_name": "Wan首尾帧视频", "inputs": { "batch_size": { "name": "批量大小" }, "clip_vision_end_image": { "name": "clip 视觉结束图像" }, "clip_vision_start_image": { "name": "clip 视觉起始图像" }, "end_image": { "name": "结束图像" }, "height": { "name": "高度" }, "length": { "name": "长度" }, "negative": { "name": "负向" }, "positive": { "name": "正向" }, "start_image": { "name": "起始图像" }, "vae": { "name": "vae" }, "width": { "name": "宽度" } }, "outputs": { "0": { "name": "正向", "tooltip": null }, "1": { "name": "负向", "tooltip": null }, "2": { "name": "latent", "tooltip": null } } };
const WanFunControlToVideo = { "display_name": "WanFunControl视频", "inputs": { "batch_size": { "name": "批量大小" }, "clip_vision_output": { "name": "CLIP视觉输出" }, "control_video": { "name": "控制视频" }, "height": { "name": "高度" }, "length": { "name": "长度" }, "negative": { "name": "负向" }, "positive": { "name": "正向" }, "start_image": { "name": "起始图像" }, "vae": { "name": "vae" }, "width": { "name": "宽度" } }, "outputs": { "0": { "name": "正向", "tooltip": null }, "1": { "name": "负向", "tooltip": null }, "2": { "name": "latent", "tooltip": null } } };
const WanFunInpaintToVideo = { "display_name": "WanFunInpaint视频", "inputs": { "batch_size": { "name": "批量大小" }, "clip_vision_output": { "name": "CLIP视觉输出" }, "end_image": { "name": "结束图像" }, "height": { "name": "高度" }, "length": { "name": "长度" }, "negative": { "name": "负向" }, "positive": { "name": "正向" }, "start_image": { "name": "起始图像" }, "vae": { "name": "vae" }, "width": { "name": "宽度" } }, "outputs": { "0": { "name": "正向", "tooltip": null }, "1": { "name": "负向", "tooltip": null }, "2": { "name": "latent", "tooltip": null } } };
const WanHuMoImageToVideo = { "display_name": "万虎魔图像转视频", "inputs": { "audio_encoder_output": { "name": "音频编码器输出" }, "batch_size": { "name": "批次大小" }, "height": { "name": "高度" }, "length": { "name": "长度" }, "negative": { "name": "负面提示词" }, "positive": { "name": "正面提示词" }, "ref_image": { "name": "参考图像" }, "vae": { "name": "VAE" }, "width": { "name": "宽度" } }, "outputs": { "0": { "name": "正面提示词", "tooltip": null }, "1": { "name": "负面提示词", "tooltip": null }, "2": { "name": "潜空间", "tooltip": null } } };
const WanImageToImageApi = { "description": "根据一张或两张输入图像和文本提示生成图像。输出图像目前固定为160万像素；其宽高比与输入图像匹配。", "display_name": "万图像转图像", "inputs": { "control_after_generate": { "name": "生成后控制" }, "image": { "name": "图像", "tooltip": "单图编辑或多图融合，最多2张图像。" }, "model": { "name": "模型", "tooltip": "要使用的模型。" }, "negative_prompt": { "name": "负面提示词", "tooltip": "用于指导避免内容的负面文本提示。" }, "prompt": { "name": "提示词", "tooltip": "用于描述元素和视觉特征的提示词，支持英文/中文。" }, "seed": { "name": "种子", "tooltip": "生成使用的种子值。" }, "watermark": { "name": "水印", "tooltip": '是否在结果中添加"AI生成"水印。' } }, "outputs": { "0": { "tooltip": null } } };
const WanImageToVideo = { "display_name": "Wan图像到视频", "inputs": { "batch_size": { "name": "批量大小" }, "clip_vision_output": { "name": "clip视觉输出" }, "height": { "name": "高度" }, "length": { "name": "长度" }, "negative": { "name": "负面" }, "positive": { "name": "正面" }, "start_image": { "name": "开始图像" }, "vae": { "name": "vae" }, "width": { "name": "宽度" } }, "outputs": { "0": { "name": "正面", "tooltip": null }, "1": { "name": "负面", "tooltip": null }, "2": { "name": "潜在", "tooltip": null } } };
const WanImageToVideoApi = { "description": "基于首帧图像和文本提示生成视频。", "display_name": "万图生视频", "inputs": { "audio": { "name": "音频", "tooltip": "音频必须包含清晰、响亮的人声，无杂音和背景音乐。" }, "control_after_generate": { "name": "生成后控制" }, "duration": { "name": "时长", "tooltip": "可用时长：5秒和10秒" }, "generate_audio": { "name": "生成音频", "tooltip": "若无音频输入，则自动生成音频。" }, "image": { "name": "图像" }, "model": { "name": "模型", "tooltip": "要使用的模型。" }, "negative_prompt": { "name": "负面提示词", "tooltip": "用于指导避免内容的负面文本提示。" }, "prompt": { "name": "提示词", "tooltip": "用于描述元素和视觉特征的提示词，支持英文/中文。" }, "prompt_extend": { "name": "提示词扩展", "tooltip": "是否通过AI辅助增强提示词。" }, "resolution": { "name": "分辨率" }, "seed": { "name": "种子", "tooltip": "生成使用的种子值。" }, "watermark": { "name": "水印", "tooltip": '是否在结果中添加"AI生成"水印。' } }, "outputs": { "0": { "tooltip": null } } };
const WanPhantomSubjectToVideo = { "display_name": "万幻主体转视频", "inputs": { "batch_size": { "name": "批次大小" }, "height": { "name": "高度" }, "images": { "name": "图像" }, "length": { "name": "长度" }, "negative": { "name": "负面提示词" }, "positive": { "name": "正面提示词" }, "vae": { "name": "VAE" }, "width": { "name": "宽度" } }, "outputs": { "0": { "name": "正面提示词", "tooltip": null }, "1": { "name": "负面文本", "tooltip": null }, "2": { "name": "负面图像文本", "tooltip": null }, "3": { "name": "潜变量", "tooltip": null } } };
const WanSoundImageToVideo = { "display_name": "WanSound图像到视频", "inputs": { "audio_encoder_output": { "name": "音频编码器输出" }, "batch_size": { "name": "批次大小" }, "control_video": { "name": "控制视频" }, "height": { "name": "高度" }, "length": { "name": "长度" }, "negative": { "name": "负面提示词" }, "positive": { "name": "正面提示词" }, "ref_image": { "name": "参考图像" }, "ref_motion": { "name": "参考动作" }, "vae": { "name": "VAE" }, "width": { "name": "宽度" } }, "outputs": { "0": { "name": "正面提示词", "tooltip": null }, "1": { "name": "负面提示词", "tooltip": null }, "2": { "name": "潜变量", "tooltip": null } } };
const WanSoundImageToVideoExtend = { "display_name": "WanSound图像到视频扩展", "inputs": { "audio_encoder_output": { "name": "音频编码器输出" }, "control_video": { "name": "控制视频" }, "length": { "name": "长度" }, "negative": { "name": "负面提示词" }, "positive": { "name": "正面提示词" }, "ref_image": { "name": "参考图像" }, "vae": { "name": "VAE" }, "video_latent": { "name": "视频潜变量" } }, "outputs": { "0": { "name": "正面提示词", "tooltip": null }, "1": { "name": "负面提示词", "tooltip": null }, "2": { "name": "潜变量", "tooltip": null } } };
const WanTextToImageApi = { "description": "基于文本提示生成图像。", "display_name": "Wan文生图", "inputs": { "control_after_generate": { "name": "生成后控制" }, "height": { "name": "高度" }, "model": { "name": "模型", "tooltip": "要使用的模型。" }, "negative_prompt": { "name": "负面提示词", "tooltip": "用于指导避免内容的负面文本提示。" }, "prompt": { "name": "提示词", "tooltip": "用于描述元素和视觉特征的提示词，支持英文/中文。" }, "prompt_extend": { "name": "提示词增强", "tooltip": "是否使用AI辅助增强提示词。" }, "seed": { "name": "种子", "tooltip": "用于生成的种子值。" }, "watermark": { "name": "水印", "tooltip": '是否在结果中添加"AI生成"水印。' }, "width": { "name": "宽度" } }, "outputs": { "0": { "tooltip": null } } };
const WanTextToVideoApi = { "description": "基于文本提示生成视频。", "display_name": "Wan文生视频", "inputs": { "audio": { "name": "音频", "tooltip": "音频必须包含清晰、响亮的人声，无杂音和背景音乐。" }, "control_after_generate": { "name": "生成后控制" }, "duration": { "name": "时长", "tooltip": "可用时长：5秒和10秒" }, "generate_audio": { "name": "生成音频", "tooltip": "若无音频输入，则自动生成音频。" }, "model": { "name": "模型", "tooltip": "要使用的模型。" }, "negative_prompt": { "name": "负面提示词", "tooltip": "用于引导避免内容的负面文本提示。" }, "prompt": { "name": "提示词", "tooltip": "用于描述元素和视觉特征的提示词，支持英文/中文。" }, "prompt_extend": { "name": "优化提示词", "tooltip": "是否通过AI辅助增强提示词。" }, "seed": { "name": "随机种", "tooltip": "用于生成的种子值。" }, "size": { "name": "尺寸" }, "watermark": { "name": "水印", "tooltip": "是否在结果中添加“AI生成”水印。" } }, "outputs": { "0": { "tooltip": null } } };
const WanTrackToVideo = { "display_name": "WanTrack视频", "inputs": { "batch_size": { "name": "批次大小" }, "clip_vision_output": { "name": "CLIP视觉输出" }, "height": { "name": "高度" }, "length": { "name": "长度" }, "negative": { "name": "负面条件" }, "positive": { "name": "正面条件" }, "start_image": { "name": "图像" }, "temperature": { "name": "温度" }, "topk": { "name": "topk" }, "tracks": { "name": "tracks" }, "vae": { "name": "vae" }, "width": { "name": "宽度" } }, "outputs": { "0": { "name": "正面提示词", "tooltip": null }, "1": { "name": "负面提示词", "tooltip": null }, "2": { "name": "latent", "tooltip": null } } };
const WanVaceToVideo = { "display_name": "WanVace视频", "inputs": { "batch_size": { "name": "批量大小" }, "control_masks": { "name": "控制遮罩" }, "control_video": { "name": "控制视频" }, "height": { "name": "高度" }, "length": { "name": "长度" }, "negative": { "name": "负面条件" }, "positive": { "name": "正面条件" }, "reference_image": { "name": "参考图像" }, "strength": { "name": "强度" }, "vae": { "name": "vae" }, "width": { "name": "宽度" } }, "outputs": { "0": { "name": "正向", "tooltip": null }, "1": { "name": "负向", "tooltip": null }, "2": { "name": "latent", "tooltip": null }, "3": { "name": "裁剪latent", "tooltip": null } } };
const WebcamCapture = { "display_name": "网络摄像头捕获", "inputs": { "capture_on_queue": { "name": "执行时捕获" }, "height": { "name": "高度" }, "image": { "name": "图像" }, "waiting for camera___": {}, "width": { "name": "宽度" } } };
const unCLIPCheckpointLoader = { "display_name": "unCLIPCheckpoint加载器", "inputs": { "ckpt_name": { "name": "Checkpoint名称" } } };
const unCLIPConditioning = { "display_name": "unCLIP条件", "inputs": { "clip_vision_output": { "name": "CLIP视觉输出" }, "conditioning": { "name": "条件" }, "noise_augmentation": { "name": "噪波增强" }, "strength": { "name": "强度" } } };
const wanBlockSwap = { "description": "NOP", "display_name": "Wan块置换", "inputs": { "model": { "name": "模型" } }, "outputs": { "0": { "tooltip": null } } };
const nodeDefs = {
  APG,
  AddNoise,
  AlignYourStepsScheduler,
  AudioAdjustVolume,
  AudioConcat,
  AudioEncoderEncode,
  AudioEncoderLoader,
  AudioMerge,
  BasicGuider,
  BasicScheduler,
  BetaSamplingScheduler,
  ByteDanceFirstLastFrameNode,
  ByteDanceImageEditNode,
  ByteDanceImageNode,
  ByteDanceImageReferenceNode,
  ByteDanceImageToVideoNode,
  ByteDanceSeedreamNode,
  ByteDanceTextToVideoNode,
  CFGGuider,
  CFGNorm,
  CFGZeroStar,
  CLIPAttentionMultiply,
  CLIPLoader,
  CLIPMergeAdd,
  CLIPMergeSimple,
  CLIPMergeSubtract,
  CLIPSave,
  CLIPSetLastLayer,
  CLIPTextEncode,
  CLIPTextEncodeControlnet,
  CLIPTextEncodeFlux,
  CLIPTextEncodeHiDream,
  CLIPTextEncodeHunyuanDiT,
  CLIPTextEncodeLumina2,
  CLIPTextEncodePixArtAlpha,
  CLIPTextEncodeSD3,
  CLIPTextEncodeSDXL,
  CLIPTextEncodeSDXLRefiner,
  CLIPVisionEncode,
  CLIPVisionLoader,
  Canny,
  CaseConverter,
  CheckpointLoader,
  CheckpointLoaderSimple,
  CheckpointSave,
  ChromaRadianceOptions,
  CombineHooks2,
  CombineHooks4,
  CombineHooks8,
  ConditioningAverage,
  ConditioningCombine,
  ConditioningConcat,
  ConditioningSetArea,
  ConditioningSetAreaPercentage,
  ConditioningSetAreaPercentageVideo,
  ConditioningSetAreaStrength,
  ConditioningSetDefaultCombine,
  ConditioningSetMask,
  ConditioningSetProperties,
  ConditioningSetPropertiesAndCombine,
  ConditioningSetTimestepRange,
  ConditioningStableAudio,
  ConditioningTimestepsRange,
  ConditioningZeroOut,
  ContextWindowsManual,
  ControlNetApply,
  ControlNetApplyAdvanced,
  ControlNetApplySD3,
  ControlNetInpaintingAliMamaApply,
  ControlNetLoader,
  CosmosImageToVideoLatent,
  CosmosPredict2ImageToVideoLatent,
  CreateHookKeyframe,
  CreateHookKeyframesFromFloats,
  CreateHookKeyframesInterpolated,
  CreateHookLora,
  CreateHookLoraModelOnly,
  CreateHookModelAsLora,
  CreateHookModelAsLoraModelOnly,
  CreateVideo,
  CropMask,
  DiffControlNetLoader,
  DifferentialDiffusion,
  DiffusersLoader,
  DisableNoise,
  DualCFGGuider,
  DualCLIPLoader,
  EasyCache,
  EmptyAceStepLatentAudio,
  EmptyAudio,
  EmptyChromaRadianceLatentImage,
  EmptyCosmosLatentVideo,
  EmptyHunyuanImageLatent,
  EmptyHunyuanLatentVideo,
  EmptyHunyuanVideo15Latent,
  EmptyImage,
  EmptyLTXVLatentVideo,
  EmptyLatentAudio,
  EmptyLatentHunyuan3Dv2,
  EmptyLatentImage,
  EmptyMochiLatentVideo,
  EmptySD3LatentImage,
  "Epsilon Scaling": { "display_name": "Epsilon缩放", "inputs": { "model": { "name": "模型" }, "scaling_factor": { "name": "系数" } }, "outputs": { "0": { "tooltip": null } } },
  ExponentialScheduler,
  ExtendIntermediateSigmas,
  FeatherMask,
  FlipSigmas,
  FluxDisableGuidance,
  FluxGuidance,
  FluxKontextImageScale,
  FluxKontextMaxImageNode,
  FluxKontextMultiReferenceLatentMethod,
  FluxKontextProImageNode,
  FluxProExpandNode,
  FluxProFillNode,
  FluxProUltraImageNode,
  FreSca,
  FreeU,
  FreeU_V2,
  GITSScheduler,
  GLIGENLoader,
  GLIGENTextBoxApply,
  GeminiImage2Node,
  GeminiImageNode,
  GeminiInputFiles,
  GeminiNode,
  GetImageSize,
  GetVideoComponents,
  GrowMask,
  Hunyuan3Dv2Conditioning,
  Hunyuan3Dv2ConditioningMultiView,
  HunyuanImageToVideo,
  HunyuanRefinerLatent,
  HunyuanVideo15ImageToVideo,
  HunyuanVideo15LatentUpscaleWithModel,
  HunyuanVideo15SuperResolution,
  HyperTile,
  HypernetworkLoader,
  IdeogramV1,
  IdeogramV2,
  IdeogramV3,
  ImageAddNoise,
  ImageBatch,
  ImageBlend,
  ImageBlur,
  ImageColorToMask,
  ImageCompositeMasked,
  ImageCrop,
  ImageFlip,
  ImageFromBatch,
  ImageInvert,
  ImageOnlyCheckpointLoader,
  ImageOnlyCheckpointSave,
  ImagePadForOutpaint,
  ImageQuantize,
  ImageRGBToYUV,
  ImageRotate,
  ImageScale,
  ImageScaleBy,
  ImageScaleToMaxDimension,
  ImageScaleToTotalPixels,
  ImageSharpen,
  ImageStitch,
  ImageToMask,
  ImageUpscaleWithModel,
  ImageYUVToRGB,
  InpaintModelConditioning,
  InstructPixToPixConditioning,
  InvertMask,
  JoinImageWithAlpha,
  KSampler,
  KSamplerAdvanced,
  KSamplerSelect,
  KarrasScheduler,
  KlingCameraControlI2VNode,
  KlingCameraControlT2VNode,
  KlingCameraControls,
  KlingDualCharacterVideoEffectNode,
  KlingImage2VideoNode,
  KlingImageGenerationNode,
  KlingLipSyncAudioToVideoNode,
  KlingLipSyncTextToVideoNode,
  KlingSingleImageVideoEffectNode,
  KlingStartEndFrameNode,
  KlingTextToVideoNode,
  KlingVideoExtendNode,
  KlingVirtualTryOnNode,
  LTXVAddGuide,
  LTXVConditioning,
  LTXVCropGuides,
  LTXVImgToVideo,
  LTXVPreprocess,
  LTXVScheduler,
  LaplaceScheduler,
  LatentAdd,
  LatentApplyOperation,
  LatentApplyOperationCFG,
  LatentBatch,
  LatentBatchSeedBehavior,
  LatentBlend,
  LatentComposite,
  LatentCompositeMasked,
  LatentConcat,
  LatentCrop,
  LatentCut,
  LatentFlip,
  LatentFromBatch,
  LatentInterpolate,
  LatentMultiply,
  LatentOperationSharpen,
  LatentOperationTonemapReinhard,
  LatentRotate,
  LatentSubtract,
  LatentUpscale,
  LatentUpscaleBy,
  LatentUpscaleModelLoader,
  LazyCache,
  Load3D,
  LoadAudio,
  LoadImage,
  LoadImageMask,
  LoadImageOutput,
  LoadLatent,
  LoadVideo,
  LoraLoader,
  LoraLoaderModelOnly,
  LoraModelLoader,
  LoraSave,
  LossGraphNode,
  LotusConditioning,
  LtxvApiImageToVideo,
  LtxvApiTextToVideo,
  LumaConceptsNode,
  LumaImageModifyNode,
  LumaImageNode,
  LumaImageToVideoNode,
  LumaReferenceNode,
  LumaVideoNode,
  Mahiro,
  MaskComposite,
  MaskPreview,
  MaskToImage,
  MinimaxHailuoVideoNode,
  MinimaxImageToVideoNode,
  MinimaxTextToVideoNode,
  ModelComputeDtype,
  ModelMergeAdd,
  ModelMergeAuraflow,
  ModelMergeBlocks,
  ModelMergeCosmos14B,
  ModelMergeCosmos7B,
  ModelMergeCosmosPredict2_14B,
  ModelMergeCosmosPredict2_2B,
  ModelMergeFlux1,
  ModelMergeLTXV,
  ModelMergeMochiPreview,
  ModelMergeQwenImage,
  ModelMergeSD1,
  ModelMergeSD2,
  ModelMergeSD35_Large,
  ModelMergeSD3_2B,
  ModelMergeSDXL,
  ModelMergeSimple,
  ModelMergeSubtract,
  ModelMergeWAN2_1,
  ModelPatchLoader,
  ModelSamplingAuraFlow,
  ModelSamplingContinuousEDM,
  ModelSamplingContinuousV,
  ModelSamplingDiscrete,
  ModelSamplingFlux,
  ModelSamplingLTXV,
  ModelSamplingSD3,
  ModelSamplingStableCascade,
  ModelSave,
  MoonvalleyImg2VideoNode,
  MoonvalleyTxt2VideoNode,
  MoonvalleyVideo2VideoNode,
  Morphology,
  OpenAIChatConfig,
  OpenAIChatNode,
  OpenAIDalle2,
  OpenAIDalle3,
  OpenAIGPTImage1,
  OpenAIInputFiles,
  OpenAIVideoSora2,
  OptimalStepsScheduler,
  PairConditioningCombine,
  PairConditioningSetDefaultCombine,
  PairConditioningSetProperties,
  PairConditioningSetPropertiesAndCombine,
  PatchModelAddDownscale,
  PerpNeg,
  PerpNegGuider,
  PerturbedAttentionGuidance,
  PhotoMakerEncode,
  PhotoMakerLoader,
  PixverseImageToVideoNode,
  PixverseTemplateNode,
  PixverseTextToVideoNode,
  PixverseTransitionVideoNode,
  PolyexponentialScheduler,
  PorterDuffImageComposite,
  Preview3D,
  PreviewAny,
  PreviewAudio,
  PreviewImage,
  PrimitiveBoolean,
  PrimitiveFloat,
  PrimitiveInt,
  PrimitiveString,
  PrimitiveStringMultiline,
  QuadrupleCLIPLoader,
  QwenImageDiffsynthControlnet,
  RandomNoise,
  RebatchImages,
  RebatchLatents,
  RecordAudio,
  RecraftColorRGB,
  RecraftControls,
  RecraftCreativeUpscaleNode,
  RecraftCrispUpscaleNode,
  RecraftImageInpaintingNode,
  RecraftImageToImageNode,
  RecraftRemoveBackgroundNode,
  RecraftReplaceBackgroundNode,
  RecraftStyleV3DigitalIllustration,
  RecraftStyleV3InfiniteStyleLibrary,
  RecraftStyleV3LogoRaster,
  RecraftStyleV3RealisticImage,
  RecraftTextToImageNode,
  RecraftTextToVectorNode,
  RecraftVectorizeImageNode,
  ReferenceLatent,
  RegexExtract,
  RegexMatch,
  RegexReplace,
  RenormCFG,
  RepeatImageBatch,
  RepeatLatentBatch,
  RescaleCFG,
  ResizeAndPadImage,
  Rodin3D_Detail,
  Rodin3D_Gen2,
  Rodin3D_Regular,
  Rodin3D_Sketch,
  Rodin3D_Smooth,
  RunwayFirstLastFrameNode,
  RunwayImageToVideoNodeGen3a,
  RunwayImageToVideoNodeGen4,
  RunwayTextToImageNode,
  SDTurboScheduler,
  SD_4XUpscale_Conditioning,
  SV3D_Conditioning,
  SVD_img2vid_Conditioning,
  SamplerCustom,
  SamplerCustomAdvanced,
  SamplerDPMAdaptative,
  SamplerDPMPP_2M_SDE,
  SamplerDPMPP_2S_Ancestral,
  SamplerDPMPP_3M_SDE,
  SamplerDPMPP_SDE,
  SamplerER_SDE,
  SamplerEulerAncestral,
  SamplerEulerAncestralCFGPP,
  SamplerEulerCFGpp,
  SamplerLCMUpscale,
  SamplerLMS,
  SamplerSASolver,
  SamplingPercentToSigma,
  SaveAnimatedPNG,
  SaveAnimatedWEBP,
  SaveAudio,
  SaveAudioMP3,
  SaveAudioOpus,
  SaveGLB,
  SaveImage,
  SaveImageWebsocket,
  SaveLatent,
  SaveSVGNode,
  SaveVideo,
  SaveWEBM,
  ScaleROPE,
  SelfAttentionGuidance,
  SetClipHooks,
  SetFirstSigma,
  SetHookKeyframes,
  SetLatentNoiseMask,
  SetUnionControlNetType,
  SkipLayerGuidanceDiT,
  SkipLayerGuidanceDiTSimple,
  SkipLayerGuidanceSD3,
  SolidMask,
  SplitAudioChannels,
  SplitImageWithAlpha,
  SplitSigmas,
  SplitSigmasDenoise,
  StabilityAudioInpaint,
  StabilityAudioToAudio,
  StabilityStableImageSD_3_5Node,
  StabilityStableImageUltraNode,
  StabilityTextToAudio,
  StabilityUpscaleConservativeNode,
  StabilityUpscaleCreativeNode,
  StabilityUpscaleFastNode,
  StableCascade_EmptyLatentImage,
  StableCascade_StageB_Conditioning,
  StableCascade_StageC_VAEEncode,
  StableCascade_SuperResolutionControlnet,
  StableZero123_Conditioning,
  StableZero123_Conditioning_Batched,
  StringCompare,
  StringConcatenate,
  StringContains,
  StringLength,
  StringReplace,
  StringSubstring,
  StringTrim,
  StyleModelApply,
  StyleModelLoader,
  T5TokenizerOptions,
  TCFG,
  TemporalScoreRescaling,
  TextEncodeAceStepAudio,
  TextEncodeHunyuanVideo_ImageToVideo,
  TextEncodeQwenImageEdit,
  TextEncodeQwenImageEditPlus,
  ThresholdMask,
  TomePatchModel,
  TopazImageEnhance,
  TopazVideoEnhance,
  TorchCompileModel,
  TrainLoraNode,
  TrimAudioDuration,
  TrimVideoLatent,
  TripleCLIPLoader,
  TripoConversionNode,
  TripoImageToModelNode,
  TripoMultiviewToModelNode,
  TripoRefineNode,
  TripoRetargetNode,
  TripoRigNode,
  TripoTextToModelNode,
  TripoTextureNode,
  UNETLoader,
  UNetCrossAttentionMultiply,
  UNetSelfAttentionMultiply,
  UNetTemporalAttentionMultiply,
  USOStyleReference,
  UpscaleModelLoader,
  VAEDecode,
  VAEDecodeAudio,
  VAEDecodeHunyuan3D,
  VAEDecodeTiled,
  VAEEncode,
  VAEEncodeAudio,
  VAEEncodeForInpaint,
  VAEEncodeTiled,
  VAELoader,
  VAESave,
  VPScheduler,
  Veo3VideoGenerationNode,
  VeoVideoGenerationNode,
  VideoLinearCFGGuidance,
  VideoTriangleCFGGuidance,
  ViduImageToVideoNode,
  ViduReferenceVideoNode,
  ViduStartEndToVideoNode,
  ViduTextToVideoNode,
  VoxelToMesh,
  VoxelToMeshBasic,
  Wan22FunControlToVideo,
  Wan22ImageToVideoLatent,
  WanAnimateToVideo,
  WanCameraEmbedding,
  WanCameraImageToVideo,
  WanContextWindowsManual,
  WanFirstLastFrameToVideo,
  WanFunControlToVideo,
  WanFunInpaintToVideo,
  WanHuMoImageToVideo,
  WanImageToImageApi,
  WanImageToVideo,
  WanImageToVideoApi,
  WanPhantomSubjectToVideo,
  WanSoundImageToVideo,
  WanSoundImageToVideoExtend,
  WanTextToImageApi,
  WanTextToVideoApi,
  WanTrackToVideo,
  WanVaceToVideo,
  WebcamCapture,
  unCLIPCheckpointLoader,
  unCLIPConditioning,
  wanBlockSwap
};
export {
  APG,
  AddNoise,
  AlignYourStepsScheduler,
  AudioAdjustVolume,
  AudioConcat,
  AudioEncoderEncode,
  AudioEncoderLoader,
  AudioMerge,
  BasicGuider,
  BasicScheduler,
  BetaSamplingScheduler,
  ByteDanceFirstLastFrameNode,
  ByteDanceImageEditNode,
  ByteDanceImageNode,
  ByteDanceImageReferenceNode,
  ByteDanceImageToVideoNode,
  ByteDanceSeedreamNode,
  ByteDanceTextToVideoNode,
  CFGGuider,
  CFGNorm,
  CFGZeroStar,
  CLIPAttentionMultiply,
  CLIPLoader,
  CLIPMergeAdd,
  CLIPMergeSimple,
  CLIPMergeSubtract,
  CLIPSave,
  CLIPSetLastLayer,
  CLIPTextEncode,
  CLIPTextEncodeControlnet,
  CLIPTextEncodeFlux,
  CLIPTextEncodeHiDream,
  CLIPTextEncodeHunyuanDiT,
  CLIPTextEncodeLumina2,
  CLIPTextEncodePixArtAlpha,
  CLIPTextEncodeSD3,
  CLIPTextEncodeSDXL,
  CLIPTextEncodeSDXLRefiner,
  CLIPVisionEncode,
  CLIPVisionLoader,
  Canny,
  CaseConverter,
  CheckpointLoader,
  CheckpointLoaderSimple,
  CheckpointSave,
  ChromaRadianceOptions,
  CombineHooks2,
  CombineHooks4,
  CombineHooks8,
  ConditioningAverage,
  ConditioningCombine,
  ConditioningConcat,
  ConditioningSetArea,
  ConditioningSetAreaPercentage,
  ConditioningSetAreaPercentageVideo,
  ConditioningSetAreaStrength,
  ConditioningSetDefaultCombine,
  ConditioningSetMask,
  ConditioningSetProperties,
  ConditioningSetPropertiesAndCombine,
  ConditioningSetTimestepRange,
  ConditioningStableAudio,
  ConditioningTimestepsRange,
  ConditioningZeroOut,
  ContextWindowsManual,
  ControlNetApply,
  ControlNetApplyAdvanced,
  ControlNetApplySD3,
  ControlNetInpaintingAliMamaApply,
  ControlNetLoader,
  CosmosImageToVideoLatent,
  CosmosPredict2ImageToVideoLatent,
  CreateHookKeyframe,
  CreateHookKeyframesFromFloats,
  CreateHookKeyframesInterpolated,
  CreateHookLora,
  CreateHookLoraModelOnly,
  CreateHookModelAsLora,
  CreateHookModelAsLoraModelOnly,
  CreateVideo,
  CropMask,
  DiffControlNetLoader,
  DifferentialDiffusion,
  DiffusersLoader,
  DisableNoise,
  DualCFGGuider,
  DualCLIPLoader,
  EasyCache,
  EmptyAceStepLatentAudio,
  EmptyAudio,
  EmptyChromaRadianceLatentImage,
  EmptyCosmosLatentVideo,
  EmptyHunyuanImageLatent,
  EmptyHunyuanLatentVideo,
  EmptyHunyuanVideo15Latent,
  EmptyImage,
  EmptyLTXVLatentVideo,
  EmptyLatentAudio,
  EmptyLatentHunyuan3Dv2,
  EmptyLatentImage,
  EmptyMochiLatentVideo,
  EmptySD3LatentImage,
  ExponentialScheduler,
  ExtendIntermediateSigmas,
  FeatherMask,
  FlipSigmas,
  FluxDisableGuidance,
  FluxGuidance,
  FluxKontextImageScale,
  FluxKontextMaxImageNode,
  FluxKontextMultiReferenceLatentMethod,
  FluxKontextProImageNode,
  FluxProExpandNode,
  FluxProFillNode,
  FluxProUltraImageNode,
  FreSca,
  FreeU,
  FreeU_V2,
  GITSScheduler,
  GLIGENLoader,
  GLIGENTextBoxApply,
  GeminiImage2Node,
  GeminiImageNode,
  GeminiInputFiles,
  GeminiNode,
  GetImageSize,
  GetVideoComponents,
  GrowMask,
  Hunyuan3Dv2Conditioning,
  Hunyuan3Dv2ConditioningMultiView,
  HunyuanImageToVideo,
  HunyuanRefinerLatent,
  HunyuanVideo15ImageToVideo,
  HunyuanVideo15LatentUpscaleWithModel,
  HunyuanVideo15SuperResolution,
  HyperTile,
  HypernetworkLoader,
  IdeogramV1,
  IdeogramV2,
  IdeogramV3,
  ImageAddNoise,
  ImageBatch,
  ImageBlend,
  ImageBlur,
  ImageColorToMask,
  ImageCompositeMasked,
  ImageCrop,
  ImageFlip,
  ImageFromBatch,
  ImageInvert,
  ImageOnlyCheckpointLoader,
  ImageOnlyCheckpointSave,
  ImagePadForOutpaint,
  ImageQuantize,
  ImageRGBToYUV,
  ImageRotate,
  ImageScale,
  ImageScaleBy,
  ImageScaleToMaxDimension,
  ImageScaleToTotalPixels,
  ImageSharpen,
  ImageStitch,
  ImageToMask,
  ImageUpscaleWithModel,
  ImageYUVToRGB,
  InpaintModelConditioning,
  InstructPixToPixConditioning,
  InvertMask,
  JoinImageWithAlpha,
  KSampler,
  KSamplerAdvanced,
  KSamplerSelect,
  KarrasScheduler,
  KlingCameraControlI2VNode,
  KlingCameraControlT2VNode,
  KlingCameraControls,
  KlingDualCharacterVideoEffectNode,
  KlingImage2VideoNode,
  KlingImageGenerationNode,
  KlingLipSyncAudioToVideoNode,
  KlingLipSyncTextToVideoNode,
  KlingSingleImageVideoEffectNode,
  KlingStartEndFrameNode,
  KlingTextToVideoNode,
  KlingVideoExtendNode,
  KlingVirtualTryOnNode,
  LTXVAddGuide,
  LTXVConditioning,
  LTXVCropGuides,
  LTXVImgToVideo,
  LTXVPreprocess,
  LTXVScheduler,
  LaplaceScheduler,
  LatentAdd,
  LatentApplyOperation,
  LatentApplyOperationCFG,
  LatentBatch,
  LatentBatchSeedBehavior,
  LatentBlend,
  LatentComposite,
  LatentCompositeMasked,
  LatentConcat,
  LatentCrop,
  LatentCut,
  LatentFlip,
  LatentFromBatch,
  LatentInterpolate,
  LatentMultiply,
  LatentOperationSharpen,
  LatentOperationTonemapReinhard,
  LatentRotate,
  LatentSubtract,
  LatentUpscale,
  LatentUpscaleBy,
  LatentUpscaleModelLoader,
  LazyCache,
  Load3D,
  LoadAudio,
  LoadImage,
  LoadImageMask,
  LoadImageOutput,
  LoadLatent,
  LoadVideo,
  LoraLoader,
  LoraLoaderModelOnly,
  LoraModelLoader,
  LoraSave,
  LossGraphNode,
  LotusConditioning,
  LtxvApiImageToVideo,
  LtxvApiTextToVideo,
  LumaConceptsNode,
  LumaImageModifyNode,
  LumaImageNode,
  LumaImageToVideoNode,
  LumaReferenceNode,
  LumaVideoNode,
  Mahiro,
  MaskComposite,
  MaskPreview,
  MaskToImage,
  MinimaxHailuoVideoNode,
  MinimaxImageToVideoNode,
  MinimaxTextToVideoNode,
  ModelComputeDtype,
  ModelMergeAdd,
  ModelMergeAuraflow,
  ModelMergeBlocks,
  ModelMergeCosmos14B,
  ModelMergeCosmos7B,
  ModelMergeCosmosPredict2_14B,
  ModelMergeCosmosPredict2_2B,
  ModelMergeFlux1,
  ModelMergeLTXV,
  ModelMergeMochiPreview,
  ModelMergeQwenImage,
  ModelMergeSD1,
  ModelMergeSD2,
  ModelMergeSD35_Large,
  ModelMergeSD3_2B,
  ModelMergeSDXL,
  ModelMergeSimple,
  ModelMergeSubtract,
  ModelMergeWAN2_1,
  ModelPatchLoader,
  ModelSamplingAuraFlow,
  ModelSamplingContinuousEDM,
  ModelSamplingContinuousV,
  ModelSamplingDiscrete,
  ModelSamplingFlux,
  ModelSamplingLTXV,
  ModelSamplingSD3,
  ModelSamplingStableCascade,
  ModelSave,
  MoonvalleyImg2VideoNode,
  MoonvalleyTxt2VideoNode,
  MoonvalleyVideo2VideoNode,
  Morphology,
  OpenAIChatConfig,
  OpenAIChatNode,
  OpenAIDalle2,
  OpenAIDalle3,
  OpenAIGPTImage1,
  OpenAIInputFiles,
  OpenAIVideoSora2,
  OptimalStepsScheduler,
  PairConditioningCombine,
  PairConditioningSetDefaultCombine,
  PairConditioningSetProperties,
  PairConditioningSetPropertiesAndCombine,
  PatchModelAddDownscale,
  PerpNeg,
  PerpNegGuider,
  PerturbedAttentionGuidance,
  PhotoMakerEncode,
  PhotoMakerLoader,
  PixverseImageToVideoNode,
  PixverseTemplateNode,
  PixverseTextToVideoNode,
  PixverseTransitionVideoNode,
  PolyexponentialScheduler,
  PorterDuffImageComposite,
  Preview3D,
  PreviewAny,
  PreviewAudio,
  PreviewImage,
  PrimitiveBoolean,
  PrimitiveFloat,
  PrimitiveInt,
  PrimitiveString,
  PrimitiveStringMultiline,
  QuadrupleCLIPLoader,
  QwenImageDiffsynthControlnet,
  RandomNoise,
  RebatchImages,
  RebatchLatents,
  RecordAudio,
  RecraftColorRGB,
  RecraftControls,
  RecraftCreativeUpscaleNode,
  RecraftCrispUpscaleNode,
  RecraftImageInpaintingNode,
  RecraftImageToImageNode,
  RecraftRemoveBackgroundNode,
  RecraftReplaceBackgroundNode,
  RecraftStyleV3DigitalIllustration,
  RecraftStyleV3InfiniteStyleLibrary,
  RecraftStyleV3LogoRaster,
  RecraftStyleV3RealisticImage,
  RecraftTextToImageNode,
  RecraftTextToVectorNode,
  RecraftVectorizeImageNode,
  ReferenceLatent,
  RegexExtract,
  RegexMatch,
  RegexReplace,
  RenormCFG,
  RepeatImageBatch,
  RepeatLatentBatch,
  RescaleCFG,
  ResizeAndPadImage,
  Rodin3D_Detail,
  Rodin3D_Gen2,
  Rodin3D_Regular,
  Rodin3D_Sketch,
  Rodin3D_Smooth,
  RunwayFirstLastFrameNode,
  RunwayImageToVideoNodeGen3a,
  RunwayImageToVideoNodeGen4,
  RunwayTextToImageNode,
  SDTurboScheduler,
  SD_4XUpscale_Conditioning,
  SV3D_Conditioning,
  SVD_img2vid_Conditioning,
  SamplerCustom,
  SamplerCustomAdvanced,
  SamplerDPMAdaptative,
  SamplerDPMPP_2M_SDE,
  SamplerDPMPP_2S_Ancestral,
  SamplerDPMPP_3M_SDE,
  SamplerDPMPP_SDE,
  SamplerER_SDE,
  SamplerEulerAncestral,
  SamplerEulerAncestralCFGPP,
  SamplerEulerCFGpp,
  SamplerLCMUpscale,
  SamplerLMS,
  SamplerSASolver,
  SamplingPercentToSigma,
  SaveAnimatedPNG,
  SaveAnimatedWEBP,
  SaveAudio,
  SaveAudioMP3,
  SaveAudioOpus,
  SaveGLB,
  SaveImage,
  SaveImageWebsocket,
  SaveLatent,
  SaveSVGNode,
  SaveVideo,
  SaveWEBM,
  ScaleROPE,
  SelfAttentionGuidance,
  SetClipHooks,
  SetFirstSigma,
  SetHookKeyframes,
  SetLatentNoiseMask,
  SetUnionControlNetType,
  SkipLayerGuidanceDiT,
  SkipLayerGuidanceDiTSimple,
  SkipLayerGuidanceSD3,
  SolidMask,
  SplitAudioChannels,
  SplitImageWithAlpha,
  SplitSigmas,
  SplitSigmasDenoise,
  StabilityAudioInpaint,
  StabilityAudioToAudio,
  StabilityStableImageSD_3_5Node,
  StabilityStableImageUltraNode,
  StabilityTextToAudio,
  StabilityUpscaleConservativeNode,
  StabilityUpscaleCreativeNode,
  StabilityUpscaleFastNode,
  StableCascade_EmptyLatentImage,
  StableCascade_StageB_Conditioning,
  StableCascade_StageC_VAEEncode,
  StableCascade_SuperResolutionControlnet,
  StableZero123_Conditioning,
  StableZero123_Conditioning_Batched,
  StringCompare,
  StringConcatenate,
  StringContains,
  StringLength,
  StringReplace,
  StringSubstring,
  StringTrim,
  StyleModelApply,
  StyleModelLoader,
  T5TokenizerOptions,
  TCFG,
  TemporalScoreRescaling,
  TextEncodeAceStepAudio,
  TextEncodeHunyuanVideo_ImageToVideo,
  TextEncodeQwenImageEdit,
  TextEncodeQwenImageEditPlus,
  ThresholdMask,
  TomePatchModel,
  TopazImageEnhance,
  TopazVideoEnhance,
  TorchCompileModel,
  TrainLoraNode,
  TrimAudioDuration,
  TrimVideoLatent,
  TripleCLIPLoader,
  TripoConversionNode,
  TripoImageToModelNode,
  TripoMultiviewToModelNode,
  TripoRefineNode,
  TripoRetargetNode,
  TripoRigNode,
  TripoTextToModelNode,
  TripoTextureNode,
  UNETLoader,
  UNetCrossAttentionMultiply,
  UNetSelfAttentionMultiply,
  UNetTemporalAttentionMultiply,
  USOStyleReference,
  UpscaleModelLoader,
  VAEDecode,
  VAEDecodeAudio,
  VAEDecodeHunyuan3D,
  VAEDecodeTiled,
  VAEEncode,
  VAEEncodeAudio,
  VAEEncodeForInpaint,
  VAEEncodeTiled,
  VAELoader,
  VAESave,
  VPScheduler,
  Veo3VideoGenerationNode,
  VeoVideoGenerationNode,
  VideoLinearCFGGuidance,
  VideoTriangleCFGGuidance,
  ViduImageToVideoNode,
  ViduReferenceVideoNode,
  ViduStartEndToVideoNode,
  ViduTextToVideoNode,
  VoxelToMesh,
  VoxelToMeshBasic,
  Wan22FunControlToVideo,
  Wan22ImageToVideoLatent,
  WanAnimateToVideo,
  WanCameraEmbedding,
  WanCameraImageToVideo,
  WanContextWindowsManual,
  WanFirstLastFrameToVideo,
  WanFunControlToVideo,
  WanFunInpaintToVideo,
  WanHuMoImageToVideo,
  WanImageToImageApi,
  WanImageToVideo,
  WanImageToVideoApi,
  WanPhantomSubjectToVideo,
  WanSoundImageToVideo,
  WanSoundImageToVideoExtend,
  WanTextToImageApi,
  WanTextToVideoApi,
  WanTrackToVideo,
  WanVaceToVideo,
  WebcamCapture,
  nodeDefs as default,
  unCLIPCheckpointLoader,
  unCLIPConditioning,
  wanBlockSwap
};
//# sourceMappingURL=nodeDefs-DIAYlJwM.js.map
