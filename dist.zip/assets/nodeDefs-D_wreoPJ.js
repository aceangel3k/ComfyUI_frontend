const APG = { "display_name": "적응형 투사 가이던스", "inputs": { "eta": { "name": "eta", "tooltip": "병렬 가이던스 벡터의 크기를 조절합니다. 1로 설정 시 기본 CFG 동작입니다." }, "model": { "name": "모델" }, "momentum": { "name": "momentum", "tooltip": "확산 과정 중 가이던스의 이동 평균을 조절합니다. 0으로 설정 시 비활성화됩니다." }, "norm_threshold": { "name": "norm_threshold", "tooltip": "가이던스 벡터를 이 값으로 정규화합니다. 0으로 설정 시 정규화가 비활성화됩니다." } }, "outputs": { "0": { "tooltip": null } } };
const AddNoise = { "display_name": "노이즈 추가", "inputs": { "latent_image": { "name": "잠재 이미지" }, "model": { "name": "모델" }, "noise": { "name": "노이즈" }, "sigmas": { "name": "시그마 배열" } } };
const AlignYourStepsScheduler = { "display_name": "AlignYourSteps 스케쥴러", "inputs": { "denoise": { "name": "노이즈 제거양" }, "model_type": { "name": "모델 유형" }, "steps": { "name": "스텝 수" } }, "outputs": { "0": { "tooltip": null } } };
const AudioAdjustVolume = { "display_name": "오디오 볼륨 조절", "inputs": { "audio": { "name": "오디오" }, "volume": { "name": "volume", "tooltip": "데시벨(dB) 단위의 볼륨 조절. 0 = 변경 없음, +6 = 두 배, -6 = 절반 등" } } };
const AudioConcat = { "description": "지정된 방향으로 audio1을 audio2에 연결합니다.", "display_name": "오디오 연결", "inputs": { "audio1": { "name": "audio1" }, "audio2": { "name": "audio2" }, "direction": { "name": "direction", "tooltip": "audio2를 audio1 뒤에 추가할지 앞에 추가할지 여부입니다." } } };
const AudioEncoderEncode = { "display_name": "오디오 인코더 인코딩", "inputs": { "audio": { "name": "audio" }, "audio_encoder": { "name": "audio_encoder" } }, "outputs": { "0": { "tooltip": null } } };
const AudioEncoderLoader = { "display_name": "오디오 인코더 로더", "inputs": { "audio_encoder_name": { "name": "audio_encoder_name" } }, "outputs": { "0": { "tooltip": null } } };
const AudioMerge = { "description": "두 오디오 트랙의 파형을 겹쳐서 결합합니다.", "display_name": "오디오 병합", "inputs": { "audio1": { "name": "audio1" }, "audio2": { "name": "audio2" }, "merge_method": { "name": "merge_method", "tooltip": "오디오 파형을 결합하는 데 사용되는 방법입니다." } } };
const BasicGuider = { "display_name": "기본 가이드", "inputs": { "conditioning": { "name": "조건" }, "model": { "name": "모델" } } };
const BasicScheduler = { "display_name": "기본 스케줄러", "inputs": { "denoise": { "name": "노이즈 제거양" }, "model": { "name": "모델" }, "scheduler": { "name": "스케줄러" }, "steps": { "name": "스텝 수" } } };
const BetaSamplingScheduler = { "display_name": "베타 샘플링 스케줄러", "inputs": { "alpha": { "name": "알파" }, "beta": { "name": "베타" }, "model": { "name": "모델" }, "steps": { "name": "스텝 수" } } };
const ByteDanceFirstLastFrameNode = { "description": "프롬프트와 첫 번째 및 마지막 프레임을 사용하여 비디오를 생성합니다.", "display_name": "ByteDance 첫-마지막-프레임에서 비디오 생성", "inputs": { "aspect_ratio": { "name": "aspect_ratio", "tooltip": "출력 비디오의 화면비입니다." }, "camera_fixed": { "name": "camera_fixed", "tooltip": "카메라를 고정할지 여부를 지정합니다. 플랫폼이 카메라 고정 지시를 프롬프트에 추가하지만 실제 효과를 보장하지는 않습니다." }, "control_after_generate": { "name": "생성 후 제어" }, "duration": { "name": "duration", "tooltip": "출력 비디오의 지속 시간(초)입니다." }, "first_frame": { "name": "first_frame", "tooltip": "비디오에 사용될 첫 번째 프레임입니다." }, "last_frame": { "name": "last_frame", "tooltip": "비디오에 사용될 마지막 프레임입니다." }, "model": { "name": "model" }, "prompt": { "name": "prompt", "tooltip": "비디오 생성에 사용되는 텍스트 프롬프트입니다." }, "resolution": { "name": "resolution", "tooltip": "출력 비디오의 해상도입니다." }, "seed": { "name": "seed", "tooltip": "생성에 사용할 시드 값입니다." }, "watermark": { "name": "watermark", "tooltip": '비디오에 "AI 생성" 워터마크를 추가할지 여부' } }, "outputs": { "0": { "tooltip": null } } };
const ByteDanceImageEditNode = { "description": "프롬프트 기반으로 ByteDance 모델을 사용하여 이미지 편집", "display_name": "ByteDance 이미지 편집", "inputs": { "control_after_generate": { "name": "생성 후 제어" }, "guidance_scale": { "name": "가이던스 스케일", "tooltip": "값이 높을수록 이미지가 프롬프트를 더 밀접하게 따름" }, "image": { "name": "이미지", "tooltip": "편집할 기본 이미지" }, "model": { "name": "모델" }, "prompt": { "name": "프롬프트", "tooltip": "이미지 편집 지시사항" }, "seed": { "name": "시드", "tooltip": "생성에 사용할 시드 값" }, "watermark": { "name": "워터마크", "tooltip": '이미지에 "AI 생성" 워터마크를 추가할지 여부' } }, "outputs": { "0": { "tooltip": null } } };
const ByteDanceImageNode = { "description": "프롬프트 기반으로 ByteDance 모델을 사용하여 이미지 생성", "display_name": "ByteDance 이미지", "inputs": { "control_after_generate": { "name": "생성 후 제어" }, "guidance_scale": { "name": "가이던스 스케일", "tooltip": "값이 높을수록 이미지가 프롬프트를 더 밀접하게 따름" }, "height": { "name": "높이", "tooltip": "이미지의 사용자 지정 높이. `size_preset`이 `Custom`으로 설정된 경우에만 값이 적용됨" }, "model": { "name": "모델" }, "prompt": { "name": "프롬프트", "tooltip": "이미지 생성에 사용할 텍스트 프롬프트" }, "seed": { "name": "시드", "tooltip": "생성에 사용할 시드 값" }, "size_preset": { "name": "크기 사전 설정", "tooltip": "권장 크기를 선택하세요. 사용자 지정을 선택하면 아래 너비와 높이를 사용합니다" }, "watermark": { "name": "워터마크", "tooltip": '이미지에 "AI 생성" 워터마크를 추가할지 여부' }, "width": { "name": "너비", "tooltip": "이미지의 사용자 지정 너비. `size_preset`이 `Custom`으로 설정된 경우에만 값이 적용됨" } }, "outputs": { "0": { "tooltip": null } } };
const ByteDanceImageReferenceNode = { "description": "프롬프트와 참조 이미지를 사용하여 비디오 생성", "display_name": "ByteDance 참조 이미지를 비디오로", "inputs": { "aspect_ratio": { "name": "화면비율", "tooltip": "출력 비디오의 화면비율입니다." }, "control_after_generate": { "name": "생성 후 제어" }, "duration": { "name": "지속 시간", "tooltip": "출력 비디오의 지속 시간(초)입니다." }, "images": { "name": "이미지", "tooltip": "1개에서 4개의 이미지" }, "model": { "name": "모델" }, "prompt": { "name": "프롬프트", "tooltip": "비디오 생성에 사용할 텍스트 프롬프트" }, "resolution": { "name": "해상도", "tooltip": "출력 비디오의 해상도" }, "seed": { "name": "시드", "tooltip": "생성에 사용할 시드 값입니다." }, "watermark": { "name": "워터마크", "tooltip": '비디오에 "AI 생성" 워터마크를 추가할지 여부입니다.' } }, "outputs": { "0": { "tooltip": null } } };
const ByteDanceImageToVideoNode = { "description": "이미지와 프롬프트를 기반으로 API를 통해 ByteDance 모델을 사용하여 비디오 생성", "display_name": "ByteDance 이미지 투 비디오", "inputs": { "aspect_ratio": { "name": "화면비율", "tooltip": "출력 비디오의 화면비율입니다." }, "camera_fixed": { "name": "카메라 고정", "tooltip": "카메라를 고정할지 여부를 지정합니다. 플랫폼이 카메라 고정 지시를 프롬프트에 추가하지만 실제 효과를 보장하지는 않습니다." }, "control_after_generate": { "name": "생성 후 제어" }, "duration": { "name": "지속 시간", "tooltip": "출력 비디오의 지속 시간(초)입니다." }, "image": { "name": "이미지", "tooltip": "비디오에 사용할 첫 번째 프레임입니다." }, "model": { "name": "모델" }, "prompt": { "name": "프롬프트", "tooltip": "비디오 생성에 사용된 텍스트 프롬프트입니다." }, "resolution": { "name": "해상도", "tooltip": "출력 비디오의 해상도입니다." }, "seed": { "name": "시드", "tooltip": "생성에 사용할 시드 값입니다." }, "watermark": { "name": "워터마크", "tooltip": '비디오에 "AI 생성" 워터마크를 추가할지 여부입니다.' } }, "outputs": { "0": { "tooltip": null } } };
const ByteDanceSeedreamNode = { "description": "최대 4K 해상도까지 통합 텍스트-이미지 생성 및 정밀한 단일 문장 편집.", "display_name": "ByteDance Seedream 4", "inputs": { "control_after_generate": { "name": "control after generate" }, "fail_on_partial": { "name": "fail_on_partial", "tooltip": "활성화하면 요청된 이미지 중 일부가 누락되거나 오류가 반환될 경우 실행을 중단합니다." }, "height": { "name": "높이", "tooltip": "이미지의 사용자 지정 높이입니다. 이 값은 `size_preset`이 `Custom`으로 설정된 경우에만 작동합니다" }, "image": { "name": "이미지", "tooltip": "이미지-이미지 생성을 위한 입력 이미지입니다. 단일 또는 다중 참조 생성을 위한 1-10개 이미지 목록입니다." }, "max_images": { "name": "max_images", "tooltip": "sequential_image_generation='auto'일 때 생성할 최대 이미지 수입니다. 총 이미지 수(입력 + 생성)는 15개를 초과할 수 없습니다." }, "model": { "name": "모델", "tooltip": "모델 이름" }, "prompt": { "name": "프롬프트", "tooltip": "이미지를 생성하거나 편집하기 위한 텍스트 프롬프트입니다." }, "seed": { "name": "seed", "tooltip": "생성에 사용할 시드 값입니다." }, "sequential_image_generation": { "name": "순차적 이미지 생성", "tooltip": "그룹 이미지 생성 모드입니다. 'disabled'는 단일 이미지를 생성하고, 'auto'는 모델이 여러 관련 이미지(예: 스토리 장면, 캐릭터 변형)를 생성할지 여부를 결정하도록 합니다." }, "size_preset": { "name": "크기 사전 설정", "tooltip": "권장 크기를 선택하세요. 아래 너비와 높이를 사용하려면 사용자 지정을 선택하세요." }, "watermark": { "name": "watermark", "tooltip": '이미지에 "AI 생성" 워터마크를 추가할지 여부입니다.' }, "width": { "name": "너비", "tooltip": "이미지의 사용자 지정 너비입니다. 이 값은 `size_preset`이 `Custom`으로 설정된 경우에만 작동합니다" } }, "outputs": { "0": { "tooltip": null } } };
const ByteDanceTextToVideoNode = { "description": "프롬프트를 기반으로 API를 통해 ByteDance 모델을 사용하여 비디오 생성", "display_name": "ByteDance 텍스트-비디오", "inputs": { "aspect_ratio": { "name": "aspect_ratio", "tooltip": "출력 비디오의 화면비입니다." }, "camera_fixed": { "name": "camera_fixed", "tooltip": "카메라를 고정할지 여부를 지정합니다. 플랫폼이 카메라 고정 지시를 프롬프트에 추가하지만, 실제 효과를 보장하지는 않습니다." }, "control_after_generate": { "name": "control after generate" }, "duration": { "name": "duration", "tooltip": "출력 비디오의 지속 시간(초)입니다." }, "model": { "name": "model" }, "prompt": { "name": "prompt", "tooltip": "비디오 생성에 사용되는 텍스트 프롬프트입니다." }, "resolution": { "name": "resolution", "tooltip": "출력 비디오의 해상도입니다." }, "seed": { "name": "seed", "tooltip": "생성에 사용할 시드 값입니다." }, "watermark": { "name": "watermark", "tooltip": '비디오에 "AI 생성" 워터마크를 추가할지 여부입니다.' } }, "outputs": { "0": { "tooltip": null } } };
const CFGGuider = { "display_name": "CFG 가이드", "inputs": { "cfg": { "name": "cfg" }, "model": { "name": "모델" }, "negative": { "name": "부정 조건" }, "positive": { "name": "긍정 조건" } } };
const CFGNorm = { "display_name": "CFGNorm", "inputs": { "model": { "name": "model" }, "strength": { "name": "strength" } }, "outputs": { "0": { "name": "patched_model", "tooltip": null } } };
const CFGZeroStar = { "display_name": "CFGZeroStar", "inputs": { "model": { "name": "모델" } }, "outputs": { "0": { "name": "패치된 모델", "tooltip": null } } };
const CLIPAttentionMultiply = { "display_name": "CLIP 어텐션 곱하기", "inputs": { "clip": { "name": "clip" }, "k": { "name": "k" }, "out": { "name": "out" }, "q": { "name": "q" }, "v": { "name": "v" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPLoader = { "description": "[조합법]\n\nstable_diffusion: clip-l\nstable_cascade: clip-g\nsd3: t5 / clip-g / clip-l\nstable_audio: t5\nmochi: t5\ncosmos: old t5 xxl", "display_name": "CLIP 로드", "inputs": { "clip_name": { "name": "CLIP 파일명" }, "device": { "name": "장치" }, "type": { "name": "유형" } } };
const CLIPMergeAdd = { "display_name": "CLIP 병합 (더하기)", "inputs": { "clip1": { "name": "CLIP1" }, "clip2": { "name": "CLIP2" } } };
const CLIPMergeSimple = { "display_name": "CLIP 병합 (단순)", "inputs": { "clip1": { "name": "CLIP1" }, "clip2": { "name": "CLIP2" }, "ratio": { "name": "비율" } } };
const CLIPMergeSubtract = { "display_name": "CLIP 병합 (빼기)", "inputs": { "clip1": { "name": "CLIP1" }, "clip2": { "name": "CLIP2" }, "multiplier": { "name": "배율" } } };
const CLIPSave = { "display_name": "CLIP 저장", "inputs": { "clip": { "name": "clip" }, "filename_prefix": { "name": "파일명 접두사" } } };
const CLIPSetLastLayer = { "display_name": "CLIP 마지막 레이어 설정", "inputs": { "clip": { "name": "clip" }, "stop_at_clip_layer": { "name": "CLIP 레이어 중단점" } } };
const CLIPTextEncode = { "description": "CLIP 모델을 사용하여 텍스트 프롬프트를 인코딩하여 확산 모델이 특정 이미지를 생성하도록 유도하는 임베딩으로 변환합니다.", "display_name": "CLIP 텍스트 인코딩 (프롬프트)", "inputs": { "clip": { "name": "clip", "tooltip": "텍스트 인코딩에 사용되는 CLIP 모델입니다." }, "text": { "name": "프롬프트 텍스트", "tooltip": "인코딩할 텍스트입니다." } }, "outputs": { "0": { "tooltip": "확산 모델을 유도하는 데 사용되는 텍스트 임베딩을 포함하는 조건입니다." } } };
const CLIPTextEncodeControlnet = { "display_name": "CLIP 텍스트 인코딩 (컨트롤넷)", "inputs": { "clip": { "name": "clip" }, "conditioning": { "name": "조건" }, "text": { "name": "프롬프트 텍스트" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeFlux = { "display_name": "CLIP 텍스트 인코딩 (FLUX)", "inputs": { "clip": { "name": "clip" }, "clip_l": { "name": "clip-l 프롬프트" }, "guidance": { "name": "가이던스" }, "t5xxl": { "name": "t5xxl 프롬프트" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeHiDream = { "display_name": "CLIPTextEncodeHiDream", "inputs": { "clip": { "name": "clip" }, "clip_g": { "name": "clip-g 프롬프트" }, "clip_l": { "name": "clip-l 프롬프트" }, "llama": { "name": "llama 프롬프트" }, "t5xxl": { "name": "t5xxl 프롬프트" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeHunyuanDiT = { "display_name": "CLIP 텍스트 인코딩 (HunyuanDiT)", "inputs": { "bert": { "name": "bert 프롬프트" }, "clip": { "name": "clip" }, "mt5xl": { "name": "mt5xl 프롬프트" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeLumina2 = { "description": "CLIP 모델을 사용하여 시스템 프롬프트와 사용자 프롬프트를 인코딩하여 특정 이미지를 생성하는 데 사용할 수 있는 임베딩으로 변환합니다.", "display_name": "CLIP 텍스트 인코딩 (Lumina2)", "inputs": { "clip": { "name": "clip", "tooltip": "텍스트를 인코딩하는 데 사용되는 CLIP 모델입니다." }, "system_prompt": { "name": "system_prompt", "tooltip": "Lumina2는 두 가지 유형의 시스템 프롬프트를 제공합니다.\nSuperior: 텍스트 프롬프트 또는 사용자 프롬프트를 기반으로 우수한 이미지-텍스트 정렬 정도로 우수한 이미지를 생성하도록 설계된 도우미입니다.\nAlignment: 텍스트 프롬프트를 기반으로 이미지-텍스트 정렬의 최고 수준으로 고품질 이미지를 생성하도록 설계된 도우미입니다." }, "user_prompt": { "name": "user_prompt", "tooltip": "인코딩할 텍스트입니다." } }, "outputs": { "0": { "tooltip": "확산 모델을 유도하는 데 사용되는 텍스트 임베딩을 포함하는 조건입니다." } } };
const CLIPTextEncodePixArtAlpha = { "description": "텍스트를 인코딩하고 PixArt Alpha의 해상도 조건을 설정합니다. PixArt Sigma에는 적용되지 않습니다.", "display_name": "CLIPTextEncodePixArtAlpha", "inputs": { "clip": { "name": "clip" }, "height": { "name": "높이" }, "text": { "name": "프롬프트 텍스트" }, "width": { "name": "너비" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeSD3 = { "display_name": "CLIP 텍스트 인코딩 (SD3)", "inputs": { "clip": { "name": "clip" }, "clip_g": { "name": "clip-g 프롬프트" }, "clip_l": { "name": "clip-l 프롬프트" }, "empty_padding": { "name": "빈_패딩" }, "t5xxl": { "name": "t5xxl" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeSDXL = { "display_name": "CLIP 텍스트 인코딩 (SDXL)", "inputs": { "clip": { "name": "clip" }, "crop_h": { "name": "크롭 높이" }, "crop_w": { "name": "크롭 너비" }, "height": { "name": "높이" }, "target_height": { "name": "목표 높이" }, "target_width": { "name": "목표 너비" }, "text_g": { "name": "clip-g 프롬프트" }, "text_l": { "name": "clip-l 프롬프트" }, "width": { "name": "너비" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeSDXLRefiner = { "display_name": "CLIP 텍스트 인코딩 (SDXL Refiner)", "inputs": { "ascore": { "name": "ascore" }, "clip": { "name": "clip" }, "height": { "name": "높이" }, "text": { "name": "텍스트" }, "width": { "name": "너비" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPVisionEncode = { "display_name": "CLIP_VISION 인코딩", "inputs": { "clip_vision": { "name": "clip_vision" }, "crop": { "name": "자르기 방법" }, "image": { "name": "이미지" } } };
const CLIPVisionLoader = { "display_name": "CLIP_VISION 로드", "inputs": { "clip_name": { "name": "CLIP 파일명" } } };
const Canny = { "display_name": "Canny 경계 필터", "inputs": { "high_threshold": { "name": "높은 임계값" }, "image": { "name": "이미지" }, "low_threshold": { "name": "낮은 임계값" } }, "outputs": { "0": { "tooltip": null } } };
const CaseConverter = { "display_name": "대소문자 변환기", "inputs": { "mode": { "name": "mode" }, "string": { "name": "string" } }, "outputs": { "0": { "tooltip": null } } };
const CheckpointLoader = { "display_name": "구성으로 체크포인트 로드 (지원 중단)", "inputs": { "ckpt_name": { "name": "체크포인트 파일명" }, "config_name": { "name": "설정 이름" } } };
const CheckpointLoaderSimple = { "description": "확산 모델 체크포인트를 로드합니다. 확산 모델은 잠재 데이터의 노이즈를 제거하는 데 사용됩니다.", "display_name": "체크포인트 로드", "inputs": { "ckpt_name": { "name": "체크포인트 파일명", "tooltip": "로드할 체크포인트(모델)의 이름입니다." } }, "outputs": { "0": { "tooltip": "노이즈 제거를 위한 잠재 모델입니다." }, "1": { "tooltip": "텍스트 프롬프트를 인코딩하는 데 사용되는 CLIP 모델입니다." }, "2": { "tooltip": "이미지를 잠재 공간으로 인코딩하고 디코딩하는 데 사용되는 VAE 모델입니다." } } };
const CheckpointSave = { "display_name": "체크포인트 저장", "inputs": { "clip": { "name": "clip" }, "filename_prefix": { "name": "파일명 접두사" }, "model": { "name": "모델" }, "vae": { "name": "vae" } } };
const ChromaRadianceOptions = { "description": "Chroma Radiance 모델의 고급 옵션을 설정할 수 있습니다.", "display_name": "ChromaRadianceOptions", "inputs": { "end_sigma": { "name": "end_sigma", "tooltip": "이 옵션이 적용될 마지막 시그마 값입니다." }, "model": { "name": "model" }, "nerf_tile_size": { "name": "nerf_tile_size", "tooltip": "기본 NeRF 타일 크기를 재정의할 수 있습니다. -1은 기본값(32)을 사용함을 의미합니다. 0은 비타일링 모드를 사용함을 의미합니다(많은 VRAM이 필요할 수 있음)." }, "preserve_wrapper": { "name": "preserve_wrapper", "tooltip": "활성화하면 기존 모델 함수 래퍼가 존재할 경우 이를 위임합니다. 일반적으로 활성화된 상태로 유지해야 합니다." }, "start_sigma": { "name": "start_sigma", "tooltip": "이 옵션이 적용될 첫 번째 시그마 값입니다." } }, "outputs": { "0": { "tooltip": null } } };
const CombineHooks2 = { "display_name": "후크 결합 [2]", "inputs": { "hooks_A": { "name": "후크 A" }, "hooks_B": { "name": "후크 B" } } };
const CombineHooks4 = { "display_name": "후크 결합 [4]", "inputs": { "hooks_A": { "name": "후크 A" }, "hooks_B": { "name": "후크 B" }, "hooks_C": { "name": "후크 C" }, "hooks_D": { "name": "후크 D" } } };
const CombineHooks8 = { "display_name": "후크 결합 [8]", "inputs": { "hooks_A": { "name": "후크 A" }, "hooks_B": { "name": "후크 B" }, "hooks_C": { "name": "후크 C" }, "hooks_D": { "name": "후크 D" }, "hooks_E": { "name": "후크 E" }, "hooks_F": { "name": "후크 F" }, "hooks_G": { "name": "후크 G" }, "hooks_H": { "name": "후크 H" } } };
const ConditioningAverage = { "display_name": "조건 (평균)", "inputs": { "conditioning_from": { "name": "추가 조건" }, "conditioning_to": { "name": "대상 조건" }, "conditioning_to_strength": { "name": "대상 조건 강도" } } };
const ConditioningCombine = { "display_name": "조건 (결합)", "inputs": { "conditioning_1": { "name": "조건 1" }, "conditioning_2": { "name": "조건 2" } } };
const ConditioningConcat = { "display_name": "조건 (연결)", "inputs": { "conditioning_from": { "name": "추가 조건" }, "conditioning_to": { "name": "대상 조건" } } };
const ConditioningSetArea = { "display_name": "조건 (영역 설정)", "inputs": { "conditioning": { "name": "조건" }, "height": { "name": "높이" }, "strength": { "name": "강도" }, "width": { "name": "너비" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const ConditioningSetAreaPercentage = { "display_name": "조건 (비율로 영역 설정)", "inputs": { "conditioning": { "name": "조건" }, "height": { "name": "높이" }, "strength": { "name": "강도" }, "width": { "name": "너비" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const ConditioningSetAreaPercentageVideo = { "display_name": "비디오 조건 (비율로 영역 설정)", "inputs": { "conditioning": { "name": "조건" }, "height": { "name": "높이" }, "strength": { "name": "강도" }, "temporal": { "name": "시간" }, "width": { "name": "너비" }, "x": { "name": "x" }, "y": { "name": "y" }, "z": { "name": "z" } } };
const ConditioningSetAreaStrength = { "display_name": "조건 (영역 강도 설정)", "inputs": { "conditioning": { "name": "조건" }, "strength": { "name": "강도" } } };
const ConditioningSetDefaultCombine = { "display_name": "조건 (기본 결합 설정)", "inputs": { "cond": { "name": "조건" }, "cond_DEFAULT": { "name": "기본 조건" }, "hooks": { "name": "후크" } } };
const ConditioningSetMask = { "display_name": "조건 (마스크 설정)", "inputs": { "conditioning": { "name": "조건" }, "mask": { "name": "마스크" }, "set_cond_area": { "name": "조건 영역 설정" }, "strength": { "name": "강도" } } };
const ConditioningSetProperties = { "display_name": "조건 (속성 설정)", "inputs": { "cond_NEW": { "name": "새 조건" }, "hooks": { "name": "후크" }, "mask": { "name": "마스크" }, "set_cond_area": { "name": "조건 영역 설정" }, "strength": { "name": "강도" }, "timesteps": { "name": "타임스텝 범위" } } };
const ConditioningSetPropertiesAndCombine = { "display_name": "조건 (속성 설정 및 결합)", "inputs": { "cond": { "name": "조건" }, "cond_NEW": { "name": "새 조건" }, "hooks": { "name": "후크" }, "mask": { "name": "마스크" }, "set_cond_area": { "name": "조건 영역 설정" }, "strength": { "name": "강도" }, "timesteps": { "name": "타임스텝 범위" } } };
const ConditioningSetTimestepRange = { "display_name": "조건 (타임스텝 범위 설정)", "inputs": { "conditioning": { "name": "조건" }, "end": { "name": "끝" }, "start": { "name": "시작" } } };
const ConditioningStableAudio = { "display_name": "Stable Audio 조건 설정", "inputs": { "negative": { "name": "부정 조건" }, "positive": { "name": "긍정 조건" }, "seconds_start": { "name": "시작(초)" }, "seconds_total": { "name": "전체(초)" } }, "outputs": { "0": { "name": "긍정 조건" }, "1": { "name": "부정 조건" } } };
const ConditioningTimestepsRange = { "display_name": "조건 (타임스텝 범위)", "inputs": { "end_percent": { "name": "종료 퍼센트" }, "start_percent": { "name": "시작 퍼센트" } }, "outputs": { "1": { "name": "이전 범위" }, "2": { "name": "이후 범위" } } };
const ConditioningZeroOut = { "display_name": "조건 (0으로 출력)", "inputs": { "conditioning": { "name": "조건" } } };
const ContextWindowsManual = { "description": "컨텍스트 윈도우를 수동으로 설정합니다.", "display_name": "컨텍스트 윈도우 (수동)", "inputs": { "closed_loop": { "name": "closed_loop", "tooltip": "컨텍스트 윈도우 루프를 닫을지 여부입니다. 루프 스케줄에만 적용됩니다." }, "context_length": { "name": "context_length", "tooltip": "컨텍스트 윈도우의 길이입니다." }, "context_overlap": { "name": "context_overlap", "tooltip": "컨텍스트 윈도우의 중첩 정도입니다." }, "context_schedule": { "name": "context_schedule", "tooltip": "컨텍스트 윈도우의 스케줄입니다." }, "context_stride": { "name": "context_stride", "tooltip": "컨텍스트 윈도우의 스트라이드입니다. 균일 스케줄에만 적용됩니다." }, "dim": { "name": "dim", "tooltip": "컨텍스트 윈도우를 적용할 차원입니다." }, "fuse_method": { "name": "fuse_method", "tooltip": "컨텍스트 윈도우를 융합하는 데 사용할 방법입니다." }, "model": { "name": "model", "tooltip": "샘플링 중 컨텍스트 윈도우를 적용할 모델입니다." } }, "outputs": { "0": { "tooltip": "샘플링 중 컨텍스트 윈도우가 적용된 모델입니다." } } };
const ControlNetApply = { "display_name": "컨트롤넷 적용 (구형)", "inputs": { "conditioning": { "name": "조건" }, "control_net": { "name": "컨트롤넷" }, "image": { "name": "이미지" }, "strength": { "name": "강도" } } };
const ControlNetApplyAdvanced = { "display_name": "컨트롤넷 적용", "inputs": { "control_net": { "name": "컨트롤넷" }, "end_percent": { "name": "종료 퍼센트" }, "image": { "name": "이미지" }, "negative": { "name": "부정 조건" }, "positive": { "name": "긍정 조건" }, "start_percent": { "name": "시작 퍼센트" }, "strength": { "name": "강도" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "긍정 조건" }, "1": { "name": "부정 조건" } } };
const ControlNetApplySD3 = { "display_name": "컨트롤넷을 VAE와 함께 적용", "inputs": { "control_net": { "name": "컨트롤넷" }, "end_percent": { "name": "종료 퍼센트" }, "image": { "name": "이미지" }, "negative": { "name": "부정 조건" }, "positive": { "name": "긍정 조건" }, "start_percent": { "name": "시작 퍼센트" }, "strength": { "name": "강도" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "긍정 조건", "tooltip": null }, "1": { "name": "부정 조건", "tooltip": null } } };
const ControlNetInpaintingAliMamaApply = { "display_name": "컨트롤넷 인페인팅 AliMama 적용", "inputs": { "control_net": { "name": "컨트롤넷" }, "end_percent": { "name": "종료 퍼센트" }, "image": { "name": "이미지" }, "mask": { "name": "마스크" }, "negative": { "name": "부정 조건" }, "positive": { "name": "긍정 조건" }, "start_percent": { "name": "시작 퍼센트" }, "strength": { "name": "강도" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "긍정 조건", "tooltip": null }, "1": { "name": "부정 조건", "tooltip": null } } };
const ControlNetLoader = { "display_name": "컨트롤넷 모델 로드", "inputs": { "control_net_name": { "name": "컨트롤넷 파일명" } } };
const CosmosImageToVideoLatent = { "display_name": "Cosmos 비디오 생성 (이미지 → 비디오)", "inputs": { "batch_size": { "name": "배치 크기" }, "end_image": { "name": "끝 이미지" }, "height": { "name": "높이" }, "length": { "name": "길이" }, "start_image": { "name": "시작 이미지" }, "vae": { "name": "vae" }, "width": { "name": "너비" } }, "outputs": { "0": { "tooltip": null } } };
const CosmosPredict2ImageToVideoLatent = { "display_name": "CosmosPredict2ImageToVideoLatent", "inputs": { "batch_size": { "name": "batch_size" }, "end_image": { "name": "end_image" }, "height": { "name": "height" }, "length": { "name": "length" }, "start_image": { "name": "start_image" }, "vae": { "name": "vae" }, "width": { "name": "width" } }, "outputs": { "0": { "tooltip": null } } };
const CreateHookKeyframe = { "display_name": "후크 키프레임 생성", "inputs": { "prev_hook_kf": { "name": "이전 KF 후크" }, "start_percent": { "name": "시작 퍼센트" }, "strength_mult": { "name": "강도 곱" } }, "outputs": { "0": { "name": "KF 후크" } } };
const CreateHookKeyframesFromFloats = { "display_name": "실수로 후크 키프레임 생성", "inputs": { "end_percent": { "name": "종료 퍼센트" }, "floats_strength": { "name": "실수 강도" }, "prev_hook_kf": { "name": "이전 KF 후크" }, "print_keyframes": { "name": "키프레임 출력" }, "start_percent": { "name": "시작 퍼센트" } }, "outputs": { "0": { "name": "KF 후크" } } };
const CreateHookKeyframesInterpolated = { "display_name": "보간된 후크 키프레임 생성", "inputs": { "end_percent": { "name": "종료 퍼센트" }, "interpolation": { "name": "보간" }, "keyframes_count": { "name": "키프레임 카운트" }, "prev_hook_kf": { "name": "이전 KF 후크" }, "print_keyframes": { "name": "키프레임 출력" }, "start_percent": { "name": "시작 퍼센트" }, "strength_end": { "name": "종료 강도" }, "strength_start": { "name": "시작 강도" } }, "outputs": { "0": { "name": "KF 후크" } } };
const CreateHookLora = { "display_name": "후크 LoRA 생성", "inputs": { "lora_name": { "name": "LoRA 파일명" }, "prev_hooks": { "name": "이전 후크" }, "strength_clip": { "name": "CLIP 강도" }, "strength_model": { "name": "모델 강도" } } };
const CreateHookLoraModelOnly = { "display_name": "후크 LoRA 생성 (모델 전용)", "inputs": { "lora_name": { "name": "LoRA 파일명" }, "prev_hooks": { "name": "이전 후크" }, "strength_model": { "name": "모델 강도" } } };
const CreateHookModelAsLora = { "display_name": "후크 모델을 LoRA로 생성", "inputs": { "ckpt_name": { "name": "체크포인트 파일명" }, "prev_hooks": { "name": "이전 후크" }, "strength_clip": { "name": "CLIP 강도" }, "strength_model": { "name": "모델 강도" } } };
const CreateHookModelAsLoraModelOnly = { "display_name": "후크 모델을 LoRA로 생성 (모델 전용)", "inputs": { "ckpt_name": { "name": "체크포인트 파일명" }, "prev_hooks": { "name": "이전 후크" }, "strength_model": { "name": "모델 강도" } } };
const CreateVideo = { "description": "이미지로부터 비디오를 생성합니다.", "display_name": "비디오 생성", "inputs": { "audio": { "name": "오디오", "tooltip": "비디오에 추가할 오디오입니다." }, "fps": { "name": "fps" }, "images": { "name": "이미지", "tooltip": "비디오를 생성할 이미지입니다." } }, "outputs": { "0": { "tooltip": null } } };
const CropMask = { "display_name": "마스크 자르기", "inputs": { "height": { "name": "높이" }, "mask": { "name": "마스크" }, "width": { "name": "너비" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const DiffControlNetLoader = { "display_name": "컨트롤넷 모델 로드 (차이)", "inputs": { "control_net_name": { "name": "컨트롤넷 파일명" }, "model": { "name": "모델" } } };
const DifferentialDiffusion = { "display_name": "차등 확산", "inputs": { "model": { "name": "모델" }, "strength": { "name": "strength" } }, "outputs": { "0": { "tooltip": null } } };
const DiffusersLoader = { "display_name": "Diffusers 로드", "inputs": { "model_path": { "name": "모델 경로" } } };
const DisableNoise = { "display_name": "노이즈 비활성화" };
const DualCFGGuider = { "display_name": "이중 CFG 가이드", "inputs": { "cfg_cond2_negative": { "name": "(조건2 - 부정 조건) cfg" }, "cfg_conds": { "name": "전체 조건 cfg" }, "cond1": { "name": "조건1" }, "cond2": { "name": "조건2" }, "model": { "name": "모델" }, "negative": { "name": "부정 조건" }, "style": { "name": "style" } } };
const DualCLIPLoader = { "description": "[조합법]\n\nsdxl: clip-l, clip-g\nsd3: clip-l, clip-g / clip-l, t5 / clip-g, t5\nflux: clip-l, t5", "display_name": "이중 CLIP 로드", "inputs": { "clip_name1": { "name": "CLIP 파일명1" }, "clip_name2": { "name": "CLIP 파일명2" }, "device": { "name": "장치" }, "type": { "name": "유형" } } };
const EasyCache = { "description": "네이티브 EasyCache 구현입니다.", "display_name": "EasyCache", "inputs": { "end_percent": { "name": "end_percent", "tooltip": "EasyCache 사용을 종료할 상대 샘플링 단계입니다." }, "model": { "name": "model", "tooltip": "EasyCache를 추가할 모델입니다." }, "reuse_threshold": { "name": "reuse_threshold", "tooltip": "캐시된 단계를 재사용하기 위한 임계값입니다." }, "start_percent": { "name": "start_percent", "tooltip": "EasyCache 사용을 시작할 상대 샘플링 단계입니다." }, "verbose": { "name": "verbose", "tooltip": "상세 정보를 로깅할지 여부입니다." } }, "outputs": { "0": { "tooltip": "EasyCache가 적용된 모델입니다." } } };
const EmptyAceStepLatentAudio = { "display_name": "EmptyAceStepLatentAudio", "inputs": { "batch_size": { "name": "배치 크기", "tooltip": "배치에 포함된 잠재 이미지의 수입니다." }, "seconds": { "name": "초" } }, "outputs": { "0": { "tooltip": null } } };
const EmptyAudio = { "display_name": "빈 오디오", "inputs": { "channels": { "name": "채널", "tooltip": "오디오 채널 수 (1: 모노, 2: 스테레오)." }, "duration": { "name": "지속 시간", "tooltip": "빈 오디오 클립의 지속 시간(초 단위)" }, "sample_rate": { "name": "샘플링 레이트", "tooltip": "빈 오디오 클립의 샘플링 레이트입니다." } } };
const EmptyChromaRadianceLatentImage = { "display_name": "빈 색조 복사 잠재 이미지", "inputs": { "batch_size": { "name": "배치 크기" }, "height": { "name": "높이" }, "width": { "name": "너비" } }, "outputs": { "0": { "tooltip": null } } };
const EmptyCosmosLatentVideo = { "display_name": "빈 잠재 비디오 (Cosmos)", "inputs": { "batch_size": { "name": "배치 크기" }, "height": { "name": "높이" }, "length": { "name": "길이" }, "width": { "name": "너비" } }, "outputs": { "0": { "tooltip": null } } };
const EmptyHunyuanImageLatent = { "display_name": "빈 훈위안 이미지 잠재", "inputs": { "batch_size": { "name": "배치 크기" }, "height": { "name": "높이" }, "width": { "name": "너비" } }, "outputs": { "0": { "tooltip": null } } };
const EmptyHunyuanLatentVideo = { "display_name": "빈 잠재 비디오 (Hunyuan)", "inputs": { "batch_size": { "name": "배치 크기" }, "height": { "name": "높이" }, "length": { "name": "길이" }, "width": { "name": "너비" } }, "outputs": { "0": { "tooltip": null } } };
const EmptyImage = { "display_name": "빈 이미지", "inputs": { "batch_size": { "name": "배치 크기" }, "color": { "name": "색" }, "height": { "name": "높이" }, "width": { "name": "너비" } } };
const EmptyLTXVLatentVideo = { "display_name": "빈 잠재 비디오 (LTXV)", "inputs": { "batch_size": { "name": "배치 크기" }, "height": { "name": "높이" }, "length": { "name": "길이" }, "width": { "name": "너비" } }, "outputs": { "0": { "tooltip": null } } };
const EmptyLatentAudio = { "display_name": "빈 잠재 오디오", "inputs": { "batch_size": { "name": "배치 크기", "tooltip": "배치의 잠재 이미지 수입니다." }, "seconds": { "name": "초" } } };
const EmptyLatentHunyuan3Dv2 = { "display_name": "EmptyLatentHunyuan3Dv2", "inputs": { "batch_size": { "name": "배치 크기", "tooltip": "배치에 있는 잠재 이미지의 수입니다." }, "resolution": { "name": "해상도" } } };
const EmptyLatentImage = { "description": "샘플링을 통해 디노이즈할 빈 잠재 이미지의 새 배치를 생성합니다.", "display_name": "빈 잠재 이미지", "inputs": { "batch_size": { "name": "배치 크기", "tooltip": "배치의 잠재 이미지 수입니다." }, "height": { "name": "높이", "tooltip": "잠재 이미지의 높이(픽셀)입니다." }, "width": { "name": "너비", "tooltip": "잠재 이미지의 너비(픽셀)입니다." } }, "outputs": { "0": { "tooltip": "빈 잠재 이미지 배치입니다." } } };
const EmptyMochiLatentVideo = { "display_name": "빈 잠재 비디오 (Mochi)", "inputs": { "batch_size": { "name": "배치 크기" }, "height": { "name": "높이" }, "length": { "name": "길이" }, "width": { "name": "너비" } }, "outputs": { "0": { "tooltip": null } } };
const EmptySD3LatentImage = { "display_name": "빈 잠재 이미지 (SD3)", "inputs": { "batch_size": { "name": "배치 크기" }, "height": { "name": "높이" }, "width": { "name": "너비" } }, "outputs": { "0": { "tooltip": null } } };
const ExponentialScheduler = { "display_name": "지수 스케줄러", "inputs": { "sigma_max": { "name": "sigma_max" }, "sigma_min": { "name": "sigma_min" }, "steps": { "name": "스텝 수" } } };
const ExtendIntermediateSigmas = { "display_name": "시그마 배열 중간 구간 확장", "inputs": { "end_at_sigma": { "name": "시그마 종료점" }, "sigmas": { "name": "시그마 배열" }, "spacing": { "name": "간격 분포 방식" }, "start_at_sigma": { "name": "시그마 시작점" }, "steps": { "name": "스텝 수" } } };
const FeatherMask = { "display_name": "마스크 가장자리 흐리게", "inputs": { "bottom": { "name": "아래쪽" }, "left": { "name": "왼쪽" }, "mask": { "name": "마스크" }, "right": { "name": "오른쪽" }, "top": { "name": "위쪽" } } };
const FlipSigmas = { "display_name": "시그마 배열 뒤집기", "inputs": { "sigmas": { "name": "시그마 배열" } } };
const FluxDisableGuidance = { "description": "이 노드는 Flux 및 Flux와 유사한 모델에서 가이던스 임베드를 완전히 비활성화합니다", "display_name": "가이드 비활성화 (FLUX)", "inputs": { "conditioning": { "name": "조건" } }, "outputs": { "0": { "tooltip": null } } };
const FluxGuidance = { "display_name": "FLUX 가이드", "inputs": { "conditioning": { "name": "조건" }, "guidance": { "name": "지침" } }, "outputs": { "0": { "tooltip": null } } };
const FluxKontextImageScale = { "description": "이 노드는 이미지를 Flux Kontext에 더 최적화된 크기로 조정합니다.", "display_name": "Flux Kontext 이미지 스케일", "inputs": { "image": { "name": "이미지" } }, "outputs": { "0": { "tooltip": null } } };
const FluxKontextMaxImageNode = { "description": "프롬프트와 종횡비를 기반으로 API를 통해 Flux.1 Kontext [최대]를 사용하여 이미지를 편집합니다.", "display_name": "Flux.1 Kontext [최대] 이미지", "inputs": { "aspect_ratio": { "name": "종횡비", "tooltip": "이미지의 종횡비; 1:4에서 4:1 사이여야 합니다." }, "control_after_generate": { "name": "생성 후 제어" }, "guidance": { "name": "가이던스", "tooltip": "이미지 생성 과정의 가이던스 강도" }, "input_image": { "name": "입력 이미지" }, "prompt": { "name": "프롬프트", "tooltip": "이미지 생성용 프롬프트 - 편집할 내용과 방법을 지정합니다." }, "prompt_upsampling": { "name": "프롬프트 업샘플링", "tooltip": "프롬프트에 업샘플링을 수행할지 여부입니다. 활성화하면 자동으로 프롬프트를 수정하여 더 창의적인 생성을 수행하지만, 결과는 비결정적입니다(동일한 시드라도 정확히 같은 결과를 생성하지 않음)." }, "seed": { "name": "시드", "tooltip": "노이즈 생성에 사용되는 랜덤 시드입니다." }, "steps": { "name": "단계", "tooltip": "이미지 생성 과정의 단계 수" } }, "outputs": { "0": { "tooltip": null } } };
const FluxKontextMultiReferenceLatentMethod = { "display_name": "Flux Kontext 다중 참조 잠재 방법", "inputs": { "conditioning": { "name": "조건화" }, "reference_latents_method": { "name": "참조 잠재 방법" } }, "outputs": { "0": { "tooltip": null } } };
const FluxKontextProImageNode = { "description": "프롬프트와 종횡비를 기반으로 API를 통해 Flux.1 Kontext [프로]를 사용하여 이미지를 편집합니다.", "display_name": "Flux.1 Kontext [프로] 이미지", "inputs": { "aspect_ratio": { "name": "aspect_ratio", "tooltip": "이미지의 종횡비; 1:4에서 4:1 사이여야 합니다." }, "control_after_generate": { "name": "생성 후 제어" }, "guidance": { "name": "guidance", "tooltip": "이미지 생성 과정의 가이던스 강도" }, "input_image": { "name": "input_image" }, "prompt": { "name": "prompt", "tooltip": "이미지 생성을 위한 프롬프트 - 무엇을 어떻게 편집할지 지정합니다." }, "prompt_upsampling": { "name": "prompt_upsampling", "tooltip": "프롬프트에 업샘플링을 수행할지 여부. 활성화하면 더 창의적인 생성을 위해 프롬프트를 자동으로 수정하지만, 결과는 비결정적입니다(동일한 시드라도 정확히 같은 결과를 생성하지 않음)." }, "seed": { "name": "seed", "tooltip": "노이즈 생성에 사용되는 랜덤 시드" }, "steps": { "name": "steps", "tooltip": "이미지 생성 과정의 단계 수" } }, "outputs": { "0": { "tooltip": null } } };
const FluxProExpandNode = { "description": "프롬프트를 기반으로 이미지의 바깥 영역을 확장합니다.", "display_name": "Flux.1 이미지 확장", "inputs": { "bottom": { "name": "하단", "tooltip": "이미지 하단에 확장할 픽셀 수" }, "control_after_generate": { "name": "생성 후 제어" }, "guidance": { "name": "가이던스", "tooltip": "이미지 생성 과정의 가이던스 강도" }, "image": { "name": "이미지" }, "left": { "name": "좌측", "tooltip": "이미지 좌측에 확장할 픽셀 수" }, "prompt": { "name": "프롬프트", "tooltip": "이미지 생성을 위한 프롬프트" }, "prompt_upsampling": { "name": "프롬프트 업샘플링", "tooltip": "프롬프트에 업샘플링을 수행할지 여부입니다. 활성화 시, 더 창의적인 생성을 위해 프롬프트가 자동으로 수정되지만 결과는 비결정적입니다(같은 시드라도 정확히 같은 결과가 나오지 않습니다)." }, "right": { "name": "우측", "tooltip": "이미지 우측에 확장할 픽셀 수" }, "seed": { "name": "시드", "tooltip": "노이즈 생성을 위해 사용되는 랜덤 시드입니다." }, "steps": { "name": "스텝 수", "tooltip": "이미지 생성 과정의 스텝 수" }, "top": { "name": "상단", "tooltip": "이미지 상단에 확장할 픽셀 수" } }, "outputs": { "0": { "tooltip": null } } };
const FluxProFillNode = { "description": "마스크와 프롬프트를 기반으로 이미지를 인페인팅합니다.", "display_name": "Flux.1 이미지 채우기", "inputs": { "control_after_generate": { "name": "생성 후 제어" }, "guidance": { "name": "가이던스", "tooltip": "이미지 생성 과정의 가이던스 강도" }, "image": { "name": "이미지" }, "mask": { "name": "마스크" }, "prompt": { "name": "프롬프트", "tooltip": "이미지 생성을 위한 프롬프트" }, "prompt_upsampling": { "name": "프롬프트 업샘플링", "tooltip": "프롬프트에 업샘플링을 수행할지 여부입니다. 활성화 시, 더 창의적인 생성을 위해 프롬프트가 자동으로 수정되지만 결과는 비결정적입니다(같은 시드라도 정확히 같은 결과가 나오지 않습니다)." }, "seed": { "name": "시드", "tooltip": "노이즈 생성을 위해 사용되는 랜덤 시드입니다." }, "steps": { "name": "스텝 수", "tooltip": "이미지 생성 과정의 스텝 수" } }, "outputs": { "0": { "tooltip": null } } };
const FluxProUltraImageNode = { "description": "프롬프트와 해상도를 기반으로 api를 통해 Flux Pro 1.1 Ultra로 이미지를 생성합니다.", "display_name": "Flux 1.1 [pro] Ultra 이미지", "inputs": { "aspect_ratio": { "name": "종횡비", "tooltip": "이미지의 종횡비; 1:4에서 4:1 사이여야 합니다." }, "control_after_generate": { "name": "생성 후 제어" }, "image_prompt": { "name": "이미지 프롬프트" }, "image_prompt_strength": { "name": "이미지 프롬프트 강도", "tooltip": "프롬프트와 이미지 프롬프트 간의 혼합 비율입니다." }, "prompt": { "name": "프롬프트", "tooltip": "이미지 생성을 위한 프롬프트" }, "prompt_upsampling": { "name": "프롬프트 업샘플링", "tooltip": "프롬프트에 업샘플링을 수행할지 여부입니다. 활성화하면 프롬프트가 자동으로 더 창의적으로 수정되지만, 결과는 비결정적입니다(같은 시드라도 정확히 같은 결과가 나오지 않습니다)." }, "raw": { "name": "원본", "tooltip": "True로 설정하면 덜 가공되고 더 자연스러운 이미지를 생성합니다." }, "seed": { "name": "시드", "tooltip": "노이즈 생성을 위한 랜덤 시드입니다." } }, "outputs": { "0": { "tooltip": null } } };
const FreSca = { "description": "주파수에 따라 가이던스에 스케일을 적용합니다", "display_name": "FreSca", "inputs": { "freq_cutoff": { "name": "주파수 컷오프", "tooltip": "저주파수로 간주할 중심 주위의 주파수 인덱스 개수" }, "model": { "name": "모델" }, "scale_high": { "name": "고주파 스케일", "tooltip": "고주파수 성분에 대한 스케일 계수" }, "scale_low": { "name": "저주파 스케일", "tooltip": "저주파수 성분에 대한 스케일 계수" } }, "outputs": { "0": { "tooltip": null } } };
const FreeU = { "display_name": "FreeU", "inputs": { "b1": { "name": "b1" }, "b2": { "name": "b2" }, "model": { "name": "모델" }, "s1": { "name": "s1" }, "s2": { "name": "s2" } } };
const FreeU_V2 = { "display_name": "FreeU V2", "inputs": { "b1": { "name": "b1" }, "b2": { "name": "b2" }, "model": { "name": "모델" }, "s1": { "name": "s1" }, "s2": { "name": "s2" } } };
const GITSScheduler = { "display_name": "GITS 스케줄러", "inputs": { "coeff": { "name": "계수" }, "denoise": { "name": "노이즈 제거양" }, "steps": { "name": "스텝 수" } }, "outputs": { "0": { "tooltip": null } } };
const GLIGENLoader = { "display_name": "GLIGEN 로드", "inputs": { "gligen_name": { "name": "gligen 파일명" } } };
const GLIGENTextBoxApply = { "display_name": "GLIGEN 텍스트 박스 적용", "inputs": { "clip": { "name": "clip" }, "conditioning_to": { "name": "조건 대상" }, "gligen_textbox_model": { "name": "gligen 텍스트상자 모델" }, "height": { "name": "높이" }, "text": { "name": "텍스트" }, "width": { "name": "너비" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const GeminiImageNode = { "description": "Google API를 통해 이미지를 동기적으로 편집합니다.", "display_name": "Google Gemini 이미지", "inputs": { "aspect_ratio": { "name": "aspect_ratio", "tooltip": "기본적으로 출력 이미지 크기를 입력 이미지 크기에 맞추거나, 그렇지 않으면 1:1 정사각형을 생성합니다." }, "control_after_generate": { "name": "control after generate" }, "files": { "name": "files", "tooltip": "모델의 컨텍스트로 사용할 선택적 파일. Gemini Generate Content Input Files 노드의 입력을 허용합니다." }, "images": { "name": "images", "tooltip": "모델의 컨텍스트로 사용할 선택적 이미지. 여러 이미지를 포함하려면 Batch Images 노드를 사용할 수 있습니다." }, "model": { "name": "model", "tooltip": "응답 생성에 사용할 Gemini 모델" }, "prompt": { "name": "prompt", "tooltip": "생성을 위한 텍스트 프롬프트" }, "seed": { "name": "seed", "tooltip": "시드가 특정 값으로 고정되면, 모델은 반복 요청에 대해 동일한 응답을 제공하기 위해 최선을 다합니다. 결정론적 출력은 보장되지 않습니다. 또한 모델이나 온도와 같은 매개변수 설정을 변경하면 동일한 시드 값을 사용하더라도 응답에 변동이 발생할 수 있습니다. 기본적으로 랜덤 시드 값이 사용됩니다." } }, "outputs": { "0": { "tooltip": null }, "1": { "tooltip": null } } };
const GeminiInputFiles = { "description": "Gemini LLM 노드의 입력으로 포함할 입력 파일을 로드하고 준비합니다. 파일은 응답을 생성할 때 Gemini 모델에 의해 읽힙니다. 텍스트 파일의 내용은 토큰 제한에 포함됩니다. 🛈 팁: 다른 Gemini 입력 파일 노드와 함께 연결하여 사용할 수 있습니다.", "display_name": "Gemini 입력 파일", "inputs": { "GEMINI_INPUT_FILES": { "name": "GEMINI_INPUT_FILES", "tooltip": "이 노드에서 로드된 파일과 함께 배치할 선택적 추가 파일. 단일 메시지에 여러 입력 파일을 포함할 수 있도록 입력 파일을 연결할 수 있습니다." }, "file": { "name": "file", "tooltip": "모델의 컨텍스트로 포함할 입력 파일. 현재는 텍스트(.txt) 및 PDF(.pdf) 파일만 허용됩니다." } }, "outputs": { "0": { "tooltip": null } } };
const GeminiNode = { "description": "Google의 Gemini AI 모델로 텍스트 응답을 생성합니다. 더 관련성 있고 의미 있는 응답을 생성하기 위해 컨텍스트로 여러 유형의 입력(텍스트, 이미지, 오디오, 비디오)을 제공할 수 있습니다.", "display_name": "Google Gemini", "inputs": { "audio": { "name": "오디오", "tooltip": "모델의 컨텍스트로 사용할 선택적 오디오입니다." }, "control_after_generate": { "name": "생성 후 제어" }, "files": { "name": "파일", "tooltip": "모델의 컨텍스트로 사용할 선택적 파일입니다. Gemini Generate Content Input Files 노드의 입력을 허용합니다." }, "images": { "name": "images", "tooltip": "모델의 컨텍스트로 사용할 선택적 이미지. 여러 이미지를 포함하려면 Batch Images 노드를 사용할 수 있습니다." }, "model": { "name": "model", "tooltip": "응답 생성에 사용할 Gemini 모델" }, "prompt": { "name": "prompt", "tooltip": "모델에 대한 텍스트 입력으로, 응답 생성에 사용됩니다. 모델에 대한 상세한 지침, 질문 또는 컨텍스트를 포함할 수 있습니다." }, "seed": { "name": "seed", "tooltip": "시드가 특정 값으로 고정되면, 모델은 반복 요청에 대해 동일한 응답을 제공하기 위해 최선을 다합니다. 결정론적 출력은 보장되지 않습니다. 또한 모델이나 온도와 같은 매개변수 설정을 변경하면 동일한 시드 값을 사용하더라도 응답에 변동이 발생할 수 있습니다. 기본적으로 랜덤 시드 값이 사용됩니다." }, "video": { "name": "비디오", "tooltip": "모델의 컨텍스트로 사용할 선택적 비디오입니다." } }, "outputs": { "0": { "tooltip": null } } };
const GetImageSize = { "description": "이미지의 너비와 높이를 반환하고 변경 없이 전달합니다.", "display_name": "이미지 크기 가져오기", "inputs": { "image": { "name": "이미지" } }, "outputs": { "0": { "name": "너비" }, "1": { "name": "높이" }, "2": { "name": "배치 크기" } } };
const GetVideoComponents = { "description": "비디오에서 모든 컴포넌트(프레임, 오디오, 프레임레이트)를 추출합니다.", "display_name": "비디오 컴포넌트 추출", "inputs": { "video": { "name": "비디오", "tooltip": "컴포넌트를 추출할 비디오입니다." } }, "outputs": { "0": { "name": "이미지", "tooltip": null }, "1": { "name": "오디오", "tooltip": null }, "2": { "name": "fps", "tooltip": null } } };
const GrowMask = { "display_name": "마스크 확장", "inputs": { "expand": { "name": "확장" }, "mask": { "name": "마스크" }, "tapered_corners": { "name": "마름모 모서리" } } };
const Hunyuan3Dv2Conditioning = { "display_name": "Hunyuan3Dv2Conditioning", "inputs": { "clip_vision_output": { "name": "clip_vision_output" } }, "outputs": { "0": { "name": "긍정 조건" }, "1": { "name": "부정 조건" } } };
const Hunyuan3Dv2ConditioningMultiView = { "display_name": "Hunyuan3Dv2ConditioningMultiView", "inputs": { "back": { "name": "뒤" }, "front": { "name": "앞" }, "left": { "name": "왼쪽" }, "right": { "name": "오른쪽" } }, "outputs": { "0": { "name": "긍정 조건" }, "1": { "name": "부정 조건" } } };
const HunyuanImageToVideo = { "display_name": "HunyuanImageToVideo", "inputs": { "batch_size": { "name": "배치 크기" }, "guidance_type": { "name": "가이던스 유형" }, "height": { "name": "높이" }, "length": { "name": "길이" }, "positive": { "name": "긍정 조건" }, "start_image": { "name": "시작 이미지" }, "vae": { "name": "vae" }, "width": { "name": "너비" } }, "outputs": { "0": { "name": "긍정 조건", "tooltip": null }, "1": { "name": "잠재 비디오", "tooltip": null } } };
const HunyuanRefinerLatent = { "display_name": "HunyuanRefinerLatent", "inputs": { "latent": { "name": "잠재" }, "negative": { "name": "부정적" }, "noise_augmentation": { "name": "노이즈 증강" }, "positive": { "name": "긍정적" } }, "outputs": { "0": { "name": "긍정적", "tooltip": null }, "1": { "name": "부정적", "tooltip": null }, "2": { "name": "잠재", "tooltip": null } } };
const HyperTile = { "display_name": "하이퍼 타일", "inputs": { "max_depth": { "name": "최대 깊이" }, "model": { "name": "모델" }, "scale_depth": { "name": "스케일 깊이" }, "swap_size": { "name": "스왑 크기" }, "tile_size": { "name": "타일 크기" } }, "outputs": { "0": { "tooltip": null } } };
const HypernetworkLoader = { "display_name": "하이퍼네트워크 로드", "inputs": { "hypernetwork_name": { "name": "하이퍼네트워크 이름" }, "model": { "name": "모델" }, "strength": { "name": "강도" } }, "outputs": { "0": { "tooltip": null } } };
const IdeogramV1 = { "description": "Ideogram V1 모델을 사용하여 동기적으로 이미지를 생성합니다.\n\n이미지 링크는 제한된 기간 동안만 제공되며, 이미지를 보관하려면 반드시 다운로드해야 합니다.", "display_name": "Ideogram V1", "inputs": { "aspect_ratio": { "name": "종횡비", "tooltip": "이미지 생성에 사용할 종횡비" }, "control_after_generate": { "name": "생성 후 제어" }, "magic_prompt_option": { "name": "매직 프롬프트 옵션", "tooltip": "생성 시 MagicPrompt 사용 여부 결정" }, "negative_prompt": { "name": "부정 프롬프트", "tooltip": "이미지에서 제외할 내용을 설명" }, "num_images": { "name": "이미지 수" }, "prompt": { "name": "프롬프트", "tooltip": "이미지 생성을 위한 프롬프트" }, "seed": { "name": "시드" }, "turbo": { "name": "터보", "tooltip": "터보 모드 사용 여부 (더 빠른 생성, 품질 저하 가능성 있음)" } }, "outputs": { "0": { "tooltip": null } } };
const IdeogramV2 = { "description": "Ideogram V2 모델을 사용하여 동기적으로 이미지를 생성합니다.\n\n이미지 링크는 일정 기간 동안만 제공되며, 이미지를 보관하려면 반드시 다운로드해야 합니다.", "display_name": "Ideogram V2", "inputs": { "aspect_ratio": { "name": "종횡비", "tooltip": "이미지 생성에 사용할 종횡비. 해상도가 AUTO로 설정되지 않은 경우 무시됩니다." }, "control_after_generate": { "name": "생성 후 제어" }, "magic_prompt_option": { "name": "매직 프롬프트 옵션", "tooltip": "생성 시 MagicPrompt 사용 여부 결정" }, "negative_prompt": { "name": "부정 프롬프트", "tooltip": "이미지에서 제외할 내용을 설명" }, "num_images": { "name": "이미지 수" }, "prompt": { "name": "프롬프트", "tooltip": "이미지 생성을 위한 프롬프트" }, "resolution": { "name": "해상도", "tooltip": "이미지 생성에 사용할 해상도. AUTO로 설정되지 않은 경우, aspect_ratio 설정을 덮어씁니다." }, "seed": { "name": "시드" }, "style_type": { "name": "스타일 타입", "tooltip": "생성에 사용할 스타일 타입 (V2 전용)" }, "turbo": { "name": "터보", "tooltip": "터보 모드 사용 여부 (더 빠른 생성, 품질 저하 가능성 있음)" } }, "outputs": { "0": { "tooltip": null } } };
const IdeogramV3 = { "description": "Ideogram V3 모델을 사용하여 동기적으로 이미지를 생성합니다.\n\n텍스트 프롬프트를 통한 일반 이미지 생성과 mask를 사용한 이미지 편집을 모두 지원합니다.\n이미지 링크는 제한된 기간 동안만 제공되며, 이미지를 보관하려면 반드시 다운로드해야 합니다.", "display_name": "Ideogram V3", "inputs": { "aspect_ratio": { "name": "종횡비", "tooltip": "이미지 생성을 위한 종횡비입니다. 해상도가 자동이 아닐 경우 무시됩니다." }, "character_image": { "name": "캐릭터 이미지", "tooltip": "캐릭터 참조로 사용할 이미지입니다." }, "character_mask": { "name": "캐릭터 마스크", "tooltip": "캐릭터 참조 이미지에 대한 선택적 마스크입니다." }, "control_after_generate": { "name": "생성 후 제어" }, "image": { "name": "이미지", "tooltip": "이미지 편집을 위한 선택적 참조 이미지입니다." }, "magic_prompt_option": { "name": "매직 프롬프트 옵션", "tooltip": "생성 시 MagicPrompt 사용 여부를 결정합니다" }, "mask": { "name": "마스크", "tooltip": "인페인팅을 위한 선택적 마스크 (흰색 영역이 대체됩니다)" }, "num_images": { "name": "이미지 수" }, "prompt": { "name": "프롬프트", "tooltip": "이미지 생성 또는 편집을 위한 프롬프트" }, "rendering_speed": { "name": "렌더링 속도", "tooltip": "생성 속도와 품질 간의 균형을 조절합니다" }, "resolution": { "name": "해상도", "tooltip": "이미지 생성을 위한 해상도입니다. 자동이 아닐 경우 종횡비 설정을 덮어씁니다." }, "seed": { "name": "시드" } }, "outputs": { "0": { "tooltip": null } } };
const ImageAddNoise = { "display_name": "이미지에 노이즈 추가", "inputs": { "control_after_generate": { "name": "생성 후 제어" }, "image": { "name": "이미지" }, "seed": { "name": "시드", "tooltip": "노이즈 생성에 사용되는 랜덤 시드입니다." }, "strength": { "name": "강도" } } };
const ImageBatch = { "display_name": "이미지 배치", "inputs": { "image1": { "name": "이미지1" }, "image2": { "name": "이미지2" } } };
const ImageBlend = { "display_name": "이미지 혼합", "inputs": { "blend_factor": { "name": "혼합 계수" }, "blend_mode": { "name": "혼합 모드" }, "image1": { "name": "이미지1" }, "image2": { "name": "이미지2" } }, "outputs": { "0": { "tooltip": null } } };
const ImageBlur = { "display_name": "이미지 흐림", "inputs": { "blur_radius": { "name": "블러 반경" }, "image": { "name": "이미지" }, "sigma": { "name": "시그마" } }, "outputs": { "0": { "tooltip": null } } };
const ImageColorToMask = { "display_name": "이미지 색상을 마스크로 변환", "inputs": { "color": { "name": "색상" }, "image": { "name": "이미지" } } };
const ImageCompositeMasked = { "display_name": "마스크된 이미지 합성", "inputs": { "destination": { "name": "대상" }, "mask": { "name": "마스크" }, "resize_source": { "name": "원본 크기 조정" }, "source": { "name": "원본" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const ImageCrop = { "display_name": "이미지 자르기", "inputs": { "height": { "name": "높이" }, "image": { "name": "이미지" }, "width": { "name": "너비" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const ImageFlip = { "display_name": "이미지 뒤집기", "inputs": { "flip_method": { "name": "뒤집기 방법" }, "image": { "name": "이미지" } } };
const ImageFromBatch = { "display_name": "배치에서 이미지 가져오기", "inputs": { "batch_index": { "name": "배치 번호" }, "image": { "name": "이미지" }, "length": { "name": "길이" } } };
const ImageInvert = { "display_name": "이미지 반전", "inputs": { "image": { "name": "이미지" } } };
const ImageOnlyCheckpointLoader = { "display_name": "이미지 전용 체크포인트 로드 (img2vid 모델)", "inputs": { "ckpt_name": { "name": "체크포인트 파일명" } } };
const ImageOnlyCheckpointSave = { "display_name": "이미지 전용 체크포인트 저장", "inputs": { "clip_vision": { "name": "clip_vision" }, "filename_prefix": { "name": "파일명 접두사" }, "model": { "name": "모델" }, "vae": { "name": "vae" } } };
const ImagePadForOutpaint = { "display_name": "아웃페인팅을 위한 이미지 패딩", "inputs": { "bottom": { "name": "아래" }, "feathering": { "name": "가장자리 흐림" }, "image": { "name": "이미지" }, "left": { "name": "왼쪽" }, "right": { "name": "오른쪽" }, "top": { "name": "위" } } };
const ImageQuantize = { "display_name": "이미지 양자화", "inputs": { "colors": { "name": "색상" }, "dither": { "name": "디더링" }, "image": { "name": "이미지" } }, "outputs": { "0": { "tooltip": null } } };
const ImageRGBToYUV = { "display_name": "ImageRGBToYUV", "inputs": { "image": { "name": "이미지" } }, "outputs": { "0": { "name": "Y", "tooltip": null }, "1": { "name": "U", "tooltip": null }, "2": { "name": "V", "tooltip": null } } };
const ImageRotate = { "display_name": "이미지 회전", "inputs": { "image": { "name": "이미지" }, "rotation": { "name": "회전" } } };
const ImageScale = { "display_name": "이미지 확대", "inputs": { "crop": { "name": "자르기" }, "height": { "name": "높이" }, "image": { "name": "이미지" }, "upscale_method": { "name": "확대 방법" }, "width": { "name": "너비" } } };
const ImageScaleBy = { "display_name": "이미지 확대 비율", "inputs": { "image": { "name": "이미지" }, "scale_by": { "name": "배율" }, "upscale_method": { "name": "확대 방법" } } };
const ImageScaleToMaxDimension = { "display_name": "이미지를 최대 크기로 확대", "inputs": { "image": { "name": "이미지" }, "largest_size": { "name": "최대 크기" }, "upscale_method": { "name": "업스케일 방법" } } };
const ImageScaleToTotalPixels = { "display_name": "총 픽셀 수에 맞춰 이미지 크기 조정", "inputs": { "image": { "name": "이미지" }, "megapixels": { "name": "메가픽셀수" }, "upscale_method": { "name": "확대 방법" } }, "outputs": { "0": { "tooltip": null } } };
const ImageSharpen = { "display_name": "이미지 선명화", "inputs": { "alpha": { "name": "알파" }, "image": { "name": "이미지" }, "sharpen_radius": { "name": "선명화 반경" }, "sigma": { "name": "시그마" } }, "outputs": { "0": { "tooltip": null } } };
const ImageStitch = { "description": "\n지정된 방향으로 image2를 image1에 스티치합니다.\nimage2가 제공되지 않으면 image1을 변경 없이 반환합니다.\n이미지 사이에 선택적 간격을 추가할 수 있습니다.\n", "display_name": "이미지 스티치", "inputs": { "direction": { "name": "방향" }, "image1": { "name": "이미지1" }, "image2": { "name": "이미지2" }, "match_image_size": { "name": "이미지 크기 맞추기" }, "spacing_color": { "name": "간격 색상" }, "spacing_width": { "name": "간격 너비" } } };
const ImageToMask = { "display_name": "이미지를 마스크로 변환", "inputs": { "channel": { "name": "채널" }, "image": { "name": "이미지" } } };
const ImageUpscaleWithModel = { "display_name": "모델을 사용한 이미지 확대", "inputs": { "image": { "name": "이미지" }, "upscale_model": { "name": "확대 모델" } }, "outputs": { "0": { "tooltip": null } } };
const ImageYUVToRGB = { "display_name": "ImageYUVToRGB", "inputs": { "U": { "name": "U" }, "V": { "name": "V" }, "Y": { "name": "Y" } }, "outputs": { "0": { "tooltip": null } } };
const InpaintModelConditioning = { "display_name": "인페인팅 모델 조건 설정", "inputs": { "mask": { "name": "마스크" }, "negative": { "name": "부정 조건" }, "noise_mask": { "name": "노이즈 마스크", "tooltip": "잠재 데이터에 노이즈 마스크를 추가하여 샘플링이 마스크 내에서만 발생하도록 합니다. 모델에 따라 결과가 개선되거나 완전히 망가질 수 있습니다." }, "pixels": { "name": "픽셀 이미지" }, "positive": { "name": "긍정 조건" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "긍정 조건" }, "1": { "name": "부정 조건" }, "2": { "name": "잠재 데이터" } } };
const InstructPixToPixConditioning = { "display_name": "InstructPixToPix 조건 설정", "inputs": { "negative": { "name": "부정 조건" }, "pixels": { "name": "픽셀" }, "positive": { "name": "긍정 조건" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "긍정 조건", "tooltip": null }, "1": { "name": "부정 조건", "tooltip": null }, "2": { "name": "잠재 이미지", "tooltip": null } } };
const InvertMask = { "display_name": "마스크 반전", "inputs": { "mask": { "name": "마스크" } } };
const JoinImageWithAlpha = { "display_name": "알파와 함께 이미지 결합", "inputs": { "alpha": { "name": "알파" }, "image": { "name": "이미지" } }, "outputs": { "0": { "tooltip": null } } };
const KSampler = { "description": "제공된 모델, 긍정 및 부정 조건을 사용하여 잠재 데이터를 디노이즈합니다.", "display_name": "KSampler", "inputs": { "cfg": { "name": "cfg", "tooltip": "Classifier-Free Guidance 스케일은 창의성과 프롬프트 준수를 균형 있게 조절합니다. 값이 높을수록 프롬프트와 더 밀접하게 일치하는 이미지가 생성되지만, 너무 높은 값은 품질에 부정적인 영향을 미칠 수 있습니다." }, "control_after_generate": { "name": "생성 후 제어" }, "denoise": { "name": "노이즈 제거양", "tooltip": "적용되는 노이즈 제거의 양으로, 낮은 값은 초기 이미지의 구조를 유지하여 이미지 간 샘플링을 가능하게 합니다." }, "latent_image": { "name": "잠재 데이터", "tooltip": "노이즈 제거할 잠재 데이터입니다." }, "model": { "name": "모델", "tooltip": "입력 잠재 데이터의 노이즈 제거에 사용되는 모델입니다." }, "negative": { "name": "부정 조건", "tooltip": "이미지에서 제외하고 싶은 속성을 설명하는 조건입니다." }, "positive": { "name": "긍정 조건", "tooltip": "이미지에 포함하고 싶은 속성을 설명하는 조건입니다." }, "sampler_name": { "name": "샘플러 이름", "tooltip": "샘플링 시 사용되는 알고리즘으로, 생성된 출력의 품질, 속도 및 스타일에 영향을 미칠 수 있습니다." }, "scheduler": { "name": "스케줄러", "tooltip": "스케줄러는 노이즈가 점진적으로 제거되어 이미지를 형성하는 방식을 제어합니다." }, "seed": { "name": "시드", "tooltip": "노이즈 생성을 위한 랜덤 시드입니다." }, "steps": { "name": "스텝 수", "tooltip": "노이즈 제거 과정에서 사용되는 단계 수입니다." } }, "outputs": { "0": { "tooltip": "노이즈가 제거된 잠재 데이터입니다." } } };
const KSamplerAdvanced = { "display_name": "고급 KSampler", "inputs": { "add_noise": { "name": "노이즈 추가" }, "cfg": { "name": "cfg" }, "control_after_generate": { "name": "생성 후 제어" }, "end_at_step": { "name": "종료 스텝" }, "latent_image": { "name": "잠재 데이터" }, "model": { "name": "모델" }, "negative": { "name": "부정 조건" }, "noise_seed": { "name": "노이즈 시드" }, "positive": { "name": "긍정 조건" }, "return_with_leftover_noise": { "name": "잔여 노이즈 반환" }, "sampler_name": { "name": "샘플러 이름" }, "scheduler": { "name": "스케줄러" }, "start_at_step": { "name": "시작 스텝" }, "steps": { "name": "스텝 수" } } };
const KSamplerSelect = { "display_name": "KSampler (선택)", "inputs": { "sampler_name": { "name": "샘플러 이름" } } };
const KarrasScheduler = { "display_name": "Karras 스케줄러", "inputs": { "rho": { "name": "rho" }, "sigma_max": { "name": "최대 시그마" }, "sigma_min": { "name": "최소 시그마" }, "steps": { "name": "스텝 수" } } };
const KlingCameraControlI2VNode = { "description": "정지 이미지를 실제 영화 촬영과 유사한 전문적인 카메라 움직임으로 시네마틱 비디오로 변환합니다. 원본 이미지에 초점을 유지하면서 줌, 회전, 패닝, 틸트, 1인칭 시점 등 가상 카메라 동작을 제어할 수 있습니다.", "display_name": "Kling 이미지 투 비디오 (카메라 컨트롤)", "inputs": { "aspect_ratio": { "name": "종횡비" }, "camera_control": { "name": "카메라 제어", "tooltip": "Kling Camera Controls 노드를 사용하여 생성할 수 있습니다. 비디오 생성 중 카메라의 움직임과 모션을 제어합니다." }, "cfg_scale": { "name": "cfg 스케일" }, "negative_prompt": { "name": "부정 프롬프트", "tooltip": "비디오에서 제외할 내용을 설명" }, "prompt": { "name": "프롬프트", "tooltip": "비디오 생성을 위한 프롬프트" }, "start_frame": { "name": "start_frame", "tooltip": "참조 이미지 - URL 또는 Base64 인코딩 문자열, 10MB를 초과할 수 없으며, 해상도는 최소 300*300px, 가로세로 비율은 1:2.5 ~ 2.5:1 사이여야 합니다. Base64는 data:image 접두사를 포함하지 않아야 합니다." } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "비디오 ID", "tooltip": null }, "2": { "name": "길이", "tooltip": null } } };
const KlingCameraControlT2VNode = { "description": "텍스트를 실제 영화 촬영과 유사한 전문적인 카메라 움직임이 적용된 시네마틱 비디오로 변환합니다. 원본 텍스트에 초점을 유지하면서 줌, 회전, 팬, 틸트, 1인칭 시점 등 가상 카메라 동작을 제어할 수 있습니다.", "display_name": "Kling 텍스트 투 비디오 (카메라 컨트롤)", "inputs": { "aspect_ratio": { "name": "종횡비" }, "camera_control": { "name": "카메라 제어", "tooltip": "Kling 카메라 컨트롤 노드를 사용하여 생성할 수 있습니다. 비디오 생성 중 카메라의 움직임과 모션을 제어합니다." }, "cfg_scale": { "name": "cfg 스케일" }, "negative_prompt": { "name": "부정 프롬프트", "tooltip": "비디오에서 제외할 내용을 설명" }, "prompt": { "name": "프롬프트", "tooltip": "비디오 생성을 위한 프롬프트" } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "비디오 ID", "tooltip": null }, "2": { "name": "길이", "tooltip": null } } };
const KlingCameraControls = { "description": "Kling 카메라 컨트롤 및 모션 제어 효과를 위한 구성 옵션을 지정할 수 있습니다.", "display_name": "Kling 카메라 컨트롤", "inputs": { "camera_control_type": { "name": "카메라 제어 종류" }, "horizontal_movement": { "name": "수평 이동", "tooltip": "카메라의 수평 축(x축) 이동을 제어합니다. 음수는 왼쪽, 양수는 오른쪽을 의미합니다." }, "pan": { "name": "수평 회전", "tooltip": "카메라의 수직 평면(x축) 회전을 제어합니다. 음수는 아래쪽 회전, 양수는 위쪽 회전을 의미합니다." }, "roll": { "name": "축 회전", "tooltip": "카메라의 롤링(z축) 정도를 제어합니다. 음수는 반시계 방향, 양수는 시계 방향을 의미합니다." }, "tilt": { "name": "상하 회전", "tooltip": "카메라의 수평 평면(y축) 회전을 제어합니다. 음수는 왼쪽 회전, 양수는 오른쪽 회전을 의미합니다." }, "vertical_movement": { "name": "수직 이동", "tooltip": "카메라의 수직 축(y축) 이동을 제어합니다. 음수는 아래쪽, 양수는 위쪽을 의미합니다." }, "zoom": { "name": "확대/축소", "tooltip": "카메라의 초점 거리 변화를 제어합니다. 음수는 좁은 시야각, 양수는 넓은 시야각을 의미합니다." } }, "outputs": { "0": { "name": "카메라 제어", "tooltip": null } } };
const KlingDualCharacterVideoEffectNode = { "description": "'효과 장면'에 따라 비디오를 생성할 때 다양한 특수 효과를 적용합니다. 첫 번째 이미지는 합성의 왼쪽에, 두 번째 이미지는 오른쪽에 배치됩니다.", "display_name": "Kling 듀얼 캐릭터 비디오 효과", "inputs": { "duration": { "name": "길이" }, "effect_scene": { "name": "효과 장면" }, "image_left": { "name": "왼쪽 이미지", "tooltip": "왼쪽 이미지" }, "image_right": { "name": "오른쪽 이미지", "tooltip": "오른쪽 이미지" }, "mode": { "name": "모드" }, "model_name": { "name": "모델명" } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "길이", "tooltip": null } } };
const KlingImage2VideoNode = { "display_name": "Kling 비디오 생성 (이미지 → 비디오)", "inputs": { "aspect_ratio": { "name": "종횡비" }, "cfg_scale": { "name": "cfg 스케일" }, "duration": { "name": "길이" }, "mode": { "name": "모드" }, "model_name": { "name": "모델명" }, "negative_prompt": { "name": "부정 프롬프트", "tooltip": "비디오에서 제외할 내용을 설명" }, "prompt": { "name": "프롬프트", "tooltip": "비디오 생성을 위한 프롬프트" }, "start_frame": { "name": "start_frame", "tooltip": "참조 이미지 - URL 또는 Base64 인코딩 문자열, 10MB를 초과할 수 없으며, 해상도는 최소 300*300px, 가로세로 비율은 1:2.5 ~ 2.5:1 사이여야 합니다. Base64에는 data:image 접두사가 포함되지 않아야 합니다." } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "비디오 ID", "tooltip": null }, "2": { "name": "길이", "tooltip": null } } };
const KlingImageGenerationNode = { "description": "Kling 이미지 생성 노드. 텍스트 프롬프트와 선택적 참조 이미지를 사용하여 이미지를 생성합니다.", "display_name": "Kling 이미지 생성 (텍스트 → 이미지)", "inputs": { "aspect_ratio": { "name": "종횡비" }, "human_fidelity": { "name": "사람 충실도", "tooltip": "피사체 참조 유사도" }, "image": { "name": "이미지" }, "image_fidelity": { "name": "이미지 충실도", "tooltip": "사용자 업로드 이미지의 참조 강도" }, "image_type": { "name": "이미지 종류" }, "model_name": { "name": "모델 명" }, "n": { "name": "개수", "tooltip": "생성할 이미지 수" }, "negative_prompt": { "name": "부정 프롬프트", "tooltip": "이미지에서 제외할 내용을 설명" }, "prompt": { "name": "프롬프트", "tooltip": "이미지 생성을 위한 프롬프트" } }, "outputs": { "0": { "tooltip": null } } };
const KlingLipSyncAudioToVideoNode = { "description": "Kling 립싱크 오디오 투 비디오 노드. 비디오 파일의 입 모양 움직임을 오디오 파일의 오디오 내용에 맞게 동기화합니다.", "display_name": "Kling 립싱크 비디오 오디오와 함께", "inputs": { "audio": { "name": "오디오" }, "video": { "name": "비디오" }, "voice_language": { "name": "음성 언어" } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "비디오 ID", "tooltip": null }, "2": { "name": "재생 시간", "tooltip": null } } };
const KlingLipSyncTextToVideoNode = { "description": "Kling 립싱크 텍스트-투-비디오 노드입니다. 비디오 파일에서 입 모양 움직임을 텍스트 프롬프트에 맞춰 동기화합니다.", "display_name": "Kling 립싱크 비디오 (텍스트 기반)", "inputs": { "text": { "name": "텍스트", "tooltip": "립싱크 비디오 생성을 위한 텍스트 내용입니다. text2video 모드에서 필수입니다. 최대 길이는 120자입니다." }, "video": { "name": "비디오" }, "voice": { "name": "음성" }, "voice_speed": { "name": "음성 속도", "tooltip": "음성 속도. 유효 범위: 0.8~2.0, 소수점 한 자리까지 입력 가능합니다." } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "비디오 ID", "tooltip": null }, "2": { "name": "길이", "tooltip": null } } };
const KlingSingleImageVideoEffectNode = { "description": "'효과 장면'에 따라 비디오를 생성할 때 다양한 특수 효과를 적용합니다.", "display_name": "Kling 비디오 효과", "inputs": { "duration": { "name": "길이" }, "effect_scene": { "name": "효과 장면" }, "image": { "name": "이미지", "tooltip": "참조 이미지. URL 또는 Base64 인코딩 문자열(data:image 접두사 제외). 파일 크기는 10MB를 초과할 수 없으며, 해상도는 최소 300*300px, 가로세로 비율은 1:2.5 ~ 2.5:1 사이여야 합니다." }, "model_name": { "name": "모델 명" } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "비디오 ID", "tooltip": null }, "2": { "name": "길이", "tooltip": null } } };
const KlingStartEndFrameNode = { "description": "제공한 시작 이미지와 종료 이미지 사이를 전환하는 비디오 시퀀스를 생성합니다. 이 노드는 중간의 모든 프레임을 만들어 첫 프레임에서 마지막 프레임까지 부드러운 변환을 제공합니다.", "display_name": "Kling 비디오 생성 (시작-끝 프레임)", "inputs": { "aspect_ratio": { "name": "종횡비" }, "cfg_scale": { "name": "cfg 스케일" }, "end_frame": { "name": "끝 프레임", "tooltip": "참조 이미지 - 끝 프레임 제어. URL 또는 Base64 인코딩 문자열, 10MB를 초과할 수 없으며, 해상도는 최소 300*300px이어야 합니다. Base64에는 data:image 접두사가 포함되지 않아야 합니다." }, "mode": { "name": "모드", "tooltip": "비디오 생성을 위한 구성. 형식: 모드 / 길이 / 모델명" }, "negative_prompt": { "name": "부정 프롬프트", "tooltip": "비디오에서 제외할 내용을 설명" }, "prompt": { "name": "프롬프트", "tooltip": "비디오 생성을 위한 프롬프트" }, "start_frame": { "name": "시작 프레임", "tooltip": "참조 이미지 - URL 또는 Base64 인코딩 문자열, 10MB를 초과할 수 없으며, 해상도는 최소 300*300px, 가로세로 비율은 1:2.5 ~ 2.5:1 사이여야 합니다. Base64에는 data:image 접두사가 포함되지 않아야 합니다." } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "비디오 ID", "tooltip": null }, "2": { "name": "길이", "tooltip": null } } };
const KlingTextToVideoNode = { "description": "Kling 텍스트 투 비디오 노드", "display_name": "Kling 비디오 생성 (텍스트 → 비디오)", "inputs": { "aspect_ratio": { "name": "종횡비" }, "cfg_scale": { "name": "cfg 스케일" }, "mode": { "name": "모드", "tooltip": "비디오 생성을 위한 설정 (형식: 모드 / 길이 / 모델명)" }, "negative_prompt": { "name": "부정 프롬프트", "tooltip": "부정 텍스트 프롬프트" }, "prompt": { "name": "프롬프트", "tooltip": "긍정 텍스트 프롬프트" } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "비디오 ID", "tooltip": null }, "2": { "name": "길이", "tooltip": null } } };
const KlingVideoExtendNode = { "description": "Kling 비디오 확장 노드입니다. 다른 Kling 노드에서 생성된 비디오를 확장합니다. video_id는 다른 Kling 노드를 사용하여 생성됩니다.", "display_name": "Kling 비디오 확장", "inputs": { "cfg_scale": { "name": "cfg 스케일" }, "negative_prompt": { "name": "부정 프롬프트", "tooltip": "확장된 비디오에서 피하고 싶은 요소를 위한 부정적인 텍스트 프롬프트" }, "prompt": { "name": "프롬프트", "tooltip": "비디오 확장을 안내하는 긍정적인 텍스트 프롬프트" }, "video_id": { "name": "비디오 ID", "tooltip": "확장할 비디오의 ID입니다. 텍스트-투-비디오, 이미지-투-비디오, 이전 비디오 확장 작업에서 생성된 비디오를 지원합니다. 확장 후 총 길이는 3분을 초과할 수 없습니다." } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "비디오 ID", "tooltip": null }, "2": { "name": "길이", "tooltip": null } } };
const KlingVirtualTryOnNode = { "description": "Kling 가상 착용 노드입니다. 인물 이미지와 의류 이미지를 입력하여 인물에게 의류를 착용시킵니다.", "display_name": "Kling 가상 착용", "inputs": { "cloth_image": { "name": "의상 이미지" }, "human_image": { "name": "사람 이미지" }, "model_name": { "name": "모델 명" } }, "outputs": { "0": { "tooltip": null } } };
const LTXVAddGuide = { "display_name": "LTXV 가이드 추가", "inputs": { "frame_idx": { "name": "프레임 번호", "tooltip": "조건을 시작할 프레임 번호. 단일 프레임 이미지 또는 1-8 프레임의 비디오의 경우 어떤 프레임 번호 값도 허용됩니다. 9+ 프레임의 비디오의 경우, 프레임 번호는 8의 배수여야 합니다. 그렇지 않으면 가장 가까운 8의 배수로 내림됩니다. 음수 값은 비디오의 끝에서부터 계산됩니다." }, "image": { "name": "이미지", "tooltip": "잠재 비디오에 조건을 부여하는 이미지 또는 비디오. 8*n + 1 프레임이어야 합니다. 비디오가 8*n + 1 프레임이 아닌 경우 가장 가까운 8*n + 1 프레임으로 자릅니다." }, "latent": { "name": "잠재 비디오" }, "negative": { "name": "부정 조건" }, "positive": { "name": "긍정 조건" }, "strength": { "name": "강도" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "긍정 조건", "tooltip": null }, "1": { "name": "부정 조건", "tooltip": null }, "2": { "name": "잠재 비디오", "tooltip": null } } };
const LTXVConditioning = { "display_name": "LTXV 조건 설정", "inputs": { "frame_rate": { "name": "프레임율" }, "negative": { "name": "부정 조건" }, "positive": { "name": "긍정 조건" } }, "outputs": { "0": { "name": "긍정 조건", "tooltip": null }, "1": { "name": "부정 조건", "tooltip": null } } };
const LTXVCropGuides = { "display_name": "LTXV 가이드 자르기", "inputs": { "latent": { "name": "잠재 비디오" }, "negative": { "name": "부정 조건" }, "positive": { "name": "긍정 조건" } }, "outputs": { "0": { "name": "긍정 조건", "tooltip": null }, "1": { "name": "부정 조건", "tooltip": null }, "2": { "name": "잠재 비디오", "tooltip": null } } };
const LTXVImgToVideo = { "display_name": "LTXV 비디오 생성 (이미지 → 비디오)", "inputs": { "batch_size": { "name": "배치 크기" }, "height": { "name": "높이" }, "image": { "name": "이미지" }, "length": { "name": "길이" }, "negative": { "name": "부정 조건" }, "positive": { "name": "긍정 조건" }, "strength": { "name": "강도" }, "vae": { "name": "vae" }, "width": { "name": "너비" } }, "outputs": { "0": { "name": "긍정 조건", "tooltip": null }, "1": { "name": "부정 조건", "tooltip": null }, "2": { "name": "잠재 데이터", "tooltip": null } } };
const LTXVPreprocess = { "display_name": "LTXV 전처리", "inputs": { "image": { "name": "이미지" }, "img_compression": { "name": "이미지 압축", "tooltip": "이미지에 적용할 압축의 양." } }, "outputs": { "0": { "name": "출력 이미지", "tooltip": null } } };
const LTXVScheduler = { "display_name": "LTXV 스케줄러", "inputs": { "base_shift": { "name": "기반 시프트" }, "latent": { "name": "잠재 비디오" }, "max_shift": { "name": "최대 시프트" }, "steps": { "name": "스텝 수" }, "stretch": { "name": "늘이기", "tooltip": "시그마를 [종료값, 1] 범위로 늘립니다." }, "terminal": { "name": "종료값", "tooltip": "늘린 후 시그마의 종료값입니다." } }, "outputs": { "0": { "tooltip": null } } };
const LaplaceScheduler = { "display_name": "라플라스 스케줄러", "inputs": { "beta": { "name": "beta" }, "mu": { "name": "mu" }, "sigma_max": { "name": "최대 시그마" }, "sigma_min": { "name": "최소 시그마" }, "steps": { "name": "스텝 수" } } };
const LatentAdd = { "display_name": "잠재 데이터 연산 (더하기)", "inputs": { "samples1": { "name": "잠재 데이터1" }, "samples2": { "name": "잠재 데이터2" } }, "outputs": { "0": { "tooltip": null } } };
const LatentApplyOperation = { "display_name": "잠재 데이터 연산 (연산 적용)", "inputs": { "operation": { "name": "연산" }, "samples": { "name": "잠재 데이터" } }, "outputs": { "0": { "tooltip": null } } };
const LatentApplyOperationCFG = { "display_name": "잠재 데이터 CFG 연산 (연산 적용)", "inputs": { "model": { "name": "모델" }, "operation": { "name": "연산" } }, "outputs": { "0": { "tooltip": null } } };
const LatentBatch = { "display_name": "잠재 데이터 배치 연결", "inputs": { "samples1": { "name": "잠재 데이터1" }, "samples2": { "name": "잠재 데이터2" } }, "outputs": { "0": { "tooltip": null } } };
const LatentBatchSeedBehavior = { "display_name": "잠재 데이터 배치 시드 동작", "inputs": { "samples": { "name": "잠재 데이터" }, "seed_behavior": { "name": "시드 동작" } }, "outputs": { "0": { "tooltip": null } } };
const LatentBlend = { "display_name": "잠재 데이터 연산 (혼합)", "inputs": { "blend_factor": { "name": "혼합 계수" }, "samples1": { "name": "잠재 데이터1" }, "samples2": { "name": "잠재 데이터2" } } };
const LatentComposite = { "display_name": "잠재 데이터 합성 (위치 기반)", "inputs": { "feather": { "name": "가장자리 흐림" }, "samples_from": { "name": "추가 잠재 데이터" }, "samples_to": { "name": "대상 잠재 데이터" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const LatentCompositeMasked = { "display_name": "잠재 데이터 합성 (마스크 기반)", "inputs": { "destination": { "name": "대상" }, "mask": { "name": "마스크" }, "resize_source": { "name": "원본 크기 조정" }, "source": { "name": "원본" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const LatentConcat = { "display_name": "LatentConcat", "inputs": { "dim": { "name": "차원" }, "samples1": { "name": "샘플1" }, "samples2": { "name": "샘플2" } }, "outputs": { "0": { "tooltip": null } } };
const LatentCrop = { "display_name": "잠재 데이터 자르기", "inputs": { "height": { "name": "높이" }, "samples": { "name": "잠재 데이터" }, "width": { "name": "너비" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const LatentCut = { "display_name": "LatentCut", "inputs": { "amount": { "name": "양" }, "dim": { "name": "차원" }, "index": { "name": "인덱스" }, "samples": { "name": "샘플" } }, "outputs": { "0": { "tooltip": null } } };
const LatentFlip = { "display_name": "잠재 데이터 연산 (뒤집기)", "inputs": { "flip_method": { "name": "뒤집기 방법" }, "samples": { "name": "잠재 데이터" } } };
const LatentFromBatch = { "display_name": "배치에서 잠재 데이터 가져오기", "inputs": { "batch_index": { "name": "배치_인덱스" }, "length": { "name": "길이" }, "samples": { "name": "잠재 데이터" } } };
const LatentInterpolate = { "display_name": "잠재 데이터 연산 (보간)", "inputs": { "ratio": { "name": "비율" }, "samples1": { "name": "잠재 데이터1" }, "samples2": { "name": "잠재 데이터2" } }, "outputs": { "0": { "tooltip": null } } };
const LatentMultiply = { "display_name": "잠재 데이터 연산 (곱하기)", "inputs": { "multiplier": { "name": "배율" }, "samples": { "name": "잠재 데이터" } }, "outputs": { "0": { "tooltip": null } } };
const LatentOperationSharpen = { "display_name": "잠재 데이터 연산 (선명화)", "inputs": { "alpha": { "name": "알파" }, "sharpen_radius": { "name": "선명화 반경" }, "sigma": { "name": "시그마" } }, "outputs": { "0": { "tooltip": null } } };
const LatentOperationTonemapReinhard = { "display_name": "잠재 데이터 연산 (톤맵 레인하르트)", "inputs": { "multiplier": { "name": "배율" } }, "outputs": { "0": { "tooltip": null } } };
const LatentRotate = { "display_name": "잠재 데이터 연산 (회전)", "inputs": { "rotation": { "name": "회전" }, "samples": { "name": "잠재 데이터" } } };
const LatentSubtract = { "display_name": "잠재 데이터 연산 (빼기)", "inputs": { "samples1": { "name": "잠재 데이터1" }, "samples2": { "name": "잠재 데이터2" } }, "outputs": { "0": { "tooltip": null } } };
const LatentUpscale = { "display_name": "잠재 데이터 크기 조정", "inputs": { "crop": { "name": "자르기" }, "height": { "name": "높이" }, "samples": { "name": "잠재 데이터" }, "upscale_method": { "name": "업스케일 방법" }, "width": { "name": "너비" } } };
const LatentUpscaleBy = { "display_name": "잠재 데이터 크기 배율 조정", "inputs": { "samples": { "name": "잠재 데이터" }, "scale_by": { "name": "확대율" }, "upscale_method": { "name": "확대 방법" } } };
const LazyCache = { "description": "EasyCache의 자체 제작 버전 - 구현이 '더 쉬운' EasyCache 버전입니다. 전체적으로는 EasyCache보다 성능이 떨어지지만, 일부 드문 경우에 더 좋으며 ComfyUI의 모든 것과 완벽한 호환성을 제공합니다.", "display_name": "LazyCache", "inputs": { "end_percent": { "name": "종료 백분율", "tooltip": "LazyCache 사용을 종료할 상대적 샘플링 단계입니다." }, "model": { "name": "모델", "tooltip": "LazyCache를 적용할 모델입니다." }, "reuse_threshold": { "name": "재사용 임계값", "tooltip": "캐시된 단계를 재사용하기 위한 임계값입니다." }, "start_percent": { "name": "시작 백분율", "tooltip": "LazyCache 사용을 시작할 상대적 샘플링 단계입니다." }, "verbose": { "name": "상세 정보", "tooltip": "상세 정보를 기록할지 여부입니다." } }, "outputs": { "0": { "tooltip": "LazyCache가 적용된 모델입니다." } } };
const Load3D = { "display_name": "3D 불러오기", "inputs": { "clear": {}, "height": { "name": "높이" }, "image": { "name": "이미지" }, "model_file": { "name": "모델 파일" }, "upload 3d model": {}, "width": { "name": "너비" } }, "outputs": { "0": { "name": "이미지" }, "1": { "name": "마스크" }, "2": { "name": "메시 경로" }, "3": { "name": "노멀" }, "4": { "name": "라인아트" }, "5": { "name": "카메라 정보" } } };
const LoadAudio = { "display_name": "오디오 로드", "inputs": { "audio": { "name": "오디오" }, "audioUI": { "name": "오디오UI" }, "upload": { "name": "업로드할 파일 선택" } } };
const LoadImage = { "display_name": "이미지 로드", "inputs": { "image": { "name": "이미지" }, "upload": { "name": "업로드할 파일 선택" } } };
const LoadImageMask = { "display_name": "마스크 이미지 로드", "inputs": { "channel": { "name": "채널" }, "image": { "name": "이미지" }, "upload": { "name": "업로드할 파일 선택" } } };
const LoadImageOutput = { "description": "입력(input) 폴더 대신 출력(output) 폴더에서 이미지를 로드합니다. 새로 고침 버튼을 클릭하면 노드는 이미지 목록을 업데이트하고 자동으로 첫 번째 이미지를 선택하여 쉬운 반복을 가능하게 합니다.", "display_name": "이미지 로드 (출력에서)", "inputs": { "image": { "name": "이미지" }, "refresh": {}, "upload": { "name": "업로드할 파일 선택" } } };
const LoadLatent = { "display_name": "잠재 데이터 로드", "inputs": { "latent": { "name": "잠재 데이터" } } };
const LoadVideo = { "display_name": "비디오 불러오기", "inputs": { "file": { "name": "파일" }, "upload": { "name": "업로드할 파일 선택" } }, "outputs": { "0": { "tooltip": null } } };
const LoraLoader = { "description": "LoRA는 확산 모델과 CLIP 모델을 부분적으로 변경해서, 잠재 데이터의 노이즈 제거 방향을 바꿉니다. 여러 LoRA 노드를 연결할 수 있습니다.", "display_name": "LoRA 로드", "inputs": { "clip": { "name": "clip", "tooltip": "LoRA가 적용될 CLIP 모델입니다." }, "lora_name": { "name": "LoRA 이름", "tooltip": "LoRA의 이름입니다." }, "model": { "name": "모델", "tooltip": "LoRA가 적용될 확산 모델입니다." }, "strength_clip": { "name": "clip 강도", "tooltip": "CLIP 모델을 적용하는 강도입니다. 이 값은 음수가 될 수 있습니다." }, "strength_model": { "name": "모델 강도", "tooltip": "확산 모델을 적용하는 강도입니다. 이 값은 음수가 될 수 있습니다." } }, "outputs": { "0": { "tooltip": "수정된 확산 모델입니다." }, "1": { "tooltip": "수정된 CLIP 모델입니다." } } };
const LoraLoaderModelOnly = { "description": "LoRA는 확산 모델과 CLIP 모델을 부분적으로 변경해서, 잠재 데이터의 노이즈 제거 방향을 바꿉니다. 여러 LoRA 노드를 연결할 수 있습니다. (이 노드는 CLIP 모델은 로드하지 않습니다.)", "display_name": "LoRA 로드 (모델 전용)", "inputs": { "lora_name": { "name": "LoRA 이름" }, "model": { "name": "모델" }, "strength_model": { "name": "모델 강도" } }, "outputs": { "0": { "tooltip": "수정된 확산 모델입니다." } } };
const LoraModelLoader = { "display_name": "LoRA 모델 로드", "inputs": { "lora": { "name": "LoRA", "tooltip": "디퓨전 모델에 적용할 LoRA 모델입니다." }, "model": { "name": "모델", "tooltip": "LoRA가 적용될 디퓨전 모델입니다." }, "strength_model": { "name": "모델 강도", "tooltip": "디퓨전 모델을 수정하는 강도입니다. 이 값은 음수일 수 있습니다." } }, "outputs": { "0": { "tooltip": "수정된 디퓨전 모델입니다." } } };
const LoraSave = { "display_name": "LoRA 추출 및 저장", "inputs": { "bias_diff": { "name": "차이 편향" }, "filename_prefix": { "name": "파일명 접두사" }, "lora_type": { "name": "LoRA 유형" }, "model_diff": { "name": "모델 차이", "tooltip": "LoRA로 변환 될 ModelSubtract 출력입니다." }, "rank": { "name": "순위" }, "text_encoder_diff": { "name": "텍스트 인코더 차이", "tooltip": "LoRA로 변환 될 CLIPSubtract 출력입니다." } } };
const LossGraphNode = { "display_name": "손실 그래프 그리기", "inputs": { "filename_prefix": { "name": "파일명 접두사" }, "loss": { "name": "손실" } } };
const LotusConditioning = { "display_name": "Lotus 조건 설정", "outputs": { "0": { "name": "조건", "tooltip": null } } };
const LtxvApiImageToVideo = { "description": "시작 이미지를 기반으로 사용자 지정 가능한 지속 시간과 해상도를 가진 전문가급 품질의 비디오입니다.", "display_name": "LTXV 이미지 투 비디오", "inputs": { "duration": { "name": "지속 시간" }, "fps": { "name": "FPS" }, "generate_audio": { "name": "오디오 생성", "tooltip": "true로 설정하면 생성된 비디오에 장면과 일치하는 AI 생성 오디오가 포함됩니다." }, "image": { "name": "이미지", "tooltip": "비디오에 사용할 첫 번째 프레임입니다." }, "model": { "name": "모델" }, "prompt": { "name": "프롬프트" }, "resolution": { "name": "해상도" } }, "outputs": { "0": { "tooltip": null } } };
const LtxvApiTextToVideo = { "description": "사용자 지정 가능한 지속 시간과 해상도를 가진 전문가급 품질의 비디오입니다.", "display_name": "LTXV 텍스트 투 비디오", "inputs": { "duration": { "name": "지속 시간" }, "fps": { "name": "FPS" }, "generate_audio": { "name": "오디오 생성", "tooltip": "true로 설정하면 생성된 비디오에 장면과 일치하는 AI 생성 오디오가 포함됩니다." }, "model": { "name": "모델" }, "prompt": { "name": "프롬프트" }, "resolution": { "name": "해상도" } }, "outputs": { "0": { "tooltip": null } } };
const LumaConceptsNode = { "description": "루마 텍스트 투 비디오 및 루마 이미지 투 비디오 노드에서 사용할 하나 이상의 카메라 컨셉을 보관합니다.", "display_name": "Luma 컨셉", "inputs": { "concept1": { "name": "컨셉1" }, "concept2": { "name": "컨셉2" }, "concept3": { "name": "컨셉3" }, "concept4": { "name": "컨셉4" }, "luma_concepts": { "name": "luma 컨셉", "tooltip": "여기에 선택한 컨셉에 추가할 선택적 카메라 컨셉입니다." } }, "outputs": { "0": { "name": "luma 컨셉", "tooltip": null } } };
const LumaImageModifyNode = { "description": "프롬프트와 종횡비에 따라 이미지를 동기적으로 수정합니다.", "display_name": "Luma 이미지 생성 (이미지 → 이미지)", "inputs": { "control_after_generate": { "name": "생성 후 제어" }, "image": { "name": "이미지" }, "image_weight": { "name": "이미지 가중치", "tooltip": "이미지의 가중치; 1.0에 가까울수록 이미지가 덜 수정됩니다." }, "model": { "name": "모델" }, "prompt": { "name": "프롬프트", "tooltip": "이미지 생성을 위한 프롬프트" }, "seed": { "name": "시드", "tooltip": "노드를 다시 실행할지 결정하는 시드; 실제 결과는 시드와 상관없이 비결정적입니다." } }, "outputs": { "0": { "tooltip": null } } };
const LumaImageNode = { "description": "프롬프트와 종횡비에 따라 이미지를 동기적으로 생성합니다.", "display_name": "Luma 이미지 생성 (텍스트 → 이미지)", "inputs": { "aspect_ratio": { "name": "종횡비" }, "character_image": { "name": "캐릭터 참조 이미지", "tooltip": "캐릭터 참조 이미지; 여러 장의 배치가 가능하며, 최대 4개의 이미지를 사용할 수 있습니다." }, "control_after_generate": { "name": "생성 후 제어" }, "image_luma_ref": { "name": "Luma 참조 이미지", "tooltip": "입력 이미지를 사용해 생성에 영향을 주는 Luma Reference 노드 연결; 최대 4개의 이미지를 사용할 수 있습니다." }, "model": { "name": "모델" }, "prompt": { "name": "프롬프트", "tooltip": "이미지 생성을 위한 프롬프트" }, "seed": { "name": "시드", "tooltip": "노드가 다시 실행될지 결정하는 시드; 실제 결과는 시드와 관계없이 비결정적입니다." }, "style_image": { "name": "스타일 참조 이미지", "tooltip": "스타일 참조 이미지; 1개의 이미지만 사용됩니다." }, "style_image_weight": { "name": "스타일 이미지 가중치", "tooltip": "스타일 이미지의 가중치. 스타일 이미지가 제공되지 않으면 무시됩니다." } }, "outputs": { "0": { "tooltip": null } } };
const LumaImageToVideoNode = { "description": "프롬프트, 입력 이미지, output_size를 기반으로 동기적으로 비디오를 생성합니다.", "display_name": "Luma 이미지 → 비디오", "inputs": { "control_after_generate": { "name": "생성 후 제어" }, "duration": { "name": "길이" }, "first_image": { "name": "첫 이미지", "tooltip": "생성된 비디오의 첫 프레임." }, "last_image": { "name": "마지막 이미지", "tooltip": "생성된 비디오의 마지막 프레임." }, "loop": { "name": "루프" }, "luma_concepts": { "name": "Luma 컨셉", "tooltip": "선택 사항: Luma 컨셉 노드를 통해 카메라 움직임을 지정하는 카메라 컨셉." }, "model": { "name": "모델" }, "prompt": { "name": "프롬프트", "tooltip": "비디오 생성을 위한 프롬프트" }, "resolution": { "name": "해상도" }, "seed": { "name": "시드", "tooltip": "노드가 다시 실행되어야 하는지 결정하는 시드입니다. 실제 결과는 시드와 상관없이 비결정적입니다." } }, "outputs": { "0": { "tooltip": null } } };
const LumaReferenceNode = { "description": "Luma 이미지 생성 노드에서 사용할 이미지와 가중치를 보관합니다.", "display_name": "Luma 이미지 참조", "inputs": { "image": { "name": "이미지", "tooltip": "참조로 사용할 이미지입니다." }, "luma_ref": { "name": "luma_ref" }, "weight": { "name": "가중치", "tooltip": "이미지 참조의 가중치입니다." } }, "outputs": { "0": { "name": "luma_ref", "tooltip": null } } };
const LumaVideoNode = { "description": "프롬프트와 output_size에 따라 동기적으로 비디오를 생성합니다.", "display_name": "Luma 텍스트 투 비디오", "inputs": { "aspect_ratio": { "name": "종횡비" }, "control_after_generate": { "name": "생성 후 제어" }, "duration": { "name": "길이" }, "loop": { "name": "루프" }, "luma_concepts": { "name": "Luma 컨셉", "tooltip": "카메라 움직임을 제어하기 위한 선택적 Camera Concepts (Luma Concepts 노드 사용)." }, "model": { "name": "모델" }, "prompt": { "name": "프롬프트", "tooltip": "비디오 생성을 위한 프롬프트" }, "resolution": { "name": "해상도" }, "seed": { "name": "시드", "tooltip": "노드가 다시 실행되어야 하는지 결정하는 시드입니다. 실제 결과는 시드와 관계없이 비결정적입니다." } }, "outputs": { "0": { "tooltip": null } } };
const Mahiro = { "description": "노이즈 제거의 '방향'을 긍정 조건과 부정 조건 차에 의한 것 보다는 긍정 조건 방향으로 더 크게 작동하도록 가이더 동작을 변경합니다.", "display_name": "마히로", "inputs": { "model": { "name": "모델" } }, "outputs": { "0": { "name": "변경된 모델", "tooltip": null } } };
const MaskComposite = { "display_name": "마스크 합성", "inputs": { "destination": { "name": "대상" }, "operation": { "name": "연산" }, "source": { "name": "원본" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const MaskPreview = { "description": "입력 이미지를 ComfyUI 출력 디렉터리에 저장합니다.", "display_name": "마스크 미리보기", "inputs": { "mask": { "name": "마스크" } } };
const MaskToImage = { "display_name": "마스크를 이미지로 변환", "inputs": { "mask": { "name": "마스크" } } };
const MinimaxHailuoVideoNode = { "description": "새로운 MiniMax Hailuo-02 모델을 사용하여 프롬프트로 비디오를 생성하며, 선택적으로 시작 프레임을 사용할 수 있습니다.", "display_name": "MiniMax Hailuo 비디오", "inputs": { "control_after_generate": { "name": "생성 후 제어" }, "duration": { "name": "지속 시간", "tooltip": "출력 비디오의 길이(초)입니다." }, "first_frame_image": { "name": "첫 번째 프레임 이미지", "tooltip": "비디오 생성에 사용할 선택적 이미지입니다." }, "prompt_optimizer": { "name": "프롬프트 최적화", "tooltip": "필요할 때 생성 품질을 향상시키기 위해 프롬프트를 최적화합니다." }, "prompt_text": { "name": "텍스트 프롬프트", "tooltip": "비디오 생성을 안내하는 텍스트 프롬프트입니다." }, "resolution": { "name": "해상도", "tooltip": "비디오 디스플레이의 해상도입니다. 1080p는 1920x1080, 768p는 1366x768입니다." }, "seed": { "name": "시드", "tooltip": "노이즈 생성에 사용되는 랜덤 시드입니다." } }, "outputs": { "0": { "tooltip": null } } };
const MinimaxImageToVideoNode = { "description": "MiniMax의 API를 사용하여 이미지와 프롬프트로부터 비디오를 생성합니다", "display_name": "MiniMax 이미지에서 비디오로", "inputs": { "control_after_generate": { "name": "생성 후 제어" }, "image": { "name": "이미지", "tooltip": "비디오 생성의 첫 프레임으로 사용할 이미지" }, "model": { "name": "모델", "tooltip": "비디오 생성에 사용할 모델" }, "prompt_text": { "name": "프롬프트 텍스트", "tooltip": "비디오 생성을 안내할 텍스트 프롬프트" }, "seed": { "name": "시드", "tooltip": "노이즈 생성을 위해 사용되는 랜덤 시드입니다." } }, "outputs": { "0": { "tooltip": null } } };
const MinimaxTextToVideoNode = { "description": "MiniMax의 API를 사용하여 프롬프트로부터 비디오를 생성합니다", "display_name": "MiniMax 텍스트 투 비디오", "inputs": { "control_after_generate": { "name": "생성 후 제어" }, "model": { "name": "모델", "tooltip": "비디오 생성을 위해 사용할 모델" }, "prompt_text": { "name": "프롬프트 텍스트", "tooltip": "비디오 생성을 안내할 텍스트 프롬프트" }, "seed": { "name": "시드", "tooltip": "노이즈 생성을 위해 사용되는 랜덤 시드입니다." } }, "outputs": { "0": { "tooltip": null } } };
const ModelComputeDtype = { "display_name": "ModelComputeDtype", "inputs": { "dtype": { "name": "dtype" }, "model": { "name": "모델" } } };
const ModelMergeAdd = { "display_name": "모델 병합 (더하기)", "inputs": { "model1": { "name": "모델1" }, "model2": { "name": "모델2" } } };
const ModelMergeAuraflow = { "display_name": "모델 병합 (AuraFlow)", "inputs": { "cond_seq_linear_": { "name": "cond_seq_linear." }, "double_layers_0_": { "name": "double_layers.0." }, "double_layers_1_": { "name": "double_layers.1." }, "double_layers_2_": { "name": "double_layers.2." }, "double_layers_3_": { "name": "double_layers.3." }, "final_linear_": { "name": "final_linear." }, "init_x_linear_": { "name": "init_x_linear." }, "modF_": { "name": "modF." }, "model1": { "name": "모델1" }, "model2": { "name": "모델2" }, "positional_encoding": { "name": "positional_encoding" }, "register_tokens": { "name": "register_tokens" }, "single_layers_0_": { "name": "single_layers.0." }, "single_layers_10_": { "name": "single_layers.10." }, "single_layers_11_": { "name": "single_layers.11." }, "single_layers_12_": { "name": "single_layers.12." }, "single_layers_13_": { "name": "single_layers.13." }, "single_layers_14_": { "name": "single_layers.14." }, "single_layers_15_": { "name": "single_layers.15." }, "single_layers_16_": { "name": "single_layers.16." }, "single_layers_17_": { "name": "single_layers.17." }, "single_layers_18_": { "name": "single_layers.18." }, "single_layers_19_": { "name": "single_layers.19." }, "single_layers_1_": { "name": "single_layers.1." }, "single_layers_20_": { "name": "single_layers.20." }, "single_layers_21_": { "name": "single_layers.21." }, "single_layers_22_": { "name": "single_layers.22." }, "single_layers_23_": { "name": "single_layers.23." }, "single_layers_24_": { "name": "single_layers.24." }, "single_layers_25_": { "name": "single_layers.25." }, "single_layers_26_": { "name": "single_layers.26." }, "single_layers_27_": { "name": "single_layers.27." }, "single_layers_28_": { "name": "single_layers.28." }, "single_layers_29_": { "name": "single_layers.29." }, "single_layers_2_": { "name": "single_layers.2." }, "single_layers_30_": { "name": "single_layers.30." }, "single_layers_31_": { "name": "single_layers.31." }, "single_layers_3_": { "name": "single_layers.3." }, "single_layers_4_": { "name": "single_layers.4." }, "single_layers_5_": { "name": "single_layers.5." }, "single_layers_6_": { "name": "single_layers.6." }, "single_layers_7_": { "name": "single_layers.7." }, "single_layers_8_": { "name": "single_layers.8." }, "single_layers_9_": { "name": "single_layers.9." }, "t_embedder_": { "name": "t_embedder." } } };
const ModelMergeBlocks = { "display_name": "모델 병합 (블록)", "inputs": { "input": { "name": "input" }, "middle": { "name": "middle" }, "model1": { "name": "모델1" }, "model2": { "name": "모델2" }, "out": { "name": "out" } } };
const ModelMergeCosmos14B = { "display_name": "모델 병합 (Cosmos 14B)", "inputs": { "affline_norm_": { "name": "affline_norm." }, "blocks_block0_": { "name": "blocks.block0." }, "blocks_block10_": { "name": "blocks.block10." }, "blocks_block11_": { "name": "blocks.block11." }, "blocks_block12_": { "name": "blocks.block12." }, "blocks_block13_": { "name": "blocks.block13." }, "blocks_block14_": { "name": "blocks.block14." }, "blocks_block15_": { "name": "blocks.block15." }, "blocks_block16_": { "name": "blocks.block16." }, "blocks_block17_": { "name": "blocks.block17." }, "blocks_block18_": { "name": "blocks.block18." }, "blocks_block19_": { "name": "blocks.block19." }, "blocks_block1_": { "name": "blocks.block1." }, "blocks_block20_": { "name": "blocks.block20." }, "blocks_block21_": { "name": "blocks.block21." }, "blocks_block22_": { "name": "blocks.block22." }, "blocks_block23_": { "name": "blocks.block23." }, "blocks_block24_": { "name": "blocks.block24." }, "blocks_block25_": { "name": "blocks.block25." }, "blocks_block26_": { "name": "blocks.block26." }, "blocks_block27_": { "name": "blocks.block27." }, "blocks_block28_": { "name": "blocks.block28." }, "blocks_block29_": { "name": "blocks.block29." }, "blocks_block2_": { "name": "blocks.block2." }, "blocks_block30_": { "name": "blocks.block30." }, "blocks_block31_": { "name": "blocks.block31." }, "blocks_block32_": { "name": "blocks.block32." }, "blocks_block33_": { "name": "blocks.block33." }, "blocks_block34_": { "name": "blocks.block34." }, "blocks_block35_": { "name": "blocks.block35." }, "blocks_block3_": { "name": "blocks.block3." }, "blocks_block4_": { "name": "blocks.block4." }, "blocks_block5_": { "name": "blocks.block5." }, "blocks_block6_": { "name": "blocks.block6." }, "blocks_block7_": { "name": "blocks.block7." }, "blocks_block8_": { "name": "blocks.block8." }, "blocks_block9_": { "name": "blocks.block9." }, "extra_pos_embedder_": { "name": "extra_pos_embedder." }, "final_layer_": { "name": "final_layer." }, "model1": { "name": "모델1" }, "model2": { "name": "모델2" }, "pos_embedder_": { "name": "pos_embedder." }, "t_embedder_": { "name": "t_embedder." }, "x_embedder_": { "name": "x_embedder." } } };
const ModelMergeCosmos7B = { "display_name": "모델 병합 (Cosmos 7B)", "inputs": { "affline_norm_": { "name": "affline_norm." }, "blocks_block0_": { "name": "blocks.block0." }, "blocks_block10_": { "name": "blocks.block10." }, "blocks_block11_": { "name": "blocks.block11." }, "blocks_block12_": { "name": "blocks.block12." }, "blocks_block13_": { "name": "blocks.block13." }, "blocks_block14_": { "name": "blocks.block14." }, "blocks_block15_": { "name": "blocks.block15." }, "blocks_block16_": { "name": "blocks.block16." }, "blocks_block17_": { "name": "blocks.block17." }, "blocks_block18_": { "name": "blocks.block18." }, "blocks_block19_": { "name": "blocks.block19." }, "blocks_block1_": { "name": "blocks.block1." }, "blocks_block20_": { "name": "blocks.block20." }, "blocks_block21_": { "name": "blocks.block21." }, "blocks_block22_": { "name": "blocks.block22." }, "blocks_block23_": { "name": "blocks.block23." }, "blocks_block24_": { "name": "blocks.block24." }, "blocks_block25_": { "name": "blocks.block25." }, "blocks_block26_": { "name": "blocks.block26." }, "blocks_block27_": { "name": "blocks.block27." }, "blocks_block2_": { "name": "blocks.block2." }, "blocks_block3_": { "name": "blocks.block3." }, "blocks_block4_": { "name": "blocks.block4." }, "blocks_block5_": { "name": "blocks.block5." }, "blocks_block6_": { "name": "blocks.block6." }, "blocks_block7_": { "name": "blocks.block7." }, "blocks_block8_": { "name": "blocks.block8." }, "blocks_block9_": { "name": "blocks.block9." }, "extra_pos_embedder_": { "name": "extra_pos_embedder." }, "final_layer_": { "name": "final_layer." }, "model1": { "name": "모델1" }, "model2": { "name": "모델2" }, "pos_embedder_": { "name": "pos_embedder." }, "t_embedder_": { "name": "t_embedder." }, "x_embedder_": { "name": "x_embedder." } } };
const ModelMergeCosmosPredict2_14B = { "display_name": "ModelMergeCosmosPredict2_14B", "inputs": { "blocks_0_": { "name": "blocks.0." }, "blocks_10_": { "name": "blocks.10." }, "blocks_11_": { "name": "blocks.11." }, "blocks_12_": { "name": "blocks.12." }, "blocks_13_": { "name": "blocks.13." }, "blocks_14_": { "name": "blocks.14." }, "blocks_15_": { "name": "blocks.15." }, "blocks_16_": { "name": "blocks.16." }, "blocks_17_": { "name": "blocks.17." }, "blocks_18_": { "name": "blocks.18." }, "blocks_19_": { "name": "blocks.19." }, "blocks_1_": { "name": "blocks.1." }, "blocks_20_": { "name": "blocks.20." }, "blocks_21_": { "name": "blocks.21." }, "blocks_22_": { "name": "blocks.22." }, "blocks_23_": { "name": "blocks.23." }, "blocks_24_": { "name": "blocks.24." }, "blocks_25_": { "name": "blocks.25." }, "blocks_26_": { "name": "blocks.26." }, "blocks_27_": { "name": "blocks.27." }, "blocks_28_": { "name": "blocks.28." }, "blocks_29_": { "name": "blocks.29." }, "blocks_2_": { "name": "blocks.2." }, "blocks_30_": { "name": "blocks.30." }, "blocks_31_": { "name": "blocks.31." }, "blocks_32_": { "name": "blocks.32." }, "blocks_33_": { "name": "blocks.33." }, "blocks_34_": { "name": "blocks.34." }, "blocks_35_": { "name": "blocks.35." }, "blocks_3_": { "name": "blocks.3." }, "blocks_4_": { "name": "blocks.4." }, "blocks_5_": { "name": "blocks.5." }, "blocks_6_": { "name": "blocks.6." }, "blocks_7_": { "name": "blocks.7." }, "blocks_8_": { "name": "blocks.8." }, "blocks_9_": { "name": "blocks.9." }, "final_layer_": { "name": "최종 레이어." }, "model1": { "name": "모델1" }, "model2": { "name": "모델2" }, "pos_embedder_": { "name": "pos_embedder." }, "t_embedder_": { "name": "t_embedder." }, "t_embedding_norm_": { "name": "t_embedding_norm." }, "x_embedder_": { "name": "x_embedder." } } };
const ModelMergeCosmosPredict2_2B = { "display_name": "ModelMergeCosmosPredict2_2B", "inputs": { "blocks_0_": { "name": "블록 0." }, "blocks_10_": { "name": "블록 10." }, "blocks_11_": { "name": "블록 11." }, "blocks_12_": { "name": "블록 12." }, "blocks_13_": { "name": "블록 13." }, "blocks_14_": { "name": "블록 14." }, "blocks_15_": { "name": "블록 15." }, "blocks_16_": { "name": "블록 16." }, "blocks_17_": { "name": "블록 17." }, "blocks_18_": { "name": "블록 18." }, "blocks_19_": { "name": "블록 19." }, "blocks_1_": { "name": "블록 1." }, "blocks_20_": { "name": "블록 20." }, "blocks_21_": { "name": "블록 21." }, "blocks_22_": { "name": "블록 22." }, "blocks_23_": { "name": "블록 23." }, "blocks_24_": { "name": "블록 24." }, "blocks_25_": { "name": "블록 25." }, "blocks_26_": { "name": "블록 26." }, "blocks_27_": { "name": "블록 27." }, "blocks_2_": { "name": "블록 2." }, "blocks_3_": { "name": "블록 3." }, "blocks_4_": { "name": "블록 4." }, "blocks_5_": { "name": "블록 5." }, "blocks_6_": { "name": "블록 6." }, "blocks_7_": { "name": "블록 7." }, "blocks_8_": { "name": "블록 8." }, "blocks_9_": { "name": "블록 9." }, "final_layer_": { "name": "최종 레이어." }, "model1": { "name": "모델1" }, "model2": { "name": "모델2" }, "pos_embedder_": { "name": "위치 임베더." }, "t_embedder_": { "name": "t 임베더." }, "t_embedding_norm_": { "name": "t 임베딩 정규화." }, "x_embedder_": { "name": "x 임베더." } } };
const ModelMergeFlux1 = { "display_name": "모델 병합 (FLUX.1)", "inputs": { "double_blocks_0_": { "name": "double_blocks.0." }, "double_blocks_10_": { "name": "double_blocks.10." }, "double_blocks_11_": { "name": "double_blocks.11." }, "double_blocks_12_": { "name": "double_blocks.12." }, "double_blocks_13_": { "name": "double_blocks.13." }, "double_blocks_14_": { "name": "double_blocks.14." }, "double_blocks_15_": { "name": "double_blocks.15." }, "double_blocks_16_": { "name": "double_blocks.16." }, "double_blocks_17_": { "name": "double_blocks.17." }, "double_blocks_18_": { "name": "double_blocks.18." }, "double_blocks_1_": { "name": "double_blocks.1." }, "double_blocks_2_": { "name": "double_blocks.2." }, "double_blocks_3_": { "name": "double_blocks.3." }, "double_blocks_4_": { "name": "double_blocks.4." }, "double_blocks_5_": { "name": "double_blocks.5." }, "double_blocks_6_": { "name": "double_blocks.6." }, "double_blocks_7_": { "name": "double_blocks.7." }, "double_blocks_8_": { "name": "double_blocks.8." }, "double_blocks_9_": { "name": "double_blocks.9." }, "final_layer_": { "name": "final_layer." }, "guidance_in": { "name": "guidance_in" }, "img_in_": { "name": "img_in." }, "model1": { "name": "모델1" }, "model2": { "name": "모델2" }, "single_blocks_0_": { "name": "single_blocks.0." }, "single_blocks_10_": { "name": "single_blocks.10." }, "single_blocks_11_": { "name": "single_blocks.11." }, "single_blocks_12_": { "name": "single_blocks.12." }, "single_blocks_13_": { "name": "single_blocks.13." }, "single_blocks_14_": { "name": "single_blocks.14." }, "single_blocks_15_": { "name": "single_blocks.15." }, "single_blocks_16_": { "name": "single_blocks.16." }, "single_blocks_17_": { "name": "single_blocks.17." }, "single_blocks_18_": { "name": "single_blocks.18." }, "single_blocks_19_": { "name": "single_blocks.19." }, "single_blocks_1_": { "name": "single_blocks.1." }, "single_blocks_20_": { "name": "single_blocks.20." }, "single_blocks_21_": { "name": "single_blocks.21." }, "single_blocks_22_": { "name": "single_blocks.22." }, "single_blocks_23_": { "name": "single_blocks.23." }, "single_blocks_24_": { "name": "single_blocks.24." }, "single_blocks_25_": { "name": "single_blocks.25." }, "single_blocks_26_": { "name": "single_blocks.26." }, "single_blocks_27_": { "name": "single_blocks.27." }, "single_blocks_28_": { "name": "single_blocks.28." }, "single_blocks_29_": { "name": "single_blocks.29." }, "single_blocks_2_": { "name": "single_blocks.2." }, "single_blocks_30_": { "name": "single_blocks.30." }, "single_blocks_31_": { "name": "single_blocks.31." }, "single_blocks_32_": { "name": "single_blocks.32." }, "single_blocks_33_": { "name": "single_blocks.33." }, "single_blocks_34_": { "name": "single_blocks.34." }, "single_blocks_35_": { "name": "single_blocks.35." }, "single_blocks_36_": { "name": "single_blocks.36." }, "single_blocks_37_": { "name": "single_blocks.37." }, "single_blocks_3_": { "name": "single_blocks.3." }, "single_blocks_4_": { "name": "single_blocks.4." }, "single_blocks_5_": { "name": "single_blocks.5." }, "single_blocks_6_": { "name": "single_blocks.6." }, "single_blocks_7_": { "name": "single_blocks.7." }, "single_blocks_8_": { "name": "single_blocks.8." }, "single_blocks_9_": { "name": "single_blocks.9." }, "time_in_": { "name": "time_in." }, "txt_in_": { "name": "txt_in." }, "vector_in_": { "name": "vector_in." } } };
const ModelMergeLTXV = { "display_name": "모델 병합 (LTXV)", "inputs": { "adaln_single_": { "name": "adaln_single." }, "caption_projection_": { "name": "caption_projection." }, "model1": { "name": "모델1" }, "model2": { "name": "모델2" }, "patchify_proj_": { "name": "patchify_proj." }, "proj_out_": { "name": "proj_out." }, "scale_shift_table": { "name": "scale_shift_table" }, "transformer_blocks_0_": { "name": "transformer_blocks.0." }, "transformer_blocks_10_": { "name": "transformer_blocks.10." }, "transformer_blocks_11_": { "name": "transformer_blocks.11." }, "transformer_blocks_12_": { "name": "transformer_blocks.12." }, "transformer_blocks_13_": { "name": "transformer_blocks.13." }, "transformer_blocks_14_": { "name": "transformer_blocks.14." }, "transformer_blocks_15_": { "name": "transformer_blocks.15." }, "transformer_blocks_16_": { "name": "transformer_blocks.16." }, "transformer_blocks_17_": { "name": "transformer_blocks.17." }, "transformer_blocks_18_": { "name": "transformer_blocks.18." }, "transformer_blocks_19_": { "name": "transformer_blocks.19." }, "transformer_blocks_1_": { "name": "transformer_blocks.1." }, "transformer_blocks_20_": { "name": "transformer_blocks.20." }, "transformer_blocks_21_": { "name": "transformer_blocks.21." }, "transformer_blocks_22_": { "name": "transformer_blocks.22." }, "transformer_blocks_23_": { "name": "transformer_blocks.23." }, "transformer_blocks_24_": { "name": "transformer_blocks.24." }, "transformer_blocks_25_": { "name": "transformer_blocks.25." }, "transformer_blocks_26_": { "name": "transformer_blocks.26." }, "transformer_blocks_27_": { "name": "transformer_blocks.27." }, "transformer_blocks_2_": { "name": "transformer_blocks.2." }, "transformer_blocks_3_": { "name": "transformer_blocks.3." }, "transformer_blocks_4_": { "name": "transformer_blocks.4." }, "transformer_blocks_5_": { "name": "transformer_blocks.5." }, "transformer_blocks_6_": { "name": "transformer_blocks.6." }, "transformer_blocks_7_": { "name": "transformer_blocks.7." }, "transformer_blocks_8_": { "name": "transformer_blocks.8." }, "transformer_blocks_9_": { "name": "transformer_blocks.9." } } };
const ModelMergeMochiPreview = { "display_name": "모델 병합 (Mochi Preview)", "inputs": { "blocks_0_": { "name": "blocks.0." }, "blocks_10_": { "name": "blocks.10." }, "blocks_11_": { "name": "blocks.11." }, "blocks_12_": { "name": "blocks.12." }, "blocks_13_": { "name": "blocks.13." }, "blocks_14_": { "name": "blocks.14." }, "blocks_15_": { "name": "blocks.15." }, "blocks_16_": { "name": "blocks.16." }, "blocks_17_": { "name": "blocks.17." }, "blocks_18_": { "name": "blocks.18." }, "blocks_19_": { "name": "blocks.19." }, "blocks_1_": { "name": "blocks.1." }, "blocks_20_": { "name": "blocks.20." }, "blocks_21_": { "name": "blocks.21." }, "blocks_22_": { "name": "blocks.22." }, "blocks_23_": { "name": "blocks.23." }, "blocks_24_": { "name": "blocks.24." }, "blocks_25_": { "name": "blocks.25." }, "blocks_26_": { "name": "blocks.26." }, "blocks_27_": { "name": "blocks.27." }, "blocks_28_": { "name": "blocks.28." }, "blocks_29_": { "name": "blocks.29." }, "blocks_2_": { "name": "blocks.2." }, "blocks_30_": { "name": "blocks.30." }, "blocks_31_": { "name": "blocks.31." }, "blocks_32_": { "name": "blocks.32." }, "blocks_33_": { "name": "blocks.33." }, "blocks_34_": { "name": "blocks.34." }, "blocks_35_": { "name": "blocks.35." }, "blocks_36_": { "name": "blocks.36." }, "blocks_37_": { "name": "blocks.37." }, "blocks_38_": { "name": "blocks.38." }, "blocks_39_": { "name": "blocks.39." }, "blocks_3_": { "name": "blocks.3." }, "blocks_40_": { "name": "blocks.40." }, "blocks_41_": { "name": "blocks.41." }, "blocks_42_": { "name": "blocks.42." }, "blocks_43_": { "name": "blocks.43." }, "blocks_44_": { "name": "blocks.44." }, "blocks_45_": { "name": "blocks.45." }, "blocks_46_": { "name": "blocks.46." }, "blocks_47_": { "name": "blocks.47." }, "blocks_4_": { "name": "blocks.4." }, "blocks_5_": { "name": "blocks.5." }, "blocks_6_": { "name": "blocks.6." }, "blocks_7_": { "name": "blocks.7." }, "blocks_8_": { "name": "blocks.8." }, "blocks_9_": { "name": "blocks.9." }, "final_layer_": { "name": "final_layer." }, "model1": { "name": "모델1" }, "model2": { "name": "모델2" }, "pos_frequencies_": { "name": "pos_frequencies." }, "t5_y_embedder_": { "name": "t5_y_embedder." }, "t5_yproj_": { "name": "t5_yproj." }, "t_embedder_": { "name": "t_embedder." } } };
const ModelMergeQwenImage = { "display_name": "ModelMergeQwenImage", "inputs": { "img_in_": { "name": "이미지 입력." }, "model1": { "name": "모델1" }, "model2": { "name": "모델2" }, "pos_embeds_": { "name": "위치 임베딩." }, "proj_out_": { "name": "proj_out." }, "time_text_embed_": { "name": "시간 텍스트 임베딩." }, "transformer_blocks_0_": { "name": "트랜스포머 블록.0." }, "transformer_blocks_10_": { "name": "트랜스포머 블록.10." }, "transformer_blocks_11_": { "name": "트랜스포머 블록.11." }, "transformer_blocks_12_": { "name": "트랜스포머 블록.12." }, "transformer_blocks_13_": { "name": "트랜스포머 블록.13." }, "transformer_blocks_14_": { "name": "트랜스포머 블록.14." }, "transformer_blocks_15_": { "name": "트랜스포머 블록.15." }, "transformer_blocks_16_": { "name": "트랜스포머 블록.16." }, "transformer_blocks_17_": { "name": "트랜스포머 블록.17." }, "transformer_blocks_18_": { "name": "트랜스포머 블록.18." }, "transformer_blocks_19_": { "name": "트랜스포머 블록.19." }, "transformer_blocks_1_": { "name": "트랜스포머 블록.1." }, "transformer_blocks_20_": { "name": "트랜스포머 블록.20." }, "transformer_blocks_21_": { "name": "트랜스포머 블록.21." }, "transformer_blocks_22_": { "name": "트랜스포머 블록.22." }, "transformer_blocks_23_": { "name": "트랜스포머 블록.23." }, "transformer_blocks_24_": { "name": "트랜스포머 블록.24." }, "transformer_blocks_25_": { "name": "트랜스포머 블록.25." }, "transformer_blocks_26_": { "name": "트랜스포머 블록.26." }, "transformer_blocks_27_": { "name": "트랜스포머 블록.27." }, "transformer_blocks_28_": { "name": "트랜스포머 블록.28." }, "transformer_blocks_29_": { "name": "트랜스포머 블록.29." }, "transformer_blocks_2_": { "name": "트랜스포머 블록.2." }, "transformer_blocks_30_": { "name": "트랜스포머 블록.30." }, "transformer_blocks_31_": { "name": "트랜스포머 블록.31." }, "transformer_blocks_32_": { "name": "트랜스포머 블록.32." }, "transformer_blocks_33_": { "name": "트랜스포머 블록.33." }, "transformer_blocks_34_": { "name": "트랜스포머 블록.34." }, "transformer_blocks_35_": { "name": "트랜스포머 블록.35." }, "transformer_blocks_36_": { "name": "트랜스포머 블록.36." }, "transformer_blocks_37_": { "name": "트랜스포머 블록.37." }, "transformer_blocks_38_": { "name": "트랜스포머 블록.38." }, "transformer_blocks_39_": { "name": "트랜스포머 블록.39." }, "transformer_blocks_3_": { "name": "트랜스포머 블록.3." }, "transformer_blocks_40_": { "name": "트랜스포머 블록.40." }, "transformer_blocks_41_": { "name": "트랜스포머 블록.41." }, "transformer_blocks_42_": { "name": "트랜스포머 블록.42." }, "transformer_blocks_43_": { "name": "트랜스포머 블록.43." }, "transformer_blocks_44_": { "name": "트랜스포머 블록.44." }, "transformer_blocks_45_": { "name": "transformer_blocks.45." }, "transformer_blocks_46_": { "name": "transformer_blocks.46." }, "transformer_blocks_47_": { "name": "transformer_blocks.47." }, "transformer_blocks_48_": { "name": "transformer_blocks.48." }, "transformer_blocks_49_": { "name": "transformer_blocks.49." }, "transformer_blocks_4_": { "name": "트랜스포머 블록.4." }, "transformer_blocks_50_": { "name": "transformer_blocks.50." }, "transformer_blocks_51_": { "name": "transformer_blocks.51." }, "transformer_blocks_52_": { "name": "transformer_blocks.52." }, "transformer_blocks_53_": { "name": "transformer_blocks.53." }, "transformer_blocks_54_": { "name": "transformer_blocks.54." }, "transformer_blocks_55_": { "name": "transformer_blocks.55." }, "transformer_blocks_56_": { "name": "transformer_blocks.56." }, "transformer_blocks_57_": { "name": "transformer_blocks.57." }, "transformer_blocks_58_": { "name": "transformer_blocks.58." }, "transformer_blocks_59_": { "name": "transformer_blocks.59." }, "transformer_blocks_5_": { "name": "트랜스포머 블록.5." }, "transformer_blocks_6_": { "name": "트랜스포머 블록.6." }, "transformer_blocks_7_": { "name": "트랜스포머 블록.7." }, "transformer_blocks_8_": { "name": "트랜스포머 블록.8." }, "transformer_blocks_9_": { "name": "트랜스포머 블록.9." }, "txt_in_": { "name": "텍스트 입력." }, "txt_norm_": { "name": "텍스트 정규화." } } };
const ModelMergeSD1 = { "display_name": "모델 병합 (SD1)", "inputs": { "input_blocks_0_": { "name": "input_blocks.0." }, "input_blocks_10_": { "name": "input_blocks.10." }, "input_blocks_11_": { "name": "input_blocks.11." }, "input_blocks_1_": { "name": "input_blocks.1." }, "input_blocks_2_": { "name": "input_blocks.2." }, "input_blocks_3_": { "name": "input_blocks.3." }, "input_blocks_4_": { "name": "input_blocks.4." }, "input_blocks_5_": { "name": "input_blocks.5." }, "input_blocks_6_": { "name": "input_blocks.6." }, "input_blocks_7_": { "name": "input_blocks.7." }, "input_blocks_8_": { "name": "input_blocks.8." }, "input_blocks_9_": { "name": "input_blocks.9." }, "label_emb_": { "name": "label_emb." }, "middle_block_0_": { "name": "middle_blocks.0." }, "middle_block_1_": { "name": "middle_blocks.1." }, "middle_block_2_": { "name": "middle_blocks.2." }, "model1": { "name": "모델1" }, "model2": { "name": "모델2" }, "out_": { "name": "out." }, "output_blocks_0_": { "name": "out_blocks.0." }, "output_blocks_10_": { "name": "out_blocks.10." }, "output_blocks_11_": { "name": "out_blocks.11." }, "output_blocks_1_": { "name": "out_blocks.1." }, "output_blocks_2_": { "name": "out_blocks.2." }, "output_blocks_3_": { "name": "out_blocks.3." }, "output_blocks_4_": { "name": "out_blocks.4." }, "output_blocks_5_": { "name": "out_blocks.5." }, "output_blocks_6_": { "name": "out_blocks.6." }, "output_blocks_7_": { "name": "out_blocks.7." }, "output_blocks_8_": { "name": "out_blocks.8." }, "output_blocks_9_": { "name": "out_blocks.9." }, "time_embed_": { "name": "time_embed." } } };
const ModelMergeSD2 = { "display_name": "모델 병합 (SD2)", "inputs": { "input_blocks_0_": { "name": "input_blocks.0." }, "input_blocks_10_": { "name": "input_blocks.10." }, "input_blocks_11_": { "name": "input_blocks.11." }, "input_blocks_1_": { "name": "input_blocks.1." }, "input_blocks_2_": { "name": "input_blocks.2." }, "input_blocks_3_": { "name": "input_blocks.3." }, "input_blocks_4_": { "name": "input_blocks.4." }, "input_blocks_5_": { "name": "input_blocks.5." }, "input_blocks_6_": { "name": "input_blocks.6." }, "input_blocks_7_": { "name": "input_blocks.7." }, "input_blocks_8_": { "name": "input_blocks.8." }, "input_blocks_9_": { "name": "input_blocks.9." }, "label_emb_": { "name": "label_emb." }, "middle_block_0_": { "name": "middle_blocks.0." }, "middle_block_1_": { "name": "middle_blocks.1." }, "middle_block_2_": { "name": "middle_blocks.2." }, "model1": { "name": "모델1" }, "model2": { "name": "모델2" }, "out_": { "name": "out." }, "output_blocks_0_": { "name": "out_blocks.0." }, "output_blocks_10_": { "name": "out_blocks.10." }, "output_blocks_11_": { "name": "out_blocks.11." }, "output_blocks_1_": { "name": "out_blocks.1." }, "output_blocks_2_": { "name": "out_blocks.2." }, "output_blocks_3_": { "name": "out_blocks.3." }, "output_blocks_4_": { "name": "out_blocks.4." }, "output_blocks_5_": { "name": "out_blocks.5." }, "output_blocks_6_": { "name": "out_blocks.6." }, "output_blocks_7_": { "name": "out_blocks.7." }, "output_blocks_8_": { "name": "out_blocks.8." }, "output_blocks_9_": { "name": "out_blocks.9." }, "time_embed_": { "name": "time_embed." } } };
const ModelMergeSD35_Large = { "display_name": "모델 병합 (SD35 Large)", "inputs": { "context_embedder_": { "name": "context_embedder." }, "final_layer_": { "name": "final_layer." }, "joint_blocks_0_": { "name": "joint_blocks.0." }, "joint_blocks_10_": { "name": "joint_blocks.10." }, "joint_blocks_11_": { "name": "joint_blocks.11." }, "joint_blocks_12_": { "name": "joint_blocks.12." }, "joint_blocks_13_": { "name": "joint_blocks.13." }, "joint_blocks_14_": { "name": "joint_blocks.14." }, "joint_blocks_15_": { "name": "joint_blocks.15." }, "joint_blocks_16_": { "name": "joint_blocks.16." }, "joint_blocks_17_": { "name": "joint_blocks.17." }, "joint_blocks_18_": { "name": "joint_blocks.18." }, "joint_blocks_19_": { "name": "joint_blocks.19." }, "joint_blocks_1_": { "name": "joint_blocks.1." }, "joint_blocks_20_": { "name": "joint_blocks.20." }, "joint_blocks_21_": { "name": "joint_blocks.21." }, "joint_blocks_22_": { "name": "joint_blocks.22." }, "joint_blocks_23_": { "name": "joint_blocks.23." }, "joint_blocks_24_": { "name": "joint_blocks.24." }, "joint_blocks_25_": { "name": "joint_blocks.25." }, "joint_blocks_26_": { "name": "joint_blocks.26." }, "joint_blocks_27_": { "name": "joint_blocks.27." }, "joint_blocks_28_": { "name": "joint_blocks.28." }, "joint_blocks_29_": { "name": "joint_blocks.29." }, "joint_blocks_2_": { "name": "joint_blocks.2." }, "joint_blocks_30_": { "name": "joint_blocks.30." }, "joint_blocks_31_": { "name": "joint_blocks.31." }, "joint_blocks_32_": { "name": "joint_blocks.32." }, "joint_blocks_33_": { "name": "joint_blocks.33." }, "joint_blocks_34_": { "name": "joint_blocks.34." }, "joint_blocks_35_": { "name": "joint_blocks.35." }, "joint_blocks_36_": { "name": "joint_blocks.36." }, "joint_blocks_37_": { "name": "joint_blocks.37." }, "joint_blocks_3_": { "name": "joint_blocks.3." }, "joint_blocks_4_": { "name": "joint_blocks.4." }, "joint_blocks_5_": { "name": "joint_blocks.5." }, "joint_blocks_6_": { "name": "joint_blocks.6." }, "joint_blocks_7_": { "name": "joint_blocks.7." }, "joint_blocks_8_": { "name": "joint_blocks.8." }, "joint_blocks_9_": { "name": "joint_blocks.9." }, "model1": { "name": "모델1" }, "model2": { "name": "모델2" }, "pos_embed_": { "name": "pos_embed." }, "t_embedder_": { "name": "t_embedder." }, "x_embedder_": { "name": "x_embedder." }, "y_embedder_": { "name": "y_embedder." } } };
const ModelMergeSD3_2B = { "display_name": "모델 병합 (SD3 2B)", "inputs": { "context_embedder_": { "name": "context_embedder." }, "final_layer_": { "name": "final_layer." }, "joint_blocks_0_": { "name": "joint_blocks.0." }, "joint_blocks_10_": { "name": "joint_blocks.10." }, "joint_blocks_11_": { "name": "joint_blocks.11." }, "joint_blocks_12_": { "name": "joint_blocks.12." }, "joint_blocks_13_": { "name": "joint_blocks.13." }, "joint_blocks_14_": { "name": "joint_blocks.14." }, "joint_blocks_15_": { "name": "joint_blocks.15." }, "joint_blocks_16_": { "name": "joint_blocks.16." }, "joint_blocks_17_": { "name": "joint_blocks.17." }, "joint_blocks_18_": { "name": "joint_blocks.18." }, "joint_blocks_19_": { "name": "joint_blocks.19." }, "joint_blocks_1_": { "name": "joint_blocks.1." }, "joint_blocks_20_": { "name": "joint_blocks.20." }, "joint_blocks_21_": { "name": "joint_blocks.21." }, "joint_blocks_22_": { "name": "joint_blocks.22." }, "joint_blocks_23_": { "name": "joint_blocks.23." }, "joint_blocks_2_": { "name": "joint_blocks.2." }, "joint_blocks_3_": { "name": "joint_blocks.3." }, "joint_blocks_4_": { "name": "joint_blocks.4." }, "joint_blocks_5_": { "name": "joint_blocks.5." }, "joint_blocks_6_": { "name": "joint_blocks.6." }, "joint_blocks_7_": { "name": "joint_blocks.7." }, "joint_blocks_8_": { "name": "joint_blocks.8." }, "joint_blocks_9_": { "name": "joint_blocks.9." }, "model1": { "name": "모델1" }, "model2": { "name": "모델2" }, "pos_embed_": { "name": "pos_embed." }, "t_embedder_": { "name": "t_embedder." }, "x_embedder_": { "name": "x_embedder." }, "y_embedder_": { "name": "y_embedder." } } };
const ModelMergeSDXL = { "display_name": "모델 병합 (SDXL)", "inputs": { "input_blocks_0": { "name": "input_blocks.0" }, "input_blocks_1": { "name": "input_blocks.1" }, "input_blocks_2": { "name": "input_blocks.2" }, "input_blocks_3": { "name": "input_blocks.3" }, "input_blocks_4": { "name": "input_blocks.4" }, "input_blocks_5": { "name": "input_blocks.5" }, "input_blocks_6": { "name": "input_blocks.6" }, "input_blocks_7": { "name": "input_blocks.7" }, "input_blocks_8": { "name": "input_blocks.8" }, "label_emb_": { "name": "label_emb." }, "middle_block_0": { "name": "middle_block.0" }, "middle_block_1": { "name": "middle_block.1" }, "middle_block_2": { "name": "middle_block.2" }, "model1": { "name": "모델1" }, "model2": { "name": "모델2" }, "out_": { "name": "out." }, "output_blocks_0": { "name": "output_blocks.0" }, "output_blocks_1": { "name": "output_blocks.1" }, "output_blocks_2": { "name": "output_blocks.2" }, "output_blocks_3": { "name": "output_blocks.3" }, "output_blocks_4": { "name": "output_blocks.4" }, "output_blocks_5": { "name": "output_blocks.5" }, "output_blocks_6": { "name": "output_blocks.6" }, "output_blocks_7": { "name": "output_blocks.7" }, "output_blocks_8": { "name": "output_blocks.8" }, "time_embed_": { "name": "time_embed." } } };
const ModelMergeSimple = { "display_name": "모델 병합 (단순)", "inputs": { "model1": { "name": "모델1" }, "model2": { "name": "모델2" }, "ratio": { "name": "비율" } } };
const ModelMergeSubtract = { "display_name": "모델 병합 (빼기)", "inputs": { "model1": { "name": "모델1" }, "model2": { "name": "모델2" }, "multiplier": { "name": "배율" } } };
const ModelMergeWAN2_1 = { "description": "1.3B 모델은 30개의 블록, 14B 모델은 40개의 블록을 가지고 있습니다. 이미지 투 비디오 모델에는 추가적인 img_emb가 있습니다.", "display_name": "모델 병합 (WAN2.1)", "inputs": { "blocks_0_": { "name": "blocks.0." }, "blocks_10_": { "name": "blocks.10." }, "blocks_11_": { "name": "blocks.11." }, "blocks_12_": { "name": "blocks.12." }, "blocks_13_": { "name": "blocks.13." }, "blocks_14_": { "name": "blocks.14." }, "blocks_15_": { "name": "blocks.15." }, "blocks_16_": { "name": "blocks.16." }, "blocks_17_": { "name": "blocks.17." }, "blocks_18_": { "name": "blocks.18." }, "blocks_19_": { "name": "blocks.19." }, "blocks_1_": { "name": "blocks.1." }, "blocks_20_": { "name": "blocks.20." }, "blocks_21_": { "name": "blocks.21." }, "blocks_22_": { "name": "blocks.22." }, "blocks_23_": { "name": "blocks.23." }, "blocks_24_": { "name": "blocks.24." }, "blocks_25_": { "name": "blocks.25." }, "blocks_26_": { "name": "blocks.26." }, "blocks_27_": { "name": "blocks.27." }, "blocks_28_": { "name": "blocks.28." }, "blocks_29_": { "name": "blocks.29." }, "blocks_2_": { "name": "blocks.2." }, "blocks_30_": { "name": "blocks.30." }, "blocks_31_": { "name": "blocks.31." }, "blocks_32_": { "name": "blocks.32." }, "blocks_33_": { "name": "blocks.33." }, "blocks_34_": { "name": "blocks.34." }, "blocks_35_": { "name": "blocks.35." }, "blocks_36_": { "name": "blocks.36." }, "blocks_37_": { "name": "blocks.37." }, "blocks_38_": { "name": "blocks.38." }, "blocks_39_": { "name": "blocks.39." }, "blocks_3_": { "name": "blocks.3." }, "blocks_4_": { "name": "blocks.4." }, "blocks_5_": { "name": "blocks.5." }, "blocks_6_": { "name": "blocks.6." }, "blocks_7_": { "name": "blocks.7." }, "blocks_8_": { "name": "blocks.8." }, "blocks_9_": { "name": "blocks.9." }, "head_": { "name": "head." }, "img_emb_": { "name": "img_emb." }, "model1": { "name": "모델1" }, "model2": { "name": "모델2" }, "patch_embedding_": { "name": "patch_embedding." }, "text_embedding_": { "name": "text_embedding." }, "time_embedding_": { "name": "time_embedding." }, "time_projection_": { "name": "time_projection." } } };
const ModelPatchLoader = { "display_name": "모델 패치 로더", "inputs": { "name": { "name": "이름" } } };
const ModelSamplingAuraFlow = { "display_name": "모델 샘플링 (AuraFlow)", "inputs": { "model": { "name": "모델" }, "shift": { "name": "시프트" } } };
const ModelSamplingContinuousEDM = { "display_name": "모델 샘플링 (연속 EDM)", "inputs": { "model": { "name": "모델" }, "sampling": { "name": "샘플링" }, "sigma_max": { "name": "최대 시그마" }, "sigma_min": { "name": "최소 시그마" } } };
const ModelSamplingContinuousV = { "display_name": "모델 샘플링 (연속 V)", "inputs": { "model": { "name": "모델" }, "sampling": { "name": "샘플링" }, "sigma_max": { "name": "최대 시그마" }, "sigma_min": { "name": "최소 시그마" } } };
const ModelSamplingDiscrete = { "display_name": "모델 샘플링 (이산)", "inputs": { "model": { "name": "모델" }, "sampling": { "name": "샘플링" }, "zsnr": { "name": "zsnr" } } };
const ModelSamplingFlux = { "display_name": "모델 샘플링 (FLUX)", "inputs": { "base_shift": { "name": "기본 시프트" }, "height": { "name": "높이" }, "max_shift": { "name": "최대 시프트" }, "model": { "name": "모델" }, "width": { "name": "너비" } } };
const ModelSamplingLTXV = { "display_name": "모델 샘플링 (LTXV)", "inputs": { "base_shift": { "name": "기반 시프트" }, "latent": { "name": "잠재 비디오" }, "max_shift": { "name": "최대 시프트" }, "model": { "name": "모델" } }, "outputs": { "0": { "tooltip": null } } };
const ModelSamplingSD3 = { "display_name": "모델 샘플링 (SD3)", "inputs": { "model": { "name": "모델" }, "shift": { "name": "시프트" } } };
const ModelSamplingStableCascade = { "display_name": "모델 샘플링 (StableCascade)", "inputs": { "model": { "name": "모델" }, "shift": { "name": "시프트" } } };
const ModelSave = { "display_name": "모델 저장", "inputs": { "filename_prefix": { "name": "파일명 접두사" }, "model": { "name": "모델" } } };
const MoonvalleyImg2VideoNode = { "description": "문밸리 마레이 이미지 투 비디오 노드", "display_name": "문밸리 마레이 이미지 투 비디오", "inputs": { "control_after_generate": { "name": "생성 후 제어" }, "image": { "name": "이미지", "tooltip": "비디오 생성에 사용되는 참조 이미지" }, "negative_prompt": { "name": "네거티브 프롬프트", "tooltip": "네거티브 프롬프트 텍스트" }, "prompt": { "name": "프롬프트" }, "prompt_adherence": { "name": "프롬프트 준수도", "tooltip": "생성 제어를 위한 가이던스 스케일" }, "resolution": { "name": "해상도", "tooltip": "출력 비디오의 해상도" }, "seed": { "name": "시드", "tooltip": "랜덤 시드 값" }, "steps": { "name": "스텝", "tooltip": "노이즈 제거 스텝 수" } }, "outputs": { "0": { "tooltip": null } } };
const MoonvalleyTxt2VideoNode = { "display_name": "문밸리 마레이 텍스트 투 비디오", "inputs": { "control_after_generate": { "name": "생성 후 제어" }, "negative_prompt": { "name": "네거티브 프롬프트", "tooltip": "네거티브 프롬프트 텍스트" }, "prompt": { "name": "프롬프트" }, "prompt_adherence": { "name": "프롬프트 준수도", "tooltip": "생성 제어를 위한 가이던스 스케일" }, "resolution": { "name": "해상도", "tooltip": "출력 비디오의 해상도" }, "seed": { "name": "시드", "tooltip": "랜덤 시드 값" }, "steps": { "name": "스텝", "tooltip": "추론 단계" } }, "outputs": { "0": { "tooltip": null } } };
const MoonvalleyVideo2VideoNode = { "display_name": "Moonvalley Marey 비디오 투 비디오", "inputs": { "control_type": { "name": "제어 유형" }, "motion_intensity": { "name": "모션 강도", "tooltip": "'모션 전송' 제어 유형일 때만 사용됩니다" }, "negative_prompt": { "name": "네거티브 프롬프트", "tooltip": "네거티브 프롬프트 텍스트" }, "prompt": { "name": "프롬프트", "tooltip": "생성할 비디오를 설명합니다" }, "seed": { "name": "시드", "tooltip": "랜덤 시드 값" }, "steps": { "name": "단계", "tooltip": "추론 단계 수" }, "video": { "name": "비디오", "tooltip": "출력 비디오를 생성하는 데 사용되는 참조 비디오. 최소 5초 이상이어야 합니다. 5초보다 긴 비디오는 자동으로 잘립니다. MP4 형식만 지원됩니다." } }, "outputs": { "0": { "tooltip": null } } };
const Morphology = { "display_name": "이미지 형태 변환", "inputs": { "image": { "name": "이미지" }, "kernel_size": { "name": "커널 크기" }, "operation": { "name": "연산" } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIChatConfig = { "description": "OpenAI 채팅 노드에 대한 고급 구성 옵션을 지정할 수 있습니다.", "display_name": "OpenAI ChatGPT 고급 옵션", "inputs": { "instructions": { "name": "지침", "tooltip": "모델이 응답을 생성하는 방법에 대한 지침" }, "max_output_tokens": { "name": "최대 출력 토큰", "tooltip": "응답에 대해 생성될 수 있는 토큰 수의 상한값으로, 표시되는 출력 토큰을 포함합니다" }, "truncation": { "name": "트렁케이션", "tooltip": "모델 응답에 사용할 트렁케이션 전략. auto: 이 응답과 이전 응답의 컨텍스트가 모델의 컨텍스트 창 크기를 초과하면 모델은 대화 중간의 입력 항목을 삭제하여 컨텍스트 창에 맞도록 응답을 자릅니다. disabled: 모델 응답이 모델의 컨텍스트 창 크기를 초과하면 요청이 400 오류와 함께 실패합니다" } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIChatNode = { "description": "OpenAI 모델에서 텍스트 응답을 생성합니다.", "display_name": "OpenAI ChatGPT", "inputs": { "advanced_options": { "name": "고급 옵션", "tooltip": "모델에 대한 선택적 구성. OpenAI 채팅 고급 옵션 노드의 입력을 허용합니다." }, "files": { "name": "파일", "tooltip": "모델의 컨텍스트로 사용할 선택적 파일(들). OpenAI 채팅 입력 파일 노드의 입력을 허용합니다." }, "images": { "name": "이미지", "tooltip": "모델의 컨텍스트로 사용할 선택적 이미지(들). 여러 이미지를 포함하려면 배치 이미지 노드를 사용할 수 있습니다." }, "model": { "name": "모델", "tooltip": "응답을 생성하는 데 사용되는 모델" }, "persist_context": { "name": "컨텍스트 유지", "tooltip": "이 매개변수는 더 이상 사용되지 않으며 효과가 없습니다." }, "prompt": { "name": "프롬프트", "tooltip": "모델에 대한 텍스트 입력으로, 응답을 생성하는 데 사용됩니다." } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIDalle2 = { "description": "OpenAI의 DALL·E 2 엔드포인트를 통해 동기적으로 이미지를 생성합니다.", "display_name": "OpenAI DALL·E 2", "inputs": { "control_after_generate": { "name": "생성 후 제어" }, "image": { "name": "이미지", "tooltip": "이미지 편집을 위한 선택적 참조 이미지." }, "mask": { "name": "마스크", "tooltip": "인페인팅을 위한 선택적 마스크 (흰색 영역이 대체됨)" }, "n": { "name": "개수", "tooltip": "생성할 이미지 수" }, "prompt": { "name": "프롬프트", "tooltip": "DALL·E를 위한 텍스트 프롬프트" }, "seed": { "name": "시드", "tooltip": "백엔드에 아직 구현되지 않음" }, "size": { "name": "크기", "tooltip": "이미지 크기" } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIDalle3 = { "description": "OpenAI의 DALL·E 3 엔드포인트를 통해 동기적으로 이미지를 생성합니다.", "display_name": "OpenAI DALL·E 3", "inputs": { "control_after_generate": { "name": "생성 후 제어" }, "prompt": { "name": "프롬프트", "tooltip": "DALL·E를 위한 텍스트 프롬프트" }, "quality": { "name": "품질", "tooltip": "이미지 품질" }, "seed": { "name": "시드", "tooltip": "백엔드에 아직 구현되지 않음" }, "size": { "name": "크기", "tooltip": "이미지 크기" }, "style": { "name": "스타일", "tooltip": "Vivid는 모델이 하이퍼리얼하고 극적인 이미지를 생성하도록 유도합니다. Natural은 모델이 더 자연스럽고 덜 하이퍼리얼한 이미지를 생성하도록 합니다." } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIGPTImage1 = { "description": "OpenAI의 GPT Image 1 엔드포인트를 통해 동기적으로 이미지를 생성합니다.", "display_name": "OpenAI GPT Image 1", "inputs": { "background": { "name": "배경", "tooltip": "배경이 있는 이미지 또는 없는 이미지를 반환" }, "control_after_generate": { "name": "생성 후 제어" }, "image": { "name": "참조 이미지", "tooltip": "이미지 편집을 위한 선택적 참조 이미지." }, "mask": { "name": "마스크", "tooltip": "인페인팅을 위한 선택적 마스크 (흰색 영역이 대체됨)" }, "n": { "name": "개수", "tooltip": "생성할 이미지의 수" }, "prompt": { "name": "프롬프트", "tooltip": "GPT Image 1을 위한 텍스트 프롬프트" }, "quality": { "name": "품질", "tooltip": "이미지 품질, 비용과 생성 시간에 영향을 줍니다." }, "seed": { "name": "시드", "tooltip": "백엔드에 아직 구현되지 않음" }, "size": { "name": "크기", "tooltip": "이미지 크기" } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIInputFiles = { "description": "OpenAI 채팅 노드에 대한 입력으로 포함할 입력 파일(텍스트, PDF 등)을 로드하고 준비합니다. 파일은 OpenAI 모델이 응답을 생성할 때 읽힙니다. 🛈 팁: 다른 OpenAI 입력 파일 노드와 함께 연결하여 사용할 수 있습니다.", "display_name": "OpenAI ChatGPT 입력 파일", "inputs": { "OPENAI_INPUT_FILES": { "name": "OPENAI_INPUT_FILES", "tooltip": "이 노드에서 로드된 파일과 함께 배치할 선택적 추가 파일(들). 단일 메시지에 여러 입력 파일을 포함할 수 있도록 입력 파일을 연결할 수 있습니다." }, "file": { "name": "파일", "tooltip": "모델의 컨텍스트로 포함할 입력 파일. 현재는 텍스트(.txt) 및 PDF(.pdf) 파일만 허용됩니다." } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIVideoSora2 = { "description": "OpenAI 비디오 및 오디오 생성.", "display_name": "OpenAI Sora - 비디오", "inputs": { "control_after_generate": { "name": "생성 후 제어" }, "duration": { "name": "지속 시간" }, "image": { "name": "이미지" }, "model": { "name": "모델" }, "prompt": { "name": "프롬프트", "tooltip": "안내 텍스트; 입력 이미지가 있을 경우 비워둘 수 있습니다." }, "seed": { "name": "시드", "tooltip": "노드 재실행 여부를 결정하는 시드; 실제 결과는 시드와 관계없이 비결정적입니다." }, "size": { "name": "크기" } }, "outputs": { "0": { "tooltip": null } } };
const OptimalStepsScheduler = { "display_name": "OptimalStepsScheduler", "inputs": { "denoise": { "name": "디노이즈" }, "model_type": { "name": "모델 종류" }, "steps": { "name": "스텝" } }, "outputs": { "0": { "tooltip": null } } };
const PairConditioningCombine = { "display_name": "조건 쌍 (결합)", "inputs": { "negative_A": { "name": "부정 조건 A" }, "negative_B": { "name": "부정 조건 B" }, "positive_A": { "name": "긍정 조건 A" }, "positive_B": { "name": "긍정 조건 B" } }, "outputs": { "0": { "name": "긍정 조건" }, "1": { "name": "부정 조건" } } };
const PairConditioningSetDefaultCombine = { "display_name": "조건 쌍 (기본 결합 설정)", "inputs": { "hooks": { "name": "후크" }, "negative": { "name": "부정 조건" }, "negative_DEFAULT": { "name": "기본 부정 조건" }, "positive": { "name": "긍정 조건" }, "positive_DEFAULT": { "name": "기본 긍정 조건" } }, "outputs": { "0": { "name": "긍정 조건" }, "1": { "name": "부정 조건" } } };
const PairConditioningSetProperties = { "display_name": "조건 쌍 (속성 설정)", "inputs": { "hooks": { "name": "후크" }, "mask": { "name": "마스크" }, "negative_NEW": { "name": "새 부정 조건" }, "positive_NEW": { "name": "새 긍정 조건" }, "set_cond_area": { "name": "조건 영역 설정" }, "strength": { "name": "강도" }, "timesteps": { "name": "타임스텝 범위" } }, "outputs": { "0": { "name": "긍정 조건" }, "1": { "name": "부정 조건" } } };
const PairConditioningSetPropertiesAndCombine = { "display_name": "조건 쌍 (속성 설정 및 결합)", "inputs": { "hooks": { "name": "후크" }, "mask": { "name": "마스크" }, "negative": { "name": "부정 조건" }, "negative_NEW": { "name": "새 부정 조건" }, "positive": { "name": "긍정 조건" }, "positive_NEW": { "name": "새 긍정 조건" }, "set_cond_area": { "name": "조건 영역 설정" }, "strength": { "name": "강도" }, "timesteps": { "name": "타임스텝 범위" } }, "outputs": { "0": { "name": "긍정 조건" }, "1": { "name": "부정 조건" } } };
const PatchModelAddDownscale = { "display_name": "다운스케일 추가 모델 패치 (Kohya Deep Shrink)", "inputs": { "block_number": { "name": "블록 번호" }, "downscale_after_skip": { "name": "스킵 후 다운스케일" }, "downscale_factor": { "name": "다운스케일 배율" }, "downscale_method": { "name": "다운스케일 방법" }, "end_percent": { "name": "종료 퍼센트" }, "model": { "name": "모델" }, "start_percent": { "name": "시작 퍼센트" }, "upscale_method": { "name": "업스케일 방법" } }, "outputs": { "0": { "tooltip": null } } };
const PerpNeg = { "display_name": "Perp-Neg (PerpNegGuider에 의해 지원 중단됨)", "inputs": { "empty_conditioning": { "name": "빈 조건" }, "model": { "name": "모델" }, "neg_scale": { "name": "부정 스케일" } }, "outputs": { "0": { "tooltip": null } } };
const PerpNegGuider = { "display_name": "PerpNeg 가이드", "inputs": { "cfg": { "name": "cfg" }, "empty_conditioning": { "name": "빈 조건" }, "model": { "name": "모델" }, "neg_scale": { "name": "부정 스케일" }, "negative": { "name": "부정 조건" }, "positive": { "name": "긍정 조건" } }, "outputs": { "0": { "tooltip": null } } };
const PerturbedAttentionGuidance = { "display_name": "교란 어텐션 유도 (PAG)", "inputs": { "model": { "name": "모델" }, "scale": { "name": "스케일" } }, "outputs": { "0": { "tooltip": null } } };
const PhotoMakerEncode = { "display_name": "포토메이커 인코딩", "inputs": { "clip": { "name": "clip" }, "image": { "name": "이미지" }, "photomaker": { "name": "포토메이커 모델" }, "text": { "name": "텍스트" } }, "outputs": { "0": { "tooltip": null } } };
const PhotoMakerLoader = { "display_name": "포토메이커 로드", "inputs": { "photomaker_model_name": { "name": "포토메이커 파일명" } }, "outputs": { "0": { "tooltip": null } } };
const PixverseImageToVideoNode = { "description": "프롬프트와 output_size에 따라 동기적으로 비디오를 생성합니다.", "display_name": "PixVerse 이미지에서 비디오로", "inputs": { "control_after_generate": { "name": "생성 후 제어" }, "duration_seconds": { "name": "길이(초)" }, "image": { "name": "이미지" }, "motion_mode": { "name": "모션 모드" }, "negative_prompt": { "name": "부정 프롬프트", "tooltip": "이미지에서 원하지 않는 요소에 대한 선택적 텍스트 설명." }, "pixverse_template": { "name": "PixVerse 템플릿", "tooltip": "생성 스타일에 영향을 주는 선택적 템플릿으로, PixVerse Template 노드에서 생성됩니다." }, "prompt": { "name": "프롬프트", "tooltip": "비디오 생성을 위한 프롬프트" }, "quality": { "name": "품질" }, "seed": { "name": "시드", "tooltip": "비디오 생성을 위한 시드." } }, "outputs": { "0": { "tooltip": null } } };
const PixverseTemplateNode = { "display_name": "PixVerse 템플릿", "inputs": { "template": { "name": "템플릿" } }, "outputs": { "0": { "name": "pixverse 템플릿", "tooltip": null } } };
const PixverseTextToVideoNode = { "description": "프롬프트와 output_size에 따라 동기적으로 비디오를 생성합니다.", "display_name": "PixVerse 텍스트 투 비디오", "inputs": { "aspect_ratio": { "name": "화면 비율" }, "control_after_generate": { "name": "생성 후 제어" }, "duration_seconds": { "name": "길이(초)" }, "motion_mode": { "name": "모션 모드" }, "negative_prompt": { "name": "부정 프롬프트", "tooltip": "이미지에서 원하지 않는 요소에 대한 선택적 텍스트 설명." }, "pixverse_template": { "name": "PixVerse 템플릿", "tooltip": "생성 스타일에 영향을 주는 선택적 템플릿으로, PixVerse Template 노드에서 생성됩니다." }, "prompt": { "name": "프롬프트", "tooltip": "비디오 생성을 위한 프롬프트" }, "quality": { "name": "품질" }, "seed": { "name": "시드", "tooltip": "비디오 생성을 위한 시드." } }, "outputs": { "0": { "tooltip": null } } };
const PixverseTransitionVideoNode = { "description": "프롬프트와 output_size에 따라 동기적으로 비디오를 생성합니다.", "display_name": "PixVerse 전환 비디오", "inputs": { "control_after_generate": { "name": "생성 후 제어" }, "duration_seconds": { "name": "길이(초)" }, "first_frame": { "name": "시작 프레임" }, "last_frame": { "name": "끝 프레임" }, "motion_mode": { "name": "모션 모드" }, "negative_prompt": { "name": "부정 프롬프트", "tooltip": "이미지에서 원하지 않는 요소에 대한 선택적 텍스트 설명입니다." }, "prompt": { "name": "프롬프트", "tooltip": "비디오 생성을 위한 프롬프트" }, "quality": { "name": "품질" }, "seed": { "name": "시드", "tooltip": "비디오 생성을 위한 시드." } }, "outputs": { "0": { "tooltip": null } } };
const PolyexponentialScheduler = { "display_name": "다항 지수 스케줄러", "inputs": { "rho": { "name": "rho" }, "sigma_max": { "name": "최대 시그마" }, "sigma_min": { "name": "최소 시그마" }, "steps": { "name": "스텝 수" } } };
const PorterDuffImageComposite = { "display_name": "포터-더프 이미지 합성", "inputs": { "destination": { "name": "대상" }, "destination_alpha": { "name": "대상 알파" }, "mode": { "name": "모드" }, "source": { "name": "원본" }, "source_alpha": { "name": "원본 알파" } }, "outputs": { "0": { "tooltip": null }, "1": { "tooltip": null } } };
const Preview3D = { "display_name": "3D 미리보기", "inputs": { "camera_info": { "name": "카메라 정보" }, "image": { "name": "이미지" }, "model_file": { "name": "모델 파일" } } };
const PreviewAny = { "display_name": "미리보기 아무거나", "inputs": { "preview": {}, "source": { "name": "소스" } } };
const PreviewAudio = { "display_name": "오디오 미리듣기", "inputs": { "audio": { "name": "오디오" }, "audioUI": { "name": "오디오UI" } } };
const PreviewImage = { "description": "입력 이미지를 ComfyUI 의 임시(temp) 폴더에 저장합니다.", "display_name": "이미지 미리보기", "inputs": { "images": { "name": "이미지" } } };
const PrimitiveBoolean = { "display_name": "논리값", "inputs": { "value": { "name": "값" } }, "outputs": { "0": { "tooltip": null } } };
const PrimitiveFloat = { "display_name": "실수", "inputs": { "value": { "name": "값" } }, "outputs": { "0": { "tooltip": null } } };
const PrimitiveInt = { "display_name": "정수", "inputs": { "control_after_generate": { "name": "생성 후 제어" }, "value": { "name": "값" } }, "outputs": { "0": { "tooltip": null } } };
const PrimitiveString = { "display_name": "문자열", "inputs": { "value": { "name": "값" } }, "outputs": { "0": { "tooltip": null } } };
const PrimitiveStringMultiline = { "display_name": "문자열 (여러 줄)", "inputs": { "value": { "name": "값" } }, "outputs": { "0": { "tooltip": null } } };
const QuadrupleCLIPLoader = { "description": "[레시피]\n\nhidream: long clip-l, long clip-g, t5xxl, llama_8b_3.1_instruct", "display_name": "QuadrupleCLIPLoader", "inputs": { "clip_name1": { "name": "clip 이름 1" }, "clip_name2": { "name": "clip 이름 2" }, "clip_name3": { "name": "clip 이름 3" }, "clip_name4": { "name": "clip 이름 4" } }, "outputs": { "0": { "tooltip": null } } };
const QwenImageDiffsynthControlnet = { "display_name": "QwenImageDiffsynthControlnet", "inputs": { "image": { "name": "이미지" }, "mask": { "name": "마스크" }, "model": { "name": "모델" }, "model_patch": { "name": "모델 패치" }, "strength": { "name": "강도" }, "vae": { "name": "VAE" } } };
const RandomNoise = { "display_name": "무작위 노이즈", "inputs": { "control_after_generate": { "name": "생성 후 제어" }, "noise_seed": { "name": "노이즈 시드" } } };
const RebatchImages = { "display_name": "이미지 배치 재배치", "inputs": { "batch_size": { "name": "배치 크기" }, "images": { "name": "이미지" } }, "outputs": { "0": { "tooltip": null } } };
const RebatchLatents = { "display_name": "잠재 데이터 배치 재배치", "inputs": { "batch_size": { "name": "배치 크기" }, "latents": { "name": "잠재 데이터" } }, "outputs": { "0": { "tooltip": null } } };
const RecordAudio = { "display_name": "오디오 녹음", "inputs": { "audio": { "name": "오디오" } } };
const RecraftColorRGB = { "description": "특정 RGB 값을 선택하여 Recraft Color를 생성합니다.", "display_name": "Recraft Color RGB", "inputs": { "b": { "name": "b", "tooltip": "색상의 파란색 값입니다." }, "g": { "name": "g", "tooltip": "색상의 초록색 값입니다." }, "r": { "name": "r", "tooltip": "색상의 빨간색 값입니다." }, "recraft_color": { "name": "recraft 색" } }, "outputs": { "0": { "name": "recraft 색", "tooltip": null } } };
const RecraftControls = { "description": "Recraft 생성을 커스터마이즈하기 위한 'Recraft 제어'을 생성합니다.", "display_name": "Recraft 제어", "inputs": { "background_color": { "name": "배경색" }, "colors": { "name": "색상" } }, "outputs": { "0": { "name": "recraft 제어", "tooltip": null } } };
const RecraftCreativeUpscaleNode = { "description": "이미지를 동기적으로 업스케일합니다.\n‘크리에이티브 업스케일’ 도구를 사용하여 주어진 래스터 이미지를 향상시키고, 작은 디테일과 얼굴을 정교하게 개선하면서 해상도를 높입니다.", "display_name": "Recraft 크리에이티브 업스케일 이미지", "inputs": { "image": { "name": "이미지" } }, "outputs": { "0": { "tooltip": null } } };
const RecraftCrispUpscaleNode = { "description": "이미지를 동기적으로 업스케일합니다.\n‘선명 업스케일’ 도구를 사용하여 주어진 래스터 이미지를 향상시키고, 해상도를 높여 이미지를 더 선명하고 깨끗하게 만듭니다.", "display_name": "Recraft 선명 업스케일 이미지", "inputs": { "image": { "name": "이미지" } }, "outputs": { "0": { "tooltip": null } } };
const RecraftImageInpaintingNode = { "description": "프롬프트와 마스크를 기반으로 이미지를 수정합니다.", "display_name": "Recraft 이미지 인페인팅", "inputs": { "control_after_generate": { "name": "생성 후 제어" }, "image": { "name": "이미지" }, "mask": { "name": "마스크" }, "n": { "name": "n", "tooltip": "생성할 이미지의 개수입니다." }, "negative_prompt": { "name": "부정 프롬프트", "tooltip": "이미지에서 원하지 않는 요소에 대한 선택적 텍스트 설명입니다." }, "prompt": { "name": "프롬프트", "tooltip": "이미지 생성을 위한 프롬프트입니다." }, "recraft_style": { "name": "recraft 스타일" }, "seed": { "name": "시드", "tooltip": "노드가 다시 실행되어야 하는지 결정하는 시드입니다. 실제 결과는 시드와 관계없이 비결정적입니다." } }, "outputs": { "0": { "tooltip": null } } };
const RecraftImageToImageNode = { "description": "프롬프트와 강도를 기반으로 이미지를 수정합니다.", "display_name": "Recraft 이미지 생성 (이미지 → 이미지)", "inputs": { "control_after_generate": { "name": "생성 후 제어" }, "image": { "name": "이미지" }, "n": { "name": "개수", "tooltip": "생성할 이미지의 수입니다." }, "negative_prompt": { "name": "부정 프롬프트", "tooltip": "이미지에서 원하지 않는 요소에 대한 선택적 텍스트 설명입니다." }, "prompt": { "name": "프롬프트", "tooltip": "이미지 생성을 위한 프롬프트입니다." }, "recraft_controls": { "name": "recraft 제어", "tooltip": "Recraft 제어 노드를 통한 생성에 대한 추가 제어(선택 사항)입니다." }, "recraft_style": { "name": "recraft 스타일" }, "seed": { "name": "시드", "tooltip": "노드가 다시 실행되어야 하는지 결정하는 시드입니다. 실제 결과는 시드와 관계없이 비결정적입니다." }, "strength": { "name": "강도", "tooltip": "원본 이미지와의 차이를 정의합니다. [0, 1] 범위 내에서, 0은 거의 동일함을, 1은 매우 다름을 의미합니다." } }, "outputs": { "0": { "tooltip": null } } };
const RecraftRemoveBackgroundNode = { "description": "이미지에서 배경을 제거하고, 처리된 이미지와 mask를 반환합니다.", "display_name": "Recraft 배경 제거", "inputs": { "image": { "name": "이미지" } }, "outputs": { "0": { "tooltip": null }, "1": { "tooltip": null } } };
const RecraftReplaceBackgroundNode = { "description": "제공된 프롬프트를 기반으로 이미지의 배경을 교체합니다.", "display_name": "Recraft 배경 교체", "inputs": { "control_after_generate": { "name": "생성 후 제어" }, "image": { "name": "이미지" }, "n": { "name": "개수", "tooltip": "생성할 이미지의 수입니다." }, "negative_prompt": { "name": "부정 프롬프트", "tooltip": "이미지에서 원하지 않는 요소에 대한 선택적 텍스트 설명입니다." }, "prompt": { "name": "프롬프트", "tooltip": "이미지 생성을 위한 프롬프트입니다." }, "recraft_style": { "name": "recraft 스타일" }, "seed": { "name": "시드", "tooltip": "노드를 다시 실행할지 결정하는 시드입니다. 실제 결과는 시드와 상관없이 비결정적입니다." } }, "outputs": { "0": { "tooltip": null } } };
const RecraftStyleV3DigitalIllustration = { "description": "realistic_image 스타일과 선택적 하위 스타일을 선택하세요.", "display_name": "Recraft 스타일 - 디지털 일러스트레이션", "inputs": { "substyle": { "name": "하위 스타일" } }, "outputs": { "0": { "name": "recraft 스타일", "tooltip": null } } };
const RecraftStyleV3InfiniteStyleLibrary = { "description": "Recraft의 무한 스타일 라이브러리에서 기존 UUID를 기반으로 스타일을 선택합니다.", "display_name": "Recraft 스타일 - 무한 스타일 라이브러리", "inputs": { "style_id": { "name": "스타일 ID", "tooltip": "무한 스타일 라이브러리의 스타일 UUID입니다." } }, "outputs": { "0": { "name": "recraft 스타일", "tooltip": null } } };
const RecraftStyleV3LogoRaster = { "description": "realistic_image 스타일과 선택적 하위 스타일을 선택하세요.", "display_name": "Recraft 스타일 - 로고 래스터", "inputs": { "substyle": { "name": "하위 스타일" } }, "outputs": { "0": { "name": "recraft 스타일", "tooltip": null } } };
const RecraftStyleV3RealisticImage = { "description": "realistic_image 스타일과 선택적 하위 스타일을 선택하세요.", "display_name": "Recraft 스타일 - 사실적인 이미지", "inputs": { "substyle": { "name": "하위 스타일" } }, "outputs": { "0": { "name": "recraft 스타일", "tooltip": null } } };
const RecraftTextToImageNode = { "description": "프롬프트와 해상도에 따라 이미지를 동기적으로 생성합니다.", "display_name": "Recraft 이미지 생성 (텍스트 → 이미지)", "inputs": { "control_after_generate": { "name": "생성 후 제어" }, "n": { "name": "개수", "tooltip": "생성할 이미지의 개수입니다." }, "negative_prompt": { "name": "부정 프롬프트", "tooltip": "이미지에서 원하지 않는 요소에 대한 선택적 텍스트 설명입니다." }, "prompt": { "name": "프롬프트", "tooltip": "이미지 생성을 위한 프롬프트입니다." }, "recraft_controls": { "name": "recraft 제어", "tooltip": "Recraft 제어 노드를 통한 생성에 대한 추가 제어(선택 사항)입니다." }, "recraft_style": { "name": "recraft 스타일" }, "seed": { "name": "시드", "tooltip": "노드를 다시 실행할지 결정하는 시드입니다. 실제 결과는 시드와 관계없이 비결정적입니다." }, "size": { "name": "크기", "tooltip": "생성된 이미지의 크기입니다." } }, "outputs": { "0": { "tooltip": null } } };
const RecraftTextToVectorNode = { "description": "프롬프트와 해상도에 따라 SVG를 동기적으로 생성합니다.", "display_name": "Recraft 벡터 생성 (텍스트 → 벡터)", "inputs": { "control_after_generate": { "name": "생성 후 제어" }, "n": { "name": "개수", "tooltip": "생성할 이미지의 개수입니다." }, "negative_prompt": { "name": "부정 프롬프트", "tooltip": "이미지에서 원하지 않는 요소에 대한 선택적 텍스트 설명입니다." }, "prompt": { "name": "프롬프트", "tooltip": "이미지 생성을 위한 프롬프트입니다." }, "recraft_controls": { "name": "Recraft 제어", "tooltip": "Recraft 제어 노드를 통한 생성에 대한 추가적인 선택적 제어입니다." }, "seed": { "name": "시드", "tooltip": "노드를 다시 실행할지 결정하는 시드입니다. 실제 결과는 시드와 관계없이 비결정적입니다." }, "size": { "name": "크기", "tooltip": "생성된 이미지의 크기입니다." }, "substyle": { "name": "하위 스타일" } }, "outputs": { "0": { "tooltip": null } } };
const RecraftVectorizeImageNode = { "description": "입력 이미지로부터 SVG를 동기적으로 생성합니다.", "display_name": "Recraft 벡터 생성 (이미지 → 벡터)", "inputs": { "image": { "name": "이미지" } }, "outputs": { "0": { "tooltip": null } } };
const ReferenceLatent = { "description": "이 노드는 편집 모델의 안내 잠재를 설정합니다. 모델이 지원하는 경우 여러 개를 연결하여 여러 참조 이미지를 설정할 수 있습니다.", "display_name": "참조 잠재", "inputs": { "conditioning": { "name": "조건화" }, "latent": { "name": "잠재" } }, "outputs": { "0": { "tooltip": null } } };
const RegexExtract = { "display_name": "정규식 추출", "inputs": { "case_insensitive": { "name": "대소문자 구분 안 함" }, "dotall": { "name": "모든 문자 포함" }, "group_index": { "name": "그룹 인덱스" }, "mode": { "name": "모드" }, "multiline": { "name": "여러 줄" }, "regex_pattern": { "name": "정규식 패턴" }, "string": { "name": "문자열" } }, "outputs": { "0": { "tooltip": null } } };
const RegexMatch = { "display_name": "정규식 일치", "inputs": { "case_insensitive": { "name": "대소문자 구분 안 함" }, "dotall": { "name": "모든 문자 포함" }, "multiline": { "name": "여러 줄" }, "regex_pattern": { "name": "정규식 패턴" }, "string": { "name": "문자열" } }, "outputs": { "0": { "name": "일치 항목", "tooltip": null } } };
const RegexReplace = { "description": "정규식 패턴을 사용하여 텍스트 찾기 및 바꾸기.", "display_name": "정규식 치환", "inputs": { "case_insensitive": { "name": "대소문자 구분 안 함" }, "count": { "name": "횟수", "tooltip": "수행할 최대 교체 횟수입니다. 0으로 설정하면 모든 항목을 교체합니다(기본값). 1로 설정하면 첫 번째 일치 항목만, 2로 설정하면 처음 두 항목 등을 교체합니다." }, "dotall": { "name": "모든 문자 모드", "tooltip": "활성화하면 점(.) 문자가 줄바꿈 문자를 포함한 모든 문자와 일치합니다. 비활성화하면 점이 줄바꿈 문자와 일치하지 않습니다." }, "multiline": { "name": "여러 줄 모드" }, "regex_pattern": { "name": "정규식 패턴" }, "replace": { "name": "바꾸기" }, "string": { "name": "문자열" } }, "outputs": { "0": { "tooltip": null } } };
const RenormCFG = { "display_name": "RenormCFG", "inputs": { "cfg_trunc": { "name": "cfg_trunc" }, "model": { "name": "모델" }, "renorm_cfg": { "name": "renorm_cfg" } }, "outputs": { "0": { "tooltip": null } } };
const RepeatImageBatch = { "display_name": "이미지 반복 배치 생성", "inputs": { "amount": { "name": "개수" }, "image": { "name": "이미지" } } };
const RepeatLatentBatch = { "display_name": "잠재 데이터 반복 배치 생성", "inputs": { "amount": { "name": "개수" }, "samples": { "name": "잠재 데이터" } } };
const RescaleCFG = { "display_name": "CFG 리스케일", "inputs": { "model": { "name": "모델" }, "multiplier": { "name": "배율" } } };
const ResizeAndPadImage = { "display_name": "이미지 크기 조정 및 패딩", "inputs": { "image": { "name": "이미지" }, "interpolation": { "name": "보간" }, "padding_color": { "name": "패딩 색상" }, "target_height": { "name": "대상 높이" }, "target_width": { "name": "대상 너비" } } };
const Rodin3D_Detail = { "description": "Rodin API를 사용하여 3D 에셋 생성", "display_name": "Rodin 3D 생성 - 디테일 생성", "inputs": { "Images": { "name": "이미지" }, "Material_Type": { "name": "재질 유형" }, "Polygon_count": { "name": "폴리곤 수" }, "Seed": { "name": "시드" } }, "outputs": { "0": { "name": "3D 모델 경로", "tooltip": null } } };
const Rodin3D_Gen2 = { "description": "Rodin API를 사용하여 3D 에셋 생성", "display_name": "Rodin 3D 생성 - Gen-2 생성", "inputs": { "Images": { "name": "이미지" }, "Material_Type": { "name": "재질 유형" }, "Polygon_count": { "name": "폴리곤 수" }, "Seed": { "name": "시드" }, "TAPose": { "name": "TAPose" } }, "outputs": { "0": { "name": "3D 모델 경로", "tooltip": null } } };
const Rodin3D_Regular = { "description": "Rodin API를 사용하여 3D 에셋 생성", "display_name": "Rodin 3D 생성 - 일반 생성", "inputs": { "Images": { "name": "이미지" }, "Material_Type": { "name": "재질 유형" }, "Polygon_count": { "name": "폴리곤 수" }, "Seed": { "name": "시드" } }, "outputs": { "0": { "name": "3D 모델 경로", "tooltip": null } } };
const Rodin3D_Sketch = { "description": "Rodin API를 사용하여 3D 에셋 생성", "display_name": "Rodin 3D 생성 - 스케치 생성", "inputs": { "Images": { "name": "이미지" }, "Seed": { "name": "시드" } }, "outputs": { "0": { "name": "3D 모델 경로", "tooltip": null } } };
const Rodin3D_Smooth = { "description": "Rodin API를 사용하여 3D 에셋 생성", "display_name": "Rodin 3D 생성 - 스무스 생성", "inputs": { "Images": { "name": "이미지" }, "Material_Type": { "name": "재질 유형" }, "Polygon_count": { "name": "폴리곤 수" }, "Seed": { "name": "시드" } }, "outputs": { "0": { "name": "3D 모델 경로", "tooltip": null } } };
const RunwayFirstLastFrameNode = { "description": "첫 번째와 마지막 키프레임을 업로드하고 프롬프트를 작성하여 비디오를 생성합니다. 마지막 프레임이 첫 번째 프레임과 완전히 다른 경우와 같은 복잡한 전환은 10초의 긴 지속 시간을 사용하는 것이 좋습니다. 이렇게 하면 두 입력 사이를 부드럽게 전환할 수 있는 시간이 더 주어집니다. 시작하기 전에 입력 선택이 생성 성공을 보장할 수 있도록 다음 모범 사례를 검토하세요: https://help.runwayml.com/hc/en-us/articles/34170748696595-Creating-with-Keyframes-on-Gen-3.", "display_name": "Runway 첫-마지막 프레임 비디오 변환", "inputs": { "control_after_generate": { "name": "control after generate" }, "duration": { "name": "duration" }, "end_frame": { "name": "end_frame", "tooltip": "비디오에 사용할 종료 프레임. Gen3a Turbo에서만 지원됩니다." }, "prompt": { "name": "prompt", "tooltip": "생성을 위한 텍스트 프롬프트" }, "ratio": { "name": "ratio" }, "seed": { "name": "seed", "tooltip": "생성을 위한 랜덤 시드" }, "start_frame": { "name": "start_frame", "tooltip": "비디오에 사용할 시작 프레임" } }, "outputs": { "0": { "tooltip": null } } };
const RunwayImageToVideoNodeGen3a = { "description": "Gen3a Turbo 모델을 사용하여 단일 시작 프레임에서 비디오를 생성합니다. 시작하기 전에 입력 선택이 생성 성공을 보장할 수 있도록 다음 모범 사례를 검토하세요: https://help.runwayml.com/hc/en-us/articles/33927968552339-Creating-with-Act-One-on-Gen-3-Alpha-and-Turbo.", "display_name": "Runway 이미지 비디오 변환 (Gen3a Turbo)", "inputs": { "control_after_generate": { "name": "control after generate" }, "duration": { "name": "duration" }, "prompt": { "name": "prompt", "tooltip": "생성을 위한 텍스트 프롬프트" }, "ratio": { "name": "ratio" }, "seed": { "name": "seed", "tooltip": "생성을 위한 랜덤 시드" }, "start_frame": { "name": "start_frame", "tooltip": "비디오에 사용할 시작 프레임" } }, "outputs": { "0": { "tooltip": null } } };
const RunwayImageToVideoNodeGen4 = { "description": "Gen4 Turbo 모델을 사용하여 단일 시작 프레임에서 비디오를 생성합니다. 시작하기 전에 입력 선택이 생성 성공을 보장할 수 있도록 다음 모범 사례를 검토하세요: https://help.runwayml.com/hc/en-us/articles/37327109429011-Creating-with-Gen-4-Video.", "display_name": "Runway 이미지 비디오 변환 (Gen4 Turbo)", "inputs": { "control_after_generate": { "name": "control after generate" }, "duration": { "name": "duration" }, "prompt": { "name": "prompt", "tooltip": "생성을 위한 텍스트 프롬프트" }, "ratio": { "name": "ratio" }, "seed": { "name": "seed", "tooltip": "생성을 위한 랜덤 시드" }, "start_frame": { "name": "start_frame", "tooltip": "비디오에 사용할 시작 프레임" } }, "outputs": { "0": { "tooltip": null } } };
const RunwayTextToImageNode = { "description": "Runway의 Gen 4 모델을 사용하여 텍스트 프롬프트에서 이미지를 생성합니다. 참조 이미지를 포함하여 생성을 안내할 수도 있습니다.", "display_name": "Runway 텍스트 이미지 생성", "inputs": { "prompt": { "name": "prompt", "tooltip": "생성을 위한 텍스트 프롬프트" }, "ratio": { "name": "ratio" }, "reference_image": { "name": "reference_image", "tooltip": "생성을 안내하는 선택적 참조 이미지" } }, "outputs": { "0": { "tooltip": null } } };
const SDTurboScheduler = { "display_name": "SD-Turbo 스케줄러", "inputs": { "denoise": { "name": "노이즈 제거양" }, "model": { "name": "모델" }, "steps": { "name": "스텝 수" } } };
const SD_4XUpscale_Conditioning = { "display_name": "SD_4X 확대 조건 설정", "inputs": { "images": { "name": "이미지" }, "negative": { "name": "부정 조건" }, "noise_augmentation": { "name": "노이즈 증강" }, "positive": { "name": "긍정 조건" }, "scale_ratio": { "name": "확대율" } }, "outputs": { "0": { "name": "긍정 조건", "tooltip": null }, "1": { "name": "부정 조건", "tooltip": null }, "2": { "name": "잠재 이미지", "tooltip": null } } };
const SV3D_Conditioning = { "display_name": "SV3D 조건 설정", "inputs": { "clip_vision": { "name": "clip_vision" }, "elevation": { "name": "고도" }, "height": { "name": "높이" }, "init_image": { "name": "초기 이미지" }, "vae": { "name": "vae" }, "video_frames": { "name": "비디오 프레임" }, "width": { "name": "너비" } }, "outputs": { "0": { "name": "긍정 조건", "tooltip": null }, "1": { "name": "부정 조건", "tooltip": null }, "2": { "name": "잠재 데이터", "tooltip": null } } };
const SVD_img2vid_Conditioning = { "display_name": "SVD 조건 설정 (이미지 → 비디오)", "inputs": { "augmentation_level": { "name": "증강 레벨" }, "clip_vision": { "name": "clip_vision" }, "fps": { "name": "fps" }, "height": { "name": "높이" }, "init_image": { "name": "초기 이미지" }, "motion_bucket_id": { "name": "모션 버킷 ID" }, "vae": { "name": "vae" }, "video_frames": { "name": "비디오 프레임" }, "width": { "name": "너비" } }, "outputs": { "0": { "name": "긍정 조건" }, "1": { "name": "부정 조건" }, "2": { "name": "잠재 비디오" } } };
const SamplerCustom = { "display_name": "사용자 정의 샘플러", "inputs": { "add_noise": { "name": "노이즈 추가" }, "cfg": { "name": "cfg" }, "control_after_generate": { "name": "생성 후 제어" }, "latent_image": { "name": "잠재 데이터" }, "model": { "name": "모델" }, "negative": { "name": "부정 조건" }, "noise_seed": { "name": "노이즈 시드" }, "positive": { "name": "긍정 조건" }, "sampler": { "name": "샘플러" }, "sigmas": { "name": "시그마 배열" } }, "outputs": { "0": { "name": "출력" }, "1": { "name": "노이즈 제거된 출력" } } };
const SamplerCustomAdvanced = { "display_name": "고급 사용자 정의 샘플러", "inputs": { "guider": { "name": "가이더" }, "latent_image": { "name": "잠재 데이터" }, "noise": { "name": "노이즈" }, "sampler": { "name": "샘플러" }, "sigmas": { "name": "시그마 배열" } }, "outputs": { "0": { "name": "출력" }, "1": { "name": "노이즈 제거된 출력" } } };
const SamplerDPMAdaptative = { "display_name": "DPMAdaptive 샘플러", "inputs": { "accept_safety": { "name": "accept_safety" }, "atol": { "name": "atol" }, "dcoeff": { "name": "dcoeff" }, "eta": { "name": "eta" }, "h_init": { "name": "초기 h" }, "icoeff": { "name": "icoeff" }, "order": { "name": "order" }, "pcoeff": { "name": "pcoeff" }, "rtol": { "name": "rtol" }, "s_noise": { "name": "s_noise" } } };
const SamplerDPMPP_2M_SDE = { "display_name": "DPMPP_2M_SDE 샘플러", "inputs": { "eta": { "name": "eta" }, "noise_device": { "name": "노이즈 생성 장치" }, "s_noise": { "name": "s_noise" }, "solver_type": { "name": "Solver 유형" } } };
const SamplerDPMPP_2S_Ancestral = { "display_name": "DPMPP_2S_Ancestral 샘플러", "inputs": { "eta": { "name": "eta" }, "s_noise": { "name": "s_noise" } } };
const SamplerDPMPP_3M_SDE = { "display_name": "DPMPP_3M_SDE 샘플러", "inputs": { "eta": { "name": "eta" }, "noise_device": { "name": "노이즈 생성 장치" }, "s_noise": { "name": "s_noise" } } };
const SamplerDPMPP_SDE = { "display_name": "DPMPP_SDE 샘플러", "inputs": { "eta": { "name": "eta" }, "noise_device": { "name": "노이즈 생성 장치" }, "r": { "name": "r" }, "s_noise": { "name": "s_noise" } } };
const SamplerER_SDE = { "display_name": "SamplerER_SDE", "inputs": { "eta": { "name": "ETA", "tooltip": "역시간 SDE의 확률적 강도.\neta=0일 때 결정론적 ODE로 축소됩니다. 이 설정은 ER-SDE 솔버 유형에는 적용되지 않습니다." }, "max_stage": { "name": "최대 단계" }, "s_noise": { "name": "S 노이즈" }, "solver_type": { "name": "solver_type" } } };
const SamplerEulerAncestral = { "display_name": "Eluer Ancestral 샘플러", "inputs": { "eta": { "name": "eta" }, "s_noise": { "name": "s_noise" } } };
const SamplerEulerAncestralCFGPP = { "display_name": "Eluer Acnestral CFG++ 샘플러", "inputs": { "eta": { "name": "eta" }, "s_noise": { "name": "s_noise" } } };
const SamplerEulerCFGpp = { "display_name": "Eluer CFG++ 샘플러", "inputs": { "version": { "name": "버전" } }, "outputs": { "0": { "tooltip": null } } };
const SamplerLCMUpscale = { "display_name": "LCM 확대 샘플러", "inputs": { "scale_ratio": { "name": "확대율" }, "scale_steps": { "name": "확대 스텝 수" }, "upscale_method": { "name": "업스케일 방법" } }, "outputs": { "0": { "tooltip": null } } };
const SamplerLMS = { "display_name": "LMS 샘플러", "inputs": { "order": { "name": "순서" } } };
const SamplerSASolver = { "display_name": "SamplerSASolver", "inputs": { "corrector_order": { "name": "수정기 차수" }, "eta": { "name": "ETA" }, "model": { "name": "모델" }, "predictor_order": { "name": "예측기 차수" }, "s_noise": { "name": "S 노이즈" }, "sde_end_percent": { "name": "SDE 종료 백분율" }, "sde_start_percent": { "name": "SDE 시작 백분율" }, "simple_order_2": { "name": "단순 2차" }, "use_pece": { "name": "PECE 사용" } } };
const SamplingPercentToSigma = { "display_name": "SamplingPercentToSigma", "inputs": { "model": { "name": "모델" }, "return_actual_sigma": { "name": "실제 시그마 값 반환", "tooltip": "간격 검사에 사용된 값 대신 실제 시그마 값을 반환합니다.\n이 설정은 0.0과 1.0에서만 결과에 영향을 미칩니다." }, "sampling_percent": { "name": "샘플링 백분율" } }, "outputs": { "0": { "name": "시그마 값" } } };
const SaveAnimatedPNG = { "display_name": "애니메이션 PNG 저장", "inputs": { "compress_level": { "name": "압축 레벨" }, "filename_prefix": { "name": "파일명 접두사" }, "fps": { "name": "fps" }, "images": { "name": "이미지" } } };
const SaveAnimatedWEBP = { "display_name": "애니메이션 WEBP 저장", "inputs": { "filename_prefix": { "name": "파일명 접두사" }, "fps": { "name": "fps" }, "images": { "name": "이미지" }, "lossless": { "name": "무손실" }, "method": { "name": "방법" }, "quality": { "name": "품질" } } };
const SaveAudio = { "display_name": "오디오 저장", "inputs": { "audio": { "name": "오디오" }, "audioUI": { "name": "오디오UI" }, "filename_prefix": { "name": "파일명 접두사" } } };
const SaveAudioMP3 = { "display_name": "오디오 저장 (MP3)", "inputs": { "audio": { "name": "오디오" }, "audioUI": { "name": "오디오 UI" }, "filename_prefix": { "name": "파일명 접두사" }, "quality": { "name": "품질" } } };
const SaveAudioOpus = { "display_name": "오디오 저장 (Opus)", "inputs": { "audio": { "name": "오디오" }, "audioUI": { "name": "오디오 UI" }, "filename_prefix": { "name": "파일명 접두사" }, "quality": { "name": "품질" } } };
const SaveGLB = { "display_name": "GLB 저장", "inputs": { "filename_prefix": { "name": "파일명 접두사" }, "image": { "name": "이미지" }, "mesh": { "name": "메시" } } };
const SaveImage = { "description": "입력 이미지를 ComfyUI 출력 디렉토리에 저장합니다.", "display_name": "이미지 저장", "inputs": { "filename_prefix": { "name": "파일명 접두사", "tooltip": "저장할 파일의 접두사입니다. 여기에는 %date:yyyy-MM-dd% 또는 %Empty Latent Image.width%와 같은 형식 정보가 포함되어 노드의 값을 포함할 수 있습니다." }, "images": { "name": "이미지", "tooltip": "저장할 이미지입니다." } } };
const SaveImageWebsocket = { "display_name": "이미지 웹소켓 전송", "inputs": { "images": { "name": "이미지" } } };
const SaveLatent = { "display_name": "잠재 데이터 저장", "inputs": { "filename_prefix": { "name": "파일명 접두사" }, "samples": { "name": "잠재 데이터" } } };
const SaveSVGNode = { "description": "디스크에 SVG 파일 저장.", "display_name": "SVG 노드 저장", "inputs": { "filename_prefix": { "name": "파일명 접두사", "tooltip": "저장할 파일의 접두사. 여기에는 %date:yyyy-MM-dd% 또는 %Empty Latent Image.width%와 같은 노드의 값을 포함하는 형식 정보가 포함될 수 있습니다." }, "svg": { "name": "SVG" } } };
const SaveVideo = { "description": "입력 이미지를 ComfyUI 출력 디렉토리에 저장합니다.", "display_name": "비디오 저장", "inputs": { "codec": { "name": "코덱", "tooltip": "비디오에 사용할 코덱입니다." }, "filename_prefix": { "name": "파일명 접두사", "tooltip": "저장할 파일의 접두사입니다. %date:yyyy-MM-dd% 또는 %Empty Latent Image.width%와 같이 노드의 값을 포함하는 포맷 정보를 사용할 수 있습니다." }, "format": { "name": "포맷", "tooltip": "비디오를 저장할 포맷입니다." }, "video": { "name": "비디오", "tooltip": "저장할 비디오입니다." } } };
const SaveWEBM = { "display_name": "동영상 저장 (WEBM)", "inputs": { "codec": { "name": "코덱" }, "crf": { "name": "crf", "tooltip": "crf가 높을수록 파일 크기는 작지만 품질은 낮아집니다. crf가 낮을수록 파일 크기는 커지지만 품질은 높아집니다." }, "filename_prefix": { "name": "파일명_접두사" }, "fps": { "name": "fps" }, "images": { "name": "이미지" } } };
const ScaleROPE = { "description": "모델의 ROPE를 스케일링하고 이동합니다.", "display_name": "ROPE 스케일", "inputs": { "model": { "name": "모델" }, "scale_t": { "name": "시간 축 스케일" }, "scale_x": { "name": "X축 스케일" }, "scale_y": { "name": "Y축 스케일" }, "shift_t": { "name": "시간 축 이동" }, "shift_x": { "name": "X축 이동" }, "shift_y": { "name": "Y축 이동" } }, "outputs": { "0": { "tooltip": null } } };
const SelfAttentionGuidance = { "display_name": "셀프 어텐션 가이드", "inputs": { "blur_sigma": { "name": "블러 시그마" }, "model": { "name": "모델" }, "scale": { "name": "스케일" } }, "outputs": { "0": { "tooltip": null } } };
const SetClipHooks = { "display_name": "CLIP 후크 설정", "inputs": { "apply_to_conds": { "name": "조건에 적용" }, "clip": { "name": "clip" }, "hooks": { "name": "후크" }, "schedule_clip": { "name": "clip 스케쥴 사용" } } };
const SetFirstSigma = { "display_name": "SetFirstSigma", "inputs": { "sigma": { "name": "시그마" }, "sigmas": { "name": "시그마 배열" } } };
const SetHookKeyframes = { "display_name": "후크 키프레임 설정", "inputs": { "hook_kf": { "name": "KF 후크" }, "hooks": { "name": "후크" } } };
const SetLatentNoiseMask = { "display_name": "잠재 데이터에 노이즈 마스크 설정", "inputs": { "mask": { "name": "마스크" }, "samples": { "name": "잠재 데이터" } } };
const SetUnionControlNetType = { "display_name": "통합 컨트롤넷 유형 설정", "inputs": { "control_net": { "name": "컨트롤넷" }, "type": { "name": "유형" } }, "outputs": { "0": { "tooltip": null } } };
const SkipLayerGuidanceDiT = { "description": "모든 DiT 모델에서 사용할 수 있는 '레이어 건너뛰기 가이던스' 노드의 범용 버전입니다.", "display_name": "레이어 건너뛰기 가이던스 (DiT)", "inputs": { "double_layers": { "name": "double_layers" }, "end_percent": { "name": "종료 퍼센트" }, "model": { "name": "모델" }, "rescaling_scale": { "name": "리스케일 크기" }, "scale": { "name": "크기" }, "single_layers": { "name": "single_layers" }, "start_percent": { "name": "시작 퍼센트" } }, "outputs": { "0": { "tooltip": null } } };
const SkipLayerGuidanceDiTSimple = { "description": "uncond 패스만 수정하는 SkipLayerGuidanceDiT 노드의 간단 버전입니다.", "display_name": "SkipLayerGuidanceDiT 간단 버전", "inputs": { "double_layers": { "name": "이중 레이어" }, "end_percent": { "name": "종료 백분율" }, "model": { "name": "모델" }, "single_layers": { "name": "단일 레이어" }, "start_percent": { "name": "시작 백분율" } }, "outputs": { "0": { "tooltip": null } } };
const SkipLayerGuidanceSD3 = { "description": "SD3 용 레이어 건너뛰기 가이던스 노드입니다.", "display_name": "레이어 건너뛰기 가이던스 (SD3)", "inputs": { "end_percent": { "name": "종료 퍼센트" }, "layers": { "name": "layers" }, "model": { "name": "모델" }, "scale": { "name": "크기" }, "start_percent": { "name": "시작 퍼센트" } }, "outputs": { "0": { "tooltip": null } } };
const SolidMask = { "display_name": "단색 마스크", "inputs": { "height": { "name": "높이" }, "value": { "name": "값" }, "width": { "name": "너비" } } };
const SplitAudioChannels = { "description": "오디오를 좌우 채널로 분리합니다.", "display_name": "오디오 채널 분리", "inputs": { "audio": { "name": "오디오" } }, "outputs": { "0": { "name": "왼쪽" }, "1": { "name": "오른쪽" } } };
const SplitImageWithAlpha = { "display_name": "이미지와 알파채널 분리", "inputs": { "image": { "name": "이미지" } }, "outputs": { "0": { "tooltip": null }, "1": { "tooltip": null } } };
const SplitSigmas = { "display_name": "시그마 배열 분할 (스텝)", "inputs": { "sigmas": { "name": "시그마 배열" }, "step": { "name": "분할 스텝" } }, "outputs": { "0": { "name": "높은 시그마 배열" }, "1": { "name": "낮은 시그마 배열" } } };
const SplitSigmasDenoise = { "display_name": "시그마 배열 분할 (노이즈 제거양)", "inputs": { "denoise": { "name": "노이즈 제거양" }, "sigmas": { "name": "시그마 배열" } }, "outputs": { "0": { "name": "높은 시그마 배열" }, "1": { "name": "낮은 시그마 배열" } } };
const StabilityAudioInpaint = { "description": "텍스트 지침을 사용하여 기존 오디오 샘플의 일부를 변환합니다.", "display_name": "Stability AI 오디오 인페인팅", "inputs": { "audio": { "name": "오디오", "tooltip": "오디오 길이는 6초에서 190초 사이여야 합니다." }, "control_after_generate": { "name": "생성 후 제어" }, "duration": { "name": "지속 시간", "tooltip": "생성된 오디오의 지속 시간(초)을 제어합니다." }, "mask_end": { "name": "마스크 종료" }, "mask_start": { "name": "마스크 시작" }, "model": { "name": "모델" }, "prompt": { "name": "프롬프트" }, "seed": { "name": "시드", "tooltip": "생성에 사용되는 랜덤 시드 값입니다." }, "steps": { "name": "단계 수", "tooltip": "샘플링 단계 수를 제어합니다." } }, "outputs": { "0": { "tooltip": null } } };
const StabilityAudioToAudio = { "description": "텍스트 지침을 사용하여 기존 오디오 샘플을 새로운 고품질 구성으로 변환합니다.", "display_name": "Stability AI 오디오 변환", "inputs": { "audio": { "name": "오디오", "tooltip": "오디오 길이는 6초에서 190초 사이여야 합니다." }, "control_after_generate": { "name": "생성 후 제어" }, "duration": { "name": "지속 시간", "tooltip": "생성된 오디오의 지속 시간(초)을 제어합니다." }, "model": { "name": "모델" }, "prompt": { "name": "프롬프트" }, "seed": { "name": "시드", "tooltip": "생성에 사용되는 랜덤 시드 값입니다." }, "steps": { "name": "단계 수", "tooltip": "샘플링 단계 수를 제어합니다." }, "strength": { "name": "강도", "tooltip": "이 매개변수는 오디오 매개변수가 생성된 오디오에 미치는 영향의 정도를 제어합니다." } }, "outputs": { "0": { "tooltip": null } } };
const StabilityStableImageSD_3_5Node = { "description": "프롬프트와 해상도에 따라 이미지를 동기적으로 생성합니다.", "display_name": "Stability AI Stable Diffusion 3.5 이미지", "inputs": { "aspect_ratio": { "name": "종횡비", "tooltip": "생성된 이미지의 종횡비입니다." }, "cfg_scale": { "name": "cfg 스케일", "tooltip": "디퓨전 과정이 프롬프트 텍스트를 얼마나 엄격하게 따르는지 결정합니다(값이 높을수록 이미지가 프롬프트에 더 가깝게 생성됩니다)." }, "control_after_generate": { "name": "생성 후 제어" }, "image": { "name": "이미지" }, "image_denoise": { "name": "노이즈 제거양", "tooltip": "입력 이미지의 노이즈 제거 정도; 0.0은 입력 이미지와 동일, 1.0은 이미지가 전혀 제공되지 않은 것과 같습니다." }, "model": { "name": "모델" }, "negative_prompt": { "name": "부정 프롬프트", "tooltip": "출력 이미지에 나타나지 않길 원하는 키워드입니다. 고급 기능입니다." }, "prompt": { "name": "프롬프트", "tooltip": "출력 이미지에서 보고 싶은 내용을 입력하세요. 요소, 색상, 주제를 명확하게 정의하는 강력하고 구체적인 프롬프트가 더 나은 결과를 가져옵니다." }, "seed": { "name": "시드", "tooltip": "노이즈 생성을 위해 사용되는 랜덤 시드입니다." }, "style_preset": { "name": "스타일 프리셋", "tooltip": "생성된 이미지에 원하는 스타일(선택 사항)입니다." } }, "outputs": { "0": { "tooltip": null } } };
const StabilityStableImageUltraNode = { "description": "프롬프트와 해상도에 따라 이미지를 동기적으로 생성합니다.", "display_name": "Stability AI Stable Image Ultra", "inputs": { "aspect_ratio": { "name": "종횡비", "tooltip": "생성된 이미지의 가로세로 비율입니다." }, "control_after_generate": { "name": "생성 후 제어" }, "image": { "name": "이미지" }, "image_denoise": { "name": "노이즈 제거양", "tooltip": "입력 이미지의 노이즈 제거 정도입니다. 0.0은 입력 이미지와 동일하며, 1.0은 이미지가 전혀 제공되지 않은 것과 같습니다." }, "negative_prompt": { "name": "부정 프롬프트", "tooltip": "출력 이미지에서 보고 싶지 않은 내용을 설명하는 텍스트입니다. 고급 기능입니다." }, "prompt": { "name": "프롬프트", "tooltip": "출력 이미지에서 보고 싶은 내용을 입력하세요. 요소, 색상, 주제를 명확하게 정의하는 강력하고 구체적인 프롬프트가 더 나은 결과를 가져옵니다. 특정 단어의 가중치를 조절하려면 `(단어:가중치)` 형식을 사용하세요. 여기서 `단어`는 가중치를 조절하고 싶은 단어이고, `가중치`는 0과 1 사이의 값입니다. 예시: `The sky was a crisp (blue:0.3) and (green:0.8)`는 하늘이 파란색과 초록색이지만 초록색이 더 많다는 의미입니다." }, "seed": { "name": "시드", "tooltip": "노이즈 생성을 위한 랜덤 시드 값입니다." }, "style_preset": { "name": "스타일 프리셋", "tooltip": "생성된 이미지에 적용할 선택적 스타일입니다." } }, "outputs": { "0": { "tooltip": null } } };
const StabilityTextToAudio = { "description": "텍스트 설명으로부터 고품질 음악과 사운드 효과를 생성합니다.", "display_name": "Stability AI 텍스트-오디오 변환", "inputs": { "control_after_generate": { "name": "생성 후 제어" }, "duration": { "name": "지속 시간", "tooltip": "생성된 오디오의 지속 시간(초)을 제어합니다." }, "model": { "name": "모델" }, "prompt": { "name": "프롬프트" }, "seed": { "name": "시드", "tooltip": "생성에 사용되는 무작위 시드 값입니다." }, "steps": { "name": "단계", "tooltip": "샘플링 단계 수를 제어합니다." } }, "outputs": { "0": { "tooltip": null } } };
const StabilityUpscaleConservativeNode = { "description": "이미지를 최소한의 변경으로 4K 해상도로 업스케일합니다.", "display_name": "Stability AI 업스케일 보수적", "inputs": { "control_after_generate": { "name": "생성 후 제어" }, "creativity": { "name": "창의성", "tooltip": "초기 이미지에 크게 의존하지 않는 추가 디테일이 생성될 가능성을 조절합니다." }, "image": { "name": "이미지" }, "negative_prompt": { "name": "부정 프롬프트", "tooltip": "출력 이미지에 나타나길 원하지 않는 키워드를 입력하세요. 고급 기능입니다." }, "prompt": { "name": "프롬프트", "tooltip": "출력 이미지에서 보고 싶은 내용을 입력하세요. 요소, 색상, 주제를 명확하게 정의하는 강력하고 구체적인 프롬프트가 더 나은 결과를 가져옵니다." }, "seed": { "name": "시드", "tooltip": "노이즈 생성을 위한 랜덤 시드입니다." } }, "outputs": { "0": { "tooltip": null } } };
const StabilityUpscaleCreativeNode = { "description": "이미지를 최소한의 변경으로 4K 해상도로 업스케일합니다.", "display_name": "Stability AI 업스케일 크리에이티브", "inputs": { "control_after_generate": { "name": "생성 후 제어" }, "creativity": { "name": "창의성", "tooltip": "초기 이미지에 크게 의존하지 않고 추가적인 디테일이 생성될 가능성을 조절합니다." }, "image": { "name": "이미지" }, "negative_prompt": { "name": "부정 프롬프트", "tooltip": "출력 이미지에 나타나길 원하지 않는 키워드를 입력하세요. 고급 기능입니다." }, "prompt": { "name": "프롬프트", "tooltip": "출력 이미지에서 보고 싶은 내용을 입력하세요. 요소, 색상, 주제를 명확하게 정의하는 강력하고 구체적인 프롬프트가 더 나은 결과를 가져옵니다." }, "seed": { "name": "시드", "tooltip": "노이즈 생성을 위한 랜덤 시드입니다." }, "style_preset": { "name": "스타일 프리셋", "tooltip": "생성된 이미지에 원하는 스타일(선택 사항)을 지정합니다." } }, "outputs": { "0": { "tooltip": null } } };
const StabilityUpscaleFastNode = { "description": "Stability API 호출을 통해 이미지를 원본의 4배 크기로 빠르게 업스케일합니다. 저화질/압축 이미지의 업스케일에 적합합니다.", "display_name": "Stability AI 초고속 업스케일", "inputs": { "image": { "name": "이미지" } }, "outputs": { "0": { "tooltip": null } } };
const StableCascade_EmptyLatentImage = { "display_name": "StableCascade 빈 잠재 이미지", "inputs": { "batch_size": { "name": "배치 크기" }, "compression": { "name": "압축" }, "height": { "name": "높이" }, "width": { "name": "너비" } }, "outputs": { "0": { "name": "StageC 잠재 이미지", "tooltip": null }, "1": { "name": "StageB 잠재 이미지", "tooltip": null } } };
const StableCascade_StageB_Conditioning = { "display_name": "StableCascasde_StageB 조건 설정", "inputs": { "conditioning": { "name": "조건" }, "stage_c": { "name": "StageC 잠재 이미지" } }, "outputs": { "0": { "tooltip": null } } };
const StableCascade_StageC_VAEEncode = { "display_name": "StableCascade_StageC VAE 인코딩", "inputs": { "compression": { "name": "압축" }, "image": { "name": "이미지" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "StageC 잠재 이미지", "tooltip": null }, "1": { "name": "StageB 잠재 이미지", "tooltip": null } } };
const StableCascade_SuperResolutionControlnet = { "display_name": "StableCascade 초고해상도 컨트롤넷", "inputs": { "image": { "name": "이미지" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "컨트롤넷 입력", "tooltip": null }, "1": { "name": "StageC 잠재 이미지", "tooltip": null }, "2": { "name": "StageB 잠재 이미지", "tooltip": null } } };
const StableZero123_Conditioning = { "display_name": "StableZero123 조건 설정", "inputs": { "azimuth": { "name": "방위각" }, "batch_size": { "name": "배치 크기" }, "clip_vision": { "name": "clip_vision" }, "elevation": { "name": "고도" }, "height": { "name": "높이" }, "init_image": { "name": "초기 이미지" }, "vae": { "name": "vae" }, "width": { "name": "너비" } }, "outputs": { "0": { "name": "긍정 조건", "tooltip": null }, "1": { "name": "부정 조건", "tooltip": null }, "2": { "name": "잠재 데이터", "tooltip": null } } };
const StableZero123_Conditioning_Batched = { "display_name": "StableZero123 조건 설정 (배치)", "inputs": { "azimuth": { "name": "방위각" }, "azimuth_batch_increment": { "name": "방위각 배치 증가" }, "batch_size": { "name": "배치 크기" }, "clip_vision": { "name": "clip_vision" }, "elevation": { "name": "고도" }, "elevation_batch_increment": { "name": "고도 배치 증가" }, "height": { "name": "높이" }, "init_image": { "name": "초기 이미지" }, "vae": { "name": "vae" }, "width": { "name": "너비" } }, "outputs": { "0": { "name": "긍정 조건", "tooltip": null }, "1": { "name": "부정 조건", "tooltip": null }, "2": { "name": "잠재 데이터", "tooltip": null } } };
const StringCompare = { "display_name": "비교", "inputs": { "case_sensitive": { "name": "대소문자 구분" }, "mode": { "name": "모드" }, "string_a": { "name": "문자열_a" }, "string_b": { "name": "문자열_b" } }, "outputs": { "0": { "tooltip": null } } };
const StringConcatenate = { "display_name": "연결", "inputs": { "delimiter": { "name": "구분자" }, "string_a": { "name": "문자열_a" }, "string_b": { "name": "문자열_b" } }, "outputs": { "0": { "tooltip": null } } };
const StringContains = { "display_name": "포함", "inputs": { "case_sensitive": { "name": "대소문자 구분" }, "string": { "name": "문자열" }, "substring": { "name": "부분 문자열" } }, "outputs": { "0": { "name": "포함 여부", "tooltip": null } } };
const StringLength = { "display_name": "길이", "inputs": { "string": { "name": "문자열" } }, "outputs": { "0": { "name": "길이", "tooltip": null } } };
const StringReplace = { "display_name": "바꾸기", "inputs": { "find": { "name": "찾기" }, "replace": { "name": "바꾸기" }, "string": { "name": "문자열" } }, "outputs": { "0": { "tooltip": null } } };
const StringSubstring = { "display_name": "부분 문자열", "inputs": { "end": { "name": "끝" }, "start": { "name": "시작" }, "string": { "name": "문자열" } }, "outputs": { "0": { "tooltip": null } } };
const StringTrim = { "display_name": "정리", "inputs": { "mode": { "name": "모드" }, "string": { "name": "문자열" } }, "outputs": { "0": { "tooltip": null } } };
const StyleModelApply = { "display_name": "스타일 모델 적용", "inputs": { "clip_vision_output": { "name": "clip_vision 출력" }, "conditioning": { "name": "조건" }, "strength": { "name": "강도" }, "strength_type": { "name": "강도 유형" }, "style_model": { "name": "스타일 모델" } } };
const StyleModelLoader = { "display_name": "스타일 모델 로드", "inputs": { "style_model_name": { "name": "스타일 모델 이름" } } };
const T5TokenizerOptions = { "display_name": "T5 토큰생성기 옵션", "inputs": { "clip": { "name": "clip" }, "min_length": { "name": "최소 길이" }, "min_padding": { "name": "최소 패딩" } }, "outputs": { "0": { "tooltip": null } } };
const TCFG = { "description": "TCFG – 접선 감쇠 CFG (2503.18137)\n\n품질 향상을 위해 무조건부(부정)를 조건부(긍정)와 일치하도록 정제합니다.", "display_name": "접선 감쇠 CFG", "inputs": { "model": { "name": "모델" } }, "outputs": { "0": { "name": "패치된 모델", "tooltip": null } } };
const TemporalScoreRescaling = { "description": "[Post-CFG 함수]\nTSR - 시간적 점수 재조정 (2510.01184)\n\n모델의 점수나 노이즈를 재조정하여 샘플링 다양성을 조절합니다.", "display_name": "TSR - 시간적 점수 재조정", "inputs": { "model": { "name": "모델" }, "tsr_k": { "name": "tsr_k", "tooltip": "재조정 강도를 제어합니다.\n낮은 k 값은 더 세부적인 결과를 생성하고, 높은 k 값은 이미지 생성에서 더 부드러운 결과를 생성합니다. k = 1로 설정하면 재조정이 비활성화됩니다." }, "tsr_sigma": { "name": "tsr_sigma", "tooltip": "재조정이 언제 시작되는지 제어합니다.\n값이 클수록 더 일찍 효과가 나타납니다." } }, "outputs": { "0": { "name": "패치된 모델", "tooltip": null } } };
const TextEncodeAceStepAudio = { "display_name": "TextEncodeAceStepAudio", "inputs": { "clip": { "name": "clip" }, "lyrics": { "name": "가사" }, "lyrics_strength": { "name": "가사 강도" }, "tags": { "name": "태그" } }, "outputs": { "0": { "tooltip": null } } };
const TextEncodeHunyuanVideo_ImageToVideo = { "display_name": "HunyuanVideo 텍스트 인코딩 (이미지 → 비디오)", "inputs": { "clip": { "name": "클립" }, "clip_vision_output": { "name": "clip_vision 출력" }, "image_interleave": { "name": "이미지 인터리브", "tooltip": "이미지가 텍스트 프롬프트와 비교하여 얼마나 영향을 미치는지. 높은 숫자는 텍스트 프롬프트로부터 더 많은 영향을 받음을 의미합니다." }, "prompt": { "name": "프롬프트" } }, "outputs": { "0": { "tooltip": null } } };
const TextEncodeQwenImageEdit = { "display_name": "TextEncodeQwenImageEdit", "inputs": { "clip": { "name": "clip" }, "image": { "name": "이미지" }, "prompt": { "name": "프롬프트" }, "vae": { "name": "vae" } }, "outputs": { "0": { "tooltip": null } } };
const TextEncodeQwenImageEditPlus = { "display_name": "TextEncodeQwenImageEditPlus", "inputs": { "clip": { "name": "clip" }, "image1": { "name": "이미지1" }, "image2": { "name": "이미지2" }, "image3": { "name": "이미지3" }, "prompt": { "name": "프롬프트" }, "vae": { "name": "vae" } }, "outputs": { "0": { "tooltip": null } } };
const ThresholdMask = { "display_name": "임계값 마스크", "inputs": { "mask": { "name": "마스크" }, "value": { "name": "값" } } };
const TomePatchModel = { "display_name": "토큰 병합(ToMe) 모델 패치", "inputs": { "model": { "name": "모델" }, "ratio": { "name": "비율" } }, "outputs": { "0": { "tooltip": null } } };
const TorchCompileModel = { "display_name": "모델 토치 컴파일", "inputs": { "backend": { "name": "백엔드" }, "model": { "name": "모델" } }, "outputs": { "0": { "tooltip": null } } };
const TrainLoraNode = { "display_name": "LoRA 학습", "inputs": { "algorithm": { "name": "알고리즘", "tooltip": "훈련에 사용할 알고리즘입니다." }, "batch_size": { "name": "배치 크기", "tooltip": "학습에 사용할 배치 크기입니다." }, "control_after_generate": { "name": "생성 후 제어" }, "existing_lora": { "name": "기존 LoRA", "tooltip": "추가할 기존 LoRA입니다. 새 LoRA의 경우 None으로 설정하세요." }, "grad_accumulation_steps": { "name": "기울기 누적 단계 수", "tooltip": "학습에 사용할 기울기 누적 단계 수입니다." }, "gradient_checkpointing": { "name": "기울기 체크포인팅", "tooltip": "훈련에 기울기 체크포인팅을 사용합니다." }, "latents": { "name": "잠재 변수", "tooltip": "학습에 사용할 잠재 변수로, 모델의 데이터셋/입력으로 사용됩니다." }, "learning_rate": { "name": "학습률", "tooltip": "학습에 사용할 학습률입니다." }, "lora_dtype": { "name": "LoRA 데이터 타입", "tooltip": "LoRA에 사용할 데이터 타입입니다." }, "loss_function": { "name": "손실 함수", "tooltip": "훈련에 사용할 손실 함수입니다." }, "model": { "name": "모델", "tooltip": "LoRA를 학습시킬 모델입니다." }, "optimizer": { "name": "옵티마이저", "tooltip": "학습에 사용할 옵티마이저입니다." }, "positive": { "name": "긍정 조건", "tooltip": "학습에 사용할 긍정 조건입니다." }, "rank": { "name": "랭크", "tooltip": "LoRA 계층의 랭크입니다." }, "seed": { "name": "시드", "tooltip": "훈련에 사용할 시드 (LoRA 가중치 초기화 및 노이즈 샘플링용 생성기에 사용됨)" }, "steps": { "name": "단계 수", "tooltip": "LoRA를 학습시킬 단계 수입니다." }, "training_dtype": { "name": "훈련 데이터 타입", "tooltip": "훈련에 사용할 데이터 타입입니다." } }, "outputs": { "0": { "name": "LoRA가 적용된 모델" }, "1": { "name": "LoRA" }, "2": { "name": "손실" }, "3": { "name": "단계" } } };
const TrimAudioDuration = { "description": "오디오 텐서를 선택한 시간 범위로 자릅니다.", "display_name": "오디오 길이 자르기", "inputs": { "audio": { "name": "오디오" }, "duration": { "name": "지속 시간", "tooltip": "지속 시간(초)" }, "start_index": { "name": "시작 인덱스", "tooltip": "시작 시간(초), 음수일 경우 끝에서부터 계산 (소수 단위 지원)." } } };
const TrimVideoLatent = { "display_name": "잠재 비디오 자르기", "inputs": { "samples": { "name": "샘플" }, "trim_amount": { "name": "자르기 양" } }, "outputs": { "0": { "tooltip": null } } };
const TripleCLIPLoader = { "description": "[조합법]\n\nsd3: clip-l, clip-g, t5", "display_name": "삼중 CLIP 로드", "inputs": { "clip_name1": { "name": "CLIP 파일명1" }, "clip_name2": { "name": "CLIP 파일명2" }, "clip_name3": { "name": "CLIP 파일명3" } }, "outputs": { "0": { "tooltip": null } } };
const TripoConversionNode = { "display_name": "Tripo: 모델 변환", "inputs": { "face_limit": { "name": "면 제한" }, "format": { "name": "형식" }, "original_model_task_id": { "name": "원본 모델 작업 ID" }, "quad": { "name": "쿼드" }, "texture_format": { "name": "텍스처 형식" }, "texture_size": { "name": "텍스처 크기" } } };
const TripoImageToModelNode = { "display_name": "Tripo: 이미지를 모델로", "inputs": { "face_limit": { "name": "얼굴 제한" }, "image": { "name": "이미지" }, "model_seed": { "name": "모델 시드" }, "model_version": { "name": "모델 버전", "tooltip": "생성에 사용할 모델 버전" }, "orientation": { "name": "방향" }, "pbr": { "name": "PBR" }, "quad": { "name": "쿼드" }, "style": { "name": "스타일" }, "texture": { "name": "텍스처" }, "texture_alignment": { "name": "텍스처 정렬" }, "texture_quality": { "name": "텍스처 품질" }, "texture_seed": { "name": "텍스처 시드" } }, "outputs": { "0": { "name": "모델 파일", "tooltip": null }, "1": { "name": "모델 작업 ID", "tooltip": null } } };
const TripoMultiviewToModelNode = { "display_name": "Tripo: 다중 뷰에서 모델 생성", "inputs": { "face_limit": { "name": "얼굴 제한" }, "image": { "name": "이미지" }, "image_back": { "name": "뒷면 이미지" }, "image_left": { "name": "왼쪽 이미지" }, "image_right": { "name": "오른쪽 이미지" }, "model_seed": { "name": "모델 시드" }, "model_version": { "name": "모델 버전", "tooltip": "생성에 사용할 모델 버전" }, "orientation": { "name": "방향" }, "pbr": { "name": "PBR" }, "quad": { "name": "쿼드" }, "texture": { "name": "텍스처" }, "texture_alignment": { "name": "텍스처 정렬" }, "texture_quality": { "name": "텍스처 품질" }, "texture_seed": { "name": "텍스처 시드" } }, "outputs": { "0": { "name": "모델 파일", "tooltip": null }, "1": { "name": "모델 작업 ID", "tooltip": null } } };
const TripoRefineNode = { "description": "v1.4 Tripo 모델로 생성된 드래프트 모델만 정제합니다.", "display_name": "Tripo: 드래프트 모델 정제", "inputs": { "model_task_id": { "name": "모델 작업 ID", "tooltip": "v1.4 Tripo 모델이어야 합니다" } }, "outputs": { "0": { "name": "모델 파일", "tooltip": null }, "1": { "name": "모델 작업 ID", "tooltip": null } } };
const TripoRetargetNode = { "display_name": "Tripo: 리깅된 모델 리타겟", "inputs": { "animation": { "name": "애니메이션" }, "original_model_task_id": { "name": "원본 모델 작업 ID" } }, "outputs": { "0": { "name": "모델 파일", "tooltip": null }, "1": { "name": "리타겟 작업 ID", "tooltip": null } } };
const TripoRigNode = { "display_name": "Tripo: 모델 리깅", "inputs": { "original_model_task_id": { "name": "원본 모델 작업 ID" } }, "outputs": { "0": { "name": "모델 파일", "tooltip": null }, "1": { "name": "리깅 작업 ID", "tooltip": null } } };
const TripoTextToModelNode = { "display_name": "Tripo: 텍스트에서 모델 생성", "inputs": { "face_limit": { "name": "얼굴 제한" }, "image_seed": { "name": "이미지 시드" }, "model_seed": { "name": "모델 시드" }, "model_version": { "name": "모델 버전" }, "negative_prompt": { "name": "네거티브 프롬프트" }, "pbr": { "name": "PBR" }, "prompt": { "name": "프롬프트" }, "quad": { "name": "쿼드" }, "style": { "name": "스타일" }, "texture": { "name": "텍스처" }, "texture_quality": { "name": "텍스처 품질" }, "texture_seed": { "name": "텍스처 시드" } }, "outputs": { "0": { "name": "모델 파일", "tooltip": null }, "1": { "name": "모델 작업 ID", "tooltip": null } } };
const TripoTextureNode = { "display_name": "Tripo: 텍스처 모델", "inputs": { "model_task_id": { "name": "모델 작업 ID" }, "pbr": { "name": "PBR" }, "texture": { "name": "텍스처" }, "texture_alignment": { "name": "텍스처 정렬" }, "texture_quality": { "name": "텍스처 품질" }, "texture_seed": { "name": "텍스처 시드" } }, "outputs": { "0": { "name": "모델 파일", "tooltip": null }, "1": { "name": "모델 작업 ID", "tooltip": null } } };
const UNETLoader = { "display_name": "확산 모델 로드", "inputs": { "unet_name": { "name": "UNet 모델 파일명" }, "weight_dtype": { "name": "가중치 데이터 유형" } } };
const UNetCrossAttentionMultiply = { "display_name": "UNet 교차 어텐션 곱하기", "inputs": { "k": { "name": "k" }, "model": { "name": "모델" }, "out": { "name": "out" }, "q": { "name": "q" }, "v": { "name": "v" } }, "outputs": { "0": { "tooltip": null } } };
const UNetSelfAttentionMultiply = { "display_name": "UNet 셀프 어텐션 곱하기", "inputs": { "k": { "name": "k" }, "model": { "name": "모델" }, "out": { "name": "out" }, "q": { "name": "q" }, "v": { "name": "v" } }, "outputs": { "0": { "tooltip": null } } };
const UNetTemporalAttentionMultiply = { "display_name": "UNet 템포럴 어텐션 곱하기", "inputs": { "cross_structural": { "name": "구조적 크로스" }, "cross_temporal": { "name": "시간적 크로스" }, "model": { "name": "모델" }, "self_structural": { "name": "구조적 셀프" }, "self_temporal": { "name": "시간적 셀프" } }, "outputs": { "0": { "tooltip": null } } };
const USOStyleReference = { "display_name": "USO 스타일 참조", "inputs": { "clip_vision_output": { "name": "CLIP 비전 출력" }, "model": { "name": "모델" }, "model_patch": { "name": "모델 패치" } } };
const UpscaleModelLoader = { "display_name": "업스케일 모델 로드", "inputs": { "model_name": { "name": "모델 파일명" } }, "outputs": { "0": { "tooltip": null } } };
const VAEDecode = { "description": "잠재 데이터를 픽셀 공간 이미지로 디코딩합니다.", "display_name": "VAE 디코드", "inputs": { "samples": { "name": "잠재 데이터", "tooltip": "디코딩할 잠재입니다." }, "vae": { "name": "vae", "tooltip": "잠재 디코딩에 사용되는 VAE 모델입니다." } }, "outputs": { "0": { "tooltip": "디코딩된 이미지입니다." } } };
const VAEDecodeAudio = { "display_name": "오디오 VAE 디코드", "inputs": { "samples": { "name": "잠재 오디오" }, "vae": { "name": "vae" } } };
const VAEDecodeHunyuan3D = { "display_name": "VAEDecodeHunyuan3D", "inputs": { "num_chunks": { "name": "분할 수" }, "octree_resolution": { "name": "옥트리 해상도" }, "samples": { "name": "샘플" }, "vae": { "name": "vae" } } };
const VAEDecodeTiled = { "display_name": "VAE 디코드 (타일)", "inputs": { "overlap": { "name": "겹침" }, "samples": { "name": "잠재 데이터" }, "temporal_overlap": { "name": "시간 겹침", "tooltip": "비디오 VAE에만 사용됩니다: 겹치는 프레임의 양." }, "temporal_size": { "name": "시간 크기", "tooltip": "비디오 VAE에만 사용됩니다: 한 번에 디코딩할 프레임의 양." }, "tile_size": { "name": "타일 크기" }, "vae": { "name": "vae" } } };
const VAEEncode = { "display_name": "VAE 인코드", "inputs": { "pixels": { "name": "픽셀 이미지" }, "vae": { "name": "vae" } } };
const VAEEncodeAudio = { "display_name": "오디오 VAE 인코드", "inputs": { "audio": { "name": "오디오" }, "vae": { "name": "vae" } } };
const VAEEncodeForInpaint = { "display_name": "VAE 인코드 (인페인팅용)", "inputs": { "grow_mask_by": { "name": "마스크 확장" }, "mask": { "name": "마스크" }, "pixels": { "name": "픽셀" }, "vae": { "name": "vae" } } };
const VAEEncodeTiled = { "display_name": "VAE 인코드 (타일)", "inputs": { "overlap": { "name": "겹침" }, "pixels": { "name": "픽셀" }, "temporal_overlap": { "name": "시간적 겹침", "tooltip": "비디오 VAE에만 사용됩니다: 겹치는 프레임의 양." }, "temporal_size": { "name": "시간적 크기", "tooltip": "비디오 VAE에만 사용됩니다: 한 번에 인코딩할 프레임의 양." }, "tile_size": { "name": "타일 크기" }, "vae": { "name": "vae" } } };
const VAELoader = { "display_name": "VAE 로드", "inputs": { "vae_name": { "name": "vae 파일명" } } };
const VAESave = { "display_name": "VAE 저장", "inputs": { "filename_prefix": { "name": "파일명 접두사" }, "vae": { "name": "vae" } } };
const VPScheduler = { "display_name": "VP 스케줄러", "inputs": { "beta_d": { "name": "beta_d" }, "beta_min": { "name": "beta_min" }, "eps_s": { "name": "eps_s" }, "steps": { "name": "스텝 수" } } };
const Veo3VideoGenerationNode = { "description": "Google의 Veo 3 API를 사용하여 텍스트 프롬프트에서 비디오를 생성합니다", "display_name": "Google Veo 3 비디오 생성", "inputs": { "aspect_ratio": { "name": "화면비", "tooltip": "출력 비디오의 화면비" }, "control_after_generate": { "name": "생성 후 제어" }, "duration_seconds": { "name": "지속시간_초", "tooltip": "출력 비디오의 지속 시간(초) (Veo 3은 8초만 지원합니다)" }, "enhance_prompt": { "name": "프롬프트 향상", "tooltip": "AI 지원으로 프롬프트를 향상시킬지 여부" }, "generate_audio": { "name": "오디오 생성", "tooltip": "비디오용 오디오 생성. 모든 Veo 3 모델에서 지원됩니다." }, "image": { "name": "이미지", "tooltip": "비디오 생성을 안내하는 선택적 참조 이미지" }, "model": { "name": "모델", "tooltip": "비디오 생성에 사용할 Veo 3 모델" }, "negative_prompt": { "name": "네거티브 프롬프트", "tooltip": "비디오에서 피해야 할 내용을 안내하는 네거티브 텍스트 프롬프트" }, "person_generation": { "name": "사람 생성", "tooltip": "비디오에서 사람 생성 허용 여부" }, "prompt": { "name": "프롬프트", "tooltip": "비디오의 텍스트 설명" }, "seed": { "name": "시드", "tooltip": "비디오 생성을 위한 시드 (0은 랜덤)" } }, "outputs": { "0": { "tooltip": null } } };
const VeoVideoGenerationNode = { "description": "Google의 Veo API를 사용하여 텍스트 프롬프트로부터 비디오를 생성합니다", "display_name": "Google Veo2 비디오 생성", "inputs": { "aspect_ratio": { "name": "종횡비", "tooltip": "출력 비디오의 가로세로 비율" }, "control_after_generate": { "name": "생성 후 제어" }, "duration_seconds": { "name": "duration_seconds", "tooltip": "출력 비디오의 길이(초)" }, "enhance_prompt": { "name": "프롬프트 개선", "tooltip": "AI 지원으로 프롬프트를 향상시킬지 여부" }, "image": { "name": "이미지", "tooltip": "비디오 생성을 안내할 선택적 참조 이미지" }, "model": { "name": "모델", "tooltip": "비디오 생성에 사용할 Veo 2 모델" }, "negative_prompt": { "name": "부정 프롬프트", "tooltip": "비디오에서 피해야 할 내용을 안내하는 네거티브 텍스트 프롬프트" }, "person_generation": { "name": "사람 생성", "tooltip": "비디오에서 사람 생성을 허용할지 여부" }, "prompt": { "name": "프롬프트", "tooltip": "비디오에 대한 텍스트 설명" }, "seed": { "name": "시드", "tooltip": "비디오 생성용 시드 (0은 무작위)" } }, "outputs": { "0": { "tooltip": null } } };
const VideoLinearCFGGuidance = { "display_name": "비디오 선형 CFG 가이드", "inputs": { "min_cfg": { "name": "최소 cfg" }, "model": { "name": "모델" } } };
const VideoTriangleCFGGuidance = { "display_name": "비디오 삼각형 CFG 가이드", "inputs": { "min_cfg": { "name": "최소 cfg" }, "model": { "name": "모델" } } };
const ViduImageToVideoNode = { "description": "이미지와 선택적 프롬프트로부터 비디오 생성", "display_name": "Vidu 이미지 비디오 생성", "inputs": { "control_after_generate": { "name": "control after generate" }, "duration": { "name": "duration", "tooltip": "출력 비디오의 길이(초 단위)" }, "image": { "name": "image", "tooltip": "생성된 비디오의 시작 프레임으로 사용될 이미지" }, "model": { "name": "model", "tooltip": "모델 이름" }, "movement_amplitude": { "name": "movement_amplitude", "tooltip": "프레임 내 객체들의 움직임 진폭" }, "prompt": { "name": "prompt", "tooltip": "비디오 생성을 위한 텍스트 설명" }, "resolution": { "name": "resolution", "tooltip": "지원되는 값은 모델 및 길이에 따라 다를 수 있음" }, "seed": { "name": "seed", "tooltip": "비디오 생성을 위한 시드(0은 랜덤)" } }, "outputs": { "0": { "tooltip": null } } };
const ViduReferenceVideoNode = { "description": "여러 이미지와 프롬프트로부터 비디오 생성", "display_name": "Vidu 참조 비디오 생성", "inputs": { "aspect_ratio": { "name": "aspect_ratio", "tooltip": "출력 비디오의 화면비" }, "control_after_generate": { "name": "control after generate" }, "duration": { "name": "duration", "tooltip": "출력 비디오의 길이(초 단위)" }, "images": { "name": "images", "tooltip": "일관된 주제로 비디오를 생성하기 위한 참조 이미지(최대 7개 이미지)" }, "model": { "name": "model", "tooltip": "모델 이름" }, "movement_amplitude": { "name": "movement_amplitude", "tooltip": "프레임 내 객체들의 움직임 진폭" }, "prompt": { "name": "prompt", "tooltip": "비디오 생성을 위한 텍스트 설명" }, "resolution": { "name": "resolution", "tooltip": "지원되는 값은 모델 및 길이에 따라 다를 수 있음" }, "seed": { "name": "seed", "tooltip": "비디오 생성을 위한 시드(0은 랜덤)" } }, "outputs": { "0": { "tooltip": null } } };
const ViduStartEndToVideoNode = { "description": "시작 및 종료 프레임과 프롬프트로부터 비디오 생성", "display_name": "Vidu 시작-종료 비디오 생성", "inputs": { "control_after_generate": { "name": "생성 후 제어" }, "duration": { "name": "지속 시간", "tooltip": "출력 비디오의 지속 시간(초 단위)" }, "end_frame": { "name": "end_frame", "tooltip": "종료 프레임" }, "first_frame": { "name": "first_frame", "tooltip": "시작 프레임" }, "model": { "name": "model", "tooltip": "모델 이름" }, "movement_amplitude": { "name": "움직임 강도", "tooltip": "프레임 내 객체의 움직임 강도" }, "prompt": { "name": "prompt", "tooltip": "비디오 생성을 위한 텍스트 설명" }, "resolution": { "name": "해상도", "tooltip": "지원되는 값은 모델 및 지속 시간에 따라 다를 수 있음" }, "seed": { "name": "시드", "tooltip": "비디오 생성 시드 값 (0일 경우 무작위)" } }, "outputs": { "0": { "tooltip": null } } };
const ViduTextToVideoNode = { "description": "텍스트 프롬프트로 비디오 생성", "display_name": "Vidu 텍스트 비디오 생성", "inputs": { "aspect_ratio": { "name": "화면비", "tooltip": "출력 비디오의 화면비" }, "control_after_generate": { "name": "생성 후 제어" }, "duration": { "name": "지속 시간", "tooltip": "출력 비디오의 지속 시간(초 단위)" }, "model": { "name": "모델", "tooltip": "모델 이름" }, "movement_amplitude": { "name": "움직임 강도", "tooltip": "프레임 내 객체의 움직임 강도" }, "prompt": { "name": "프롬프트", "tooltip": "비디오 생성을 위한 텍스트 설명" }, "resolution": { "name": "해상도", "tooltip": "지원되는 값은 모델 및 지속 시간에 따라 다를 수 있음" }, "seed": { "name": "시드", "tooltip": "비디오 생성 시드 값 (0일 경우 무작위)" } }, "outputs": { "0": { "tooltip": null } } };
const VoxelToMesh = { "display_name": "복셀 → 매시", "inputs": { "algorithm": { "name": "알고리즘" }, "threshold": { "name": "임계값" }, "voxel": { "name": "복셀" } } };
const VoxelToMeshBasic = { "display_name": "복셀 → 매시 (기본)", "inputs": { "threshold": { "name": "임계값" }, "voxel": { "name": "복셀" } } };
const Wan22FunControlToVideo = { "display_name": "Wan22FunControlToVideo", "inputs": { "batch_size": { "name": "배치 크기" }, "control_video": { "name": "제어 비디오" }, "height": { "name": "높이" }, "length": { "name": "길이" }, "negative": { "name": "부정 프롬프트" }, "positive": { "name": "긍정 프롬프트" }, "ref_image": { "name": "참조 이미지" }, "vae": { "name": "VAE" }, "width": { "name": "너비" } }, "outputs": { "0": { "name": "긍정 프롬프트", "tooltip": null }, "1": { "name": "부정 프롬프트", "tooltip": null }, "2": { "name": "잠재 공간", "tooltip": null } } };
const Wan22ImageToVideoLatent = { "display_name": "Wan22ImageToVideoLatent", "inputs": { "batch_size": { "name": "배치 크기" }, "height": { "name": "높이" }, "length": { "name": "길이" }, "start_image": { "name": "시작 이미지" }, "vae": { "name": "VAE" }, "width": { "name": "너비" } }, "outputs": { "0": { "tooltip": null } } };
const WanAnimateToVideo = { "display_name": "완애니메이트투비디오", "inputs": { "background_video": { "name": "배경 비디오" }, "batch_size": { "name": "배치 크기" }, "character_mask": { "name": "캐릭터 마스크" }, "clip_vision_output": { "name": "클립 비전 출력" }, "continue_motion": { "name": "연속 모션" }, "continue_motion_max_frames": { "name": "연속 모션 최대 프레임 수" }, "face_video": { "name": "얼굴 비디오" }, "height": { "name": "높이" }, "length": { "name": "길이" }, "negative": { "name": "부정 프롬프트" }, "pose_video": { "name": "포즈 비디오" }, "positive": { "name": "긍정 프롬프트" }, "reference_image": { "name": "참조 이미지" }, "vae": { "name": "VAE" }, "video_frame_offset": { "name": "비디오 프레임 오프셋", "tooltip": "모든 입력 비디오에서 탐색할 프레임 수입니다. 청크 방식으로 더 긴 비디오를 생성하는 데 사용됩니다. 비디오를 연장하려면 이전 노드의 video_frame_offset 출력에 연결하세요." }, "width": { "name": "너비" } }, "outputs": { "0": { "name": "긍정 프롬프트", "tooltip": null }, "1": { "name": "부정 프롬프트", "tooltip": null }, "2": { "name": "잠재 공간", "tooltip": null }, "3": { "name": "잠재 공간 트리밍", "tooltip": null }, "4": { "name": "이미지 트리밍", "tooltip": null }, "5": { "name": "비디오 프레임 오프셋", "tooltip": null } } };
const WanCameraEmbedding = { "display_name": "완카메라임베딩", "inputs": { "camera_pose": { "name": "카메라 포즈" }, "cx": { "name": "cx" }, "cy": { "name": "cy" }, "fx": { "name": "fx" }, "fy": { "name": "fy" }, "height": { "name": "높이" }, "length": { "name": "길이" }, "speed": { "name": "속도" }, "width": { "name": "너비" } }, "outputs": { "0": { "name": "카메라 임베딩", "tooltip": null }, "1": { "name": "너비", "tooltip": null }, "2": { "name": "높이", "tooltip": null }, "3": { "name": "길이", "tooltip": null } } };
const WanCameraImageToVideo = { "display_name": "완카메라이미지투비디오", "inputs": { "batch_size": { "name": "배치 크기" }, "camera_conditions": { "name": "카메라 조건" }, "clip_vision_output": { "name": "CLIP 비전 출력" }, "height": { "name": "높이" }, "length": { "name": "길이" }, "negative": { "name": "부정 프롬프트" }, "positive": { "name": "긍정 프롬프트" }, "start_image": { "name": "시작 이미지" }, "vae": { "name": "VAE" }, "width": { "name": "너비" } }, "outputs": { "0": { "name": "긍정 프롬프트", "tooltip": null }, "1": { "name": "부정 프롬프트", "tooltip": null }, "2": { "name": "잠재 공간", "tooltip": null } } };
const WanContextWindowsManual = { "description": "WAN 유사 모델에 대한 컨텍스트 창을 수동으로 설정합니다 (dim=2).", "display_name": "WAN 컨텍스트 창 (수동)", "inputs": { "closed_loop": { "name": "폐쇄 루프", "tooltip": "컨텍스트 창 루프를 닫을지 여부입니다. 루프 스케줄에만 적용됩니다." }, "context_length": { "name": "컨텍스트 길이", "tooltip": "컨텍스트 창의 길이입니다." }, "context_overlap": { "name": "컨텍스트 오버랩", "tooltip": "컨텍스트 창의 오버랩입니다." }, "context_schedule": { "name": "컨텍스트 스케줄", "tooltip": "컨텍스트 창의 스트라이드입니다." }, "context_stride": { "name": "컨텍스트 스트라이드", "tooltip": "컨텍스트 창의 스트라이드입니다. 균일 스케줄에만 적용됩니다." }, "fuse_method": { "name": "퓨즈 방법", "tooltip": "컨텍스트 창을 융합하는 데 사용할 방법입니다." }, "model": { "name": "모델", "tooltip": "샘플링 중 컨텍스트 창을 적용할 모델입니다." } }, "outputs": { "0": { "tooltip": "샘플링 중 컨텍스트 창이 적용된 모델입니다." } } };
const WanFirstLastFrameToVideo = { "display_name": "WAN 비디오 생성 (시작-끝 프레임)", "inputs": { "batch_size": { "name": "배치 크기" }, "clip_vision_end_image": { "name": "clip 비전 종료 이미지" }, "clip_vision_start_image": { "name": "clip 비전 시작 이미지" }, "end_image": { "name": "종료 이미지" }, "height": { "name": "높이" }, "length": { "name": "길이" }, "negative": { "name": "부정 조건" }, "positive": { "name": "긍정 조건" }, "start_image": { "name": "시작 이미지" }, "vae": { "name": "vae" }, "width": { "name": "너비" } }, "outputs": { "0": { "name": "긍정 조건", "tooltip": null }, "1": { "name": "부정 조건", "tooltip": null }, "2": { "name": "latent", "tooltip": null } } };
const WanFunControlToVideo = { "display_name": "WAN 비디오 생성 (Fun Control)", "inputs": { "batch_size": { "name": "배치 크기" }, "clip_vision_output": { "name": "clip 비전 출력" }, "control_video": { "name": "제어 비디오" }, "height": { "name": "높이" }, "length": { "name": "길이" }, "negative": { "name": "부정 조건" }, "positive": { "name": "긍정 조건" }, "start_image": { "name": "시작 이미지" }, "vae": { "name": "vae" }, "width": { "name": "너비" } }, "outputs": { "0": { "name": "긍정 조건", "tooltip": null }, "1": { "name": "부정 조건", "tooltip": null }, "2": { "name": "latent", "tooltip": null } } };
const WanFunInpaintToVideo = { "display_name": "WAN 비디오 생성 (Fun Inpaint)", "inputs": { "batch_size": { "name": "배치 크기" }, "clip_vision_output": { "name": "clip_vision 출력" }, "end_image": { "name": "종료 이미지" }, "height": { "name": "높이" }, "length": { "name": "길이" }, "negative": { "name": "부정 조건" }, "positive": { "name": "긍정 조건" }, "start_image": { "name": "시작 이미지" }, "vae": { "name": "vae" }, "width": { "name": "너비" } }, "outputs": { "0": { "name": "긍정 조건", "tooltip": null }, "1": { "name": "부정 조건", "tooltip": null }, "2": { "name": "latent", "tooltip": null } } };
const WanHuMoImageToVideo = { "display_name": "WanHuMo 이미지-비디오 변환", "inputs": { "audio_encoder_output": { "name": "오디오 인코더 출력" }, "batch_size": { "name": "배치 크기" }, "height": { "name": "높이" }, "length": { "name": "길이" }, "negative": { "name": "부정 프롬프트" }, "positive": { "name": "긍정 프롬프트" }, "ref_image": { "name": "참조 이미지" }, "vae": { "name": "VAE" }, "width": { "name": "너비" } }, "outputs": { "0": { "name": "긍정 프롬프트", "tooltip": null }, "1": { "name": "부정 프롬프트", "tooltip": null }, "2": { "name": "잠재 공간", "tooltip": null } } };
const WanImageToImageApi = { "description": "하나 또는 두 개의 입력 이미지와 텍스트 프롬프트로부터 이미지를 생성합니다. 출력 이미지는 현재 1.6 MP로 고정되며, 종횡비는 입력 이미지와 일치합니다.", "display_name": "Wan 이미지-이미지 변환", "inputs": { "control_after_generate": { "name": "생성 후 제어" }, "image": { "name": "이미지", "tooltip": "단일 이미지 편집 또는 다중 이미지 융합, 최대 2개 이미지." }, "model": { "name": "모델", "tooltip": "사용할 모델입니다." }, "negative_prompt": { "name": "네거티브 프롬프트", "tooltip": "피해야 할 내용을 안내하는 네거티브 텍스트 프롬프트입니다." }, "prompt": { "name": "프롬프트", "tooltip": "요소와 시각적 특징을 설명하는 데 사용되는 프롬프트로, 영어/중국어를 지원합니다." }, "seed": { "name": "시드", "tooltip": "생성에 사용할 시드 값입니다." }, "watermark": { "name": "워터마크", "tooltip": '결과물에 "AI 생성" 워터마크를 추가할지 여부입니다.' } }, "outputs": { "0": { "tooltip": null } } };
const WanImageToVideo = { "display_name": "WAN 비디오 생성 (이미지 → 비디오)", "inputs": { "batch_size": { "name": "배치 크기" }, "clip_vision_output": { "name": "clip_vision 출력" }, "height": { "name": "높이" }, "length": { "name": "길이" }, "negative": { "name": "부정 조건" }, "positive": { "name": "긍정 조건" }, "start_image": { "name": "시작 이미지" }, "vae": { "name": "vae" }, "width": { "name": "너비" } }, "outputs": { "0": { "name": "긍정 조건", "tooltip": null }, "1": { "name": "부정 조건", "tooltip": null }, "2": { "name": "잠재 비디오", "tooltip": null } } };
const WanImageToVideoApi = { "description": "첫 번째 프레임과 텍스트 프롬프트를 기반으로 비디오를 생성합니다.", "display_name": "Wan 이미지-비디오 변환", "inputs": { "audio": { "name": "오디오", "tooltip": "오디오는 명확하고 큰 음성으로, 잡음이나 배경 음악 없이 포함되어야 합니다." }, "control_after_generate": { "name": "생성 후 제어" }, "duration": { "name": "지속 시간", "tooltip": "사용 가능한 지속 시간: 5초 및 10초" }, "generate_audio": { "name": "오디오 생성", "tooltip": "오디오 입력이 없을 경우 자동으로 오디오를 생성합니다." }, "image": { "name": "이미지" }, "model": { "name": "모델", "tooltip": "사용할 모델입니다." }, "negative_prompt": { "name": "네거티브 프롬프트", "tooltip": "피해야 할 내용을 안내하는 네거티브 텍스트 프롬프트입니다." }, "prompt": { "name": "프롬프트", "tooltip": "요소와 시각적 특징을 설명하는 데 사용되는 프롬프트로, 영어/중국어를 지원합니다." }, "prompt_extend": { "name": "프롬프트 확장", "tooltip": "AI 지원으로 프롬프트를 향상시킬지 여부입니다." }, "resolution": { "name": "해상도" }, "seed": { "name": "시드", "tooltip": "생성에 사용할 시드 값입니다." }, "watermark": { "name": "워터마크", "tooltip": '결과물에 "AI 생성" 워터마크를 추가할지 여부입니다.' } }, "outputs": { "0": { "tooltip": null } } };
const WanPhantomSubjectToVideo = { "display_name": "WanPhantomSubjectToVideo", "inputs": { "batch_size": { "name": "배치 크기" }, "height": { "name": "높이" }, "images": { "name": "이미지" }, "length": { "name": "길이" }, "negative": { "name": "네거티브" }, "positive": { "name": "포지티브" }, "vae": { "name": "VAE" }, "width": { "name": "너비" } }, "outputs": { "0": { "name": "포지티브", "tooltip": null }, "1": { "name": "네거티브 텍스트", "tooltip": null }, "2": { "name": "네거티브 이미지 텍스트", "tooltip": null }, "3": { "name": "잠재", "tooltip": null } } };
const WanSoundImageToVideo = { "display_name": "WanSoundImageToVideo", "inputs": { "audio_encoder_output": { "name": "오디오 인코더 출력" }, "batch_size": { "name": "배치 크기" }, "control_video": { "name": "제어 비디오" }, "height": { "name": "높이" }, "length": { "name": "길이" }, "negative": { "name": "부정 프롬프트" }, "positive": { "name": "긍정 프롬프트" }, "ref_image": { "name": "참조 이미지" }, "ref_motion": { "name": "참조 모션" }, "vae": { "name": "VAE" }, "width": { "name": "너비" } }, "outputs": { "0": { "name": "긍정 프롬프트", "tooltip": null }, "1": { "name": "부정 프롬프트", "tooltip": null }, "2": { "name": "잠재 공간", "tooltip": null } } };
const WanSoundImageToVideoExtend = { "display_name": "WanSoundImageToVideoExtend", "inputs": { "audio_encoder_output": { "name": "오디오 인코더 출력" }, "control_video": { "name": "제어 비디오" }, "length": { "name": "길이" }, "negative": { "name": "부정 프롬프트" }, "positive": { "name": "긍정 프롬프트" }, "ref_image": { "name": "참조 이미지" }, "vae": { "name": "VAE" }, "video_latent": { "name": "비디오 잠재 공간" } }, "outputs": { "0": { "name": "긍정 프롬프트", "tooltip": null }, "1": { "name": "부정 프롬프트", "tooltip": null }, "2": { "name": "잠재 공간", "tooltip": null } } };
const WanTextToImageApi = { "description": "텍스트 프롬프트를 기반으로 이미지를 생성합니다.", "display_name": "Wan 텍스트 투 이미지", "inputs": { "control_after_generate": { "name": "생성 후 제어" }, "height": { "name": "높이" }, "model": { "name": "모델", "tooltip": "사용할 모델." }, "negative_prompt": { "name": "부정 프롬프트", "tooltip": "피해야 할 내용을 안내하는 부정 텍스트 프롬프트입니다." }, "prompt": { "name": "프롬프트", "tooltip": "요소와 시각적 특징을 설명하는 프롬프트로, 영어/중국어를 지원합니다." }, "prompt_extend": { "name": "프롬프트 확장", "tooltip": "AI 지원으로 프롬프트를 향상시킬지 여부입니다." }, "seed": { "name": "시드", "tooltip": "생성에 사용할 시드 값입니다." }, "watermark": { "name": "워터마크", "tooltip": '결과물에 "AI 생성" 워터마크를 추가할지 여부입니다.' }, "width": { "name": "너비" } }, "outputs": { "0": { "tooltip": null } } };
const WanTextToVideoApi = { "description": "텍스트 프롬프트를 기반으로 비디오를 생성합니다.", "display_name": "Wan 텍스트 투 비디오", "inputs": { "audio": { "name": "오디오", "tooltip": "오디오는 명확하고 큰 음성으로, 잡음이나 배경 음악 없이 포함되어야 합니다." }, "control_after_generate": { "name": "생성 후 제어" }, "duration": { "name": "지속 시간", "tooltip": "사용 가능한 지속 시간: 5초와 10초" }, "generate_audio": { "name": "오디오 생성", "tooltip": "오디오 입력이 없을 경우 자동으로 오디오를 생성합니다." }, "model": { "name": "모델", "tooltip": "사용할 모델." }, "negative_prompt": { "name": "부정 프롬프트", "tooltip": "피해야 할 내용을 안내하는 부정 텍스트 프롬프트." }, "prompt": { "name": "프롬프트", "tooltip": "요소와 시각적 특징을 설명하는 데 사용되는 프롬프트로, 영어/중국어를 지원합니다." }, "prompt_extend": { "name": "프롬프트 확장", "tooltip": "AI 지원으로 프롬프트를 향상시킬지 여부." }, "seed": { "name": "시드", "tooltip": "생성에 사용할 시드 값." }, "size": { "name": "크기" }, "watermark": { "name": "워터마크", "tooltip": '결과에 "AI 생성" 워터마크를 추가할지 여부.' } }, "outputs": { "0": { "tooltip": null } } };
const WanTrackToVideo = { "display_name": "WanTrackToVideo", "inputs": { "batch_size": { "name": "배치 크기" }, "clip_vision_output": { "name": "CLIP 비전 출력" }, "height": { "name": "높이" }, "length": { "name": "길이" }, "negative": { "name": "부정" }, "positive": { "name": "긍정" }, "start_image": { "name": "시작 이미지" }, "temperature": { "name": "온도" }, "topk": { "name": "상위 K" }, "tracks": { "name": "트랙" }, "vae": { "name": "VAE" }, "width": { "name": "너비" } }, "outputs": { "0": { "name": "긍정", "tooltip": null }, "1": { "name": "부정", "tooltip": null }, "2": { "name": "잠재", "tooltip": null } } };
const WanVaceToVideo = { "display_name": "WAN 비디오 생성 (VACE)", "inputs": { "batch_size": { "name": "배치 크기" }, "control_masks": { "name": "제어 마스크" }, "control_video": { "name": "제어 비디오" }, "height": { "name": "높이" }, "length": { "name": "길이" }, "negative": { "name": "부정 조건" }, "positive": { "name": "긍정 조건" }, "reference_image": { "name": "참조 이미지" }, "strength": { "name": "강도" }, "vae": { "name": "vae" }, "width": { "name": "너비" } }, "outputs": { "0": { "name": "긍정 조건", "tooltip": null }, "1": { "name": "부정 조건", "tooltip": null }, "2": { "name": "잠재 비디오", "tooltip": null }, "3": { "name": "잘린 잠재 비디오", "tooltip": null } } };
const WebcamCapture = { "display_name": "웹캠 캡처", "inputs": { "capture_on_queue": { "name": "큐에서 캡처" }, "height": { "name": "높이" }, "image": { "name": "이미지" }, "waiting for camera___": {}, "width": { "name": "너비" } } };
const unCLIPCheckpointLoader = { "display_name": "unCLIP 체크포인트 로드", "inputs": { "ckpt_name": { "name": "체크포인트 파일명" } } };
const unCLIPConditioning = { "display_name": "unCLIP 조건 설정", "inputs": { "clip_vision_output": { "name": "clip_vision 출력" }, "conditioning": { "name": "조건" }, "noise_augmentation": { "name": "노이즈 증강" }, "strength": { "name": "강도" } } };
const nodeDefs = {
  APG,
  AddNoise,
  AlignYourStepsScheduler,
  AudioAdjustVolume,
  AudioConcat,
  AudioEncoderEncode,
  AudioEncoderLoader,
  AudioMerge,
  BasicGuider,
  BasicScheduler,
  BetaSamplingScheduler,
  ByteDanceFirstLastFrameNode,
  ByteDanceImageEditNode,
  ByteDanceImageNode,
  ByteDanceImageReferenceNode,
  ByteDanceImageToVideoNode,
  ByteDanceSeedreamNode,
  ByteDanceTextToVideoNode,
  CFGGuider,
  CFGNorm,
  CFGZeroStar,
  CLIPAttentionMultiply,
  CLIPLoader,
  CLIPMergeAdd,
  CLIPMergeSimple,
  CLIPMergeSubtract,
  CLIPSave,
  CLIPSetLastLayer,
  CLIPTextEncode,
  CLIPTextEncodeControlnet,
  CLIPTextEncodeFlux,
  CLIPTextEncodeHiDream,
  CLIPTextEncodeHunyuanDiT,
  CLIPTextEncodeLumina2,
  CLIPTextEncodePixArtAlpha,
  CLIPTextEncodeSD3,
  CLIPTextEncodeSDXL,
  CLIPTextEncodeSDXLRefiner,
  CLIPVisionEncode,
  CLIPVisionLoader,
  Canny,
  CaseConverter,
  CheckpointLoader,
  CheckpointLoaderSimple,
  CheckpointSave,
  ChromaRadianceOptions,
  CombineHooks2,
  CombineHooks4,
  CombineHooks8,
  ConditioningAverage,
  ConditioningCombine,
  ConditioningConcat,
  ConditioningSetArea,
  ConditioningSetAreaPercentage,
  ConditioningSetAreaPercentageVideo,
  ConditioningSetAreaStrength,
  ConditioningSetDefaultCombine,
  ConditioningSetMask,
  ConditioningSetProperties,
  ConditioningSetPropertiesAndCombine,
  ConditioningSetTimestepRange,
  ConditioningStableAudio,
  ConditioningTimestepsRange,
  ConditioningZeroOut,
  ContextWindowsManual,
  ControlNetApply,
  ControlNetApplyAdvanced,
  ControlNetApplySD3,
  ControlNetInpaintingAliMamaApply,
  ControlNetLoader,
  CosmosImageToVideoLatent,
  CosmosPredict2ImageToVideoLatent,
  CreateHookKeyframe,
  CreateHookKeyframesFromFloats,
  CreateHookKeyframesInterpolated,
  CreateHookLora,
  CreateHookLoraModelOnly,
  CreateHookModelAsLora,
  CreateHookModelAsLoraModelOnly,
  CreateVideo,
  CropMask,
  DiffControlNetLoader,
  DifferentialDiffusion,
  DiffusersLoader,
  DisableNoise,
  DualCFGGuider,
  DualCLIPLoader,
  EasyCache,
  EmptyAceStepLatentAudio,
  EmptyAudio,
  EmptyChromaRadianceLatentImage,
  EmptyCosmosLatentVideo,
  EmptyHunyuanImageLatent,
  EmptyHunyuanLatentVideo,
  EmptyImage,
  EmptyLTXVLatentVideo,
  EmptyLatentAudio,
  EmptyLatentHunyuan3Dv2,
  EmptyLatentImage,
  EmptyMochiLatentVideo,
  EmptySD3LatentImage,
  "Epsilon Scaling": { "display_name": "엡실론 스케일링", "inputs": { "model": { "name": "모델" }, "scaling_factor": { "name": "스케일링 계수" } }, "outputs": { "0": { "tooltip": null } } },
  ExponentialScheduler,
  ExtendIntermediateSigmas,
  FeatherMask,
  FlipSigmas,
  FluxDisableGuidance,
  FluxGuidance,
  FluxKontextImageScale,
  FluxKontextMaxImageNode,
  FluxKontextMultiReferenceLatentMethod,
  FluxKontextProImageNode,
  FluxProExpandNode,
  FluxProFillNode,
  FluxProUltraImageNode,
  FreSca,
  FreeU,
  FreeU_V2,
  GITSScheduler,
  GLIGENLoader,
  GLIGENTextBoxApply,
  GeminiImageNode,
  GeminiInputFiles,
  GeminiNode,
  GetImageSize,
  GetVideoComponents,
  GrowMask,
  Hunyuan3Dv2Conditioning,
  Hunyuan3Dv2ConditioningMultiView,
  HunyuanImageToVideo,
  HunyuanRefinerLatent,
  HyperTile,
  HypernetworkLoader,
  IdeogramV1,
  IdeogramV2,
  IdeogramV3,
  ImageAddNoise,
  ImageBatch,
  ImageBlend,
  ImageBlur,
  ImageColorToMask,
  ImageCompositeMasked,
  ImageCrop,
  ImageFlip,
  ImageFromBatch,
  ImageInvert,
  ImageOnlyCheckpointLoader,
  ImageOnlyCheckpointSave,
  ImagePadForOutpaint,
  ImageQuantize,
  ImageRGBToYUV,
  ImageRotate,
  ImageScale,
  ImageScaleBy,
  ImageScaleToMaxDimension,
  ImageScaleToTotalPixels,
  ImageSharpen,
  ImageStitch,
  ImageToMask,
  ImageUpscaleWithModel,
  ImageYUVToRGB,
  InpaintModelConditioning,
  InstructPixToPixConditioning,
  InvertMask,
  JoinImageWithAlpha,
  KSampler,
  KSamplerAdvanced,
  KSamplerSelect,
  KarrasScheduler,
  KlingCameraControlI2VNode,
  KlingCameraControlT2VNode,
  KlingCameraControls,
  KlingDualCharacterVideoEffectNode,
  KlingImage2VideoNode,
  KlingImageGenerationNode,
  KlingLipSyncAudioToVideoNode,
  KlingLipSyncTextToVideoNode,
  KlingSingleImageVideoEffectNode,
  KlingStartEndFrameNode,
  KlingTextToVideoNode,
  KlingVideoExtendNode,
  KlingVirtualTryOnNode,
  LTXVAddGuide,
  LTXVConditioning,
  LTXVCropGuides,
  LTXVImgToVideo,
  LTXVPreprocess,
  LTXVScheduler,
  LaplaceScheduler,
  LatentAdd,
  LatentApplyOperation,
  LatentApplyOperationCFG,
  LatentBatch,
  LatentBatchSeedBehavior,
  LatentBlend,
  LatentComposite,
  LatentCompositeMasked,
  LatentConcat,
  LatentCrop,
  LatentCut,
  LatentFlip,
  LatentFromBatch,
  LatentInterpolate,
  LatentMultiply,
  LatentOperationSharpen,
  LatentOperationTonemapReinhard,
  LatentRotate,
  LatentSubtract,
  LatentUpscale,
  LatentUpscaleBy,
  LazyCache,
  Load3D,
  LoadAudio,
  LoadImage,
  LoadImageMask,
  LoadImageOutput,
  LoadLatent,
  LoadVideo,
  LoraLoader,
  LoraLoaderModelOnly,
  LoraModelLoader,
  LoraSave,
  LossGraphNode,
  LotusConditioning,
  LtxvApiImageToVideo,
  LtxvApiTextToVideo,
  LumaConceptsNode,
  LumaImageModifyNode,
  LumaImageNode,
  LumaImageToVideoNode,
  LumaReferenceNode,
  LumaVideoNode,
  Mahiro,
  MaskComposite,
  MaskPreview,
  MaskToImage,
  MinimaxHailuoVideoNode,
  MinimaxImageToVideoNode,
  MinimaxTextToVideoNode,
  ModelComputeDtype,
  ModelMergeAdd,
  ModelMergeAuraflow,
  ModelMergeBlocks,
  ModelMergeCosmos14B,
  ModelMergeCosmos7B,
  ModelMergeCosmosPredict2_14B,
  ModelMergeCosmosPredict2_2B,
  ModelMergeFlux1,
  ModelMergeLTXV,
  ModelMergeMochiPreview,
  ModelMergeQwenImage,
  ModelMergeSD1,
  ModelMergeSD2,
  ModelMergeSD35_Large,
  ModelMergeSD3_2B,
  ModelMergeSDXL,
  ModelMergeSimple,
  ModelMergeSubtract,
  ModelMergeWAN2_1,
  ModelPatchLoader,
  ModelSamplingAuraFlow,
  ModelSamplingContinuousEDM,
  ModelSamplingContinuousV,
  ModelSamplingDiscrete,
  ModelSamplingFlux,
  ModelSamplingLTXV,
  ModelSamplingSD3,
  ModelSamplingStableCascade,
  ModelSave,
  MoonvalleyImg2VideoNode,
  MoonvalleyTxt2VideoNode,
  MoonvalleyVideo2VideoNode,
  Morphology,
  OpenAIChatConfig,
  OpenAIChatNode,
  OpenAIDalle2,
  OpenAIDalle3,
  OpenAIGPTImage1,
  OpenAIInputFiles,
  OpenAIVideoSora2,
  OptimalStepsScheduler,
  PairConditioningCombine,
  PairConditioningSetDefaultCombine,
  PairConditioningSetProperties,
  PairConditioningSetPropertiesAndCombine,
  PatchModelAddDownscale,
  PerpNeg,
  PerpNegGuider,
  PerturbedAttentionGuidance,
  PhotoMakerEncode,
  PhotoMakerLoader,
  PixverseImageToVideoNode,
  PixverseTemplateNode,
  PixverseTextToVideoNode,
  PixverseTransitionVideoNode,
  PolyexponentialScheduler,
  PorterDuffImageComposite,
  Preview3D,
  PreviewAny,
  PreviewAudio,
  PreviewImage,
  PrimitiveBoolean,
  PrimitiveFloat,
  PrimitiveInt,
  PrimitiveString,
  PrimitiveStringMultiline,
  QuadrupleCLIPLoader,
  QwenImageDiffsynthControlnet,
  RandomNoise,
  RebatchImages,
  RebatchLatents,
  RecordAudio,
  RecraftColorRGB,
  RecraftControls,
  RecraftCreativeUpscaleNode,
  RecraftCrispUpscaleNode,
  RecraftImageInpaintingNode,
  RecraftImageToImageNode,
  RecraftRemoveBackgroundNode,
  RecraftReplaceBackgroundNode,
  RecraftStyleV3DigitalIllustration,
  RecraftStyleV3InfiniteStyleLibrary,
  RecraftStyleV3LogoRaster,
  RecraftStyleV3RealisticImage,
  RecraftTextToImageNode,
  RecraftTextToVectorNode,
  RecraftVectorizeImageNode,
  ReferenceLatent,
  RegexExtract,
  RegexMatch,
  RegexReplace,
  RenormCFG,
  RepeatImageBatch,
  RepeatLatentBatch,
  RescaleCFG,
  ResizeAndPadImage,
  Rodin3D_Detail,
  Rodin3D_Gen2,
  Rodin3D_Regular,
  Rodin3D_Sketch,
  Rodin3D_Smooth,
  RunwayFirstLastFrameNode,
  RunwayImageToVideoNodeGen3a,
  RunwayImageToVideoNodeGen4,
  RunwayTextToImageNode,
  SDTurboScheduler,
  SD_4XUpscale_Conditioning,
  SV3D_Conditioning,
  SVD_img2vid_Conditioning,
  SamplerCustom,
  SamplerCustomAdvanced,
  SamplerDPMAdaptative,
  SamplerDPMPP_2M_SDE,
  SamplerDPMPP_2S_Ancestral,
  SamplerDPMPP_3M_SDE,
  SamplerDPMPP_SDE,
  SamplerER_SDE,
  SamplerEulerAncestral,
  SamplerEulerAncestralCFGPP,
  SamplerEulerCFGpp,
  SamplerLCMUpscale,
  SamplerLMS,
  SamplerSASolver,
  SamplingPercentToSigma,
  SaveAnimatedPNG,
  SaveAnimatedWEBP,
  SaveAudio,
  SaveAudioMP3,
  SaveAudioOpus,
  SaveGLB,
  SaveImage,
  SaveImageWebsocket,
  SaveLatent,
  SaveSVGNode,
  SaveVideo,
  SaveWEBM,
  ScaleROPE,
  SelfAttentionGuidance,
  SetClipHooks,
  SetFirstSigma,
  SetHookKeyframes,
  SetLatentNoiseMask,
  SetUnionControlNetType,
  SkipLayerGuidanceDiT,
  SkipLayerGuidanceDiTSimple,
  SkipLayerGuidanceSD3,
  SolidMask,
  SplitAudioChannels,
  SplitImageWithAlpha,
  SplitSigmas,
  SplitSigmasDenoise,
  StabilityAudioInpaint,
  StabilityAudioToAudio,
  StabilityStableImageSD_3_5Node,
  StabilityStableImageUltraNode,
  StabilityTextToAudio,
  StabilityUpscaleConservativeNode,
  StabilityUpscaleCreativeNode,
  StabilityUpscaleFastNode,
  StableCascade_EmptyLatentImage,
  StableCascade_StageB_Conditioning,
  StableCascade_StageC_VAEEncode,
  StableCascade_SuperResolutionControlnet,
  StableZero123_Conditioning,
  StableZero123_Conditioning_Batched,
  StringCompare,
  StringConcatenate,
  StringContains,
  StringLength,
  StringReplace,
  StringSubstring,
  StringTrim,
  StyleModelApply,
  StyleModelLoader,
  T5TokenizerOptions,
  TCFG,
  TemporalScoreRescaling,
  TextEncodeAceStepAudio,
  TextEncodeHunyuanVideo_ImageToVideo,
  TextEncodeQwenImageEdit,
  TextEncodeQwenImageEditPlus,
  ThresholdMask,
  TomePatchModel,
  TorchCompileModel,
  TrainLoraNode,
  TrimAudioDuration,
  TrimVideoLatent,
  TripleCLIPLoader,
  TripoConversionNode,
  TripoImageToModelNode,
  TripoMultiviewToModelNode,
  TripoRefineNode,
  TripoRetargetNode,
  TripoRigNode,
  TripoTextToModelNode,
  TripoTextureNode,
  UNETLoader,
  UNetCrossAttentionMultiply,
  UNetSelfAttentionMultiply,
  UNetTemporalAttentionMultiply,
  USOStyleReference,
  UpscaleModelLoader,
  VAEDecode,
  VAEDecodeAudio,
  VAEDecodeHunyuan3D,
  VAEDecodeTiled,
  VAEEncode,
  VAEEncodeAudio,
  VAEEncodeForInpaint,
  VAEEncodeTiled,
  VAELoader,
  VAESave,
  VPScheduler,
  Veo3VideoGenerationNode,
  VeoVideoGenerationNode,
  VideoLinearCFGGuidance,
  VideoTriangleCFGGuidance,
  ViduImageToVideoNode,
  ViduReferenceVideoNode,
  ViduStartEndToVideoNode,
  ViduTextToVideoNode,
  VoxelToMesh,
  VoxelToMeshBasic,
  Wan22FunControlToVideo,
  Wan22ImageToVideoLatent,
  WanAnimateToVideo,
  WanCameraEmbedding,
  WanCameraImageToVideo,
  WanContextWindowsManual,
  WanFirstLastFrameToVideo,
  WanFunControlToVideo,
  WanFunInpaintToVideo,
  WanHuMoImageToVideo,
  WanImageToImageApi,
  WanImageToVideo,
  WanImageToVideoApi,
  WanPhantomSubjectToVideo,
  WanSoundImageToVideo,
  WanSoundImageToVideoExtend,
  WanTextToImageApi,
  WanTextToVideoApi,
  WanTrackToVideo,
  WanVaceToVideo,
  WebcamCapture,
  unCLIPCheckpointLoader,
  unCLIPConditioning
};
export {
  APG,
  AddNoise,
  AlignYourStepsScheduler,
  AudioAdjustVolume,
  AudioConcat,
  AudioEncoderEncode,
  AudioEncoderLoader,
  AudioMerge,
  BasicGuider,
  BasicScheduler,
  BetaSamplingScheduler,
  ByteDanceFirstLastFrameNode,
  ByteDanceImageEditNode,
  ByteDanceImageNode,
  ByteDanceImageReferenceNode,
  ByteDanceImageToVideoNode,
  ByteDanceSeedreamNode,
  ByteDanceTextToVideoNode,
  CFGGuider,
  CFGNorm,
  CFGZeroStar,
  CLIPAttentionMultiply,
  CLIPLoader,
  CLIPMergeAdd,
  CLIPMergeSimple,
  CLIPMergeSubtract,
  CLIPSave,
  CLIPSetLastLayer,
  CLIPTextEncode,
  CLIPTextEncodeControlnet,
  CLIPTextEncodeFlux,
  CLIPTextEncodeHiDream,
  CLIPTextEncodeHunyuanDiT,
  CLIPTextEncodeLumina2,
  CLIPTextEncodePixArtAlpha,
  CLIPTextEncodeSD3,
  CLIPTextEncodeSDXL,
  CLIPTextEncodeSDXLRefiner,
  CLIPVisionEncode,
  CLIPVisionLoader,
  Canny,
  CaseConverter,
  CheckpointLoader,
  CheckpointLoaderSimple,
  CheckpointSave,
  ChromaRadianceOptions,
  CombineHooks2,
  CombineHooks4,
  CombineHooks8,
  ConditioningAverage,
  ConditioningCombine,
  ConditioningConcat,
  ConditioningSetArea,
  ConditioningSetAreaPercentage,
  ConditioningSetAreaPercentageVideo,
  ConditioningSetAreaStrength,
  ConditioningSetDefaultCombine,
  ConditioningSetMask,
  ConditioningSetProperties,
  ConditioningSetPropertiesAndCombine,
  ConditioningSetTimestepRange,
  ConditioningStableAudio,
  ConditioningTimestepsRange,
  ConditioningZeroOut,
  ContextWindowsManual,
  ControlNetApply,
  ControlNetApplyAdvanced,
  ControlNetApplySD3,
  ControlNetInpaintingAliMamaApply,
  ControlNetLoader,
  CosmosImageToVideoLatent,
  CosmosPredict2ImageToVideoLatent,
  CreateHookKeyframe,
  CreateHookKeyframesFromFloats,
  CreateHookKeyframesInterpolated,
  CreateHookLora,
  CreateHookLoraModelOnly,
  CreateHookModelAsLora,
  CreateHookModelAsLoraModelOnly,
  CreateVideo,
  CropMask,
  DiffControlNetLoader,
  DifferentialDiffusion,
  DiffusersLoader,
  DisableNoise,
  DualCFGGuider,
  DualCLIPLoader,
  EasyCache,
  EmptyAceStepLatentAudio,
  EmptyAudio,
  EmptyChromaRadianceLatentImage,
  EmptyCosmosLatentVideo,
  EmptyHunyuanImageLatent,
  EmptyHunyuanLatentVideo,
  EmptyImage,
  EmptyLTXVLatentVideo,
  EmptyLatentAudio,
  EmptyLatentHunyuan3Dv2,
  EmptyLatentImage,
  EmptyMochiLatentVideo,
  EmptySD3LatentImage,
  ExponentialScheduler,
  ExtendIntermediateSigmas,
  FeatherMask,
  FlipSigmas,
  FluxDisableGuidance,
  FluxGuidance,
  FluxKontextImageScale,
  FluxKontextMaxImageNode,
  FluxKontextMultiReferenceLatentMethod,
  FluxKontextProImageNode,
  FluxProExpandNode,
  FluxProFillNode,
  FluxProUltraImageNode,
  FreSca,
  FreeU,
  FreeU_V2,
  GITSScheduler,
  GLIGENLoader,
  GLIGENTextBoxApply,
  GeminiImageNode,
  GeminiInputFiles,
  GeminiNode,
  GetImageSize,
  GetVideoComponents,
  GrowMask,
  Hunyuan3Dv2Conditioning,
  Hunyuan3Dv2ConditioningMultiView,
  HunyuanImageToVideo,
  HunyuanRefinerLatent,
  HyperTile,
  HypernetworkLoader,
  IdeogramV1,
  IdeogramV2,
  IdeogramV3,
  ImageAddNoise,
  ImageBatch,
  ImageBlend,
  ImageBlur,
  ImageColorToMask,
  ImageCompositeMasked,
  ImageCrop,
  ImageFlip,
  ImageFromBatch,
  ImageInvert,
  ImageOnlyCheckpointLoader,
  ImageOnlyCheckpointSave,
  ImagePadForOutpaint,
  ImageQuantize,
  ImageRGBToYUV,
  ImageRotate,
  ImageScale,
  ImageScaleBy,
  ImageScaleToMaxDimension,
  ImageScaleToTotalPixels,
  ImageSharpen,
  ImageStitch,
  ImageToMask,
  ImageUpscaleWithModel,
  ImageYUVToRGB,
  InpaintModelConditioning,
  InstructPixToPixConditioning,
  InvertMask,
  JoinImageWithAlpha,
  KSampler,
  KSamplerAdvanced,
  KSamplerSelect,
  KarrasScheduler,
  KlingCameraControlI2VNode,
  KlingCameraControlT2VNode,
  KlingCameraControls,
  KlingDualCharacterVideoEffectNode,
  KlingImage2VideoNode,
  KlingImageGenerationNode,
  KlingLipSyncAudioToVideoNode,
  KlingLipSyncTextToVideoNode,
  KlingSingleImageVideoEffectNode,
  KlingStartEndFrameNode,
  KlingTextToVideoNode,
  KlingVideoExtendNode,
  KlingVirtualTryOnNode,
  LTXVAddGuide,
  LTXVConditioning,
  LTXVCropGuides,
  LTXVImgToVideo,
  LTXVPreprocess,
  LTXVScheduler,
  LaplaceScheduler,
  LatentAdd,
  LatentApplyOperation,
  LatentApplyOperationCFG,
  LatentBatch,
  LatentBatchSeedBehavior,
  LatentBlend,
  LatentComposite,
  LatentCompositeMasked,
  LatentConcat,
  LatentCrop,
  LatentCut,
  LatentFlip,
  LatentFromBatch,
  LatentInterpolate,
  LatentMultiply,
  LatentOperationSharpen,
  LatentOperationTonemapReinhard,
  LatentRotate,
  LatentSubtract,
  LatentUpscale,
  LatentUpscaleBy,
  LazyCache,
  Load3D,
  LoadAudio,
  LoadImage,
  LoadImageMask,
  LoadImageOutput,
  LoadLatent,
  LoadVideo,
  LoraLoader,
  LoraLoaderModelOnly,
  LoraModelLoader,
  LoraSave,
  LossGraphNode,
  LotusConditioning,
  LtxvApiImageToVideo,
  LtxvApiTextToVideo,
  LumaConceptsNode,
  LumaImageModifyNode,
  LumaImageNode,
  LumaImageToVideoNode,
  LumaReferenceNode,
  LumaVideoNode,
  Mahiro,
  MaskComposite,
  MaskPreview,
  MaskToImage,
  MinimaxHailuoVideoNode,
  MinimaxImageToVideoNode,
  MinimaxTextToVideoNode,
  ModelComputeDtype,
  ModelMergeAdd,
  ModelMergeAuraflow,
  ModelMergeBlocks,
  ModelMergeCosmos14B,
  ModelMergeCosmos7B,
  ModelMergeCosmosPredict2_14B,
  ModelMergeCosmosPredict2_2B,
  ModelMergeFlux1,
  ModelMergeLTXV,
  ModelMergeMochiPreview,
  ModelMergeQwenImage,
  ModelMergeSD1,
  ModelMergeSD2,
  ModelMergeSD35_Large,
  ModelMergeSD3_2B,
  ModelMergeSDXL,
  ModelMergeSimple,
  ModelMergeSubtract,
  ModelMergeWAN2_1,
  ModelPatchLoader,
  ModelSamplingAuraFlow,
  ModelSamplingContinuousEDM,
  ModelSamplingContinuousV,
  ModelSamplingDiscrete,
  ModelSamplingFlux,
  ModelSamplingLTXV,
  ModelSamplingSD3,
  ModelSamplingStableCascade,
  ModelSave,
  MoonvalleyImg2VideoNode,
  MoonvalleyTxt2VideoNode,
  MoonvalleyVideo2VideoNode,
  Morphology,
  OpenAIChatConfig,
  OpenAIChatNode,
  OpenAIDalle2,
  OpenAIDalle3,
  OpenAIGPTImage1,
  OpenAIInputFiles,
  OpenAIVideoSora2,
  OptimalStepsScheduler,
  PairConditioningCombine,
  PairConditioningSetDefaultCombine,
  PairConditioningSetProperties,
  PairConditioningSetPropertiesAndCombine,
  PatchModelAddDownscale,
  PerpNeg,
  PerpNegGuider,
  PerturbedAttentionGuidance,
  PhotoMakerEncode,
  PhotoMakerLoader,
  PixverseImageToVideoNode,
  PixverseTemplateNode,
  PixverseTextToVideoNode,
  PixverseTransitionVideoNode,
  PolyexponentialScheduler,
  PorterDuffImageComposite,
  Preview3D,
  PreviewAny,
  PreviewAudio,
  PreviewImage,
  PrimitiveBoolean,
  PrimitiveFloat,
  PrimitiveInt,
  PrimitiveString,
  PrimitiveStringMultiline,
  QuadrupleCLIPLoader,
  QwenImageDiffsynthControlnet,
  RandomNoise,
  RebatchImages,
  RebatchLatents,
  RecordAudio,
  RecraftColorRGB,
  RecraftControls,
  RecraftCreativeUpscaleNode,
  RecraftCrispUpscaleNode,
  RecraftImageInpaintingNode,
  RecraftImageToImageNode,
  RecraftRemoveBackgroundNode,
  RecraftReplaceBackgroundNode,
  RecraftStyleV3DigitalIllustration,
  RecraftStyleV3InfiniteStyleLibrary,
  RecraftStyleV3LogoRaster,
  RecraftStyleV3RealisticImage,
  RecraftTextToImageNode,
  RecraftTextToVectorNode,
  RecraftVectorizeImageNode,
  ReferenceLatent,
  RegexExtract,
  RegexMatch,
  RegexReplace,
  RenormCFG,
  RepeatImageBatch,
  RepeatLatentBatch,
  RescaleCFG,
  ResizeAndPadImage,
  Rodin3D_Detail,
  Rodin3D_Gen2,
  Rodin3D_Regular,
  Rodin3D_Sketch,
  Rodin3D_Smooth,
  RunwayFirstLastFrameNode,
  RunwayImageToVideoNodeGen3a,
  RunwayImageToVideoNodeGen4,
  RunwayTextToImageNode,
  SDTurboScheduler,
  SD_4XUpscale_Conditioning,
  SV3D_Conditioning,
  SVD_img2vid_Conditioning,
  SamplerCustom,
  SamplerCustomAdvanced,
  SamplerDPMAdaptative,
  SamplerDPMPP_2M_SDE,
  SamplerDPMPP_2S_Ancestral,
  SamplerDPMPP_3M_SDE,
  SamplerDPMPP_SDE,
  SamplerER_SDE,
  SamplerEulerAncestral,
  SamplerEulerAncestralCFGPP,
  SamplerEulerCFGpp,
  SamplerLCMUpscale,
  SamplerLMS,
  SamplerSASolver,
  SamplingPercentToSigma,
  SaveAnimatedPNG,
  SaveAnimatedWEBP,
  SaveAudio,
  SaveAudioMP3,
  SaveAudioOpus,
  SaveGLB,
  SaveImage,
  SaveImageWebsocket,
  SaveLatent,
  SaveSVGNode,
  SaveVideo,
  SaveWEBM,
  ScaleROPE,
  SelfAttentionGuidance,
  SetClipHooks,
  SetFirstSigma,
  SetHookKeyframes,
  SetLatentNoiseMask,
  SetUnionControlNetType,
  SkipLayerGuidanceDiT,
  SkipLayerGuidanceDiTSimple,
  SkipLayerGuidanceSD3,
  SolidMask,
  SplitAudioChannels,
  SplitImageWithAlpha,
  SplitSigmas,
  SplitSigmasDenoise,
  StabilityAudioInpaint,
  StabilityAudioToAudio,
  StabilityStableImageSD_3_5Node,
  StabilityStableImageUltraNode,
  StabilityTextToAudio,
  StabilityUpscaleConservativeNode,
  StabilityUpscaleCreativeNode,
  StabilityUpscaleFastNode,
  StableCascade_EmptyLatentImage,
  StableCascade_StageB_Conditioning,
  StableCascade_StageC_VAEEncode,
  StableCascade_SuperResolutionControlnet,
  StableZero123_Conditioning,
  StableZero123_Conditioning_Batched,
  StringCompare,
  StringConcatenate,
  StringContains,
  StringLength,
  StringReplace,
  StringSubstring,
  StringTrim,
  StyleModelApply,
  StyleModelLoader,
  T5TokenizerOptions,
  TCFG,
  TemporalScoreRescaling,
  TextEncodeAceStepAudio,
  TextEncodeHunyuanVideo_ImageToVideo,
  TextEncodeQwenImageEdit,
  TextEncodeQwenImageEditPlus,
  ThresholdMask,
  TomePatchModel,
  TorchCompileModel,
  TrainLoraNode,
  TrimAudioDuration,
  TrimVideoLatent,
  TripleCLIPLoader,
  TripoConversionNode,
  TripoImageToModelNode,
  TripoMultiviewToModelNode,
  TripoRefineNode,
  TripoRetargetNode,
  TripoRigNode,
  TripoTextToModelNode,
  TripoTextureNode,
  UNETLoader,
  UNetCrossAttentionMultiply,
  UNetSelfAttentionMultiply,
  UNetTemporalAttentionMultiply,
  USOStyleReference,
  UpscaleModelLoader,
  VAEDecode,
  VAEDecodeAudio,
  VAEDecodeHunyuan3D,
  VAEDecodeTiled,
  VAEEncode,
  VAEEncodeAudio,
  VAEEncodeForInpaint,
  VAEEncodeTiled,
  VAELoader,
  VAESave,
  VPScheduler,
  Veo3VideoGenerationNode,
  VeoVideoGenerationNode,
  VideoLinearCFGGuidance,
  VideoTriangleCFGGuidance,
  ViduImageToVideoNode,
  ViduReferenceVideoNode,
  ViduStartEndToVideoNode,
  ViduTextToVideoNode,
  VoxelToMesh,
  VoxelToMeshBasic,
  Wan22FunControlToVideo,
  Wan22ImageToVideoLatent,
  WanAnimateToVideo,
  WanCameraEmbedding,
  WanCameraImageToVideo,
  WanContextWindowsManual,
  WanFirstLastFrameToVideo,
  WanFunControlToVideo,
  WanFunInpaintToVideo,
  WanHuMoImageToVideo,
  WanImageToImageApi,
  WanImageToVideo,
  WanImageToVideoApi,
  WanPhantomSubjectToVideo,
  WanSoundImageToVideo,
  WanSoundImageToVideoExtend,
  WanTextToImageApi,
  WanTextToVideoApi,
  WanTrackToVideo,
  WanVaceToVideo,
  WebcamCapture,
  nodeDefs as default,
  unCLIPCheckpointLoader,
  unCLIPConditioning
};
//# sourceMappingURL=nodeDefs-D_wreoPJ.js.map
