const APG = { "display_name": "التوجيه المتكيف المسقط", "inputs": { "eta": { "name": "إيتا", "tooltip": "يتحكم في مقياس متجه التوجيه المتوازي. سلوك CFG الافتراضي عند إعداد 1." }, "model": { "name": "النموذج" }, "momentum": { "name": "الزخم", "tooltip": "يتحكم في المتوسط المتحرك للتوجيه أثناء الانتشار، معطل عند إعداد 0." }, "norm_threshold": { "name": "عتبة التطبيع", "tooltip": "تطبيع متجه التوجيه إلى هذه القيمة، يتم تعطيل التطبيع عند إعداد 0." } }, "outputs": { "0": { "tooltip": null } } };
const AddNoise = { "display_name": "إضافة ضجيج", "inputs": { "latent_image": { "name": "الصورة الكامنة" }, "model": { "name": "النموذج" }, "noise": { "name": "الضجيج" }, "sigmas": { "name": "سيغما" } } };
const AlignYourStepsScheduler = { "display_name": "جدولة محاذاة خطواتك", "inputs": { "denoise": { "name": "إزالة الضجيج" }, "model_type": { "name": "نوع النموذج" }, "steps": { "name": "الخطوات" } }, "outputs": { "0": { "tooltip": null } } };
const AudioAdjustVolume = { "display_name": "ضبط مستوى الصوت", "inputs": { "audio": { "name": "الصوت" }, "volume": { "name": "مستوى الصوت", "tooltip": "ضبط مستوى الصوت بالديسيبل (dB). 0 = لا تغيير، +6 = مضاعفة، -6 = النصف، إلخ" } } };
const AudioConcat = { "description": "يربط الصوت1 بالصوت2 في الاتجاه المحدد.", "display_name": "دمج الصوت", "inputs": { "audio1": { "name": "الصوت1" }, "audio2": { "name": "الصوت2" }, "direction": { "name": "الاتجاه", "tooltip": "ما إذا كان سيتم إلحاق الصوت2 بعد أو قبل الصوت1." } } };
const AudioEncoderEncode = { "display_name": "تشفير مشفر الصوت", "inputs": { "audio": { "name": "الصوت" }, "audio_encoder": { "name": "مشفر الصوت" } }, "outputs": { "0": { "tooltip": null } } };
const AudioEncoderLoader = { "display_name": "محمل مشفر الصوت", "inputs": { "audio_encoder_name": { "name": "اسم مشفر الصوت" } }, "outputs": { "0": { "tooltip": null } } };
const AudioMerge = { "description": "دمج مسارين صوتيين عن طريق تراكب موجاتهما.", "display_name": "دمج الصوت", "inputs": { "audio1": { "name": "الصوت1" }, "audio2": { "name": "الصوت2" }, "merge_method": { "name": "طريقة الدمج", "tooltip": "الطريقة المستخدمة لدمج الموجات الصوتية." } } };
const BasicGuider = { "display_name": "الموجه الأساسي", "inputs": { "conditioning": { "name": "التهيئة" }, "model": { "name": "النموذج" } } };
const BasicScheduler = { "display_name": "الجدولة الأساسية", "inputs": { "denoise": { "name": "إزالة الضجيج" }, "model": { "name": "النموذج" }, "scheduler": { "name": "الجدولة" }, "steps": { "name": "الخطوات" } } };
const BetaSamplingScheduler = { "display_name": "جدولة أخذ عينات بيتا", "inputs": { "alpha": { "name": "ألفا" }, "beta": { "name": "بيتا" }, "model": { "name": "النموذج" }, "steps": { "name": "الخطوات" } } };
const ByteDanceFirstLastFrameNode = { "description": "إنشاء فيديو باستخدام المطالبة النصية والإطار الأول والأخير.", "display_name": "تحويل الإطار الأول-الأخير من ByteDance إلى فيديو", "inputs": { "aspect_ratio": { "name": "نسبة_الجانب", "tooltip": "نسبة الجانب للفيديو الناتج." }, "camera_fixed": { "name": "الكاميرا_ثابتة", "tooltip": "تحدد ما إذا كان سيتم تثبيت الكاميرا. التطبيق يضيف تعليمات لتثبيت الكاميرا إلى مطالبتك النصية، لكنه لا يضمن التأثير الفعلي." }, "control_after_generate": { "name": "التحكم بعد الإنشاء" }, "duration": { "name": "المدة", "tooltip": "مدة الفيديو الناتج بالثواني." }, "first_frame": { "name": "الإطار_الأول", "tooltip": "الإطار الأول الذي سيتم استخدامه للفيديو." }, "last_frame": { "name": "الإطار_الأخير", "tooltip": "الإطار الأخير الذي سيتم استخدامه للفيديو." }, "model": { "name": "النموذج" }, "prompt": { "name": "المطالبة النصية", "tooltip": "المطالبة النصية المستخدمة لإنشاء الفيديو." }, "resolution": { "name": "الدقة", "tooltip": "دقة الفيديو الناتج." }, "seed": { "name": "البذرة", "tooltip": "البذرة المستخدمة للإنشاء." }, "watermark": { "name": "علامة_مائية", "tooltip": 'ما إذا كان سيتم إضافة علامة مائية "تم إنشاؤه بالذكاء الاصطناعي" إلى الفيديو.' } }, "outputs": { "0": { "tooltip": null } } };
const ByteDanceImageEditNode = { "description": "تحرير الصور باستخدام نماذج ByteDance عبر واجهة برمجة التطبيقات بناءً على المطالبة النصية", "display_name": "تحرير الصور من ByteDance", "inputs": { "control_after_generate": { "name": "التحكم بعد التوليد" }, "guidance_scale": { "name": "مقياس التوجيه", "tooltip": "القيمة الأعلى تجعل الصورة تتبع النص الموجه بشكل أكبر" }, "image": { "name": "الصورة", "tooltip": "الصورة الأساسية للتحرير" }, "model": { "name": "النموذج" }, "prompt": { "name": "المطالبة النصية", "tooltip": "تعليمات لتحرير الصورة" }, "seed": { "name": "البذرة", "tooltip": "البذرة المستخدمة في التوليد" }, "watermark": { "name": "علامة مائية", "tooltip": 'ما إذا كان سيتم إضافة علامة مائية "تم إنشاؤها بالذكاء الاصطناعي" إلى الصورة' } }, "outputs": { "0": { "tooltip": null } } };
const ByteDanceImageNode = { "description": "إنشاء الصور باستخدام نماذج ByteDance عبر API استنادًا إلى النص الموجه", "display_name": "صورة ByteDance", "inputs": { "control_after_generate": { "name": "التحكم بعد التوليد" }, "guidance_scale": { "name": "مقياس التوجيه", "tooltip": "القيمة الأعلى تجعل الصورة تتبع النص الموجه بشكل أكبر" }, "height": { "name": "الارتفاع", "tooltip": "الارتفاع المخصص للصورة. القيمة تعمل فقط إذا تم ضبط `size_preset` على `Custom`" }, "model": { "name": "النموذج" }, "prompt": { "name": "النص الموجه", "tooltip": "النص الموجه المستخدم لإنشاء الصورة" }, "seed": { "name": "البذرة", "tooltip": "البذرة المستخدمة في التوليد" }, "size_preset": { "name": "ضبط الحجم", "tooltip": "اختر حجمًا موصى به. اختر مخصص لاستخدام العرض والارتفاع أدناه" }, "watermark": { "name": "علامة مائية", "tooltip": 'ما إذا كان سيتم إضافة علامة مائية "تم إنشاؤها بالذكاء الاصطناعي" إلى الصورة' }, "width": { "name": "العرض", "tooltip": "العرض المخصص للصورة. القيمة تعمل فقط إذا تم ضبط `size_preset` على `Custom`" } }, "outputs": { "0": { "tooltip": null } } };
const ByteDanceImageReferenceNode = { "description": "إنشاء فيديو باستخدام النص الموجه والصور المرجعية.", "display_name": "فيديو ByteDance من الصور المرجعية", "inputs": { "aspect_ratio": { "name": "aspect_ratio", "tooltip": "نسبة العرض إلى الارتفاع للفيديو الناتج." }, "control_after_generate": { "name": "control after generate" }, "duration": { "name": "duration", "tooltip": "مدة الفيديو الناتج بالثواني." }, "images": { "name": "images", "tooltip": "من صورة إلى أربع صور." }, "model": { "name": "النموذج" }, "prompt": { "name": "prompt", "tooltip": "المطالبة النصية المستخدمة لتوليد الفيديو." }, "resolution": { "name": "resolution", "tooltip": "دقة الفيديو الناتج." }, "seed": { "name": "seed", "tooltip": "البذرة المستخدمة في التوليد." }, "watermark": { "name": "watermark", "tooltip": 'ما إذا كان سيتم إضافة علامة مائية "تم إنشاؤه بالذكاء الاصطناعي" إلى الفيديو.' } }, "outputs": { "0": { "tooltip": null } } };
const ByteDanceImageToVideoNode = { "description": "توليد فيديو باستخدام نماذج ByteDance عبر واجهة برمجة التطبيقات بناءً على الصورة والمطالبة", "display_name": "ByteDance من صورة إلى فيديو", "inputs": { "aspect_ratio": { "name": "aspect_ratio", "tooltip": "نسبة العرض إلى الارتفاع للفيديو الناتج." }, "camera_fixed": { "name": "camera_fixed", "tooltip": "يحدد ما إذا كان سيتم تثبيت الكاميرا. يضيف التطبيق تعليمات لتثبيت الكاميرا إلى المطالبة الخاصة بك، لكنه لا يضمن التأثير الفعلي." }, "control_after_generate": { "name": "control after generate" }, "duration": { "name": "duration", "tooltip": "مدة الفيديو الناتج بالثواني." }, "image": { "name": "image", "tooltip": "الإطار الأول الذي سيتم استخدامه للفيديو." }, "model": { "name": "model" }, "prompt": { "name": "prompt", "tooltip": "المطالبة النصية المستخدمة لتوليد الفيديو." }, "resolution": { "name": "resolution", "tooltip": "دقة الفيديو الناتج." }, "seed": { "name": "seed", "tooltip": "البذرة المستخدمة في التوليد." }, "watermark": { "name": "watermark", "tooltip": 'ما إذا كان سيتم إضافة علامة مائية "تم إنشاؤها بالذكاء الاصطناعي" إلى الفيديو.' } }, "outputs": { "0": { "tooltip": null } } };
const ByteDanceSeedreamNode = { "description": "توليد موحد من النص إلى الصورة وتحرير دقيق للجملة الواحدة بدقة تصل إلى 4K.", "display_name": "ByteDance Seedream 4", "inputs": { "control_after_generate": { "name": "التحكم بعد التوليد" }, "fail_on_partial": { "name": "fail_on_partial", "tooltip": "إذا تم تمكينه، قم بإحباط التنفيذ إذا كانت أي من الصور المطلوبة مفقودة أو تُرجع خطأ." }, "height": { "name": "height", "tooltip": "الارتفاع المخصص للصورة. القيمة تعمل فقط إذا تم تعيين `size_preset` على `Custom`" }, "image": { "name": "image", "tooltip": "الصورة(الصور) المدخلة لتوليد الصورة من الصورة. قائمة من 1-10 صور للتوليد الفردي أو متعدد المرجعيات." }, "max_images": { "name": "max_images", "tooltip": "الحد الأقصى لعدد الصور التي سيتم توليدها عندما يكون sequential_image_generation='auto'. إجمالي الصور (المدخلة + المولدة) لا يمكن أن يتجاوز 15." }, "model": { "name": "model", "tooltip": "اسم النموذج" }, "prompt": { "name": "prompt", "tooltip": "مطالبة نصية لإنشاء أو تحرير صورة." }, "seed": { "name": "seed", "tooltip": "البذرة المستخدمة في التوليد." }, "sequential_image_generation": { "name": "sequential_image_generation", "tooltip": "وضع توليد الصور المتسلسل. 'disabled' يولد صورة واحدة. 'auto' يسمح للنموذج بتحديد ما إذا كان سيتم توليد صور متعددة ذات صلة (مثل مشاهد القصة، اختلافات الشخصية)." }, "size_preset": { "name": "size_preset", "tooltip": "اختر حجمًا موصى به. اختر Custom لاستخدام العرض والارتفاع أدناه." }, "watermark": { "name": "watermark", "tooltip": 'ما إذا كان سيتم إضافة علامة مائية "تم إنشاؤها بالذكاء الاصطناعي" إلى الصورة.' }, "width": { "name": "width", "tooltip": "العرض المخصص للصورة. القيمة تعمل فقط إذا تم تعيين `size_preset` على `Custom`" } }, "outputs": { "0": { "tooltip": null } } };
const ByteDanceTextToVideoNode = { "description": "توليد فيديو باستخدام نماذج ByteDance عبر API استنادًا إلى النص الموجه", "display_name": "ByteDance نص إلى فيديو", "inputs": { "aspect_ratio": { "name": "نسبة العرض إلى الارتفاع", "tooltip": "نسبة العرض إلى الارتفاع للفيديو الناتج." }, "camera_fixed": { "name": "الكاميرا ثابتة", "tooltip": "تحدد ما إذا كان سيتم تثبيت الكاميرا. تُلحق المنصة تعليمات لتثبيت الكاميرا بنصك الموجه، لكنها لا تضمن التأثير الفعلي." }, "control_after_generate": { "name": "التحكم بعد التوليد" }, "duration": { "name": "المدة", "tooltip": "مدة الفيديو الناتج بالثواني." }, "model": { "name": "النموذج" }, "prompt": { "name": "النص الموجه", "tooltip": "النص الموجه المستخدم لتوليد الفيديو." }, "resolution": { "name": "الدقة", "tooltip": "دقة الفيديو الناتج." }, "seed": { "name": "البذرة", "tooltip": "البذرة المستخدمة في التوليد." }, "watermark": { "name": "علامة مائية", "tooltip": 'ما إذا كان سيتم إضافة علامة مائية "تم توليدها بالذكاء الاصطناعي" إلى الفيديو.' } }, "outputs": { "0": { "tooltip": null } } };
const CFGGuider = { "display_name": "موجه CFG", "inputs": { "cfg": { "name": "CFG" }, "model": { "name": "النموذج" }, "negative": { "name": "سلبي" }, "positive": { "name": "إيجابي" } } };
const CFGNorm = { "display_name": "CFGNorm", "inputs": { "model": { "name": "النموذج" }, "strength": { "name": "القوة" } }, "outputs": { "0": { "name": "النموذج المعدل", "tooltip": null } } };
const CFGZeroStar = { "display_name": "CFGZeroStar", "inputs": { "model": { "name": "النموذج" } }, "outputs": { "0": { "name": "النموذج المعدل", "tooltip": null } } };
const CLIPAttentionMultiply = { "display_name": "ضرب انتباه CLIP", "inputs": { "clip": { "name": "CLIP" }, "k": { "name": "K" }, "out": { "name": "الإخراج" }, "q": { "name": "Q" }, "v": { "name": "V" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPLoader = { "description": "[الوصفات]\n\nstable_diffusion: clip-l\nstable_cascade: clip-g\nsd3: t5 xxl / clip-g / clip-l\nstable_audio: t5 base\nmochi: t5 xxl\ncosmos: old t5 xxl\nlumina2: gemma 2 2B\nwan: umt5 xxl\nhidream: llama-3.1 (موصى به) أو t5", "display_name": "تحميل CLIP", "inputs": { "clip_name": { "name": "اسم CLIP" }, "device": { "name": "الجهاز" }, "type": { "name": "النوع" } } };
const CLIPMergeAdd = { "display_name": "دمج CLIP - إضافة", "inputs": { "clip1": { "name": "CLIP 1" }, "clip2": { "name": "CLIP 2" } } };
const CLIPMergeSimple = { "display_name": "دمج CLIP - بسيط", "inputs": { "clip1": { "name": "CLIP 1" }, "clip2": { "name": "CLIP 2" }, "ratio": { "name": "النسبة" } } };
const CLIPMergeSubtract = { "display_name": "دمج CLIP - طرح", "inputs": { "clip1": { "name": "CLIP 1" }, "clip2": { "name": "CLIP 2" }, "multiplier": { "name": "المضاعف" } } };
const CLIPSave = { "display_name": "حفظ CLIP", "inputs": { "clip": { "name": "CLIP" }, "filename_prefix": { "name": "بادئة اسم الملف" } } };
const CLIPSetLastLayer = { "display_name": "تعيين الطبقة الأخيرة لـ CLIP", "inputs": { "clip": { "name": "CLIP" }, "stop_at_clip_layer": { "name": "التوقف عند طبقة CLIP" } } };
const CLIPTextEncode = { "description": "يقوم بترميز أمر نصي باستخدام نموذج CLIP إلى تمثيل مضمَّن يمكن استخدامه لتوجيه نموذج الانتشار نحو إنشاء صور محددة.", "display_name": "ترميز نص CLIP (أمر)", "inputs": { "clip": { "name": "CLIP", "tooltip": "نموذج CLIP المستخدم لترميز النص." }, "text": { "name": "النص", "tooltip": "النص المراد ترميزه." } }, "outputs": { "0": { "tooltip": "تهيئة تحتوي على النص المضمن المستخدم لتوجيه نموذج الانتشار." } } };
const CLIPTextEncodeControlnet = { "display_name": "ترميز نص CLIP لـ Controlnet", "inputs": { "clip": { "name": "CLIP" }, "conditioning": { "name": "التهيئة" }, "text": { "name": "النص" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeFlux = { "display_name": "ترميز نص CLIP لـ Flux", "inputs": { "clip": { "name": "CLIP" }, "clip_l": { "name": "CLIP-L" }, "guidance": { "name": "التوجيه" }, "t5xxl": { "name": "T5-XXL" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeHiDream = { "display_name": "ترميز نص CLIP لـ HiDream", "inputs": { "clip": { "name": "CLIP" }, "clip_g": { "name": "CLIP-G" }, "clip_l": { "name": "CLIP-L" }, "llama": { "name": "LLaMA" }, "t5xxl": { "name": "T5-XXL" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeHunyuanDiT = { "display_name": "ترميز نص CLIP لـ HunyuanDiT", "inputs": { "bert": { "name": "BERT" }, "clip": { "name": "CLIP" }, "mt5xl": { "name": "mT5-XL" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeLumina2 = { "description": "يقوم بترميز أمر النظام وأمر المستخدم باستخدام نموذج CLIP إلى تمثيل مضمَّن يمكن استخدامه لتوجيه نموذج الانتشار نحو إنشاء صور محددة.", "display_name": "ترميز نص CLIP لـ Lumina2", "inputs": { "clip": { "name": "CLIP", "tooltip": "نموذج CLIP المستخدم لترميز النص." }, "system_prompt": { "name": "أمر النظام", "tooltip": "يوفر Lumina2 نوعين من أوامر النظام: متفوق: أنت مساعد مصمم لإنشاء صور متفوقة بدرجة عالية من التوافق بين النص والصورة استنادًا إلى الأوامر النصية أو أوامر المستخدم. محاذاة: أنت مساعد مصمم لإنشاء صور عالية الجودة مع أعلى درجة من التوافق بين النص والصورة استنادًا إلى الأوامر النصية." }, "user_prompt": { "name": "أمر المستخدم", "tooltip": "النص المراد ترميزه." } }, "outputs": { "0": { "tooltip": "تهيئة تحتوي على النص المضمن المستخدم لتوجيه نموذج الانتشار." } } };
const CLIPTextEncodePixArtAlpha = { "description": "يقوم بترميز النص ويضبط تهيئة الدقة لـ PixArt Alpha. لا ينطبق على PixArt Sigma.", "display_name": "ترميز نص CLIP لـ PixArt Alpha", "inputs": { "clip": { "name": "CLIP" }, "height": { "name": "الارتفاع" }, "text": { "name": "النص" }, "width": { "name": "العرض" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeSD3 = { "display_name": "ترميز نص CLIP لـ SD3", "inputs": { "clip": { "name": "CLIP" }, "clip_g": { "name": "CLIP-G" }, "clip_l": { "name": "CLIP-L" }, "empty_padding": { "name": "حشو فارغ" }, "t5xxl": { "name": "T5-XXL" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeSDXL = { "display_name": "ترميز نص CLIP لـ SDXL", "inputs": { "clip": { "name": "CLIP" }, "crop_h": { "name": "قص الارتفاع" }, "crop_w": { "name": "قص العرض" }, "height": { "name": "الارتفاع" }, "target_height": { "name": "الارتفاع المستهدف" }, "target_width": { "name": "العرض المستهدف" }, "text_g": { "name": "النص G" }, "text_l": { "name": "النص L" }, "width": { "name": "العرض" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeSDXLRefiner = { "display_name": "مُحسّن ترميز نص CLIP لـ SDXL", "inputs": { "ascore": { "name": "الدرجة A" }, "clip": { "name": "CLIP" }, "height": { "name": "الارتفاع" }, "text": { "name": "النص" }, "width": { "name": "العرض" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPVisionEncode = { "display_name": "ترميز رؤية CLIP", "inputs": { "clip_vision": { "name": "رؤية CLIP" }, "crop": { "name": "القص" }, "image": { "name": "الصورة" } } };
const CLIPVisionLoader = { "display_name": "تحميل رؤية CLIP", "inputs": { "clip_name": { "name": "اسم CLIP" } } };
const Canny = { "display_name": "كاني", "inputs": { "high_threshold": { "name": "الحد الأعلى" }, "image": { "name": "الصورة" }, "low_threshold": { "name": "الحد الأدنى" } }, "outputs": { "0": { "tooltip": null } } };
const CaseConverter = { "display_name": "محول حالة الأحرف", "inputs": { "mode": { "name": "الوضع" }, "string": { "name": "سلسلة نصية" } }, "outputs": { "0": { "tooltip": null } } };
const CheckpointLoader = { "display_name": "تحميل نقطة التحقق مع الإعدادات (متوقف)", "inputs": { "ckpt_name": { "name": "اسم نقطة التحقق" }, "config_name": { "name": "اسم الإعداد" } } };
const CheckpointLoaderSimple = { "description": "يقوم بتحميل نقطة تحقق نموذج الانتشار، حيث تُستخدم نماذج الانتشار لإزالة الضجيج من البيانات الكامنة.", "display_name": "تحميل نقطة التحقق", "inputs": { "ckpt_name": { "name": "اسم نقطة التحقق", "tooltip": "اسم نقطة التحقق (النموذج) المراد تحميله." } }, "outputs": { "0": { "tooltip": "النموذج المستخدم لإزالة الضجيج من البيانات الكامنة." }, "1": { "tooltip": "نموذج CLIP المستخدم لترميز أوامر النص." }, "2": { "tooltip": "نموذج VAE المستخدم لترميز وفك ترميز الصور من وإلى الفضاء الكامن." } } };
const CheckpointSave = { "display_name": "حفظ نقطة التحقق", "inputs": { "clip": { "name": "CLIP" }, "filename_prefix": { "name": "بادئة اسم الملف" }, "model": { "name": "النموذج" }, "vae": { "name": "VAE" } } };
const ChromaRadianceOptions = { "description": "يسمح بتعيين خيارات متقدمة لنموذج Chroma Radiance.", "display_name": "خيارات ChromaRadiance", "inputs": { "end_sigma": { "name": "end_sigma", "tooltip": "آخر قيمة سيجما التي ستكون هذه الخيارات سارية المفعول عندها." }, "model": { "name": "النموذج" }, "nerf_tile_size": { "name": "nerf_tile_size", "tooltip": "يسمح بتجاوز حجم البلوك الافتراضي لـ NeRF. -1 تعني استخدام القيمة الافتراضية (32). 0 تعني استخدام وضع عدم التجزئة (قد يتطلب الكثير من VRAM)." }, "preserve_wrapper": { "name": "preserve_wrapper", "tooltip": "عند التمكين، سيتم تفويض الأمر إلى غلاف دالة النموذج الحالي إذا كان موجودًا. يجب عمومًا تركه مفعلًا." }, "start_sigma": { "name": "start_sigma", "tooltip": "أول قيمة سيجما التي ستكون هذه الخيارات سارية المفعول عندها." } }, "outputs": { "0": { "tooltip": null } } };
const CombineHooks2 = { "display_name": "دمج الخطافات [2]", "inputs": { "hooks_A": { "name": "الخُطاف A" }, "hooks_B": { "name": "الخُطاف B" } } };
const CombineHooks4 = { "display_name": "دمج الخطافات [4]", "inputs": { "hooks_A": { "name": "الخُطاف A" }, "hooks_B": { "name": "الخُطاف B" }, "hooks_C": { "name": "الخُطاف C" }, "hooks_D": { "name": "الخُطاف D" } } };
const CombineHooks8 = { "display_name": "دمج الخطافات [8]", "inputs": { "hooks_A": { "name": "الخُطاف A" }, "hooks_B": { "name": "الخُطاف B" }, "hooks_C": { "name": "الخُطاف C" }, "hooks_D": { "name": "الخُطاف D" }, "hooks_E": { "name": "الخُطاف E" }, "hooks_F": { "name": "الخُطاف F" }, "hooks_G": { "name": "الخُطاف G" }, "hooks_H": { "name": "الخُطاف H" } } };
const ConditioningAverage = { "display_name": "متوسط التهيئة", "inputs": { "conditioning_from": { "name": "تهيئة من" }, "conditioning_to": { "name": "تهيئة إلى" }, "conditioning_to_strength": { "name": "قوة التهيئة إلى" } } };
const ConditioningCombine = { "display_name": "التهيئة (دمج)", "inputs": { "conditioning_1": { "name": "تهيئة 1" }, "conditioning_2": { "name": "تهيئة 2" } } };
const ConditioningConcat = { "display_name": "التهيئة (ربط)", "inputs": { "conditioning_from": { "name": "تهيئة من" }, "conditioning_to": { "name": "تهيئة إلى" } } };
const ConditioningSetArea = { "display_name": "التهيئة (تعيين منطقة)", "inputs": { "conditioning": { "name": "التهيئة" }, "height": { "name": "الارتفاع" }, "strength": { "name": "القوة" }, "width": { "name": "العرض" }, "x": { "name": "س" }, "y": { "name": "ص" } } };
const ConditioningSetAreaPercentage = { "display_name": "التهيئة (تعيين منطقة بالنسبة المئوية)", "inputs": { "conditioning": { "name": "التهيئة" }, "height": { "name": "الارتفاع" }, "strength": { "name": "القوة" }, "width": { "name": "العرض" }, "x": { "name": "س" }, "y": { "name": "ص" } } };
const ConditioningSetAreaPercentageVideo = { "display_name": "تهيئة نسبة المساحة للفيديو", "inputs": { "conditioning": { "name": "التهيئة" }, "height": { "name": "الارتفاع" }, "strength": { "name": "القوة" }, "temporal": { "name": "زمني" }, "width": { "name": "العرض" }, "x": { "name": "س" }, "y": { "name": "ص" }, "z": { "name": "ع" } } };
const ConditioningSetAreaStrength = { "display_name": "تعيين قوة التهيئة", "inputs": { "conditioning": { "name": "التهيئة" }, "strength": { "name": "القوة" } } };
const ConditioningSetDefaultCombine = { "display_name": "تهيئة دمج افتراضية", "inputs": { "cond": { "name": "تهيئة" }, "cond_DEFAULT": { "name": "تهيئة افتراضية" }, "hooks": { "name": "الخطافات" } } };
const ConditioningSetMask = { "display_name": "التهيئة (تعيين قناع)", "inputs": { "conditioning": { "name": "التهيئة" }, "mask": { "name": "القناع" }, "set_cond_area": { "name": "تعيين منطقة التهيئة" }, "strength": { "name": "القوة" } } };
const ConditioningSetProperties = { "display_name": "تعيين خصائص التهيئة", "inputs": { "cond_NEW": { "name": "تهيئة جديدة" }, "hooks": { "name": "الخطافات" }, "mask": { "name": "القناع" }, "set_cond_area": { "name": "تعيين منطقة التهيئة" }, "strength": { "name": "القوة" }, "timesteps": { "name": "خطوات زمنية" } } };
const ConditioningSetPropertiesAndCombine = { "display_name": "تعيين خصائص التهيئة ودمج", "inputs": { "cond": { "name": "تهيئة" }, "cond_NEW": { "name": "تهيئة جديدة" }, "hooks": { "name": "الخطافات" }, "mask": { "name": "القناع" }, "set_cond_area": { "name": "تعيين منطقة التهيئة" }, "strength": { "name": "القوة" }, "timesteps": { "name": "خطوات زمنية" } } };
const ConditioningSetTimestepRange = { "display_name": "تعيين نطاق الخطوات الزمنية للتهيئة", "inputs": { "conditioning": { "name": "التهيئة" }, "end": { "name": "النهاية" }, "start": { "name": "البداية" } } };
const ConditioningStableAudio = { "display_name": "تهيئة الصوت المستقر", "inputs": { "negative": { "name": "سلبي" }, "positive": { "name": "إيجابي" }, "seconds_start": { "name": "ثواني البداية" }, "seconds_total": { "name": "إجمالي الثواني" } }, "outputs": { "0": { "name": "إيجابي" }, "1": { "name": "سلبي" } } };
const ConditioningTimestepsRange = { "display_name": "نطاق الخطوات الزمنية", "inputs": { "end_percent": { "name": "نسبة النهاية" }, "start_percent": { "name": "نسبة البداية" } }, "outputs": { "1": { "name": "قبل النطاق" }, "2": { "name": "بعد النطاق" } } };
const ConditioningZeroOut = { "display_name": "تصفير التهيئة", "inputs": { "conditioning": { "name": "تهيئة" } } };
const ContextWindowsManual = { "description": "تعيين نوافذ السياق يدويًا.", "display_name": "Context Windows (Manual)", "inputs": { "closed_loop": { "name": "closed_loop", "tooltip": "ما إذا كان سيتم إغلاق حلقة نافذة السياق؛ تنطبق فقط على الجداول الحلقية." }, "context_length": { "name": "context_length", "tooltip": "طول نافذة السياق." }, "context_overlap": { "name": "context_overlap", "tooltip": "تداخل نافذة السياق." }, "context_schedule": { "name": "context_schedule", "tooltip": "جدول نافذة السياق." }, "context_stride": { "name": "context_stride", "tooltip": "خطوة نافذة السياق؛ تنطبق فقط على الجداول المنتظمة." }, "dim": { "name": "dim", "tooltip": "البعد المراد تطبيق نوافذ السياق عليه." }, "fuse_method": { "name": "fuse_method", "tooltip": "الطريقة المستخدمة لدمج نوافذ السياق." }, "model": { "name": "model", "tooltip": "النموذج المراد تطبيق نوافذ السياق عليه أثناء أخذ العينات." } }, "outputs": { "0": { "tooltip": "النموذج مع تطبيق نوافذ السياق أثناء أخذ العينات." } } };
const ControlNetApply = { "display_name": "تطبيق ControlNet (قديم)", "inputs": { "conditioning": { "name": "تهيئة" }, "control_net": { "name": "شبكة التحكم" }, "image": { "name": "صورة" }, "strength": { "name": "القوة" } } };
const ControlNetApplyAdvanced = { "display_name": "تطبيق ControlNet", "inputs": { "control_net": { "name": "شبكة التحكم" }, "end_percent": { "name": "نسبة النهاية" }, "image": { "name": "صورة" }, "negative": { "name": "سلبي" }, "positive": { "name": "إيجابي" }, "start_percent": { "name": "نسبة البداية" }, "strength": { "name": "القوة" }, "vae": { "name": "VAE" } }, "outputs": { "0": { "name": "إيجابي" }, "1": { "name": "سلبي" } } };
const ControlNetApplySD3 = { "display_name": "تطبيق ControlNet مع VAE", "inputs": { "control_net": { "name": "شبكة التحكم" }, "end_percent": { "name": "نسبة النهاية" }, "image": { "name": "صورة" }, "negative": { "name": "سلبي" }, "positive": { "name": "إيجابي" }, "start_percent": { "name": "نسبة البداية" }, "strength": { "name": "القوة" }, "vae": { "name": "VAE" } }, "outputs": { "0": { "name": "إيجابي", "tooltip": null }, "1": { "name": "سلبي", "tooltip": null } } };
const ControlNetInpaintingAliMamaApply = { "display_name": "تطبيق ControlNet للترميم - علي ماما", "inputs": { "control_net": { "name": "شبكة التحكم" }, "end_percent": { "name": "نسبة النهاية" }, "image": { "name": "صورة" }, "mask": { "name": "قناع" }, "negative": { "name": "سلبي" }, "positive": { "name": "إيجابي" }, "start_percent": { "name": "نسبة البداية" }, "strength": { "name": "القوة" }, "vae": { "name": "VAE" } }, "outputs": { "0": { "name": "إيجابي", "tooltip": null }, "1": { "name": "سلبي", "tooltip": null } } };
const ControlNetLoader = { "display_name": "تحميل نموذج ControlNet", "inputs": { "control_net_name": { "name": "اسم شبكة التحكم" } } };
const CosmosImageToVideoLatent = { "display_name": "تحويل صورة كوزموس إلى فيديو كامِن", "inputs": { "batch_size": { "name": "حجم الدفعة" }, "end_image": { "name": "الصورة النهاية" }, "height": { "name": "الارتفاع" }, "length": { "name": "المدة" }, "start_image": { "name": "الصورة البداية" }, "vae": { "name": "VAE" }, "width": { "name": "العرض" } }, "outputs": { "0": { "tooltip": null } } };
const CosmosPredict2ImageToVideoLatent = { "display_name": "CosmosPredict2ImageToVideoLatent", "inputs": { "batch_size": { "name": "حجم الدُفعة" }, "end_image": { "name": "صورة النهاية" }, "height": { "name": "الارتفاع" }, "length": { "name": "الطول" }, "start_image": { "name": "صورة البداية" }, "vae": { "name": "vae" }, "width": { "name": "width" } }, "outputs": { "0": { "tooltip": null } } };
const CreateHookKeyframe = { "display_name": "إنشاء إطار مفتاحي للخطاف", "inputs": { "prev_hook_kf": { "name": "الإطار المفتاحي السابق" }, "start_percent": { "name": "نسبة البداية" }, "strength_mult": { "name": "معامل القوة" } }, "outputs": { "0": { "name": "إطار مفتاحي للخطاف" } } };
const CreateHookKeyframesFromFloats = { "display_name": "إنشاء إطارات مفتاحية من القيم العشرية", "inputs": { "end_percent": { "name": "نسبة النهاية" }, "floats_strength": { "name": "قوة القيم العشرية" }, "prev_hook_kf": { "name": "الإطار المفتاحي السابق" }, "print_keyframes": { "name": "طباعة الإطارات المفتاحية" }, "start_percent": { "name": "نسبة البداية" } }, "outputs": { "0": { "name": "إطار مفتاحي للخطاف" } } };
const CreateHookKeyframesInterpolated = { "display_name": "إنشاء إطارات مفتاحية بخطاف (مُInterpolated)", "inputs": { "end_percent": { "name": "نسبة النهاية" }, "interpolation": { "name": "الاستيفاء" }, "keyframes_count": { "name": "عدد الإطارات المفتاحية" }, "prev_hook_kf": { "name": "الإطار المفتاحي السابق" }, "print_keyframes": { "name": "طباعة الإطارات المفتاحية" }, "start_percent": { "name": "نسبة البداية" }, "strength_end": { "name": "قوة النهاية" }, "strength_start": { "name": "قوة البداية" } }, "outputs": { "0": { "name": "إطار مفتاحي للخطاف" } } };
const CreateHookLora = { "display_name": "إنشاء خطاف LoRA", "inputs": { "lora_name": { "name": "اسم LoRA" }, "prev_hooks": { "name": "الخطافات السابقة" }, "strength_clip": { "name": "قوة القص" }, "strength_model": { "name": "قوة النموذج" } } };
const CreateHookLoraModelOnly = { "display_name": "إنشاء خطاف LoRA (النموذج فقط)", "inputs": { "lora_name": { "name": "اسم LoRA" }, "prev_hooks": { "name": "الخطافات السابقة" }, "strength_model": { "name": "قوة النموذج" } } };
const CreateHookModelAsLora = { "display_name": "إنشاء خطاف كنموذج LoRA", "inputs": { "ckpt_name": { "name": "اسم نقطة الحفظ" }, "prev_hooks": { "name": "الخطافات السابقة" }, "strength_clip": { "name": "قوة القص" }, "strength_model": { "name": "قوة النموذج" } } };
const CreateHookModelAsLoraModelOnly = { "display_name": "إنشاء خطاف كنموذج LoRA (النموذج فقط)", "inputs": { "ckpt_name": { "name": "اسم نقطة الحفظ" }, "prev_hooks": { "name": "الخطافات السابقة" }, "strength_model": { "name": "قوة النموذج" } } };
const CreateVideo = { "description": "إنشاء فيديو من الصور.", "display_name": "إنشاء فيديو", "inputs": { "audio": { "name": "الصوت", "tooltip": "الصوت الذي سيتم إضافته للفيديو." }, "fps": { "name": "الإطارات في الثانية" }, "images": { "name": "الصور", "tooltip": "الصور التي سيتم إنشاء الفيديو منها." } }, "outputs": { "0": { "tooltip": null } } };
const CropMask = { "display_name": "قص القناع", "inputs": { "height": { "name": "الارتفاع" }, "mask": { "name": "قناع" }, "width": { "name": "العرض" }, "x": { "name": "س" }, "y": { "name": "ص" } } };
const DiffControlNetLoader = { "display_name": "تحميل نموذج ControlNet (فرق)", "inputs": { "control_net_name": { "name": "اسم شبكة التحكم" }, "model": { "name": "النموذج" } } };
const DifferentialDiffusion = { "display_name": "انتشار تفاضلي", "inputs": { "model": { "name": "النموذج" }, "strength": { "name": "القوة" } }, "outputs": { "0": { "tooltip": null } } };
const DiffusersLoader = { "display_name": "تحميل Diffusers", "inputs": { "model_path": { "name": "مسار النموذج" } } };
const DisableNoise = { "display_name": "تعطيل الضجيج" };
const DualCFGGuider = { "display_name": "موجّه CFG مزدوج", "inputs": { "cfg_cond2_negative": { "name": "شرط CFG 2 سلبي" }, "cfg_conds": { "name": "شروط CFG" }, "cond1": { "name": "الشرط 1" }, "cond2": { "name": "الشرط 2" }, "model": { "name": "النموذج" }, "negative": { "name": "سلبي" }, "style": { "name": "النمط" } } };
const DualCLIPLoader = { "description": "[الوصفات]\n\nsdxl: clip-l, clip-g\nsd3: clip-l, clip-g / clip-l, t5 / clip-g, t5\nflux: clip-l, t5\nhidream: على الأقل واحد من t5 أو llama، يفضل t5 و llama", "display_name": "محمل DualCLIP", "inputs": { "clip_name1": { "name": "اسم_clip1" }, "clip_name2": { "name": "اسم_clip2" }, "device": { "name": "الجهاز" }, "type": { "name": "النوع" } } };
const EasyCache = { "description": "تنفيذ أصلي لذاكرة التخزين المؤقت السهلة.", "display_name": "ذاكرة التخزين المؤقت السهلة", "inputs": { "end_percent": { "name": "نسبة النهاية", "tooltip": "خطوة أخذ العينات النسبية لإنهاء استخدام ذاكرة التخزين المؤقت السهلة." }, "model": { "name": "النموذج", "tooltip": "النموذج المراد إضافة ذاكرة التخزين المؤقت السهلة إليه." }, "reuse_threshold": { "name": "عتبة إعادة الاستخدام", "tooltip": "العتبة لإعادة استخدام الخطوات المخزنة مؤقتًا." }, "start_percent": { "name": "نسبة البداية", "tooltip": "خطوة أخذ العينات النسبية لبدء استخدام ذاكرة التخزين المؤقت السهلة." }, "verbose": { "name": "مفصل", "tooltip": "ما إذا كان سيتم تسجيل معلومات مفصلة." } }, "outputs": { "0": { "tooltip": "النموذج مع ذاكرة التخزين المؤقت السهلة." } } };
const EmptyAceStepLatentAudio = { "display_name": "خطوة الصوت الكامن الفارغ", "inputs": { "batch_size": { "name": "حجم الدُفعة", "tooltip": "عدد الصور الكامنة في الدُفعة." }, "seconds": { "name": "ثواني" } }, "outputs": { "0": { "tooltip": null } } };
const EmptyAudio = { "display_name": "صوت فارغ", "inputs": { "channels": { "name": "القنوات", "tooltip": "عدد قنوات الصوت (1 للأحادي، 2 للستيريو)." }, "duration": { "name": "المدة", "tooltip": "مدة مقطع الصوت الفارغ بالثواني" }, "sample_rate": { "name": "معدل العينات", "tooltip": "معدل العينات لمقطع الصوت الفارغ." } } };
const EmptyChromaRadianceLatentImage = { "display_name": "EmptyChromaRadianceLatentImage", "inputs": { "batch_size": { "name": "حجم_الدفعة" }, "height": { "name": "الارتفاع" }, "width": { "name": "العرض" } }, "outputs": { "0": { "tooltip": null } } };
const EmptyCosmosLatentVideo = { "display_name": "فيديو كوزموس كامن فارغ", "inputs": { "batch_size": { "name": "حجم_الدُفعة" }, "height": { "name": "الارتفاع" }, "length": { "name": "المدة" }, "width": { "name": "العرض" } }, "outputs": { "0": { "tooltip": null } } };
const EmptyHunyuanImageLatent = { "display_name": "EmptyHunyuanImageLatent", "inputs": { "batch_size": { "name": "حجم_الدفعة" }, "height": { "name": "الارتفاع" }, "width": { "name": "العرض" } }, "outputs": { "0": { "tooltip": null } } };
const EmptyHunyuanLatentVideo = { "display_name": "فيديو هونييوان كامن فارغ", "inputs": { "batch_size": { "name": "حجم_الدُفعة" }, "height": { "name": "الارتفاع" }, "length": { "name": "المدة" }, "width": { "name": "العرض" } }, "outputs": { "0": { "tooltip": null } } };
const EmptyImage = { "display_name": "صورة فارغة", "inputs": { "batch_size": { "name": "حجم_الدُفعة" }, "color": { "name": "اللون" }, "height": { "name": "الارتفاع" }, "width": { "name": "العرض" } } };
const EmptyLTXVLatentVideo = { "display_name": "فيديو LTXV كامن فارغ", "inputs": { "batch_size": { "name": "حجم_الدُفعة" }, "height": { "name": "الارتفاع" }, "length": { "name": "المدة" }, "width": { "name": "العرض" } }, "outputs": { "0": { "tooltip": null } } };
const EmptyLatentAudio = { "display_name": "صوت كامن فارغ", "inputs": { "batch_size": { "name": "حجم_الدُفعة", "tooltip": "عدد الصور الكامنة في الدُفعة." }, "seconds": { "name": "الثواني" } } };
const EmptyLatentHunyuan3Dv2 = { "display_name": "هونييوان 3D كامن فارغ نسخة 2", "inputs": { "batch_size": { "name": "حجم_الدُفعة", "tooltip": "عدد الصور الكامنة في الدُفعة." }, "resolution": { "name": "الدقة" } } };
const EmptyLatentImage = { "description": "إنشاء دفعة جديدة من الصور الكامنة الفارغة ليتم تنظيفها عبر التوليد.", "display_name": "صورة كامنة فارغة", "inputs": { "batch_size": { "name": "حجم_الدُفعة", "tooltip": "عدد الصور الكامنة في الدُفعة." }, "height": { "name": "الارتفاع", "tooltip": "ارتفاع الصور الكامنة بالبكسل." }, "width": { "name": "العرض", "tooltip": "عرض الصور الكامنة بالبكسل." } }, "outputs": { "0": { "tooltip": "دفعة الصور الكامنة الفارغة." } } };
const EmptyMochiLatentVideo = { "display_name": "فيديو موتشي كامن فارغ", "inputs": { "batch_size": { "name": "حجم_الدُفعة" }, "height": { "name": "الارتفاع" }, "length": { "name": "المدة" }, "width": { "name": "العرض" } }, "outputs": { "0": { "tooltip": null } } };
const EmptySD3LatentImage = { "display_name": "صورة SD3 كامنة فارغة", "inputs": { "batch_size": { "name": "حجم_الدُفعة" }, "height": { "name": "الارتفاع" }, "width": { "name": "العرض" } }, "outputs": { "0": { "tooltip": null } } };
const ExponentialScheduler = { "display_name": "مجدول أُسّي", "inputs": { "sigma_max": { "name": "سيغما_القصوى" }, "sigma_min": { "name": "سيغما_الدنيا" }, "steps": { "name": "الخطوات" } } };
const ExtendIntermediateSigmas = { "display_name": "تمديد قيم سيغما المتوسطة", "inputs": { "end_at_sigma": { "name": "النهاية_عند_السيغما" }, "sigmas": { "name": "قيم_السيغما" }, "spacing": { "name": "المسافة" }, "start_at_sigma": { "name": "البداية_عند_السيغما" }, "steps": { "name": "الخطوات" } } };
const FeatherMask = { "display_name": "قناع التمويه", "inputs": { "bottom": { "name": "الأسفل" }, "left": { "name": "اليسار" }, "mask": { "name": "القناع" }, "right": { "name": "اليمين" }, "top": { "name": "الأعلى" } } };
const FlipSigmas = { "display_name": "عكس قيم السيغما", "inputs": { "sigmas": { "name": "قيم_السيغما" } } };
const FluxDisableGuidance = { "description": "تعطيل كامل لتضمين الإرشاد على موديلات فلوكس ومشابهة.", "display_name": "تعطيل إرشاد فلوكس", "inputs": { "conditioning": { "name": "التهيئة" } }, "outputs": { "0": { "tooltip": null } } };
const FluxGuidance = { "display_name": "إرشاد فلوكس", "inputs": { "conditioning": { "name": "التهيئة" }, "guidance": { "name": "الإرشاد" } }, "outputs": { "0": { "tooltip": null } } };
const FluxKontextImageScale = { "description": "تعيد هذه العقدة ضبط حجم الصورة إلى حجم أكثر ملاءمة لـ flux kontext.", "display_name": "FluxKontextImageScale", "inputs": { "image": { "name": "الصورة" } }, "outputs": { "0": { "tooltip": null } } };
const FluxKontextMaxImageNode = { "description": "يحرر الصور باستخدام Flux.1 Kontext [max] عبر واجهة برمجة التطبيقات بناءً على المطالبة ونسبة العرض إلى الارتفاع.", "display_name": "Flux.1 Kontext [max] Image", "inputs": { "aspect_ratio": { "name": "نسبة_العرض_إلى_الارتفاع", "tooltip": "نسبة العرض إلى الارتفاع للصورة؛ يجب أن تكون بين 1:4 و 4:1." }, "control_after_generate": { "name": "التحكم بعد التوليد" }, "guidance": { "name": "الإرشاد", "tooltip": "قوة الإرشاد لعملية توليد الصورة" }, "input_image": { "name": "الصورة_المدخلة" }, "prompt": { "name": "المطالبة", "tooltip": "المطالبة لتوليد الصورة - حدد ماذا وكيف تريد التحرير." }, "prompt_upsampling": { "name": "رفع_دقة_المطالبة", "tooltip": "ما إذا كان سيتم إجراء رفع الدقة على المطالبة. إذا كانت نشطة، تقوم تلقائيًا بتعديل المطالبة لتوليد أكثر إبداعًا، ولكن النتائج غير حتمية (نفس البذرة لن تنتج نفس النتيجة بالضبط)." }, "seed": { "name": "البذرة", "tooltip": "البذرة العشوائية المستخدمة لإنشاء الضوضاء." }, "steps": { "name": "الخطوات", "tooltip": "عدد الخطوات لعملية توليد الصورة" } }, "outputs": { "0": { "tooltip": null } } };
const FluxKontextMultiReferenceLatentMethod = { "display_name": "طريقة FluxKontextMultiReferenceLatent", "inputs": { "conditioning": { "name": "التكييف" }, "reference_latents_method": { "name": "طريقة المرجع الكامن" } }, "outputs": { "0": { "tooltip": null } } };
const FluxKontextProImageNode = { "description": "يحرر الصور باستخدام Flux.1 Kontext [pro] عبر واجهة برمجة التطبيقات بناءً على النص الموجه ونسبة الأبعاد.", "display_name": "Flux.1 Kontext [pro] صورة", "inputs": { "aspect_ratio": { "name": "نسبة الأبعاد", "tooltip": "نسبة أبعاد الصورة؛ يجب أن تكون بين 1:4 و 4:1." }, "control_after_generate": { "name": "التحكم بعد التوليد" }, "guidance": { "name": "التوجيه", "tooltip": "قوة التوجيه لعملية توليد الصورة" }, "input_image": { "name": "صورة الإدخال" }, "prompt": { "name": "النص الموجه", "tooltip": "النص الموجه لتوليد الصورة - حدد ما يجب تحريره وكيفية تحريره." }, "prompt_upsampling": { "name": "رفع دقة النص الموجه", "tooltip": "ما إذا كان سيتم إجراء رفع الدقة على النص الموجه. إذا كان نشطًا، يقوم تلقائيًا بتعديل النص الموجه لتوليد أكثر إبداعًا، ولكن النتائج غير حتمية (نفس البذرة لن تنتج نفس النتيجة بالضبط)." }, "seed": { "name": "البذرة", "tooltip": "البذرة العشوائية المستخدمة لإنشاء الضوضاء." }, "steps": { "name": "الخطوات", "tooltip": "عدد الخطوات لعملية توليد الصورة" } }, "outputs": { "0": { "tooltip": null } } };
const FluxProExpandNode = { "description": "توسيع الصورة بناءً على الوصف.", "display_name": "Flux.1 توسيع الصورة", "inputs": { "bottom": { "name": "الأسفل", "tooltip": "عدد البكسلات لتوسيع الصورة من الأسفل" }, "control_after_generate": { "name": "التحكم بعد التوليد" }, "guidance": { "name": "الإرشاد", "tooltip": "قوة الإرشاد لعملية توليد الصورة" }, "image": { "name": "الصورة" }, "left": { "name": "اليسار", "tooltip": "عدد البكسلات لتوسيع الصورة من اليسار" }, "prompt": { "name": "الوصف", "tooltip": "الوصف المطلوب لتوليد الصورة" }, "prompt_upsampling": { "name": "تحسين_الوصف", "tooltip": "ما إذا كان يجب تحسين الوصف. إذا تم تفعيله، يتم تعديل الوصف تلقائيًا للحصول على توليد إبداعي أكثر، لكن النتائج غير حتمية (نفس البذرة لن تنتج نفس النتيجة بالضبط)." }, "right": { "name": "اليمين", "tooltip": "عدد البكسلات لتوسيع الصورة من اليمين" }, "seed": { "name": "البذرة", "tooltip": "البذرة العشوائية المستخدمة لإنشاء الضجيج." }, "steps": { "name": "الخطوات", "tooltip": "عدد الخطوات في عملية توليد الصورة" }, "top": { "name": "الأعلى", "tooltip": "عدد البكسلات لتوسيع الصورة من الأعلى" } }, "outputs": { "0": { "tooltip": null } } };
const FluxProFillNode = { "description": "ملء الصورة بناءً على القناع والوصف.", "display_name": "Flux.1 ملء الصورة", "inputs": { "control_after_generate": { "name": "التحكم بعد التوليد" }, "guidance": { "name": "الإرشاد", "tooltip": "قوة الإرشاد لعملية توليد الصورة" }, "image": { "name": "الصورة" }, "mask": { "name": "القناع" }, "prompt": { "name": "الوصف", "tooltip": "الوصف المطلوب لتوليد الصورة" }, "prompt_upsampling": { "name": "تحسين_الوصف", "tooltip": "ما إذا كان يجب تحسين الوصف. إذا تم تفعيله، يتم تعديل الوصف تلقائيًا للحصول على توليد إبداعي أكثر، لكن النتائج غير حتمية (نفس البذرة لن تنتج نفس النتيجة بالضبط)." }, "seed": { "name": "البذرة", "tooltip": "البذرة العشوائية المستخدمة لإنشاء الضجيج." }, "steps": { "name": "الخطوات", "tooltip": "عدد الخطوات في عملية توليد الصورة" } }, "outputs": { "0": { "tooltip": null } } };
const FluxProUltraImageNode = { "description": "ينشئ صورًا باستخدام Flux Pro 1.1 Ultra عبر API بناءً على الوصف والدقة.", "display_name": "Flux 1.1 [pro] صورة فائقة", "inputs": { "aspect_ratio": { "name": "نسبة_الأبعاد", "tooltip": "نسبة أبعاد الصورة؛ يجب أن تكون بين 1:4 و4:1." }, "control_after_generate": { "name": "التحكم بعد التوليد" }, "image_prompt": { "name": "وصف_صورة" }, "image_prompt_strength": { "name": "قوة_وصف_الصورة", "tooltip": "نسبة الدمج بين الوصف النصي ووصف الصورة." }, "prompt": { "name": "الوصف", "tooltip": "الوصف لتوليد الصورة" }, "prompt_upsampling": { "name": "تحسين_الوصف", "tooltip": "هل يجب إجراء تحسين على الوصف؟ إذا كان مفعلاً، يتم تعديل الوصف تلقائيًا للحصول على توليد أكثر إبداعًا، لكن النتائج غير حتمية (نفس البذرة لن تعطي نفس النتيجة تمامًا)." }, "raw": { "name": "خام", "tooltip": "عند التفعيل، يتم توليد صور أقل معالجة وأكثر طبيعية المظهر." }, "seed": { "name": "البذرة", "tooltip": "البذرة العشوائية المستخدمة لإنشاء الضجيج." } }, "outputs": { "0": { "tooltip": null } } };
const FreSca = { "description": "يطبق تحجيمًا معتمدًا على الترددات على الإرشاد", "display_name": "FreSca", "inputs": { "freq_cutoff": { "name": "قطع_التردد", "tooltip": "عدد مؤشرات التردد حول المركز التي تعتبر ترددات منخفضة" }, "model": { "name": "النموذج" }, "scale_high": { "name": "تحجيم_التردد_العالي", "tooltip": "عامل التحجيم لمكونات التردد العالي" }, "scale_low": { "name": "تحجيم_التردد_المنخفض", "tooltip": "عامل التحجيم لمكونات التردد المنخفض" } }, "outputs": { "0": { "tooltip": null } } };
const FreeU = { "display_name": "FreeU", "inputs": { "b1": { "name": "b1" }, "b2": { "name": "b2" }, "model": { "name": "النموذج" }, "s1": { "name": "s1" }, "s2": { "name": "s2" } } };
const FreeU_V2 = { "display_name": "FreeU_V2", "inputs": { "b1": { "name": "b1" }, "b2": { "name": "b2" }, "model": { "name": "النموذج" }, "s1": { "name": "s1" }, "s2": { "name": "s2" } } };
const GITSScheduler = { "display_name": "GITSScheduler", "inputs": { "coeff": { "name": "المعامل" }, "denoise": { "name": "إزالة_الضجيج" }, "steps": { "name": "الخطوات" } }, "outputs": { "0": { "tooltip": null } } };
const GLIGENLoader = { "display_name": "GLIGENLoader", "inputs": { "gligen_name": { "name": "اسم_gligen" } } };
const GLIGENTextBoxApply = { "display_name": "تطبيق صندوق نص GLIGEN", "inputs": { "clip": { "name": "clip" }, "conditioning_to": { "name": "التكييف_إلى" }, "gligen_textbox_model": { "name": "نموذج_صندوق_النص_GLIGEN" }, "height": { "name": "الارتفاع" }, "text": { "name": "النص" }, "width": { "name": "العرض" }, "x": { "name": "س_محور" }, "y": { "name": "ص_محور" } } };
const GeminiImageNode = { "description": "تحرير الصور بشكل متزامن عبر واجهة برمجة تطبيقات Google.", "display_name": "صورة Google Gemini", "inputs": { "aspect_ratio": { "name": "نسبة_الجانب", "tooltip": "افتراضيًا، يطابق حجم الصورة الناتجة حجم صورتك المدخلة، أو يُنشئ مربعات بنسبة 1:1 بخلاف ذلك." }, "control_after_generate": { "name": "التحكم بعد الإنشاء" }, "files": { "name": "ملفات", "tooltip": "ملف (ملفات) اختياري(ة) لاستخدامها كسياق للنموذج. يقبل مدخلات من عقدة ملفات إدخال إنشاء محتوى Gemini." }, "images": { "name": "الصور", "tooltip": "صورة (صور) اختيارية لاستخدامها كسياق للنموذج. لتضمين صور متعددة، يمكنك استخدام عقدة الصور المجمعة." }, "model": { "name": "النموذج", "tooltip": "نموذج Gemini المستخدم لتوليد الاستجابات." }, "prompt": { "name": "النص الموجه", "tooltip": "النص الموجه للتوليد" }, "seed": { "name": "البذرة", "tooltip": "عند تثبيت البذرة على قيمة محددة، يبذل النموذج قصارى جهده لتقديم نفس الاستجابة للطلبات المتكررة. لا يتم ضمان الإخراج الحتمي. أيضًا، تغيير النموذج أو إعدادات المعاملات، مثل درجة الحرارة، يمكن أن يسبب اختلافات في الاستجابة حتى عند استخدام نفس قيمة البذرة. افتراضيًا، يتم استخدام قيمة بذرة عشوائية." } }, "outputs": { "0": { "tooltip": null }, "1": { "tooltip": null } } };
const GeminiInputFiles = { "description": "يقوم بتحميل وإعداد ملفات الإدخال لتضمينها كمدخلات لعقد Gemini LLM. ستقرأ النماذج Gemini الملفات عند إنشاء استجابة. محتويات ملف النص تُحتسب ضمن حد الرموز. 🛈 نصيحة: يمكن ربطها مع عقد ملفات إدخال Gemini الأخرى.", "display_name": "ملفات إدخال Gemini", "inputs": { "GEMINI_INPUT_FILES": { "name": "ملفات_إدخال_GEMINI", "tooltip": "ملف (ملفات) إضافي(ة) اختياري(ة) لدمجها مع الملف المحمل من هذه العقدة. يسمح بربط ملفات الإدخال بحيث يمكن لرسالة واحدة أن تتضمن ملفات إدخال متعددة." }, "file": { "name": "ملف", "tooltip": "ملفات الإدخال لتضمينها كسياق للنموذج. تقبل حاليًا ملفات النص (.txt) وملفات PDF (.pdf) فقط." } }, "outputs": { "0": { "tooltip": null } } };
const GeminiNode = { "description": "إنشاء استجابات نصية باستخدام نموذج الذكاء الاصطناعي Gemini من Google. يمكنك تقديم أنواع متعددة من المدخلات (نص، صور، صوت، فيديو) كسياق لإنشاء استجابات أكثر صلة ومعنى.", "display_name": "Google Gemini", "inputs": { "audio": { "name": "صوت", "tooltip": "صوت اختياري لاستخدامه كسياق للنموذج." }, "control_after_generate": { "name": "التحكم بعد الإنشاء" }, "files": { "name": "ملفات", "tooltip": "ملف (ملفات) اختياري(ة) لاستخدامها كسياق للنموذج. يقبل مدخلات من عقدة ملفات إدخال إنشاء محتوى Gemini." }, "images": { "name": "صور", "tooltip": "صورة (صور) اختيارية لاستخدامها كسياق للنموذج. لتضمين صور متعددة، يمكنك استخدام عقدة الصور المجمعة." }, "model": { "name": "نموذج", "tooltip": "نموذج Gemini لاستخدامه في إنشاء الاستجابات." }, "prompt": { "name": "مطالبة", "tooltip": "مدخلات نصية للنموذج، تُستخدم لإنشاء استجابة. يمكنك تضمين تعليمات مفصلة، أسئلة، أو سياق للنموذج." }, "seed": { "name": "بذرة", "tooltip": "عند تثبيت البذرة على قيمة محددة، يبذل النموذج قصارى جهده لتقديم نفس الاستجابة للطلبات المتكررة. لا يتم ضمان الإخراج الحتمي. أيضًا، تغيير النموذج أو إعدادات المعاملات، مثل درجة الحرارة، يمكن أن يسبب اختلافات في الاستجابة حتى عند استخدام نفس قيمة البذرة. افتراضيًا، تُستخدم قيمة بذرة عشوائية." }, "video": { "name": "فيديو", "tooltip": "فيديو اختياري لاستخدامه كسياق للنموذج." } }, "outputs": { "0": { "tooltip": null } } };
const GetImageSize = { "description": "يعرض عرض وارتفاع الصورة، ويمررها دون تغيير.", "display_name": "الحصول على حجم الصورة", "inputs": { "image": { "name": "صورة" } }, "outputs": { "0": { "name": "العرض" }, "1": { "name": "الارتفاع" }, "2": { "name": "حجم الدُفعة" } } };
const GetVideoComponents = { "description": "يستخرج جميع المكونات من الفيديو: الإطارات، الصوت، ومعدل الإطارات.", "display_name": "استخراج مكونات الفيديو", "inputs": { "video": { "name": "الفيديو", "tooltip": "الفيديو الذي سيتم استخراج المكونات منه." } }, "outputs": { "0": { "name": "الصور", "tooltip": null }, "1": { "name": "الصوت", "tooltip": null }, "2": { "name": "معدل_الإطارات", "tooltip": null } } };
const GrowMask = { "display_name": "توسيع القناع", "inputs": { "expand": { "name": "التوسيع" }, "mask": { "name": "القناع" }, "tapered_corners": { "name": "زوايا_منحدرة" } } };
const Hunyuan3Dv2Conditioning = { "display_name": "Hunyuan3Dv2التكييف", "inputs": { "clip_vision_output": { "name": "مخرج_clip_الرؤية" } }, "outputs": { "0": { "name": "إيجابي" }, "1": { "name": "سلبي" } } };
const Hunyuan3Dv2ConditioningMultiView = { "display_name": "Hunyuan3Dv2التكييف متعدد الرؤى", "inputs": { "back": { "name": "الخلفي" }, "front": { "name": "الأمامي" }, "left": { "name": "الأيسر" }, "right": { "name": "الأيمن" } }, "outputs": { "0": { "name": "إيجابي" }, "1": { "name": "سلبي" } } };
const HunyuanImageToVideo = { "display_name": "Hunyuan صورة إلى فيديو", "inputs": { "batch_size": { "name": "حجم_الدفعة" }, "guidance_type": { "name": "نوع_الإرشاد" }, "height": { "name": "الارتفاع" }, "length": { "name": "الطول" }, "positive": { "name": "إيجابي" }, "start_image": { "name": "صورة_البداية" }, "vae": { "name": "vae" }, "width": { "name": "العرض" } }, "outputs": { "0": { "name": "إيجابي", "tooltip": null }, "1": { "name": "كامِن", "tooltip": null } } };
const HunyuanRefinerLatent = { "display_name": "HunyuanRefinerLatent", "inputs": { "latent": { "name": "كامن" }, "negative": { "name": "سلبي" }, "noise_augmentation": { "name": "زيادة الضوضاء" }, "positive": { "name": "إيجابي" } }, "outputs": { "0": { "name": "إيجابي", "tooltip": null }, "1": { "name": "سلبي", "tooltip": null }, "2": { "name": "كامن", "tooltip": null } } };
const HyperTile = { "display_name": "HyperTile", "inputs": { "max_depth": { "name": "أقصى_عمق" }, "model": { "name": "النموذج" }, "scale_depth": { "name": "تحجيم_العمق" }, "swap_size": { "name": "حجم_التبديل" }, "tile_size": { "name": "حجم_القرميدة" } }, "outputs": { "0": { "tooltip": null } } };
const HypernetworkLoader = { "display_name": "محمل الشبكات الفائقة", "inputs": { "hypernetwork_name": { "name": "اسم_الشبكة_الفائقة" }, "model": { "name": "النموذج" }, "strength": { "name": "القوة" } }, "outputs": { "0": { "tooltip": null } } };
const IdeogramV1 = { "description": "ينشئ صورًا تزامنيًا باستخدام نموذج Ideogram V1.\n\nروابط الصور متاحة لفترة محدودة؛ إذا أردت الاحتفاظ بالصورة، يجب تنزيلها.", "display_name": "Ideogram V1", "inputs": { "aspect_ratio": { "name": "نسبة_الأبعاد", "tooltip": "نسبة الأبعاد لتوليد الصورة." }, "control_after_generate": { "name": "التحكم بعد التوليد" }, "magic_prompt_option": { "name": "خيار_الوصف_السحري", "tooltip": "تحديد ما إذا كان يجب استخدام MagicPrompt في التوليد" }, "negative_prompt": { "name": "الوصف_السلبي", "tooltip": "وصف ما يجب استبعاده من الصورة" }, "num_images": { "name": "عدد_الصور" }, "prompt": { "name": "الوصف", "tooltip": "الوصف لتوليد الصورة" }, "seed": { "name": "البذرة" }, "turbo": { "name": "الوضع_السريع", "tooltip": "هل تستخدم وضع التيربو (توليد أسرع، جودة أقل محتملة)" } }, "outputs": { "0": { "tooltip": null } } };
const IdeogramV2 = { "description": "ينشئ الصور بشكل متزامن باستخدام نموذج إيديوغرام الإصدار 2.\n\nروابط الصور متاحة لفترة محدودة من الوقت؛ إذا كنت ترغب في الاحتفاظ بالصورة، يجب عليك تنزيلها.", "display_name": "إيديوغرام الإصدار 2", "inputs": { "aspect_ratio": { "name": "نسبة العرض إلى الارتفاع", "tooltip": "نسبة العرض إلى الارتفاع لتوليد الصورة. يتم تجاهلها إذا لم يتم تعيين الدقة إلى تلقائي." }, "control_after_generate": { "name": "التحكم بعد التوليد" }, "magic_prompt_option": { "name": "خيار الموجه السحري", "tooltip": "تحديد ما إذا كان يجب استخدام الموجه السحري في التوليد" }, "negative_prompt": { "name": "الموجه السلبي", "tooltip": "وصف ما يجب استبعاده من الصورة" }, "num_images": { "name": "عدد الصور" }, "prompt": { "name": "الموجه", "tooltip": "الموجه لتوليد الصورة" }, "resolution": { "name": "الدقة", "tooltip": "دقة توليد الصورة. إذا لم يتم تعيينها إلى تلقائي، فإنها تتجاوز إعداد نسبة العرض إلى الارتفاع." }, "seed": { "name": "البذرة" }, "style_type": { "name": "نوع الأسلوب", "tooltip": "نوع الأسلوب للتوليد (الإصدار 2 فقط)" }, "turbo": { "name": "تيربو", "tooltip": "هل يتم استخدام وضع التيربو (توليد أسرع، وجودة قد تكون أقل)" } }, "outputs": { "0": { "tooltip": null } } };
const IdeogramV3 = { "description": "ينشئ الصور بشكل متزامن باستخدام نموذج إيديوغرام الإصدار 3.\n\nيدعم التوليد العادي للصور من النصوص وتحرير الصور مع القناع.\nروابط الصور متاحة لفترة محدودة من الوقت؛ إذا كنت ترغب في الاحتفاظ بالصورة، يجب عليك تنزيلها.", "display_name": "إيديوغرام الإصدار 3", "inputs": { "aspect_ratio": { "name": "نسبة العرض إلى الارتفاع", "tooltip": "نسبة العرض إلى الارتفاع لتوليد الصورة. يتم تجاهلها إذا لم يتم تعيين الدقة إلى تلقائي." }, "character_image": { "name": "صورة الشخصية", "tooltip": "الصورة المستخدمة كمرجع للشخصية." }, "character_mask": { "name": "قناع الشخصية", "tooltip": "قناع اختياري لصورة مرجع الشخصية." }, "control_after_generate": { "name": "التحكم بعد التوليد" }, "image": { "name": "الصورة", "tooltip": "صورة مرجعية اختيارية لتحرير الصورة." }, "magic_prompt_option": { "name": "خيار الموجه السحري", "tooltip": "تحديد ما إذا كان يجب استخدام الموجه السحري في التوليد" }, "mask": { "name": "القناع", "tooltip": "قناع اختياري للرسم داخل المناطق (سيتم استبدال المناطق البيضاء)" }, "num_images": { "name": "عدد الصور" }, "prompt": { "name": "الموجه", "tooltip": "الموجه لتوليد الصورة أو تحريرها" }, "rendering_speed": { "name": "سرعة العرض", "tooltip": "التحكم في التوازن بين سرعة التوليد والجودة" }, "resolution": { "name": "الدقة", "tooltip": "دقة توليد الصورة. إذا لم يتم تعيينها إلى تلقائي، فإنها تتجاوز إعداد نسبة العرض إلى الارتفاع." }, "seed": { "name": "البذرة" } }, "outputs": { "0": { "tooltip": null } } };
const ImageAddNoise = { "display_name": "ImageAddNoise", "inputs": { "control_after_generate": { "name": "التحكم بعد الإنشاء" }, "image": { "name": "صورة" }, "seed": { "name": "البذرة", "tooltip": "البذرة العشوائية المستخدمة لإنشاء الضوضاء." }, "strength": { "name": "القوة" } } };
const ImageBatch = { "display_name": "دفعة الصور", "inputs": { "image1": { "name": "الصورة 1" }, "image2": { "name": "الصورة 2" } } };
const ImageBlend = { "display_name": "مزج الصور", "inputs": { "blend_factor": { "name": "عامل المزج" }, "blend_mode": { "name": "طريقة المزج" }, "image1": { "name": "الصورة 1" }, "image2": { "name": "الصورة 2" } }, "outputs": { "0": { "tooltip": null } } };
const ImageBlur = { "display_name": "تمويه الصورة", "inputs": { "blur_radius": { "name": "نصف قطر التمويه" }, "image": { "name": "الصورة" }, "sigma": { "name": "سيغما" } }, "outputs": { "0": { "tooltip": null } } };
const ImageColorToMask = { "display_name": "لون الصورة إلى قناع", "inputs": { "color": { "name": "اللون" }, "image": { "name": "الصورة" } } };
const ImageCompositeMasked = { "display_name": "تركيب صورة مع قناع", "inputs": { "destination": { "name": "الوجهة" }, "mask": { "name": "القناع" }, "resize_source": { "name": "تغيير حجم المصدر" }, "source": { "name": "المصدر" }, "x": { "name": "إحداثي X" }, "y": { "name": "إحداثي Y" } } };
const ImageCrop = { "display_name": "اقتصاص الصورة", "inputs": { "height": { "name": "الارتفاع" }, "image": { "name": "الصورة" }, "width": { "name": "العرض" }, "x": { "name": "إحداثي X" }, "y": { "name": "إحداثي Y" } } };
const ImageFlip = { "display_name": "ImageFlip", "inputs": { "flip_method": { "name": "طريقة الالتفاف" }, "image": { "name": "صورة" } } };
const ImageFromBatch = { "display_name": "صورة من دفعة", "inputs": { "batch_index": { "name": "فهرس الدفعة" }, "image": { "name": "الصورة" }, "length": { "name": "الطول" } } };
const ImageInvert = { "display_name": "عكس الصورة", "inputs": { "image": { "name": "الصورة" } } };
const ImageOnlyCheckpointLoader = { "display_name": "محمل نقطة تحقق الصور فقط (نموذج img2vid)", "inputs": { "ckpt_name": { "name": "اسم نقطة التحقق" } } };
const ImageOnlyCheckpointSave = { "display_name": "حفظ نقطة تحقق الصور فقط", "inputs": { "clip_vision": { "name": "رؤية Clip" }, "filename_prefix": { "name": "بادئة اسم الملف" }, "model": { "name": "النموذج" }, "vae": { "name": "VAE" } } };
const ImagePadForOutpaint = { "display_name": "توسيع الصورة للرسم الخارجي", "inputs": { "bottom": { "name": "الأسفل" }, "feathering": { "name": "التدرج" }, "image": { "name": "الصورة" }, "left": { "name": "اليسار" }, "right": { "name": "اليمين" }, "top": { "name": "الأعلى" } } };
const ImageQuantize = { "display_name": "تكميم الصورة", "inputs": { "colors": { "name": "الألوان" }, "dither": { "name": "التنقيط" }, "image": { "name": "الصورة" } }, "outputs": { "0": { "tooltip": null } } };
const ImageRGBToYUV = { "display_name": "تحويل الصورة من RGB إلى YUV", "inputs": { "image": { "name": "الصورة" } }, "outputs": { "0": { "name": "Y", "tooltip": null }, "1": { "name": "U", "tooltip": null }, "2": { "name": "V", "tooltip": null } } };
const ImageRotate = { "display_name": "ImageRotate", "inputs": { "image": { "name": "صورة" }, "rotation": { "name": "الدوران" } } };
const ImageScale = { "display_name": "تكبير الصورة", "inputs": { "crop": { "name": "اقتصاص" }, "height": { "name": "الارتفاع" }, "image": { "name": "الصورة" }, "upscale_method": { "name": "طريقة التكبير" }, "width": { "name": "العرض" } } };
const ImageScaleBy = { "display_name": "تكبير الصورة بمقدار", "inputs": { "image": { "name": "الصورة" }, "scale_by": { "name": "التكبير بمقدار" }, "upscale_method": { "name": "طريقة التكبير" } } };
const ImageScaleToMaxDimension = { "display_name": "ImageScaleToMaxDimension", "inputs": { "image": { "name": "صورة" }, "largest_size": { "name": "أكبر_حجم" }, "upscale_method": { "name": "طريقة_التكبير" } } };
const ImageScaleToTotalPixels = { "display_name": "تكبير الصورة إلى عدد بكسلات معين", "inputs": { "image": { "name": "الصورة" }, "megapixels": { "name": "الميغابكسل" }, "upscale_method": { "name": "طريقة التكبير" } }, "outputs": { "0": { "tooltip": null } } };
const ImageSharpen = { "display_name": "تحسين وضوح الصورة", "inputs": { "alpha": { "name": "ألفا" }, "image": { "name": "الصورة" }, "sharpen_radius": { "name": "نصف قطر التحسين" }, "sigma": { "name": "سيغما" } }, "outputs": { "0": { "tooltip": null } } };
const ImageStitch = { "description": "\nيربط الصورة الثانية بالصورة الأولى في الاتجاه المحدد.\nإذا لم يتم توفير الصورة الثانية، يتم إرجاع الصورة الأولى دون تغيير.\nيمكن إضافة تباعد اختياري بين الصور.\n", "display_name": "ربط_الصور", "inputs": { "direction": { "name": "الاتجاه" }, "image1": { "name": "الصورة_الأولى" }, "image2": { "name": "الصورة_الثانية" }, "match_image_size": { "name": "مطابقة_حجم_الصورة" }, "spacing_color": { "name": "لون_التباعد" }, "spacing_width": { "name": "عرض_التباعد" } } };
const ImageToMask = { "display_name": "تحويل الصورة إلى قناع", "inputs": { "channel": { "name": "القناة" }, "image": { "name": "الصورة" } } };
const ImageUpscaleWithModel = { "display_name": "تكبير الصورة (باستخدام نموذج)", "inputs": { "image": { "name": "الصورة" }, "upscale_model": { "name": "نموذج التكبير" } }, "outputs": { "0": { "tooltip": null } } };
const ImageYUVToRGB = { "display_name": "تحويل الصورة من YUV إلى RGB", "inputs": { "U": { "name": "U" }, "V": { "name": "V" }, "Y": { "name": "Y" } }, "outputs": { "0": { "tooltip": null } } };
const InpaintModelConditioning = { "display_name": "تكوين نموذج التلوين", "inputs": { "mask": { "name": "قناع" }, "negative": { "name": "سلبي" }, "noise_mask": { "name": "قناع الضجيج", "tooltip": "أضف قناع ضجيج إلى المتغير الكامن بحيث يحدث التوليد داخل القناع فقط. قد يحسن النتائج أو يفسدها تمامًا اعتمادًا على النموذج." }, "pixels": { "name": "بكسلات" }, "positive": { "name": "إيجابي" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "إيجابي" }, "1": { "name": "سلبي" }, "2": { "name": "المتغير الكامن" } } };
const InstructPixToPixConditioning = { "display_name": "تكوين توجيهي للبيكسل إلى بيكسل", "inputs": { "negative": { "name": "سلبي" }, "pixels": { "name": "بكسلات" }, "positive": { "name": "إيجابي" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "إيجابي", "tooltip": null }, "1": { "name": "سلبي", "tooltip": null }, "2": { "name": "المتغير الكامن", "tooltip": null } } };
const InvertMask = { "display_name": "عكس القناع", "inputs": { "mask": { "name": "قناع" } } };
const JoinImageWithAlpha = { "display_name": "دمج الصورة مع ألفا", "inputs": { "alpha": { "name": "ألفا" }, "image": { "name": "صورة" } }, "outputs": { "0": { "tooltip": null } } };
const KSampler = { "description": "يستخدم النموذج المقدم، والتوجيه الإيجابي والسلبي لإزالة الضجيج من الصورة الكامنة.", "display_name": "KSampler", "inputs": { "cfg": { "name": "cfg", "tooltip": "مقياس التوجيه بدون مصنف يوازن بين الإبداع والالتزام بالتوجيه. القيم الأعلى تؤدي إلى صور أقرب للنص، لكن القيم العالية جدًا تؤثر سلبًا على الجودة." }, "control_after_generate": { "name": "التحكم بعد الإنشاء" }, "denoise": { "name": "ازاله الضجيج", "tooltip": "مقدار إزالة الضجيج المطبق، القيم الأقل تحافظ على هيكل الصورة الأصلية مما يسمح بأخذ العينات من صورة إلى أخرى." }, "latent_image": { "name": "الصوره الكامنه", "tooltip": "الصورة الكامنة التي سيتم إزالة الضجيج منها." }, "model": { "name": "النمودج", "tooltip": "النموذج المستخدم لإزالة الضجيج من الصورة الكامنة المدخلة." }, "negative": { "name": "سلبي", "tooltip": "التوجيه الذي يصف الخصائص التي تريد استبعادها من الصورة." }, "positive": { "name": "إيجابي", "tooltip": "التوجيه الذي يصف الخصائص التي تريد تضمينها في الصورة." }, "sampler_name": { "name": "اسم المقطع", "tooltip": "الخوارزمية المستخدمة أثناء أخذ العينات، قد تؤثر على الجودة، السرعة، وأسلوب الناتج." }, "scheduler": { "name": "المجدول", "tooltip": "الجدول الزمني يتحكم في كيفية إزالة الضجيج تدريجيًا لتشكيل الصورة." }, "seed": { "name": "بذرة", "tooltip": "البذرة العشوائية المستخدمة لإنشاء الضجيج." }, "steps": { "name": "الخطوات", "tooltip": "عدد الخطوات المستخدمة في عملية إزالة الضجيج." } }, "outputs": { "0": { "tooltip": "الصورة الكامنة بعد إزالة الضجيج." } } };
const KSamplerAdvanced = { "display_name": "KSampler (متقدم)", "inputs": { "add_noise": { "name": "اضافة ضجيج" }, "cfg": { "name": "cfg" }, "control_after_generate": { "name": "التحكم بعد الإنشاء" }, "end_at_step": { "name": "توقف عند الخطوة" }, "latent_image": { "name": "الصوره الكامنة" }, "model": { "name": "النموذج" }, "negative": { "name": "سلبي" }, "noise_seed": { "name": "بذرة الضجيج" }, "positive": { "name": "إيجابي" }, "return_with_leftover_noise": { "name": "أخرج بالضجيج المتبقي" }, "sampler_name": { "name": "اسم المقطع" }, "scheduler": { "name": "المجدول" }, "start_at_step": { "name": "ابدأ بالخطوة" }, "steps": { "name": "الخطوات" } } };
const KSamplerSelect = { "display_name": "KSamplerSelect", "inputs": { "sampler_name": { "name": "sampler_name" } } };
const KarrasScheduler = { "display_name": "جدول كراس", "inputs": { "rho": { "name": "رو" }, "sigma_max": { "name": "سيجما ماكس" }, "sigma_min": { "name": "سيجما مين" }, "steps": { "name": "خطوات" } } };
const KlingCameraControlI2VNode = { "description": "تحويل الصور الثابتة إلى فيديوهات سينمائية مع حركات كاميرا احترافية تحاكي التصوير السينمائي الحقيقي. تحكم في زووم، دوران، تحريك الكاميرا، الميل، والرؤية من منظور الشخص الأول مع الحفاظ على تركيز الصورة الأصلية.", "display_name": "تحكم كاميرا كليغ: صورة إلى فيديو", "inputs": { "aspect_ratio": { "name": "نسبة العرض إلى الارتفاع" }, "camera_control": { "name": "تحكم الكاميرا", "tooltip": "يمكن إنشاؤه باستخدام عقدة تحكم كاميرا كليغ. يتحكم في حركة الكاميرا أثناء توليد الفيديو." }, "cfg_scale": { "name": "مقياس CFG" }, "negative_prompt": { "name": "نص التوجيه السلبي", "tooltip": "نص التوجيه السلبي" }, "prompt": { "name": "نص التوجيه الإيجابي", "tooltip": "نص التوجيه الإيجابي" }, "start_frame": { "name": "الإطار الابتدائي", "tooltip": "صورة مرجعية - رابط أو نص مشفر Base64، لا تتجاوز 10 ميغابايت، الدقة لا تقل عن 300×300 بكسل، نسبة العرض إلى الارتفاع بين 1:2.5 و2.5:1. يجب ألا يتضمن Base64 بادئة data:image." } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "معرّف الفيديو", "tooltip": null }, "2": { "name": "المدة", "tooltip": null } } };
const KlingCameraControlT2VNode = { "description": "تحويل النصوص إلى فيديوهات سينمائية مع حركات كاميرا احترافية تحاكي التصوير السينمائي الحقيقي. تحكم في زووم، دوران، تحريك الكاميرا، الميل، والرؤية من منظور الشخص الأول مع الحفاظ على تركيز النص الأصلي.", "display_name": "تحكم كاميرا كليغ: نص إلى فيديو", "inputs": { "aspect_ratio": { "name": "نسبة العرض إلى الارتفاع" }, "camera_control": { "name": "تحكم الكاميرا", "tooltip": "يمكن إنشاؤه باستخدام عقدة تحكم كاميرا كليغ. يتحكم في حركة الكاميرا أثناء توليد الفيديو." }, "cfg_scale": { "name": "مقياس CFG" }, "negative_prompt": { "name": "نص التوجيه السلبي", "tooltip": "نص التوجيه السلبي" }, "prompt": { "name": "نص التوجيه الإيجابي", "tooltip": "نص التوجيه الإيجابي" } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "معرّف الفيديو", "tooltip": null }, "2": { "name": "المدة", "tooltip": null } } };
const KlingCameraControls = { "description": "يتيح تحديد خيارات التكوين لتأثيرات تحكم كاميرا كليغ وحركة الكاميرا.", "display_name": "تحكم كاميرا كليغ", "inputs": { "camera_control_type": { "name": "نوع تحكم الكاميرا" }, "horizontal_movement": { "name": "الحركة الأفقية", "tooltip": "يتحكم في حركة الكاميرا على المحور الأفقي (المحور X). القيم السالبة تعني التحرك لليسار، والقيم الموجبة تعني التحرك لليمين." }, "pan": { "name": "تدوير Pan", "tooltip": "يتحكم في دوران الكاميرا في المستوى الرأسي (المحور X). القيم السالبة تعني دوران لأسفل، والقيم الموجبة تعني دوران لأعلى." }, "roll": { "name": "تدوير Roll", "tooltip": "يتحكم في دوران الكاميرا حول المحور Z. القيم السالبة تعني دوران عكس عقارب الساعة، والقيم الموجبة تعني دوران مع عقارب الساعة." }, "tilt": { "name": "تدوير Tilt", "tooltip": "يتحكم في دوران الكاميرا في المستوى الأفقي (المحور Y). القيم السالبة تعني دوران لليسار، والقيم الموجبة تعني دوران لليمين." }, "vertical_movement": { "name": "الحركة الرأسية", "tooltip": "يتحكم في حركة الكاميرا على المحور الرأسي (المحور Y). القيم السالبة تعني التحرك للأسفل، والقيم الموجبة تعني التحرك للأعلى." }, "zoom": { "name": "التكبير", "tooltip": "يتحكم في تغيير طول البعد البؤري للكاميرا. القيم السالبة تعني مجال رؤية أضيق، والقيم الموجبة تعني مجال رؤية أوسع." } }, "outputs": { "0": { "name": "تحكم الكاميرا", "tooltip": null } } };
const KlingDualCharacterVideoEffectNode = { "description": "تحقيق تأثيرات خاصة مختلفة عند توليد فيديو بناءً على مشهد التأثير. ستوضع الصورة الأولى على الجانب الأيسر، والثانية على الجانب الأيمن من التركيب.", "display_name": "تأثيرات فيديو شخصية مزدوجة كليغ", "inputs": { "duration": { "name": "المدة" }, "effect_scene": { "name": "مشهد التأثير" }, "image_left": { "name": "الصورة اليسرى", "tooltip": "الصورة على الجانب الأيسر" }, "image_right": { "name": "الصورة اليمنى", "tooltip": "الصورة على الجانب الأيمن" }, "mode": { "name": "الوضع" }, "model_name": { "name": "اسم النموذج" } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "المدة", "tooltip": null } } };
const KlingImage2VideoNode = { "display_name": "كليغ صورة إلى فيديو", "inputs": { "aspect_ratio": { "name": "نسبة العرض إلى الارتفاع" }, "cfg_scale": { "name": "مقياس CFG" }, "duration": { "name": "المدة" }, "mode": { "name": "الوضع" }, "model_name": { "name": "اسم النموذج" }, "negative_prompt": { "name": "نص التوجيه السلبي", "tooltip": "نص التوجيه السلبي" }, "prompt": { "name": "نص التوجيه الإيجابي", "tooltip": "نص التوجيه الإيجابي" }, "start_frame": { "name": "الإطار الابتدائي", "tooltip": "صورة مرجعية - رابط أو نص مشفر Base64، لا تتجاوز 10 ميغابايت، الدقة لا تقل عن 300×300 بكسل، نسبة العرض إلى الارتفاع بين 1:2.5 و2.5:1. يجب ألا يتضمن Base64 بادئة data:image." } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "معرّف الفيديو", "tooltip": null }, "2": { "name": "المدة", "tooltip": null } } };
const KlingImageGenerationNode = { "description": "عقدة توليد صورة كليغ. توليد صورة من نص مع صورة مرجعية اختيارية.", "display_name": "توليد صورة كليغ", "inputs": { "aspect_ratio": { "name": "نسبة العرض إلى الارتفاع" }, "human_fidelity": { "name": "تشابه الموضوع", "tooltip": "تشابه المرجع للموضوع البشري" }, "image": { "name": "صورة" }, "image_fidelity": { "name": "شدة المرجع للصورة المرفوعة", "tooltip": "شدة المرجع للصور المرفوعة من المستخدم" }, "image_type": { "name": "نوع الصورة" }, "model_name": { "name": "اسم النموذج" }, "n": { "name": "عدد الصور", "tooltip": "عدد الصور المولدة" }, "negative_prompt": { "name": "نص التوجيه السلبي", "tooltip": "نص التوجيه السلبي" }, "prompt": { "name": "نص التوجيه الإيجابي", "tooltip": "نص التوجيه الإيجابي" } }, "outputs": { "0": { "tooltip": null } } };
const KlingLipSyncAudioToVideoNode = { "description": "عقدة مزامنة شفاه كليغ من الصوت إلى الفيديو. تزامن حركة الفم في فيديو مع محتوى صوتي.", "display_name": "مزامنة شفاه كليغ مع الصوت", "inputs": { "audio": { "name": "صوت" }, "video": { "name": "فيديو" }, "voice_language": { "name": "لغة الصوت" } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "معرّف الفيديو", "tooltip": null }, "2": { "name": "المدة", "tooltip": null } } };
const KlingLipSyncTextToVideoNode = { "description": "عقدة مزامنة شفاه كليغ من النص إلى الفيديو. تزامن حركة الفم في فيديو مع نص توجيهي.", "display_name": "مزامنة شفاه كليغ مع النص", "inputs": { "text": { "name": "نص", "tooltip": "محتوى النص لتوليد فيديو مزامنة الشفاه. مطلوب عند الوضع text2video. الحد الأقصى للطول 120 حرفًا." }, "video": { "name": "فيديو" }, "voice": { "name": "صوت" }, "voice_speed": { "name": "سرعة الصوت", "tooltip": "معدل الكلام. النطاق الصحيح: 0.8~2.0، بدقة عشرية واحدة." } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "معرّف الفيديو", "tooltip": null }, "2": { "name": "المدة", "tooltip": null } } };
const KlingSingleImageVideoEffectNode = { "description": "تحقيق تأثيرات خاصة مختلفة عند توليد فيديو بناءً على مشهد التأثير.", "display_name": "تأثيرات فيديو كليغ", "inputs": { "duration": { "name": "المدة" }, "effect_scene": { "name": "مشهد التأثير" }, "image": { "name": "صورة مرجعية", "tooltip": "صورة مرجعية. رابط أو نص مشفر Base64 (بدون بادئة data:image). لا يتجاوز حجم الملف 10 ميغابايت، الدقة لا تقل عن 300×300 بكسل، نسبة العرض إلى الارتفاع بين 1:2.5 و2.5:1" }, "model_name": { "name": "اسم النموذج" } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "معرّف الفيديو", "tooltip": null }, "2": { "name": "المدة", "tooltip": null } } };
const KlingStartEndFrameNode = { "description": "إنشاء تسلسل فيديو ينتقل بين صور البداية والنهاية التي تزودها. يقوم العقد بإنشاء جميع الإطارات بينهما، مما ينتج تحولًا سلسًا من الإطار الأول إلى الأخير.", "display_name": "كليينج إطار البداية-النهاية إلى فيديو", "inputs": { "aspect_ratio": { "name": "aspect_ratio" }, "cfg_scale": { "name": "cfg_scale" }, "end_frame": { "name": "end_frame", "tooltip": "صورة مرجعية - تحكم إطار النهاية. رابط URL أو نص مشفر بصيغة Base64، لا يتجاوز 10 ميجابايت، الدقة لا تقل عن 300*300 بكسل. يجب ألا يتضمن نص Base64 بادئة data:image." }, "mode": { "name": "mode", "tooltip": "التكوين المستخدم لتوليد الفيديو وفقًا للصيغة: الوضع / المدة / اسم النموذج." }, "negative_prompt": { "name": "negative_prompt", "tooltip": "نص سلبي للتوجيه" }, "prompt": { "name": "prompt", "tooltip": "نص إيجابي للتوجيه" }, "start_frame": { "name": "start_frame", "tooltip": "صورة مرجعية - رابط URL أو نص مشفر بصيغة Base64، لا يتجاوز 10 ميجابايت، الدقة لا تقل عن 300*300 بكسل، نسبة العرض إلى الارتفاع بين 1:2.5 ~ 2.5:1. يجب ألا يتضمن نص Base64 بادئة data:image." } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "video_id", "tooltip": null }, "2": { "name": "duration", "tooltip": null } } };
const KlingTextToVideoNode = { "description": "عقدة تحويل النص إلى فيديو من كليينج", "display_name": "كليينج تحويل النص إلى فيديو", "inputs": { "aspect_ratio": { "name": "aspect_ratio" }, "cfg_scale": { "name": "cfg_scale" }, "mode": { "name": "mode", "tooltip": "التكوين المستخدم لتوليد الفيديو وفقًا للصيغة: الوضع / المدة / اسم النموذج." }, "negative_prompt": { "name": "negative_prompt", "tooltip": "نص سلبي للتوجيه" }, "prompt": { "name": "prompt", "tooltip": "نص إيجابي للتوجيه" } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "video_id", "tooltip": null }, "2": { "name": "duration", "tooltip": null } } };
const KlingVideoExtendNode = { "description": "عقدة تمديد الفيديو من كليينج. تمديد الفيديوهات المصنوعة بواسطة عقد كليينج الأخرى. يتم إنشاء video_id باستخدام عقد كليينج الأخرى.", "display_name": "كليينج تمديد الفيديو", "inputs": { "cfg_scale": { "name": "cfg_scale" }, "negative_prompt": { "name": "negative_prompt", "tooltip": "نص سلبي لعناصر يجب تجنبها في الفيديو الممدد" }, "prompt": { "name": "prompt", "tooltip": "نص إيجابي لتوجيه تمديد الفيديو" }, "video_id": { "name": "video_id", "tooltip": "معرف الفيديو المراد تمديده. يدعم الفيديوهات الناتجة عن تحويل النص إلى فيديو، وتحويل الصورة إلى فيديو، وعمليات تمديد الفيديو السابقة. لا يمكن أن تتجاوز مدة الفيديو الإجمالية بعد التمديد 3 دقائق." } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "video_id", "tooltip": null }, "2": { "name": "duration", "tooltip": null } } };
const KlingVirtualTryOnNode = { "description": "عقدة تجربة الملابس الافتراضية من كليينج. أدخل صورة إنسان وصورة ملابس لتجربة الملابس على الإنسان.", "display_name": "كليينج تجربة الملابس الافتراضية", "inputs": { "cloth_image": { "name": "cloth_image" }, "human_image": { "name": "human_image" }, "model_name": { "name": "model_name" } }, "outputs": { "0": { "tooltip": null } } };
const LTXVAddGuide = { "display_name": "إضافة دليل LTXV", "inputs": { "frame_idx": { "name": "مؤشر الإطار", "tooltip": "مؤشر الإطار لبدء التهيئة. لأي صورة أو فيديو بإطارات 1-8، أي قيمة مقبولة. للفيديوهات 9+، يجب أن يكون قابلاً للقسمة على 8، وإلا سيتم تقريبه للأسفل لأقرب مضاعف 8. القيم السالبة تُحسب من نهاية الفيديو." }, "image": { "name": "صورة", "tooltip": "صورة أو فيديو لتكييف الفيديو الكامن عليه. يجب أن يكون عدد الإطارات 8*n + 1. إذا لم يكن كذلك، سيتم قصه إلى أقرب 8*n + 1." }, "latent": { "name": "كامن" }, "negative": { "name": "سلبي" }, "positive": { "name": "إيجابي" }, "strength": { "name": "القوة" }, "vae": { "name": "VAE" } }, "outputs": { "0": { "name": "إيجابي", "tooltip": null }, "1": { "name": "سلبي", "tooltip": null }, "2": { "name": "كامن", "tooltip": null } } };
const LTXVConditioning = { "display_name": "تهيئة LTXV", "inputs": { "frame_rate": { "name": "معدل الإطارات" }, "negative": { "name": "سلبي" }, "positive": { "name": "إيجابي" } }, "outputs": { "0": { "name": "إيجابي", "tooltip": null }, "1": { "name": "سلبي", "tooltip": null } } };
const LTXVCropGuides = { "display_name": "قص أدلة LTXV", "inputs": { "latent": { "name": "كامن" }, "negative": { "name": "سلبي" }, "positive": { "name": "إيجابي" } }, "outputs": { "0": { "name": "إيجابي", "tooltip": null }, "1": { "name": "سلبي", "tooltip": null }, "2": { "name": "كامن", "tooltip": null } } };
const LTXVImgToVideo = { "display_name": "LTXV صورة إلى فيديو", "inputs": { "batch_size": { "name": "حجم الدُفعة" }, "height": { "name": "الارتفاع" }, "image": { "name": "صورة" }, "length": { "name": "الطول" }, "negative": { "name": "سلبي" }, "positive": { "name": "إيجابي" }, "strength": { "name": "القوة" }, "vae": { "name": "vae" }, "width": { "name": "العرض" } }, "outputs": { "0": { "name": "إيجابي", "tooltip": null }, "1": { "name": "سلبي", "tooltip": null }, "2": { "name": "كامن", "tooltip": null } } };
const LTXVPreprocess = { "display_name": "LTXV المعالجة المسبقة", "inputs": { "image": { "name": "صورة" }, "img_compression": { "name": "ضغط الصورة", "tooltip": "مقدار الضغط الذي سيتم تطبيقه على الصورة." } }, "outputs": { "0": { "name": "صورة الإخراج", "tooltip": null } } };
const LTXVScheduler = { "display_name": "LTXV المجدول", "inputs": { "base_shift": { "name": "الانزياح الأساسي" }, "latent": { "name": "كامن" }, "max_shift": { "name": "الانزياح الأقصى" }, "steps": { "name": "خطوات" }, "stretch": { "name": "تمدد", "tooltip": "تمديد قيم السيغما لتكون ضمن المدى [النهائي، 1]." }, "terminal": { "name": "نهائي", "tooltip": "القيمة النهائية للسيغما بعد التمدد." } }, "outputs": { "0": { "tooltip": null } } };
const LaplaceScheduler = { "display_name": "جدول لاپلاس", "inputs": { "beta": { "name": "beta" }, "mu": { "name": "mu" }, "sigma_max": { "name": "sigma_max" }, "sigma_min": { "name": "sigma_min" }, "steps": { "name": "الخطوات" } } };
const LatentAdd = { "display_name": "جمع الكامن", "inputs": { "samples1": { "name": "samples1" }, "samples2": { "name": "samples2" } }, "outputs": { "0": { "tooltip": null } } };
const LatentApplyOperation = { "display_name": "تطبيق عملية على الكامن", "inputs": { "operation": { "name": "operation" }, "samples": { "name": "samples" } }, "outputs": { "0": { "tooltip": null } } };
const LatentApplyOperationCFG = { "display_name": "تطبيق عملية مع CFG على الكامن", "inputs": { "model": { "name": "model" }, "operation": { "name": "operation" } }, "outputs": { "0": { "tooltip": null } } };
const LatentBatch = { "display_name": "دفعة كامن", "inputs": { "samples1": { "name": "samples1" }, "samples2": { "name": "samples2" } }, "outputs": { "0": { "tooltip": null } } };
const LatentBatchSeedBehavior = { "display_name": "سلوك بذرة دفعة الكامن", "inputs": { "samples": { "name": "samples" }, "seed_behavior": { "name": "seed_behavior" } }, "outputs": { "0": { "tooltip": null } } };
const LatentBlend = { "display_name": "مزج الكامن", "inputs": { "blend_factor": { "name": "blend_factor" }, "samples1": { "name": "samples1" }, "samples2": { "name": "samples2" } } };
const LatentComposite = { "display_name": "تركيب الكامن", "inputs": { "feather": { "name": "feather" }, "samples_from": { "name": "samples_from" }, "samples_to": { "name": "samples_to" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const LatentCompositeMasked = { "display_name": "تركيب كامن مقنع", "inputs": { "destination": { "name": "destination" }, "mask": { "name": "mask" }, "resize_source": { "name": "resize_source" }, "source": { "name": "source" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const LatentConcat = { "display_name": "دمج_الكامن", "inputs": { "dim": { "name": "البعد" }, "samples1": { "name": "عينات1" }, "samples2": { "name": "عينات2" } }, "outputs": { "0": { "tooltip": null } } };
const LatentCrop = { "display_name": "قص الكامن", "inputs": { "height": { "name": "height" }, "samples": { "name": "samples" }, "width": { "name": "width" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const LatentCut = { "display_name": "قطع_الكامن", "inputs": { "amount": { "name": "الكمية" }, "dim": { "name": "البعد" }, "index": { "name": "المؤشر" }, "samples": { "name": "العينات" } }, "outputs": { "0": { "tooltip": null } } };
const LatentFlip = { "display_name": "قلب الكامن", "inputs": { "flip_method": { "name": "flip_method" }, "samples": { "name": "samples" } } };
const LatentFromBatch = { "display_name": "الكامن من الدفعة", "inputs": { "batch_index": { "name": "batch_index" }, "length": { "name": "length" }, "samples": { "name": "samples" } } };
const LatentInterpolate = { "display_name": "استيفاء الكامن", "inputs": { "ratio": { "name": "ratio" }, "samples1": { "name": "samples1" }, "samples2": { "name": "samples2" } }, "outputs": { "0": { "tooltip": null } } };
const LatentMultiply = { "display_name": "الضرب الكامن", "inputs": { "multiplier": { "name": "المضاعف" }, "samples": { "name": "عينات" } }, "outputs": { "0": { "tooltip": null } } };
const LatentOperationSharpen = { "display_name": "عملية التوضيح الكامن", "inputs": { "alpha": { "name": "ألفا" }, "sharpen_radius": { "name": "نصف قطر التوضيح" }, "sigma": { "name": "سيغما" } }, "outputs": { "0": { "tooltip": null } } };
const LatentOperationTonemapReinhard = { "display_name": "عملية خريطة اللون الكامنة - راينهارد", "inputs": { "multiplier": { "name": "المضاعف" } }, "outputs": { "0": { "tooltip": null } } };
const LatentRotate = { "display_name": "تدوير كامن", "inputs": { "rotation": { "name": "التدوير" }, "samples": { "name": "عينات" } } };
const LatentSubtract = { "display_name": "طرح كامن", "inputs": { "samples1": { "name": "عينات 1" }, "samples2": { "name": "عينات 2" } }, "outputs": { "0": { "tooltip": null } } };
const LatentUpscale = { "display_name": "تكبير كامن", "inputs": { "crop": { "name": "قص" }, "height": { "name": "الارتفاع" }, "samples": { "name": "عينات" }, "upscale_method": { "name": "طريقة التكبير" }, "width": { "name": "العرض" } } };
const LatentUpscaleBy = { "display_name": "تكبير كامن بنسبة", "inputs": { "samples": { "name": "عينات" }, "scale_by": { "name": "نسبة التكبير" }, "upscale_method": { "name": "طريقة التكبير" } } };
const LazyCache = { "description": "نسخة محلية الصنع من EasyCache - نسخة 'أسهل' من EasyCache للتنفيذ. تعمل بشكل عام أسوأ من EasyCache، ولكن أفضل في بعض الحالات النادرة ومتوافقة عالميًا مع كل شيء في ComfyUI.", "display_name": "ذاكرة_التخزين_المؤقت_الكسولة", "inputs": { "end_percent": { "name": "النسبة_المئوية_النهاية", "tooltip": "خطوة أخذ العينات النسبية لإنهاء استخدام ذاكرة التخزين المؤقت الكسولة." }, "model": { "name": "النموذج", "tooltip": "النموذج المراد إضافة ذاكرة التخزين المؤقت الكسولة إليه." }, "reuse_threshold": { "name": "عتبة_إعادة_الاستخدام", "tooltip": "العتبة لإعادة استخدام الخطوات المخزنة مؤقتًا." }, "start_percent": { "name": "النسبة_المئوية_البداية", "tooltip": "خطوة أخذ العينات النسبية لبدء استخدام ذاكرة التخزين المؤقت الكسولة." }, "verbose": { "name": "مفصل", "tooltip": "ما إذا كان سيتم تسجيل المعلومات التفصيلية." } }, "outputs": { "0": { "tooltip": "النموذج مع LazyCache." } } };
const Load3D = { "display_name": "تحميل ثلاثي الأبعاد", "inputs": { "clear": {}, "height": { "name": "الارتفاع" }, "image": { "name": "صورة" }, "model_file": { "name": "ملف النموذج" }, "upload 3d model": {}, "width": { "name": "العرض" } }, "outputs": { "0": { "name": "صورة" }, "1": { "name": "قناع" }, "2": { "name": "مسار الشبكة" }, "3": { "name": "المعتاد" }, "4": { "name": "الخطوط" }, "5": { "name": "معلومات الكاميرا" } } };
const LoadAudio = { "display_name": "تحميل الصوت", "inputs": { "audio": { "name": "صوت" }, "audioUI": { "name": "واجهة الصوت" }, "upload": { "name": "اختر ملف للتحميل" } } };
const LoadImage = { "display_name": "تحميل صورة", "inputs": { "image": { "name": "صورة" }, "upload": { "name": "اختر ملف للتحميل" } } };
const LoadImageMask = { "display_name": "تحميل صورة (كقناع)", "inputs": { "channel": { "name": "القناة" }, "image": { "name": "صورة" }, "upload": { "name": "اختر ملف للتحميل" } } };
const LoadImageOutput = { "description": "تحميل صورة من مجلد المخرجات. عند الضغط على زر التحديث، سيقوم العقدة بتحديث قائمة الصور واختيار أول صورة تلقائياً لتسهيل التكرار.", "display_name": "تحميل صورة (من المخرجات)", "inputs": { "image": { "name": "صورة" }, "refresh": {}, "upload": { "name": "اختر ملف للتحميل" } } };
const LoadLatent = { "display_name": "تحميل كامن", "inputs": { "latent": { "name": "كامن" } } };
const LoadVideo = { "display_name": "تحميل فيديو", "inputs": { "file": { "name": "ملف" }, "upload": { "name": "اختر ملف للتحميل" } }, "outputs": { "0": { "tooltip": null } } };
const LoraLoader = { "description": "يُستخدم LoRA لتعديل نماذج الانتشار و CLIP، وتغيير طريقة إزالة الضجيج من الكامن مثل تطبيق الأنماط. يمكن ربط عدة عقد LoRA معاً.", "display_name": "تحميل LoRA", "inputs": { "clip": { "name": "CLIP", "tooltip": "نموذج CLIP الذي سيتم تطبيق LoRA عليه." }, "lora_name": { "name": "اسم LoRA", "tooltip": "اسم LoRA." }, "model": { "name": "النموذج", "tooltip": "نموذج الانتشار الذي سيتم تطبيق LoRA عليه." }, "strength_clip": { "name": "قوة تعديل CLIP", "tooltip": "مدى قوة تعديل نموذج CLIP. يمكن أن تكون القيمة سالبة." }, "strength_model": { "name": "قوة تعديل النموذج", "tooltip": "مدى قوة تعديل نموذج الانتشار. يمكن أن تكون القيمة سالبة." } }, "outputs": { "0": { "tooltip": "نموذج الانتشار المعدل." }, "1": { "tooltip": "نموذج CLIP المعدل." } } };
const LoraLoaderModelOnly = { "description": "يُستخدم LoRA لتعديل نماذج الانتشار و CLIP، وتغيير طريقة إزالة الضجيج من الكامن مثل تطبيق الأنماط. يمكن ربط عدة عقد LoRA معاً.", "display_name": "تحميل LoRA (نموذج فقط)", "inputs": { "lora_name": { "name": "اسم LoRA" }, "model": { "name": "النموذج" }, "strength_model": { "name": "قوة تعديل النموذج" } }, "outputs": { "0": { "tooltip": "نموذج الانتشار المعدل." } } };
const LoraModelLoader = { "display_name": "تحميل نموذج LoRA", "inputs": { "lora": { "name": "lora", "tooltip": "نموذج LoRA لتطبيقه على نموذج الانتشار." }, "model": { "name": "نموذج", "tooltip": "نموذج الانتشار الذي سيتم تطبيق LoRA عليه." }, "strength_model": { "name": "قوة_النموذج", "tooltip": "مدى قوة تعديل نموذج الانتشار. يمكن أن تكون هذه القيمة سالبة." } }, "outputs": { "0": { "tooltip": "نموذج الانتشار المعدل." } } };
const LoraSave = { "display_name": "استخراج وحفظ LoRA", "inputs": { "bias_diff": { "name": "فرق الانحياز" }, "filename_prefix": { "name": "بادئة اسم الملف" }, "lora_type": { "name": "نوع LoRA" }, "model_diff": { "name": "فرق النموذج", "tooltip": "مخرج ModelSubtract الذي سيتم تحويله إلى LoRA." }, "rank": { "name": "الرتبة" }, "text_encoder_diff": { "name": "فرق مشفر النص", "tooltip": "مخرج CLIPSubtract الذي سيتم تحويله إلى LoRA." } } };
const LossGraphNode = { "display_name": "رسم بياني للخسارة", "inputs": { "filename_prefix": { "name": "بادئة_اسم_الملف" }, "loss": { "name": "خسارة" } } };
const LotusConditioning = { "display_name": "تهيئة Lotus", "outputs": { "0": { "name": "تهيئة", "tooltip": null } } };
const LtxvApiImageToVideo = { "description": "مقاطع فيديو بجودة احترافية مع مدة ودقة قابلة للتخصيص بناءً على الصورة الأولية.", "display_name": "LTXV صورة إلى فيديو", "inputs": { "duration": { "name": "مدة" }, "fps": { "name": "معدل الإطارات" }, "generate_audio": { "name": "إنشاء_صوت", "tooltip": "عند تفعيله، سيتضمن الفيديو المُنشأ صوتًا مُولَّدًا بالذكاء الاصطناعي يتناسب مع المشهد." }, "image": { "name": "صورة", "tooltip": "الإطار الأول الذي سيتم استخدامه للفيديو." }, "model": { "name": "نموذج" }, "prompt": { "name": "مُوجِّه" }, "resolution": { "name": "دقة" } }, "outputs": { "0": { "tooltip": null } } };
const LtxvApiTextToVideo = { "description": "مقاطع فيديو بجودة احترافية مع مدة ودقة قابلة للتخصيص.", "display_name": "LTXV نص إلى فيديو", "inputs": { "duration": { "name": "مدة" }, "fps": { "name": "معدل الإطارات" }, "generate_audio": { "name": "إنشاء_صوت", "tooltip": "عند تفعيله، سيتضمن الفيديو المُنشأ صوتًا مُولَّدًا بالذكاء الاصطناعي يتناسب مع المشهد." }, "model": { "name": "نموذج" }, "prompt": { "name": "مُوجِّه" }, "resolution": { "name": "دقة" } }, "outputs": { "0": { "tooltip": null } } };
const LumaConceptsNode = { "description": "يحتوي على مفهوم كاميرا واحد أو أكثر للاستخدام مع Luma نص إلى فيديو وLuma صورة إلى فيديو.", "display_name": "مفاهيم لومة", "inputs": { "concept1": { "name": "المفهوم 1" }, "concept2": { "name": "المفهوم 2" }, "concept3": { "name": "المفهوم 3" }, "concept4": { "name": "المفهوم 4" }, "luma_concepts": { "name": "مفاهيم لومة", "tooltip": "مفاهيم كاميرا اختيارية لإضافتها إلى المفاهيم المختارة هنا." } }, "outputs": { "0": { "name": "مفاهيم لومة", "tooltip": null } } };
const LumaImageModifyNode = { "description": "تعديل الصور بشكل متزامن بناءً على النص المطلوب ونسبة العرض إلى الارتفاع.", "display_name": "Luma صورة إلى صورة", "inputs": { "control_after_generate": { "name": "التحكم بعد التوليد" }, "image": { "name": "صورة" }, "image_weight": { "name": "وزن الصورة", "tooltip": "وزن الصورة؛ كلما اقترب من 1.0، كان التعديل أقل على الصورة." }, "model": { "name": "نموذج" }, "prompt": { "name": "النص المطلوب", "tooltip": "النص المطلوب لتوليد الصورة" }, "seed": { "name": "البذرة", "tooltip": "تُستخدم لتحديد ما إذا كان يجب إعادة تشغيل العقدة؛ النتائج الفعلية غير حتمية بغض النظر عن البذرة." } }, "outputs": { "0": { "tooltip": null } } };
const LumaImageNode = { "description": "توليد الصور بشكل متزامن بناءً على النص المطلوب ونسبة العرض إلى الارتفاع.", "display_name": "Luma نص إلى صورة", "inputs": { "aspect_ratio": { "name": "نسبة العرض إلى الارتفاع" }, "character_image": { "name": "صورة الشخصية", "tooltip": "صور مرجعية للشخصية؛ يمكن أن تكون دفعة متعددة، حتى 4 صور يمكن اعتبارها." }, "control_after_generate": { "name": "التحكم بعد التوليد" }, "image_luma_ref": { "name": "مرجع لومة للصورة", "tooltip": "اتصال عقدة مرجع لومة للتأثير على التوليد باستخدام الصور المدخلة؛ يمكن اعتبار ما يصل إلى 4 صور." }, "model": { "name": "نموذج" }, "prompt": { "name": "النص المطلوب", "tooltip": "النص المطلوب لتوليد الصورة" }, "seed": { "name": "البذرة", "tooltip": "تُستخدم لتحديد ما إذا كان يجب إعادة تشغيل العقدة؛ النتائج الفعلية غير حتمية بغض النظر عن البذرة." }, "style_image": { "name": "صورة النمط", "tooltip": "صورة مرجعية للنمط؛ سيتم استخدام صورة واحدة فقط." }, "style_image_weight": { "name": "وزن صورة النمط", "tooltip": "وزن صورة النمط. يتم تجاهله إذا لم يتم توفير صورة نمط." } }, "outputs": { "0": { "tooltip": null } } };
const LumaImageToVideoNode = { "description": "توليد الفيديوهات بشكل متزامن بناءً على النص المطلوب، الصور المدخلة، وحجم الإخراج.", "display_name": "Luma صورة إلى فيديو", "inputs": { "control_after_generate": { "name": "التحكم بعد التوليد" }, "duration": { "name": "المدة" }, "first_image": { "name": "الصورة الأولى", "tooltip": "الإطار الأول من الفيديو المولد." }, "last_image": { "name": "الصورة الأخيرة", "tooltip": "الإطار الأخير من الفيديو المولد." }, "loop": { "name": "التكرار" }, "luma_concepts": { "name": "مفاهيم لومة", "tooltip": "مفاهيم كاميرا اختيارية لتوجيه حركة الكاميرا عبر عقدة مفاهيم لومة." }, "model": { "name": "نموذج" }, "prompt": { "name": "النص المطلوب", "tooltip": "النص المطلوب لتوليد الفيديو" }, "resolution": { "name": "الدقة" }, "seed": { "name": "البذرة", "tooltip": "تُستخدم لتحديد ما إذا كان يجب إعادة تشغيل العقدة؛ النتائج الفعلية غير حتمية بغض النظر عن البذرة." } }, "outputs": { "0": { "tooltip": null } } };
const LumaReferenceNode = { "description": "يحتوي على صورة ووزن لاستخدامها مع عقدة توليد صورة لومة.", "display_name": "مرجع لومة", "inputs": { "image": { "name": "صورة", "tooltip": "صورة لاستخدامها كمرجع." }, "luma_ref": { "name": "مرجع لومة" }, "weight": { "name": "الوزن", "tooltip": "وزن صورة المرجع." } }, "outputs": { "0": { "name": "مرجع لومة", "tooltip": null } } };
const LumaVideoNode = { "description": "توليد الفيديوهات بشكل متزامن بناءً على النص المطلوب وحجم الإخراج.", "display_name": "Luma نص إلى فيديو", "inputs": { "aspect_ratio": { "name": "نسبة العرض إلى الارتفاع" }, "control_after_generate": { "name": "التحكم بعد التوليد" }, "duration": { "name": "المدة" }, "loop": { "name": "التكرار" }, "luma_concepts": { "name": "مفاهيم لومة", "tooltip": "مفاهيم كاميرا اختيارية لتوجيه حركة الكاميرا عبر عقدة مفاهيم لومة." }, "model": { "name": "نموذج" }, "prompt": { "name": "النص المطلوب", "tooltip": "النص المطلوب لتوليد الفيديو" }, "resolution": { "name": "الدقة" }, "seed": { "name": "البذرة", "tooltip": "تُستخدم لتحديد ما إذا كان يجب إعادة تشغيل العقدة؛ النتائج الفعلية غير حتمية بغض النظر عن البذرة." } }, "outputs": { "0": { "tooltip": null } } };
const Mahiro = { "description": "تعديل التوجيه للتركيز أكثر على 'اتجاه' النص الإيجابي بدلاً من الفرق بين النص السلبي.", "display_name": "ماهيرو لطيفة جداً وتستحق دالة توجيه أفضل!! (。・ω・。)", "inputs": { "model": { "name": "نموذج" } }, "outputs": { "0": { "name": "نموذج مُعدل", "tooltip": null } } };
const MaskComposite = { "display_name": "تركيب القناع", "inputs": { "destination": { "name": "الوجهة" }, "operation": { "name": "عملية" }, "source": { "name": "المصدر" }, "x": { "name": "س" }, "y": { "name": "ص" } } };
const MaskPreview = { "description": "يحفظ الصور المدخلة في مجلد الإخراج الخاص بـ ComfyUI.", "display_name": "معاينة القناع", "inputs": { "mask": { "name": "قناع" } } };
const MaskToImage = { "display_name": "تحويل القناع إلى صورة", "inputs": { "mask": { "name": "قناع" } } };
const MinimaxHailuoVideoNode = { "description": "ينشئ مقاطع فيديو من المُوجِّه، مع إطار أول اختياري باستخدام نموذج MiniMax Hailuo-02 الجديد.", "display_name": "MiniMax Hailuo فيديو", "inputs": { "control_after_generate": { "name": "control after generate" }, "duration": { "name": "duration", "tooltip": "طول الفيديو الناتج بالثواني." }, "first_frame_image": { "name": "صورة_الإطار_الأول", "tooltip": "صورة اختيارية لاستخدامها كالإطار الأول لتوليد فيديو." }, "prompt_optimizer": { "name": "prompt_optimizer", "tooltip": "تحسين النص المطلوب لتحسين جودة التوليد عند الحاجة." }, "prompt_text": { "name": "نص_المُوجِّه", "tooltip": "المُوجِّه النصي لتوجيه إنشاء الفيديو." }, "resolution": { "name": "resolution", "tooltip": "أبعاد عرض الفيديو. 1080p هي 1920x1080، 768p هي 1366x768." }, "seed": { "name": "بذرة", "tooltip": "البذرة العشوائية المستخدمة لإنشاء الضوضاء." } }, "outputs": { "0": { "tooltip": null } } };
const MinimaxImageToVideoNode = { "description": "توليد فيديوهات من صورة ونصوص باستخدام API الخاص بـ MiniMax", "display_name": "MiniMax صورة إلى فيديو", "inputs": { "control_after_generate": { "name": "التحكم بعد التوليد" }, "image": { "name": "صورة", "tooltip": "الصورة لاستخدامها كالإطار الأول من الفيديو" }, "model": { "name": "نموذج", "tooltip": "النموذج المستخدم لتوليد الفيديو" }, "prompt_text": { "name": "نص النص المطلوب", "tooltip": "نص لتوجيه توليد الفيديو" }, "seed": { "name": "بذرة", "tooltip": "البذرة العشوائية المستخدمة لإنشاء الضجيج." } }, "outputs": { "0": { "tooltip": null } } };
const MinimaxTextToVideoNode = { "description": "توليد فيديوهات من نصوص باستخدام API الخاص بـ MiniMax", "display_name": "MiniMax نص إلى فيديو", "inputs": { "control_after_generate": { "name": "التحكم بعد التوليد" }, "model": { "name": "نموذج", "tooltip": "النموذج المستخدم لتوليد الفيديو" }, "prompt_text": { "name": "نص النص المطلوب", "tooltip": "نص لتوجيه توليد الفيديو" }, "seed": { "name": "بذرة", "tooltip": "البذرة العشوائية المستخدمة لإنشاء الضجيج." } }, "outputs": { "0": { "tooltip": null } } };
const ModelComputeDtype = { "display_name": "نوع بيانات حساب النموذج", "inputs": { "dtype": { "name": "نوع البيانات" }, "model": { "name": "نموذج" } } };
const ModelMergeAdd = { "display_name": "دمج النموذج بإضافة", "inputs": { "model1": { "name": "نموذج 1" }, "model2": { "name": "نموذج 2" } } };
const ModelMergeAuraflow = { "display_name": "دمج_النموذج_أورافلو", "inputs": { "cond_seq_linear_": { "name": "تسلسل_شرطي_خطي" }, "double_layers_0_": { "name": "طبقات_مزدوجة.0" }, "double_layers_1_": { "name": "طبقات_مزدوجة.1" }, "double_layers_2_": { "name": "طبقات_مزدوجة.2" }, "double_layers_3_": { "name": "طبقات_مزدوجة.3" }, "final_linear_": { "name": "الخطي_النهائي" }, "init_x_linear_": { "name": "المُبادرة_الخطيه_x" }, "modF_": { "name": "مُعدلF" }, "model1": { "name": "النموذج1" }, "model2": { "name": "النموذج2" }, "positional_encoding": { "name": "ترميز_موضعي" }, "register_tokens": { "name": "تسجيل_الرموز" }, "single_layers_0_": { "name": "طبقات_مفردة.0" }, "single_layers_10_": { "name": "طبقات_مفردة.10" }, "single_layers_11_": { "name": "طبقات_مفردة.11" }, "single_layers_12_": { "name": "طبقات_مفردة.12" }, "single_layers_13_": { "name": "طبقات_مفردة.13" }, "single_layers_14_": { "name": "طبقات_مفردة.14" }, "single_layers_15_": { "name": "طبقات_مفردة.15" }, "single_layers_16_": { "name": "طبقات_مفردة.16" }, "single_layers_17_": { "name": "طبقات_مفردة.17" }, "single_layers_18_": { "name": "طبقات_مفردة.18" }, "single_layers_19_": { "name": "طبقات_مفردة.19" }, "single_layers_1_": { "name": "طبقات_مفردة.1" }, "single_layers_20_": { "name": "طبقات_مفردة.20" }, "single_layers_21_": { "name": "طبقات_مفردة.21" }, "single_layers_22_": { "name": "طبقات_مفردة.22" }, "single_layers_23_": { "name": "طبقات_مفردة.23" }, "single_layers_24_": { "name": "طبقات_مفردة.24" }, "single_layers_25_": { "name": "طبقات_مفردة.25" }, "single_layers_26_": { "name": "طبقات_مفردة.26" }, "single_layers_27_": { "name": "طبقات_مفردة.27" }, "single_layers_28_": { "name": "طبقات_مفردة.28" }, "single_layers_29_": { "name": "طبقات_مفردة.29" }, "single_layers_2_": { "name": "طبقات_مفردة.2" }, "single_layers_30_": { "name": "طبقات_مفردة.30" }, "single_layers_31_": { "name": "طبقات_مفردة.31" }, "single_layers_3_": { "name": "طبقات_مفردة.3" }, "single_layers_4_": { "name": "طبقات_مفردة.4" }, "single_layers_5_": { "name": "طبقات_مفردة.5" }, "single_layers_6_": { "name": "طبقات_مفردة.6" }, "single_layers_7_": { "name": "طبقات_مفردة.7" }, "single_layers_8_": { "name": "طبقات_مفردة.8" }, "single_layers_9_": { "name": "طبقات_مفردة.9" }, "t_embedder_": { "name": "مضمن_t" } } };
const ModelMergeBlocks = { "display_name": "دمج_كتل_النموذج", "inputs": { "input": { "name": "الإدخال" }, "middle": { "name": "الوسط" }, "model1": { "name": "النموذج1" }, "model2": { "name": "النموذج2" }, "out": { "name": "الإخراج" } } };
const ModelMergeCosmos14B = { "display_name": "دمج_نموذج_كوزموس14B", "inputs": { "affline_norm_": { "name": "تطبيع_تحويلي" }, "blocks_block0_": { "name": "كتل.كتلة0" }, "blocks_block10_": { "name": "كتل.كتلة10" }, "blocks_block11_": { "name": "كتل.كتلة11" }, "blocks_block12_": { "name": "كتل.كتلة12" }, "blocks_block13_": { "name": "كتل.كتلة13" }, "blocks_block14_": { "name": "كتل.كتلة14" }, "blocks_block15_": { "name": "كتل.كتلة15" }, "blocks_block16_": { "name": "كتل.كتلة16" }, "blocks_block17_": { "name": "كتل.كتلة17" }, "blocks_block18_": { "name": "كتل.كتلة18" }, "blocks_block19_": { "name": "كتل.كتلة19" }, "blocks_block1_": { "name": "كتل.كتلة1" }, "blocks_block20_": { "name": "كتل.كتلة20" }, "blocks_block21_": { "name": "كتل.كتلة21" }, "blocks_block22_": { "name": "كتل.كتلة22" }, "blocks_block23_": { "name": "كتل.كتلة23" }, "blocks_block24_": { "name": "كتل.كتلة24" }, "blocks_block25_": { "name": "كتل.كتلة25" }, "blocks_block26_": { "name": "كتل.كتلة26" }, "blocks_block27_": { "name": "كتل.كتلة27" }, "blocks_block28_": { "name": "كتل.كتلة28" }, "blocks_block29_": { "name": "كتل.كتلة29" }, "blocks_block2_": { "name": "كتل.كتلة2" }, "blocks_block30_": { "name": "كتل.كتلة30" }, "blocks_block31_": { "name": "كتل.كتلة31" }, "blocks_block32_": { "name": "كتل.كتلة32" }, "blocks_block33_": { "name": "كتل.كتلة33" }, "blocks_block34_": { "name": "كتل.كتلة34" }, "blocks_block35_": { "name": "كتل.كتلة35" }, "blocks_block3_": { "name": "كتل.كتلة3" }, "blocks_block4_": { "name": "كتل.كتلة4" }, "blocks_block5_": { "name": "كتل.كتلة5" }, "blocks_block6_": { "name": "كتل.كتلة6" }, "blocks_block7_": { "name": "كتل.كتلة7" }, "blocks_block8_": { "name": "كتل.كتلة8" }, "blocks_block9_": { "name": "كتل.كتلة9" }, "extra_pos_embedder_": { "name": "مضمن_موقع_إضافي" }, "final_layer_": { "name": "الطبقة_النهائية" }, "model1": { "name": "النموذج1" }, "model2": { "name": "النموذج2" }, "pos_embedder_": { "name": "مضمن_الموقع" }, "t_embedder_": { "name": "مضمن_t" }, "x_embedder_": { "name": "مضمن_x" } } };
const ModelMergeCosmos7B = { "display_name": "دمج_نموذج_كوزموس7B", "inputs": { "affline_norm_": { "name": "تطبيع_تحويلي" }, "blocks_block0_": { "name": "كتل.كتلة0" }, "blocks_block10_": { "name": "كتل.كتلة10" }, "blocks_block11_": { "name": "كتل.كتلة11" }, "blocks_block12_": { "name": "كتل.كتلة12" }, "blocks_block13_": { "name": "كتل.كتلة13" }, "blocks_block14_": { "name": "كتل.كتلة14" }, "blocks_block15_": { "name": "كتل.كتلة15" }, "blocks_block16_": { "name": "كتل.كتلة16" }, "blocks_block17_": { "name": "كتل.كتلة17" }, "blocks_block18_": { "name": "كتل.كتلة18" }, "blocks_block19_": { "name": "كتل.كتلة19" }, "blocks_block1_": { "name": "كتل.كتلة1" }, "blocks_block20_": { "name": "كتل.كتلة20" }, "blocks_block21_": { "name": "كتل.كتلة21" }, "blocks_block22_": { "name": "كتل.كتلة22" }, "blocks_block23_": { "name": "كتل.كتلة23" }, "blocks_block24_": { "name": "كتل.كتلة24" }, "blocks_block25_": { "name": "كتل.كتلة25" }, "blocks_block26_": { "name": "كتل.كتلة26" }, "blocks_block27_": { "name": "كتل.كتلة27" }, "blocks_block2_": { "name": "كتل.كتلة2" }, "blocks_block3_": { "name": "كتل.كتلة3" }, "blocks_block4_": { "name": "كتل.كتلة4" }, "blocks_block5_": { "name": "كتل.كتلة5" }, "blocks_block6_": { "name": "كتل.كتلة6" }, "blocks_block7_": { "name": "كتل.كتلة7" }, "blocks_block8_": { "name": "كتل.كتلة8" }, "blocks_block9_": { "name": "كتل.كتلة9" }, "extra_pos_embedder_": { "name": "مضمن_موقع_إضافي" }, "final_layer_": { "name": "الطبقة_النهائية" }, "model1": { "name": "النموذج1" }, "model2": { "name": "النموذج2" }, "pos_embedder_": { "name": "مضمن_الموقع" }, "t_embedder_": { "name": "مضمن_t" }, "x_embedder_": { "name": "مضمن_x" } } };
const ModelMergeCosmosPredict2_14B = { "display_name": "ModelMergeCosmosPredict2_14B", "inputs": { "blocks_0_": { "name": "blocks.0." }, "blocks_10_": { "name": "blocks.10." }, "blocks_11_": { "name": "blocks.11." }, "blocks_12_": { "name": "blocks.12." }, "blocks_13_": { "name": "blocks.13." }, "blocks_14_": { "name": "blocks.14." }, "blocks_15_": { "name": "كتل.15." }, "blocks_16_": { "name": "كتل.16." }, "blocks_17_": { "name": "كتل.17." }, "blocks_18_": { "name": "كتل.18." }, "blocks_19_": { "name": "كتل.19." }, "blocks_1_": { "name": "blocks.1." }, "blocks_20_": { "name": "كتل.20." }, "blocks_21_": { "name": "كتل.21." }, "blocks_22_": { "name": "كتل.22." }, "blocks_23_": { "name": "كتل.23." }, "blocks_24_": { "name": "كتل.24." }, "blocks_25_": { "name": "كتل.25." }, "blocks_26_": { "name": "كتل.26." }, "blocks_27_": { "name": "كتل.27." }, "blocks_28_": { "name": "كتل.28." }, "blocks_29_": { "name": "كتل.29." }, "blocks_2_": { "name": "blocks.2." }, "blocks_30_": { "name": "كتل.30." }, "blocks_31_": { "name": "كتل.31." }, "blocks_32_": { "name": "كتل.32." }, "blocks_33_": { "name": "كتل.33." }, "blocks_34_": { "name": "كتل.34." }, "blocks_35_": { "name": "كتل.35." }, "blocks_3_": { "name": "blocks.3." }, "blocks_4_": { "name": "blocks.4." }, "blocks_5_": { "name": "blocks.5." }, "blocks_6_": { "name": "blocks.6." }, "blocks_7_": { "name": "blocks.7." }, "blocks_8_": { "name": "blocks.8." }, "blocks_9_": { "name": "blocks.9." }, "final_layer_": { "name": "الطبقة_النهائية." }, "model1": { "name": "model1" }, "model2": { "name": "model2" }, "pos_embedder_": { "name": "pos_embedder." }, "t_embedder_": { "name": "t_embedder." }, "t_embedding_norm_": { "name": "t_embedding_norm." }, "x_embedder_": { "name": "x_embedder." } } };
const ModelMergeCosmosPredict2_2B = { "display_name": "دمج_النموذج_كوزموس_التنبؤ_2_2ب", "inputs": { "blocks_0_": { "name": "كتل.0." }, "blocks_10_": { "name": "كتل.10." }, "blocks_11_": { "name": "كتل.11." }, "blocks_12_": { "name": "كتل.12." }, "blocks_13_": { "name": "كتل.13." }, "blocks_14_": { "name": "كتل.14." }, "blocks_15_": { "name": "كتل.15." }, "blocks_16_": { "name": "كتل.16." }, "blocks_17_": { "name": "كتل.17." }, "blocks_18_": { "name": "كتل.18." }, "blocks_19_": { "name": "كتل.19." }, "blocks_1_": { "name": "كتل.1." }, "blocks_20_": { "name": "كتل.20." }, "blocks_21_": { "name": "كتل.21." }, "blocks_22_": { "name": "كتل.22." }, "blocks_23_": { "name": "كتل.23." }, "blocks_24_": { "name": "كتل.24." }, "blocks_25_": { "name": "كتل.25." }, "blocks_26_": { "name": "كتل.26." }, "blocks_27_": { "name": "كتل.27." }, "blocks_2_": { "name": "كتل.2." }, "blocks_3_": { "name": "كتل.3." }, "blocks_4_": { "name": "كتل.4." }, "blocks_5_": { "name": "كتل.5." }, "blocks_6_": { "name": "كتل.6." }, "blocks_7_": { "name": "كتل.7." }, "blocks_8_": { "name": "كتل.8." }, "blocks_9_": { "name": "كتل.9." }, "final_layer_": { "name": "الطبقة_النهائية." }, "model1": { "name": "النموذج1" }, "model2": { "name": "النموذج2" }, "pos_embedder_": { "name": "مضمن_الموضع." }, "t_embedder_": { "name": "مضمن_t." }, "t_embedding_norm_": { "name": "تطبيع_تضمين_t." }, "x_embedder_": { "name": "مضمن_x." } } };
const ModelMergeFlux1 = { "display_name": "ModelMergeFlux1", "inputs": { "double_blocks_0_": { "name": "كتل مزدوجة 0" }, "double_blocks_10_": { "name": "كتل مزدوجة 10" }, "double_blocks_11_": { "name": "كتل مزدوجة 11" }, "double_blocks_12_": { "name": "كتل مزدوجة 12" }, "double_blocks_13_": { "name": "كتل مزدوجة 13" }, "double_blocks_14_": { "name": "كتل مزدوجة 14" }, "double_blocks_15_": { "name": "كتل مزدوجة 15" }, "double_blocks_16_": { "name": "كتل مزدوجة 16" }, "double_blocks_17_": { "name": "كتل مزدوجة 17" }, "double_blocks_18_": { "name": "كتل مزدوجة 18" }, "double_blocks_1_": { "name": "كتل مزدوجة 1" }, "double_blocks_2_": { "name": "كتل مزدوجة 2" }, "double_blocks_3_": { "name": "كتل مزدوجة 3" }, "double_blocks_4_": { "name": "كتل مزدوجة 4" }, "double_blocks_5_": { "name": "كتل مزدوجة 5" }, "double_blocks_6_": { "name": "كتل مزدوجة 6" }, "double_blocks_7_": { "name": "كتل مزدوجة 7" }, "double_blocks_8_": { "name": "كتل مزدوجة 8" }, "double_blocks_9_": { "name": "كتل مزدوجة 9" }, "final_layer_": { "name": "الطبقة النهائية" }, "guidance_in": { "name": "توجيه الإدخال" }, "img_in_": { "name": "صورة الإدخال" }, "model1": { "name": "النموذج 1" }, "model2": { "name": "النموذج 2" }, "single_blocks_0_": { "name": "كتل فردية 0" }, "single_blocks_10_": { "name": "كتل فردية 10" }, "single_blocks_11_": { "name": "كتل فردية 11" }, "single_blocks_12_": { "name": "كتل فردية 12" }, "single_blocks_13_": { "name": "كتل فردية 13" }, "single_blocks_14_": { "name": "كتل فردية 14" }, "single_blocks_15_": { "name": "كتل فردية 15" }, "single_blocks_16_": { "name": "كتل فردية 16" }, "single_blocks_17_": { "name": "كتل فردية 17" }, "single_blocks_18_": { "name": "كتل فردية 18" }, "single_blocks_19_": { "name": "كتل فردية 19" }, "single_blocks_1_": { "name": "كتل فردية 1" }, "single_blocks_20_": { "name": "كتل فردية 20" }, "single_blocks_21_": { "name": "كتل فردية 21" }, "single_blocks_22_": { "name": "كتل فردية 22" }, "single_blocks_23_": { "name": "كتل فردية 23" }, "single_blocks_24_": { "name": "كتل فردية 24" }, "single_blocks_25_": { "name": "كتل فردية 25" }, "single_blocks_26_": { "name": "كتل فردية 26" }, "single_blocks_27_": { "name": "كتل فردية 27" }, "single_blocks_28_": { "name": "كتل فردية 28" }, "single_blocks_29_": { "name": "كتل فردية 29" }, "single_blocks_2_": { "name": "كتل فردية 2" }, "single_blocks_30_": { "name": "كتل فردية 30" }, "single_blocks_31_": { "name": "كتل فردية 31" }, "single_blocks_32_": { "name": "كتل فردية 32" }, "single_blocks_33_": { "name": "كتل فردية 33" }, "single_blocks_34_": { "name": "كتل فردية 34" }, "single_blocks_35_": { "name": "كتل فردية 35" }, "single_blocks_36_": { "name": "كتل فردية 36" }, "single_blocks_37_": { "name": "كتل فردية 37" }, "single_blocks_3_": { "name": "كتل فردية 3" }, "single_blocks_4_": { "name": "كتل فردية 4" }, "single_blocks_5_": { "name": "كتل فردية 5" }, "single_blocks_6_": { "name": "كتل فردية 6" }, "single_blocks_7_": { "name": "كتل فردية 7" }, "single_blocks_8_": { "name": "كتل فردية 8" }, "single_blocks_9_": { "name": "كتل فردية 9" }, "time_in_": { "name": "وقت الإدخال" }, "txt_in_": { "name": "نص الإدخال" }, "vector_in_": { "name": "متجه الإدخال" } } };
const ModelMergeLTXV = { "display_name": "ModelMergeLTXV", "inputs": { "adaln_single_": { "name": "آدال إن الفردي" }, "caption_projection_": { "name": "إسقاط التسمية التوضيحية" }, "model1": { "name": "النموذج 1" }, "model2": { "name": "النموذج 2" }, "patchify_proj_": { "name": "مشروع التقسيم" }, "proj_out_": { "name": "الإسقاط الخارجي" }, "scale_shift_table": { "name": "جدول تحجيم الإزاحة" }, "transformer_blocks_0_": { "name": "كتل المحول 0" }, "transformer_blocks_10_": { "name": "كتل المحول 10" }, "transformer_blocks_11_": { "name": "كتل المحول 11" }, "transformer_blocks_12_": { "name": "كتل المحول 12" }, "transformer_blocks_13_": { "name": "كتل المحول 13" }, "transformer_blocks_14_": { "name": "كتل المحول 14" }, "transformer_blocks_15_": { "name": "كتل المحول 15" }, "transformer_blocks_16_": { "name": "كتل المحول 16" }, "transformer_blocks_17_": { "name": "كتل المحول 17" }, "transformer_blocks_18_": { "name": "كتل المحول 18" }, "transformer_blocks_19_": { "name": "كتل المحول 19" }, "transformer_blocks_1_": { "name": "كتل المحول 1" }, "transformer_blocks_20_": { "name": "كتل المحول 20" }, "transformer_blocks_21_": { "name": "كتل المحول 21" }, "transformer_blocks_22_": { "name": "كتل المحول 22" }, "transformer_blocks_23_": { "name": "كتل المحول 23" }, "transformer_blocks_24_": { "name": "كتل المحول 24" }, "transformer_blocks_25_": { "name": "كتل المحول 25" }, "transformer_blocks_26_": { "name": "كتل المحول 26" }, "transformer_blocks_27_": { "name": "كتل المحول 27" }, "transformer_blocks_2_": { "name": "كتل المحول 2" }, "transformer_blocks_3_": { "name": "كتل المحول 3" }, "transformer_blocks_4_": { "name": "كتل المحول 4" }, "transformer_blocks_5_": { "name": "كتل المحول 5" }, "transformer_blocks_6_": { "name": "كتل المحول 6" }, "transformer_blocks_7_": { "name": "كتل المحول 7" }, "transformer_blocks_8_": { "name": "كتل المحول 8" }, "transformer_blocks_9_": { "name": "كتل المحول 9" } } };
const ModelMergeMochiPreview = { "display_name": "ModelMergeMochiPreview", "inputs": { "blocks_0_": { "name": "كتل 0" }, "blocks_10_": { "name": "كتل 10" }, "blocks_11_": { "name": "كتل 11" }, "blocks_12_": { "name": "كتل 12" }, "blocks_13_": { "name": "كتل 13" }, "blocks_14_": { "name": "كتل 14" }, "blocks_15_": { "name": "كتل 15" }, "blocks_16_": { "name": "كتل 16" }, "blocks_17_": { "name": "كتل 17" }, "blocks_18_": { "name": "كتل 18" }, "blocks_19_": { "name": "كتل 19" }, "blocks_1_": { "name": "كتل 1" }, "blocks_20_": { "name": "كتل 20" }, "blocks_21_": { "name": "كتل 21" }, "blocks_22_": { "name": "كتل 22" }, "blocks_23_": { "name": "كتل 23" }, "blocks_24_": { "name": "كتل 24" }, "blocks_25_": { "name": "كتل 25" }, "blocks_26_": { "name": "كتل 26" }, "blocks_27_": { "name": "كتل 27" }, "blocks_28_": { "name": "كتل 28" }, "blocks_29_": { "name": "كتل 29" }, "blocks_2_": { "name": "كتل 2" }, "blocks_30_": { "name": "كتل 30" }, "blocks_31_": { "name": "كتل 31" }, "blocks_32_": { "name": "كتل 32" }, "blocks_33_": { "name": "كتل 33" }, "blocks_34_": { "name": "كتل 34" }, "blocks_35_": { "name": "كتل 35" }, "blocks_36_": { "name": "كتل 36" }, "blocks_37_": { "name": "كتل 37" }, "blocks_38_": { "name": "كتل 38" }, "blocks_39_": { "name": "كتل 39" }, "blocks_3_": { "name": "كتل 3" }, "blocks_40_": { "name": "كتل 40" }, "blocks_41_": { "name": "كتل 41" }, "blocks_42_": { "name": "كتل 42" }, "blocks_43_": { "name": "كتل 43" }, "blocks_44_": { "name": "كتل 44" }, "blocks_45_": { "name": "كتل 45" }, "blocks_46_": { "name": "كتل 46" }, "blocks_47_": { "name": "كتل 47" }, "blocks_4_": { "name": "كتل 4" }, "blocks_5_": { "name": "كتل 5" }, "blocks_6_": { "name": "كتل 6" }, "blocks_7_": { "name": "كتل 7" }, "blocks_8_": { "name": "كتل 8" }, "blocks_9_": { "name": "كتل 9" }, "final_layer_": { "name": "الطبقة النهائية" }, "model1": { "name": "النموذج 1" }, "model2": { "name": "النموذج 2" }, "pos_frequencies_": { "name": "ترددات المواضع" }, "t5_y_embedder_": { "name": "تضمين y لـ T5" }, "t5_yproj_": { "name": "إسقاط y لـ T5" }, "t_embedder_": { "name": "تضمين الزمن" } } };
const ModelMergeQwenImage = { "display_name": "دمج_النموذج_QwenImage", "inputs": { "img_in_": { "name": "img_in." }, "model1": { "name": "النموذج1" }, "model2": { "name": "model2" }, "pos_embeds_": { "name": "pos_embeds." }, "proj_out_": { "name": "proj_out." }, "time_text_embed_": { "name": "time_text_embed." }, "transformer_blocks_0_": { "name": "transformer_blocks.0." }, "transformer_blocks_10_": { "name": "transformer_blocks.10." }, "transformer_blocks_11_": { "name": "transformer_blocks.11." }, "transformer_blocks_12_": { "name": "transformer_blocks.12." }, "transformer_blocks_13_": { "name": "transformer_blocks.13." }, "transformer_blocks_14_": { "name": "transformer_blocks.14." }, "transformer_blocks_15_": { "name": "transformer_blocks.15." }, "transformer_blocks_16_": { "name": "transformer_blocks.16." }, "transformer_blocks_17_": { "name": "transformer_blocks.17." }, "transformer_blocks_18_": { "name": "transformer_blocks.18." }, "transformer_blocks_19_": { "name": "transformer_blocks.19." }, "transformer_blocks_1_": { "name": "transformer_blocks.1." }, "transformer_blocks_20_": { "name": "transformer_blocks.20." }, "transformer_blocks_21_": { "name": "transformer_blocks.21." }, "transformer_blocks_22_": { "name": "transformer_blocks.22." }, "transformer_blocks_23_": { "name": "transformer_blocks.23." }, "transformer_blocks_24_": { "name": "transformer_blocks.24." }, "transformer_blocks_25_": { "name": "transformer_blocks.25." }, "transformer_blocks_26_": { "name": "transformer_blocks.26." }, "transformer_blocks_27_": { "name": "transformer_blocks.27." }, "transformer_blocks_28_": { "name": "transformer_blocks.28." }, "transformer_blocks_29_": { "name": "transformer_blocks.29." }, "transformer_blocks_2_": { "name": "transformer_blocks.2." }, "transformer_blocks_30_": { "name": "transformer_blocks.30." }, "transformer_blocks_31_": { "name": "transformer_blocks.31." }, "transformer_blocks_32_": { "name": "transformer_blocks.32." }, "transformer_blocks_33_": { "name": "transformer_blocks.33." }, "transformer_blocks_34_": { "name": "transformer_blocks.34." }, "transformer_blocks_35_": { "name": "transformer_blocks.35." }, "transformer_blocks_36_": { "name": "transformer_blocks.36." }, "transformer_blocks_37_": { "name": "transformer_blocks.37." }, "transformer_blocks_38_": { "name": "transformer_blocks.38." }, "transformer_blocks_39_": { "name": "transformer_blocks.39." }, "transformer_blocks_3_": { "name": "transformer_blocks.3." }, "transformer_blocks_40_": { "name": "transformer_blocks.40." }, "transformer_blocks_41_": { "name": "transformer_blocks.41." }, "transformer_blocks_42_": { "name": "transformer_blocks.42." }, "transformer_blocks_43_": { "name": "transformer_blocks.43." }, "transformer_blocks_44_": { "name": "transformer_blocks.44." }, "transformer_blocks_45_": { "name": "transformer_blocks.45." }, "transformer_blocks_46_": { "name": "transformer_blocks.46." }, "transformer_blocks_47_": { "name": "transformer_blocks.47." }, "transformer_blocks_48_": { "name": "transformer_blocks.48." }, "transformer_blocks_49_": { "name": "transformer_blocks.49." }, "transformer_blocks_4_": { "name": "transformer_blocks.4." }, "transformer_blocks_50_": { "name": "transformer_blocks.50." }, "transformer_blocks_51_": { "name": "transformer_blocks.51." }, "transformer_blocks_52_": { "name": "transformer_blocks.52." }, "transformer_blocks_53_": { "name": "transformer_blocks.53." }, "transformer_blocks_54_": { "name": "transformer_blocks.54." }, "transformer_blocks_55_": { "name": "transformer_blocks.55." }, "transformer_blocks_56_": { "name": "transformer_blocks.56." }, "transformer_blocks_57_": { "name": "transformer_blocks.57." }, "transformer_blocks_58_": { "name": "transformer_blocks.58." }, "transformer_blocks_59_": { "name": "transformer_blocks.59." }, "transformer_blocks_5_": { "name": "transformer_blocks.5." }, "transformer_blocks_6_": { "name": "transformer_blocks.6." }, "transformer_blocks_7_": { "name": "transformer_blocks.7." }, "transformer_blocks_8_": { "name": "transformer_blocks.8." }, "transformer_blocks_9_": { "name": "transformer_blocks.9." }, "txt_in_": { "name": "txt_in." }, "txt_norm_": { "name": "txt_norm." } } };
const ModelMergeSD1 = { "display_name": "دمج النموذج SD1", "inputs": { "input_blocks_0_": { "name": "كتل الإدخال.0." }, "input_blocks_10_": { "name": "كتل الإدخال.10." }, "input_blocks_11_": { "name": "كتل الإدخال.11." }, "input_blocks_1_": { "name": "كتل الإدخال.1." }, "input_blocks_2_": { "name": "كتل الإدخال.2." }, "input_blocks_3_": { "name": "كتل الإدخال.3." }, "input_blocks_4_": { "name": "كتل الإدخال.4." }, "input_blocks_5_": { "name": "كتل الإدخال.5." }, "input_blocks_6_": { "name": "كتل الإدخال.6." }, "input_blocks_7_": { "name": "كتل الإدخال.7." }, "input_blocks_8_": { "name": "كتل الإدخال.8." }, "input_blocks_9_": { "name": "كتل الإدخال.9." }, "label_emb_": { "name": "تضمين التسمية." }, "middle_block_0_": { "name": "كتلة الوسط.0." }, "middle_block_1_": { "name": "كتلة الوسط.1." }, "middle_block_2_": { "name": "كتلة الوسط.2." }, "model1": { "name": "النموذج 1" }, "model2": { "name": "النموذج 2" }, "out_": { "name": "الإخراج." }, "output_blocks_0_": { "name": "كتل الإخراج.0." }, "output_blocks_10_": { "name": "كتل الإخراج.10." }, "output_blocks_11_": { "name": "كتل الإخراج.11." }, "output_blocks_1_": { "name": "كتل الإخراج.1." }, "output_blocks_2_": { "name": "كتل الإخراج.2." }, "output_blocks_3_": { "name": "كتل الإخراج.3." }, "output_blocks_4_": { "name": "كتل الإخراج.4." }, "output_blocks_5_": { "name": "كتل الإخراج.5." }, "output_blocks_6_": { "name": "كتل الإخراج.6." }, "output_blocks_7_": { "name": "كتل الإخراج.7." }, "output_blocks_8_": { "name": "كتل الإخراج.8." }, "output_blocks_9_": { "name": "كتل الإخراج.9." }, "time_embed_": { "name": "تضمين الوقت." } } };
const ModelMergeSD2 = { "display_name": "دمج النموذج SD2", "inputs": { "input_blocks_0_": { "name": "كتل الإدخال.0." }, "input_blocks_10_": { "name": "كتل الإدخال.10." }, "input_blocks_11_": { "name": "كتل الإدخال.11." }, "input_blocks_1_": { "name": "كتل الإدخال.1." }, "input_blocks_2_": { "name": "كتل الإدخال.2." }, "input_blocks_3_": { "name": "كتل الإدخال.3." }, "input_blocks_4_": { "name": "كتل الإدخال.4." }, "input_blocks_5_": { "name": "كتل الإدخال.5." }, "input_blocks_6_": { "name": "كتل الإدخال.6." }, "input_blocks_7_": { "name": "كتل الإدخال.7." }, "input_blocks_8_": { "name": "كتل الإدخال.8." }, "input_blocks_9_": { "name": "كتل الإدخال.9." }, "label_emb_": { "name": "تضمين التسمية." }, "middle_block_0_": { "name": "كتلة الوسط.0." }, "middle_block_1_": { "name": "كتلة الوسط.1." }, "middle_block_2_": { "name": "كتلة الوسط.2." }, "model1": { "name": "النموذج 1" }, "model2": { "name": "النموذج 2" }, "out_": { "name": "الإخراج." }, "output_blocks_0_": { "name": "كتل الإخراج.0." }, "output_blocks_10_": { "name": "كتل الإخراج.10." }, "output_blocks_11_": { "name": "كتل الإخراج.11." }, "output_blocks_1_": { "name": "كتل الإخراج.1." }, "output_blocks_2_": { "name": "كتل الإخراج.2." }, "output_blocks_3_": { "name": "كتل الإخراج.3." }, "output_blocks_4_": { "name": "كتل الإخراج.4." }, "output_blocks_5_": { "name": "كتل الإخراج.5." }, "output_blocks_6_": { "name": "كتل الإخراج.6." }, "output_blocks_7_": { "name": "كتل الإخراج.7." }, "output_blocks_8_": { "name": "كتل الإخراج.8." }, "output_blocks_9_": { "name": "كتل الإخراج.9." }, "time_embed_": { "name": "تضمين الوقت." } } };
const ModelMergeSD35_Large = { "display_name": "دمج النموذج SD35_كبير", "inputs": { "context_embedder_": { "name": "مُدمج السياق." }, "final_layer_": { "name": "الطبقة النهائية." }, "joint_blocks_0_": { "name": "كتل مشتركة.0." }, "joint_blocks_10_": { "name": "كتل مشتركة.10." }, "joint_blocks_11_": { "name": "كتل مشتركة.11." }, "joint_blocks_12_": { "name": "كتل مشتركة.12." }, "joint_blocks_13_": { "name": "كتل مشتركة.13." }, "joint_blocks_14_": { "name": "كتل مشتركة.14." }, "joint_blocks_15_": { "name": "كتل مشتركة.15." }, "joint_blocks_16_": { "name": "كتل مشتركة.16." }, "joint_blocks_17_": { "name": "كتل مشتركة.17." }, "joint_blocks_18_": { "name": "كتل مشتركة.18." }, "joint_blocks_19_": { "name": "كتل مشتركة.19." }, "joint_blocks_1_": { "name": "كتل مشتركة.1." }, "joint_blocks_20_": { "name": "كتل مشتركة.20." }, "joint_blocks_21_": { "name": "كتل مشتركة.21." }, "joint_blocks_22_": { "name": "كتل مشتركة.22." }, "joint_blocks_23_": { "name": "كتل مشتركة.23." }, "joint_blocks_24_": { "name": "كتل مشتركة.24." }, "joint_blocks_25_": { "name": "كتل مشتركة.25." }, "joint_blocks_26_": { "name": "كتل مشتركة.26." }, "joint_blocks_27_": { "name": "كتل مشتركة.27." }, "joint_blocks_28_": { "name": "كتل مشتركة.28." }, "joint_blocks_29_": { "name": "كتل مشتركة.29." }, "joint_blocks_2_": { "name": "كتل مشتركة.2." }, "joint_blocks_30_": { "name": "كتل مشتركة.30." }, "joint_blocks_31_": { "name": "كتل مشتركة.31." }, "joint_blocks_32_": { "name": "كتل مشتركة.32." }, "joint_blocks_33_": { "name": "كتل مشتركة.33." }, "joint_blocks_34_": { "name": "كتل مشتركة.34." }, "joint_blocks_35_": { "name": "كتل مشتركة.35." }, "joint_blocks_36_": { "name": "كتل مشتركة.36." }, "joint_blocks_37_": { "name": "كتل مشتركة.37." }, "joint_blocks_3_": { "name": "كتل مشتركة.3." }, "joint_blocks_4_": { "name": "كتل مشتركة.4." }, "joint_blocks_5_": { "name": "كتل مشتركة.5." }, "joint_blocks_6_": { "name": "كتل مشتركة.6." }, "joint_blocks_7_": { "name": "كتل مشتركة.7." }, "joint_blocks_8_": { "name": "كتل مشتركة.8." }, "joint_blocks_9_": { "name": "كتل مشتركة.9." }, "model1": { "name": "النموذج 1" }, "model2": { "name": "النموذج 2" }, "pos_embed_": { "name": "تضمين الموضع." }, "t_embedder_": { "name": "مُدمج T." }, "x_embedder_": { "name": "مُدمج X." }, "y_embedder_": { "name": "مُدمج Y." } } };
const ModelMergeSD3_2B = { "display_name": "دمج النموذج SD3_2B", "inputs": { "context_embedder_": { "name": "مُدمج السياق." }, "final_layer_": { "name": "الطبقة النهائية." }, "joint_blocks_0_": { "name": "كتل مشتركة.0." }, "joint_blocks_10_": { "name": "كتل مشتركة.10." }, "joint_blocks_11_": { "name": "كتل مشتركة.11." }, "joint_blocks_12_": { "name": "كتل مشتركة.12." }, "joint_blocks_13_": { "name": "كتل مشتركة.13." }, "joint_blocks_14_": { "name": "كتل مشتركة.14." }, "joint_blocks_15_": { "name": "كتل مشتركة.15." }, "joint_blocks_16_": { "name": "كتل مشتركة.16." }, "joint_blocks_17_": { "name": "كتل مشتركة.17." }, "joint_blocks_18_": { "name": "كتل مشتركة.18." }, "joint_blocks_19_": { "name": "كتل مشتركة.19." }, "joint_blocks_1_": { "name": "كتل مشتركة.1." }, "joint_blocks_20_": { "name": "كتل مشتركة.20." }, "joint_blocks_21_": { "name": "كتل مشتركة.21." }, "joint_blocks_22_": { "name": "كتل مشتركة.22." }, "joint_blocks_23_": { "name": "كتل مشتركة.23." }, "joint_blocks_2_": { "name": "كتل مشتركة.2." }, "joint_blocks_3_": { "name": "كتل مشتركة.3." }, "joint_blocks_4_": { "name": "كتل مشتركة.4." }, "joint_blocks_5_": { "name": "كتل مشتركة.5." }, "joint_blocks_6_": { "name": "كتل مشتركة.6." }, "joint_blocks_7_": { "name": "كتل مشتركة.7." }, "joint_blocks_8_": { "name": "كتل مشتركة.8." }, "joint_blocks_9_": { "name": "كتل مشتركة.9." }, "model1": { "name": "النموذج 1" }, "model2": { "name": "النموذج 2" }, "pos_embed_": { "name": "تضمين الموضع." }, "t_embedder_": { "name": "مُدمج T." }, "x_embedder_": { "name": "مُدمج X." }, "y_embedder_": { "name": "مُدمج Y." } } };
const ModelMergeSDXL = { "display_name": "دمج النموذج SDXL", "inputs": { "input_blocks_0": { "name": "كتل الإدخال.0" }, "input_blocks_1": { "name": "كتل الإدخال.1" }, "input_blocks_2": { "name": "كتل الإدخال.2" }, "input_blocks_3": { "name": "كتل الإدخال.3" }, "input_blocks_4": { "name": "كتل الإدخال.4" }, "input_blocks_5": { "name": "كتل الإدخال.5" }, "input_blocks_6": { "name": "كتل الإدخال.6" }, "input_blocks_7": { "name": "كتل الإدخال.7" }, "input_blocks_8": { "name": "كتل الإدخال.8" }, "label_emb_": { "name": "تضمين التسمية." }, "middle_block_0": { "name": "الكتلة الوسطى.0" }, "middle_block_1": { "name": "الكتلة الوسطى.1" }, "middle_block_2": { "name": "الكتلة الوسطى.2" }, "model1": { "name": "النموذج 1" }, "model2": { "name": "النموذج 2" }, "out_": { "name": "الخارج." }, "output_blocks_0": { "name": "كتل الإخراج.0" }, "output_blocks_1": { "name": "كتل الإخراج.1" }, "output_blocks_2": { "name": "كتل الإخراج.2" }, "output_blocks_3": { "name": "كتل الإخراج.3" }, "output_blocks_4": { "name": "كتل الإخراج.4" }, "output_blocks_5": { "name": "كتل الإخراج.5" }, "output_blocks_6": { "name": "كتل الإخراج.6" }, "output_blocks_7": { "name": "كتل الإخراج.7" }, "output_blocks_8": { "name": "كتل الإخراج.8" }, "time_embed_": { "name": "تضمين الوقت." } } };
const ModelMergeSimple = { "display_name": "دمج النموذج البسيط", "inputs": { "model1": { "name": "النموذج 1" }, "model2": { "name": "النموذج 2" }, "ratio": { "name": "النسبة" } } };
const ModelMergeSubtract = { "display_name": "طرح النموذج المدمج", "inputs": { "model1": { "name": "النموذج 1" }, "model2": { "name": "النموذج 2" }, "multiplier": { "name": "المضاعف" } } };
const ModelMergeWAN2_1 = { "description": "النموذج 1.3B يحتوي على 30 كتلة، النموذج 14B يحتوي على 40 كتلة. نموذج الصورة إلى الفيديو يحتوي على تضمين صورة إضافي.", "display_name": "دمج النموذج WAN2_1", "inputs": { "blocks_0_": { "name": "الكتل.0." }, "blocks_10_": { "name": "الكتل.10." }, "blocks_11_": { "name": "الكتل.11." }, "blocks_12_": { "name": "الكتل.12." }, "blocks_13_": { "name": "الكتل.13." }, "blocks_14_": { "name": "الكتل.14." }, "blocks_15_": { "name": "الكتل.15." }, "blocks_16_": { "name": "الكتل.16." }, "blocks_17_": { "name": "الكتل.17." }, "blocks_18_": { "name": "الكتل.18." }, "blocks_19_": { "name": "الكتل.19." }, "blocks_1_": { "name": "الكتل.1." }, "blocks_20_": { "name": "الكتل.20." }, "blocks_21_": { "name": "الكتل.21." }, "blocks_22_": { "name": "الكتل.22." }, "blocks_23_": { "name": "الكتل.23." }, "blocks_24_": { "name": "الكتل.24." }, "blocks_25_": { "name": "الكتل.25." }, "blocks_26_": { "name": "الكتل.26." }, "blocks_27_": { "name": "الكتل.27." }, "blocks_28_": { "name": "الكتل.28." }, "blocks_29_": { "name": "الكتل.29." }, "blocks_2_": { "name": "الكتل.2." }, "blocks_30_": { "name": "الكتل.30." }, "blocks_31_": { "name": "الكتل.31." }, "blocks_32_": { "name": "الكتل.32." }, "blocks_33_": { "name": "الكتل.33." }, "blocks_34_": { "name": "الكتل.34." }, "blocks_35_": { "name": "الكتل.35." }, "blocks_36_": { "name": "الكتل.36." }, "blocks_37_": { "name": "الكتل.37." }, "blocks_38_": { "name": "الكتل.38." }, "blocks_39_": { "name": "الكتل.39." }, "blocks_3_": { "name": "الكتل.3." }, "blocks_4_": { "name": "الكتل.4." }, "blocks_5_": { "name": "الكتل.5." }, "blocks_6_": { "name": "الكتل.6." }, "blocks_7_": { "name": "الكتل.7." }, "blocks_8_": { "name": "الكتل.8." }, "blocks_9_": { "name": "الكتل.9." }, "head_": { "name": "الرأس." }, "img_emb_": { "name": "تضمين الصورة." }, "model1": { "name": "النموذج 1" }, "model2": { "name": "النموذج 2" }, "patch_embedding_": { "name": "تضمين الرقعة." }, "text_embedding_": { "name": "تضمين النص." }, "time_embedding_": { "name": "تضمين الوقت." }, "time_projection_": { "name": "إسقاط الوقت." } } };
const ModelPatchLoader = { "display_name": "ModelPatchLoader", "inputs": { "name": { "name": "الاسم" } } };
const ModelSamplingAuraFlow = { "display_name": "تدفق عينات النموذج AuraFlow", "inputs": { "model": { "name": "النموذج" }, "shift": { "name": "الإزاحة" } } };
const ModelSamplingContinuousEDM = { "display_name": "تدفق عينات النموذج EDM المستمر", "inputs": { "model": { "name": "النموذج" }, "sampling": { "name": "العينة" }, "sigma_max": { "name": "سيغما القصوى" }, "sigma_min": { "name": "سيغما الدنيا" } } };
const ModelSamplingContinuousV = { "display_name": "تدفق عينات النموذج V المستمر", "inputs": { "model": { "name": "النموذج" }, "sampling": { "name": "العينة" }, "sigma_max": { "name": "سيغما القصوى" }, "sigma_min": { "name": "سيغما الدنيا" } } };
const ModelSamplingDiscrete = { "display_name": "تدفق عينات النموذج المتقطع", "inputs": { "model": { "name": "النموذج" }, "sampling": { "name": "العينة" }, "zsnr": { "name": "zsnr" } } };
const ModelSamplingFlux = { "display_name": "تدفق عينات النموذج Flux", "inputs": { "base_shift": { "name": "الإزاحة الأساسية" }, "height": { "name": "الارتفاع" }, "max_shift": { "name": "أقصى إزاحة" }, "model": { "name": "النموذج" }, "width": { "name": "العرض" } } };
const ModelSamplingLTXV = { "display_name": "تدفق عينات النموذج LTXV", "inputs": { "base_shift": { "name": "الإزاحة الأساسية" }, "latent": { "name": "الكامن" }, "max_shift": { "name": "أقصى إزاحة" }, "model": { "name": "النموذج" } }, "outputs": { "0": { "tooltip": null } } };
const ModelSamplingSD3 = { "display_name": "تدفق عينات النموذج SD3", "inputs": { "model": { "name": "النموذج" }, "shift": { "name": "الإزاحة" } } };
const ModelSamplingStableCascade = { "display_name": "تدفق عينات النموذج StableCascade", "inputs": { "model": { "name": "النموذج" }, "shift": { "name": "الإزاحة" } } };
const ModelSave = { "display_name": "حفظ النموذج", "inputs": { "filename_prefix": { "name": "بادئة اسم الملف" }, "model": { "name": "النموذج" } } };
const MoonvalleyImg2VideoNode = { "description": "عقدة Moonvalley Marey صورة إلى فيديو", "display_name": "Moonvalley Marey صورة إلى فيديو", "inputs": { "control_after_generate": { "name": "التحكم بعد التوليد" }, "image": { "name": "الصورة", "tooltip": "الصورة المرجعية المستخدمة لتوليد الفيديو" }, "negative_prompt": { "name": "النص التوجيهي السلبي", "tooltip": "نص التوجيه السلبي" }, "prompt": { "name": "النص التوجيهي" }, "prompt_adherence": { "name": "الالتزام بالنص التوجيهي", "tooltip": "مقياس التوجيه للتحكم في التوليد" }, "resolution": { "name": "الدقة", "tooltip": "دقة الفيديو الناتج" }, "seed": { "name": "البذرة", "tooltip": "قيمة البذرة العشوائية" }, "steps": { "name": "الخطوات", "tooltip": "عدد خطوات إزالة الضوضاء" } }, "outputs": { "0": { "tooltip": null } } };
const MoonvalleyTxt2VideoNode = { "display_name": "Moonvalley Marey نص إلى فيديو", "inputs": { "control_after_generate": { "name": "التحكم بعد التوليد" }, "negative_prompt": { "name": "النص التوجيهي السلبي", "tooltip": "نص التوجيه السلبي" }, "prompt": { "name": "النص التوجيهي" }, "prompt_adherence": { "name": "الالتزام بالنص التوجيهي", "tooltip": "مقياس التوجيه للتحكم في التوليد" }, "resolution": { "name": "الدقة", "tooltip": "دقة الفيديو الناتج" }, "seed": { "name": "البذرة", "tooltip": "قيمة البذرة العشوائية" }, "steps": { "name": "الخطوات", "tooltip": "خطوات الاستدلال" } }, "outputs": { "0": { "tooltip": null } } };
const MoonvalleyVideo2VideoNode = { "display_name": "Moonvalley Marey من فيديو إلى فيديو", "inputs": { "control_type": { "name": "نوع التحكم" }, "motion_intensity": { "name": "شدة الحركة", "tooltip": "يستخدم فقط إذا كان نوع التحكم هو 'نقل الحركة'" }, "negative_prompt": { "name": "النص التوجيهي السلبي", "tooltip": "نص النص التوجيهي السلبي" }, "prompt": { "name": "النص التوجيهي", "tooltip": "يصف الفيديو المراد توليده" }, "seed": { "name": "البذرة", "tooltip": "قيمة البذرة العشوائية" }, "steps": { "name": "الخطوات", "tooltip": "عدد خطوات الاستدلال" }, "video": { "name": "الفيديو", "tooltip": "الفيديو المرجعي المستخدم لتوليد الفيديو الناتج. يجب أن يكون طوله 5 ثوانٍ على الأقل. سيتم اقتصاص مقاطع الفيديو الأطول من 5 ثوانٍ تلقائيًا. يدعم فقط تنسيق MP4." } }, "outputs": { "0": { "tooltip": null } } };
const Morphology = { "display_name": "مورفولوجيا الصورة", "inputs": { "image": { "name": "الصورة" }, "kernel_size": { "name": "حجم النواة" }, "operation": { "name": "العملية" } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIChatConfig = { "description": "يسمح بتحديد خيارات التكوين المتقدمة لعقد الدردشة الخاصة بـ OpenAI.", "display_name": "خيارات OpenAI ChatGPT المتقدمة", "inputs": { "instructions": { "name": "التعليمات", "tooltip": "تعليمات للنموذج حول كيفية توليد الاستجابة" }, "max_output_tokens": { "name": "الرموز المخرجة القصوى", "tooltip": "حد أعلى لعدد الرموز التي يمكن توليدها للاستجابة، بما في ذلك الرموز المخرجة المرئية" }, "truncation": { "name": "الاقتصاص", "tooltip": "استراتيجية الاقتصاص المستخدمة لاستجابة النموذج. تلقائي: إذا تجاوز سياق هذه الاستجابة والاستجابات السابقة حجم نافذة سياق النموذج، فسيقوم النموذج باقتصاص الاستجابة لتناسب نافذة السياق عن طريق إسقاط عناصر الإدخال في منتصف المحادثة. معطل: إذا كانت استجابة النموذج ستتجاوز حجم نافذة السياق للنموذج، فسيفشل الطلب مع خطأ 400" } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIChatNode = { "description": "إنشاء ردود نصية من نموذج OpenAI.", "display_name": "OpenAI ChatGPT", "inputs": { "advanced_options": { "name": "advanced_options", "tooltip": "إعدادات اختيارية للنموذج. تقبل مدخلات من عقدة OpenAI Chat Advanced Options." }, "files": { "name": "files", "tooltip": "ملف/ملفات اختيارية لاستخدامها كسياق للنموذج. تقبل مدخلات من عقدة OpenAI Chat Input Files." }, "images": { "name": "images", "tooltip": "صورة/صور اختيارية لاستخدامها كسياق للنموذج. لتضمين صور متعددة، يمكنك استخدام عقدة Batch Images." }, "model": { "name": "model", "tooltip": "النموذج المستخدم لإنشاء الرد" }, "persist_context": { "name": "persist_context", "tooltip": "هذه المعلمة قديمة ولم تعد فعالة." }, "prompt": { "name": "prompt", "tooltip": "مدخلات نصية للنموذج، تُستخدم لإنشاء رد." } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIDalle2 = { "description": "ينشئ صورًا بشكل متزامن عبر نقطة نهاية DALL·E 2 من OpenAI.", "display_name": "OpenAI DALL·E 2", "inputs": { "control_after_generate": { "name": "التحكم بعد الإنشاء" }, "image": { "name": "الصورة", "tooltip": "صورة مرجعية اختيارية لتحرير الصور." }, "mask": { "name": "القناع", "tooltip": "قناع اختياري للرسم الداخلي (سيتم استبدال المناطق البيضاء)" }, "n": { "name": "عدد الصور", "tooltip": "كم عدد الصور التي يتم إنشاؤها" }, "prompt": { "name": "النص الوصفي", "tooltip": "النص الوصفي لـ DALL·E" }, "seed": { "name": "البذرة", "tooltip": "لم يتم تنفيذه بعد في الخلفية" }, "size": { "name": "الحجم", "tooltip": "حجم الصورة" } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIDalle3 = { "description": "ينشئ صورًا بشكل متزامن عبر نقطة نهاية DALL·E 3 من OpenAI.", "display_name": "OpenAI DALL·E 3", "inputs": { "control_after_generate": { "name": "التحكم بعد الإنشاء" }, "prompt": { "name": "النص الوصفي", "tooltip": "النص الوصفي لـ DALL·E" }, "quality": { "name": "الجودة", "tooltip": "جودة الصورة" }, "seed": { "name": "البذرة", "tooltip": "لم يتم تنفيذه بعد في الخلفية" }, "size": { "name": "الحجم", "tooltip": "حجم الصورة" }, "style": { "name": "الأسلوب", "tooltip": "النمط 'Vivid' يجعل النموذج يميل لإنشاء صور فائقة الواقعية ودرامية. النمط 'Natural' يجعل النموذج ينتج صورًا أكثر طبيعية وأقل واقعية بشكل مبالغ." } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIGPTImage1 = { "description": "ينشئ صورًا بشكل متزامن عبر نقطة نهاية GPT Image 1 من OpenAI.", "display_name": "OpenAI GPT صورة 1", "inputs": { "background": { "name": "الخلفية", "tooltip": "إرجاع الصورة مع أو بدون خلفية" }, "control_after_generate": { "name": "التحكم بعد الإنشاء" }, "image": { "name": "الصورة", "tooltip": "صورة مرجعية اختيارية لتحرير الصور." }, "mask": { "name": "القناع", "tooltip": "قناع اختياري للرسم الداخلي (سيتم استبدال المناطق البيضاء)" }, "n": { "name": "عدد الصور", "tooltip": "كم عدد الصور التي يتم إنشاؤها" }, "prompt": { "name": "النص الوصفي", "tooltip": "النص الوصفي لـ GPT Image 1" }, "quality": { "name": "الجودة", "tooltip": "جودة الصورة، تؤثر على التكلفة ووقت الإنشاء." }, "seed": { "name": "البذرة", "tooltip": "لم يتم تنفيذه بعد في الخلفية" }, "size": { "name": "الحجم", "tooltip": "حجم الصورة" } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIInputFiles = { "description": "يقوم بتحميل وإعداد ملفات الإدخال (نص، pdf، إلخ) لتضمينها كمدخلات لعقدة OpenAI Chat. سيتم قراءة الملفات بواسطة نموذج OpenAI عند إنشاء الرد. 🛈 تلميح: يمكن ربطها مع عقد OpenAI Input File الأخرى.", "display_name": "OpenAI ChatGPT Input Files", "inputs": { "OPENAI_INPUT_FILES": { "name": "OPENAI_INPUT_FILES", "tooltip": "ملف/ملفات إضافية اختيارية لدمجها مع الملف المحمل من هذه العقدة. يسمح بربط ملفات الإدخال بحيث يمكن أن تتضمن رسالة واحدة ملفات إدخال متعددة." }, "file": { "name": "file", "tooltip": "ملفات الإدخال لتضمينها كسياق للنموذج. تقبل حاليًا فقط ملفات النص (.txt) وPDF (.pdf)." } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIVideoSora2 = { "description": "إنشاء فيديو وصوت من OpenAI.", "display_name": "OpenAI Sora - Video", "inputs": { "control_after_generate": { "name": "التحكم بعد التوليد" }, "duration": { "name": "duration" }, "image": { "name": "image" }, "model": { "name": "model" }, "prompt": { "name": "prompt", "tooltip": "نص توجيهي؛ قد يكون فارغًا إذا كانت هناك صورة إدخال موجودة." }, "seed": { "name": "seed", "tooltip": "بذرة لتحديد ما إذا كانت العقدة يجب أن تعيد التشغيل؛ النتائج الفعلية غير حتمية بغض النظر عن البذرة." }, "size": { "name": "size" } }, "outputs": { "0": { "tooltip": null } } };
const OptimalStepsScheduler = { "display_name": "مجدول الخطوات الأمثل", "inputs": { "denoise": { "name": "إزالة الضجيج" }, "model_type": { "name": "نوع النموذج" }, "steps": { "name": "عدد الخطوات" } }, "outputs": { "0": { "tooltip": null } } };
const PairConditioningCombine = { "display_name": "دمج زوج الشرط", "inputs": { "negative_A": { "name": "سلبي A" }, "negative_B": { "name": "سلبي B" }, "positive_A": { "name": "إيجابي A" }, "positive_B": { "name": "إيجابي B" } }, "outputs": { "0": { "name": "إيجابي" }, "1": { "name": "سلبي" } } };
const PairConditioningSetDefaultCombine = { "display_name": "تعيين الدمج الافتراضي لزوج الشرط", "inputs": { "hooks": { "name": "خطافات" }, "negative": { "name": "سلبي" }, "negative_DEFAULT": { "name": "سلبي افتراضي" }, "positive": { "name": "إيجابي" }, "positive_DEFAULT": { "name": "إيجابي افتراضي" } }, "outputs": { "0": { "name": "إيجابي" }, "1": { "name": "سلبي" } } };
const PairConditioningSetProperties = { "display_name": "تعيين خصائص زوج الشرط", "inputs": { "hooks": { "name": "خطافات" }, "mask": { "name": "القناع" }, "negative_NEW": { "name": "سلبي جديد" }, "positive_NEW": { "name": "إيجابي جديد" }, "set_cond_area": { "name": "تعيين منطقة الشرط" }, "strength": { "name": "القوة" }, "timesteps": { "name": "خطوات الزمن" } }, "outputs": { "0": { "name": "إيجابي" }, "1": { "name": "سلبي" } } };
const PairConditioningSetPropertiesAndCombine = { "display_name": "تعيين ودمج خصائص زوج الشرط", "inputs": { "hooks": { "name": "خطافات" }, "mask": { "name": "القناع" }, "negative": { "name": "سلبي" }, "negative_NEW": { "name": "سلبي جديد" }, "positive": { "name": "إيجابي" }, "positive_NEW": { "name": "إيجابي جديد" }, "set_cond_area": { "name": "تعيين منطقة الشرط" }, "strength": { "name": "القوة" }, "timesteps": { "name": "خطوات الزمن" } }, "outputs": { "0": { "name": "إيجابي" }, "1": { "name": "سلبي" } } };
const PatchModelAddDownscale = { "display_name": "إضافة تقليل الحجم للنموذج (Kohya Deep Shrink)", "inputs": { "block_number": { "name": "رقم الكتلة" }, "downscale_after_skip": { "name": "التصغير بعد التخطي" }, "downscale_factor": { "name": "عامل التصغير" }, "downscale_method": { "name": "طريقة التصغير" }, "end_percent": { "name": "نسبة النهاية" }, "model": { "name": "النموذج" }, "start_percent": { "name": "نسبة البداية" }, "upscale_method": { "name": "طريقة التكبير" } }, "outputs": { "0": { "tooltip": null } } };
const PerpNeg = { "display_name": "Perp-Neg (تم إهماله بواسطة PerpNegGuider)", "inputs": { "empty_conditioning": { "name": "تهيئة فارغة" }, "model": { "name": "النموذج" }, "neg_scale": { "name": "مقياس سلبي" } }, "outputs": { "0": { "tooltip": null } } };
const PerpNegGuider = { "display_name": "PerpNegGuider", "inputs": { "cfg": { "name": "إعدادات CFG" }, "empty_conditioning": { "name": "تهيئة فارغة" }, "model": { "name": "النموذج" }, "neg_scale": { "name": "مقياس سلبي" }, "negative": { "name": "سلبي" }, "positive": { "name": "إيجابي" } }, "outputs": { "0": { "tooltip": null } } };
const PerturbedAttentionGuidance = { "display_name": "توجيه الانتباه المتغير", "inputs": { "model": { "name": "النموذج" }, "scale": { "name": "المقياس" } }, "outputs": { "0": { "tooltip": null } } };
const PhotoMakerEncode = { "display_name": "ترميز صانع الصور", "inputs": { "clip": { "name": "مقطع" }, "image": { "name": "الصورة" }, "photomaker": { "name": "صانع الصور" }, "text": { "name": "النص" } }, "outputs": { "0": { "tooltip": null } } };
const PhotoMakerLoader = { "display_name": "محمل صانع الصور", "inputs": { "photomaker_model_name": { "name": "اسم نموذج صانع الصور" } }, "outputs": { "0": { "tooltip": null } } };
const PixverseImageToVideoNode = { "description": "ينتج فيديوهات بشكل متزامن بناءً على النص المطلوب وحجم المخرج.", "display_name": "بيكسفيرس صورة إلى فيديو", "inputs": { "control_after_generate": { "name": "التحكم بعد التوليد" }, "duration_seconds": { "name": "مدة الثواني" }, "image": { "name": "الصورة" }, "motion_mode": { "name": "وضع الحركة" }, "negative_prompt": { "name": "نص المطالبة السلبية", "tooltip": "وصف نصي اختياري للعناصر غير المرغوبة في الصورة." }, "pixverse_template": { "name": "قالب بيكسفيرس", "tooltip": "قالب اختياري للتأثير على نمط التوليد، يتم إنشاؤه بواسطة عقدة قالب بيكسفيرس." }, "prompt": { "name": "النص المطلوب", "tooltip": "النص المطلوب لتوليد الفيديو" }, "quality": { "name": "الجودة" }, "seed": { "name": "البذرة", "tooltip": "البذرة لتوليد الفيديو." } }, "outputs": { "0": { "tooltip": null } } };
const PixverseTemplateNode = { "display_name": "قالب بيكسفيرس", "inputs": { "template": { "name": "القالب" } }, "outputs": { "0": { "name": "قالب بيكسفيرس", "tooltip": null } } };
const PixverseTextToVideoNode = { "description": "ينتج فيديوهات بشكل متزامن بناءً على النص المطلوب وحجم المخرج.", "display_name": "بيكسفيرس نص إلى فيديو", "inputs": { "aspect_ratio": { "name": "نسبة العرض إلى الارتفاع" }, "control_after_generate": { "name": "التحكم بعد التوليد" }, "duration_seconds": { "name": "مدة الثواني" }, "motion_mode": { "name": "وضع الحركة" }, "negative_prompt": { "name": "نص المطالبة السلبية", "tooltip": "وصف نصي اختياري للعناصر غير المرغوبة في الصورة." }, "pixverse_template": { "name": "قالب بيكسفيرس", "tooltip": "قالب اختياري للتأثير على نمط التوليد، يتم إنشاؤه بواسطة عقدة قالب بيكسفيرس." }, "prompt": { "name": "النص المطلوب", "tooltip": "النص المطلوب لتوليد الفيديو" }, "quality": { "name": "الجودة" }, "seed": { "name": "البذرة", "tooltip": "البذرة لتوليد الفيديو." } }, "outputs": { "0": { "tooltip": null } } };
const PixverseTransitionVideoNode = { "description": "ينتج فيديوهات بشكل متزامن بناءً على النص المطلوب وحجم المخرج.", "display_name": "بيكسفيرس فيديو الانتقال", "inputs": { "control_after_generate": { "name": "التحكم بعد التوليد" }, "duration_seconds": { "name": "مدة الثواني" }, "first_frame": { "name": "الإطار الأول" }, "last_frame": { "name": "الإطار الأخير" }, "motion_mode": { "name": "وضع الحركة" }, "negative_prompt": { "name": "نص المطالبة السلبية", "tooltip": "وصف نصي اختياري للعناصر غير المرغوبة في الصورة." }, "prompt": { "name": "النص المطلوب", "tooltip": "النص المطلوب لتوليد الفيديو" }, "quality": { "name": "الجودة" }, "seed": { "name": "البذرة", "tooltip": "البذرة لتوليد الفيديو." } }, "outputs": { "0": { "tooltip": null } } };
const PolyexponentialScheduler = { "display_name": "جدولة متعددة الأسية", "inputs": { "rho": { "name": "رو" }, "sigma_max": { "name": "سيغما ماكس" }, "sigma_min": { "name": "سيغما مين" }, "steps": { "name": "الخطوات" } } };
const PorterDuffImageComposite = { "display_name": "تركيب صورة بورتر-داف", "inputs": { "destination": { "name": "الوجهة" }, "destination_alpha": { "name": "ألفا الوجهة" }, "mode": { "name": "الوضع" }, "source": { "name": "المصدر" }, "source_alpha": { "name": "ألفا المصدر" } }, "outputs": { "0": { "tooltip": null }, "1": { "tooltip": null } } };
const Preview3D = { "display_name": "معاينة ثلاثية الأبعاد", "inputs": { "camera_info": { "name": "معلومات الكاميرا" }, "image": { "name": "الصورة" }, "model_file": { "name": "ملف النموذج" } } };
const PreviewAny = { "display_name": "معاينة أي", "inputs": { "preview": {}, "source": { "name": "المصدر" } } };
const PreviewAudio = { "display_name": "معاينة الصوت", "inputs": { "audio": { "name": "الصوت" }, "audioUI": { "name": "واجهة المستخدم للصوت" } } };
const PreviewImage = { "description": "يحفظ الصور المدخلة في دليل مخرجات ComfyUI الخاص بك.", "display_name": "معاينة الصورة", "inputs": { "images": { "name": "الصور" } } };
const PrimitiveBoolean = { "display_name": "منطقي", "inputs": { "value": { "name": "القيمة" } }, "outputs": { "0": { "tooltip": null } } };
const PrimitiveFloat = { "display_name": "عائم", "inputs": { "value": { "name": "القيمة" } }, "outputs": { "0": { "tooltip": null } } };
const PrimitiveInt = { "display_name": "عدد صحيح", "inputs": { "control_after_generate": { "name": "التحكم بعد التوليد" }, "value": { "name": "القيمة" } }, "outputs": { "0": { "tooltip": null } } };
const PrimitiveString = { "display_name": "نص", "inputs": { "value": { "name": "القيمة" } }, "outputs": { "0": { "tooltip": null } } };
const PrimitiveStringMultiline = { "display_name": "نص (متعدد الأسطر)", "inputs": { "value": { "name": "القيمة" } }, "outputs": { "0": { "tooltip": null } } };
const QuadrupleCLIPLoader = { "description": "[وصفات]\n\nhidream: long clip-l, long clip-g, t5xxl, llama_8b_3.1_instruct", "display_name": "محمل CLIP رباعي", "inputs": { "clip_name1": { "name": "اسم الكليب 1" }, "clip_name2": { "name": "اسم الكليب 2" }, "clip_name3": { "name": "اسم الكليب 3" }, "clip_name4": { "name": "اسم الكليب 4" } }, "outputs": { "0": { "tooltip": null } } };
const QwenImageDiffsynthControlnet = { "display_name": "QwenImageDiffsynthControlnet", "inputs": { "image": { "name": "الصورة" }, "mask": { "name": "القناع" }, "model": { "name": "النموذج" }, "model_patch": { "name": "تصحيح النموذج" }, "strength": { "name": "القوة" }, "vae": { "name": "vae" } } };
const RandomNoise = { "display_name": "ضجيج عشوائية", "inputs": { "control_after_generate": { "name": "التحكم بعد التوليد" }, "noise_seed": { "name": "بذرة الضجيج" } } };
const RebatchImages = { "display_name": "إعادة تجميع الصور", "inputs": { "batch_size": { "name": "حجم الدفعة" }, "images": { "name": "الصور" } }, "outputs": { "0": { "tooltip": null } } };
const RebatchLatents = { "display_name": "إعادة تجميع المتغيرات الكامنة", "inputs": { "batch_size": { "name": "حجم الدفعة" }, "latents": { "name": "المتغيرات الكامنة" } }, "outputs": { "0": { "tooltip": null } } };
const RecordAudio = { "display_name": "تسجيل الصوت", "inputs": { "audio": { "name": "الصوت" } } };
const RecraftColorRGB = { "description": "إنشاء لون Recraft باختيار قيم RGB محددة.", "display_name": "إعادة صياغة لون RGB", "inputs": { "b": { "name": "الأزرق", "tooltip": "قيمة اللون الأزرق." }, "g": { "name": "الأخضر", "tooltip": "قيمة اللون الأخضر." }, "r": { "name": "الأحمر", "tooltip": "قيمة اللون الأحمر." }, "recraft_color": { "name": "لون إعادة الصياغة" } }, "outputs": { "0": { "name": "لون إعادة الصياغة", "tooltip": null } } };
const RecraftControls = { "description": "إنشاء عناصر تحكم Recraft لتخصيص توليد Recraft.", "display_name": "عناصر تحكم إعادة الصياغة", "inputs": { "background_color": { "name": "لون الخلفية" }, "colors": { "name": "الألوان" } }, "outputs": { "0": { "name": "عناصر تحكم إعادة الصياغة", "tooltip": null } } };
const RecraftCreativeUpscaleNode = { "description": "تكبير الصورة بشكل متزامن.\nيعزز صورة نقطية معينة باستخدام أداة 'التكبير الإبداعي'، مع التركيز على تحسين التفاصيل الصغيرة والوجوه.", "display_name": "تكبير إبداعي لإعادة الصياغة", "inputs": { "image": { "name": "الصورة" } }, "outputs": { "0": { "tooltip": null } } };
const RecraftCrispUpscaleNode = { "description": "تكبير الصورة بشكل متزامن.\nيعزز صورة نقطية معينة باستخدام أداة 'تكبير الوضوح'، مما يزيد دقة الصورة ويجعلها أكثر حدة ونقاء.", "display_name": "إعادة صياغة صورة عالية الوضوح", "inputs": { "image": { "name": "صورة" } }, "outputs": { "0": { "tooltip": null } } };
const RecraftImageInpaintingNode = { "description": "تعديل الصورة بناءً على الوصف والقناع.", "display_name": "إعادة صياغة ترميم الصورة", "inputs": { "control_after_generate": { "name": "التحكم بعد الإنشاء" }, "image": { "name": "صورة" }, "mask": { "name": "قناع" }, "n": { "name": "عدد", "tooltip": "عدد الصور المراد إنشاؤها." }, "negative_prompt": { "name": "الوصف السلبي", "tooltip": "وصف نصي اختياري للعناصر غير المرغوبة في الصورة." }, "prompt": { "name": "الوصف", "tooltip": "الوصف المستخدم لإنشاء الصورة." }, "recraft_style": { "name": "نمط إعادة الصياغة" }, "seed": { "name": "بذرة", "tooltip": "بذرة لتحديد ما إذا كان يجب إعادة تشغيل العقدة؛ النتائج الفعلية غير حتمية بغض النظر عن البذرة." } }, "outputs": { "0": { "tooltip": null } } };
const RecraftImageToImageNode = { "description": "تعديل الصورة بناءً على الوصف والقوة.", "display_name": "إعادة صياغة صورة إلى صورة", "inputs": { "control_after_generate": { "name": "التحكم بعد الإنشاء" }, "image": { "name": "صورة" }, "n": { "name": "عدد", "tooltip": "عدد الصور المراد إنشاؤها." }, "negative_prompt": { "name": "الوصف السلبي", "tooltip": "وصف نصي اختياري للعناصر غير المرغوبة في الصورة." }, "prompt": { "name": "الوصف", "tooltip": "الوصف المستخدم لإنشاء الصورة." }, "recraft_controls": { "name": "عناصر تحكم إعادة الصياغة", "tooltip": "عناصر تحكم إضافية اختيارية عبر عقدة عناصر تحكم إعادة الصياغة." }, "recraft_style": { "name": "نمط إعادة الصياغة" }, "seed": { "name": "بذرة", "tooltip": "بذرة لتحديد ما إذا كان يجب إعادة تشغيل العقدة؛ النتائج الفعلية غير حتمية بغض النظر عن البذرة." }, "strength": { "name": "القوة", "tooltip": "تعريف الاختلاف عن الصورة الأصلية، يجب أن يكون في النطاق [0, 1]، حيث 0 يعني شبه مطابق، و1 يعني اختلاف كبير." } }, "outputs": { "0": { "tooltip": null } } };
const RecraftRemoveBackgroundNode = { "description": "إزالة الخلفية من الصورة، وإرجاع الصورة المعالجة والقناع.", "display_name": "إعادة صياغة إزالة الخلفية", "inputs": { "image": { "name": "صورة" } }, "outputs": { "0": { "tooltip": null }, "1": { "tooltip": null } } };
const RecraftReplaceBackgroundNode = { "description": "استبدال الخلفية في الصورة بناءً على الوصف المقدم.", "display_name": "إعادة صياغة استبدال الخلفية", "inputs": { "control_after_generate": { "name": "التحكم بعد الإنشاء" }, "image": { "name": "صورة" }, "n": { "name": "عدد", "tooltip": "عدد الصور المراد إنشاؤها." }, "negative_prompt": { "name": "الوصف السلبي", "tooltip": "وصف نصي اختياري للعناصر غير المرغوبة في الصورة." }, "prompt": { "name": "الوصف", "tooltip": "الوصف المستخدم لإنشاء الصورة." }, "recraft_style": { "name": "نمط إعادة الصياغة" }, "seed": { "name": "بذرة", "tooltip": "بذرة لتحديد ما إذا كان يجب إعادة تشغيل العقدة؛ النتائج الفعلية غير حتمية بغض النظر عن البذرة." } }, "outputs": { "0": { "tooltip": null } } };
const RecraftStyleV3DigitalIllustration = { "description": "اختر نمط الصورة الواقعية والنمط الفرعي الاختياري.", "display_name": "نمط إعادة الصياغة - الرسم الرقمي", "inputs": { "substyle": { "name": "النمط الفرعي" } }, "outputs": { "0": { "name": "نمط إعادة الصياغة", "tooltip": null } } };
const RecraftStyleV3InfiniteStyleLibrary = { "description": "اختر نمطاً بناءً على UUID موجود مسبقًا من مكتبة أنماط إعادة الصياغة اللانهائية.", "display_name": "نمط إعادة الصياغة - مكتبة الأنماط اللانهائية", "inputs": { "style_id": { "name": "معرف النمط", "tooltip": "UUID للنمط من مكتبة الأنماط اللانهائية." } }, "outputs": { "0": { "name": "نمط إعادة الصياغة", "tooltip": null } } };
const RecraftStyleV3LogoRaster = { "description": "اختر نمط الصورة الواقعية والنمط الفرعي الاختياري.", "display_name": "نمط إعادة الصياغة - شعار نقطي", "inputs": { "substyle": { "name": "النمط الفرعي" } }, "outputs": { "0": { "name": "نمط إعادة الصياغة", "tooltip": null } } };
const RecraftStyleV3RealisticImage = { "description": "اختر نمط الصورة الواقعية والنمط الفرعي الاختياري.", "display_name": "نمط إعادة الصياغة - صورة واقعية", "inputs": { "substyle": { "name": "النمط الفرعي" } }, "outputs": { "0": { "name": "نمط إعادة الصياغة", "tooltip": null } } };
const RecraftTextToImageNode = { "description": "ينشئ صورًا بشكل متزامن بناءً على الوصف والدقة.", "display_name": "إعادة صياغة نص إلى صورة", "inputs": { "control_after_generate": { "name": "التحكم بعد الإنشاء" }, "n": { "name": "عدد", "tooltip": "عدد الصور المراد إنشاؤها." }, "negative_prompt": { "name": "الوصف السلبي", "tooltip": "وصف نصي اختياري للعناصر غير المرغوبة في الصورة." }, "prompt": { "name": "الوصف", "tooltip": "الوصف المستخدم لإنشاء الصورة." }, "recraft_controls": { "name": "عناصر تحكم إعادة الصياغة", "tooltip": "عناصر تحكم إضافية اختيارية عبر عقدة عناصر تحكم إعادة الصياغة." }, "recraft_style": { "name": "نمط إعادة الصياغة" }, "seed": { "name": "بذرة", "tooltip": "بذرة لتحديد ما إذا كان يجب إعادة تشغيل العقدة؛ النتائج الفعلية غير حتمية بغض النظر عن البذرة." }, "size": { "name": "الحجم", "tooltip": "حجم الصورة المُنشأة." } }, "outputs": { "0": { "tooltip": null } } };
const RecraftTextToVectorNode = { "description": "ينشئ SVG بشكل متزامن بناءً على الوصف والدقة.", "display_name": "إعادة صياغة نص إلى متجه", "inputs": { "control_after_generate": { "name": "التحكم بعد الإنشاء" }, "n": { "name": "عدد", "tooltip": "عدد الصور المراد إنشاؤها." }, "negative_prompt": { "name": "الوصف السلبي", "tooltip": "وصف نصي اختياري للعناصر غير المرغوبة في الصورة." }, "prompt": { "name": "الوصف", "tooltip": "الوصف المستخدم لإنشاء الصورة." }, "recraft_controls": { "name": "عناصر تحكم إعادة الصياغة", "tooltip": "عناصر تحكم إضافية اختيارية عبر عقدة عناصر تحكم إعادة الصياغة." }, "seed": { "name": "بذرة", "tooltip": "بذرة لتحديد ما إذا كان يجب إعادة تشغيل العقدة؛ النتائج الفعلية غير حتمية بغض النظر عن البذرة." }, "size": { "name": "الحجم", "tooltip": "حجم الصورة المُنشأة." }, "substyle": { "name": "النمط الفرعي" } }, "outputs": { "0": { "tooltip": null } } };
const RecraftVectorizeImageNode = { "description": "ينشئ SVG بشكل متزامن من صورة إدخال.", "display_name": "إعادة صياغة تحويل الصورة إلى متجه", "inputs": { "image": { "name": "صورة" } }, "outputs": { "0": { "tooltip": null } } };
const ReferenceLatent = { "description": "تعيّن هذه العقدة المرجع الكامن الموجه لنموذج التعديل. إذا كان النموذج يدعم ذلك، يمكنك ربط عدة مراجع لتعيين عدة صور مرجعية.", "display_name": "المرجع الكامن", "inputs": { "conditioning": { "name": "التكييف" }, "latent": { "name": "كامن" } }, "outputs": { "0": { "tooltip": null } } };
const RegexExtract = { "display_name": "استخراج التعبير النمطي", "inputs": { "case_insensitive": { "name": "غير حساس لحالة الأحرف" }, "dotall": { "name": "dotall" }, "group_index": { "name": "مؤشر المجموعة" }, "mode": { "name": "الوضع" }, "multiline": { "name": "متعدد الأسطر" }, "regex_pattern": { "name": "نمط التعبير النمطي" }, "string": { "name": "السلسلة النصية" } }, "outputs": { "0": { "tooltip": null } } };
const RegexMatch = { "display_name": "مطابقة التعبير النمطي", "inputs": { "case_insensitive": { "name": "غير حساس لحالة الأحرف" }, "dotall": { "name": "dotall" }, "multiline": { "name": "متعدد الأسطر" }, "regex_pattern": { "name": "نمط التعبير النمطي" }, "string": { "name": "السلسلة النصية" } }, "outputs": { "0": { "name": "مطابقات", "tooltip": null } } };
const RegexReplace = { "description": "ابحث واستبدل النص باستخدام أنماط التعبيرات النمطية.", "display_name": "استبدال التعبير النمطي", "inputs": { "case_insensitive": { "name": "غير_حساس_لحالة_الحرف" }, "count": { "name": "عدد", "tooltip": "الحد الأقصى لعدد عمليات الاستبدال التي سيتم إجراؤها. اضبط على 0 لاستبدال جميع التواجدات (الافتراضي). اضبط على 1 لاستبدال المطابقة الأولى فقط، 2 لأول مطابقتين، إلخ." }, "dotall": { "name": "مطابقة_الكل", "tooltip": "عند التمكين، سيطابق حرف النقطة (.) أي حرف بما في ذلك أحرف السطر الجديد. عند التعطيل، لن تطابق النقاط أحرف الأسطر الجديدة." }, "multiline": { "name": "متعدد_الأسطر" }, "regex_pattern": { "name": "نمط_التعبير_النمطي" }, "replace": { "name": "استبدال" }, "string": { "name": "سلسلة نصية" } }, "outputs": { "0": { "tooltip": null } } };
const RenormCFG = { "display_name": "إعادة تهيئة CFG", "inputs": { "cfg_trunc": { "name": "اقتطاع CFG" }, "model": { "name": "النموذج" }, "renorm_cfg": { "name": "إعادة تهيئة CFG" } }, "outputs": { "0": { "tooltip": null } } };
const RepeatImageBatch = { "display_name": "تكرار دفعة الصور", "inputs": { "amount": { "name": "الكمية" }, "image": { "name": "الصورة" } } };
const RepeatLatentBatch = { "display_name": "تكرار دفعة الخفاء", "inputs": { "amount": { "name": "الكمية" }, "samples": { "name": "عينات" } } };
const RescaleCFG = { "display_name": "إعادة تحجيم CFG", "inputs": { "model": { "name": "النموذج" }, "multiplier": { "name": "المُضَاعِف" } } };
const ResizeAndPadImage = { "display_name": "تغيير_حجم_وإضافة_حشوة_للصورة", "inputs": { "image": { "name": "صورة" }, "interpolation": { "name": "استيفاء" }, "padding_color": { "name": "لون_الحشوة" }, "target_height": { "name": "الارتفاع_الهدف" }, "target_width": { "name": "العرض_الهدف" } } };
const Rodin3D_Detail = { "description": "توليد أصول ثلاثية الأبعاد باستخدام واجهة برمجة تطبيقات رودين", "display_name": "رودين 3D توليد - توليد التفاصيل", "inputs": { "Images": { "name": "الصور" }, "Material_Type": { "name": "نوع_المادة" }, "Polygon_count": { "name": "عدد_المضلعات" }, "Seed": { "name": "البذرة" } }, "outputs": { "0": { "name": "مسار_النموذج_ثلاثي_الأبعاد", "tooltip": null } } };
const Rodin3D_Gen2 = { "description": "توليد أصول ثلاثية الأبعاد باستخدام واجهة برمجة تطبيقات رودين", "display_name": "رودين 3D توليد - توليد الجيل الثاني", "inputs": { "Images": { "name": "الصور" }, "Material_Type": { "name": "نوع المادة" }, "Polygon_count": { "name": "عدد المضلعات" }, "Seed": { "name": "البذرة" }, "TAPose": { "name": "وضعية_TAP" } }, "outputs": { "0": { "name": "مسار النموذج ثلاثي الأبعاد", "tooltip": null } } };
const Rodin3D_Regular = { "description": "توليد أصول ثلاثية الأبعاد باستخدام واجهة برمجة تطبيقات رودين", "display_name": "رودين 3D توليد - توليد عادي", "inputs": { "Images": { "name": "الصور" }, "Material_Type": { "name": "نوع المادة" }, "Polygon_count": { "name": "عدد المضلعات" }, "Seed": { "name": "البذرة" } }, "outputs": { "0": { "name": "مسار النموذج ثلاثي الأبعاد", "tooltip": null } } };
const Rodin3D_Sketch = { "description": "توليد أصول ثلاثية الأبعاد باستخدام واجهة برمجة تطبيقات رودين", "display_name": "رودين 3D توليد - توليد رسومي", "inputs": { "Images": { "name": "الصور" }, "Seed": { "name": "البذرة" } }, "outputs": { "0": { "name": "مسار النموذج ثلاثي الأبعاد", "tooltip": null } } };
const Rodin3D_Smooth = { "description": "توليد أصول ثلاثية الأبعاد باستخدام واجهة برمجة تطبيقات رودين", "display_name": "رودين 3D توليد - توليد سلس", "inputs": { "Images": { "name": "الصور" }, "Material_Type": { "name": "نوع المادة" }, "Polygon_count": { "name": "عدد المضلعات" }, "Seed": { "name": "البذرة" } }, "outputs": { "0": { "name": "مسار النموذج ثلاثي الأبعاد", "tooltip": null } } };
const RunwayFirstLastFrameNode = { "description": "قم برفع الإطارات الرئيسية الأولى والأخيرة، واكتب موجهًا، وقم بتوليد فيديو. قد تستفيد التحولات الأكثر تعقيدًا، مثل الحالات التي يختلف فيها الإطار الأخير تمامًا عن الإطار الأول، من المدة الأطول البالغة 10 ثوانٍ. سيمنح هذا التوليد مزيدًا من الوقت للانتقال بسلاسة بين المدخلين. قبل البدء، راجع أفضل الممارسات هذه لضمان أن اختياراتك للمدخلات ستؤدي إلى نجاح التوليد: https://help.runwayml.com/hc/en-us/articles/34170748696595-Creating-with-Keyframes-on-Gen-3.", "display_name": "Runway تحويل الإطار الأول-الأخير إلى فيديو", "inputs": { "control_after_generate": { "name": "التحكم بعد التوليد" }, "duration": { "name": "المدة" }, "end_frame": { "name": "الإطار_النهاية", "tooltip": "الإطار النهائي المستخدم في الفيديو. مدعوم لـ gen3a_turbo فقط." }, "prompt": { "name": "موجه", "tooltip": "موجه نصي للتوليد" }, "ratio": { "name": "النسبة" }, "seed": { "name": "البذرة", "tooltip": "بذرة عشوائية للتوليد" }, "start_frame": { "name": "الإطار_البداية", "tooltip": "الإطار الأولي المستخدم في الفيديو" } }, "outputs": { "0": { "tooltip": null } } };
const RunwayImageToVideoNodeGen3a = { "description": "توليد فيديو من إطار بداية واحد باستخدام نموذج Gen3a Turbo. قبل البدء، راجع أفضل الممارسات لضمان أن اختياراتك المدخلة ستؤدي إلى نجاح التوليد: https://help.runwayml.com/hc/en-us/articles/33927968552339-Creating-with-Act-One-on-Gen-3-Alpha-and-Turbo.", "display_name": "Runway صورة إلى فيديو (Gen3a Turbo)", "inputs": { "control_after_generate": { "name": "التحكم بعد التوليد" }, "duration": { "name": "المدة" }, "prompt": { "name": "المطالبة النصية", "tooltip": "المطالبة النصية للتوليد" }, "ratio": { "name": "النسبة" }, "seed": { "name": "البذرة", "tooltip": "بذرة عشوائية للتوليد" }, "start_frame": { "name": "الإطار البدائي", "tooltip": "الإطار البدائي المستخدم للفيديو" } }, "outputs": { "0": { "tooltip": null } } };
const RunwayImageToVideoNodeGen4 = { "description": "توليد فيديو من إطار بداية واحد باستخدام نموذج Gen4 Turbo. قبل البدء، راجع أفضل الممارسات لضمان أن اختياراتك المدخلة ستؤدي إلى نجاح التوليد: https://help.runwayml.com/hc/en-us/articles/37327109429011-Creating-with-Gen-4-Video.", "display_name": "Runway صورة إلى فيديو (Gen4 Turbo)", "inputs": { "control_after_generate": { "name": "التحكم بعد التوليد" }, "duration": { "name": "المدة" }, "prompt": { "name": "المطالبة النصية", "tooltip": "المطالبة النصية للتوليد" }, "ratio": { "name": "النسبة" }, "seed": { "name": "البذرة", "tooltip": "بذرة عشوائية للتوليد" }, "start_frame": { "name": "الإطار البدائي", "tooltip": "الإطار البدائي المستخدم للفيديو" } }, "outputs": { "0": { "tooltip": null } } };
const RunwayTextToImageNode = { "description": "توليد صورة من مطالبة نصية باستخدام نموذج Gen 4 من Runway. يمكنك أيضًا تضمين صورة مرجعية لتوجيه التوليد.", "display_name": "Runway نص إلى صورة", "inputs": { "prompt": { "name": "المطالبة النصية", "tooltip": "النص الموجه للإنشاء" }, "ratio": { "name": "النسبة" }, "reference_image": { "name": "الصورة المرجعية", "tooltip": "صورة مرجعية اختيارية لتوجيه عملية الإنشاء" } }, "outputs": { "0": { "tooltip": null } } };
const SDTurboScheduler = { "display_name": "جدول SD Turbo", "inputs": { "denoise": { "name": "إزالة التشويش" }, "model": { "name": "النموذج" }, "steps": { "name": "الخطوات" } } };
const SD_4XUpscale_Conditioning = { "display_name": "تحسين SD 4X", "inputs": { "images": { "name": "الصور" }, "negative": { "name": "سلبي" }, "noise_augmentation": { "name": "تعزيز الضجيج" }, "positive": { "name": "إيجابي" }, "scale_ratio": { "name": "نسبة المقياس" } }, "outputs": { "0": { "name": "إيجابي", "tooltip": null }, "1": { "name": "سلبي", "tooltip": null }, "2": { "name": "كامن", "tooltip": null } } };
const SV3D_Conditioning = { "display_name": "تهيئة SV3D", "inputs": { "clip_vision": { "name": "رؤية المقطع" }, "elevation": { "name": "الارتفاع الزاوي" }, "height": { "name": "الارتفاع" }, "init_image": { "name": "الصورة الأصلية" }, "vae": { "name": "vae" }, "video_frames": { "name": "إطارات الفيديو" }, "width": { "name": "العرض" } }, "outputs": { "0": { "name": "إيجابي", "tooltip": null }, "1": { "name": "سلبي", "tooltip": null }, "2": { "name": "كامِن", "tooltip": null } } };
const SVD_img2vid_Conditioning = { "display_name": "تهيئة تحويل صورة إلى فيديو من SVD", "inputs": { "augmentation_level": { "name": "مستوى التضخيم" }, "clip_vision": { "name": "رؤية المقطع" }, "fps": { "name": "الإطارات في الثانية" }, "height": { "name": "الارتفاع" }, "init_image": { "name": "الصورة الأصلية" }, "motion_bucket_id": { "name": "معرف دلو الحركة" }, "vae": { "name": "vae" }, "video_frames": { "name": "إطارات الفيديو" }, "width": { "name": "العرض" } }, "outputs": { "0": { "name": "إيجابي" }, "1": { "name": "سلبي" }, "2": { "name": "كامِن" } } };
const SamplerCustom = { "display_name": "المُعين المخصص", "inputs": { "add_noise": { "name": "إضافة ضجيج" }, "cfg": { "name": "CFG" }, "control_after_generate": { "name": "التحكم بعد التوليد" }, "latent_image": { "name": "صورة الخفاء" }, "model": { "name": "النموذج" }, "negative": { "name": "السلبي" }, "noise_seed": { "name": "بذرة الضجيج" }, "positive": { "name": "الإيجابي" }, "sampler": { "name": "المُعين" }, "sigmas": { "name": "سيغما" } }, "outputs": { "0": { "name": "المخرج" }, "1": { "name": "المخرج المنقح" } } };
const SamplerCustomAdvanced = { "display_name": "المُعين المخصص المتقدم", "inputs": { "guider": { "name": "الدليل" }, "latent_image": { "name": "صورة الخفاء" }, "noise": { "name": "الضجيج" }, "sampler": { "name": "المُعين" }, "sigmas": { "name": "سيغما" } }, "outputs": { "0": { "name": "المخرج" }, "1": { "name": "المخرج المنقح" } } };
const SamplerDPMAdaptative = { "display_name": "المُعين DPM التكيفي", "inputs": { "accept_safety": { "name": "قبول الأمان" }, "atol": { "name": "atol" }, "dcoeff": { "name": "dcoeff" }, "eta": { "name": "إيتا" }, "h_init": { "name": "h_init" }, "icoeff": { "name": "icoeff" }, "order": { "name": "الترتيب" }, "pcoeff": { "name": "pcoeff" }, "rtol": { "name": "rtol" }, "s_noise": { "name": "ضجيج s" } } };
const SamplerDPMPP_2M_SDE = { "display_name": "المُعين DPMPP_2M_SDE", "inputs": { "eta": { "name": "إيتا" }, "noise_device": { "name": "جهاز الضجيج" }, "s_noise": { "name": "ضجيج s" }, "solver_type": { "name": "نوع المُحلل" } } };
const SamplerDPMPP_2S_Ancestral = { "display_name": "المُعين DPMPP_2S_Ancestral", "inputs": { "eta": { "name": "إيتا" }, "s_noise": { "name": "ضجيج s" } } };
const SamplerDPMPP_3M_SDE = { "display_name": "المُعين DPMPP_3M_SDE", "inputs": { "eta": { "name": "إيتا" }, "noise_device": { "name": "جهاز الضجيج" }, "s_noise": { "name": "ضجيج s" } } };
const SamplerDPMPP_SDE = { "display_name": "المُعين DPMPP_SDE", "inputs": { "eta": { "name": "إيتا" }, "noise_device": { "name": "جهاز الضجيج" }, "r": { "name": "r" }, "s_noise": { "name": "ضجيج s" } } };
const SamplerER_SDE = { "display_name": "SamplerER_SDE", "inputs": { "eta": { "name": "إيتا", "tooltip": "القوة العشوائية لمعادلة SDE العكسية الزمن.\nعندما تكون إيتا=0، تتحول إلى معادلة ODE حتمية. هذا الإعداد لا ينطبق على نوع حل ER-SDE." }, "max_stage": { "name": "المرحلة القصوى" }, "s_noise": { "name": "الضوضاء s" }, "solver_type": { "name": "نوع الحل" } } };
const SamplerEulerAncestral = { "display_name": "المُعين Euler الأثري", "inputs": { "eta": { "name": "إيتا" }, "s_noise": { "name": "ضجيج s" } } };
const SamplerEulerAncestralCFGPP = { "display_name": "المُعين Euler الأثري CFG++", "inputs": { "eta": { "name": "إيتا" }, "s_noise": { "name": "ضجيج s" } } };
const SamplerEulerCFGpp = { "display_name": "المُعين Euler CFG++", "inputs": { "version": { "name": "الإصدار" } }, "outputs": { "0": { "tooltip": null } } };
const SamplerLCMUpscale = { "display_name": "المُعين LCM للتكبير", "inputs": { "scale_ratio": { "name": "نسبة التكبير" }, "scale_steps": { "name": "خطوات التكبير" }, "upscale_method": { "name": "طريقة التكبير" } }, "outputs": { "0": { "tooltip": null } } };
const SamplerLMS = { "display_name": "المُعين LMS", "inputs": { "order": { "name": "الترتيب" } } };
const SamplerSASolver = { "display_name": "SamplerSASolver", "inputs": { "corrector_order": { "name": "ترتيب المصحح" }, "eta": { "name": "إيتا" }, "model": { "name": "النموذج" }, "predictor_order": { "name": "ترتيب المتنبئ" }, "s_noise": { "name": "الضوضاء s" }, "sde_end_percent": { "name": "نسبة انتهاء SDE" }, "sde_start_percent": { "name": "نسبة بدء SDE" }, "simple_order_2": { "name": "الترتيب البسيط 2" }, "use_pece": { "name": "استخدام PECE" } } };
const SamplingPercentToSigma = { "display_name": "SamplingPercentToSigma", "inputs": { "model": { "name": "النموذج" }, "return_actual_sigma": { "name": "إرجاع سيجما الفعلية", "tooltip": "إرجاع قيمة سيجما الفعلية بدلاً من القيمة المستخدمة للتحقق من الفترات.\nهذا يؤثر فقط على النتائج عند 0.0 و 1.0." }, "sampling_percent": { "name": "نسبة أخذ العينات" } }, "outputs": { "0": { "name": "قيمة سيجما" } } };
const SaveAnimatedPNG = { "display_name": "حفظ PNG متحرك", "inputs": { "compress_level": { "name": "مستوى الضغط" }, "filename_prefix": { "name": "بادئة اسم الملف" }, "fps": { "name": "معدل الإطارات في الثانية" }, "images": { "name": "الصور" } } };
const SaveAnimatedWEBP = { "display_name": "حفظ WEBP متحرك", "inputs": { "filename_prefix": { "name": "بادئة اسم الملف" }, "fps": { "name": "معدل الإطارات في الثانية" }, "images": { "name": "الصور" }, "lossless": { "name": "بدون خسارة" }, "method": { "name": "الطريقة" }, "quality": { "name": "الجودة" } } };
const SaveAudio = { "display_name": "حفظ الصوت", "inputs": { "audio": { "name": "الصوت" }, "audioUI": { "name": "واجهة الصوت" }, "filename_prefix": { "name": "بادئة اسم الملف" } } };
const SaveAudioMP3 = { "display_name": "حفظ الصوت (MP3)", "inputs": { "audio": { "name": "الصوت" }, "audioUI": { "name": "واجهة الصوت" }, "filename_prefix": { "name": "بادئة اسم الملف" }, "quality": { "name": "الجودة" } } };
const SaveAudioOpus = { "display_name": "حفظ الصوت (Opus)", "inputs": { "audio": { "name": "صوت" }, "audioUI": { "name": "واجهة الصوت" }, "filename_prefix": { "name": "بادئة اسم الملف" }, "quality": { "name": "الجودة" } } };
const SaveGLB = { "display_name": "حفظ GLB", "inputs": { "filename_prefix": { "name": "بادئة اسم الملف" }, "image": { "name": "الصورة" }, "mesh": { "name": "الشبكة" } } };
const SaveImage = { "description": "يحفظ الصور المدخلة في مجلد مخرجات ComfyUI الخاص بك.", "display_name": "حفظ الصورة", "inputs": { "filename_prefix": { "name": "بادئة اسم الملف", "tooltip": "بادئة اسم الملف للحفظ. يمكن أن تتضمن معلومات تنسيق مثل %date:yyyy-MM-dd% أو %Empty Latent Image.width% لاستخدام قيم من العقد." }, "images": { "name": "الصور", "tooltip": "الصور التي سيتم حفظها." } } };
const SaveImageWebsocket = { "display_name": "حفظ صورة عبر Websocket", "inputs": { "images": { "name": "الصور" } } };
const SaveLatent = { "display_name": "حفظ الكامن", "inputs": { "filename_prefix": { "name": "بادئة اسم الملف" }, "samples": { "name": "عينات" } } };
const SaveSVGNode = { "description": "حفظ ملفات SVG على القرص.", "display_name": "عقدة حفظ SVG", "inputs": { "filename_prefix": { "name": "بادئة اسم الملف", "tooltip": "البادئة للملف المراد حفظه. قد تتضمن هذه معلومات تنسيق مثل %date:yyyy-MM-dd% أو %Empty Latent Image.width% لتضمين قيم من العقد." }, "svg": { "name": "svg" } } };
const SaveVideo = { "description": "يحفظ الصور المدخلة في مجلد مخرجات ComfyUI الخاص بك.", "display_name": "حفظ الفيديو", "inputs": { "codec": { "name": "الترميز", "tooltip": "الترميز المستخدم للفيديو." }, "filename_prefix": { "name": "بادئة اسم الملف", "tooltip": "بادئة اسم الملف للحفظ. يمكن أن تتضمن معلومات تنسيق مثل %date:yyyy-MM-dd% أو %Empty Latent Image.width% لاستخدام قيم من العقد." }, "format": { "name": "الصيغة", "tooltip": "الصيغة التي سيتم حفظ الفيديو بها." }, "video": { "name": "الفيديو", "tooltip": "الفيديو الذي سيتم حفظه." } } };
const SaveWEBM = { "display_name": "حفظ WEBM", "inputs": { "codec": { "name": "الترميز" }, "crf": { "name": "crf", "tooltip": "كلما زاد crf انخفضت الجودة وحجم الملف، وكلما انخفض زادت الجودة وحجم الملف." }, "filename_prefix": { "name": "بادئة اسم الملف" }, "fps": { "name": "معدل الإطارات في الثانية" }, "images": { "name": "الصور" } } };
const ScaleROPE = { "description": "قياس وتحويل ROPE للنموذج.", "display_name": "مقياس ROPE", "inputs": { "model": { "name": "نموذج" }, "scale_t": { "name": "مقياس_ت" }, "scale_x": { "name": "مقياس_س" }, "scale_y": { "name": "مقياس_ص" }, "shift_t": { "name": "تحويل_ت" }, "shift_x": { "name": "تحويل_س" }, "shift_y": { "name": "تحويل_ص" } }, "outputs": { "0": { "tooltip": null } } };
const SelfAttentionGuidance = { "display_name": "توجيه الانتباه الذاتي", "inputs": { "blur_sigma": { "name": "تمويه سيغما" }, "model": { "name": "النموذج" }, "scale": { "name": "المقياس" } }, "outputs": { "0": { "tooltip": null } } };
const SetClipHooks = { "display_name": "تعيين CLIP Hooks", "inputs": { "apply_to_conds": { "name": "تطبيق على الشروط" }, "clip": { "name": "CLIP" }, "hooks": { "name": "Hooks" }, "schedule_clip": { "name": "جدولة CLIP" } } };
const SetFirstSigma = { "display_name": "تعيين Sigma الأول", "inputs": { "sigma": { "name": "Sigma" }, "sigmas": { "name": "Sigmas" } } };
const SetHookKeyframes = { "display_name": "تعيين إطارات مفتاحية للـ Hook", "inputs": { "hook_kf": { "name": "الإطار المفتاحي للـ Hook" }, "hooks": { "name": "Hooks" } } };
const SetLatentNoiseMask = { "display_name": "تعيين قناع ضجيج الكامن", "inputs": { "mask": { "name": "القناع" }, "samples": { "name": "عينات" } } };
const SetUnionControlNetType = { "display_name": "تعيين نوع Union ControlNet", "inputs": { "control_net": { "name": "شبكة التحكم" }, "type": { "name": "النوع" } }, "outputs": { "0": { "tooltip": null } } };
const SkipLayerGuidanceDiT = { "description": "نسخة عامة من عقدة SkipLayerGuidance يمكن استخدامها مع كل نموذج DiT.", "display_name": "توجيه تخطي الطبقة DiT", "inputs": { "double_layers": { "name": "طبقات مزدوجة" }, "end_percent": { "name": "نسبة النهاية" }, "model": { "name": "النموذج" }, "rescaling_scale": { "name": "مقياس إعادة التحجيم" }, "scale": { "name": "المقياس" }, "single_layers": { "name": "طبقات مفردة" }, "start_percent": { "name": "نسبة البداية" } }, "outputs": { "0": { "tooltip": null } } };
const SkipLayerGuidanceDiTSimple = { "description": "نسخة مبسطة من عقدة توجيه طبقة التخطي DiT التي تعدل فقط تمرير uncond.", "display_name": "توجيه طبقة التخطي DiT المبسط", "inputs": { "double_layers": { "name": "طبقات مزدوجة" }, "end_percent": { "name": "النسبة المئوية للنهاية" }, "model": { "name": "نموذج" }, "single_layers": { "name": "طبقات مفردة" }, "start_percent": { "name": "النسبة المئوية للبداية" } }, "outputs": { "0": { "tooltip": null } } };
const SkipLayerGuidanceSD3 = { "description": "نسخة عامة من عقدة SkipLayerGuidance يمكن استخدامها مع كل نموذج DiT.", "display_name": "توجيه تخطي الطبقة SD3", "inputs": { "end_percent": { "name": "نسبة النهاية" }, "layers": { "name": "الطبقات" }, "model": { "name": "النموذج" }, "scale": { "name": "المقياس" }, "start_percent": { "name": "نسبة البداية" } }, "outputs": { "0": { "tooltip": null } } };
const SolidMask = { "display_name": "قناع صلب", "inputs": { "height": { "name": "الارتفاع" }, "value": { "name": "القيمة" }, "width": { "name": "العرض" } } };
const SplitAudioChannels = { "description": "يفصل الصوت إلى القناتين اليسرى واليمنى.", "display_name": "فصل قنوات الصوت", "inputs": { "audio": { "name": "صوت" } }, "outputs": { "0": { "name": "يسار" }, "1": { "name": "يمين" } } };
const SplitImageWithAlpha = { "display_name": "فصل الصورة مع ألفا", "inputs": { "image": { "name": "الصورة" } }, "outputs": { "0": { "tooltip": null }, "1": { "tooltip": null } } };
const SplitSigmas = { "display_name": "فصل Sigmas", "inputs": { "sigmas": { "name": "Sigmas" }, "step": { "name": "الخطوة" } }, "outputs": { "0": { "name": "Sigmas عالية" }, "1": { "name": "Sigmas منخفضة" } } };
const SplitSigmasDenoise = { "display_name": "فصل Sigmas إزالة التشويش", "inputs": { "denoise": { "name": "إزالة التشويش" }, "sigmas": { "name": "Sigmas" } }, "outputs": { "0": { "name": "Sigmas عالية" }, "1": { "name": "Sigmas منخفضة" } } };
const StabilityAudioInpaint = { "description": "يحول جزءًا من عينة الصوت الحالية باستخدام تعليمات نصية.", "display_name": "إعادة رسم الصوت من Stability AI", "inputs": { "audio": { "name": "صوت", "tooltip": "يجب أن يكون الصوت بين 6 و190 ثانية." }, "control_after_generate": { "name": "التحكم بعد الإنشاء" }, "duration": { "name": "المدة", "tooltip": "يتحكم في مدة الصوت المُنشأ بالثواني." }, "mask_end": { "name": "نهاية القناع" }, "mask_start": { "name": "بداية القناع" }, "model": { "name": "نموذج" }, "prompt": { "name": "مُوجِه" }, "seed": { "name": "بذرة", "tooltip": "البذرة العشوائية المستخدمة في الإنشاء." }, "steps": { "name": "خطوات", "tooltip": "يتحكم في عدد خطوات أخذ العينات." } }, "outputs": { "0": { "tooltip": null } } };
const StabilityAudioToAudio = { "description": "يحول عينات الصوت الحالية إلى تركيبات جديدة عالية الجودة باستخدام تعليمات نصية.", "display_name": "تحويل الصوت إلى صوت من Stability AI", "inputs": { "audio": { "name": "صوت", "tooltip": "يجب أن يكون الصوت بين 6 و190 ثانية." }, "control_after_generate": { "name": "التحكم بعد الإنشاء" }, "duration": { "name": "المدة", "tooltip": "تتحكم في مدة الصوت المُنشأ بالثواني." }, "model": { "name": "نموذج" }, "prompt": { "name": "مُوجِه" }, "seed": { "name": "البذرة", "tooltip": "البذرة العشوائية المستخدمة في الإنشاء." }, "steps": { "name": "الخطوات", "tooltip": "تتحكم في عدد خطوات أخذ العينات." }, "strength": { "name": "القوة", "tooltip": "تتحكم المعلمة في مقدار تأثير معامل الصوت على الصوت المُنشأ." } }, "outputs": { "0": { "tooltip": null } } };
const StabilityStableImageSD_3_5Node = { "description": "ينتج الصور بشكل متزامن بناءً على النص والنسبة.", "display_name": "Stability AI صورة Stable Diffusion 3.5", "inputs": { "aspect_ratio": { "name": "نسبة العرض إلى الارتفاع", "tooltip": "نسبة عرض الصورة الناتجة." }, "cfg_scale": { "name": "مقياس CFG", "tooltip": "مدى التزام عملية الانتشار بالنص الوصفي (القيم الأعلى تبقي الصورة أقرب للنص)." }, "control_after_generate": { "name": "التحكم بعد الإنشاء" }, "image": { "name": "الصورة" }, "image_denoise": { "name": "إزالة التشويش من الصورة", "tooltip": "0.0 تعني صورة مطابقة للأصل، 1.0 تعني عدم وجود صورة أصلية." }, "model": { "name": "النموذج" }, "negative_prompt": { "name": "نص سلبي", "tooltip": "الكلمات التي لا ترغب برؤيتها في الصورة الناتجة. ميزة متقدمة." }, "prompt": { "name": "النص الوصفي", "tooltip": "ما ترغب برؤيته في الصورة الناتجة. نص وصفي قوي وواضح يحدد العناصر والألوان والموضوعات يؤدي لنتائج أفضل." }, "seed": { "name": "البذرة", "tooltip": "البذرة العشوائية لإنشاء الضجيج." }, "style_preset": { "name": "نمط مسبق", "tooltip": "النمط المرغوب اختياريًا للصورة الناتجة." } }, "outputs": { "0": { "tooltip": null } } };
const StabilityStableImageUltraNode = { "description": "ينتج الصور بشكل متزامن بناءً على النص والنسبة.", "display_name": "Stability AI صورة Stable Ultra", "inputs": { "aspect_ratio": { "name": "نسبة العرض إلى الارتفاع", "tooltip": "نسبة عرض الصورة الناتجة." }, "control_after_generate": { "name": "التحكم بعد الإنشاء" }, "image": { "name": "الصورة" }, "image_denoise": { "name": "إزالة التشويش من الصورة", "tooltip": "0.0 تعني صورة مطابقة للأصل، 1.0 تعني عدم وجود صورة أصلية." }, "negative_prompt": { "name": "نص سلبي", "tooltip": "وصف لما لا ترغب برؤيته في الصورة الناتجة. ميزة متقدمة." }, "prompt": { "name": "النص الوصفي", "tooltip": "ما ترغب برؤيته في الصورة الناتجة. نص وصفي قوي وواضح يحدد العناصر والألوان والموضوعات يؤدي لنتائج أفضل. للتحكم في وزن كلمة معينة استخدم التنسيق (الكلمة:الوزن) حيث الوزن بين 0 و1." }, "seed": { "name": "البذرة", "tooltip": "البذرة العشوائية لإنشاء الضجيج." }, "style_preset": { "name": "نمط مسبق", "tooltip": "النمط المرغوب اختياريًا للصورة الناتجة." } }, "outputs": { "0": { "tooltip": null } } };
const StabilityTextToAudio = { "description": "ينشئ موسيقى ومؤثرات صوتية عالية الجودة من أوصاف نصية.", "display_name": "Stability AI تحويل النص إلى صوت", "inputs": { "control_after_generate": { "name": "التحكم بعد الإنشاء" }, "duration": { "name": "المدة", "tooltip": "تتحكم في مدة الصوت المُنشأ بالثواني." }, "model": { "name": "النموذج" }, "prompt": { "name": "المطالبة" }, "seed": { "name": "البذرة", "tooltip": "البذرة العشوائية المستخدمة في الإنشاء." }, "steps": { "name": "الخطوات", "tooltip": "تتحكم في عدد خطوات أخذ العينات." } }, "outputs": { "0": { "tooltip": null } } };
const StabilityUpscaleConservativeNode = { "description": "يكبر الصورة مع تغييرات طفيفة إلى دقة 4K.", "display_name": "Stability AI تكبير محافظ", "inputs": { "control_after_generate": { "name": "التحكم بعد الإنشاء" }, "creativity": { "name": "الإبداع", "tooltip": "يتحكم في احتمالية إضافة تفاصيل إضافية ليست متأثرة بقوة بالصورة الأصلية." }, "image": { "name": "الصورة" }, "negative_prompt": { "name": "نص سلبي", "tooltip": "الكلمات التي لا ترغب برؤيتها في الصورة الناتجة. ميزة متقدمة." }, "prompt": { "name": "النص الوصفي", "tooltip": "ما ترغب برؤيته في الصورة الناتجة. نص وصفي قوي وواضح يحدد العناصر والألوان والموضوعات يؤدي لنتائج أفضل." }, "seed": { "name": "البذرة", "tooltip": "البذرة العشوائية لإنشاء الضجيج." } }, "outputs": { "0": { "tooltip": null } } };
const StabilityUpscaleCreativeNode = { "description": "تكبير الصورة مع تغييرات طفيفة إلى دقة 4K.", "display_name": "تكبير استقرار الذكاء الاصطناعي الإبداعي", "inputs": { "control_after_generate": { "name": "التحكم بعد الإنشاء" }, "creativity": { "name": "الإبداع", "tooltip": "يتحكم في احتمالية إنشاء تفاصيل إضافية غير معتمدة بشكل كبير على الصورة الأصلية." }, "image": { "name": "صورة" }, "negative_prompt": { "name": "النص السلبي", "tooltip": "كلمات مفتاحية لما لا ترغب في رؤيته في الصورة الناتجة. هذه ميزة متقدمة." }, "prompt": { "name": "النص الوصفي", "tooltip": "ما ترغب في رؤيته في الصورة الناتجة. النص الوصفي القوي والواضح الذي يحدد العناصر والألوان والمواضيع بدقة يؤدي إلى نتائج أفضل." }, "seed": { "name": "البذرة", "tooltip": "البذرة العشوائية المستخدمة لإنشاء الضجيج." }, "style_preset": { "name": "نمط مسبق", "tooltip": "النمط المرغوب اختياريًا للصورة المولدة." } }, "outputs": { "0": { "tooltip": null } } };
const StabilityUpscaleFastNode = { "description": "يزيد حجم الصورة بسرعة عبر استدعاء API الخاص باستقرار الذكاء الاصطناعي إلى 4 أضعاف الحجم الأصلي؛ مخصص لتكبير الصور منخفضة الجودة أو المضغوطة.", "display_name": "تكبير استقرار الذكاء الاصطناعي السريع", "inputs": { "image": { "name": "صورة" } }, "outputs": { "0": { "tooltip": null } } };
const StableCascade_EmptyLatentImage = { "display_name": "صورة كامنة فارغة من StableCascade", "inputs": { "batch_size": { "name": "حجم الدفعة" }, "compression": { "name": "ضغط" }, "height": { "name": "الارتفاع" }, "width": { "name": "العرض" } }, "outputs": { "0": { "name": "المرحلة_ج", "tooltip": null }, "1": { "name": "المرحلة_ب", "tooltip": null } } };
const StableCascade_StageB_Conditioning = { "display_name": "تهيئة المرحلة ب من StableCascade", "inputs": { "conditioning": { "name": "تهيئة" }, "stage_c": { "name": "المرحلة_ج" } }, "outputs": { "0": { "tooltip": null } } };
const StableCascade_StageC_VAEEncode = { "display_name": "ترميز VAE للمرحلة ج من StableCascade", "inputs": { "compression": { "name": "ضغط" }, "image": { "name": "صورة" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "المرحلة_ج", "tooltip": null }, "1": { "name": "المرحلة_ب", "tooltip": null } } };
const StableCascade_SuperResolutionControlnet = { "display_name": "شبكة التحكم للدقة الفائقة من StableCascade", "inputs": { "image": { "name": "صورة" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "مدخلات شبكة التحكم", "tooltip": null }, "1": { "name": "المرحلة_ج", "tooltip": null }, "2": { "name": "المرحلة_ب", "tooltip": null } } };
const StableZero123_Conditioning = { "display_name": "تهيئة StableZero123", "inputs": { "azimuth": { "name": "السمت" }, "batch_size": { "name": "حجم الدفعة" }, "clip_vision": { "name": "رؤية المقطع" }, "elevation": { "name": "الارتفاع الزاوي" }, "height": { "name": "الارتفاع" }, "init_image": { "name": "الصورة الأصلية" }, "vae": { "name": "vae" }, "width": { "name": "العرض" } }, "outputs": { "0": { "name": "إيجابي", "tooltip": null }, "1": { "name": "سلبي", "tooltip": null }, "2": { "name": "كامِن", "tooltip": null } } };
const StableZero123_Conditioning_Batched = { "display_name": "تهيئة StableZero123 مجمعة", "inputs": { "azimuth": { "name": "السمت" }, "azimuth_batch_increment": { "name": "زيادة دفعة السمت" }, "batch_size": { "name": "حجم الدفعة" }, "clip_vision": { "name": "رؤية المقطع" }, "elevation": { "name": "الارتفاع الزاوي" }, "elevation_batch_increment": { "name": "زيادة دفعة الارتفاع الزاوي" }, "height": { "name": "الارتفاع" }, "init_image": { "name": "الصورة الأصلية" }, "vae": { "name": "vae" }, "width": { "name": "العرض" } }, "outputs": { "0": { "name": "إيجابي", "tooltip": null }, "1": { "name": "سلبي", "tooltip": null }, "2": { "name": "كامِن", "tooltip": null } } };
const StringCompare = { "display_name": "مقارنة", "inputs": { "case_sensitive": { "name": "حساس لحالة الأحرف" }, "mode": { "name": "الوضع" }, "string_a": { "name": "السلسلة_أ" }, "string_b": { "name": "السلسلة_ب" } }, "outputs": { "0": { "tooltip": null } } };
const StringConcatenate = { "display_name": "ربط", "inputs": { "delimiter": { "name": "الفاصل" }, "string_a": { "name": "السلسلة_أ" }, "string_b": { "name": "السلسلة_ب" } }, "outputs": { "0": { "tooltip": null } } };
const StringContains = { "display_name": "يحتوي", "inputs": { "case_sensitive": { "name": "حساس لحالة الأحرف" }, "string": { "name": "سلسلة نصية" }, "substring": { "name": "جزء نصي" } }, "outputs": { "0": { "name": "يحتوي على", "tooltip": null } } };
const StringLength = { "display_name": "الطول", "inputs": { "string": { "name": "سلسلة نصية" } }, "outputs": { "0": { "name": "الطول", "tooltip": null } } };
const StringReplace = { "display_name": "استبدال", "inputs": { "find": { "name": "بحث" }, "replace": { "name": "استبدال" }, "string": { "name": "سلسلة نصية" } }, "outputs": { "0": { "tooltip": null } } };
const StringSubstring = { "display_name": "جزء نصي", "inputs": { "end": { "name": "نهاية" }, "start": { "name": "بداية" }, "string": { "name": "سلسلة نصية" } }, "outputs": { "0": { "tooltip": null } } };
const StringTrim = { "display_name": "قص", "inputs": { "mode": { "name": "وضع" }, "string": { "name": "سلسلة نصية" } }, "outputs": { "0": { "tooltip": null } } };
const StyleModelApply = { "display_name": "تطبيق نموذج النمط", "inputs": { "clip_vision_output": { "name": "خرج رؤية المقطع" }, "conditioning": { "name": "تهيئة" }, "strength": { "name": "القوة" }, "strength_type": { "name": "نوع القوة" }, "style_model": { "name": "نموذج النمط" } } };
const StyleModelLoader = { "display_name": "تحميل نموذج النمط", "inputs": { "style_model_name": { "name": "اسم نموذج النمط" } } };
const T5TokenizerOptions = { "display_name": "خيارات محلل T5", "inputs": { "clip": { "name": "كليب" }, "min_length": { "name": "الحد الأدنى للطول" }, "min_padding": { "name": "الحد الأدنى للحشو" } }, "outputs": { "0": { "tooltip": null } } };
const TCFG = { "description": "TCFG – التخميد المماسي CFG (2503.18137)\n\nتحسين الشرط السلبي لمحاذاة الشرط الإيجابي لتحسين الجودة.", "display_name": "التخميد المماسي CFG", "inputs": { "model": { "name": "نموذج" } }, "outputs": { "0": { "name": "نموذج معدل", "tooltip": null } } };
const TemporalScoreRescaling = { "description": "[دالة ما بعد CFG]\nTSR - إعادة قياس النقاط الزمنية (2510.01184)\n\nإعادة قياس نقاط النموذج أو الضوضاء لتوجيه تنوع أخذ العينات.", "display_name": "TSR - إعادة قياس النقاط الزمنية", "inputs": { "model": { "name": "نموذج" }, "tsr_k": { "name": "tsr_k", "tooltip": "يتحكم في قوة إعادة القياس.\nالقيم الأقل لـ k تنتج نتائج أكثر تفصيلاً؛ القيم الأعلى لـ k تنتج نتائج أكثر سلاسة في توليد الصور. تعيين k = 1 يعطل إعادة القياس." }, "tsr_sigma": { "name": "tsr_sigma", "tooltip": "يتحكم في وقت بدء تأثير إعادة القياس.\nالقيم الأكبر تبدأ تأثيرها في وقت أبكر." } }, "outputs": { "0": { "name": "نموذج معدل", "tooltip": null } } };
const TextEncodeAceStepAudio = { "display_name": "TextEncodeAceStepAudio", "inputs": { "clip": { "name": "clip" }, "lyrics": { "name": "كلمات الأغاني" }, "lyrics_strength": { "name": "قوة الكلمات" }, "tags": { "name": "علامات" } }, "outputs": { "0": { "tooltip": null } } };
const TextEncodeHunyuanVideo_ImageToVideo = { "display_name": "ترميز النص لفيديو Hunyuan - من صورة إلى فيديو", "inputs": { "clip": { "name": "كليب" }, "clip_vision_output": { "name": "ناتج رؤية الكليب" }, "image_interleave": { "name": "تداخل الصورة", "tooltip": "مدى تأثير الصورة مقارنة بالموجه النصي. الرقم الأعلى يعني تأثير أكبر من الموجه النصي." }, "prompt": { "name": "الموجه" } }, "outputs": { "0": { "tooltip": null } } };
const TextEncodeQwenImageEdit = { "display_name": "TextEncodeQwenImageEdit", "inputs": { "clip": { "name": "clip" }, "image": { "name": "صورة" }, "prompt": { "name": "مُوجِّه" }, "vae": { "name": "vae" } }, "outputs": { "0": { "tooltip": null } } };
const TextEncodeQwenImageEditPlus = { "display_name": "TextEncodeQwenImageEditPlus", "inputs": { "clip": { "name": "clip" }, "image1": { "name": "صورة 1" }, "image2": { "name": "صورة 2" }, "image3": { "name": "صورة 3" }, "prompt": { "name": "مُوجِّه" }, "vae": { "name": "vae" } }, "outputs": { "0": { "tooltip": null } } };
const ThresholdMask = { "display_name": "قناع العتبة", "inputs": { "mask": { "name": "القناع" }, "value": { "name": "القيمة" } } };
const TomePatchModel = { "display_name": "نموذج TomePatch", "inputs": { "model": { "name": "النموذج" }, "ratio": { "name": "النسبة" } }, "outputs": { "0": { "tooltip": null } } };
const TorchCompileModel = { "display_name": "نموذج TorchCompile", "inputs": { "backend": { "name": "الخلفية" }, "model": { "name": "النموذج" } }, "outputs": { "0": { "tooltip": null } } };
const TrainLoraNode = { "display_name": "تدريب LoRA", "inputs": { "algorithm": { "name": "الخوارزمية", "tooltip": "الخوارزمية المستخدمة في التدريب." }, "batch_size": { "name": "حجم الدُفعة", "tooltip": "حجم الدُفعة المستخدم في التدريب." }, "control_after_generate": { "name": "التحكم بعد التوليد" }, "existing_lora": { "name": "LoRA الحالي", "tooltip": "LoRA الحالي للإلحاق به. اضبط على لا شيء لإنشاء LoRA جديد." }, "grad_accumulation_steps": { "name": "خطوات تراكم التدرج", "tooltip": "عدد خطوات تراكم التدرج المستخدمة في التدريب." }, "gradient_checkpointing": { "name": "التحقق من التدرج", "tooltip": "استخدام التحقق من التدرج في التدريب." }, "latents": { "name": "مُختَزَلات", "tooltip": "المُختَزَلات المستخدمة في التدريب، تُستخدم كمجموعة بيانات/مدخلات للنموذج." }, "learning_rate": { "name": "معدل التعلم", "tooltip": "معدل التعلم المستخدم في التدريب." }, "lora_dtype": { "name": "نوع بيانات LoRA", "tooltip": "نوع البيانات المستخدم في LoRA." }, "loss_function": { "name": "دالة الخسارة", "tooltip": "دالة الخسارة المستخدمة في التدريب." }, "model": { "name": "نموذج", "tooltip": "النموذج الذي سيتم تدريب LoRA عليه." }, "optimizer": { "name": "المحسن", "tooltip": "المحسن المستخدم في التدريب." }, "positive": { "name": "إيجابي", "tooltip": "التكييف الإيجابي المستخدم في التدريب." }, "rank": { "name": "الرتبة", "tooltip": "رتبة طبقات LoRA." }, "seed": { "name": "البذرة", "tooltip": "البذرة المستخدمة في التدريب (تُستخدم في المُولِّد لتهيئة أوزان LoRA وأخذ العينات الضوضائية)" }, "steps": { "name": "خطوات", "tooltip": "عدد الخطوات لتدريب LoRA." }, "training_dtype": { "name": "نوع بيانات التدريب", "tooltip": "نوع البيانات المستخدم في التدريب." } }, "outputs": { "0": { "name": "النموذج مع LoRA" }, "1": { "name": "LoRA" }, "2": { "name": "الخسارة" }, "3": { "name": "الخطوات" } } };
const TrimAudioDuration = { "description": "قص موتر الصوت إلى النطاق الزمني المختار.", "display_name": "قص مدة الصوت", "inputs": { "audio": { "name": "الصوت" }, "duration": { "name": "المدة", "tooltip": "المدة بالثواني" }, "start_index": { "name": "فهرس البداية", "tooltip": "وقت البداية بالثواني، يمكن أن يكون سالبًا للعد من النهاية (يدعم أجزاء الثانية)." } } };
const TrimVideoLatent = { "display_name": "اقتطاع فيديو الخفاء", "inputs": { "samples": { "name": "العيّنات" }, "trim_amount": { "name": "مقدار الاقتطاع" } }, "outputs": { "0": { "tooltip": null } } };
const TripleCLIPLoader = { "description": "[الوصفات]\n\nsd3: clip-l, clip-g, t5", "display_name": "محمل TripleCLIP", "inputs": { "clip_name1": { "name": "اسم الكليب 1" }, "clip_name2": { "name": "اسم الكليب 2" }, "clip_name3": { "name": "اسم الكليب 3" } }, "outputs": { "0": { "tooltip": null } } };
const TripoConversionNode = { "display_name": "Tripo: تحويل النموذج", "inputs": { "face_limit": { "name": "حد الوجه" }, "format": { "name": "التنسيق" }, "original_model_task_id": { "name": "original_model_task_id" }, "quad": { "name": "رباعي" }, "texture_format": { "name": "تنسيق النسيج" }, "texture_size": { "name": "حجم النسيج" } } };
const TripoImageToModelNode = { "display_name": "Tripo: الصورة إلى نموذج", "inputs": { "face_limit": { "name": "حد الوجه" }, "image": { "name": "الصورة" }, "model_seed": { "name": "بذرة النموذج" }, "model_version": { "name": "إصدار النموذج", "tooltip": "إصدار النموذج المستخدم في التوليد" }, "orientation": { "name": "الاتجاه" }, "pbr": { "name": "pbr" }, "quad": { "name": "رباعي" }, "style": { "name": "النمط" }, "texture": { "name": "النسيج" }, "texture_alignment": { "name": "محاذاة النسيج" }, "texture_quality": { "name": "جودة النسيج" }, "texture_seed": { "name": "بذرة النسيج" } }, "outputs": { "0": { "name": "ملف النموذج", "tooltip": null }, "1": { "name": "model task_id", "tooltip": null } } };
const TripoMultiviewToModelNode = { "display_name": "Tripo: متعدد المناظر إلى نموذج", "inputs": { "face_limit": { "name": "حد_الوجه" }, "image": { "name": "الصورة" }, "image_back": { "name": "الصورة الخلفية" }, "image_left": { "name": "الصورة اليسرى" }, "image_right": { "name": "الصورة اليمنى" }, "model_seed": { "name": "بذرة_النموذج" }, "model_version": { "name": "إصدار_النموذج", "tooltip": "إصدار النموذج المستخدم في التوليد" }, "orientation": { "name": "التوجيه" }, "pbr": { "name": "PBR" }, "quad": { "name": "رباعي" }, "texture": { "name": "الملمس" }, "texture_alignment": { "name": "محاذاة_الملمس" }, "texture_quality": { "name": "جودة_الملمس" }, "texture_seed": { "name": "بذرة_الملمس" } }, "outputs": { "0": { "name": "ملف_النموذج", "tooltip": null }, "1": { "name": "معرف_مهمة_النموذج", "tooltip": null } } };
const TripoRefineNode = { "description": "تحسين نموذج مسود تم إنشاؤه بواسطة نماذج Tripo الإصدار 1.4 فقط.", "display_name": "Tripo: تحسين النموذج المسود", "inputs": { "model_task_id": { "name": "معرف_مهمة_النموذج", "tooltip": "يجب أن يكون نموذج Tripo الإصدار 1.4" } }, "outputs": { "0": { "name": "ملف_النموذج", "tooltip": null }, "1": { "name": "معرف_مهمة_النموذج", "tooltip": null } } };
const TripoRetargetNode = { "display_name": "Tripo: إعادة توجيه النموذج المجهز", "inputs": { "animation": { "name": "الرسوم_المتحركة" }, "original_model_task_id": { "name": "معرف_مهمة_النموذج_الأصلي" } }, "outputs": { "0": { "name": "ملف_النموذج", "tooltip": null }, "1": { "name": "معرف_مهمة_إعادة_التوجيه", "tooltip": null } } };
const TripoRigNode = { "display_name": "Tripo: تجهيز النموذج", "inputs": { "original_model_task_id": { "name": "معرف_مهمة_النموذج_الأصلي" } }, "outputs": { "0": { "name": "ملف_النموذج", "tooltip": null }, "1": { "name": "معرف_مهمة_التجهيز", "tooltip": null } } };
const TripoTextToModelNode = { "display_name": "Tripo: النص إلى نموذج", "inputs": { "face_limit": { "name": "حد_الوجه" }, "image_seed": { "name": "بذرة_الصورة" }, "model_seed": { "name": "بذرة_النموذج" }, "model_version": { "name": "إصدار_النموذج" }, "negative_prompt": { "name": "النص_السلبي" }, "pbr": { "name": "PBR" }, "prompt": { "name": "المطالبة" }, "quad": { "name": "رباعي" }, "style": { "name": "النمط" }, "texture": { "name": "الملمس" }, "texture_quality": { "name": "جودة_الملمس" }, "texture_seed": { "name": "بذرة_الملمس" } }, "outputs": { "0": { "name": "ملف_النموذج", "tooltip": null }, "1": { "name": "معرف_مهمة_النموذج", "tooltip": null } } };
const TripoTextureNode = { "display_name": "Tripo: نموذج الملمس", "inputs": { "model_task_id": { "name": "معرف_مهمة_النموذج" }, "pbr": { "name": "PBR" }, "texture": { "name": "الملمس" }, "texture_alignment": { "name": "محاذاة_الملمس" }, "texture_quality": { "name": "جودة_الملمس" }, "texture_seed": { "name": "بذرة_الملمس" } }, "outputs": { "0": { "name": "ملف_النموذج", "tooltip": null }, "1": { "name": "معرف_مهمة_النموذج", "tooltip": null } } };
const UNETLoader = { "display_name": "تحميل نموذج الانتشار", "inputs": { "unet_name": { "name": "اسم UNet" }, "weight_dtype": { "name": "نوع بيانات الوزن" } } };
const UNetCrossAttentionMultiply = { "display_name": "ضرب انتباه التداخل لـ UNet", "inputs": { "k": { "name": "k" }, "model": { "name": "النموذج" }, "out": { "name": "الناتج" }, "q": { "name": "q" }, "v": { "name": "v" } }, "outputs": { "0": { "tooltip": null } } };
const UNetSelfAttentionMultiply = { "display_name": "ضرب انتباه الذات لـ UNet", "inputs": { "k": { "name": "k" }, "model": { "name": "النموذج" }, "out": { "name": "الناتج" }, "q": { "name": "q" }, "v": { "name": "v" } }, "outputs": { "0": { "tooltip": null } } };
const UNetTemporalAttentionMultiply = { "display_name": "ضرب الانتباه الزمني لـ UNet", "inputs": { "cross_structural": { "name": "التركيب المتقاطع" }, "cross_temporal": { "name": "الزمن المتقاطع" }, "model": { "name": "النموذج" }, "self_structural": { "name": "التركيب الذاتي" }, "self_temporal": { "name": "الزمن الذاتي" } }, "outputs": { "0": { "tooltip": null } } };
const USOStyleReference = { "display_name": "مرجع_النمط_USO", "inputs": { "clip_vision_output": { "name": "مخرج_رؤية_CLIP" }, "model": { "name": "النموذج" }, "model_patch": { "name": "تصحيح_النموذج" } } };
const UpscaleModelLoader = { "display_name": "تحميل نموذج التكبير", "inputs": { "model_name": { "name": "اسم النموذج" } }, "outputs": { "0": { "tooltip": null } } };
const VAEDecode = { "description": "يقوم بفك ترميز الصور الكامنة إلى صور في فضاء البكسل.", "display_name": "فك ترميز VAE", "inputs": { "samples": { "name": "عينات", "tooltip": "الكامن المراد فك ترميزه." }, "vae": { "name": "vae", "tooltip": "نموذج VAE المستخدم لفك ترميز الكامن." } }, "outputs": { "0": { "tooltip": "الصورة المفكوكة الترميز." } } };
const VAEDecodeAudio = { "display_name": "فك ترميز VAE للصوت", "inputs": { "samples": { "name": "عينات" }, "vae": { "name": "vae" } } };
const VAEDecodeHunyuan3D = { "display_name": "فك ترميز VAE Hunyuan3D", "inputs": { "num_chunks": { "name": "عدد القطع" }, "octree_resolution": { "name": "دقة شجرة الثماني" }, "samples": { "name": "عينات" }, "vae": { "name": "vae" } } };
const VAEDecodeTiled = { "display_name": "فك ترميز VAE (مبسط)", "inputs": { "overlap": { "name": "التداخل" }, "samples": { "name": "عينات" }, "temporal_overlap": { "name": "التداخل الزمني", "tooltip": "يستخدم فقط لـ VAEs الفيديو: عدد الإطارات المتداخلة." }, "temporal_size": { "name": "الحجم الزمني", "tooltip": "يستخدم فقط لـ VAEs الفيديو: عدد الإطارات التي يتم فك ترميزها في مرة واحدة." }, "tile_size": { "name": "حجم القطعة" }, "vae": { "name": "vae" } } };
const VAEEncode = { "display_name": "ترميز VAE", "inputs": { "pixels": { "name": "بكسلات" }, "vae": { "name": "vae" } } };
const VAEEncodeAudio = { "display_name": "ترميز VAE للصوت", "inputs": { "audio": { "name": "صوت" }, "vae": { "name": "vae" } } };
const VAEEncodeForInpaint = { "display_name": "ترميز VAE (للتلوين)", "inputs": { "grow_mask_by": { "name": "توسيع القناع بمقدار" }, "mask": { "name": "قناع" }, "pixels": { "name": "بكسلات" }, "vae": { "name": "vae" } } };
const VAEEncodeTiled = { "display_name": "ترميز VAE (مبسط)", "inputs": { "overlap": { "name": "التداخل" }, "pixels": { "name": "بكسلات" }, "temporal_overlap": { "name": "التداخل الزمني", "tooltip": "يستخدم فقط لـ VAEs الفيديو: عدد الإطارات المتداخلة." }, "temporal_size": { "name": "الحجم الزمني", "tooltip": "يستخدم فقط لـ VAEs الفيديو: عدد الإطارات التي يتم ترميزها في مرة واحدة." }, "tile_size": { "name": "حجم القطعة" }, "vae": { "name": "vae" } } };
const VAELoader = { "display_name": "تحميل VAE", "inputs": { "vae_name": { "name": "اسم VAE" } } };
const VAESave = { "display_name": "حفظ VAE", "inputs": { "filename_prefix": { "name": "بادئة اسم الملف" }, "vae": { "name": "vae" } } };
const VPScheduler = { "display_name": "مجدول VP", "inputs": { "beta_d": { "name": "بيتا د" }, "beta_min": { "name": "بيتا الأدنى" }, "eps_s": { "name": "إبسيلون س" }, "steps": { "name": "الخطوات" } } };
const Veo3VideoGenerationNode = { "description": "ينشئ مقاطع فيديو من نصوص وصفية باستخدام واجهة Google Veo 3", "display_name": "إنشاء فيديو Google Veo 3", "inputs": { "aspect_ratio": { "name": "نسبة الأبعاد", "tooltip": "نسبة أبعاد الفيديو الناتج" }, "control_after_generate": { "name": "التحكم بعد الإنشاء" }, "duration_seconds": { "name": "المدة بالثواني", "tooltip": "مدة الفيديو الناتج بالثواني (Veo 3 يدعم 8 ثوانٍ فقط)" }, "enhance_prompt": { "name": "تحسين النص", "tooltip": "ما إذا كان سيتم تحسين النص بمساعدة الذكاء الاصطناعي" }, "generate_audio": { "name": "إنشاء الصوت", "tooltip": "إنشاء صوت للفيديو. مدعوم من جميع نماذج Veo 3." }, "image": { "name": "الصورة", "tooltip": "صورة مرجعية اختيارية لتوجيه إنشاء الفيديو" }, "model": { "name": "النموذج", "tooltip": "نموذج Veo 3 المستخدم لإنشاء الفيديو" }, "negative_prompt": { "name": "النص السلبي", "tooltip": "النص السلبي لتوجيه ما يجب تجنبه في الفيديو" }, "person_generation": { "name": "إنشاء الأشخاص", "tooltip": "ما إذا كان سيتم السماح بإنشاء أشخاص في الفيديو" }, "prompt": { "name": "النص_الوصفي", "tooltip": "الوصف النصي للفيديو" }, "seed": { "name": "البذرة", "tooltip": "بذرة لإنشاء الفيديو (0 للعشوائية)" } }, "outputs": { "0": { "tooltip": null } } };
const VeoVideoGenerationNode = { "description": "ينشئ فيديوهات من وصف نصي باستخدام واجهة Google Veo API", "display_name": "توليد فيديو Google Veo2", "inputs": { "aspect_ratio": { "name": "نسبة العرض إلى الارتفاع", "tooltip": "نسبة العرض إلى الارتفاع للفيديو الناتج" }, "control_after_generate": { "name": "التحكم بعد التوليد" }, "duration_seconds": { "name": "مدة الفيديو بالثواني", "tooltip": "مدة الفيديو الناتج بالثواني" }, "enhance_prompt": { "name": "تعزيز الوصف", "tooltip": "هل يتم تعزيز الوصف بمساعدة الذكاء الاصطناعي" }, "image": { "name": "صورة مرجعية", "tooltip": "صورة مرجعية اختيارية لتوجيه توليد الفيديو" }, "model": { "name": "النموذج", "tooltip": "نموذج Veo 2 المستخدم لإنشاء الفيديو" }, "negative_prompt": { "name": "الوصف السلبي", "tooltip": "الوصف النصي السلبي لتوجيه ما يجب تجنبه في الفيديو" }, "person_generation": { "name": "توليد الأشخاص", "tooltip": "هل يُسمح بتوليد أشخاص في الفيديو" }, "prompt": { "name": "الوصف النصي", "tooltip": "الوصف النصي للفيديو" }, "seed": { "name": "البذرة", "tooltip": "بذرة توليد الفيديو (0 عشوائي)" } }, "outputs": { "0": { "tooltip": null } } };
const VideoLinearCFGGuidance = { "display_name": "توجيه VideoLinearCFG", "inputs": { "min_cfg": { "name": "الحد الأدنى للـ CFG" }, "model": { "name": "النموذج" } } };
const VideoTriangleCFGGuidance = { "display_name": "توجيه VideoTriangleCFG", "inputs": { "min_cfg": { "name": "الحد الأدنى للـ CFG" }, "model": { "name": "النموذج" } } };
const ViduImageToVideoNode = { "description": "إنشاء فيديو من صورة ونص اختياري", "display_name": "إنشاء الفيديو من الصورة باستخدام Vidu", "inputs": { "control_after_generate": { "name": "التحكم بعد التوليد" }, "duration": { "name": "المدة", "tooltip": "مدة الفيديو الناتج بالثواني" }, "image": { "name": "الصورة", "tooltip": "صورة لاستخدامها كإطار بداية للفيديو المُنشأ" }, "model": { "name": "النموذج", "tooltip": "اسم النموذج" }, "movement_amplitude": { "name": "سعة الحركة", "tooltip": "سعة حركة الكائنات في الإطار" }, "prompt": { "name": "النص", "tooltip": "وصف نصي لإنشاء الفيديو" }, "resolution": { "name": "الدقة", "tooltip": "القيم المدعومة قد تختلف حسب النموذج والمدة" }, "seed": { "name": "البذرة", "tooltip": "البذرة لتوليد الفيديو (0 للعشوائية)" } }, "outputs": { "0": { "tooltip": null } } };
const ViduReferenceVideoNode = { "description": "توليد فيديو من صور متعددة وموجه نصي", "display_name": "مرجع Vidu لتوليد الفيديو", "inputs": { "aspect_ratio": { "name": "نسبة الأبعاد", "tooltip": "نسبة أبعاد الفيديو الناتج" }, "control_after_generate": { "name": "التحكم بعد التوليد" }, "duration": { "name": "المدة", "tooltip": "مدة الفيديو الناتج بالثواني" }, "images": { "name": "الصور", "tooltip": "الصور المستخدمة كمراجع لتوليد فيديو بمواضيع متسقة (بحد أقصى 7 صور)." }, "model": { "name": "النموذج", "tooltip": "اسم النموذج" }, "movement_amplitude": { "name": "سعة الحركة", "tooltip": "سعة حركة الكائنات في الإطار" }, "prompt": { "name": "الموجه النصي", "tooltip": "وصف نصي لتوليد الفيديو" }, "resolution": { "name": "الدقة", "tooltip": "القيم المدعومة قد تختلف حسب النموذج والمدة" }, "seed": { "name": "البذرة", "tooltip": "البذرة لتوليد الفيديو (0 للعشوائية)" } }, "outputs": { "0": { "tooltip": null } } };
const ViduStartEndToVideoNode = { "description": "توليد فيديو من إطارات البداية والنهاية وموجه نصي", "display_name": "بداية ونهاية Vidu لتوليد الفيديو", "inputs": { "control_after_generate": { "name": "التحكم بعد التوليد" }, "duration": { "name": "المدة", "tooltip": "مدة الفيديو الناتج بالثواني" }, "end_frame": { "name": "إطار النهاية", "tooltip": "إطار النهاية" }, "first_frame": { "name": "الإطار الأول", "tooltip": "إطار البداية" }, "model": { "name": "النموذج", "tooltip": "اسم النموذج" }, "movement_amplitude": { "name": "سعة الحركة", "tooltip": "سعة حركة الكائنات في الإطار" }, "prompt": { "name": "النص التوجيهي", "tooltip": "وصف نصي لتوليد الفيديو" }, "resolution": { "name": "الدقة", "tooltip": "القيم المدعومة قد تختلف حسب النموذج والمدة" }, "seed": { "name": "البذرة", "tooltip": "بذرة توليد الفيديو (0 للعشوائية)" } }, "outputs": { "0": { "tooltip": null } } };
const ViduTextToVideoNode = { "description": "توليد فيديو من النص التوجيهي", "display_name": "توليد الفيديو من النص - Vidu", "inputs": { "aspect_ratio": { "name": "نسبة الأبعاد", "tooltip": "نسبة أبعاد الفيديو الناتج" }, "control_after_generate": { "name": "التحكم بعد التوليد" }, "duration": { "name": "المدة", "tooltip": "مدة الفيديو الناتج بالثواني" }, "model": { "name": "النموذج", "tooltip": "اسم النموذج" }, "movement_amplitude": { "name": "سعة_الحركة", "tooltip": "سعة حركة الكائنات في الإطار" }, "prompt": { "name": "النص التوجيهي", "tooltip": "وصف نصي لتوليد الفيديو" }, "resolution": { "name": "الدقة", "tooltip": "القيم المدعومة قد تختلف حسب النموذج والمدة" }, "seed": { "name": "البذرة", "tooltip": "بذرة توليد الفيديو (0 للعشوائية)" } }, "outputs": { "0": { "tooltip": null } } };
const VoxelToMesh = { "display_name": "تحويل الفوكسل إلى شبكة", "inputs": { "algorithm": { "name": "الخوارزمية" }, "threshold": { "name": "العَتَبة" }, "voxel": { "name": "فوكسل" } } };
const VoxelToMeshBasic = { "display_name": "تحويل الفوكسل إلى شبكة أساسية", "inputs": { "threshold": { "name": "العَتَبة" }, "voxel": { "name": "فوكسل" } } };
const Wan22FunControlToVideo = { "display_name": "Wan22FunControlToVideo", "inputs": { "batch_size": { "name": "حجم_الدفعة" }, "control_video": { "name": "فيديو_تحكم" }, "height": { "name": "الارتفاع" }, "length": { "name": "الطول" }, "negative": { "name": "سلبي" }, "positive": { "name": "إيجابي" }, "ref_image": { "name": "صورة_مرجعية" }, "vae": { "name": "vae" }, "width": { "name": "العرض" } }, "outputs": { "0": { "name": "إيجابي", "tooltip": null }, "1": { "name": "سلبي", "tooltip": null }, "2": { "name": "كامن", "tooltip": null } } };
const Wan22ImageToVideoLatent = { "display_name": "Wan22ImageToVideoLatent", "inputs": { "batch_size": { "name": "حجم_الدفعة" }, "height": { "name": "الارتفاع" }, "length": { "name": "الطول" }, "start_image": { "name": "صورة_البداية" }, "vae": { "name": "vae" }, "width": { "name": "العرض" } }, "outputs": { "0": { "tooltip": null } } };
const WanAnimateToVideo = { "display_name": "WanAnimateToVideo", "inputs": { "background_video": { "name": "فيديو_الخلفية" }, "batch_size": { "name": "حجم_الدفعة" }, "character_mask": { "name": "قناع_الشخصية" }, "clip_vision_output": { "name": "مخرج_رؤية_المقطع" }, "continue_motion": { "name": "مواصلة_الحركة" }, "continue_motion_max_frames": { "name": "الحد_الأقصى_لإطارات_الحركة_المستمرة" }, "face_video": { "name": "فيديو_الوجه" }, "height": { "name": "الارتفاع" }, "length": { "name": "الطول" }, "negative": { "name": "سلبي" }, "pose_video": { "name": "فيديو_الوضعية" }, "positive": { "name": "إيجابي" }, "reference_image": { "name": "صورة_مرجعية" }, "vae": { "name": "vae" }, "video_frame_offset": { "name": "إزاحة_إطار_الفيديو", "tooltip": "عدد الإطارات التي يجب البحث عنها في جميع مقاطع الفيديو المدخلة. يُستخدم لتوليد مقاطع فيديو أطول عن طريق التقسيم. قم بالاتصال بمخرج إزاحة_إطار_الفيديو للعقدة السابقة لتمديد مقطع فيديو." }, "width": { "name": "العرض" } }, "outputs": { "0": { "name": "إيجابي", "tooltip": null }, "1": { "name": "سلبي", "tooltip": null }, "2": { "name": "كامن", "tooltip": null }, "3": { "name": "قص_الكامن", "tooltip": null }, "4": { "name": "قص_الصورة", "tooltip": null }, "5": { "name": "إزاحة_إطار_الفيديو", "tooltip": null } } };
const WanCameraEmbedding = { "display_name": "تضمين_كاميرا_Wan", "inputs": { "camera_pose": { "name": "وضعية_الكاميرا" }, "cx": { "name": "cx" }, "cy": { "name": "cy" }, "fx": { "name": "fx" }, "fy": { "name": "fy" }, "height": { "name": "الارتفاع" }, "length": { "name": "الطول" }, "speed": { "name": "السرعة" }, "width": { "name": "العرض" } }, "outputs": { "0": { "name": "تضمين_الكاميرا", "tooltip": null }, "1": { "name": "العرض", "tooltip": null }, "2": { "name": "الارتفاع", "tooltip": null }, "3": { "name": "الطول", "tooltip": null } } };
const WanCameraImageToVideo = { "display_name": "WanCameraImageToVideo", "inputs": { "batch_size": { "name": "حجم الدُفعة" }, "camera_conditions": { "name": "شروط الكاميرا" }, "clip_vision_output": { "name": "خرج رؤية CLIP" }, "height": { "name": "الارتفاع" }, "length": { "name": "الطول" }, "negative": { "name": "سلبي" }, "positive": { "name": "إيجابي" }, "start_image": { "name": "الصورة البداية" }, "vae": { "name": "vae" }, "width": { "name": "العرض" } }, "outputs": { "0": { "name": "إيجابي", "tooltip": null }, "1": { "name": "سلبي", "tooltip": null }, "2": { "name": "كامن", "tooltip": null } } };
const WanContextWindowsManual = { "description": "تعيين نوافذ السياق يدويًا للنماذج الشبيهة بـ WAN (dim=2).", "display_name": "نوافذ سياق WAN (يدوي)", "inputs": { "closed_loop": { "name": "حلقة مغلقة", "tooltip": "ما إذا كان سيتم إغلاق حلقة نافذة السياق؛ تنطبق فقط على الجداول الحلقية." }, "context_length": { "name": "طول السياق", "tooltip": "طول نافذة السياق." }, "context_overlap": { "name": "تداخل السياق", "tooltip": "تداخل نافذة السياق." }, "context_schedule": { "name": "جدول السياق", "tooltip": "خطوة نافذة السياق." }, "context_stride": { "name": "خطوة السياق", "tooltip": "خطوة نافذة السياق؛ تنطبق فقط على الجداول المنتظمة." }, "fuse_method": { "name": "طريقة الدمج", "tooltip": "الطريقة المستخدمة لدمج نوافذ السياق." }, "model": { "name": "النموذج", "tooltip": "النموذج المراد تطبيق نوافذ السياق عليه أثناء أخذ العينات." } }, "outputs": { "0": { "tooltip": "النموذج مع نوافذ السياق المطبقة أثناء أخذ العينات." } } };
const WanFirstLastFrameToVideo = { "display_name": "وان إطار أول وآخر إلى فيديو", "inputs": { "batch_size": { "name": "حجم الدفعة" }, "clip_vision_end_image": { "name": "صورة نهاية رؤية الكليب" }, "clip_vision_start_image": { "name": "صورة بداية رؤية الكليب" }, "end_image": { "name": "صورة النهاية" }, "height": { "name": "الارتفاع" }, "length": { "name": "الطول" }, "negative": { "name": "سلبي" }, "positive": { "name": "إيجابي" }, "start_image": { "name": "صورة البداية" }, "vae": { "name": "vae" }, "width": { "name": "العرض" } }, "outputs": { "0": { "name": "إيجابي", "tooltip": null }, "1": { "name": "سلبي", "tooltip": null }, "2": { "name": "مضمر", "tooltip": null } } };
const WanFunControlToVideo = { "display_name": "وان تحكم ممتع إلى فيديو", "inputs": { "batch_size": { "name": "حجم الدفعة" }, "clip_vision_output": { "name": "ناتج رؤية الكليب" }, "control_video": { "name": "فيديو التحكم" }, "height": { "name": "الارتفاع" }, "length": { "name": "الطول" }, "negative": { "name": "سلبي" }, "positive": { "name": "إيجابي" }, "start_image": { "name": "صورة البداية" }, "vae": { "name": "vae" }, "width": { "name": "العرض" } }, "outputs": { "0": { "name": "إيجابي", "tooltip": null }, "1": { "name": "سلبي", "tooltip": null }, "2": { "name": "مضمر", "tooltip": null } } };
const WanFunInpaintToVideo = { "display_name": "وان تلوين ممتع إلى فيديو", "inputs": { "batch_size": { "name": "حجم الدفعة" }, "clip_vision_output": { "name": "ناتج رؤية الكليب" }, "end_image": { "name": "صورة النهاية" }, "height": { "name": "الارتفاع" }, "length": { "name": "الطول" }, "negative": { "name": "سلبي" }, "positive": { "name": "إيجابي" }, "start_image": { "name": "صورة البداية" }, "vae": { "name": "vae" }, "width": { "name": "العرض" } }, "outputs": { "0": { "name": "إيجابي", "tooltip": null }, "1": { "name": "سلبي", "tooltip": null }, "2": { "name": "مضمر", "tooltip": null } } };
const WanHuMoImageToVideo = { "display_name": "وان هو مو صورة إلى فيديو", "inputs": { "audio_encoder_output": { "name": "مخرج_مشفر_الصوت" }, "batch_size": { "name": "حجم_الدفعة" }, "height": { "name": "الارتفاع" }, "length": { "name": "الطول" }, "negative": { "name": "سلبي" }, "positive": { "name": "إيجابي" }, "ref_image": { "name": "صورة_مرجعية" }, "vae": { "name": "vae" }, "width": { "name": "العرض" } }, "outputs": { "0": { "name": "إيجابي", "tooltip": null }, "1": { "name": "سلبي", "tooltip": null }, "2": { "name": "كامن", "tooltip": null } } };
const WanImageToImageApi = { "description": "ينشئ صورة من صورة أو صورتين إدخال ونص توجيهي. حجم الصورة الناتج ثابت حاليًا عند 1.6 ميغابكسل؛ نسبة العرض إلى الارتفاع تتطابق مع صورة/صور الإدخال.", "display_name": "وان صورة إلى صورة", "inputs": { "control_after_generate": { "name": "التحكم بعد التوليد" }, "image": { "name": "صورة", "tooltip": "تحرير صورة واحدة أو دمج صور متعددة، بحد أقصى صورتين." }, "model": { "name": "نموذج", "tooltip": "النموذج المستخدم." }, "negative_prompt": { "name": "توجيه_سلبي", "tooltip": "النص التوجيهي السلبي لتوجيه ما يجب تجنبه." }, "prompt": { "name": "توجيه", "tooltip": "النص التوجيهي المستخدم لوصف العناصر والميزات البصرية، يدعم الإنجليزية/الصينية." }, "seed": { "name": "بذرة", "tooltip": "البذرة المستخدمة في التوليد." }, "watermark": { "name": "علامة_مائية", "tooltip": 'ما إذا كان سيتم إضافة علامة مائية "منتجة بالذكاء الاصطناعي" إلى النتيجة.' } }, "outputs": { "0": { "tooltip": null } } };
const WanImageToVideo = { "display_name": "وان صورة إلى فيديو", "inputs": { "batch_size": { "name": "حجم الدفعة" }, "clip_vision_output": { "name": "ناتج رؤية الكليب" }, "height": { "name": "الارتفاع" }, "length": { "name": "الطول" }, "negative": { "name": "سلبي" }, "positive": { "name": "إيجابي" }, "start_image": { "name": "صورة البداية" }, "vae": { "name": "vae" }, "width": { "name": "العرض" } }, "outputs": { "0": { "name": "إيجابي", "tooltip": null }, "1": { "name": "سلبي", "tooltip": null }, "2": { "name": "مضمر", "tooltip": null } } };
const WanImageToVideoApi = { "description": "ينشئ فيديو بناءً على الإطار الأول والنص الموجه.", "display_name": "وان صورة إلى فيديو", "inputs": { "audio": { "name": "الصوت", "tooltip": "يجب أن يحتوي الصوت على صوت واضح وعالٍ، بدون ضوضاء خارجية أو موسيقى خلفية." }, "control_after_generate": { "name": "التحكم بعد التوليد" }, "duration": { "name": "المدة", "tooltip": "المدد المتاحة: 5 و 10 ثوانٍ" }, "generate_audio": { "name": "توليد الصوت", "tooltip": "إذا لم يكن هناك مدخل صوتي، قم بتوليد الصوت تلقائيًا." }, "image": { "name": "الصورة" }, "model": { "name": "النموذج", "tooltip": "النموذج المستخدم." }, "negative_prompt": { "name": "النص الموجه السلبي", "tooltip": "النص الموجه السلبي لتوجيه ما يجب تجنبه." }, "prompt": { "name": "النص الموجه", "tooltip": "النص المستخدم لوصف العناصر والميزات البصرية، يدعم الإنجليزية/الصينية." }, "prompt_extend": { "name": "توسيع النص الموجه", "tooltip": "ما إذا كان سيتم تحسين النص الموجه بمساعدة الذكاء الاصطناعي." }, "resolution": { "name": "الدقة" }, "seed": { "name": "البذرة", "tooltip": "البذرة المستخدمة في التوليد." }, "watermark": { "name": "علامة مائية", "tooltip": 'ما إذا كان سيتم إضافة علامة مائية "تم إنشاؤها بالذكاء الاصطناعي" على النتيجة.' } }, "outputs": { "0": { "tooltip": null } } };
const WanPhantomSubjectToVideo = { "display_name": "وان فانتوم موضوع إلى فيديو", "inputs": { "batch_size": { "name": "حجم الدُفعة" }, "height": { "name": "الارتفاع" }, "images": { "name": "الصور" }, "length": { "name": "الطول" }, "negative": { "name": "سلبي" }, "positive": { "name": "إيجابي" }, "vae": { "name": "vae" }, "width": { "name": "العرض" } }, "outputs": { "0": { "name": "النص الإيجابي", "tooltip": null }, "1": { "name": "النص السلبي", "tooltip": null }, "2": { "name": "نص الصورة السلبية", "tooltip": null }, "3": { "name": "الكامن", "tooltip": null } } };
const WanSoundImageToVideo = { "display_name": "WanSoundImageToVideo", "inputs": { "audio_encoder_output": { "name": "مخرج مشفر الصوت" }, "batch_size": { "name": "حجم الدُفعة" }, "control_video": { "name": "الفيديو المتحكم به" }, "height": { "name": "الارتفاع" }, "length": { "name": "الطول" }, "negative": { "name": "النص السلبي" }, "positive": { "name": "النص الإيجابي" }, "ref_image": { "name": "الصورة المرجعية" }, "ref_motion": { "name": "الحركة المرجعية" }, "vae": { "name": "VAE" }, "width": { "name": "العرض" } }, "outputs": { "0": { "name": "النص الإيجابي", "tooltip": null }, "1": { "name": "النص السلبي", "tooltip": null }, "2": { "name": "الكامن", "tooltip": null } } };
const WanSoundImageToVideoExtend = { "display_name": "WanSoundImageToVideoExtend", "inputs": { "audio_encoder_output": { "name": "مخرج مشفر الصوت" }, "control_video": { "name": "الفيديو المتحكم به" }, "length": { "name": "الطول" }, "negative": { "name": "النص السلبي" }, "positive": { "name": "النص الإيجابي" }, "ref_image": { "name": "الصورة المرجعية" }, "vae": { "name": "VAE" }, "video_latent": { "name": "الكامن للفيديو" } }, "outputs": { "0": { "name": "إيجابي", "tooltip": null }, "1": { "name": "سلبي", "tooltip": null }, "2": { "name": "كامن", "tooltip": null } } };
const WanTextToImageApi = { "description": "ينشئ صورة بناءً على نص موجه.", "display_name": "وان من النص إلى الصورة", "inputs": { "control_after_generate": { "name": "التحكم بعد الإنشاء" }, "height": { "name": "الارتفاع" }, "model": { "name": "نموذج", "tooltip": "النموذج المستخدم." }, "negative_prompt": { "name": "نص موجه سلبي", "tooltip": "نص موجه سلبي لتوجيه ما يجب تجنبه." }, "prompt": { "name": "نص موجه", "tooltip": "النص الموجه المستخدم لوصف العناصر والميزات المرئية، يدعم الإنجليزية/الصينية." }, "prompt_extend": { "name": "توسيع النص الموجه", "tooltip": "ما إذا كان سيتم تحسين النص الموجه بمساعدة الذكاء الاصطناعي." }, "seed": { "name": "بذرة", "tooltip": "البذرة المستخدمة في الإنشاء." }, "watermark": { "name": "علامة مائية", "tooltip": 'ما إذا كان سيتم إضافة علامة مائية "منشأة بالذكاء الاصطناعي" إلى النتيجة.' }, "width": { "name": "العرض" } }, "outputs": { "0": { "tooltip": null } } };
const WanTextToVideoApi = { "description": "ينشئ فيديو بناءً على نص موجه.", "display_name": "وان من النص إلى الفيديو", "inputs": { "audio": { "name": "صوت", "tooltip": "يجب أن يحتوي الصوت على صوت واضح وعالٍ، دون ضوضاء خارجية أو موسيقى خلفية." }, "control_after_generate": { "name": "التحكم بعد التوليد" }, "duration": { "name": "المدة", "tooltip": "المدد المتاحة: 5 و 10 ثوانٍ" }, "generate_audio": { "name": "توليد_صوت", "tooltip": "إذا لم يكن هناك مدخل صوتي، قم بتوليد الصوت تلقائيًا." }, "model": { "name": "نموذج", "tooltip": "النموذج المستخدم." }, "negative_prompt": { "name": "نص موجه سلبي", "tooltip": "النص الموجه السلبي لتوجيه ما يجب تجنبه." }, "prompt": { "name": "نص موجه", "tooltip": "النص الموجه المستخدم لوصف العناصر والميزات المرئية، يدعم الإنجليزية/الصينية." }, "prompt_extend": { "name": "توسيع_المطالبة", "tooltip": "ما إذا كان سيتم تحسين المطالبة بمساعدة الذكاء الاصطناعي." }, "seed": { "name": "بذرة", "tooltip": "البذرة المستخدمة في التوليد." }, "size": { "name": "الحجم" }, "watermark": { "name": "علامة_مائية", "tooltip": 'ما إذا كان سيتم إضافة علامة مائية "تم توليدها بالذكاء الاصطناعي" إلى النتيجة.' } }, "outputs": { "0": { "tooltip": null } } };
const WanTrackToVideo = { "display_name": "تتبع_الفيديو", "inputs": { "batch_size": { "name": "حجم_الدفعة" }, "clip_vision_output": { "name": "مخرج_رؤية_المقطع" }, "height": { "name": "ارتفاع" }, "length": { "name": "طول" }, "negative": { "name": "سلبي" }, "positive": { "name": "إيجابي" }, "start_image": { "name": "صورة_البداية" }, "temperature": { "name": "درجة_الحرارة" }, "topk": { "name": "أعلى_ك" }, "tracks": { "name": "مسارات" }, "vae": { "name": "vae" }, "width": { "name": "عرض" } }, "outputs": { "0": { "name": "إيجابي", "tooltip": null }, "1": { "name": "سلبي", "tooltip": null }, "2": { "name": "كامن", "tooltip": null } } };
const WanVaceToVideo = { "display_name": "وان Vace إلى فيديو", "inputs": { "batch_size": { "name": "حجم الدفعة" }, "control_masks": { "name": "أقنعة التحكم" }, "control_video": { "name": "فيديو التحكم" }, "height": { "name": "الارتفاع" }, "length": { "name": "الطول" }, "negative": { "name": "سلبي" }, "positive": { "name": "إيجابي" }, "reference_image": { "name": "صورة مرجعية" }, "strength": { "name": "القوة" }, "vae": { "name": "vae" }, "width": { "name": "العرض" } }, "outputs": { "0": { "name": "إيجابي", "tooltip": null }, "1": { "name": "سلبي", "tooltip": null }, "2": { "name": "مضمر", "tooltip": null }, "3": { "name": "اقتطاع المضمر", "tooltip": null } } };
const WebcamCapture = { "display_name": "التقاط كاميرا ويب", "inputs": { "capture_on_queue": { "name": "التقاط في الطابور" }, "height": { "name": "الارتفاع" }, "image": { "name": "صورة" }, "waiting for camera___": {}, "width": { "name": "العرض" } } };
const unCLIPCheckpointLoader = { "display_name": "محمل نقطة فحص unCLIP", "inputs": { "ckpt_name": { "name": "اسم نقطة الفحص" } } };
const unCLIPConditioning = { "display_name": "تكييف unCLIP", "inputs": { "clip_vision_output": { "name": "ناتج رؤية الكليب" }, "conditioning": { "name": "التكييف" }, "noise_augmentation": { "name": "زيادة الضجيج" }, "strength": { "name": "القوة" } } };
const nodeDefs = {
  APG,
  AddNoise,
  AlignYourStepsScheduler,
  AudioAdjustVolume,
  AudioConcat,
  AudioEncoderEncode,
  AudioEncoderLoader,
  AudioMerge,
  BasicGuider,
  BasicScheduler,
  BetaSamplingScheduler,
  ByteDanceFirstLastFrameNode,
  ByteDanceImageEditNode,
  ByteDanceImageNode,
  ByteDanceImageReferenceNode,
  ByteDanceImageToVideoNode,
  ByteDanceSeedreamNode,
  ByteDanceTextToVideoNode,
  CFGGuider,
  CFGNorm,
  CFGZeroStar,
  CLIPAttentionMultiply,
  CLIPLoader,
  CLIPMergeAdd,
  CLIPMergeSimple,
  CLIPMergeSubtract,
  CLIPSave,
  CLIPSetLastLayer,
  CLIPTextEncode,
  CLIPTextEncodeControlnet,
  CLIPTextEncodeFlux,
  CLIPTextEncodeHiDream,
  CLIPTextEncodeHunyuanDiT,
  CLIPTextEncodeLumina2,
  CLIPTextEncodePixArtAlpha,
  CLIPTextEncodeSD3,
  CLIPTextEncodeSDXL,
  CLIPTextEncodeSDXLRefiner,
  CLIPVisionEncode,
  CLIPVisionLoader,
  Canny,
  CaseConverter,
  CheckpointLoader,
  CheckpointLoaderSimple,
  CheckpointSave,
  ChromaRadianceOptions,
  CombineHooks2,
  CombineHooks4,
  CombineHooks8,
  ConditioningAverage,
  ConditioningCombine,
  ConditioningConcat,
  ConditioningSetArea,
  ConditioningSetAreaPercentage,
  ConditioningSetAreaPercentageVideo,
  ConditioningSetAreaStrength,
  ConditioningSetDefaultCombine,
  ConditioningSetMask,
  ConditioningSetProperties,
  ConditioningSetPropertiesAndCombine,
  ConditioningSetTimestepRange,
  ConditioningStableAudio,
  ConditioningTimestepsRange,
  ConditioningZeroOut,
  ContextWindowsManual,
  ControlNetApply,
  ControlNetApplyAdvanced,
  ControlNetApplySD3,
  ControlNetInpaintingAliMamaApply,
  ControlNetLoader,
  CosmosImageToVideoLatent,
  CosmosPredict2ImageToVideoLatent,
  CreateHookKeyframe,
  CreateHookKeyframesFromFloats,
  CreateHookKeyframesInterpolated,
  CreateHookLora,
  CreateHookLoraModelOnly,
  CreateHookModelAsLora,
  CreateHookModelAsLoraModelOnly,
  CreateVideo,
  CropMask,
  DiffControlNetLoader,
  DifferentialDiffusion,
  DiffusersLoader,
  DisableNoise,
  DualCFGGuider,
  DualCLIPLoader,
  EasyCache,
  EmptyAceStepLatentAudio,
  EmptyAudio,
  EmptyChromaRadianceLatentImage,
  EmptyCosmosLatentVideo,
  EmptyHunyuanImageLatent,
  EmptyHunyuanLatentVideo,
  EmptyImage,
  EmptyLTXVLatentVideo,
  EmptyLatentAudio,
  EmptyLatentHunyuan3Dv2,
  EmptyLatentImage,
  EmptyMochiLatentVideo,
  EmptySD3LatentImage,
  "Epsilon Scaling": { "display_name": "تحجيم إبسيلون", "inputs": { "model": { "name": "النموذج" }, "scaling_factor": { "name": "معامل_التحجيم" } }, "outputs": { "0": { "tooltip": null } } },
  ExponentialScheduler,
  ExtendIntermediateSigmas,
  FeatherMask,
  FlipSigmas,
  FluxDisableGuidance,
  FluxGuidance,
  FluxKontextImageScale,
  FluxKontextMaxImageNode,
  FluxKontextMultiReferenceLatentMethod,
  FluxKontextProImageNode,
  FluxProExpandNode,
  FluxProFillNode,
  FluxProUltraImageNode,
  FreSca,
  FreeU,
  FreeU_V2,
  GITSScheduler,
  GLIGENLoader,
  GLIGENTextBoxApply,
  GeminiImageNode,
  GeminiInputFiles,
  GeminiNode,
  GetImageSize,
  GetVideoComponents,
  GrowMask,
  Hunyuan3Dv2Conditioning,
  Hunyuan3Dv2ConditioningMultiView,
  HunyuanImageToVideo,
  HunyuanRefinerLatent,
  HyperTile,
  HypernetworkLoader,
  IdeogramV1,
  IdeogramV2,
  IdeogramV3,
  ImageAddNoise,
  ImageBatch,
  ImageBlend,
  ImageBlur,
  ImageColorToMask,
  ImageCompositeMasked,
  ImageCrop,
  ImageFlip,
  ImageFromBatch,
  ImageInvert,
  ImageOnlyCheckpointLoader,
  ImageOnlyCheckpointSave,
  ImagePadForOutpaint,
  ImageQuantize,
  ImageRGBToYUV,
  ImageRotate,
  ImageScale,
  ImageScaleBy,
  ImageScaleToMaxDimension,
  ImageScaleToTotalPixels,
  ImageSharpen,
  ImageStitch,
  ImageToMask,
  ImageUpscaleWithModel,
  ImageYUVToRGB,
  InpaintModelConditioning,
  InstructPixToPixConditioning,
  InvertMask,
  JoinImageWithAlpha,
  KSampler,
  KSamplerAdvanced,
  KSamplerSelect,
  KarrasScheduler,
  KlingCameraControlI2VNode,
  KlingCameraControlT2VNode,
  KlingCameraControls,
  KlingDualCharacterVideoEffectNode,
  KlingImage2VideoNode,
  KlingImageGenerationNode,
  KlingLipSyncAudioToVideoNode,
  KlingLipSyncTextToVideoNode,
  KlingSingleImageVideoEffectNode,
  KlingStartEndFrameNode,
  KlingTextToVideoNode,
  KlingVideoExtendNode,
  KlingVirtualTryOnNode,
  LTXVAddGuide,
  LTXVConditioning,
  LTXVCropGuides,
  LTXVImgToVideo,
  LTXVPreprocess,
  LTXVScheduler,
  LaplaceScheduler,
  LatentAdd,
  LatentApplyOperation,
  LatentApplyOperationCFG,
  LatentBatch,
  LatentBatchSeedBehavior,
  LatentBlend,
  LatentComposite,
  LatentCompositeMasked,
  LatentConcat,
  LatentCrop,
  LatentCut,
  LatentFlip,
  LatentFromBatch,
  LatentInterpolate,
  LatentMultiply,
  LatentOperationSharpen,
  LatentOperationTonemapReinhard,
  LatentRotate,
  LatentSubtract,
  LatentUpscale,
  LatentUpscaleBy,
  LazyCache,
  Load3D,
  LoadAudio,
  LoadImage,
  LoadImageMask,
  LoadImageOutput,
  LoadLatent,
  LoadVideo,
  LoraLoader,
  LoraLoaderModelOnly,
  LoraModelLoader,
  LoraSave,
  LossGraphNode,
  LotusConditioning,
  LtxvApiImageToVideo,
  LtxvApiTextToVideo,
  LumaConceptsNode,
  LumaImageModifyNode,
  LumaImageNode,
  LumaImageToVideoNode,
  LumaReferenceNode,
  LumaVideoNode,
  Mahiro,
  MaskComposite,
  MaskPreview,
  MaskToImage,
  MinimaxHailuoVideoNode,
  MinimaxImageToVideoNode,
  MinimaxTextToVideoNode,
  ModelComputeDtype,
  ModelMergeAdd,
  ModelMergeAuraflow,
  ModelMergeBlocks,
  ModelMergeCosmos14B,
  ModelMergeCosmos7B,
  ModelMergeCosmosPredict2_14B,
  ModelMergeCosmosPredict2_2B,
  ModelMergeFlux1,
  ModelMergeLTXV,
  ModelMergeMochiPreview,
  ModelMergeQwenImage,
  ModelMergeSD1,
  ModelMergeSD2,
  ModelMergeSD35_Large,
  ModelMergeSD3_2B,
  ModelMergeSDXL,
  ModelMergeSimple,
  ModelMergeSubtract,
  ModelMergeWAN2_1,
  ModelPatchLoader,
  ModelSamplingAuraFlow,
  ModelSamplingContinuousEDM,
  ModelSamplingContinuousV,
  ModelSamplingDiscrete,
  ModelSamplingFlux,
  ModelSamplingLTXV,
  ModelSamplingSD3,
  ModelSamplingStableCascade,
  ModelSave,
  MoonvalleyImg2VideoNode,
  MoonvalleyTxt2VideoNode,
  MoonvalleyVideo2VideoNode,
  Morphology,
  OpenAIChatConfig,
  OpenAIChatNode,
  OpenAIDalle2,
  OpenAIDalle3,
  OpenAIGPTImage1,
  OpenAIInputFiles,
  OpenAIVideoSora2,
  OptimalStepsScheduler,
  PairConditioningCombine,
  PairConditioningSetDefaultCombine,
  PairConditioningSetProperties,
  PairConditioningSetPropertiesAndCombine,
  PatchModelAddDownscale,
  PerpNeg,
  PerpNegGuider,
  PerturbedAttentionGuidance,
  PhotoMakerEncode,
  PhotoMakerLoader,
  PixverseImageToVideoNode,
  PixverseTemplateNode,
  PixverseTextToVideoNode,
  PixverseTransitionVideoNode,
  PolyexponentialScheduler,
  PorterDuffImageComposite,
  Preview3D,
  PreviewAny,
  PreviewAudio,
  PreviewImage,
  PrimitiveBoolean,
  PrimitiveFloat,
  PrimitiveInt,
  PrimitiveString,
  PrimitiveStringMultiline,
  QuadrupleCLIPLoader,
  QwenImageDiffsynthControlnet,
  RandomNoise,
  RebatchImages,
  RebatchLatents,
  RecordAudio,
  RecraftColorRGB,
  RecraftControls,
  RecraftCreativeUpscaleNode,
  RecraftCrispUpscaleNode,
  RecraftImageInpaintingNode,
  RecraftImageToImageNode,
  RecraftRemoveBackgroundNode,
  RecraftReplaceBackgroundNode,
  RecraftStyleV3DigitalIllustration,
  RecraftStyleV3InfiniteStyleLibrary,
  RecraftStyleV3LogoRaster,
  RecraftStyleV3RealisticImage,
  RecraftTextToImageNode,
  RecraftTextToVectorNode,
  RecraftVectorizeImageNode,
  ReferenceLatent,
  RegexExtract,
  RegexMatch,
  RegexReplace,
  RenormCFG,
  RepeatImageBatch,
  RepeatLatentBatch,
  RescaleCFG,
  ResizeAndPadImage,
  Rodin3D_Detail,
  Rodin3D_Gen2,
  Rodin3D_Regular,
  Rodin3D_Sketch,
  Rodin3D_Smooth,
  RunwayFirstLastFrameNode,
  RunwayImageToVideoNodeGen3a,
  RunwayImageToVideoNodeGen4,
  RunwayTextToImageNode,
  SDTurboScheduler,
  SD_4XUpscale_Conditioning,
  SV3D_Conditioning,
  SVD_img2vid_Conditioning,
  SamplerCustom,
  SamplerCustomAdvanced,
  SamplerDPMAdaptative,
  SamplerDPMPP_2M_SDE,
  SamplerDPMPP_2S_Ancestral,
  SamplerDPMPP_3M_SDE,
  SamplerDPMPP_SDE,
  SamplerER_SDE,
  SamplerEulerAncestral,
  SamplerEulerAncestralCFGPP,
  SamplerEulerCFGpp,
  SamplerLCMUpscale,
  SamplerLMS,
  SamplerSASolver,
  SamplingPercentToSigma,
  SaveAnimatedPNG,
  SaveAnimatedWEBP,
  SaveAudio,
  SaveAudioMP3,
  SaveAudioOpus,
  SaveGLB,
  SaveImage,
  SaveImageWebsocket,
  SaveLatent,
  SaveSVGNode,
  SaveVideo,
  SaveWEBM,
  ScaleROPE,
  SelfAttentionGuidance,
  SetClipHooks,
  SetFirstSigma,
  SetHookKeyframes,
  SetLatentNoiseMask,
  SetUnionControlNetType,
  SkipLayerGuidanceDiT,
  SkipLayerGuidanceDiTSimple,
  SkipLayerGuidanceSD3,
  SolidMask,
  SplitAudioChannels,
  SplitImageWithAlpha,
  SplitSigmas,
  SplitSigmasDenoise,
  StabilityAudioInpaint,
  StabilityAudioToAudio,
  StabilityStableImageSD_3_5Node,
  StabilityStableImageUltraNode,
  StabilityTextToAudio,
  StabilityUpscaleConservativeNode,
  StabilityUpscaleCreativeNode,
  StabilityUpscaleFastNode,
  StableCascade_EmptyLatentImage,
  StableCascade_StageB_Conditioning,
  StableCascade_StageC_VAEEncode,
  StableCascade_SuperResolutionControlnet,
  StableZero123_Conditioning,
  StableZero123_Conditioning_Batched,
  StringCompare,
  StringConcatenate,
  StringContains,
  StringLength,
  StringReplace,
  StringSubstring,
  StringTrim,
  StyleModelApply,
  StyleModelLoader,
  T5TokenizerOptions,
  TCFG,
  TemporalScoreRescaling,
  TextEncodeAceStepAudio,
  TextEncodeHunyuanVideo_ImageToVideo,
  TextEncodeQwenImageEdit,
  TextEncodeQwenImageEditPlus,
  ThresholdMask,
  TomePatchModel,
  TorchCompileModel,
  TrainLoraNode,
  TrimAudioDuration,
  TrimVideoLatent,
  TripleCLIPLoader,
  TripoConversionNode,
  TripoImageToModelNode,
  TripoMultiviewToModelNode,
  TripoRefineNode,
  TripoRetargetNode,
  TripoRigNode,
  TripoTextToModelNode,
  TripoTextureNode,
  UNETLoader,
  UNetCrossAttentionMultiply,
  UNetSelfAttentionMultiply,
  UNetTemporalAttentionMultiply,
  USOStyleReference,
  UpscaleModelLoader,
  VAEDecode,
  VAEDecodeAudio,
  VAEDecodeHunyuan3D,
  VAEDecodeTiled,
  VAEEncode,
  VAEEncodeAudio,
  VAEEncodeForInpaint,
  VAEEncodeTiled,
  VAELoader,
  VAESave,
  VPScheduler,
  Veo3VideoGenerationNode,
  VeoVideoGenerationNode,
  VideoLinearCFGGuidance,
  VideoTriangleCFGGuidance,
  ViduImageToVideoNode,
  ViduReferenceVideoNode,
  ViduStartEndToVideoNode,
  ViduTextToVideoNode,
  VoxelToMesh,
  VoxelToMeshBasic,
  Wan22FunControlToVideo,
  Wan22ImageToVideoLatent,
  WanAnimateToVideo,
  WanCameraEmbedding,
  WanCameraImageToVideo,
  WanContextWindowsManual,
  WanFirstLastFrameToVideo,
  WanFunControlToVideo,
  WanFunInpaintToVideo,
  WanHuMoImageToVideo,
  WanImageToImageApi,
  WanImageToVideo,
  WanImageToVideoApi,
  WanPhantomSubjectToVideo,
  WanSoundImageToVideo,
  WanSoundImageToVideoExtend,
  WanTextToImageApi,
  WanTextToVideoApi,
  WanTrackToVideo,
  WanVaceToVideo,
  WebcamCapture,
  unCLIPCheckpointLoader,
  unCLIPConditioning
};
export {
  APG,
  AddNoise,
  AlignYourStepsScheduler,
  AudioAdjustVolume,
  AudioConcat,
  AudioEncoderEncode,
  AudioEncoderLoader,
  AudioMerge,
  BasicGuider,
  BasicScheduler,
  BetaSamplingScheduler,
  ByteDanceFirstLastFrameNode,
  ByteDanceImageEditNode,
  ByteDanceImageNode,
  ByteDanceImageReferenceNode,
  ByteDanceImageToVideoNode,
  ByteDanceSeedreamNode,
  ByteDanceTextToVideoNode,
  CFGGuider,
  CFGNorm,
  CFGZeroStar,
  CLIPAttentionMultiply,
  CLIPLoader,
  CLIPMergeAdd,
  CLIPMergeSimple,
  CLIPMergeSubtract,
  CLIPSave,
  CLIPSetLastLayer,
  CLIPTextEncode,
  CLIPTextEncodeControlnet,
  CLIPTextEncodeFlux,
  CLIPTextEncodeHiDream,
  CLIPTextEncodeHunyuanDiT,
  CLIPTextEncodeLumina2,
  CLIPTextEncodePixArtAlpha,
  CLIPTextEncodeSD3,
  CLIPTextEncodeSDXL,
  CLIPTextEncodeSDXLRefiner,
  CLIPVisionEncode,
  CLIPVisionLoader,
  Canny,
  CaseConverter,
  CheckpointLoader,
  CheckpointLoaderSimple,
  CheckpointSave,
  ChromaRadianceOptions,
  CombineHooks2,
  CombineHooks4,
  CombineHooks8,
  ConditioningAverage,
  ConditioningCombine,
  ConditioningConcat,
  ConditioningSetArea,
  ConditioningSetAreaPercentage,
  ConditioningSetAreaPercentageVideo,
  ConditioningSetAreaStrength,
  ConditioningSetDefaultCombine,
  ConditioningSetMask,
  ConditioningSetProperties,
  ConditioningSetPropertiesAndCombine,
  ConditioningSetTimestepRange,
  ConditioningStableAudio,
  ConditioningTimestepsRange,
  ConditioningZeroOut,
  ContextWindowsManual,
  ControlNetApply,
  ControlNetApplyAdvanced,
  ControlNetApplySD3,
  ControlNetInpaintingAliMamaApply,
  ControlNetLoader,
  CosmosImageToVideoLatent,
  CosmosPredict2ImageToVideoLatent,
  CreateHookKeyframe,
  CreateHookKeyframesFromFloats,
  CreateHookKeyframesInterpolated,
  CreateHookLora,
  CreateHookLoraModelOnly,
  CreateHookModelAsLora,
  CreateHookModelAsLoraModelOnly,
  CreateVideo,
  CropMask,
  DiffControlNetLoader,
  DifferentialDiffusion,
  DiffusersLoader,
  DisableNoise,
  DualCFGGuider,
  DualCLIPLoader,
  EasyCache,
  EmptyAceStepLatentAudio,
  EmptyAudio,
  EmptyChromaRadianceLatentImage,
  EmptyCosmosLatentVideo,
  EmptyHunyuanImageLatent,
  EmptyHunyuanLatentVideo,
  EmptyImage,
  EmptyLTXVLatentVideo,
  EmptyLatentAudio,
  EmptyLatentHunyuan3Dv2,
  EmptyLatentImage,
  EmptyMochiLatentVideo,
  EmptySD3LatentImage,
  ExponentialScheduler,
  ExtendIntermediateSigmas,
  FeatherMask,
  FlipSigmas,
  FluxDisableGuidance,
  FluxGuidance,
  FluxKontextImageScale,
  FluxKontextMaxImageNode,
  FluxKontextMultiReferenceLatentMethod,
  FluxKontextProImageNode,
  FluxProExpandNode,
  FluxProFillNode,
  FluxProUltraImageNode,
  FreSca,
  FreeU,
  FreeU_V2,
  GITSScheduler,
  GLIGENLoader,
  GLIGENTextBoxApply,
  GeminiImageNode,
  GeminiInputFiles,
  GeminiNode,
  GetImageSize,
  GetVideoComponents,
  GrowMask,
  Hunyuan3Dv2Conditioning,
  Hunyuan3Dv2ConditioningMultiView,
  HunyuanImageToVideo,
  HunyuanRefinerLatent,
  HyperTile,
  HypernetworkLoader,
  IdeogramV1,
  IdeogramV2,
  IdeogramV3,
  ImageAddNoise,
  ImageBatch,
  ImageBlend,
  ImageBlur,
  ImageColorToMask,
  ImageCompositeMasked,
  ImageCrop,
  ImageFlip,
  ImageFromBatch,
  ImageInvert,
  ImageOnlyCheckpointLoader,
  ImageOnlyCheckpointSave,
  ImagePadForOutpaint,
  ImageQuantize,
  ImageRGBToYUV,
  ImageRotate,
  ImageScale,
  ImageScaleBy,
  ImageScaleToMaxDimension,
  ImageScaleToTotalPixels,
  ImageSharpen,
  ImageStitch,
  ImageToMask,
  ImageUpscaleWithModel,
  ImageYUVToRGB,
  InpaintModelConditioning,
  InstructPixToPixConditioning,
  InvertMask,
  JoinImageWithAlpha,
  KSampler,
  KSamplerAdvanced,
  KSamplerSelect,
  KarrasScheduler,
  KlingCameraControlI2VNode,
  KlingCameraControlT2VNode,
  KlingCameraControls,
  KlingDualCharacterVideoEffectNode,
  KlingImage2VideoNode,
  KlingImageGenerationNode,
  KlingLipSyncAudioToVideoNode,
  KlingLipSyncTextToVideoNode,
  KlingSingleImageVideoEffectNode,
  KlingStartEndFrameNode,
  KlingTextToVideoNode,
  KlingVideoExtendNode,
  KlingVirtualTryOnNode,
  LTXVAddGuide,
  LTXVConditioning,
  LTXVCropGuides,
  LTXVImgToVideo,
  LTXVPreprocess,
  LTXVScheduler,
  LaplaceScheduler,
  LatentAdd,
  LatentApplyOperation,
  LatentApplyOperationCFG,
  LatentBatch,
  LatentBatchSeedBehavior,
  LatentBlend,
  LatentComposite,
  LatentCompositeMasked,
  LatentConcat,
  LatentCrop,
  LatentCut,
  LatentFlip,
  LatentFromBatch,
  LatentInterpolate,
  LatentMultiply,
  LatentOperationSharpen,
  LatentOperationTonemapReinhard,
  LatentRotate,
  LatentSubtract,
  LatentUpscale,
  LatentUpscaleBy,
  LazyCache,
  Load3D,
  LoadAudio,
  LoadImage,
  LoadImageMask,
  LoadImageOutput,
  LoadLatent,
  LoadVideo,
  LoraLoader,
  LoraLoaderModelOnly,
  LoraModelLoader,
  LoraSave,
  LossGraphNode,
  LotusConditioning,
  LtxvApiImageToVideo,
  LtxvApiTextToVideo,
  LumaConceptsNode,
  LumaImageModifyNode,
  LumaImageNode,
  LumaImageToVideoNode,
  LumaReferenceNode,
  LumaVideoNode,
  Mahiro,
  MaskComposite,
  MaskPreview,
  MaskToImage,
  MinimaxHailuoVideoNode,
  MinimaxImageToVideoNode,
  MinimaxTextToVideoNode,
  ModelComputeDtype,
  ModelMergeAdd,
  ModelMergeAuraflow,
  ModelMergeBlocks,
  ModelMergeCosmos14B,
  ModelMergeCosmos7B,
  ModelMergeCosmosPredict2_14B,
  ModelMergeCosmosPredict2_2B,
  ModelMergeFlux1,
  ModelMergeLTXV,
  ModelMergeMochiPreview,
  ModelMergeQwenImage,
  ModelMergeSD1,
  ModelMergeSD2,
  ModelMergeSD35_Large,
  ModelMergeSD3_2B,
  ModelMergeSDXL,
  ModelMergeSimple,
  ModelMergeSubtract,
  ModelMergeWAN2_1,
  ModelPatchLoader,
  ModelSamplingAuraFlow,
  ModelSamplingContinuousEDM,
  ModelSamplingContinuousV,
  ModelSamplingDiscrete,
  ModelSamplingFlux,
  ModelSamplingLTXV,
  ModelSamplingSD3,
  ModelSamplingStableCascade,
  ModelSave,
  MoonvalleyImg2VideoNode,
  MoonvalleyTxt2VideoNode,
  MoonvalleyVideo2VideoNode,
  Morphology,
  OpenAIChatConfig,
  OpenAIChatNode,
  OpenAIDalle2,
  OpenAIDalle3,
  OpenAIGPTImage1,
  OpenAIInputFiles,
  OpenAIVideoSora2,
  OptimalStepsScheduler,
  PairConditioningCombine,
  PairConditioningSetDefaultCombine,
  PairConditioningSetProperties,
  PairConditioningSetPropertiesAndCombine,
  PatchModelAddDownscale,
  PerpNeg,
  PerpNegGuider,
  PerturbedAttentionGuidance,
  PhotoMakerEncode,
  PhotoMakerLoader,
  PixverseImageToVideoNode,
  PixverseTemplateNode,
  PixverseTextToVideoNode,
  PixverseTransitionVideoNode,
  PolyexponentialScheduler,
  PorterDuffImageComposite,
  Preview3D,
  PreviewAny,
  PreviewAudio,
  PreviewImage,
  PrimitiveBoolean,
  PrimitiveFloat,
  PrimitiveInt,
  PrimitiveString,
  PrimitiveStringMultiline,
  QuadrupleCLIPLoader,
  QwenImageDiffsynthControlnet,
  RandomNoise,
  RebatchImages,
  RebatchLatents,
  RecordAudio,
  RecraftColorRGB,
  RecraftControls,
  RecraftCreativeUpscaleNode,
  RecraftCrispUpscaleNode,
  RecraftImageInpaintingNode,
  RecraftImageToImageNode,
  RecraftRemoveBackgroundNode,
  RecraftReplaceBackgroundNode,
  RecraftStyleV3DigitalIllustration,
  RecraftStyleV3InfiniteStyleLibrary,
  RecraftStyleV3LogoRaster,
  RecraftStyleV3RealisticImage,
  RecraftTextToImageNode,
  RecraftTextToVectorNode,
  RecraftVectorizeImageNode,
  ReferenceLatent,
  RegexExtract,
  RegexMatch,
  RegexReplace,
  RenormCFG,
  RepeatImageBatch,
  RepeatLatentBatch,
  RescaleCFG,
  ResizeAndPadImage,
  Rodin3D_Detail,
  Rodin3D_Gen2,
  Rodin3D_Regular,
  Rodin3D_Sketch,
  Rodin3D_Smooth,
  RunwayFirstLastFrameNode,
  RunwayImageToVideoNodeGen3a,
  RunwayImageToVideoNodeGen4,
  RunwayTextToImageNode,
  SDTurboScheduler,
  SD_4XUpscale_Conditioning,
  SV3D_Conditioning,
  SVD_img2vid_Conditioning,
  SamplerCustom,
  SamplerCustomAdvanced,
  SamplerDPMAdaptative,
  SamplerDPMPP_2M_SDE,
  SamplerDPMPP_2S_Ancestral,
  SamplerDPMPP_3M_SDE,
  SamplerDPMPP_SDE,
  SamplerER_SDE,
  SamplerEulerAncestral,
  SamplerEulerAncestralCFGPP,
  SamplerEulerCFGpp,
  SamplerLCMUpscale,
  SamplerLMS,
  SamplerSASolver,
  SamplingPercentToSigma,
  SaveAnimatedPNG,
  SaveAnimatedWEBP,
  SaveAudio,
  SaveAudioMP3,
  SaveAudioOpus,
  SaveGLB,
  SaveImage,
  SaveImageWebsocket,
  SaveLatent,
  SaveSVGNode,
  SaveVideo,
  SaveWEBM,
  ScaleROPE,
  SelfAttentionGuidance,
  SetClipHooks,
  SetFirstSigma,
  SetHookKeyframes,
  SetLatentNoiseMask,
  SetUnionControlNetType,
  SkipLayerGuidanceDiT,
  SkipLayerGuidanceDiTSimple,
  SkipLayerGuidanceSD3,
  SolidMask,
  SplitAudioChannels,
  SplitImageWithAlpha,
  SplitSigmas,
  SplitSigmasDenoise,
  StabilityAudioInpaint,
  StabilityAudioToAudio,
  StabilityStableImageSD_3_5Node,
  StabilityStableImageUltraNode,
  StabilityTextToAudio,
  StabilityUpscaleConservativeNode,
  StabilityUpscaleCreativeNode,
  StabilityUpscaleFastNode,
  StableCascade_EmptyLatentImage,
  StableCascade_StageB_Conditioning,
  StableCascade_StageC_VAEEncode,
  StableCascade_SuperResolutionControlnet,
  StableZero123_Conditioning,
  StableZero123_Conditioning_Batched,
  StringCompare,
  StringConcatenate,
  StringContains,
  StringLength,
  StringReplace,
  StringSubstring,
  StringTrim,
  StyleModelApply,
  StyleModelLoader,
  T5TokenizerOptions,
  TCFG,
  TemporalScoreRescaling,
  TextEncodeAceStepAudio,
  TextEncodeHunyuanVideo_ImageToVideo,
  TextEncodeQwenImageEdit,
  TextEncodeQwenImageEditPlus,
  ThresholdMask,
  TomePatchModel,
  TorchCompileModel,
  TrainLoraNode,
  TrimAudioDuration,
  TrimVideoLatent,
  TripleCLIPLoader,
  TripoConversionNode,
  TripoImageToModelNode,
  TripoMultiviewToModelNode,
  TripoRefineNode,
  TripoRetargetNode,
  TripoRigNode,
  TripoTextToModelNode,
  TripoTextureNode,
  UNETLoader,
  UNetCrossAttentionMultiply,
  UNetSelfAttentionMultiply,
  UNetTemporalAttentionMultiply,
  USOStyleReference,
  UpscaleModelLoader,
  VAEDecode,
  VAEDecodeAudio,
  VAEDecodeHunyuan3D,
  VAEDecodeTiled,
  VAEEncode,
  VAEEncodeAudio,
  VAEEncodeForInpaint,
  VAEEncodeTiled,
  VAELoader,
  VAESave,
  VPScheduler,
  Veo3VideoGenerationNode,
  VeoVideoGenerationNode,
  VideoLinearCFGGuidance,
  VideoTriangleCFGGuidance,
  ViduImageToVideoNode,
  ViduReferenceVideoNode,
  ViduStartEndToVideoNode,
  ViduTextToVideoNode,
  VoxelToMesh,
  VoxelToMeshBasic,
  Wan22FunControlToVideo,
  Wan22ImageToVideoLatent,
  WanAnimateToVideo,
  WanCameraEmbedding,
  WanCameraImageToVideo,
  WanContextWindowsManual,
  WanFirstLastFrameToVideo,
  WanFunControlToVideo,
  WanFunInpaintToVideo,
  WanHuMoImageToVideo,
  WanImageToImageApi,
  WanImageToVideo,
  WanImageToVideoApi,
  WanPhantomSubjectToVideo,
  WanSoundImageToVideo,
  WanSoundImageToVideoExtend,
  WanTextToImageApi,
  WanTextToVideoApi,
  WanTrackToVideo,
  WanVaceToVideo,
  WebcamCapture,
  nodeDefs as default,
  unCLIPCheckpointLoader,
  unCLIPConditioning
};
//# sourceMappingURL=nodeDefs-Dz-0ZIBN.js.map
