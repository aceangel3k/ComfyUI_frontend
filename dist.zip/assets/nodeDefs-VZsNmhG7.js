const APG = { "display_name": "Uyarlanabilir Projeksiyonlu Kılavuzluk", "inputs": { "eta": { "name": "eta", "tooltip": "Paralel kılavuzluk vektörünün ölçeğini kontrol eder. Varsayılan CFG davranışı 1 ayarında elde edilir." }, "model": { "name": "model" }, "momentum": { "name": "momentum", "tooltip": "Difüzyon sırasında kılavuzluğun kayan ortalamasını kontrol eder, 0 ayarında devre dışı bırakılır." }, "norm_threshold": { "name": "norm_threshold", "tooltip": "Kılavuzluk vektörünü bu değere normalleştirir, 0 ayarında normalleştirme devre dışı bırakılır." } }, "outputs": { "0": { "tooltip": null } } };
const AddNoise = { "display_name": "Gürültü Ekle", "inputs": { "latent_image": { "name": "gizli_görüntü" }, "model": { "name": "model" }, "noise": { "name": "gürültü" }, "sigmas": { "name": "sigmalar" } } };
const AlignYourStepsScheduler = { "display_name": "AdımlarınıHizalaZamanlayıcı", "inputs": { "denoise": { "name": "gürültü_azaltma" }, "model_type": { "name": "model_türü" }, "steps": { "name": "adımlar" } }, "outputs": { "0": { "tooltip": null } } };
const AudioAdjustVolume = { "display_name": "Ses Ses Seviyesi Ayarla", "inputs": { "audio": { "name": "ses" }, "volume": { "name": "volume", "tooltip": "Desibel (dB) cinsinden ses seviyesi ayarı. 0 = değişiklik yok, +6 = iki katı, -6 = yarısı, vb." } } };
const AudioConcat = { "description": "Ses1'i ses2'ye belirtilen yönde birleştirir.", "display_name": "Ses Birleştir", "inputs": { "audio1": { "name": "ses1" }, "audio2": { "name": "ses2" }, "direction": { "name": "direction", "tooltip": "Ses2'nin ses1'den sonra mı yoksa önce mi ekleneceği." } } };
const AudioEncoderEncode = { "display_name": "SesKodlayıcıKodla", "inputs": { "audio": { "name": "ses" }, "audio_encoder": { "name": "ses_kodlayıcı" } }, "outputs": { "0": { "tooltip": null } } };
const AudioEncoderLoader = { "display_name": "SesKodlayıcıYükleyici", "inputs": { "audio_encoder_name": { "name": "ses_kodlayıcı_adı" } }, "outputs": { "0": { "tooltip": null } } };
const AudioMerge = { "description": "İki ses parçasını dalga formlarını üst üste bindirerek birleştirir.", "display_name": "Ses Birleştir", "inputs": { "audio1": { "name": "ses1" }, "audio2": { "name": "ses2" }, "merge_method": { "name": "merge_method", "tooltip": "Ses dalga formlarını birleştirmek için kullanılan yöntem." } } };
const BasicGuider = { "display_name": "Temel Rehber", "inputs": { "conditioning": { "name": "koşullandırma" }, "model": { "name": "model" } } };
const BasicScheduler = { "display_name": "Temel Zamanlayıcı", "inputs": { "denoise": { "name": "gürültü_azaltma" }, "model": { "name": "model" }, "scheduler": { "name": "zamanlayıcı" }, "steps": { "name": "adımlar" } } };
const BetaSamplingScheduler = { "display_name": "BetaÖrneklemeZamanlayıcısı", "inputs": { "alpha": { "name": "alfa" }, "beta": { "name": "beta" }, "model": { "name": "model" }, "steps": { "name": "adımlar" } } };
const ByteDanceFirstLastFrameNode = { "description": "İlk ve son kareleri kullanarak video oluşturun.", "display_name": "ByteDance İlk-Son-Kare'den Videoya", "inputs": { "aspect_ratio": { "name": "en_boy_oranı", "tooltip": "Çıktı videosunun en boy oranı." }, "camera_fixed": { "name": "sabit_kamera", "tooltip": "Kameranın sabitlenip sabitlenmeyeceğini belirtir. Platform, kamerayı sabitleme talimatını isteminize ekler ancak gerçek etkiyi garanti etmez." }, "control_after_generate": { "name": "oluşturma sonrası kontrol" }, "duration": { "name": "süre", "tooltip": "Çıktı videosunun saniye cinsinden süresi." }, "first_frame": { "name": "ilk_kare", "tooltip": "Video için kullanılacak ilk kare." }, "last_frame": { "name": "son_kare", "tooltip": "Video için kullanılacak son kare." }, "model": { "name": "model" }, "prompt": { "name": "prompt", "tooltip": "Video oluşturmak için kullanılan metin istemi." }, "resolution": { "name": "çözünürlük", "tooltip": "Çıktı videosunun çözünürlüğü." }, "seed": { "name": "tohum", "tooltip": "Oluşturma için kullanılacak tohum değeri." }, "watermark": { "name": "filigran", "tooltip": 'Videoya "Yapay zeka tarafından oluşturulmuştur" filigranı eklenip eklenmeyeceği.' } }, "outputs": { "0": { "tooltip": null } } };
const ByteDanceImageEditNode = { "description": "İstek üzerine api aracılığıyla ByteDance modellerini kullanarak görüntüleri düzenleyin", "display_name": "ByteDance Görüntü Düzenleme", "inputs": { "control_after_generate": { "name": "oluşturma sonrası kontrol" }, "guidance_scale": { "name": "rehberlik_ölçeği", "tooltip": "Daha yüksek değer, görüntünün isteği daha yakından takip etmesini sağlar" }, "image": { "name": "görüntü", "tooltip": "Düzenlenecek temel görüntü" }, "model": { "name": "model" }, "prompt": { "name": "istek", "tooltip": "Görüntüyü düzenleme talimatı" }, "seed": { "name": "tohum", "tooltip": "Oluşturma için kullanılacak tohum değeri" }, "watermark": { "name": "filigran", "tooltip": 'Görüntüye "Yapay zeka tarafından oluşturulmuştur" filigranı eklenip eklenmeyeceği' } }, "outputs": { "0": { "tooltip": null } } };
const ByteDanceImageNode = { "description": "İstek üzerine api aracılığıyla ByteDance modellerini kullanarak görüntüler oluşturun", "display_name": "ByteDance Görüntü", "inputs": { "control_after_generate": { "name": "control after generate" }, "guidance_scale": { "name": "guidance_scale", "tooltip": "Daha yüksek değer, görselin istemi daha yakından takip etmesini sağlar" }, "height": { "name": "height", "tooltip": "Görsel için özel yükseklik. Bu değer yalnızca `size_preset` `Custom` olarak ayarlandığında çalışır" }, "model": { "name": "model" }, "prompt": { "name": "prompt", "tooltip": "Görseli oluşturmak için kullanılan metin istemi" }, "seed": { "name": "seed", "tooltip": "Oluşturma için kullanılacak seed değeri" }, "size_preset": { "name": "size_preset", "tooltip": "Önerilen bir boyut seçin. Aşağıdaki genişlik ve yüksekliği kullanmak için Özel'i seçin" }, "watermark": { "name": "watermark", "tooltip": 'Görsele "AI tarafından oluşturuldu" filigranı eklenip eklenmeyeceği' }, "width": { "name": "width", "tooltip": "Görsel için özel genişlik. Bu değer yalnızca `size_preset` `Custom` olarak ayarlandığında çalışır" } }, "outputs": { "0": { "tooltip": null } } };
const ByteDanceImageReferenceNode = { "description": "İstemi ve referans görselleri kullanarak video oluşturun.", "display_name": "ByteDance Referans Görsellerden Videoya", "inputs": { "aspect_ratio": { "name": "aspect_ratio", "tooltip": "Çıktı videosunun en-boy oranı." }, "control_after_generate": { "name": "control after generate" }, "duration": { "name": "duration", "tooltip": "Çıktı videosunun saniye cinsinden süresi." }, "images": { "name": "images", "tooltip": "Bir ila dört görsel." }, "model": { "name": "model" }, "prompt": { "name": "prompt", "tooltip": "Videoyu oluşturmak için kullanılan metin istemi." }, "resolution": { "name": "resolution", "tooltip": "Çıktı videosunun çözünürlüğü." }, "seed": { "name": "seed", "tooltip": "Oluşturma için kullanılacak seed değeri." }, "watermark": { "name": "watermark", "tooltip": 'Videoya "AI tarafından oluşturuldu" filigranı eklenip eklenmeyeceği.' } }, "outputs": { "0": { "tooltip": null } } };
const ByteDanceImageToVideoNode = { "description": "Görüntü ve prompt kullanarak ByteDance modelleri aracılığıyla API üzerinden video oluşturun", "display_name": "ByteDance Görüntüden Videoya", "inputs": { "aspect_ratio": { "name": "en-boy oranı", "tooltip": "Çıktı videosunun en-boy oranı." }, "camera_fixed": { "name": "sabit kamera", "tooltip": "Kameranın sabitlenip sabitlenmeyeceğini belirtir. Platform, kamerayı sabitlemek için bir talimat ekler ancak gerçek etkiyi garanti etmez." }, "control_after_generate": { "name": "oluşturma sonrası kontrol" }, "duration": { "name": "süre", "tooltip": "Oluşturulan videonun saniye cinsinden süresi." }, "image": { "name": "görüntü", "tooltip": "Video için kullanılacak ilk kare." }, "model": { "name": "model" }, "prompt": { "name": "prompt", "tooltip": "Video oluşturmak için kullanılan metin prompt'u." }, "resolution": { "name": "çözünürlük", "tooltip": "Çıktı videosunun çözünürlüğü." }, "seed": { "name": "seed", "tooltip": "Oluşturma için kullanılacak seed değeri." }, "watermark": { "name": "filigran", "tooltip": 'Videoya "AI tarafından oluşturuldu" filigranı eklenip eklenmeyeceği.' } }, "outputs": { "0": { "tooltip": null } } };
const ByteDanceSeedreamNode = { "description": "Birleşik metinden-görüntüye oluşturma ve 4K çözünürlüğe kadar hassas tek cümle düzenleme.", "display_name": "ByteDance Seedream 4", "inputs": { "control_after_generate": { "name": "oluşturma sonrası kontrol" }, "fail_on_partial": { "name": "kısmi_hatada_durdur", "tooltip": "Etkinleştirilirse, herhangi bir istenen resim eksikse veya hata döndürürse yürütmeyi durdur." }, "height": { "name": "yükseklik", "tooltip": "Görüntü için özel yükseklik. Değer yalnızca `boyut önayarı` `Özel` olarak ayarlandığında çalışır" }, "image": { "name": "görüntü", "tooltip": "Görüntüden-görüntüye oluşturma için girdi görüntüsü. Tek veya çoklu referans oluşturma için 1-10 görüntü listesi." }, "max_images": { "name": "maks_resim", "tooltip": "sequential_image_generation='auto' olduğunda oluşturulacak maksimum resim sayısı. Toplam resim sayısı (girdi + oluşturulan) 15'i geçemez." }, "model": { "name": "model", "tooltip": "Model adı" }, "prompt": { "name": "prompt", "tooltip": "Görüntü oluşturmak veya düzenlemek için metin prompt'u." }, "seed": { "name": "tohum", "tooltip": "Oluşturma için kullanılacak tohum değeri." }, "sequential_image_generation": { "name": "sıralı_resim_oluşturma", "tooltip": "Grup resim oluşturma modu. 'disabled' tek bir resim oluşturur. 'auto' modelin birden fazla ilişkili resim oluşturup oluşturmayacağına karar vermesine izin verir (örn. hikaye sahneleri, karakter varyasyonları)." }, "size_preset": { "name": "boyut önayarı", "tooltip": "Önerilen bir boyut seçin. Aşağıdaki genişlik ve yüksekliği kullanmak için Özel'i seçin." }, "watermark": { "name": "filigran", "tooltip": 'Resme "AI tarafından oluşturuldu" filigranı eklenip eklenmeyeceği.' }, "width": { "name": "genişlik", "tooltip": "Görüntü için özel genişlik. Değer yalnızca `boyut önayarı` `Özel` olarak ayarlandığında çalışır" } }, "outputs": { "0": { "tooltip": null } } };
const ByteDanceTextToVideoNode = { "description": "Prompt'a dayalı olarak api üzerinden ByteDance modellerini kullanarak video oluştur", "display_name": "ByteDance Metinden Videoya", "inputs": { "aspect_ratio": { "name": "en_boy_oranı", "tooltip": "Çıktı videosunun en boy oranı." }, "camera_fixed": { "name": "sabit_kamera", "tooltip": "Kameranın sabitlenip sabitlenmeyeceğini belirtir. Platform kamerayı sabitleme talimatını prompt'unuza ekler, ancak gerçek etkiyi garanti etmez." }, "control_after_generate": { "name": "oluşturma sonrası kontrol" }, "duration": { "name": "süre", "tooltip": "Çıktı videosunun saniye cinsinden süresi." }, "model": { "name": "model" }, "prompt": { "name": "prompt", "tooltip": "Video oluşturmak için kullanılan metin prompt'u." }, "resolution": { "name": "çözünürlük", "tooltip": "Çıktı videosunun çözünürlüğü." }, "seed": { "name": "tohum", "tooltip": "Oluşturma için kullanılacak tohum değeri." }, "watermark": { "name": "filigran", "tooltip": 'Videoya "AI tarafından oluşturuldu" filigranı eklenip eklenmeyeceği.' } }, "outputs": { "0": { "tooltip": null } } };
const CFGGuider = { "display_name": "CFG Rehberi", "inputs": { "cfg": { "name": "cfg" }, "model": { "name": "model" }, "negative": { "name": "negatif" }, "positive": { "name": "pozitif" } } };
const CFGNorm = { "display_name": "CFGNorm", "inputs": { "model": { "name": "model" }, "strength": { "name": "güç" } }, "outputs": { "0": { "name": "yama uygulanmış model", "tooltip": null } } };
const CFGZeroStar = { "display_name": "CFGSıfırYıldız", "inputs": { "model": { "name": "model" } }, "outputs": { "0": { "name": "yamalı_model", "tooltip": null } } };
const CLIPAttentionMultiply = { "display_name": "CLIP Dikkat Çarpımı", "inputs": { "clip": { "name": "clip" }, "k": { "name": "k" }, "out": { "name": "çıktı" }, "q": { "name": "q" }, "v": { "name": "v" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPLoader = { "description": "[Tarifler]\n\nstable_diffusion: clip-l\nstable_cascade: clip-g\nsd3: t5 xxl/ clip-g / clip-l\nstable_audio: t5 base\nmochi: t5 xxl\ncosmos: eski t5 xxl\nlumina2: gemma 2 2B\nwan: umt5 xxl\n hidream: llama-3.1 (Önerilir) veya t5", "display_name": "CLIP Yükle", "inputs": { "clip_name": { "name": "clip_adı" }, "device": { "name": "cihaz" }, "type": { "name": "tür" } } };
const CLIPMergeAdd = { "display_name": "CLIP Birleştirme Ekle", "inputs": { "clip1": { "name": "clip1" }, "clip2": { "name": "clip2" } } };
const CLIPMergeSimple = { "display_name": "Basit CLIP Birleştirme", "inputs": { "clip1": { "name": "clip1" }, "clip2": { "name": "clip2" }, "ratio": { "name": "oran" } } };
const CLIPMergeSubtract = { "display_name": "CLIP Birleştirme Çıkar", "inputs": { "clip1": { "name": "clip1" }, "clip2": { "name": "clip2" }, "multiplier": { "name": "çarpan" } } };
const CLIPSave = { "display_name": "CLIP Kaydet", "inputs": { "clip": { "name": "clip" }, "filename_prefix": { "name": "dosyaadı_öneki" } } };
const CLIPSetLastLayer = { "display_name": "CLIP Son Katmanı Ayarla", "inputs": { "clip": { "name": "clip" }, "stop_at_clip_layer": { "name": "clip_katmanında_dur" } } };
const CLIPTextEncode = { "description": "Bir metin istemini bir CLIP modeli kullanarak, belirli görüntülerin oluşturulmasına yönelik difüzyon modelini yönlendirmek için kullanılabilecek bir gömme içine kodlar.", "display_name": "CLIP Metin Kodlama (İstem)", "inputs": { "clip": { "name": "clip", "tooltip": "Metni kodlamak için kullanılan CLIP modeli." }, "text": { "name": "metin", "tooltip": "Kodlanacak metin." } }, "outputs": { "0": { "tooltip": "Difüzyon modelini yönlendirmek için kullanılan gömülü metni içeren bir koşullandırma." } } };
const CLIPTextEncodeControlnet = { "display_name": "CLIPMetinKodlamaControlnet", "inputs": { "clip": { "name": "clip" }, "conditioning": { "name": "koşullandırma" }, "text": { "name": "metin" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeFlux = { "display_name": "CLIPMetinKodlamaFlux", "inputs": { "clip": { "name": "clip" }, "clip_l": { "name": "clip_l" }, "guidance": { "name": "rehberlik" }, "t5xxl": { "name": "t5xxl" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeHiDream = { "display_name": "CLIPMetinKodlamaHiDream", "inputs": { "clip": { "name": "clip" }, "clip_g": { "name": "clip_g" }, "clip_l": { "name": "clip_l" }, "llama": { "name": "llama" }, "t5xxl": { "name": "t5xxl" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeHunyuanDiT = { "display_name": "CLIPMetinKodlamaHunyuanDiT", "inputs": { "bert": { "name": "bert" }, "clip": { "name": "clip" }, "mt5xl": { "name": "mt5xl" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeLumina2 = { "description": "Bir sistem istemini ve bir kullanıcı istemini bir CLIP modeli kullanarak, belirli görüntülerin oluşturulmasına yönelik difüzyon modelini yönlendirmek için kullanılabilecek bir gömme içine kodlar.", "display_name": "Lumina2 için CLIP Metin Kodlama", "inputs": { "clip": { "name": "clip", "tooltip": "Metni kodlamak için kullanılan CLIP modeli." }, "system_prompt": { "name": "sistem_istemi", "tooltip": "Lumina2 iki tür sistem istemi sağlar: Üstün: Metinsel istemlere veya kullanıcı istemlerine dayalı olarak üstün derecede görüntü-metin hizalamasına sahip üstün görüntüler oluşturmak için tasarlanmış bir asistansınız. Hizalama: Metinsel istemlere dayalı olarak en yüksek derecede görüntü-metin hizalamasına sahip yüksek kaliteli görüntüler oluşturmak için tasarlanmış bir asistansınız." }, "user_prompt": { "name": "kullanıcı_istemi", "tooltip": "Kodlanacak metin." } }, "outputs": { "0": { "tooltip": "Difüzyon modelini yönlendirmek için kullanılan gömülü metni içeren bir koşullandırma." } } };
const CLIPTextEncodePixArtAlpha = { "description": "Metni kodlar ve PixArt Alpha için çözünürlük koşullandırmasını ayarlar. PixArt Sigma için geçerli değildir.", "display_name": "CLIPMetinKodlamaPixArtAlpha", "inputs": { "clip": { "name": "clip" }, "height": { "name": "yükseklik" }, "text": { "name": "metin" }, "width": { "name": "genişlik" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeSD3 = { "display_name": "CLIPMetinKodlamaSD3", "inputs": { "clip": { "name": "clip" }, "clip_g": { "name": "clip_g" }, "clip_l": { "name": "clip_l" }, "empty_padding": { "name": "boş_dolgu" }, "t5xxl": { "name": "t5xxl" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeSDXL = { "display_name": "CLIPMetinKodlamaSDXL", "inputs": { "clip": { "name": "clip" }, "crop_h": { "name": "kırpma_y" }, "crop_w": { "name": "kırpma_g" }, "height": { "name": "yükseklik" }, "target_height": { "name": "hedef_yükseklik" }, "target_width": { "name": "hedef_genişlik" }, "text_g": { "name": "metin_g" }, "text_l": { "name": "metin_l" }, "width": { "name": "genişlik" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeSDXLRefiner = { "display_name": "CLIPMetinKodlamaSDXLRefiner", "inputs": { "ascore": { "name": "askor" }, "clip": { "name": "clip" }, "height": { "name": "yükseklik" }, "text": { "name": "metin" }, "width": { "name": "genişlik" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPVisionEncode = { "display_name": "CLIP Görü Kodlama", "inputs": { "clip_vision": { "name": "clip_görü" }, "crop": { "name": "kırp" }, "image": { "name": "görüntü" } } };
const CLIPVisionLoader = { "display_name": "CLIP Görü Yükle", "inputs": { "clip_name": { "name": "clip_adı" } } };
const Canny = { "display_name": "Canny", "inputs": { "high_threshold": { "name": "yüksek_eşik" }, "image": { "name": "görüntü" }, "low_threshold": { "name": "düşük_eşik" } }, "outputs": { "0": { "tooltip": null } } };
const CaseConverter = { "display_name": "Büyük/Küçük Harf Dönüştürücü", "inputs": { "mode": { "name": "mod" }, "string": { "name": "dize" } }, "outputs": { "0": { "tooltip": null } } };
const CheckpointLoader = { "display_name": "Yapılandırmayla Kontrol Noktası Yükle (ESKİ)", "inputs": { "ckpt_name": { "name": "ckpt_adı" }, "config_name": { "name": "yapılandırma_adı" } } };
const CheckpointLoaderSimple = { "description": "Bir difüzyon modeli kontrol noktası yükler, difüzyon modelleri gizli değişkenlerin gürültüsünü azaltmak için kullanılır.", "display_name": "Kontrol Noktası Yükle", "inputs": { "ckpt_name": { "name": "ckpt_adı", "tooltip": "Yüklenecek kontrol noktasının (modelin) adı." } }, "outputs": { "0": { "tooltip": "Gizli değişkenlerin gürültüsünü azaltmak için kullanılan model." }, "1": { "tooltip": "Metin istemlerini kodlamak için kullanılan CLIP modeli." }, "2": { "tooltip": "Görüntüleri gizli uzaya ve gizli uzaydan kodlamak ve kodunu çözmek için kullanılan VAE modeli." } } };
const CheckpointSave = { "display_name": "Kontrol Noktasını Kaydet", "inputs": { "clip": { "name": "clip" }, "filename_prefix": { "name": "dosyaadı_öneki" }, "model": { "name": "model" }, "vae": { "name": "vae" } } };
const ChromaRadianceOptions = { "description": "Chroma Radiance modeli için gelişmiş seçeneklerin ayarlanmasına izin verir.", "display_name": "ChromaRadianceSeçenekleri", "inputs": { "end_sigma": { "name": "bitiş sigma", "tooltip": "Bu seçeneklerin geçerli olacağı son sigma değeri." }, "model": { "name": "model" }, "nerf_tile_size": { "name": "nerf döşeme boyutu", "tooltip": "Varsayılan NeRF döşeme boyutunun geçersiz kılınmasına izin verir. -1 varsayılanı (32) kullan demektir. 0 döşeme modu kullanmama anlamına gelir (çok fazla VRAM gerektirebilir)." }, "preserve_wrapper": { "name": "sarmalayıcıyı koru", "tooltip": "Etkinleştirildiğinde, mevcutsa var olan bir model işlev sarmalayıcısına devreder. Genellikle etkin bırakılmalıdır." }, "start_sigma": { "name": "başlangıç sigma", "tooltip": "Bu seçeneklerin geçerli olacağı ilk sigma değeri." } }, "outputs": { "0": { "tooltip": null } } };
const CombineHooks2 = { "display_name": "Kancaları Birleştir [2]", "inputs": { "hooks_A": { "name": "kancalar_A" }, "hooks_B": { "name": "kancalar_B" } } };
const CombineHooks4 = { "display_name": "Kancaları Birleştir [4]", "inputs": { "hooks_A": { "name": "kancalar_A" }, "hooks_B": { "name": "kancalar_B" }, "hooks_C": { "name": "kancalar_C" }, "hooks_D": { "name": "kancalar_D" } } };
const CombineHooks8 = { "display_name": "Kancaları Birleştir [8]", "inputs": { "hooks_A": { "name": "kancalar_A" }, "hooks_B": { "name": "kancalar_B" }, "hooks_C": { "name": "kancalar_C" }, "hooks_D": { "name": "kancalar_D" }, "hooks_E": { "name": "kancalar_E" }, "hooks_F": { "name": "kancalar_F" }, "hooks_G": { "name": "kancalar_G" }, "hooks_H": { "name": "kancalar_H" } } };
const ConditioningAverage = { "display_name": "KoşullandırmaOrtalaması", "inputs": { "conditioning_from": { "name": "kaynak_koşullandırma" }, "conditioning_to": { "name": "hedef_koşullandırma" }, "conditioning_to_strength": { "name": "hedef_koşullandırma_gücü" } } };
const ConditioningCombine = { "display_name": "Koşullandırma (Birleştir)", "inputs": { "conditioning_1": { "name": "koşullandırma_1" }, "conditioning_2": { "name": "koşullandırma_2" } } };
const ConditioningConcat = { "display_name": "Koşullandırma (Birleştir)", "inputs": { "conditioning_from": { "name": "kaynak_koşullandırma" }, "conditioning_to": { "name": "hedef_koşullandırma" } } };
const ConditioningSetArea = { "display_name": "Koşullandırma (Alan Ayarla)", "inputs": { "conditioning": { "name": "koşullandırma" }, "height": { "name": "yükseklik" }, "strength": { "name": "güç" }, "width": { "name": "genişlik" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const ConditioningSetAreaPercentage = { "display_name": "Koşullandırma (Yüzde ile Alan Ayarla)", "inputs": { "conditioning": { "name": "koşullandırma" }, "height": { "name": "yükseklik" }, "strength": { "name": "güç" }, "width": { "name": "genişlik" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const ConditioningSetAreaPercentageVideo = { "display_name": "KoşullandırmaAlanYüzdesiVideo", "inputs": { "conditioning": { "name": "koşullandırma" }, "height": { "name": "yükseklik" }, "strength": { "name": "güç" }, "temporal": { "name": "zamansal" }, "width": { "name": "genişlik" }, "x": { "name": "x" }, "y": { "name": "y" }, "z": { "name": "z" } } };
const ConditioningSetAreaStrength = { "display_name": "KoşullandırmaAlanGücüAyarla", "inputs": { "conditioning": { "name": "koşullandırma" }, "strength": { "name": "güç" } } };
const ConditioningSetDefaultCombine = { "display_name": "Koşul Varsayılan Birleştirmeyi Ayarla", "inputs": { "cond": { "name": "koşul" }, "cond_DEFAULT": { "name": "koşul_VARSAYILAN" }, "hooks": { "name": "kancalar" } } };
const ConditioningSetMask = { "display_name": "Koşullandırma (Maske Ayarla)", "inputs": { "conditioning": { "name": "koşullandırma" }, "mask": { "name": "maske" }, "set_cond_area": { "name": "koşul_alanı_ayarla" }, "strength": { "name": "güç" } } };
const ConditioningSetProperties = { "display_name": "Koşul Özelliklerini Ayarla", "inputs": { "cond_NEW": { "name": "yeni_koşul" }, "hooks": { "name": "kancalar" }, "mask": { "name": "maske" }, "set_cond_area": { "name": "koşul_alanı_ayarla" }, "strength": { "name": "güç" }, "timesteps": { "name": "zaman_adımları" } } };
const ConditioningSetPropertiesAndCombine = { "display_name": "Koşul Özelliklerini Ayarla ve Birleştir", "inputs": { "cond": { "name": "koşul" }, "cond_NEW": { "name": "yeni_koşul" }, "hooks": { "name": "kancalar" }, "mask": { "name": "maske" }, "set_cond_area": { "name": "koşul_alanı_ayarla" }, "strength": { "name": "güç" }, "timesteps": { "name": "zaman_adımları" } } };
const ConditioningSetTimestepRange = { "display_name": "KoşullandırmaZamanAdımıAralığıAyarla", "inputs": { "conditioning": { "name": "koşullandırma" }, "end": { "name": "bitiş" }, "start": { "name": "başlangıç" } } };
const ConditioningStableAudio = { "display_name": "KoşullandırmaKararlıSes", "inputs": { "negative": { "name": "negatif" }, "positive": { "name": "pozitif" }, "seconds_start": { "name": "saniye_başlangıç" }, "seconds_total": { "name": "saniye_toplam" } }, "outputs": { "0": { "name": "pozitif" }, "1": { "name": "negatif" } } };
const ConditioningTimestepsRange = { "display_name": "Zaman Adımları Aralığı", "inputs": { "end_percent": { "name": "bitiş_yüzdesi" }, "start_percent": { "name": "başlangıç_yüzdesi" } }, "outputs": { "1": { "name": "ARALIK_ÖNCESİ" }, "2": { "name": "ARALIK_SONRASI" } } };
const ConditioningZeroOut = { "display_name": "KoşullandırmaSıfırla", "inputs": { "conditioning": { "name": "koşullandırma" } } };
const ContextWindowsManual = { "description": "Bağlam pencerelerini manuel olarak ayarlayın.", "display_name": "Bağlam Pencereleri (Manuel)", "inputs": { "closed_loop": { "name": "kapalı döngü", "tooltip": "Bağlam penceresi döngüsünün kapatılıp kapatılmayacağı; sadece döngülü çizelgeler için geçerlidir." }, "context_length": { "name": "bağlam uzunluğu", "tooltip": "Bağlam penceresinin uzunluğu." }, "context_overlap": { "name": "bağlam örtüşmesi", "tooltip": "Bağlam penceresinin örtüşme miktarı." }, "context_schedule": { "name": "bağlam çizelgesi", "tooltip": "Bağlam penceresinin adım aralığı." }, "context_stride": { "name": "bağlam adımı", "tooltip": "Bağlam penceresinin adım aralığı; sadece tekdüze çizelgeler için geçerlidir." }, "dim": { "name": "boyut", "tooltip": "Bağlam pencerelerinin uygulanacağı boyut." }, "fuse_method": { "name": "birleştirme yöntemi", "tooltip": "Bağlam pencerelerini birleştirmek için kullanılacak yöntem." }, "model": { "name": "model", "tooltip": "Örnekleme sırasında bağlam pencerelerinin uygulanacağı model." } }, "outputs": { "0": { "tooltip": "Örnekleme sırasında bağlam pencereleri uygulanmış model." } } };
const ControlNetApply = { "display_name": "ControlNet Uygula (ESKİ)", "inputs": { "conditioning": { "name": "koşullandırma" }, "control_net": { "name": "kontrol_ağı" }, "image": { "name": "görüntü" }, "strength": { "name": "güç" } } };
const ControlNetApplyAdvanced = { "display_name": "ControlNet Uygula", "inputs": { "control_net": { "name": "kontrol_ağı" }, "end_percent": { "name": "bitiş_yüzdesi" }, "image": { "name": "görüntü" }, "negative": { "name": "negatif" }, "positive": { "name": "pozitif" }, "start_percent": { "name": "başlangıç_yüzdesi" }, "strength": { "name": "güç" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "pozitif" }, "1": { "name": "negatif" } } };
const ControlNetApplySD3 = { "display_name": "VAE ile Controlnet Uygula", "inputs": { "control_net": { "name": "kontrol_ağı" }, "end_percent": { "name": "bitiş_yüzdesi" }, "image": { "name": "görüntü" }, "negative": { "name": "negatif" }, "positive": { "name": "pozitif" }, "start_percent": { "name": "başlangıç_yüzdesi" }, "strength": { "name": "güç" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "pozitif", "tooltip": null }, "1": { "name": "negatif", "tooltip": null } } };
const ControlNetInpaintingAliMamaApply = { "display_name": "ControlNetInpaintingAliMamaUygula", "inputs": { "control_net": { "name": "kontrol_ağı" }, "end_percent": { "name": "bitiş_yüzdesi" }, "image": { "name": "görüntü" }, "mask": { "name": "maske" }, "negative": { "name": "negatif" }, "positive": { "name": "pozitif" }, "start_percent": { "name": "başlangıç_yüzdesi" }, "strength": { "name": "güç" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "pozitif", "tooltip": null }, "1": { "name": "negatif", "tooltip": null } } };
const ControlNetLoader = { "display_name": "ControlNet Modelini Yükle", "inputs": { "control_net_name": { "name": "kontrol_ağı_adı" } } };
const CosmosImageToVideoLatent = { "display_name": "CosmosGörüntüdenVideoyaGizli", "inputs": { "batch_size": { "name": "toplu_boyut" }, "end_image": { "name": "bitiş_görüntüsü" }, "height": { "name": "yükseklik" }, "length": { "name": "uzunluk" }, "start_image": { "name": "başlangıç_görüntüsü" }, "vae": { "name": "vae" }, "width": { "name": "genişlik" } }, "outputs": { "0": { "tooltip": null } } };
const CosmosPredict2ImageToVideoLatent = { "display_name": "CosmosPredict2ImageToVideoLatent", "inputs": { "batch_size": { "name": "toplu_iş_boyutu" }, "end_image": { "name": "bitiş_görseli" }, "height": { "name": "yükseklik" }, "length": { "name": "uzunluk" }, "start_image": { "name": "başlangıç_görseli" }, "vae": { "name": "vae" }, "width": { "name": "genişlik" } }, "outputs": { "0": { "tooltip": null } } };
const CreateHookKeyframe = { "display_name": "Kanca Anahtar Karesi Oluştur", "inputs": { "prev_hook_kf": { "name": "önceki_kanca_kf" }, "start_percent": { "name": "başlangıç_yüzdesi" }, "strength_mult": { "name": "güç_çarpanı" } }, "outputs": { "0": { "name": "Kanca_KF" } } };
const CreateHookKeyframesFromFloats = { "display_name": "Ondalıklardan Kanca Anahtar Kareleri Oluştur", "inputs": { "end_percent": { "name": "bitiş_yüzdesi" }, "floats_strength": { "name": "ondalık_güç" }, "prev_hook_kf": { "name": "önceki_kanca_kf" }, "print_keyframes": { "name": "anahtar_kareleri_yazdır" }, "start_percent": { "name": "başlangıç_yüzdesi" } }, "outputs": { "0": { "name": "Kanca_KF" } } };
const CreateHookKeyframesInterpolated = { "display_name": "Ara Değerlenmiş Kanca Anahtar Kareleri Oluştur", "inputs": { "end_percent": { "name": "bitiş_yüzdesi" }, "interpolation": { "name": "enterpolasyon" }, "keyframes_count": { "name": "anahtar_kare_sayısı" }, "prev_hook_kf": { "name": "önceki_kanca_kf" }, "print_keyframes": { "name": "anahtar_kareleri_yazdır" }, "start_percent": { "name": "başlangıç_yüzdesi" }, "strength_end": { "name": "bitiş_gücü" }, "strength_start": { "name": "başlangıç_gücü" } }, "outputs": { "0": { "name": "Kanca_KF" } } };
const CreateHookLora = { "display_name": "Kanca LoRA Oluştur", "inputs": { "lora_name": { "name": "lora_adı" }, "prev_hooks": { "name": "önceki_kancalar" }, "strength_clip": { "name": "clip_gücü" }, "strength_model": { "name": "model_gücü" } } };
const CreateHookLoraModelOnly = { "display_name": "Kanca LoRA Oluştur (Sadece Model)", "inputs": { "lora_name": { "name": "lora_adı" }, "prev_hooks": { "name": "önceki_kancalar" }, "strength_model": { "name": "model_gücü" } } };
const CreateHookModelAsLora = { "display_name": "Modeli LoRA Olarak Kanca Oluştur", "inputs": { "ckpt_name": { "name": "ckpt_adı" }, "prev_hooks": { "name": "önceki_kancalar" }, "strength_clip": { "name": "clip_gücü" }, "strength_model": { "name": "model_gücü" } } };
const CreateHookModelAsLoraModelOnly = { "display_name": "Modeli LoRA Olarak Kanca Oluştur (Sadece Model)", "inputs": { "ckpt_name": { "name": "ckpt_adı" }, "prev_hooks": { "name": "önceki_kancalar" }, "strength_model": { "name": "model_gücü" } } };
const CreateVideo = { "description": "Görüntülerden bir video oluşturun.", "display_name": "Video Oluştur", "inputs": { "audio": { "name": "ses", "tooltip": "Videoya eklenecek ses." }, "fps": { "name": "fps" }, "images": { "name": "görüntüler", "tooltip": "Video oluşturulacak görüntüler." } }, "outputs": { "0": { "tooltip": null } } };
const CropMask = { "display_name": "Maskeyi Kırp", "inputs": { "height": { "name": "yükseklik" }, "mask": { "name": "maske" }, "width": { "name": "genişlik" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const DiffControlNetLoader = { "display_name": "ControlNet Modelini Yükle (fark)", "inputs": { "control_net_name": { "name": "kontrol_ağı_adı" }, "model": { "name": "model" } } };
const DifferentialDiffusion = { "display_name": "Diferansiyel Difüzyon", "inputs": { "model": { "name": "model" }, "strength": { "name": "güç" } }, "outputs": { "0": { "tooltip": null } } };
const DiffusersLoader = { "display_name": "Diffusers Yükleyici", "inputs": { "model_path": { "name": "model_yolu" } } };
const DisableNoise = { "display_name": "Gürültüyü Devre Dışı Bırak" };
const DualCFGGuider = { "display_name": "İkili CFG Rehberi", "inputs": { "cfg_cond2_negative": { "name": "cfg_koşul2_negatif" }, "cfg_conds": { "name": "cfg_koşulları" }, "cond1": { "name": "koşul1" }, "cond2": { "name": "koşul2" }, "model": { "name": "model" }, "negative": { "name": "negatif" }, "style": { "name": "stil" } } };
const DualCLIPLoader = { "description": "[Tarifler]\n\nsdxl: clip-l, clip-g\nsd3: clip-l, clip-g / clip-l, t5 / clip-g, t5\nflux: clip-l, t5\nhidream: t5 veya llama'dan en az biri, t5 ve llama önerilir", "display_name": "İkili CLIP Yükleyici", "inputs": { "clip_name1": { "name": "clip_adı1" }, "clip_name2": { "name": "clip_adı2" }, "device": { "name": "cihaz" }, "type": { "name": "tür" } } };
const EasyCache = { "description": "Yerel KolayÖnbellek uygulaması.", "display_name": "KolayÖnbellek", "inputs": { "end_percent": { "name": "bitiş_yüzdesi", "tooltip": "KolayÖnbellek kullanımının sona ereceği göreceli örnekleme adımı." }, "model": { "name": "model", "tooltip": "KolayÖnbellek eklenen model." }, "reuse_threshold": { "name": "yeniden_kullanım_eşiği", "tooltip": "Önbelleğe alınmış adımların yeniden kullanım eşiği." }, "start_percent": { "name": "başlangıç_yüzdesi", "tooltip": "KolayÖnbellek kullanımının başlayacağı göreceli örnekleme adımı." }, "verbose": { "name": "ayrıntılı", "tooltip": "Ayrıntılı bilgilerin günlüğe kaydedilip kaydedilmeyeceği." } }, "outputs": { "0": { "tooltip": "KolayÖnbellek ile model." } } };
const EmptyAceStepLatentAudio = { "display_name": "BoşAceAdımGizliSes", "inputs": { "batch_size": { "name": "toplu_iş_boyutu", "tooltip": "Toplu işteki gizli görsellerin sayısı." }, "seconds": { "name": "saniye" } }, "outputs": { "0": { "tooltip": null } } };
const EmptyAudio = { "display_name": "Boş Ses", "inputs": { "channels": { "name": "kanallar", "tooltip": "Ses kanalı sayısı (1 mono, 2 stereo için)." }, "duration": { "name": "süre", "tooltip": "Boş ses klibinin saniye cinsinden süresi" }, "sample_rate": { "name": "örnekleme_oranı", "tooltip": "Boş ses klibinin örnekleme oranı." } } };
const EmptyChromaRadianceLatentImage = { "display_name": "BoşKromaIşımaGizliGörsel", "inputs": { "batch_size": { "name": "toplu_iş_boyutu" }, "height": { "name": "yükseklik" }, "width": { "name": "genişlik" } }, "outputs": { "0": { "tooltip": null } } };
const EmptyCosmosLatentVideo = { "display_name": "BoşCosmosGizliVideo", "inputs": { "batch_size": { "name": "toplu_boyut" }, "height": { "name": "yükseklik" }, "length": { "name": "uzunluk" }, "width": { "name": "genişlik" } }, "outputs": { "0": { "tooltip": null } } };
const EmptyHunyuanImageLatent = { "display_name": "Boş Hunyuan Görüntü Gizli", "inputs": { "batch_size": { "name": "toplu_işlem_boyutu" }, "height": { "name": "yükseklik" }, "width": { "name": "genişlik" } }, "outputs": { "0": { "tooltip": null } } };
const EmptyHunyuanLatentVideo = { "display_name": "BoşHunyuanGizliVideo", "inputs": { "batch_size": { "name": "toplu_boyut" }, "height": { "name": "yükseklik" }, "length": { "name": "uzunluk" }, "width": { "name": "genişlik" } }, "outputs": { "0": { "tooltip": null } } };
const EmptyImage = { "display_name": "Boş Görüntü", "inputs": { "batch_size": { "name": "toplu_boyut" }, "color": { "name": "renk" }, "height": { "name": "yükseklik" }, "width": { "name": "genişlik" } } };
const EmptyLTXVLatentVideo = { "display_name": "BoşLTXVGizliVideo", "inputs": { "batch_size": { "name": "toplu_boyut" }, "height": { "name": "yükseklik" }, "length": { "name": "uzunluk" }, "width": { "name": "genişlik" } }, "outputs": { "0": { "tooltip": null } } };
const EmptyLatentAudio = { "display_name": "Boş Gizli Ses", "inputs": { "batch_size": { "name": "toplu_boyut", "tooltip": "Toplu işlemdeki gizli görüntülerin sayısı." }, "seconds": { "name": "saniye" } } };
const EmptyLatentHunyuan3Dv2 = { "display_name": "BoşGizliHunyuan3Dv2", "inputs": { "batch_size": { "name": "toplu_boyut", "tooltip": "Toplu işlemdeki gizli görüntülerin sayısı." }, "resolution": { "name": "çözünürlük" } } };
const EmptyLatentImage = { "description": "Örnekleme yoluyla gürültüsü giderilecek yeni bir boş gizli görüntü grubu oluşturun.", "display_name": "Boş Gizli Görüntü", "inputs": { "batch_size": { "name": "toplu_boyut", "tooltip": "Toplu işlemdeki gizli görüntülerin sayısı." }, "height": { "name": "yükseklik", "tooltip": "Gizli görüntülerin piksel cinsinden yüksekliği." }, "width": { "name": "genişlik", "tooltip": "Gizli görüntülerin piksel cinsinden genişliği." } }, "outputs": { "0": { "tooltip": "Boş gizli görüntü grubu." } } };
const EmptyMochiLatentVideo = { "display_name": "BoşMochiGizliVideo", "inputs": { "batch_size": { "name": "toplu_boyut" }, "height": { "name": "yükseklik" }, "length": { "name": "uzunluk" }, "width": { "name": "genişlik" } }, "outputs": { "0": { "tooltip": null } } };
const EmptySD3LatentImage = { "display_name": "BoşSD3GizliGörüntü", "inputs": { "batch_size": { "name": "toplu_boyut" }, "height": { "name": "yükseklik" }, "width": { "name": "genişlik" } }, "outputs": { "0": { "tooltip": null } } };
const ExponentialScheduler = { "display_name": "Üstel Zamanlayıcı", "inputs": { "sigma_max": { "name": "sigma_maks" }, "sigma_min": { "name": "sigma_min" }, "steps": { "name": "adımlar" } } };
const ExtendIntermediateSigmas = { "display_name": "AraSigmalarıGenişlet", "inputs": { "end_at_sigma": { "name": "sigma_bitişi" }, "sigmas": { "name": "sigmalar" }, "spacing": { "name": "aralık" }, "start_at_sigma": { "name": "sigma_başlangıcı" }, "steps": { "name": "adımlar" } } };
const FeatherMask = { "display_name": "Maskeyi Yumuşat", "inputs": { "bottom": { "name": "alt" }, "left": { "name": "sol" }, "mask": { "name": "maske" }, "right": { "name": "sağ" }, "top": { "name": "üst" } } };
const FlipSigmas = { "display_name": "Sigmaları Çevir", "inputs": { "sigmas": { "name": "sigmalar" } } };
const FluxDisableGuidance = { "description": "Bu düğüm, Flux ve Flux benzeri modellerdeki rehberlik gömmesini tamamen devre dışı bırakır", "display_name": "FluxRehberliğiDevreDışıBırak", "inputs": { "conditioning": { "name": "koşullandırma" } }, "outputs": { "0": { "tooltip": null } } };
const FluxGuidance = { "display_name": "FluxRehberliği", "inputs": { "conditioning": { "name": "koşullandırma" }, "guidance": { "name": "rehberlik" } }, "outputs": { "0": { "tooltip": null } } };
const FluxKontextImageScale = { "description": "Bu düğüm, görüntüyü flux kontext için daha uygun bir boyuta yeniden boyutlandırır.", "display_name": "FluxKontext Görüntü Ölçeği", "inputs": { "image": { "name": "görüntü" } }, "outputs": { "0": { "tooltip": null } } };
const FluxKontextMaxImageNode = { "description": "Görüntüleri, istem ve en-boy oranına dayalı olarak API üzerinden Flux.1 Kontext [maks] kullanarak düzenler.", "display_name": "Flux.1 Kontext [maks] Görüntü", "inputs": { "aspect_ratio": { "name": "en-boy_oranı", "tooltip": "Görüntünün en-boy oranı; 1:4 ile 4:1 arasında olmalıdır." }, "control_after_generate": { "name": "oluşturma sonrası kontrol" }, "guidance": { "name": "rehberlik", "tooltip": "Görüntü oluşturma süreci için rehberlik gücü" }, "input_image": { "name": "girdi_görüntüsü" }, "prompt": { "name": "istem", "tooltip": "Görüntü oluşturma için istem - neyin ve nasıl düzenleneceğini belirtin." }, "prompt_upsampling": { "name": "istem_yukarı_örnekleme", "tooltip": "İstem üzerinde yukarı örnekleme yapılıp yapılmayacağı. Etkinse, istemi otomatik olarak daha yaratıcı oluşturma için değiştirir, ancak sonuçlar belirleyici değildir (aynı tohum tam olarak aynı sonucu üretmez)." }, "seed": { "name": "tohum", "tooltip": "Gürültü oluşturmak için kullanılan rastgele tohum." }, "steps": { "name": "adımlar", "tooltip": "Görüntü oluşturma süreci için adım sayısı" } }, "outputs": { "0": { "tooltip": null } } };
const FluxKontextMultiReferenceLatentMethod = { "display_name": "FluxKontext Çoklu Referans Gizli Yöntemi", "inputs": { "conditioning": { "name": "koşullandırma" }, "reference_latents_method": { "name": "referans_gizli_yöntemi" } }, "outputs": { "0": { "tooltip": null } } };
const FluxKontextProImageNode = { "description": "Görüntüleri, istem ve en-boy oranına dayalı olarak API üzerinden Flux.1 Kontext [pro] kullanarak düzenler.", "display_name": "Flux.1 Kontext [pro] Görüntü", "inputs": { "aspect_ratio": { "name": "en-boy_oranı", "tooltip": "Görüntünün en-boy oranı; 1:4 ile 4:1 arasında olmalıdır." }, "control_after_generate": { "name": "oluşturma sonrası kontrol" }, "guidance": { "name": "kılavuzluk", "tooltip": "Görüntü oluşturma süreci için kılavuzluk gücü" }, "input_image": { "name": "girdi_görseli" }, "prompt": { "name": "istem", "tooltip": "Görüntü oluşturma için istem - neyin ve nasıl düzenleneceğini belirtin." }, "prompt_upsampling": { "name": "istek_artırma", "tooltip": "İstek üzerinde yükseltme işlemi yapılıp yapılmayacağı. Aktifse, daha yaratıcı üretim için isteği otomatik olarak değiştirir, ancak sonuçlar belirleyici değildir (aynı tohum tam olarak aynı sonucu üretmez)." }, "seed": { "name": "tohum", "tooltip": "Gürültü oluşturmak için kullanılan rastgele tohum değeri." }, "steps": { "name": "adımlar", "tooltip": "Görüntü oluşturma süreci için adım sayısı" } }, "outputs": { "0": { "tooltip": null } } };
const FluxProExpandNode = { "description": "İsteme göre görüntüyü dışa doğru boyar.", "display_name": "Flux.1 Görüntüyü Genişlet", "inputs": { "bottom": { "name": "alt", "tooltip": "Görüntünün altında genişletilecek piksel sayısı" }, "control_after_generate": { "name": "oluşturduktan sonra kontrol et" }, "guidance": { "name": "rehberlik", "tooltip": "Görüntü oluşturma süreci için rehberlik gücü" }, "image": { "name": "görüntü" }, "left": { "name": "sol", "tooltip": "Görüntünün sol tarafında genişletilecek piksel sayısı" }, "prompt": { "name": "istem", "tooltip": "Görüntü oluşturma istemi" }, "prompt_upsampling": { "name": "istem_yükseltme", "tooltip": "İstem üzerinde yükseltme yapılıp yapılmayacağı. Etkinse, daha yaratıcı üretim için istemi otomatik olarak değiştirir, ancak sonuçlar belirleyici değildir (aynı tohum tam olarak aynı sonucu vermez)." }, "right": { "name": "sağ", "tooltip": "Görüntünün sağ tarafında genişletilecek piksel sayısı" }, "seed": { "name": "tohum", "tooltip": "Gürültüyü oluşturmak için kullanılan rastgele tohum." }, "steps": { "name": "adımlar", "tooltip": "Görüntü oluşturma süreci için adım sayısı" }, "top": { "name": "üst", "tooltip": "Görüntünün üstünde genişletilecek piksel sayısı" } }, "outputs": { "0": { "tooltip": null } } };
const FluxProFillNode = { "description": "Maske ve isteme göre görüntüyü içe doğru boyar.", "display_name": "Flux.1 Görüntüyü Doldur", "inputs": { "control_after_generate": { "name": "oluşturduktan sonra kontrol et" }, "guidance": { "name": "rehberlik", "tooltip": "Görüntü oluşturma süreci için rehberlik gücü" }, "image": { "name": "görüntü" }, "mask": { "name": "maske" }, "prompt": { "name": "istem", "tooltip": "Görüntü oluşturma istemi" }, "prompt_upsampling": { "name": "istem_yükseltme", "tooltip": "İstem üzerinde yükseltme yapılıp yapılmayacağı. Etkinse, daha yaratıcı üretim için istemi otomatik olarak değiştirir, ancak sonuçlar belirleyici değildir (aynı tohum tam olarak aynı sonucu vermez)." }, "seed": { "name": "tohum", "tooltip": "Gürültüyü oluşturmak için kullanılan rastgele tohum." }, "steps": { "name": "adımlar", "tooltip": "Görüntü oluşturma süreci için adım sayısı" } }, "outputs": { "0": { "tooltip": null } } };
const FluxProUltraImageNode = { "description": "İstem ve çözünürlüğe dayalı olarak api aracılığıyla Flux Pro 1.1 Ultra kullanarak görüntüler oluşturur.", "display_name": "Flux 1.1 [pro] Ultra Görüntü", "inputs": { "aspect_ratio": { "name": "en_boy_oranı", "tooltip": "Görüntünün en boy oranı; 1:4 ile 4:1 arasında olmalıdır." }, "control_after_generate": { "name": "oluşturduktan sonra kontrol et" }, "image_prompt": { "name": "görüntü_istemi" }, "image_prompt_strength": { "name": "görüntü_istemi_gücü", "tooltip": "İstem ile görüntü istemi arasında karıştırın." }, "prompt": { "name": "istem", "tooltip": "Görüntü oluşturma istemi" }, "prompt_upsampling": { "name": "istem_yükseltme", "tooltip": "İstem üzerinde yükseltme yapılıp yapılmayacağı. Etkinse, daha yaratıcı üretim için istemi otomatik olarak değiştirir, ancak sonuçlar belirleyici değildir (aynı tohum tam olarak aynı sonucu vermez)." }, "raw": { "name": "ham", "tooltip": "Doğru olduğunda, daha az işlenmiş, daha doğal görünümlü görüntüler oluşturun." }, "seed": { "name": "tohum", "tooltip": "Gürültüyü oluşturmak için kullanılan rastgele tohum." } }, "outputs": { "0": { "tooltip": null } } };
const FreSca = { "description": "Rehberliğe frekansa bağlı ölçeklendirme uygular", "display_name": "FreSca", "inputs": { "freq_cutoff": { "name": "frekans_kesme", "tooltip": "Merkez etrafındaki frekans indekslerinin düşük frekanslı olarak kabul edileceği sayı" }, "model": { "name": "model" }, "scale_high": { "name": "yüksek_ölçek", "tooltip": "Yüksek frekanslı bileşenler için ölçeklendirme faktörü" }, "scale_low": { "name": "düşük_ölçek", "tooltip": "Düşük frekanslı bileşenler için ölçeklendirme faktörü" } }, "outputs": { "0": { "tooltip": null } } };
const FreeU = { "display_name": "FreeU", "inputs": { "b1": { "name": "b1" }, "b2": { "name": "b2" }, "model": { "name": "model" }, "s1": { "name": "s1" }, "s2": { "name": "s2" } } };
const FreeU_V2 = { "display_name": "FreeU_V2", "inputs": { "b1": { "name": "b1" }, "b2": { "name": "b2" }, "model": { "name": "model" }, "s1": { "name": "s1" }, "s2": { "name": "s2" } } };
const GITSScheduler = { "display_name": "GITSZamanlayıcı", "inputs": { "coeff": { "name": "katsayı" }, "denoise": { "name": "gürültü_azaltma" }, "steps": { "name": "adımlar" } }, "outputs": { "0": { "tooltip": null } } };
const GLIGENLoader = { "display_name": "GLIGENYükleyici", "inputs": { "gligen_name": { "name": "gligen_adı" } } };
const GLIGENTextBoxApply = { "display_name": "GLIGENMetinKutusuUygula", "inputs": { "clip": { "name": "clip" }, "conditioning_to": { "name": "hedef_koşullandırma" }, "gligen_textbox_model": { "name": "gligen_metinkutusu_modeli" }, "height": { "name": "yükseklik" }, "text": { "name": "metin" }, "width": { "name": "genişlik" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const GeminiImageNode = { "description": "Google API üzerinden görüntüleri eşzamanlı olarak düzenleyin.", "display_name": "Google Gemini Görsel", "inputs": { "aspect_ratio": { "name": "en_boy_oranı", "tooltip": "Varsayılan olarak çıktı görsel boyutunu girdi görselinizin boyutuna uyacak şekilde ayarlar veya aksi halde 1:1 kareler oluşturur." }, "control_after_generate": { "name": "oluşturma sonrası kontrol" }, "files": { "name": "dosyalar", "tooltip": "Model için bağlam olarak kullanılacak isteğe bağlı dosya(lar). Gemini İçerik Oluşturma Girdi Dosyaları düğümünden gelen girdileri kabul eder." }, "images": { "name": "görseller", "tooltip": "Model için bağlam olarak kullanılacak isteğe bağlı görsel(ler). Birden fazla görsel eklemek için Toplu Görseller düğümünü kullanabilirsiniz." }, "model": { "name": "model", "tooltip": "Yanıtlar oluşturmak için kullanılacak Gemini modeli." }, "prompt": { "name": "istek", "tooltip": "Oluşturma için metin isteği" }, "seed": { "name": "tohum", "tooltip": "Tohum belirli bir değere sabitlendiğinde, model tekrarlanan istekler için aynı yanıtı sağlamak için elinden geleni yapar. Belirleyici çıktı garanti edilmez. Ayrıca, modeli veya sıcaklık gibi parametre ayarlarını değiştirmek, aynı tohum değerini kullansanız bile yanıtta değişikliklere neden olabilir. Varsayılan olarak rastgele bir tohum değeri kullanılır." } }, "outputs": { "0": { "tooltip": null }, "1": { "tooltip": null } } };
const GeminiInputFiles = { "description": "Gemini LLM düğümleri için girdi olarak dahil edilecek girdi dosyalarını yükler ve hazırlar. Dosyalar, bir yanıt oluşturulurken Gemini modeli tarafından okunacaktır. Metin dosyasının içeriği belirteç sınırına dahildir. 🛈 İPUCU: Diğer Gemini Girdi Dosyası düğümleriyle zincirlenebilir.", "display_name": "Gemini Girdi Dosyaları", "inputs": { "GEMINI_INPUT_FILES": { "name": "GEMINI_GİRDİ_DOSYALARI", "tooltip": "Bu düğümden yüklenen dosyayla toplu olarak birleştirilecek isteğe bağlı ek dosya(lar). Tek bir mesajın birden fazla girdi dosyası içerebilmesi için girdi dosyalarının zincirlenmesine olanak tanır." }, "file": { "name": "dosya", "tooltip": "Model için bağlam olarak dahil edilecek girdi dosyaları. Şu an için yalnızca metin (.txt) ve PDF (.pdf) dosyalarını kabul eder." } }, "outputs": { "0": { "tooltip": null } } };
const GeminiNode = { "description": "Google'ın Gemini AI modeli ile metin yanıtları oluşturun. Daha alakalı ve anlamlı yanıtlar oluşturmak için bağlam olarak birden fazla girdi türü (metin, görseller, ses, video) sağlayabilirsiniz.", "display_name": "Google Gemini", "inputs": { "audio": { "name": "audio", "tooltip": "Model için bağlam olarak kullanılacak isteğe bağlı ses." }, "control_after_generate": { "name": "control after generate" }, "files": { "name": "files", "tooltip": "Model için bağlam olarak kullanılacak isteğe bağlı dosya(lar). Gemini İçerik Oluşturma Giriş Dosyaları düğümünden gelen girdileri kabul eder." }, "images": { "name": "images", "tooltip": "Model için bağlam olarak kullanılacak isteğe bağlı resim(ler). Birden fazla resim eklemek için Toplu Resimler düğümünü kullanabilirsiniz." }, "model": { "name": "model", "tooltip": "Yanıtlar oluşturmak için kullanılacak Gemini modeli." }, "prompt": { "name": "istek", "tooltip": "Modelin bir yanıt oluşturmak için kullandığı metin girdileri. Model için ayrıntılı talimatlar, sorular veya bağlam içerebilirsiniz." }, "seed": { "name": "seed", "tooltip": "Seed belirli bir değere sabitlendiğinde, model tekrarlanan istekler için aynı yanıtı sağlamak için elinden geleni yapar. Deterministik çıktı garanti edilmez. Ayrıca, modeli veya sıcaklık gibi parametre ayarlarını değiştirmek, aynı seed değerini kullansanız bile yanıtta değişikliklere neden olabilir. Varsayılan olarak rastgele bir seed değeri kullanılır." }, "video": { "name": "video", "tooltip": "Model için bağlam olarak kullanılacak isteğe bağlı video." } }, "outputs": { "0": { "tooltip": null } } };
const GetImageSize = { "description": "Resmin genişlik ve yüksekliğini döndürür ve değiştirmeden iletir.", "display_name": "Resim Boyutunu Al", "inputs": { "image": { "name": "image" } }, "outputs": { "0": { "name": "width" }, "1": { "name": "height" }, "2": { "name": "batch_size" } } };
const GetVideoComponents = { "description": "Bir videodan tüm bileşenleri çıkarır: kareler, ses ve kare hızı.", "display_name": "Video Bileşenlerini Al", "inputs": { "video": { "name": "video", "tooltip": "Bileşenlerin çıkarılacağı video." } }, "outputs": { "0": { "name": "görüntüler", "tooltip": null }, "1": { "name": "ses", "tooltip": null }, "2": { "name": "fps", "tooltip": null } } };
const GrowMask = { "display_name": "Maskeyi Büyüt", "inputs": { "expand": { "name": "genişlet" }, "mask": { "name": "maske" }, "tapered_corners": { "name": "sivri_köşeler" } } };
const Hunyuan3Dv2Conditioning = { "display_name": "Hunyuan3Dv2Koşullandırma", "inputs": { "clip_vision_output": { "name": "clip_görü_çıktısı" } }, "outputs": { "0": { "name": "pozitif" }, "1": { "name": "negatif" } } };
const Hunyuan3Dv2ConditioningMultiView = { "display_name": "Hunyuan3Dv2ÇokluGörünümKoşullandırma", "inputs": { "back": { "name": "arka" }, "front": { "name": "ön" }, "left": { "name": "sol" }, "right": { "name": "sağ" } }, "outputs": { "0": { "name": "pozitif" }, "1": { "name": "negatif" } } };
const HunyuanImageToVideo = { "display_name": "HunyuanGörüntüdenVideoya", "inputs": { "batch_size": { "name": "toplu_boyut" }, "guidance_type": { "name": "rehberlik_türü" }, "height": { "name": "yükseklik" }, "length": { "name": "uzunluk" }, "positive": { "name": "pozitif" }, "start_image": { "name": "başlangıç_görüntüsü" }, "vae": { "name": "vae" }, "width": { "name": "genişlik" } }, "outputs": { "0": { "name": "pozitif", "tooltip": null }, "1": { "name": "gizli", "tooltip": null } } };
const HunyuanRefinerLatent = { "display_name": "HunyuanRefinerLatent", "inputs": { "latent": { "name": "latent" }, "negative": { "name": "negative" }, "noise_augmentation": { "name": "noise_augmentation" }, "positive": { "name": "positive" } }, "outputs": { "0": { "name": "positive", "tooltip": null }, "1": { "name": "negative", "tooltip": null }, "2": { "name": "latent", "tooltip": null } } };
const HyperTile = { "display_name": "HiperDöşeme", "inputs": { "max_depth": { "name": "maks_derinlik" }, "model": { "name": "model" }, "scale_depth": { "name": "ölçek_derinliği" }, "swap_size": { "name": "değiştirme_boyutu" }, "tile_size": { "name": "döşeme_boyutu" } }, "outputs": { "0": { "tooltip": null } } };
const HypernetworkLoader = { "display_name": "HiperAğYükleyici", "inputs": { "hypernetwork_name": { "name": "hiperağ_adı" }, "model": { "name": "model" }, "strength": { "name": "güç" } }, "outputs": { "0": { "tooltip": null } } };
const IdeogramV1 = { "description": "Ideogram V1 modelini kullanarak eşzamanlı olarak görüntüler oluşturur.\n\nGörüntü bağlantıları sınırlı bir süre için mevcuttur; görüntüyü saklamak isterseniz indirmeniz gerekir.", "display_name": "Ideogram V1", "inputs": { "aspect_ratio": { "name": "en_boy_oranı", "tooltip": "Görüntü oluşturma için en boy oranı." }, "control_after_generate": { "name": "oluşturduktan sonra kontrol et" }, "magic_prompt_option": { "name": "sihirli_istem_seçeneği", "tooltip": "Üretimde MagicPrompt'un kullanılıp kullanılmayacağını belirleyin" }, "negative_prompt": { "name": "negatif_istem", "tooltip": "Görüntüden hariç tutulacakların açıklaması" }, "num_images": { "name": "görüntü_sayısı" }, "prompt": { "name": "istem", "tooltip": "Görüntü oluşturma istemi" }, "seed": { "name": "tohum" }, "turbo": { "name": "turbo", "tooltip": "Turbo modunun kullanılıp kullanılmayacağı (daha hızlı üretim, potansiyel olarak daha düşük kalite)" } }, "outputs": { "0": { "tooltip": null } } };
const IdeogramV2 = { "description": "Ideogram V2 modelini kullanarak eşzamanlı olarak görüntüler oluşturur.\n\nGörüntü bağlantıları sınırlı bir süre için mevcuttur; görüntüyü saklamak isterseniz indirmeniz gerekir.", "display_name": "Ideogram V2", "inputs": { "aspect_ratio": { "name": "en_boy_oranı", "tooltip": "Görüntü oluşturma için en boy oranı. Çözünürlük AUTO olarak ayarlanmadıysa yoksayılır." }, "control_after_generate": { "name": "oluşturduktan sonra kontrol et" }, "magic_prompt_option": { "name": "sihirli_istem_seçeneği", "tooltip": "Üretimde MagicPrompt'un kullanılıp kullanılmayacağını belirleyin" }, "negative_prompt": { "name": "negatif_istem", "tooltip": "Görüntüden hariç tutulacakların açıklaması" }, "num_images": { "name": "görüntü_sayısı" }, "prompt": { "name": "istem", "tooltip": "Görüntü oluşturma istemi" }, "resolution": { "name": "çözünürlük", "tooltip": "Görüntü oluşturma için çözünürlük. AUTO olarak ayarlanmadıysa, bu en_boy_oranı ayarını geçersiz kılar." }, "seed": { "name": "tohum" }, "style_type": { "name": "stil_türü", "tooltip": "Üretim için stil türü (yalnızca V2)" }, "turbo": { "name": "turbo", "tooltip": "Turbo modunun kullanılıp kullanılmayacağı (daha hızlı üretim, potansiyel olarak daha düşük kalite)" } }, "outputs": { "0": { "tooltip": null } } };
const IdeogramV3 = { "description": "Ideogram V3 modelini kullanarak eşzamanlı olarak görüntüler oluşturur.\n\nMetin istemlerinden normal görüntü oluşturmayı ve maske ile görüntü düzenlemeyi destekler.\nGörüntü bağlantıları sınırlı bir süre için mevcuttur; görüntüyü saklamak isterseniz indirmeniz gerekir.", "display_name": "Ideogram V3", "inputs": { "aspect_ratio": { "name": "en_boy_oranı", "tooltip": "Görüntü oluşturma için en boy oranı. Çözünürlük Otomatik olarak ayarlanmadıysa yoksayılır." }, "character_image": { "name": "character_image", "tooltip": "Karakter referansı olarak kullanılacak resim." }, "character_mask": { "name": "character_mask", "tooltip": "Karakter referans resmi için isteğe bağlı maske." }, "control_after_generate": { "name": "oluşturduktan sonra kontrol et" }, "image": { "name": "görüntü", "tooltip": "Görüntü düzenleme için isteğe bağlı referans görüntü." }, "magic_prompt_option": { "name": "sihirli_istem_seçeneği", "tooltip": "Üretimde MagicPrompt'un kullanılıp kullanılmayacağını belirleyin" }, "mask": { "name": "maske", "tooltip": "İç boyama için isteğe bağlı maske (beyaz alanlar değiştirilecektir)" }, "num_images": { "name": "görüntü_sayısı" }, "prompt": { "name": "istem", "tooltip": "Görüntü oluşturma veya düzenleme istemi" }, "rendering_speed": { "name": "oluşturma_hızı", "tooltip": "Üretim hızı ve kalite arasındaki dengeyi kontrol eder" }, "resolution": { "name": "çözünürlük", "tooltip": "Görüntü oluşturma için çözünürlük. Otomatik olarak ayarlanmadıysa, bu en_boy_oranı ayarını geçersiz kılar." }, "seed": { "name": "tohum" } }, "outputs": { "0": { "tooltip": null } } };
const ImageAddNoise = { "display_name": "ImageAddNoise", "inputs": { "control_after_generate": { "name": "oluşturma sonrası kontrol" }, "image": { "name": "image" }, "seed": { "name": "seed", "tooltip": "Gürültü oluşturmak için kullanılan rastgele seed." }, "strength": { "name": "güç" } } };
const ImageBatch = { "display_name": "Görüntüleri Toplu İşle", "inputs": { "image1": { "name": "görüntü1" }, "image2": { "name": "görüntü2" } } };
const ImageBlend = { "display_name": "Görüntü Karıştırma", "inputs": { "blend_factor": { "name": "karıştırma_faktörü" }, "blend_mode": { "name": "karıştırma_modu" }, "image1": { "name": "görüntü1" }, "image2": { "name": "görüntü2" } }, "outputs": { "0": { "tooltip": null } } };
const ImageBlur = { "display_name": "Görüntü Bulanıklaştırma", "inputs": { "blur_radius": { "name": "bulanıklık_yarıçapı" }, "image": { "name": "görüntü" }, "sigma": { "name": "sigma" } }, "outputs": { "0": { "tooltip": null } } };
const ImageColorToMask = { "display_name": "GörüntüRenginiMaskeyeDönüştür", "inputs": { "color": { "name": "renk" }, "image": { "name": "görüntü" } } };
const ImageCompositeMasked = { "display_name": "MaskeliGörüntüBirleştirme", "inputs": { "destination": { "name": "hedef" }, "mask": { "name": "maske" }, "resize_source": { "name": "kaynağı_yeniden_boyutlandır" }, "source": { "name": "kaynak" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const ImageCrop = { "display_name": "Görüntü Kırp", "inputs": { "height": { "name": "yükseklik" }, "image": { "name": "görüntü" }, "width": { "name": "genişlik" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const ImageFlip = { "display_name": "Görüntü Çevirme", "inputs": { "flip_method": { "name": "çevirme yöntemi" }, "image": { "name": "görüntü" } } };
const ImageFromBatch = { "display_name": "TopluİşlemdenGörüntü", "inputs": { "batch_index": { "name": "toplu_indeks" }, "image": { "name": "görüntü" }, "length": { "name": "uzunluk" } } };
const ImageInvert = { "display_name": "Görüntüyü Ters Çevir", "inputs": { "image": { "name": "görüntü" } } };
const ImageOnlyCheckpointLoader = { "display_name": "Sadece Görüntü Kontrol Noktası Yükleyici (img2vid modeli)", "inputs": { "ckpt_name": { "name": "ckpt_adı" } } };
const ImageOnlyCheckpointSave = { "display_name": "SadeceGörüntüKontrolNoktasıKaydet", "inputs": { "clip_vision": { "name": "clip_görü" }, "filename_prefix": { "name": "dosyaadı_öneki" }, "model": { "name": "model" }, "vae": { "name": "vae" } } };
const ImagePadForOutpaint = { "display_name": "Dış Boyama için Görüntüyü Doldur", "inputs": { "bottom": { "name": "alt" }, "feathering": { "name": "yumuşatma" }, "image": { "name": "görüntü" }, "left": { "name": "sol" }, "right": { "name": "sağ" }, "top": { "name": "üst" } } };
const ImageQuantize = { "display_name": "Görüntü Nicemleme", "inputs": { "colors": { "name": "renkler" }, "dither": { "name": "titreşim" }, "image": { "name": "görüntü" } }, "outputs": { "0": { "tooltip": null } } };
const ImageRGBToYUV = { "display_name": "GörüntüRGB'denYUV'ye", "inputs": { "image": { "name": "görüntü" } }, "outputs": { "0": { "name": "Y", "tooltip": null }, "1": { "name": "U", "tooltip": null }, "2": { "name": "V", "tooltip": null } } };
const ImageRotate = { "display_name": "Görüntü Döndürme", "inputs": { "image": { "name": "görüntü" }, "rotation": { "name": "döndürme" } } };
const ImageScale = { "display_name": "Görüntüyü Büyüt", "inputs": { "crop": { "name": "kırp" }, "height": { "name": "yükseklik" }, "image": { "name": "görüntü" }, "upscale_method": { "name": "büyütme_yöntemi" }, "width": { "name": "genişlik" } } };
const ImageScaleBy = { "display_name": "Görüntüyü Oranla Büyüt", "inputs": { "image": { "name": "görüntü" }, "scale_by": { "name": "oranla_büyüt" }, "upscale_method": { "name": "büyütme_yöntemi" } } };
const ImageScaleToMaxDimension = { "display_name": "Görüntüyü Maksimum Boyuta Ölçekle", "inputs": { "image": { "name": "görüntü" }, "largest_size": { "name": "en büyük boyut" }, "upscale_method": { "name": "ölçeklendirme yöntemi" } } };
const ImageScaleToTotalPixels = { "display_name": "Görüntüyü Toplam Piksele Göre Ölçekle", "inputs": { "image": { "name": "görüntü" }, "megapixels": { "name": "megapiksel" }, "upscale_method": { "name": "büyütme_yöntemi" } }, "outputs": { "0": { "tooltip": null } } };
const ImageSharpen = { "display_name": "Görüntü Keskinleştir", "inputs": { "alpha": { "name": "alfa" }, "image": { "name": "görüntü" }, "sharpen_radius": { "name": "keskinleştirme_yarıçapı" }, "sigma": { "name": "sigma" } }, "outputs": { "0": { "tooltip": null } } };
const ImageStitch = { "description": "\nimage2'yi image1'e belirtilen yönde birleştirir.\nEğer image2 sağlanmazsa, image1'i değiştirmeden döndürür.\nGörüntüler arasına isteğe bağlı boşluk eklenebilir.\n", "display_name": "Görüntü Birleştirme", "inputs": { "direction": { "name": "yön" }, "image1": { "name": "image1" }, "image2": { "name": "image2" }, "match_image_size": { "name": "görüntü boyutunu eşle" }, "spacing_color": { "name": "boşluk rengi" }, "spacing_width": { "name": "boşluk genişliği" } } };
const ImageToMask = { "display_name": "Görüntüyü Maskeye Dönüştür", "inputs": { "channel": { "name": "kanal" }, "image": { "name": "görüntü" } } };
const ImageUpscaleWithModel = { "display_name": "Görüntüyü Büyüt (Model kullanarak)", "inputs": { "image": { "name": "görüntü" }, "upscale_model": { "name": "büyütme_modeli" } }, "outputs": { "0": { "tooltip": null } } };
const ImageYUVToRGB = { "display_name": "GörüntüYUV'denRGB'ye", "inputs": { "U": { "name": "U" }, "V": { "name": "V" }, "Y": { "name": "Y" } }, "outputs": { "0": { "tooltip": null } } };
const InpaintModelConditioning = { "display_name": "İçBoyaModelKoşullandırma", "inputs": { "mask": { "name": "maske" }, "negative": { "name": "negatif" }, "noise_mask": { "name": "gürültü_maskesi", "tooltip": "Gizli değişkene bir gürültü maskesi ekleyin, böylece örnekleme yalnızca maske içinde gerçekleşir. Modele bağlı olarak sonuçları iyileştirebilir veya tamamen bozabilir." }, "pixels": { "name": "pikseller" }, "positive": { "name": "pozitif" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "pozitif" }, "1": { "name": "negatif" }, "2": { "name": "gizli" } } };
const InstructPixToPixConditioning = { "display_name": "InstructPixToPixKoşullandırma", "inputs": { "negative": { "name": "negatif" }, "pixels": { "name": "pikseller" }, "positive": { "name": "pozitif" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "pozitif", "tooltip": null }, "1": { "name": "negatif", "tooltip": null }, "2": { "name": "gizli", "tooltip": null } } };
const InvertMask = { "display_name": "Maskeyi Ters Çevir", "inputs": { "mask": { "name": "maske" } } };
const JoinImageWithAlpha = { "display_name": "Görüntüyü Alfa ile Birleştir", "inputs": { "alpha": { "name": "alfa" }, "image": { "name": "görüntü" } }, "outputs": { "0": { "tooltip": null } } };
const KSampler = { "description": "Gizli görüntünün gürültüsünü azaltmak için sağlanan modeli, pozitif ve negatif koşullandırmayı kullanır.", "display_name": "KSampler", "inputs": { "cfg": { "name": "cfg", "tooltip": "Sınıflandırıcısız Rehberlik ölçeği, yaratıcılık ile isteme bağlılık arasında bir denge kurar. Daha yüksek değerler, isteme daha yakından eşleşen görüntülerle sonuçlanır, ancak çok yüksek değerler kaliteyi olumsuz etkiler." }, "control_after_generate": { "name": "oluşturduktan sonra kontrol et" }, "denoise": { "name": "gürültü_azaltma", "tooltip": "Uygulanan gürültü giderme miktarı, daha düşük değerler ilk görüntünün yapısını koruyarak görüntüden görüntüye örneklemeye olanak tanır." }, "latent_image": { "name": "gizli_görüntü", "tooltip": "Gürültüsü giderilecek gizli görüntü." }, "model": { "name": "model", "tooltip": "Giriş gizli değişkeninin gürültüsünü azaltmak için kullanılan model." }, "negative": { "name": "negatif", "tooltip": "Görüntüden hariç tutmak istediğiniz özellikleri tanımlayan koşullandırma." }, "positive": { "name": "pozitif", "tooltip": "Görüntüye dahil etmek istediğiniz özellikleri tanımlayan koşullandırma." }, "sampler_name": { "name": "örnekleyici_adı", "tooltip": "Örnekleme sırasında kullanılan algoritma, bu, oluşturulan çıktının kalitesini, hızını ve stilini etkileyebilir." }, "scheduler": { "name": "zamanlayıcı", "tooltip": "Zamanlayıcı, görüntüyü oluşturmak için gürültünün kademeli olarak nasıl kaldırılacağını kontrol eder." }, "seed": { "name": "tohum", "tooltip": "Gürültüyü oluşturmak için kullanılan rastgele tohum." }, "steps": { "name": "adımlar", "tooltip": "Gürültü giderme işleminde kullanılan adım sayısı." } }, "outputs": { "0": { "tooltip": "Gürültüsü giderilmiş gizli değişken." } } };
const KSamplerAdvanced = { "display_name": "KSampler (Gelişmiş)", "inputs": { "add_noise": { "name": "gürültü_ekle" }, "cfg": { "name": "cfg" }, "control_after_generate": { "name": "oluşturduktan sonra kontrol et" }, "end_at_step": { "name": "bitiş_adımı" }, "latent_image": { "name": "gizli_görüntü" }, "model": { "name": "model" }, "negative": { "name": "negatif" }, "noise_seed": { "name": "gürültü_tohumu" }, "positive": { "name": "pozitif" }, "return_with_leftover_noise": { "name": "kalan_gürültüyle_dön" }, "sampler_name": { "name": "örnekleyici_adı" }, "scheduler": { "name": "zamanlayıcı" }, "start_at_step": { "name": "başlangıç_adımı" }, "steps": { "name": "adımlar" } } };
const KSamplerSelect = { "display_name": "KSamplerSeç", "inputs": { "sampler_name": { "name": "örnekleyici_adı" } } };
const KarrasScheduler = { "display_name": "KarrasZamanlayıcı", "inputs": { "rho": { "name": "rho" }, "sigma_max": { "name": "sigma_maks" }, "sigma_min": { "name": "sigma_min" }, "steps": { "name": "adımlar" } } };
const KlingCameraControlI2VNode = { "description": "Gerçek dünya sinematografisini simüle eden profesyonel kamera hareketleriyle durağan görüntüleri sinematik videolara dönüştürün. Orijinal görüntünüze odaklanırken yakınlaştırma, döndürme, kaydırma, eğme ve birinci şahıs görünümü dahil olmak üzere sanal kamera eylemlerini kontrol edin.", "display_name": "Kling Görüntüden Videoya (Kamera Kontrolü)", "inputs": { "aspect_ratio": { "name": "en_boy_oranı" }, "camera_control": { "name": "kamera_kontrolü", "tooltip": "Kling Kamera Kontrolleri düğümü kullanılarak oluşturulabilir. Video oluşturma sırasında kamera hareketini ve devinimini kontrol eder." }, "cfg_scale": { "name": "cfg_ölçeği" }, "negative_prompt": { "name": "negatif_istem", "tooltip": "Negatif metin istemi" }, "prompt": { "name": "istem", "tooltip": "Pozitif metin istemi" }, "start_frame": { "name": "başlangıç_karesi", "tooltip": "Referans Görüntü - URL veya Base64 kodlu dize, 10 MB'ı geçemez, çözünürlük 300*300 pikselden az olamaz, en boy oranı 1:2.5 ~ 2.5:1 arasındadır. Base64, data:image önekini içermemelidir." } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "video_kimliği", "tooltip": null }, "2": { "name": "süre", "tooltip": null } } };
const KlingCameraControlT2VNode = { "description": "Gerçek dünya sinematografisini simüle eden profesyonel kamera hareketleriyle metni sinematik videolara dönüştürün. Orijinal metninize odaklanırken yakınlaştırma, döndürme, kaydırma, eğme ve birinci şahıs görünümü dahil olmak üzere sanal kamera eylemlerini kontrol edin.", "display_name": "Kling Metinden Videoya (Kamera Kontrolü)", "inputs": { "aspect_ratio": { "name": "en_boy_oranı" }, "camera_control": { "name": "kamera_kontrolü", "tooltip": "Kling Kamera Kontrolleri düğümü kullanılarak oluşturulabilir. Video oluşturma sırasında kamera hareketini ve devinimini kontrol eder." }, "cfg_scale": { "name": "cfg_ölçeği" }, "negative_prompt": { "name": "negatif_istem", "tooltip": "Negatif metin istemi" }, "prompt": { "name": "istem", "tooltip": "Pozitif metin istemi" } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "video_kimliği", "tooltip": null }, "2": { "name": "süre", "tooltip": null } } };
const KlingCameraControls = { "description": "Kling Kamera Kontrolleri ve hareket kontrolü efektleri için yapılandırma seçeneklerini belirtmeye olanak tanır.", "display_name": "Kling Kamera Kontrolleri", "inputs": { "camera_control_type": { "name": "kamera_kontrol_türü" }, "horizontal_movement": { "name": "yatay_hareket", "tooltip": "Kameranın yatay eksen (x ekseni) boyunca hareketini kontrol eder. Negatif sola, pozitif sağa gösterir" }, "pan": { "name": "kaydırma", "tooltip": "Kameranın dikey düzlemde (x ekseni) dönüşünü kontrol eder. Negatif aşağı dönüşü, pozitif yukarı dönüşü gösterir." }, "roll": { "name": "yuvarlanma", "tooltip": "Kameranın yuvarlanma miktarını (z ekseni) kontrol eder. Negatif saat yönünün tersini, pozitif saat yönünü gösterir." }, "tilt": { "name": "eğme", "tooltip": "Kameranın yatay düzlemde (y ekseni) dönüşünü kontrol eder. Negatif sola dönüşü, pozitif sağa dönüşü gösterir." }, "vertical_movement": { "name": "dikey_hareket", "tooltip": "Kameranın dikey eksen (y ekseni) boyunca hareketini kontrol eder. Negatif aşağı, pozitif yukarı gösterir." }, "zoom": { "name": "yakınlaştırma", "tooltip": "Kameranın odak uzaklığındaki değişikliği kontrol eder. Negatif daha dar bir görüş alanını, pozitif daha geniş bir görüş alanını gösterir." } }, "outputs": { "0": { "name": "kamera_kontrolü", "tooltip": null } } };
const KlingDualCharacterVideoEffectNode = { "description": "Efekt_sahnesine dayalı bir video oluştururken farklı özel efektler elde edin. İlk görüntü sol tarafa, ikinci görüntü ise birleşimin sağ tarafına konumlandırılacaktır.", "display_name": "Kling İkili Karakter Video Efektleri", "inputs": { "duration": { "name": "süre" }, "effect_scene": { "name": "efekt_sahnesi" }, "image_left": { "name": "sol_görüntü", "tooltip": "Sol taraf görüntüsü" }, "image_right": { "name": "sağ_görüntü", "tooltip": "Sağ taraf görüntüsü" }, "mode": { "name": "mod" }, "model_name": { "name": "model_adı" } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "süre", "tooltip": null } } };
const KlingImage2VideoNode = { "display_name": "Kling Görüntüden Videoya", "inputs": { "aspect_ratio": { "name": "en_boy_oranı" }, "cfg_scale": { "name": "cfg_ölçeği" }, "duration": { "name": "süre" }, "mode": { "name": "mod" }, "model_name": { "name": "model_adı" }, "negative_prompt": { "name": "negatif_istem", "tooltip": "Negatif metin istemi" }, "prompt": { "name": "istem", "tooltip": "Pozitif metin istemi" }, "start_frame": { "name": "başlangıç_karesi", "tooltip": "Referans Görüntü - URL veya Base64 kodlu dize, 10 MB'ı geçemez, çözünürlük 300*300 pikselden az olamaz, en boy oranı 1:2.5 ~ 2.5:1 arasındadır. Base64, data:image önekini içermemelidir." } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "video_kimliği", "tooltip": null }, "2": { "name": "süre", "tooltip": null } } };
const KlingImageGenerationNode = { "description": "Kling Görüntü Oluşturma Düğümü. İsteğe bağlı bir referans görüntü ile bir metin isteminden bir görüntü oluşturun.", "display_name": "Kling Görüntü Oluşturma", "inputs": { "aspect_ratio": { "name": "en_boy_oranı" }, "human_fidelity": { "name": "insan_sadakati", "tooltip": "Konu referans benzerliği" }, "image": { "name": "görüntü" }, "image_fidelity": { "name": "görüntü_sadakati", "tooltip": "Kullanıcı tarafından yüklenen görüntüler için referans yoğunluğu" }, "image_type": { "name": "görüntü_türü" }, "model_name": { "name": "model_adı" }, "n": { "name": "n", "tooltip": "Oluşturulan görüntü sayısı" }, "negative_prompt": { "name": "negatif_istem", "tooltip": "Negatif metin istemi" }, "prompt": { "name": "istem", "tooltip": "Pozitif metin istemi" } }, "outputs": { "0": { "tooltip": null } } };
const KlingLipSyncAudioToVideoNode = { "description": "Kling Dudak Senkronizasyonu Sesten Videoya Düğümü. Bir video dosyasındaki ağız hareketlerini bir ses dosyasının ses içeriğiyle senkronize eder.", "display_name": "Kling Dudak Senkronizasyonu Video ile Ses", "inputs": { "audio": { "name": "ses" }, "video": { "name": "video" }, "voice_language": { "name": "ses_dili" } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "video_kimliği", "tooltip": null }, "2": { "name": "süre", "tooltip": null } } };
const KlingLipSyncTextToVideoNode = { "description": "Kling Dudak Senkronizasyonu Metinden Videoya Düğümü. Bir video dosyasındaki ağız hareketlerini bir metin istemiyle senkronize eder.", "display_name": "Kling Dudak Senkronizasyonu Video ile Metin", "inputs": { "text": { "name": "metin", "tooltip": "Dudak Senkronizasyonu Video Oluşturma için Metin İçeriği. Mod metinden videoya olduğunda gereklidir. Maksimum uzunluk 120 karakterdir." }, "video": { "name": "video" }, "voice": { "name": "ses" }, "voice_speed": { "name": "ses_hızı", "tooltip": "Konuşma Hızı. Geçerli aralık: 0.8~2.0, bir ondalık basamağa kadar doğru." } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "video_kimliği", "tooltip": null }, "2": { "name": "süre", "tooltip": null } } };
const KlingSingleImageVideoEffectNode = { "description": "Efekt_sahnesine dayalı bir video oluştururken farklı özel efektler elde edin.", "display_name": "Kling Video Efektleri", "inputs": { "duration": { "name": "süre" }, "effect_scene": { "name": "efekt_sahnesi" }, "image": { "name": "görüntü", "tooltip": " Referans Görüntü. URL veya Base64 kodlu dize (data:image öneki olmadan). Dosya boyutu 10 MB'ı geçemez, çözünürlük 300*300 pikselden az olamaz, en boy oranı 1:2.5 ~ 2.5:1 arasındadır" }, "model_name": { "name": "model_adı" } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "video_kimliği", "tooltip": null }, "2": { "name": "süre", "tooltip": null } } };
const KlingStartEndFrameNode = { "description": "Sağladığınız başlangıç ve bitiş görüntüleri arasında geçiş yapan bir video dizisi oluşturun. Düğüm, aradaki tüm kareleri oluşturarak ilk kareden son kareye pürüzsüz bir dönüşüm üretir.", "display_name": "Kling Başlangıç-Bitiş Karesinden Videoya", "inputs": { "aspect_ratio": { "name": "en_boy_oranı" }, "cfg_scale": { "name": "cfg_ölçeği" }, "end_frame": { "name": "bitiş_karesi", "tooltip": "Referans Görüntü - Bitiş karesi kontrolü. URL veya Base64 kodlu dize, 10 MB'ı geçemez, çözünürlük 300*300 pikselden az olamaz. Base64, data:image önekini içermemelidir." }, "mode": { "name": "mod", "tooltip": "Video oluşturma için kullanılacak yapılandırma, şu formatı izler: mod / süre / model_adı." }, "negative_prompt": { "name": "negatif_istem", "tooltip": "Negatif metin istemi" }, "prompt": { "name": "istem", "tooltip": "Pozitif metin istemi" }, "start_frame": { "name": "başlangıç_karesi", "tooltip": "Referans Görüntü - URL veya Base64 kodlu dize, 10 MB'ı geçemez, çözünürlük 300*300 pikselden az olamaz, en boy oranı 1:2.5 ~ 2.5:1 arasındadır. Base64, data:image önekini içermemelidir." } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "video_kimliği", "tooltip": null }, "2": { "name": "süre", "tooltip": null } } };
const KlingTextToVideoNode = { "description": "Kling Metinden Videoya Düğümü", "display_name": "Kling Metinden Videoya", "inputs": { "aspect_ratio": { "name": "en_boy_oranı" }, "cfg_scale": { "name": "cfg_ölçeği" }, "mode": { "name": "mod", "tooltip": "Video oluşturma için kullanılacak yapılandırma, şu formatı izler: mod / süre / model_adı." }, "negative_prompt": { "name": "negatif_istem", "tooltip": "Negatif metin istemi" }, "prompt": { "name": "istem", "tooltip": "Pozitif metin istemi" } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "video_kimliği", "tooltip": null }, "2": { "name": "süre", "tooltip": null } } };
const KlingVideoExtendNode = { "description": "Kling Video Uzatma Düğümü. Diğer Kling düğümleri tarafından yapılan videoları uzatın. video_id, diğer Kling Düğümleri kullanılarak oluşturulur.", "display_name": "Kling Video Uzatma", "inputs": { "cfg_scale": { "name": "cfg_ölçeği" }, "negative_prompt": { "name": "negatif_istem", "tooltip": "Uzatılmış videoda kaçınılması gereken öğeler için negatif metin istemi" }, "prompt": { "name": "istem", "tooltip": "Video uzatmayı yönlendirmek için pozitif metin istemi" }, "video_id": { "name": "video_kimliği", "tooltip": "Uzatılacak videonun kimliği. Metinden videoya, görüntüden videoya ve önceki video uzatma işlemlerinden oluşturulan videoları destekler. Uzatmadan sonra toplam süre 3 dakikayı geçemez." } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "video_kimliği", "tooltip": null }, "2": { "name": "süre", "tooltip": null } } };
const KlingVirtualTryOnNode = { "description": "Kling Sanal Deneme Düğümü. İnsan üzerine kıyafet denemek için bir insan resmi ve bir kıyafet resmi girin.", "display_name": "Kling Sanal Deneme", "inputs": { "cloth_image": { "name": "kıyafet_görüntüsü" }, "human_image": { "name": "insan_görüntüsü" }, "model_name": { "name": "model_adı" } }, "outputs": { "0": { "tooltip": null } } };
const LTXVAddGuide = { "display_name": "LTXVRehberEkle", "inputs": { "frame_idx": { "name": "kare_indeksi", "tooltip": "Koşullandırmanın başlayacağı kare indeksi. Tek kareli görüntüler veya 1-8 kareli videolar için herhangi bir kare_indeksi değeri kabul edilebilir. 9+ kareli videolar için kare_indeksi 8'e bölünebilir olmalıdır, aksi takdirde en yakın 8'in katına yuvarlanacaktır. Negatif değerler videonun sonundan sayılır." }, "image": { "name": "görüntü", "tooltip": "Gizli videoyu koşullandırmak için görüntü veya video. 8*n + 1 kare olmalıdır. Video 8*n + 1 kare değilse, en yakın 8*n + 1 kareye kırpılacaktır." }, "latent": { "name": "gizli" }, "negative": { "name": "negatif" }, "positive": { "name": "pozitif" }, "strength": { "name": "güç" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "pozitif", "tooltip": null }, "1": { "name": "negatif", "tooltip": null }, "2": { "name": "gizli", "tooltip": null } } };
const LTXVConditioning = { "display_name": "LTXVKoşullandırma", "inputs": { "frame_rate": { "name": "kare_hızı" }, "negative": { "name": "negatif" }, "positive": { "name": "pozitif" } }, "outputs": { "0": { "name": "pozitif", "tooltip": null }, "1": { "name": "negatif", "tooltip": null } } };
const LTXVCropGuides = { "display_name": "LTXVRehberleriKırp", "inputs": { "latent": { "name": "gizli" }, "negative": { "name": "negatif" }, "positive": { "name": "pozitif" } }, "outputs": { "0": { "name": "pozitif", "tooltip": null }, "1": { "name": "negatif", "tooltip": null }, "2": { "name": "gizli", "tooltip": null } } };
const LTXVImgToVideo = { "display_name": "LTXVGörüntüdenVideoya", "inputs": { "batch_size": { "name": "toplu_boyut" }, "height": { "name": "yükseklik" }, "image": { "name": "görüntü" }, "length": { "name": "uzunluk" }, "negative": { "name": "negatif" }, "positive": { "name": "pozitif" }, "strength": { "name": "güç" }, "vae": { "name": "vae" }, "width": { "name": "genişlik" } }, "outputs": { "0": { "name": "pozitif", "tooltip": null }, "1": { "name": "negatif", "tooltip": null }, "2": { "name": "gizli", "tooltip": null } } };
const LTXVPreprocess = { "display_name": "LTXVÖnİşleme", "inputs": { "image": { "name": "görüntü" }, "img_compression": { "name": "görüntü_sıkıştırma", "tooltip": "Görüntüye uygulanacak sıkıştırma miktarı." } }, "outputs": { "0": { "name": "çıktı_görüntüsü", "tooltip": null } } };
const LTXVScheduler = { "display_name": "LTXVZamanlayıcı", "inputs": { "base_shift": { "name": "temel_kaydırma" }, "latent": { "name": "gizli" }, "max_shift": { "name": "maks_kaydırma" }, "steps": { "name": "adımlar" }, "stretch": { "name": "uzatma", "tooltip": "Sigmaları [terminal, 1] aralığında olacak şekilde uzatın." }, "terminal": { "name": "terminal", "tooltip": "Uzatmadan sonra sigmaların terminal değeri." } }, "outputs": { "0": { "tooltip": null } } };
const LaplaceScheduler = { "display_name": "LaplaceZamanlayıcı", "inputs": { "beta": { "name": "beta" }, "mu": { "name": "mu" }, "sigma_max": { "name": "sigma_maks" }, "sigma_min": { "name": "sigma_min" }, "steps": { "name": "adımlar" } } };
const LatentAdd = { "display_name": "GizliEkle", "inputs": { "samples1": { "name": "örnekler1" }, "samples2": { "name": "örnekler2" } }, "outputs": { "0": { "tooltip": null } } };
const LatentApplyOperation = { "display_name": "GizliİşlemUygula", "inputs": { "operation": { "name": "işlem" }, "samples": { "name": "örnekler" } }, "outputs": { "0": { "tooltip": null } } };
const LatentApplyOperationCFG = { "display_name": "GizliİşlemUygulaCFG", "inputs": { "model": { "name": "model" }, "operation": { "name": "işlem" } }, "outputs": { "0": { "tooltip": null } } };
const LatentBatch = { "display_name": "GizliTopluİş", "inputs": { "samples1": { "name": "örnekler1" }, "samples2": { "name": "örnekler2" } }, "outputs": { "0": { "tooltip": null } } };
const LatentBatchSeedBehavior = { "display_name": "GizliTopluTohumDavranışı", "inputs": { "samples": { "name": "örnekler" }, "seed_behavior": { "name": "tohum_davranışı" } }, "outputs": { "0": { "tooltip": null } } };
const LatentBlend = { "display_name": "Gizli Karıştırma", "inputs": { "blend_factor": { "name": "karıştırma_faktörü" }, "samples1": { "name": "örnekler1" }, "samples2": { "name": "örnekler2" } } };
const LatentComposite = { "display_name": "Gizli Birleştirme", "inputs": { "feather": { "name": "yumuşatma" }, "samples_from": { "name": "kaynak_örnekler" }, "samples_to": { "name": "hedef_örnekler" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const LatentCompositeMasked = { "display_name": "MaskeliGizliBirleştirme", "inputs": { "destination": { "name": "hedef" }, "mask": { "name": "maske" }, "resize_source": { "name": "kaynağı_yeniden_boyutlandır" }, "source": { "name": "kaynak" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const LatentConcat = { "display_name": "Gizli Birleştirme", "inputs": { "dim": { "name": "boyut" }, "samples1": { "name": "örnekler1" }, "samples2": { "name": "örnekler2" } }, "outputs": { "0": { "tooltip": null } } };
const LatentCrop = { "display_name": "Gizli Değişkeni Kırp", "inputs": { "height": { "name": "yükseklik" }, "samples": { "name": "örnekler" }, "width": { "name": "genişlik" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const LatentCut = { "display_name": "Gizli Kesme", "inputs": { "amount": { "name": "miktar" }, "dim": { "name": "boyut" }, "index": { "name": "dizin" }, "samples": { "name": "örnekler" } }, "outputs": { "0": { "tooltip": null } } };
const LatentFlip = { "display_name": "Gizli Değişkeni Çevir", "inputs": { "flip_method": { "name": "çevirme_yöntemi" }, "samples": { "name": "örnekler" } } };
const LatentFromBatch = { "display_name": "Toplu İşlemden Gizli Değişken", "inputs": { "batch_index": { "name": "toplu_indeks" }, "length": { "name": "uzunluk" }, "samples": { "name": "örnekler" } } };
const LatentInterpolate = { "display_name": "GizliAraDeğerleme", "inputs": { "ratio": { "name": "oran" }, "samples1": { "name": "örnekler1" }, "samples2": { "name": "örnekler2" } }, "outputs": { "0": { "tooltip": null } } };
const LatentMultiply = { "display_name": "GizliÇarpma", "inputs": { "multiplier": { "name": "çarpan" }, "samples": { "name": "örnekler" } }, "outputs": { "0": { "tooltip": null } } };
const LatentOperationSharpen = { "display_name": "GizliİşlemKeskinleştirme", "inputs": { "alpha": { "name": "alfa" }, "sharpen_radius": { "name": "keskinleştirme_yarıçapı" }, "sigma": { "name": "sigma" } }, "outputs": { "0": { "tooltip": null } } };
const LatentOperationTonemapReinhard = { "display_name": "GizliİşlemTonEşlemeReinhard", "inputs": { "multiplier": { "name": "çarpan" } }, "outputs": { "0": { "tooltip": null } } };
const LatentRotate = { "display_name": "Gizli Değişkeni Döndür", "inputs": { "rotation": { "name": "döndürme" }, "samples": { "name": "örnekler" } } };
const LatentSubtract = { "display_name": "GizliÇıkarma", "inputs": { "samples1": { "name": "örnekler1" }, "samples2": { "name": "örnekler2" } }, "outputs": { "0": { "tooltip": null } } };
const LatentUpscale = { "display_name": "Gizli Değişkeni Büyüt", "inputs": { "crop": { "name": "kırp" }, "height": { "name": "yükseklik" }, "samples": { "name": "örnekler" }, "upscale_method": { "name": "büyütme_yöntemi" }, "width": { "name": "genişlik" } } };
const LatentUpscaleBy = { "display_name": "Gizli Değişkeni Oranla Büyüt", "inputs": { "samples": { "name": "örnekler" }, "scale_by": { "name": "oranla_büyüt" }, "upscale_method": { "name": "büyütme_yöntemi" } } };
const LazyCache = { "description": "EasyCache'in ev yapımı bir versiyonu - uygulaması daha 'kolay' bir EasyCache versiyonu. Genel olarak EasyCache'den daha kötü çalışır, ancak bazı nadir durumlarda daha iyidir VE ComfyUI'deki her şeyle evrensel uyumluluğa sahiptir.", "display_name": "Tembel Önbellek", "inputs": { "end_percent": { "name": "bitiş_yüzdesi", "tooltip": "LazyCache kullanımının sona ereceği göreceli örnekleme adımı." }, "model": { "name": "model", "tooltip": "Tembel Önbellek eklemek için model." }, "reuse_threshold": { "name": "yeniden kullanım eşiği", "tooltip": "Önbelleğe alınmış adımları yeniden kullanma eşiği." }, "start_percent": { "name": "başlangıç_yüzdesi", "tooltip": "LazyCache kullanımının başlayacağı göreceli örnekleme adımı." }, "verbose": { "name": "ayrıntılı", "tooltip": "Ayrıntılı bilgilerin günlüğe kaydedilip kaydedilmeyeceği." } }, "outputs": { "0": { "tooltip": "LazyCache ile model." } } };
const Load3D = { "display_name": "3D Yükle", "inputs": { "clear": {}, "height": { "name": "yükseklik" }, "image": { "name": "görüntü" }, "model_file": { "name": "model_dosyası" }, "upload 3d model": {}, "width": { "name": "genişlik" } }, "outputs": { "0": { "name": "görüntü" }, "1": { "name": "maske" }, "2": { "name": "ağ_yolu" }, "3": { "name": "normal" }, "4": { "name": "çizgi_sanatı" }, "5": { "name": "kamera_bilgisi" } } };
const LoadAudio = { "display_name": "Ses Yükle", "inputs": { "audio": { "name": "ses" }, "audioUI": { "name": "sesArayüzü" }, "upload": { "name": "yüklenecek dosyayı seçin" } } };
const LoadImage = { "display_name": "Görüntü Yükle", "inputs": { "image": { "name": "görüntü" }, "upload": { "name": "yüklenecek dosyayı seçin" } } };
const LoadImageMask = { "display_name": "Görüntü Yükle (Maske olarak)", "inputs": { "channel": { "name": "kanal" }, "image": { "name": "görüntü" }, "upload": { "name": "yüklenecek dosyayı seçin" } } };
const LoadImageOutput = { "description": "Çıktı klasöründen bir görüntü yükleyin. Yenile düğmesine tıklandığında, düğüm görüntü listesini güncelleyecek ve otomatik olarak ilk görüntüyü seçecek, bu da kolay yinelemeye olanak tanıyacaktır.", "display_name": "Görüntü Yükle (Çıktılardan)", "inputs": { "image": { "name": "görüntü" }, "refresh": {}, "upload": { "name": "yüklenecek dosyayı seçin" } } };
const LoadLatent = { "display_name": "GizliYükle", "inputs": { "latent": { "name": "gizli" } } };
const LoadVideo = { "display_name": "Video Yükle", "inputs": { "file": { "name": "dosya" }, "upload": { "name": "yüklenecek dosyayı seçin" } }, "outputs": { "0": { "tooltip": null } } };
const LoraLoader = { "description": "LoRA'lar, difüzyon ve CLIP modellerini değiştirmek, gizli değişkenlerin gürültüsünün giderilme şeklini değiştirmek (örneğin stiller uygulamak) için kullanılır. Birden fazla LoRA düğümü birbirine bağlanabilir.", "display_name": "LoRA Yükle", "inputs": { "clip": { "name": "clip", "tooltip": "LoRA'nın uygulanacağı CLIP modeli." }, "lora_name": { "name": "lora_adı", "tooltip": "LoRA'nın adı." }, "model": { "name": "model", "tooltip": "LoRA'nın uygulanacağı difüzyon modeli." }, "strength_clip": { "name": "clip_gücü", "tooltip": "CLIP modelinin ne kadar güçlü değiştirileceği. Bu değer negatif olabilir." }, "strength_model": { "name": "model_gücü", "tooltip": "Difüzyon modelinin ne kadar güçlü değiştirileceği. Bu değer negatif olabilir." } }, "outputs": { "0": { "tooltip": "Değiştirilmiş difüzyon modeli." }, "1": { "tooltip": "Değiştirilmiş CLIP modeli." } } };
const LoraLoaderModelOnly = { "description": "LoRA'lar, difüzyon ve CLIP modellerini değiştirmek, gizli değişkenlerin gürültüsünün giderilme şeklini değiştirmek (örneğin stiller uygulamak) için kullanılır. Birden fazla LoRA düğümü birbirine bağlanabilir.", "display_name": "SadeceModelLoRA Yükleyici", "inputs": { "lora_name": { "name": "lora_adı" }, "model": { "name": "model" }, "strength_model": { "name": "model_gücü" } }, "outputs": { "0": { "tooltip": "Değiştirilmiş difüzyon modeli." } } };
const LoraModelLoader = { "display_name": "LoRA Modeli Yükle", "inputs": { "lora": { "name": "lora", "tooltip": "Difüzyon modeline uygulanacak LoRA modeli." }, "model": { "name": "model", "tooltip": "LoRA'nın uygulanacağı difüzyon modeli." }, "strength_model": { "name": "model_gücü", "tooltip": "Difüzyon modelinin ne kadar güçlü bir şekilde değiştirileceği. Bu değer negatif olabilir." } }, "outputs": { "0": { "tooltip": "Değiştirilmiş difüzyon modeli." } } };
const LoraSave = { "display_name": "Lora'yı Çıkar ve Kaydet", "inputs": { "bias_diff": { "name": "yanlılık_farkı" }, "filename_prefix": { "name": "dosyaadı_öneki" }, "lora_type": { "name": "lora_türü" }, "model_diff": { "name": "model_farkı", "tooltip": "Lora'ya dönüştürülecek ModelSubtract çıktısı." }, "rank": { "name": "rütbe" }, "text_encoder_diff": { "name": "metin_kodlayıcı_farkı", "tooltip": "Lora'ya dönüştürülecek CLIPSubtract çıktısı." } } };
const LossGraphNode = { "display_name": "Kayıp Grafiği Çiz", "inputs": { "filename_prefix": { "name": "dosya_adı_ön_eki" }, "loss": { "name": "kayıp" } } };
const LotusConditioning = { "display_name": "LotusKoşullandırma", "outputs": { "0": { "name": "koşullandırma", "tooltip": null } } };
const LtxvApiImageToVideo = { "description": "Başlangıç görüntüsüne dayalı özelleştirilebilir süre ve çözünürlükte profesyonel kalitede videolar.", "display_name": "LTXV Görüntüden Videoya", "inputs": { "duration": { "name": "süre" }, "fps": { "name": "fps" }, "generate_audio": { "name": "ses_oluştur", "tooltip": "Doğru olduğunda, oluşturulan video sahneye uygun yapay zeka tarafından oluşturulmuş ses içerecektir." }, "image": { "name": "görüntü", "tooltip": "Video için kullanılacak ilk kare." }, "model": { "name": "model" }, "prompt": { "name": "prompt" }, "resolution": { "name": "çözünürlük" } }, "outputs": { "0": { "tooltip": null } } };
const LtxvApiTextToVideo = { "description": "Özelleştirilebilir süre ve çözünürlükte profesyonel kalitede videolar.", "display_name": "LTXV Metinden Videoya", "inputs": { "duration": { "name": "süre" }, "fps": { "name": "fps" }, "generate_audio": { "name": "ses_oluştur", "tooltip": "Doğru olduğunda, oluşturulan video sahneye uygun yapay zeka tarafından oluşturulmuş ses içerecektir." }, "model": { "name": "model" }, "prompt": { "name": "prompt" }, "resolution": { "name": "çözünürlük" } }, "outputs": { "0": { "tooltip": null } } };
const LumaConceptsNode = { "description": "Luma Metinden Videoya ve Luma Görüntüden Videoya düğümleriyle kullanılmak üzere bir veya daha fazla Kamera Kavramı tutar.", "display_name": "Luma Kavramları", "inputs": { "concept1": { "name": "kavram1" }, "concept2": { "name": "kavram2" }, "concept3": { "name": "kavram3" }, "concept4": { "name": "kavram4" }, "luma_concepts": { "name": "luma_kavramları", "tooltip": "Burada seçilenlere eklemek için isteğe bağlı Kamera Kavramları." } }, "outputs": { "0": { "name": "luma_kavramları", "tooltip": null } } };
const LumaImageModifyNode = { "description": "İstem ve en boy oranına göre görüntüleri eşzamanlı olarak değiştirir.", "display_name": "Luma Görüntüden Görüntüye", "inputs": { "control_after_generate": { "name": "oluşturduktan sonra kontrol et" }, "image": { "name": "görüntü" }, "image_weight": { "name": "görüntü_ağırlığı", "tooltip": "Görüntünün ağırlığı; 1.0'a ne kadar yakınsa, görüntü o kadar az değiştirilir." }, "model": { "name": "model" }, "prompt": { "name": "istem", "tooltip": "Görüntü oluşturma istemi" }, "seed": { "name": "tohum", "tooltip": "Düğümün yeniden çalışıp çalışmayacağını belirlemek için tohum; gerçek sonuçlar tohumdan bağımsız olarak belirleyici değildir." } }, "outputs": { "0": { "tooltip": null } } };
const LumaImageNode = { "description": "İstem ve en boy oranına göre görüntüleri eşzamanlı olarak oluşturur.", "display_name": "Luma Metinden Görüntüye", "inputs": { "aspect_ratio": { "name": "en_boy_oranı" }, "character_image": { "name": "karakter_görüntüsü", "tooltip": "Karakter referans görüntüleri; birden fazla toplu olabilir, en fazla 4 görüntü dikkate alınabilir." }, "control_after_generate": { "name": "oluşturduktan sonra kontrol et" }, "image_luma_ref": { "name": "görüntü_luma_referansı", "tooltip": "Giriş görüntüleriyle üretimi etkilemek için Luma Referans düğümü bağlantısı; en fazla 4 görüntü dikkate alınabilir." }, "model": { "name": "model" }, "prompt": { "name": "istem", "tooltip": "Görüntü oluşturma istemi" }, "seed": { "name": "tohum", "tooltip": "Düğümün yeniden çalışıp çalışmayacağını belirlemek için tohum; gerçek sonuçlar tohumdan bağımsız olarak belirleyici değildir." }, "style_image": { "name": "stil_görüntüsü", "tooltip": "Stil referans görüntüsü; yalnızca 1 görüntü kullanılacaktır." }, "style_image_weight": { "name": "stil_görüntüsü_ağırlığı", "tooltip": "Stil görüntüsünün ağırlığı. Stil_görüntüsü sağlanmazsa yoksayılır." } }, "outputs": { "0": { "tooltip": null } } };
const LumaImageToVideoNode = { "description": "İstem, giriş görüntüleri ve çıktı_boyutuna göre videoları eşzamanlı olarak oluşturur.", "display_name": "Luma Görüntüden Videoya", "inputs": { "control_after_generate": { "name": "oluşturduktan sonra kontrol et" }, "duration": { "name": "süre" }, "first_image": { "name": "ilk_görüntü", "tooltip": "Oluşturulan videonun ilk karesi." }, "last_image": { "name": "son_görüntü", "tooltip": "Oluşturulan videonun son karesi." }, "loop": { "name": "döngü" }, "luma_concepts": { "name": "luma_kavramları", "tooltip": "Luma Kavramları düğümü aracılığıyla kamera hareketini dikte etmek için isteğe bağlı Kamera Kavramları." }, "model": { "name": "model" }, "prompt": { "name": "istem", "tooltip": "Video oluşturma istemi" }, "resolution": { "name": "çözünürlük" }, "seed": { "name": "tohum", "tooltip": "Düğümün yeniden çalışıp çalışmayacağını belirlemek için tohum; gerçek sonuçlar tohumdan bağımsız olarak belirleyici değildir." } }, "outputs": { "0": { "tooltip": null } } };
const LumaReferenceNode = { "description": "Luma Görüntü Oluştur düğümüyle kullanılmak üzere bir görüntü ve ağırlık tutar.", "display_name": "Luma Referansı", "inputs": { "image": { "name": "görüntü", "tooltip": "Referans olarak kullanılacak görüntü." }, "luma_ref": { "name": "luma_referansı" }, "weight": { "name": "ağırlık", "tooltip": "Görüntü referansının ağırlığı." } }, "outputs": { "0": { "name": "luma_referansı", "tooltip": null } } };
const LumaVideoNode = { "description": "İstem ve çıktı_boyutuna göre videoları eşzamanlı olarak oluşturur.", "display_name": "Luma Metinden Videoya", "inputs": { "aspect_ratio": { "name": "en_boy_oranı" }, "control_after_generate": { "name": "oluşturduktan sonra kontrol et" }, "duration": { "name": "süre" }, "loop": { "name": "döngü" }, "luma_concepts": { "name": "luma_kavramları", "tooltip": "Luma Kavramları düğümü aracılığıyla kamera hareketini dikte etmek için isteğe bağlı Kamera Kavramları." }, "model": { "name": "model" }, "prompt": { "name": "istem", "tooltip": "Video oluşturma istemi" }, "resolution": { "name": "çözünürlük" }, "seed": { "name": "tohum", "tooltip": "Düğümün yeniden çalışıp çalışmayacağını belirlemek için tohum; gerçek sonuçlar tohumdan bağımsız olarak belirleyici değildir." } }, "outputs": { "0": { "tooltip": null } } };
const Mahiro = { "description": "Rehberliği, negatif istem arasındaki farktan ziyade pozitif istemin 'yönüne' daha fazla ölçeklenecek şekilde değiştirin.", "display_name": "Mahiro o kadar sevimli ki daha iyi bir rehberlik fonksiyonunu hak ediyor!! (。・ω・。)", "inputs": { "model": { "name": "model" } }, "outputs": { "0": { "name": "yamalı_model", "tooltip": null } } };
const MaskComposite = { "display_name": "MaskeBirleştirme", "inputs": { "destination": { "name": "hedef" }, "operation": { "name": "işlem" }, "source": { "name": "kaynak" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const MaskPreview = { "description": "Giriş görüntülerini ComfyUI çıktı dizininize kaydeder.", "display_name": "MaskeÖnizleme", "inputs": { "mask": { "name": "maske" } } };
const MaskToImage = { "display_name": "Maskeyi Görüntüye Dönüştür", "inputs": { "mask": { "name": "maske" } } };
const MinimaxHailuoVideoNode = { "description": "Yeni MiniMax Hailuo-02 modelini kullanarak prompt'tan video oluşturur, isteğe bağlı başlangıç karesi ile.", "display_name": "MiniMax Hailuo Video", "inputs": { "control_after_generate": { "name": "oluşturma sonrası kontrol" }, "duration": { "name": "süre", "tooltip": "Çıktı videosunun saniye cinsinden uzunluğu." }, "first_frame_image": { "name": "ilk_kare_görüntüsü", "tooltip": "Video oluşturmak için isteğe bağlı olarak kullanılacak ilk kare görüntüsü." }, "prompt_optimizer": { "name": "prompt_optimize_edici", "tooltip": "Gerektiğinde oluşturma kalitesini artırmak için prompt'u optimize eder." }, "prompt_text": { "name": "prompt_metni", "tooltip": "Video oluşturmayı yönlendiren metin prompt'u." }, "resolution": { "name": "çözünürlük", "tooltip": "Video ekranının boyutları. 1080p 1920x1080, 768p ise 1366x768'dir." }, "seed": { "name": "tohum", "tooltip": "Gürültü oluşturmak için kullanılan rastgele tohum değeri." } }, "outputs": { "0": { "tooltip": null } } };
const MinimaxImageToVideoNode = { "description": "MiniMax'in API'sini kullanarak bir görüntüden ve istemlerden videolar oluşturur", "display_name": "MiniMax Görüntüden Videoya", "inputs": { "control_after_generate": { "name": "oluşturduktan sonra kontrol et" }, "image": { "name": "görüntü", "tooltip": "Video oluşturmanın ilk karesi olarak kullanılacak görüntü" }, "model": { "name": "model", "tooltip": "Video oluşturma için kullanılacak model" }, "prompt_text": { "name": "istem_metni", "tooltip": "Video oluşturmayı yönlendirecek metin istemi" }, "seed": { "name": "tohum", "tooltip": "Gürültüyü oluşturmak için kullanılan rastgele tohum." } }, "outputs": { "0": { "tooltip": null } } };
const MinimaxTextToVideoNode = { "description": "MiniMax'in API'sini kullanarak istemlerden videolar oluşturur", "display_name": "MiniMax Metinden Videoya", "inputs": { "control_after_generate": { "name": "oluşturduktan sonra kontrol et" }, "model": { "name": "model", "tooltip": "Video oluşturma için kullanılacak model" }, "prompt_text": { "name": "istem_metni", "tooltip": "Video oluşturmayı yönlendirecek metin istemi" }, "seed": { "name": "tohum", "tooltip": "Gürültüyü oluşturmak için kullanılan rastgele tohum." } }, "outputs": { "0": { "tooltip": null } } };
const ModelComputeDtype = { "display_name": "ModelHesaplamaVeriTürü", "inputs": { "dtype": { "name": "veri_türü" }, "model": { "name": "model" } } };
const ModelMergeAdd = { "display_name": "ModelBirleştirmeEkle", "inputs": { "model1": { "name": "model1" }, "model2": { "name": "model2" } } };
const ModelMergeAuraflow = { "display_name": "ModelBirleştirmeAuraflow", "inputs": { "cond_seq_linear_": { "name": "koşul_dizi_doğrusal." }, "double_layers_0_": { "name": "çift_katmanlar.0." }, "double_layers_1_": { "name": "çift_katmanlar.1." }, "double_layers_2_": { "name": "çift_katmanlar.2." }, "double_layers_3_": { "name": "çift_katmanlar.3." }, "final_linear_": { "name": "son_doğrusal." }, "init_x_linear_": { "name": "başlangıç_x_doğrusal." }, "modF_": { "name": "modF." }, "model1": { "name": "model1" }, "model2": { "name": "model2" }, "positional_encoding": { "name": "konumsal_kodlama" }, "register_tokens": { "name": "kayıt_jetonları" }, "single_layers_0_": { "name": "tek_katmanlar.0." }, "single_layers_10_": { "name": "tek_katmanlar.10." }, "single_layers_11_": { "name": "tek_katmanlar.11." }, "single_layers_12_": { "name": "tek_katmanlar.12." }, "single_layers_13_": { "name": "tek_katmanlar.13." }, "single_layers_14_": { "name": "tek_katmanlar.14." }, "single_layers_15_": { "name": "tek_katmanlar.15." }, "single_layers_16_": { "name": "tek_katmanlar.16." }, "single_layers_17_": { "name": "tek_katmanlar.17." }, "single_layers_18_": { "name": "tek_katmanlar.18." }, "single_layers_19_": { "name": "tek_katmanlar.19." }, "single_layers_1_": { "name": "tek_katmanlar.1." }, "single_layers_20_": { "name": "tek_katmanlar.20." }, "single_layers_21_": { "name": "tek_katmanlar.21." }, "single_layers_22_": { "name": "tek_katmanlar.22." }, "single_layers_23_": { "name": "tek_katmanlar.23." }, "single_layers_24_": { "name": "tek_katmanlar.24." }, "single_layers_25_": { "name": "tek_katmanlar.25." }, "single_layers_26_": { "name": "tek_katmanlar.26." }, "single_layers_27_": { "name": "tek_katmanlar.27." }, "single_layers_28_": { "name": "tek_katmanlar.28." }, "single_layers_29_": { "name": "tek_katmanlar.29." }, "single_layers_2_": { "name": "tek_katmanlar.2." }, "single_layers_30_": { "name": "tek_katmanlar.30." }, "single_layers_31_": { "name": "tek_katmanlar.31." }, "single_layers_3_": { "name": "tek_katmanlar.3." }, "single_layers_4_": { "name": "tek_katmanlar.4." }, "single_layers_5_": { "name": "tek_katmanlar.5." }, "single_layers_6_": { "name": "tek_katmanlar.6." }, "single_layers_7_": { "name": "tek_katmanlar.7." }, "single_layers_8_": { "name": "tek_katmanlar.8." }, "single_layers_9_": { "name": "tek_katmanlar.9." }, "t_embedder_": { "name": "t_gömücü." } } };
const ModelMergeBlocks = { "display_name": "ModelBloklarınıBirleştir", "inputs": { "input": { "name": "giriş" }, "middle": { "name": "orta" }, "model1": { "name": "model1" }, "model2": { "name": "model2" }, "out": { "name": "çıktı" } } };
const ModelMergeCosmos14B = { "display_name": "ModelBirleştirmeCosmos14B", "inputs": { "affline_norm_": { "name": "afin_norm." }, "blocks_block0_": { "name": "bloklar.blok0." }, "blocks_block10_": { "name": "bloklar.blok10." }, "blocks_block11_": { "name": "bloklar.blok11." }, "blocks_block12_": { "name": "bloklar.blok12." }, "blocks_block13_": { "name": "bloklar.blok13." }, "blocks_block14_": { "name": "bloklar.blok14." }, "blocks_block15_": { "name": "bloklar.blok15." }, "blocks_block16_": { "name": "bloklar.blok16." }, "blocks_block17_": { "name": "bloklar.blok17." }, "blocks_block18_": { "name": "bloklar.blok18." }, "blocks_block19_": { "name": "bloklar.blok19." }, "blocks_block1_": { "name": "bloklar.blok1." }, "blocks_block20_": { "name": "bloklar.blok20." }, "blocks_block21_": { "name": "bloklar.blok21." }, "blocks_block22_": { "name": "bloklar.blok22." }, "blocks_block23_": { "name": "bloklar.blok23." }, "blocks_block24_": { "name": "bloklar.blok24." }, "blocks_block25_": { "name": "bloklar.blok25." }, "blocks_block26_": { "name": "bloklar.blok26." }, "blocks_block27_": { "name": "bloklar.blok27." }, "blocks_block28_": { "name": "bloklar.blok28." }, "blocks_block29_": { "name": "bloklar.blok29." }, "blocks_block2_": { "name": "bloklar.blok2." }, "blocks_block30_": { "name": "bloklar.blok30." }, "blocks_block31_": { "name": "bloklar.blok31." }, "blocks_block32_": { "name": "bloklar.blok32." }, "blocks_block33_": { "name": "bloklar.blok33." }, "blocks_block34_": { "name": "bloklar.blok34." }, "blocks_block35_": { "name": "bloklar.blok35." }, "blocks_block3_": { "name": "bloklar.blok3." }, "blocks_block4_": { "name": "bloklar.blok4." }, "blocks_block5_": { "name": "bloklar.blok5." }, "blocks_block6_": { "name": "bloklar.blok6." }, "blocks_block7_": { "name": "bloklar.blok7." }, "blocks_block8_": { "name": "bloklar.blok8." }, "blocks_block9_": { "name": "bloklar.blok9." }, "extra_pos_embedder_": { "name": "ek_konum_gömücü." }, "final_layer_": { "name": "son_katman." }, "model1": { "name": "model1" }, "model2": { "name": "model2" }, "pos_embedder_": { "name": "konum_gömücü." }, "t_embedder_": { "name": "t_gömücü." }, "x_embedder_": { "name": "x_gömücü." } } };
const ModelMergeCosmos7B = { "display_name": "ModelBirleştirmeCosmos7B", "inputs": { "affline_norm_": { "name": "afin_norm." }, "blocks_block0_": { "name": "bloklar.blok0." }, "blocks_block10_": { "name": "bloklar.blok10." }, "blocks_block11_": { "name": "bloklar.blok11." }, "blocks_block12_": { "name": "bloklar.blok12." }, "blocks_block13_": { "name": "bloklar.blok13." }, "blocks_block14_": { "name": "bloklar.blok14." }, "blocks_block15_": { "name": "bloklar.blok15." }, "blocks_block16_": { "name": "bloklar.blok16." }, "blocks_block17_": { "name": "bloklar.blok17." }, "blocks_block18_": { "name": "bloklar.blok18." }, "blocks_block19_": { "name": "bloklar.blok19." }, "blocks_block1_": { "name": "bloklar.blok1." }, "blocks_block20_": { "name": "bloklar.blok20." }, "blocks_block21_": { "name": "bloklar.blok21." }, "blocks_block22_": { "name": "bloklar.blok22." }, "blocks_block23_": { "name": "bloklar.blok23." }, "blocks_block24_": { "name": "bloklar.blok24." }, "blocks_block25_": { "name": "bloklar.blok25." }, "blocks_block26_": { "name": "bloklar.blok26." }, "blocks_block27_": { "name": "bloklar.blok27." }, "blocks_block2_": { "name": "bloklar.blok2." }, "blocks_block3_": { "name": "bloklar.blok3." }, "blocks_block4_": { "name": "bloklar.blok4." }, "blocks_block5_": { "name": "bloklar.blok5." }, "blocks_block6_": { "name": "bloklar.blok6." }, "blocks_block7_": { "name": "bloklar.blok7." }, "blocks_block8_": { "name": "bloklar.blok8." }, "blocks_block9_": { "name": "bloklar.blok9." }, "extra_pos_embedder_": { "name": "ek_konum_gömücü." }, "final_layer_": { "name": "son_katman." }, "model1": { "name": "model1" }, "model2": { "name": "model2" }, "pos_embedder_": { "name": "konum_gömücü." }, "t_embedder_": { "name": "t_gömücü." }, "x_embedder_": { "name": "x_gömücü." } } };
const ModelMergeCosmosPredict2_14B = { "display_name": "ModelMergeCosmosPredict2_14B", "inputs": { "blocks_0_": { "name": "blocks.0." }, "blocks_10_": { "name": "blocks.10." }, "blocks_11_": { "name": "blocks.11." }, "blocks_12_": { "name": "blocks.12." }, "blocks_13_": { "name": "blocks.13." }, "blocks_14_": { "name": "blocks.14." }, "blocks_15_": { "name": "blocks.15." }, "blocks_16_": { "name": "blocks.16." }, "blocks_17_": { "name": "blocks.17." }, "blocks_18_": { "name": "blocks.18." }, "blocks_19_": { "name": "blocks.19." }, "blocks_1_": { "name": "blocks.1." }, "blocks_20_": { "name": "blocks.20." }, "blocks_21_": { "name": "blocks.21." }, "blocks_22_": { "name": "blocks.22." }, "blocks_23_": { "name": "blocks.23." }, "blocks_24_": { "name": "blocks.24." }, "blocks_25_": { "name": "bloklar.25." }, "blocks_26_": { "name": "bloklar.26." }, "blocks_27_": { "name": "bloklar.27." }, "blocks_28_": { "name": "bloklar.28." }, "blocks_29_": { "name": "bloklar.29." }, "blocks_2_": { "name": "blocks.2." }, "blocks_30_": { "name": "bloklar.30." }, "blocks_31_": { "name": "bloklar.31." }, "blocks_32_": { "name": "bloklar.32." }, "blocks_33_": { "name": "bloklar.33." }, "blocks_34_": { "name": "bloklar.34." }, "blocks_35_": { "name": "bloklar.35." }, "blocks_3_": { "name": "blocks.3." }, "blocks_4_": { "name": "blocks.4." }, "blocks_5_": { "name": "blocks.5." }, "blocks_6_": { "name": "blocks.6." }, "blocks_7_": { "name": "blocks.7." }, "blocks_8_": { "name": "blocks.8." }, "blocks_9_": { "name": "blocks.9." }, "final_layer_": { "name": "son_katman." }, "model1": { "name": "model1" }, "model2": { "name": "model2" }, "pos_embedder_": { "name": "pos_embedder." }, "t_embedder_": { "name": "t_embedder." }, "t_embedding_norm_": { "name": "t_embedding_norm." }, "x_embedder_": { "name": "x_embedder." } } };
const ModelMergeCosmosPredict2_2B = { "display_name": "ModelBirleştirmeCosmosTahmin2_2B", "inputs": { "blocks_0_": { "name": "bloklar.0." }, "blocks_10_": { "name": "bloklar.10." }, "blocks_11_": { "name": "bloklar.11." }, "blocks_12_": { "name": "bloklar.12." }, "blocks_13_": { "name": "bloklar.13." }, "blocks_14_": { "name": "bloklar.14." }, "blocks_15_": { "name": "bloklar.15." }, "blocks_16_": { "name": "bloklar.16." }, "blocks_17_": { "name": "bloklar.17." }, "blocks_18_": { "name": "bloklar.18." }, "blocks_19_": { "name": "bloklar.19." }, "blocks_1_": { "name": "bloklar.1." }, "blocks_20_": { "name": "bloklar.20." }, "blocks_21_": { "name": "bloklar.21." }, "blocks_22_": { "name": "bloklar.22." }, "blocks_23_": { "name": "bloklar.23." }, "blocks_24_": { "name": "bloklar.24." }, "blocks_25_": { "name": "bloklar.25." }, "blocks_26_": { "name": "bloklar.26." }, "blocks_27_": { "name": "bloklar.27." }, "blocks_2_": { "name": "bloklar.2." }, "blocks_3_": { "name": "bloklar.3." }, "blocks_4_": { "name": "bloklar.4." }, "blocks_5_": { "name": "bloklar.5." }, "blocks_6_": { "name": "bloklar.6." }, "blocks_7_": { "name": "bloklar.7." }, "blocks_8_": { "name": "bloklar.8." }, "blocks_9_": { "name": "bloklar.9." }, "final_layer_": { "name": "son_katman." }, "model1": { "name": "model1" }, "model2": { "name": "model2" }, "pos_embedder_": { "name": "poz_yerleştirici." }, "t_embedder_": { "name": "t_yerleştirici." }, "t_embedding_norm_": { "name": "t_yerleştirme_normu." }, "x_embedder_": { "name": "x_yerleştirici." } } };
const ModelMergeFlux1 = { "display_name": "ModelBirleştirmeFlux1", "inputs": { "double_blocks_0_": { "name": "çift_bloklar.0." }, "double_blocks_10_": { "name": "çift_bloklar.10." }, "double_blocks_11_": { "name": "çift_bloklar.11." }, "double_blocks_12_": { "name": "çift_bloklar.12." }, "double_blocks_13_": { "name": "çift_bloklar.13." }, "double_blocks_14_": { "name": "çift_bloklar.14." }, "double_blocks_15_": { "name": "çift_bloklar.15." }, "double_blocks_16_": { "name": "çift_bloklar.16." }, "double_blocks_17_": { "name": "çift_bloklar.17." }, "double_blocks_18_": { "name": "çift_bloklar.18." }, "double_blocks_1_": { "name": "çift_bloklar.1." }, "double_blocks_2_": { "name": "çift_bloklar.2." }, "double_blocks_3_": { "name": "çift_bloklar.3." }, "double_blocks_4_": { "name": "çift_bloklar.4." }, "double_blocks_5_": { "name": "çift_bloklar.5." }, "double_blocks_6_": { "name": "çift_bloklar.6." }, "double_blocks_7_": { "name": "çift_bloklar.7." }, "double_blocks_8_": { "name": "çift_bloklar.8." }, "double_blocks_9_": { "name": "çift_bloklar.9." }, "final_layer_": { "name": "son_katman." }, "guidance_in": { "name": "rehberlik_girişi" }, "img_in_": { "name": "görüntü_girişi." }, "model1": { "name": "model1" }, "model2": { "name": "model2" }, "single_blocks_0_": { "name": "tek_bloklar.0." }, "single_blocks_10_": { "name": "tek_bloklar.10." }, "single_blocks_11_": { "name": "tek_bloklar.11." }, "single_blocks_12_": { "name": "tek_bloklar.12." }, "single_blocks_13_": { "name": "tek_bloklar.13." }, "single_blocks_14_": { "name": "tek_bloklar.14." }, "single_blocks_15_": { "name": "tek_bloklar.15." }, "single_blocks_16_": { "name": "tek_bloklar.16." }, "single_blocks_17_": { "name": "tek_bloklar.17." }, "single_blocks_18_": { "name": "tek_bloklar.18." }, "single_blocks_19_": { "name": "tek_bloklar.19." }, "single_blocks_1_": { "name": "tek_bloklar.1." }, "single_blocks_20_": { "name": "tek_bloklar.20." }, "single_blocks_21_": { "name": "tek_bloklar.21." }, "single_blocks_22_": { "name": "tek_bloklar.22." }, "single_blocks_23_": { "name": "tek_bloklar.23." }, "single_blocks_24_": { "name": "tek_bloklar.24." }, "single_blocks_25_": { "name": "tek_bloklar.25." }, "single_blocks_26_": { "name": "tek_bloklar.26." }, "single_blocks_27_": { "name": "tek_bloklar.27." }, "single_blocks_28_": { "name": "tek_bloklar.28." }, "single_blocks_29_": { "name": "tek_bloklar.29." }, "single_blocks_2_": { "name": "tek_bloklar.2." }, "single_blocks_30_": { "name": "tek_bloklar.30." }, "single_blocks_31_": { "name": "tek_bloklar.31." }, "single_blocks_32_": { "name": "tek_bloklar.32." }, "single_blocks_33_": { "name": "tek_bloklar.33." }, "single_blocks_34_": { "name": "tek_bloklar.34." }, "single_blocks_35_": { "name": "tek_bloklar.35." }, "single_blocks_36_": { "name": "tek_bloklar.36." }, "single_blocks_37_": { "name": "tek_bloklar.37." }, "single_blocks_3_": { "name": "tek_bloklar.3." }, "single_blocks_4_": { "name": "tek_bloklar.4." }, "single_blocks_5_": { "name": "tek_bloklar.5." }, "single_blocks_6_": { "name": "tek_bloklar.6." }, "single_blocks_7_": { "name": "tek_bloklar.7." }, "single_blocks_8_": { "name": "tek_bloklar.8." }, "single_blocks_9_": { "name": "tek_bloklar.9." }, "time_in_": { "name": "zaman_girişi." }, "txt_in_": { "name": "metin_girişi." }, "vector_in_": { "name": "vektör_girişi." } } };
const ModelMergeLTXV = { "display_name": "ModelBirleştirmeLTXV", "inputs": { "adaln_single_": { "name": "adaln_tek." }, "caption_projection_": { "name": "başlık_projeksiyonu." }, "model1": { "name": "model1" }, "model2": { "name": "model2" }, "patchify_proj_": { "name": "yama_proj." }, "proj_out_": { "name": "proj_çıkışı." }, "scale_shift_table": { "name": "ölçek_kaydırma_tablosu" }, "transformer_blocks_0_": { "name": "dönüştürücü_blokları.0." }, "transformer_blocks_10_": { "name": "dönüştürücü_blokları.10." }, "transformer_blocks_11_": { "name": "dönüştürücü_blokları.11." }, "transformer_blocks_12_": { "name": "dönüştürücü_blokları.12." }, "transformer_blocks_13_": { "name": "dönüştürücü_blokları.13." }, "transformer_blocks_14_": { "name": "dönüştürücü_blokları.14." }, "transformer_blocks_15_": { "name": "dönüştürücü_blokları.15." }, "transformer_blocks_16_": { "name": "dönüştürücü_blokları.16." }, "transformer_blocks_17_": { "name": "dönüştürücü_blokları.17." }, "transformer_blocks_18_": { "name": "dönüştürücü_blokları.18." }, "transformer_blocks_19_": { "name": "dönüştürücü_blokları.19." }, "transformer_blocks_1_": { "name": "dönüştürücü_blokları.1." }, "transformer_blocks_20_": { "name": "dönüştürücü_blokları.20." }, "transformer_blocks_21_": { "name": "dönüştürücü_blokları.21." }, "transformer_blocks_22_": { "name": "dönüştürücü_blokları.22." }, "transformer_blocks_23_": { "name": "dönüştürücü_blokları.23." }, "transformer_blocks_24_": { "name": "dönüştürücü_blokları.24." }, "transformer_blocks_25_": { "name": "dönüştürücü_blokları.25." }, "transformer_blocks_26_": { "name": "dönüştürücü_blokları.26." }, "transformer_blocks_27_": { "name": "dönüştürücü_blokları.27." }, "transformer_blocks_2_": { "name": "dönüştürücü_blokları.2." }, "transformer_blocks_3_": { "name": "dönüştürücü_blokları.3." }, "transformer_blocks_4_": { "name": "dönüştürücü_blokları.4." }, "transformer_blocks_5_": { "name": "dönüştürücü_blokları.5." }, "transformer_blocks_6_": { "name": "dönüştürücü_blokları.6." }, "transformer_blocks_7_": { "name": "dönüştürücü_blokları.7." }, "transformer_blocks_8_": { "name": "dönüştürücü_blokları.8." }, "transformer_blocks_9_": { "name": "dönüştürücü_blokları.9." } } };
const ModelMergeMochiPreview = { "display_name": "ModelBirleştirmeMochiÖnizleme", "inputs": { "blocks_0_": { "name": "bloklar.0." }, "blocks_10_": { "name": "bloklar.10." }, "blocks_11_": { "name": "bloklar.11." }, "blocks_12_": { "name": "bloklar.12." }, "blocks_13_": { "name": "bloklar.13." }, "blocks_14_": { "name": "bloklar.14." }, "blocks_15_": { "name": "bloklar.15." }, "blocks_16_": { "name": "bloklar.16." }, "blocks_17_": { "name": "bloklar.17." }, "blocks_18_": { "name": "bloklar.18." }, "blocks_19_": { "name": "bloklar.19." }, "blocks_1_": { "name": "bloklar.1." }, "blocks_20_": { "name": "bloklar.20." }, "blocks_21_": { "name": "bloklar.21." }, "blocks_22_": { "name": "bloklar.22." }, "blocks_23_": { "name": "bloklar.23." }, "blocks_24_": { "name": "bloklar.24." }, "blocks_25_": { "name": "bloklar.25." }, "blocks_26_": { "name": "bloklar.26." }, "blocks_27_": { "name": "bloklar.27." }, "blocks_28_": { "name": "bloklar.28." }, "blocks_29_": { "name": "bloklar.29." }, "blocks_2_": { "name": "bloklar.2." }, "blocks_30_": { "name": "bloklar.30." }, "blocks_31_": { "name": "bloklar.31." }, "blocks_32_": { "name": "bloklar.32." }, "blocks_33_": { "name": "bloklar.33." }, "blocks_34_": { "name": "bloklar.34." }, "blocks_35_": { "name": "bloklar.35." }, "blocks_36_": { "name": "bloklar.36." }, "blocks_37_": { "name": "bloklar.37." }, "blocks_38_": { "name": "bloklar.38." }, "blocks_39_": { "name": "bloklar.39." }, "blocks_3_": { "name": "bloklar.3." }, "blocks_40_": { "name": "bloklar.40." }, "blocks_41_": { "name": "bloklar.41." }, "blocks_42_": { "name": "bloklar.42." }, "blocks_43_": { "name": "bloklar.43." }, "blocks_44_": { "name": "bloklar.44." }, "blocks_45_": { "name": "bloklar.45." }, "blocks_46_": { "name": "bloklar.46." }, "blocks_47_": { "name": "bloklar.47." }, "blocks_4_": { "name": "bloklar.4." }, "blocks_5_": { "name": "bloklar.5." }, "blocks_6_": { "name": "bloklar.6." }, "blocks_7_": { "name": "bloklar.7." }, "blocks_8_": { "name": "bloklar.8." }, "blocks_9_": { "name": "bloklar.9." }, "final_layer_": { "name": "son_katman." }, "model1": { "name": "model1" }, "model2": { "name": "model2" }, "pos_frequencies_": { "name": "konum_frekansları." }, "t5_y_embedder_": { "name": "t5_y_gömücü." }, "t5_yproj_": { "name": "t5_yproj." }, "t_embedder_": { "name": "t_gömücü." } } };
const ModelMergeQwenImage = { "display_name": "ModelBirleştirmeQwenGörsel", "inputs": { "img_in_": { "name": "görsel_giriş." }, "model1": { "name": "model1" }, "model2": { "name": "model2" }, "pos_embeds_": { "name": "poz_yerleştirmeler." }, "proj_out_": { "name": "proj_out." }, "time_text_embed_": { "name": "zaman_metin_yerleştirme." }, "transformer_blocks_0_": { "name": "dönüştürücü_blokları.0." }, "transformer_blocks_10_": { "name": "dönüştürücü_blokları.10." }, "transformer_blocks_11_": { "name": "dönüştürücü_blokları.11." }, "transformer_blocks_12_": { "name": "dönüştürücü_blokları.12." }, "transformer_blocks_13_": { "name": "dönüştürücü_blokları.13." }, "transformer_blocks_14_": { "name": "transformer_blokları.14." }, "transformer_blocks_15_": { "name": "transformer_blokları.15." }, "transformer_blocks_16_": { "name": "transformer_blokları.16." }, "transformer_blocks_17_": { "name": "transformer_blokları.17." }, "transformer_blocks_18_": { "name": "transformer_blokları.18." }, "transformer_blocks_19_": { "name": "transformer_blokları.19." }, "transformer_blocks_1_": { "name": "dönüştürücü_blokları.1." }, "transformer_blocks_20_": { "name": "transformer_blokları.20." }, "transformer_blocks_21_": { "name": "transformer_blokları.21." }, "transformer_blocks_22_": { "name": "transformer_blokları.22." }, "transformer_blocks_23_": { "name": "transformer_blokları.23." }, "transformer_blocks_24_": { "name": "transformer_blokları.24." }, "transformer_blocks_25_": { "name": "transformer_blokları.25." }, "transformer_blocks_26_": { "name": "transformer_blokları.26." }, "transformer_blocks_27_": { "name": "transformer_blokları.27." }, "transformer_blocks_28_": { "name": "transformer_blokları.28." }, "transformer_blocks_29_": { "name": "transformer_blokları.29." }, "transformer_blocks_2_": { "name": "dönüştürücü_blokları.2." }, "transformer_blocks_30_": { "name": "transformer_blokları.30." }, "transformer_blocks_31_": { "name": "transformer_blokları.31." }, "transformer_blocks_32_": { "name": "transformer_blokları.32." }, "transformer_blocks_33_": { "name": "transformer_blokları.33." }, "transformer_blocks_34_": { "name": "transformer_blokları.34." }, "transformer_blocks_35_": { "name": "transformer_blokları.35." }, "transformer_blocks_36_": { "name": "transformer_blokları.36." }, "transformer_blocks_37_": { "name": "transformer_blokları.37." }, "transformer_blocks_38_": { "name": "transformer_blokları.38." }, "transformer_blocks_39_": { "name": "transformer_blokları.39." }, "transformer_blocks_3_": { "name": "dönüştürücü_blokları.3." }, "transformer_blocks_40_": { "name": "transformer_blokları.40." }, "transformer_blocks_41_": { "name": "transformer_blokları.41." }, "transformer_blocks_42_": { "name": "transformer_blokları.42." }, "transformer_blocks_43_": { "name": "transformer_blokları.43." }, "transformer_blocks_44_": { "name": "transformer_blokları.44." }, "transformer_blocks_45_": { "name": "transformer_blokları.45." }, "transformer_blocks_46_": { "name": "transformer_blokları.46." }, "transformer_blocks_47_": { "name": "transformer_blokları.47." }, "transformer_blocks_48_": { "name": "transformer_blokları.48." }, "transformer_blocks_49_": { "name": "transformer_blocks.49." }, "transformer_blocks_4_": { "name": "dönüştürücü_blokları.4." }, "transformer_blocks_50_": { "name": "transformer_blocks.50." }, "transformer_blocks_51_": { "name": "transformer_blocks.51." }, "transformer_blocks_52_": { "name": "transformer_blocks.52." }, "transformer_blocks_53_": { "name": "transformer_blocks.53." }, "transformer_blocks_54_": { "name": "transformer_blocks.54." }, "transformer_blocks_55_": { "name": "transformer_blocks.55." }, "transformer_blocks_56_": { "name": "transformer_blocks.56." }, "transformer_blocks_57_": { "name": "transformer_blocks.57." }, "transformer_blocks_58_": { "name": "transformer_blocks.58." }, "transformer_blocks_59_": { "name": "transformer_blocks.59." }, "transformer_blocks_5_": { "name": "dönüştürücü_blokları.5." }, "transformer_blocks_6_": { "name": "dönüştürücü_blokları.6." }, "transformer_blocks_7_": { "name": "dönüştürücü_blokları.7." }, "transformer_blocks_8_": { "name": "dönüştürücü_blokları.8." }, "transformer_blocks_9_": { "name": "dönüştürücü_blokları.9." }, "txt_in_": { "name": "metin_giriş." }, "txt_norm_": { "name": "metin_norm." } } };
const ModelMergeSD1 = { "display_name": "ModelBirleştirmeSD1", "inputs": { "input_blocks_0_": { "name": "giriş_blokları.0." }, "input_blocks_10_": { "name": "giriş_blokları.10." }, "input_blocks_11_": { "name": "giriş_blokları.11." }, "input_blocks_1_": { "name": "giriş_blokları.1." }, "input_blocks_2_": { "name": "giriş_blokları.2." }, "input_blocks_3_": { "name": "giriş_blokları.3." }, "input_blocks_4_": { "name": "giriş_blokları.4." }, "input_blocks_5_": { "name": "giriş_blokları.5." }, "input_blocks_6_": { "name": "giriş_blokları.6." }, "input_blocks_7_": { "name": "giriş_blokları.7." }, "input_blocks_8_": { "name": "giriş_blokları.8." }, "input_blocks_9_": { "name": "giriş_blokları.9." }, "label_emb_": { "name": "etiket_gömme." }, "middle_block_0_": { "name": "orta_blok.0." }, "middle_block_1_": { "name": "orta_blok.1." }, "middle_block_2_": { "name": "orta_blok.2." }, "model1": { "name": "model1" }, "model2": { "name": "model2" }, "out_": { "name": "çıktı." }, "output_blocks_0_": { "name": "çıktı_blokları.0." }, "output_blocks_10_": { "name": "çıktı_blokları.10." }, "output_blocks_11_": { "name": "çıktı_blokları.11." }, "output_blocks_1_": { "name": "çıktı_blokları.1." }, "output_blocks_2_": { "name": "çıktı_blokları.2." }, "output_blocks_3_": { "name": "çıktı_blokları.3." }, "output_blocks_4_": { "name": "çıktı_blokları.4." }, "output_blocks_5_": { "name": "çıktı_blokları.5." }, "output_blocks_6_": { "name": "çıktı_blokları.6." }, "output_blocks_7_": { "name": "çıktı_blokları.7." }, "output_blocks_8_": { "name": "çıktı_blokları.8." }, "output_blocks_9_": { "name": "çıktı_blokları.9." }, "time_embed_": { "name": "zaman_gömme." } } };
const ModelMergeSD2 = { "display_name": "ModelBirleştirmeSD2", "inputs": { "input_blocks_0_": { "name": "giriş_blokları.0." }, "input_blocks_10_": { "name": "giriş_blokları.10." }, "input_blocks_11_": { "name": "giriş_blokları.11." }, "input_blocks_1_": { "name": "giriş_blokları.1." }, "input_blocks_2_": { "name": "giriş_blokları.2." }, "input_blocks_3_": { "name": "giriş_blokları.3." }, "input_blocks_4_": { "name": "giriş_blokları.4." }, "input_blocks_5_": { "name": "giriş_blokları.5." }, "input_blocks_6_": { "name": "giriş_blokları.6." }, "input_blocks_7_": { "name": "giriş_blokları.7." }, "input_blocks_8_": { "name": "giriş_blokları.8." }, "input_blocks_9_": { "name": "giriş_blokları.9." }, "label_emb_": { "name": "etiket_gömme." }, "middle_block_0_": { "name": "orta_blok.0." }, "middle_block_1_": { "name": "orta_blok.1." }, "middle_block_2_": { "name": "orta_blok.2." }, "model1": { "name": "model1" }, "model2": { "name": "model2" }, "out_": { "name": "çıktı." }, "output_blocks_0_": { "name": "çıktı_blokları.0." }, "output_blocks_10_": { "name": "çıktı_blokları.10." }, "output_blocks_11_": { "name": "çıktı_blokları.11." }, "output_blocks_1_": { "name": "çıktı_blokları.1." }, "output_blocks_2_": { "name": "çıktı_blokları.2." }, "output_blocks_3_": { "name": "çıktı_blokları.3." }, "output_blocks_4_": { "name": "çıktı_blokları.4." }, "output_blocks_5_": { "name": "çıktı_blokları.5." }, "output_blocks_6_": { "name": "çıktı_blokları.6." }, "output_blocks_7_": { "name": "çıktı_blokları.7." }, "output_blocks_8_": { "name": "çıktı_blokları.8." }, "output_blocks_9_": { "name": "çıktı_blokları.9." }, "time_embed_": { "name": "zaman_gömme." } } };
const ModelMergeSD35_Large = { "display_name": "ModelBirleştirmeSD35_Büyük", "inputs": { "context_embedder_": { "name": "bağlam_gömücü." }, "final_layer_": { "name": "son_katman." }, "joint_blocks_0_": { "name": "birleşik_bloklar.0." }, "joint_blocks_10_": { "name": "birleşik_bloklar.10." }, "joint_blocks_11_": { "name": "birleşik_bloklar.11." }, "joint_blocks_12_": { "name": "birleşik_bloklar.12." }, "joint_blocks_13_": { "name": "birleşik_bloklar.13." }, "joint_blocks_14_": { "name": "birleşik_bloklar.14." }, "joint_blocks_15_": { "name": "birleşik_bloklar.15." }, "joint_blocks_16_": { "name": "birleşik_bloklar.16." }, "joint_blocks_17_": { "name": "birleşik_bloklar.17." }, "joint_blocks_18_": { "name": "birleşik_bloklar.18." }, "joint_blocks_19_": { "name": "birleşik_bloklar.19." }, "joint_blocks_1_": { "name": "birleşik_bloklar.1." }, "joint_blocks_20_": { "name": "birleşik_bloklar.20." }, "joint_blocks_21_": { "name": "birleşik_bloklar.21." }, "joint_blocks_22_": { "name": "birleşik_bloklar.22." }, "joint_blocks_23_": { "name": "birleşik_bloklar.23." }, "joint_blocks_24_": { "name": "birleşik_bloklar.24." }, "joint_blocks_25_": { "name": "birleşik_bloklar.25." }, "joint_blocks_26_": { "name": "birleşik_bloklar.26." }, "joint_blocks_27_": { "name": "birleşik_bloklar.27." }, "joint_blocks_28_": { "name": "birleşik_bloklar.28." }, "joint_blocks_29_": { "name": "birleşik_bloklar.29." }, "joint_blocks_2_": { "name": "birleşik_bloklar.2." }, "joint_blocks_30_": { "name": "birleşik_bloklar.30." }, "joint_blocks_31_": { "name": "birleşik_bloklar.31." }, "joint_blocks_32_": { "name": "birleşik_bloklar.32." }, "joint_blocks_33_": { "name": "birleşik_bloklar.33." }, "joint_blocks_34_": { "name": "birleşik_bloklar.34." }, "joint_blocks_35_": { "name": "birleşik_bloklar.35." }, "joint_blocks_36_": { "name": "birleşik_bloklar.36." }, "joint_blocks_37_": { "name": "birleşik_bloklar.37." }, "joint_blocks_3_": { "name": "birleşik_bloklar.3." }, "joint_blocks_4_": { "name": "birleşik_bloklar.4." }, "joint_blocks_5_": { "name": "birleşik_bloklar.5." }, "joint_blocks_6_": { "name": "birleşik_bloklar.6." }, "joint_blocks_7_": { "name": "birleşik_bloklar.7." }, "joint_blocks_8_": { "name": "birleşik_bloklar.8." }, "joint_blocks_9_": { "name": "birleşik_bloklar.9." }, "model1": { "name": "model1" }, "model2": { "name": "model2" }, "pos_embed_": { "name": "konum_gömme." }, "t_embedder_": { "name": "t_gömücü." }, "x_embedder_": { "name": "x_gömücü." }, "y_embedder_": { "name": "y_gömücü." } } };
const ModelMergeSD3_2B = { "display_name": "ModelBirleştirmeSD3_2B", "inputs": { "context_embedder_": { "name": "bağlam_gömücü." }, "final_layer_": { "name": "son_katman." }, "joint_blocks_0_": { "name": "birleşik_bloklar.0." }, "joint_blocks_10_": { "name": "birleşik_bloklar.10." }, "joint_blocks_11_": { "name": "birleşik_bloklar.11." }, "joint_blocks_12_": { "name": "birleşik_bloklar.12." }, "joint_blocks_13_": { "name": "birleşik_bloklar.13." }, "joint_blocks_14_": { "name": "birleşik_bloklar.14." }, "joint_blocks_15_": { "name": "birleşik_bloklar.15." }, "joint_blocks_16_": { "name": "birleşik_bloklar.16." }, "joint_blocks_17_": { "name": "birleşik_bloklar.17." }, "joint_blocks_18_": { "name": "birleşik_bloklar.18." }, "joint_blocks_19_": { "name": "birleşik_bloklar.19." }, "joint_blocks_1_": { "name": "birleşik_bloklar.1." }, "joint_blocks_20_": { "name": "birleşik_bloklar.20." }, "joint_blocks_21_": { "name": "birleşik_bloklar.21." }, "joint_blocks_22_": { "name": "birleşik_bloklar.22." }, "joint_blocks_23_": { "name": "birleşik_bloklar.23." }, "joint_blocks_2_": { "name": "birleşik_bloklar.2." }, "joint_blocks_3_": { "name": "birleşik_bloklar.3." }, "joint_blocks_4_": { "name": "birleşik_bloklar.4." }, "joint_blocks_5_": { "name": "birleşik_bloklar.5." }, "joint_blocks_6_": { "name": "birleşik_bloklar.6." }, "joint_blocks_7_": { "name": "birleşik_bloklar.7." }, "joint_blocks_8_": { "name": "birleşik_bloklar.8." }, "joint_blocks_9_": { "name": "birleşik_bloklar.9." }, "model1": { "name": "model1" }, "model2": { "name": "model2" }, "pos_embed_": { "name": "konum_gömme." }, "t_embedder_": { "name": "t_gömücü." }, "x_embedder_": { "name": "x_gömücü." }, "y_embedder_": { "name": "y_gömücü." } } };
const ModelMergeSDXL = { "display_name": "ModelBirleştirmeSDXL", "inputs": { "input_blocks_0": { "name": "giriş_blokları.0" }, "input_blocks_1": { "name": "giriş_blokları.1" }, "input_blocks_2": { "name": "giriş_blokları.2" }, "input_blocks_3": { "name": "giriş_blokları.3" }, "input_blocks_4": { "name": "giriş_blokları.4" }, "input_blocks_5": { "name": "giriş_blokları.5" }, "input_blocks_6": { "name": "giriş_blokları.6" }, "input_blocks_7": { "name": "giriş_blokları.7" }, "input_blocks_8": { "name": "giriş_blokları.8" }, "label_emb_": { "name": "etiket_gömme." }, "middle_block_0": { "name": "orta_blok.0" }, "middle_block_1": { "name": "orta_blok.1" }, "middle_block_2": { "name": "orta_blok.2" }, "model1": { "name": "model1" }, "model2": { "name": "model2" }, "out_": { "name": "çıktı." }, "output_blocks_0": { "name": "çıktı_blokları.0" }, "output_blocks_1": { "name": "çıktı_blokları.1" }, "output_blocks_2": { "name": "çıktı_blokları.2" }, "output_blocks_3": { "name": "çıktı_blokları.3" }, "output_blocks_4": { "name": "çıktı_blokları.4" }, "output_blocks_5": { "name": "çıktı_blokları.5" }, "output_blocks_6": { "name": "çıktı_blokları.6" }, "output_blocks_7": { "name": "çıktı_blokları.7" }, "output_blocks_8": { "name": "çıktı_blokları.8" }, "time_embed_": { "name": "zaman_gömme." } } };
const ModelMergeSimple = { "display_name": "BasitModelBirleştirme", "inputs": { "model1": { "name": "model1" }, "model2": { "name": "model2" }, "ratio": { "name": "oran" } } };
const ModelMergeSubtract = { "display_name": "ModelBirleştirmeÇıkarma", "inputs": { "model1": { "name": "model1" }, "model2": { "name": "model2" }, "multiplier": { "name": "çarpan" } } };
const ModelMergeWAN2_1 = { "description": "1.3B modelinde 30 blok, 14B modelinde 40 blok bulunur. Görüntüden videoya modelinde ek olarak img_emb bulunur.", "display_name": "ModelBirleştirmeWAN2_1", "inputs": { "blocks_0_": { "name": "bloklar.0." }, "blocks_10_": { "name": "bloklar.10." }, "blocks_11_": { "name": "bloklar.11." }, "blocks_12_": { "name": "bloklar.12." }, "blocks_13_": { "name": "bloklar.13." }, "blocks_14_": { "name": "bloklar.14." }, "blocks_15_": { "name": "bloklar.15." }, "blocks_16_": { "name": "bloklar.16." }, "blocks_17_": { "name": "bloklar.17." }, "blocks_18_": { "name": "bloklar.18." }, "blocks_19_": { "name": "bloklar.19." }, "blocks_1_": { "name": "bloklar.1." }, "blocks_20_": { "name": "bloklar.20." }, "blocks_21_": { "name": "bloklar.21." }, "blocks_22_": { "name": "bloklar.22." }, "blocks_23_": { "name": "bloklar.23." }, "blocks_24_": { "name": "bloklar.24." }, "blocks_25_": { "name": "bloklar.25." }, "blocks_26_": { "name": "bloklar.26." }, "blocks_27_": { "name": "bloklar.27." }, "blocks_28_": { "name": "bloklar.28." }, "blocks_29_": { "name": "bloklar.29." }, "blocks_2_": { "name": "bloklar.2." }, "blocks_30_": { "name": "bloklar.30." }, "blocks_31_": { "name": "bloklar.31." }, "blocks_32_": { "name": "bloklar.32." }, "blocks_33_": { "name": "bloklar.33." }, "blocks_34_": { "name": "bloklar.34." }, "blocks_35_": { "name": "bloklar.35." }, "blocks_36_": { "name": "bloklar.36." }, "blocks_37_": { "name": "bloklar.37." }, "blocks_38_": { "name": "bloklar.38." }, "blocks_39_": { "name": "bloklar.39." }, "blocks_3_": { "name": "bloklar.3." }, "blocks_4_": { "name": "bloklar.4." }, "blocks_5_": { "name": "bloklar.5." }, "blocks_6_": { "name": "bloklar.6." }, "blocks_7_": { "name": "bloklar.7." }, "blocks_8_": { "name": "bloklar.8." }, "blocks_9_": { "name": "bloklar.9." }, "head_": { "name": "baş." }, "img_emb_": { "name": "görüntü_gömme." }, "model1": { "name": "model1" }, "model2": { "name": "model2" }, "patch_embedding_": { "name": "yama_gömme." }, "text_embedding_": { "name": "metin_gömme." }, "time_embedding_": { "name": "zaman_gömme." }, "time_projection_": { "name": "zaman_projeksiyonu." } } };
const ModelPatchLoader = { "display_name": "ModelPatchLoader", "inputs": { "name": { "name": "ad" } } };
const ModelSamplingAuraFlow = { "display_name": "ModelÖrneklemeAuraFlow", "inputs": { "model": { "name": "model" }, "shift": { "name": "kaydırma" } } };
const ModelSamplingContinuousEDM = { "display_name": "ModelÖrneklemeSürekliEDM", "inputs": { "model": { "name": "model" }, "sampling": { "name": "örnekleme" }, "sigma_max": { "name": "sigma_maks" }, "sigma_min": { "name": "sigma_min" } } };
const ModelSamplingContinuousV = { "display_name": "ModelÖrneklemeSürekliV", "inputs": { "model": { "name": "model" }, "sampling": { "name": "örnekleme" }, "sigma_max": { "name": "sigma_maks" }, "sigma_min": { "name": "sigma_min" } } };
const ModelSamplingDiscrete = { "display_name": "ModelÖrneklemeAyrık", "inputs": { "model": { "name": "model" }, "sampling": { "name": "örnekleme" }, "zsnr": { "name": "zsnr" } } };
const ModelSamplingFlux = { "display_name": "ModelÖrneklemeFlux", "inputs": { "base_shift": { "name": "temel_kaydırma" }, "height": { "name": "yükseklik" }, "max_shift": { "name": "maks_kaydırma" }, "model": { "name": "model" }, "width": { "name": "genişlik" } } };
const ModelSamplingLTXV = { "display_name": "ModelÖrneklemeLTXV", "inputs": { "base_shift": { "name": "temel_kaydırma" }, "latent": { "name": "gizli" }, "max_shift": { "name": "maks_kaydırma" }, "model": { "name": "model" } }, "outputs": { "0": { "tooltip": null } } };
const ModelSamplingSD3 = { "display_name": "ModelÖrneklemeSD3", "inputs": { "model": { "name": "model" }, "shift": { "name": "kaydırma" } } };
const ModelSamplingStableCascade = { "display_name": "ModelÖrneklemeStabilKaskad", "inputs": { "model": { "name": "model" }, "shift": { "name": "kaydırma" } } };
const ModelSave = { "display_name": "ModelKaydet", "inputs": { "filename_prefix": { "name": "dosyaadı_öneki" }, "model": { "name": "model" } } };
const MoonvalleyImg2VideoNode = { "description": "Moonvalley Marey Görüntüden Videoya Düğümü", "display_name": "Moonvalley Marey Görüntüden Videoya", "inputs": { "control_after_generate": { "name": "control after generate" }, "image": { "name": "görüntü", "tooltip": "Videoyu oluşturmak için kullanılan referans görüntü" }, "negative_prompt": { "name": "negative_prompt", "tooltip": "Negatif prompt metni" }, "prompt": { "name": "prompt" }, "prompt_adherence": { "name": "prompt_adherence", "tooltip": "Üretim kontrolü için rehberlik ölçeği" }, "resolution": { "name": "çözünürlük", "tooltip": "Çıktı videosunun çözünürlüğü" }, "seed": { "name": "seed", "tooltip": "Rastgele seed değeri" }, "steps": { "name": "steps", "tooltip": "Gürültü giderme adımlarının sayısı" } }, "outputs": { "0": { "tooltip": null } } };
const MoonvalleyTxt2VideoNode = { "display_name": "Moonvalley Marey Metinden Videoya", "inputs": { "control_after_generate": { "name": "üretim sonrası kontrol" }, "negative_prompt": { "name": "negative_prompt", "tooltip": "Negatif prompt metni" }, "prompt": { "name": "prompt" }, "prompt_adherence": { "name": "komut uyumu", "tooltip": "Üretim kontrolü için rehberlik ölçeği" }, "resolution": { "name": "çözünürlük", "tooltip": "Çıktı videosunun çözünürlüğü" }, "seed": { "name": "tohum", "tooltip": "Rastgele tohum değeri" }, "steps": { "name": "adımlar", "tooltip": "Çıkarım adımları" } }, "outputs": { "0": { "tooltip": null } } };
const MoonvalleyVideo2VideoNode = { "display_name": "Moonvalley Marey Video'dan Video'ya", "inputs": { "control_type": { "name": "kontrol_tipi" }, "motion_intensity": { "name": "hareket_yoğunluğu", "tooltip": "Sadece kontrol_tipi 'Hareket Transferi' ise kullanılır" }, "negative_prompt": { "name": "negatif_komut", "tooltip": "Negatif komut metni" }, "prompt": { "name": "komut", "tooltip": "Oluşturulacak videoyu tanımlar" }, "seed": { "name": "tohum", "tooltip": "Rastgele tohum değeri" }, "steps": { "name": "adımlar", "tooltip": "Çıkarım adım sayısı" }, "video": { "name": "video", "tooltip": "Çıktı videosunu oluşturmak için kullanılan referans video. En az 5 saniye uzunluğunda olmalıdır. 5 saniyeden uzun videolar otomatik olarak kırpılacaktır. Sadece MP4 formatı desteklenir." } }, "outputs": { "0": { "tooltip": null } } };
const Morphology = { "display_name": "GörüntüMorfolojisi", "inputs": { "image": { "name": "görüntü" }, "kernel_size": { "name": "çekirdek_boyutu" }, "operation": { "name": "işlem" } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIChatConfig = { "description": "OpenAI Sohbet Düğümleri için gelişmiş yapılandırma seçeneklerini belirlemeye olanak tanır.", "display_name": "OpenAI ChatGPT Gelişmiş Seçenekler", "inputs": { "instructions": { "name": "talimatlar", "tooltip": "Modelin yanıtı nasıl oluşturacağına dair talimatlar" }, "max_output_tokens": { "name": "maksimum_çıktı_tokenları", "tooltip": "Görünür çıktı tokenları dahil olmak üzere bir yanıt için üretilebilecek token sayısı için üst sınır" }, "truncation": { "name": "kırpma", "tooltip": "Model yanıtı için kullanılacak kırpma stratejisi. auto: Bu yanıtın ve öncekilerin bağlamı modelin bağlam penceresi boyutunu aşarsa, model konuşmanın ortasındaki girdi öğelerini atarak yanıtı bağlam penceresine sığdırmak için kırpacaktır. devre_dışı: Bir model yanıtı model için bağlam penceresi boyutunu aşarsa, istek 400 hatasıyla başarısız olacaktır" } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIChatNode = { "description": "Bir OpenAI modelinden metin yanıtları oluşturun.", "display_name": "OpenAI ChatGPT", "inputs": { "advanced_options": { "name": "gelişmiş_seçenekler", "tooltip": "Model için isteğe bağlı yapılandırma. OpenAI Sohbet Gelişmiş Seçenekler düğümünden gelen girdileri kabul eder." }, "files": { "name": "dosyalar", "tooltip": "Model için bağlam olarak kullanılacak isteğe bağlı dosya(lar). OpenAI Sohbet Girdi Dosyaları düğümünden gelen girdileri kabul eder." }, "images": { "name": "görseller", "tooltip": "Model için bağlam olarak kullanılacak isteğe bağlı görsel(ler). Birden fazla görsel eklemek için Toplu Görseller düğümünü kullanabilirsiniz." }, "model": { "name": "model", "tooltip": "Yanıtı oluşturmak için kullanılan model" }, "persist_context": { "name": "bağlamı_sürdür", "tooltip": "Bu parametre kullanımdan kaldırılmıştır ve hiçbir etkisi yoktur." }, "prompt": { "name": "komut", "tooltip": "Modelin yanıt oluşturmak için kullandığı metin girdileri." } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIDalle2 = { "description": "OpenAI'nin DALL·E 2 uç noktası aracılığıyla eşzamanlı olarak görüntüler oluşturur.", "display_name": "OpenAI DALL·E 2", "inputs": { "control_after_generate": { "name": "oluşturduktan sonra kontrol et" }, "image": { "name": "görüntü", "tooltip": "Görüntü düzenleme için isteğe bağlı referans görüntü." }, "mask": { "name": "maske", "tooltip": "İç boyama için isteğe bağlı maske (beyaz alanlar değiştirilecektir)" }, "n": { "name": "n", "tooltip": "Kaç tane görüntü oluşturulacağı" }, "prompt": { "name": "istem", "tooltip": "DALL·E için metin istemi" }, "seed": { "name": "tohum", "tooltip": "arka uçta henüz uygulanmadı" }, "size": { "name": "boyut", "tooltip": "Görüntü boyutu" } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIDalle3 = { "description": "OpenAI'nin DALL·E 3 uç noktası aracılığıyla eşzamanlı olarak görüntüler oluşturur.", "display_name": "OpenAI DALL·E 3", "inputs": { "control_after_generate": { "name": "oluşturduktan sonra kontrol et" }, "prompt": { "name": "istem", "tooltip": "DALL·E için metin istemi" }, "quality": { "name": "kalite", "tooltip": "Görüntü kalitesi" }, "seed": { "name": "tohum", "tooltip": "arka uçta henüz uygulanmadı" }, "size": { "name": "boyut", "tooltip": "Görüntü boyutu" }, "style": { "name": "stil", "tooltip": "Canlı, modelin hiper-gerçekçi ve dramatik görüntüler oluşturmaya yönelmesine neden olur. Doğal, modelin daha doğal, daha az hiper-gerçekçi görünen görüntüler üretmesine neden olur." } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIGPTImage1 = { "description": "OpenAI'nin GPT Görüntü 1 uç noktası aracılığıyla eşzamanlı olarak görüntüler oluşturur.", "display_name": "OpenAI GPT Görüntü 1", "inputs": { "background": { "name": "arka_plan", "tooltip": "Görüntüyü arka planlı veya arka plansız döndür" }, "control_after_generate": { "name": "oluşturduktan sonra kontrol et" }, "image": { "name": "görüntü", "tooltip": "Görüntü düzenleme için isteğe bağlı referans görüntü." }, "mask": { "name": "maske", "tooltip": "İç boyama için isteğe bağlı maske (beyaz alanlar değiştirilecektir)" }, "n": { "name": "n", "tooltip": "Kaç tane görüntü oluşturulacağı" }, "prompt": { "name": "istem", "tooltip": "GPT Görüntü 1 için metin istemi" }, "quality": { "name": "kalite", "tooltip": "Görüntü kalitesi, maliyeti ve üretim süresini etkiler." }, "seed": { "name": "tohum", "tooltip": "arka uçta henüz uygulanmadı" }, "size": { "name": "boyut", "tooltip": "Görüntü boyutu" } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIInputFiles = { "description": "OpenAI Sohbet Düğümü için girdi olarak eklemek üzere girdi dosyalarını (metin, pdf vb.) yükler ve hazırlar. Dosyalar, yanıt oluşturulurken OpenAI modeli tarafından okunacaktır. 🛈 İPUCU: Diğer OpenAI Girdi Dosyası düğümleriyle zincirlenebilir.", "display_name": "OpenAI ChatGPT Girdi Dosyaları", "inputs": { "OPENAI_INPUT_FILES": { "name": "OPENAI_GİRDİ_DOSYALARI", "tooltip": "Bu düğümden yüklenen dosyayla toplu olarak birleştirilecek isteğe bağlı ek dosya(lar). Tek bir mesajın birden fazla girdi dosyası içerebilmesi için girdi dosyalarının zincirlenmesine olanak tanır." }, "file": { "name": "dosya", "tooltip": "Model için bağlam olarak eklenecek girdi dosyaları. Şu an için yalnızca metin (.txt) ve PDF (.pdf) dosyalarını kabul eder." } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIVideoSora2 = { "description": "OpenAI video ve ses oluşturma.", "display_name": "OpenAI Sora - Video", "inputs": { "control_after_generate": { "name": "oluşturduktan sonra kontrol et" }, "duration": { "name": "süre" }, "image": { "name": "görsel" }, "model": { "name": "model" }, "prompt": { "name": "komut istemi", "tooltip": "Yönlendirici metin; bir girdi görseli mevcutsa boş olabilir." }, "seed": { "name": "tohum", "tooltip": "Düğümün yeniden çalıştırılıp çalıştırılmayacağını belirlemek için tohum; gerçek sonuçlar tohuma bakılmaksızın belirsizdir." }, "size": { "name": "boyut" } }, "outputs": { "0": { "tooltip": null } } };
const OptimalStepsScheduler = { "display_name": "OptimalAdımlarZamanlayıcı", "inputs": { "denoise": { "name": "gürültü_azaltma" }, "model_type": { "name": "model_türü" }, "steps": { "name": "adımlar" } }, "outputs": { "0": { "tooltip": null } } };
const PairConditioningCombine = { "display_name": "Koşul Çifti Birleştir", "inputs": { "negative_A": { "name": "negatif_A" }, "negative_B": { "name": "negatif_B" }, "positive_A": { "name": "pozitif_A" }, "positive_B": { "name": "pozitif_B" } }, "outputs": { "0": { "name": "pozitif" }, "1": { "name": "negatif" } } };
const PairConditioningSetDefaultCombine = { "display_name": "Koşul Çifti Varsayılan Birleştirmeyi Ayarla", "inputs": { "hooks": { "name": "kancalar" }, "negative": { "name": "negatif" }, "negative_DEFAULT": { "name": "negatif_VARSAYILAN" }, "positive": { "name": "pozitif" }, "positive_DEFAULT": { "name": "pozitif_VARSAYILAN" } }, "outputs": { "0": { "name": "pozitif" }, "1": { "name": "negatif" } } };
const PairConditioningSetProperties = { "display_name": "Koşul Çifti Özelliklerini Ayarla", "inputs": { "hooks": { "name": "kancalar" }, "mask": { "name": "maske" }, "negative_NEW": { "name": "yeni_negatif" }, "positive_NEW": { "name": "yeni_pozitif" }, "set_cond_area": { "name": "koşul_alanı_ayarla" }, "strength": { "name": "güç" }, "timesteps": { "name": "zaman_adımları" } }, "outputs": { "0": { "name": "pozitif" }, "1": { "name": "negatif" } } };
const PairConditioningSetPropertiesAndCombine = { "display_name": "Koşul Çifti Özelliklerini Ayarla ve Birleştir", "inputs": { "hooks": { "name": "kancalar" }, "mask": { "name": "maske" }, "negative": { "name": "negatif" }, "negative_NEW": { "name": "yeni_negatif" }, "positive": { "name": "pozitif" }, "positive_NEW": { "name": "yeni_pozitif" }, "set_cond_area": { "name": "koşul_alanı_ayarla" }, "strength": { "name": "güç" }, "timesteps": { "name": "zaman_adımları" } }, "outputs": { "0": { "name": "pozitif" }, "1": { "name": "negatif" } } };
const PatchModelAddDownscale = { "display_name": "Model Yaması Ekle Küçültme (Kohya Deep Shrink)", "inputs": { "block_number": { "name": "blok_numarası" }, "downscale_after_skip": { "name": "atlamadan_sonra_küçült" }, "downscale_factor": { "name": "küçültme_faktörü" }, "downscale_method": { "name": "küçültme_yöntemi" }, "end_percent": { "name": "bitiş_yüzdesi" }, "model": { "name": "model" }, "start_percent": { "name": "başlangıç_yüzdesi" }, "upscale_method": { "name": "büyütme_yöntemi" } }, "outputs": { "0": { "tooltip": null } } };
const PerpNeg = { "display_name": "Perp-Neg (PerpNegGuider tarafından ESKİ)", "inputs": { "empty_conditioning": { "name": "boş_koşullandırma" }, "model": { "name": "model" }, "neg_scale": { "name": "neg_ölçek" } }, "outputs": { "0": { "tooltip": null } } };
const PerpNegGuider = { "display_name": "PerpNegRehberi", "inputs": { "cfg": { "name": "cfg" }, "empty_conditioning": { "name": "boş_koşullandırma" }, "model": { "name": "model" }, "neg_scale": { "name": "neg_ölçek" }, "negative": { "name": "negatif" }, "positive": { "name": "pozitif" } }, "outputs": { "0": { "tooltip": null } } };
const PerturbedAttentionGuidance = { "display_name": "BozulmuşDikkatRehberliği", "inputs": { "model": { "name": "model" }, "scale": { "name": "ölçek" } }, "outputs": { "0": { "tooltip": null } } };
const PhotoMakerEncode = { "display_name": "PhotoMakerKodlama", "inputs": { "clip": { "name": "clip" }, "image": { "name": "görüntü" }, "photomaker": { "name": "photomaker" }, "text": { "name": "metin" } }, "outputs": { "0": { "tooltip": null } } };
const PhotoMakerLoader = { "display_name": "PhotoMakerYükleyici", "inputs": { "photomaker_model_name": { "name": "photomaker_model_adı" } }, "outputs": { "0": { "tooltip": null } } };
const PixverseImageToVideoNode = { "description": "İstem ve çıktı_boyutuna göre videoları eşzamanlı olarak oluşturur.", "display_name": "PixVerse Görüntüden Videoya", "inputs": { "control_after_generate": { "name": "oluşturduktan sonra kontrol et" }, "duration_seconds": { "name": "süre_saniye" }, "image": { "name": "görüntü" }, "motion_mode": { "name": "hareket_modu" }, "negative_prompt": { "name": "negatif_istem", "tooltip": "Bir görüntüde istenmeyen öğelerin isteğe bağlı metin açıklaması." }, "pixverse_template": { "name": "pixverse_şablonu", "tooltip": "PixVerse Şablon düğümü tarafından oluşturulan, üretimin stilini etkilemek için isteğe bağlı bir şablon." }, "prompt": { "name": "istem", "tooltip": "Video oluşturma istemi" }, "quality": { "name": "kalite" }, "seed": { "name": "tohum", "tooltip": "Video oluşturma için tohum." } }, "outputs": { "0": { "tooltip": null } } };
const PixverseTemplateNode = { "display_name": "PixVerse Şablonu", "inputs": { "template": { "name": "şablon" } }, "outputs": { "0": { "name": "pixverse_şablonu", "tooltip": null } } };
const PixverseTextToVideoNode = { "description": "İstem ve çıktı_boyutuna göre videoları eşzamanlı olarak oluşturur.", "display_name": "PixVerse Metinden Videoya", "inputs": { "aspect_ratio": { "name": "en_boy_oranı" }, "control_after_generate": { "name": "oluşturduktan sonra kontrol et" }, "duration_seconds": { "name": "süre_saniye" }, "motion_mode": { "name": "hareket_modu" }, "negative_prompt": { "name": "negatif_istem", "tooltip": "Bir görüntüde istenmeyen öğelerin isteğe bağlı metin açıklaması." }, "pixverse_template": { "name": "pixverse_şablonu", "tooltip": "PixVerse Şablon düğümü tarafından oluşturulan, üretimin stilini etkilemek için isteğe bağlı bir şablon." }, "prompt": { "name": "istem", "tooltip": "Video oluşturma istemi" }, "quality": { "name": "kalite" }, "seed": { "name": "tohum", "tooltip": "Video oluşturma için tohum." } }, "outputs": { "0": { "tooltip": null } } };
const PixverseTransitionVideoNode = { "description": "İstem ve çıktı_boyutuna göre videoları eşzamanlı olarak oluşturur.", "display_name": "PixVerse Geçiş Videosu", "inputs": { "control_after_generate": { "name": "oluşturduktan sonra kontrol et" }, "duration_seconds": { "name": "süre_saniye" }, "first_frame": { "name": "ilk_kare" }, "last_frame": { "name": "son_kare" }, "motion_mode": { "name": "hareket_modu" }, "negative_prompt": { "name": "negatif_istem", "tooltip": "Bir görüntüde istenmeyen öğelerin isteğe bağlı metin açıklaması." }, "prompt": { "name": "istem", "tooltip": "Video oluşturma istemi" }, "quality": { "name": "kalite" }, "seed": { "name": "tohum", "tooltip": "Video oluşturma için tohum." } }, "outputs": { "0": { "tooltip": null } } };
const PolyexponentialScheduler = { "display_name": "ÇokÜstelZamanlayıcı", "inputs": { "rho": { "name": "rho" }, "sigma_max": { "name": "sigma_maks" }, "sigma_min": { "name": "sigma_min" }, "steps": { "name": "adımlar" } } };
const PorterDuffImageComposite = { "display_name": "Porter-Duff Görüntü Birleştirme", "inputs": { "destination": { "name": "hedef" }, "destination_alpha": { "name": "hedef_alfa" }, "mode": { "name": "mod" }, "source": { "name": "kaynak" }, "source_alpha": { "name": "kaynak_alfa" } }, "outputs": { "0": { "tooltip": null }, "1": { "tooltip": null } } };
const Preview3D = { "display_name": "3D Önizleme", "inputs": { "camera_info": { "name": "kamera_bilgisi" }, "image": { "name": "görüntü" }, "model_file": { "name": "model_dosyası" } } };
const PreviewAny = { "display_name": "Herhangi Bir Şeyi Önizle", "inputs": { "preview": {}, "source": { "name": "kaynak" } } };
const PreviewAudio = { "display_name": "Sesi Önizle", "inputs": { "audio": { "name": "ses" }, "audioUI": { "name": "sesArayüzü" } } };
const PreviewImage = { "description": "Giriş görüntülerini ComfyUI çıktı dizininize kaydeder.", "display_name": "Görüntüyü Önizle", "inputs": { "images": { "name": "görüntüler" } } };
const PrimitiveBoolean = { "display_name": "Boolean", "inputs": { "value": { "name": "değer" } }, "outputs": { "0": { "tooltip": null } } };
const PrimitiveFloat = { "display_name": "Float", "inputs": { "value": { "name": "değer" } }, "outputs": { "0": { "tooltip": null } } };
const PrimitiveInt = { "display_name": "Int", "inputs": { "control_after_generate": { "name": "oluşturduktan sonra kontrol et" }, "value": { "name": "değer" } }, "outputs": { "0": { "tooltip": null } } };
const PrimitiveString = { "display_name": "String", "inputs": { "value": { "name": "değer" } }, "outputs": { "0": { "tooltip": null } } };
const PrimitiveStringMultiline = { "display_name": "String (Çok Satırlı)", "inputs": { "value": { "name": "değer" } }, "outputs": { "0": { "tooltip": null } } };
const QuadrupleCLIPLoader = { "description": "[Tarifler]\n\nhidream: uzun clip-l, uzun clip-g, t5xxl, llama_8b_3.1_instruct", "display_name": "DörtlüCLIPYükleyici", "inputs": { "clip_name1": { "name": "clip_adı1" }, "clip_name2": { "name": "clip_adı2" }, "clip_name3": { "name": "clip_adı3" }, "clip_name4": { "name": "clip_adı4" } }, "outputs": { "0": { "tooltip": null } } };
const QwenImageDiffsynthControlnet = { "display_name": "QwenImageDiffsynthControlnet", "inputs": { "image": { "name": "görsel" }, "mask": { "name": "maske" }, "model": { "name": "model" }, "model_patch": { "name": "model_yaması" }, "strength": { "name": "güç" }, "vae": { "name": "vae" } } };
const RandomNoise = { "display_name": "RastgeleGürültü", "inputs": { "control_after_generate": { "name": "oluşturduktan sonra kontrol et" }, "noise_seed": { "name": "gürültü_tohumu" } } };
const RebatchImages = { "display_name": "Görüntüleri Yeniden Grupla", "inputs": { "batch_size": { "name": "toplu_boyut" }, "images": { "name": "görüntüler" } }, "outputs": { "0": { "tooltip": null } } };
const RebatchLatents = { "display_name": "Gizli Değişkenleri Yeniden Grupla", "inputs": { "batch_size": { "name": "toplu_boyut" }, "latents": { "name": "gizli_değişkenler" } }, "outputs": { "0": { "tooltip": null } } };
const RecordAudio = { "display_name": "Ses Kaydet", "inputs": { "audio": { "name": "ses" } } };
const RecraftColorRGB = { "description": "Belirli RGB değerlerini seçerek Recraft Rengi oluşturun.", "display_name": "Recraft Renk RGB", "inputs": { "b": { "name": "m", "tooltip": "Rengin Mavi değeri." }, "g": { "name": "y", "tooltip": "Rengin Yeşil değeri." }, "r": { "name": "k", "tooltip": "Rengin Kırmızı değeri." }, "recraft_color": { "name": "recraft_rengi" } }, "outputs": { "0": { "name": "recraft_rengi", "tooltip": null } } };
const RecraftControls = { "description": "Recraft üretimini özelleştirmek için Recraft Kontrolleri oluşturun.", "display_name": "Recraft Kontrolleri", "inputs": { "background_color": { "name": "arka_plan_rengi" }, "colors": { "name": "renkler" } }, "outputs": { "0": { "name": "recraft_kontrolleri", "tooltip": null } } };
const RecraftCreativeUpscaleNode = { "description": "Görüntüyü eşzamanlı olarak büyütün.\nVerilen bir raster görüntüyü ‘yaratıcı büyütme’ aracıyla geliştirir, küçük ayrıntıları ve yüzleri iyileştirmeye odaklanarak çözünürlüğü artırır.", "display_name": "Recraft Yaratıcı Büyütme Görüntüsü", "inputs": { "image": { "name": "görüntü" } }, "outputs": { "0": { "tooltip": null } } };
const RecraftCrispUpscaleNode = { "description": "Görüntüyü eşzamanlı olarak büyütün.\nVerilen bir raster görüntüyü ‘net büyütme’ aracıyla geliştirir, görüntü çözünürlüğünü artırır, görüntüyü daha keskin ve temiz hale getirir.", "display_name": "Recraft Net Büyütme Görüntüsü", "inputs": { "image": { "name": "görüntü" } }, "outputs": { "0": { "tooltip": null } } };
const RecraftImageInpaintingNode = { "description": "İstem ve maskeye göre görüntüyü değiştirin.", "display_name": "Recraft Görüntü İç Boyama", "inputs": { "control_after_generate": { "name": "oluşturduktan sonra kontrol et" }, "image": { "name": "görüntü" }, "mask": { "name": "maske" }, "n": { "name": "n", "tooltip": "Oluşturulacak görüntü sayısı." }, "negative_prompt": { "name": "negatif_istem", "tooltip": "Bir görüntüde istenmeyen öğelerin isteğe bağlı metin açıklaması." }, "prompt": { "name": "istem", "tooltip": "Görüntü oluşturma istemi." }, "recraft_style": { "name": "recraft_stili" }, "seed": { "name": "tohum", "tooltip": "Düğümün yeniden çalışıp çalışmayacağını belirlemek için tohum; gerçek sonuçlar tohumdan bağımsız olarak belirleyici değildir." } }, "outputs": { "0": { "tooltip": null } } };
const RecraftImageToImageNode = { "description": "İstem ve güce göre görüntüyü değiştirin.", "display_name": "Recraft Görüntüden Görüntüye", "inputs": { "control_after_generate": { "name": "oluşturduktan sonra kontrol et" }, "image": { "name": "görüntü" }, "n": { "name": "n", "tooltip": "Oluşturulacak görüntü sayısı." }, "negative_prompt": { "name": "negatif_istem", "tooltip": "Bir görüntüde istenmeyen öğelerin isteğe bağlı metin açıklaması." }, "prompt": { "name": "istem", "tooltip": "Görüntü oluşturma istemi." }, "recraft_controls": { "name": "recraft_kontrolleri", "tooltip": "Recraft Kontrolleri düğümü aracılığıyla üretim üzerinde isteğe bağlı ek kontroller." }, "recraft_style": { "name": "recraft_stili" }, "seed": { "name": "tohum", "tooltip": "Düğümün yeniden çalışıp çalışmayacağını belirlemek için tohum; gerçek sonuçlar tohumdan bağımsız olarak belirleyici değildir." }, "strength": { "name": "güç", "tooltip": "Orijinal görüntü ile farkı tanımlar, [0, 1] aralığında olmalıdır, burada 0 neredeyse aynı anlamına gelir ve 1 sefil bir benzerlik anlamına gelir." } }, "outputs": { "0": { "tooltip": null } } };
const RecraftRemoveBackgroundNode = { "description": "Görüntüden arka planı kaldırın ve işlenmiş görüntüyü ve maskeyi döndürün.", "display_name": "Recraft Arka Planı Kaldır", "inputs": { "image": { "name": "görüntü" } }, "outputs": { "0": { "tooltip": null }, "1": { "tooltip": null } } };
const RecraftReplaceBackgroundNode = { "description": "Sağlanan isteme göre görüntüdeki arka planı değiştirin.", "display_name": "Recraft Arka Planı Değiştir", "inputs": { "control_after_generate": { "name": "oluşturduktan sonra kontrol et" }, "image": { "name": "görüntü" }, "n": { "name": "n", "tooltip": "Oluşturulacak görüntü sayısı." }, "negative_prompt": { "name": "negatif_istem", "tooltip": "Bir görüntüde istenmeyen öğelerin isteğe bağlı metin açıklaması." }, "prompt": { "name": "istem", "tooltip": "Görüntü oluşturma istemi." }, "recraft_style": { "name": "recraft_stili" }, "seed": { "name": "tohum", "tooltip": "Düğümün yeniden çalışıp çalışmayacağını belirlemek için tohum; gerçek sonuçlar tohumdan bağımsız olarak belirleyici değildir." } }, "outputs": { "0": { "tooltip": null } } };
const RecraftStyleV3DigitalIllustration = { "description": "Gerçekçi_görüntü stilini ve isteğe bağlı alt stili seçin.", "display_name": "Recraft Stili - Dijital İllüstrasyon", "inputs": { "substyle": { "name": "alt_stil" } }, "outputs": { "0": { "name": "recraft_stili", "tooltip": null } } };
const RecraftStyleV3InfiniteStyleLibrary = { "description": "Recraft'ın Sonsuz Stil Kütüphanesinden önceden var olan UUID'ye göre stil seçin.", "display_name": "Recraft Stili - Sonsuz Stil Kütüphanesi", "inputs": { "style_id": { "name": "stil_kimliği", "tooltip": "Sonsuz Stil Kütüphanesinden stilin UUID'si." } }, "outputs": { "0": { "name": "recraft_stili", "tooltip": null } } };
const RecraftStyleV3LogoRaster = { "description": "Gerçekçi_görüntü stilini ve isteğe bağlı alt stili seçin.", "display_name": "Recraft Stili - Logo Raster", "inputs": { "substyle": { "name": "alt_stil" } }, "outputs": { "0": { "name": "recraft_stili", "tooltip": null } } };
const RecraftStyleV3RealisticImage = { "description": "Gerçekçi_görüntü stilini ve isteğe bağlı alt stili seçin.", "display_name": "Recraft Stili - Gerçekçi Görüntü", "inputs": { "substyle": { "name": "alt_stil" } }, "outputs": { "0": { "name": "recraft_stili", "tooltip": null } } };
const RecraftTextToImageNode = { "description": "İstem ve çözünürlüğe göre görüntüleri eşzamanlı olarak oluşturur.", "display_name": "Recraft Metinden Görüntüye", "inputs": { "control_after_generate": { "name": "oluşturduktan sonra kontrol et" }, "n": { "name": "n", "tooltip": "Oluşturulacak görüntü sayısı." }, "negative_prompt": { "name": "negatif_istem", "tooltip": "Bir görüntüde istenmeyen öğelerin isteğe bağlı metin açıklaması." }, "prompt": { "name": "istem", "tooltip": "Görüntü oluşturma istemi." }, "recraft_controls": { "name": "recraft_kontrolleri", "tooltip": "Recraft Kontrolleri düğümü aracılığıyla üretim üzerinde isteğe bağlı ek kontroller." }, "recraft_style": { "name": "recraft_stili" }, "seed": { "name": "tohum", "tooltip": "Düğümün yeniden çalışıp çalışmayacağını belirlemek için tohum; gerçek sonuçlar tohumdan bağımsız olarak belirleyici değildir." }, "size": { "name": "boyut", "tooltip": "Oluşturulan görüntünün boyutu." } }, "outputs": { "0": { "tooltip": null } } };
const RecraftTextToVectorNode = { "description": "İstem ve çözünürlüğe göre SVG'yi eşzamanlı olarak oluşturur.", "display_name": "Recraft Metinden Vektöre", "inputs": { "control_after_generate": { "name": "oluşturduktan sonra kontrol et" }, "n": { "name": "n", "tooltip": "Oluşturulacak görüntü sayısı." }, "negative_prompt": { "name": "negatif_istem", "tooltip": "Bir görüntüde istenmeyen öğelerin isteğe bağlı metin açıklaması." }, "prompt": { "name": "istem", "tooltip": "Görüntü oluşturma istemi." }, "recraft_controls": { "name": "recraft_kontrolleri", "tooltip": "Recraft Kontrolleri düğümü aracılığıyla üretim üzerinde isteğe bağlı ek kontroller." }, "seed": { "name": "tohum", "tooltip": "Düğümün yeniden çalışıp çalışmayacağını belirlemek için tohum; gerçek sonuçlar tohumdan bağımsız olarak belirleyici değildir." }, "size": { "name": "boyut", "tooltip": "Oluşturulan görüntünün boyutu." }, "substyle": { "name": "alt_stil" } }, "outputs": { "0": { "tooltip": null } } };
const RecraftVectorizeImageNode = { "description": "Bir giriş görüntüsünden eşzamanlı olarak SVG oluşturur.", "display_name": "Recraft Görüntüyü Vektörleştir", "inputs": { "image": { "name": "görüntü" } }, "outputs": { "0": { "tooltip": null } } };
const ReferenceLatent = { "description": "Bu düğüm, bir düzenleme modeli için kılavuz gizli değişkeni ayarlar. Model destekliyorsa, birden fazla referans görsel ayarlamak için birden fazla düğümü zincirleyebilirsiniz.", "display_name": "Referans Gizli Değişken", "inputs": { "conditioning": { "name": "koşullandırma" }, "latent": { "name": "gizli değişken" } }, "outputs": { "0": { "tooltip": null } } };
const RegexExtract = { "display_name": "Regex Çıkar", "inputs": { "case_insensitive": { "name": "büyük/küçük harf duyarsız" }, "dotall": { "name": "nokta her şey" }, "group_index": { "name": "grup_indeksi" }, "mode": { "name": "mod" }, "multiline": { "name": "çok satırlı" }, "regex_pattern": { "name": "regex_deseni" }, "string": { "name": "dize" } }, "outputs": { "0": { "tooltip": null } } };
const RegexMatch = { "display_name": "Regex Eşleştir", "inputs": { "case_insensitive": { "name": "büyük/küçük harf duyarsız" }, "dotall": { "name": "nokta her şey" }, "multiline": { "name": "çok satırlı" }, "regex_pattern": { "name": "regex_deseni" }, "string": { "name": "dize" } }, "outputs": { "0": { "name": "eşleşmeler", "tooltip": null } } };
const RegexReplace = { "description": "Regex desenlerini kullanarak metin bul ve değiştir.", "display_name": "Regex Değiştir", "inputs": { "case_insensitive": { "name": "büyük/küçük harf duyarsız" }, "count": { "name": "sayı", "tooltip": "Yapılacak maksimum değiştirme sayısı. Tüm oluşumları değiştirmek için 0 olarak ayarlayın (varsayılan). Yalnızca ilk eşleşmeyi değiştirmek için 1, ilk iki eşleşme için 2 vb. ayarlayın." }, "dotall": { "name": "nokta her şey", "tooltip": "Etkinleştirildiğinde, nokta (.) karakteri yeni satır karakterleri dahil herhangi bir karakterle eşleşir. Devre dışı bırakıldığında, noktalar yeni satırlarla eşleşmez." }, "multiline": { "name": "çok satırlı" }, "regex_pattern": { "name": "regex_deseni" }, "replace": { "name": "değiştir" }, "string": { "name": "dize" } }, "outputs": { "0": { "tooltip": null } } };
const RenormCFG = { "display_name": "YenidenNormalleştirCFG", "inputs": { "cfg_trunc": { "name": "cfg_kesme" }, "model": { "name": "model" }, "renorm_cfg": { "name": "yenidenorm_cfg" } }, "outputs": { "0": { "tooltip": null } } };
const RepeatImageBatch = { "display_name": "GörüntüGrubunuTekrarla", "inputs": { "amount": { "name": "miktar" }, "image": { "name": "görüntü" } } };
const RepeatLatentBatch = { "display_name": "Gizli Grubu Tekrarla", "inputs": { "amount": { "name": "miktar" }, "samples": { "name": "örnekler" } } };
const RescaleCFG = { "display_name": "CFG'yiYenidenÖlçekle", "inputs": { "model": { "name": "model" }, "multiplier": { "name": "çarpan" } } };
const ResizeAndPadImage = { "display_name": "Yeniden Boyutlandır ve Doldur Görsel", "inputs": { "image": { "name": "görsel" }, "interpolation": { "name": "enterpolasyon" }, "padding_color": { "name": "dolgu_rengi" }, "target_height": { "name": "hedef_yükseklik" }, "target_width": { "name": "hedef_genişlik" } } };
const Rodin3D_Detail = { "description": "Rodin API kullanarak 3D Varlıklar Oluştur", "display_name": "Rodin 3D Oluştur - Detay Oluştur", "inputs": { "Images": { "name": "Görseller" }, "Material_Type": { "name": "Malzeme_Türü" }, "Polygon_count": { "name": "Poligon_sayısı" }, "Seed": { "name": "Tohum" } }, "outputs": { "0": { "name": "3D Model Yolu", "tooltip": null } } };
const Rodin3D_Gen2 = { "description": "Rodin API kullanarak 3D Varlıklar Oluştur", "display_name": "Rodin 3D Oluştur - Gen-2 Oluştur", "inputs": { "Images": { "name": "Görseller" }, "Material_Type": { "name": "Malzeme_Türü" }, "Polygon_count": { "name": "Poligon_sayısı" }, "Seed": { "name": "Tohum" }, "TAPose": { "name": "TAPoz" } }, "outputs": { "0": { "name": "3D Model Yolu", "tooltip": null } } };
const Rodin3D_Regular = { "description": "Rodin API kullanarak 3D Varlıklar Oluştur", "display_name": "Rodin 3D Oluştur - Normal Oluştur", "inputs": { "Images": { "name": "Görseller" }, "Material_Type": { "name": "Malzeme_Türü" }, "Polygon_count": { "name": "Poligon_sayısı" }, "Seed": { "name": "Tohum" } }, "outputs": { "0": { "name": "3D Model Yolu", "tooltip": null } } };
const Rodin3D_Sketch = { "description": "Rodin API kullanarak 3D Varlıklar Oluştur", "display_name": "Rodin 3D Oluştur - Taslak Oluştur", "inputs": { "Images": { "name": "Görseller" }, "Seed": { "name": "Tohum" } }, "outputs": { "0": { "name": "3D Model Yolu", "tooltip": null } } };
const Rodin3D_Smooth = { "description": "Rodin API kullanarak 3D Varlıklar Oluştur", "display_name": "Rodin 3D Oluştur - Pürüzsüz Oluştur", "inputs": { "Images": { "name": "Görseller" }, "Material_Type": { "name": "Malzeme_Türü" }, "Polygon_count": { "name": "Çokgen Sayısı" }, "Seed": { "name": "Tohum" } }, "outputs": { "0": { "name": "3D Model Yolu", "tooltip": null } } };
const RunwayFirstLastFrameNode = { "description": "İlk ve son anahtar kareleri yükleyin, bir prompt taslağı oluşturun ve video üretin. Son karenin İlk kareden tamamen farklı olduğu durumlar gibi daha karmaşık geçişler, daha uzun 10 saniyelik süreden faydalanabilir. Bu, üretimin iki girdi arasında daha pürüzsüz geçiş yapması için daha fazla zaman tanır. Başlamadan önce, girdi seçimlerinizin üretiminizi başarıya ulaştıracağından emin olmak için bu en iyi uygulamaları gözden geçirin: https://help.runwayml.com/hc/en-us/articles/34170748696595-Creating-with-Keyframes-on-Gen-3.", "display_name": "Runway İlk-Son-Kare'den Videoya", "inputs": { "control_after_generate": { "name": "üretim sonrası kontrol" }, "duration": { "name": "süre" }, "end_frame": { "name": "bitiş_karesi", "tooltip": "Video için kullanılacak bitiş karesi. Sadece gen3a_turbo için desteklenir." }, "prompt": { "name": "prompt", "tooltip": "Üretim için metin prompt'u" }, "ratio": { "name": "oran" }, "seed": { "name": "tohum", "tooltip": "Üretim için rastgele tohum değeri" }, "start_frame": { "name": "başlangıç_karesi", "tooltip": "Video için kullanılacak başlangıç karesi" } }, "outputs": { "0": { "tooltip": null } } };
const RunwayImageToVideoNodeGen3a = { "description": "Gen3a Turbo modelini kullanarak tek bir başlangıç karesinden video üretin. Başlamadan önce, girdi seçimlerinizin üretiminizi başarıya ulaştıracağından emin olmak için bu en iyi uygulamaları gözden geçirin: https://help.runwayml.com/hc/en-us/articles/33927968552339-Creating-with-Act-One-on-Gen-3-Alpha-and-Turbo.", "display_name": "Runway Görüntüden Videoya (Gen3a Turbo)", "inputs": { "control_after_generate": { "name": "üretim sonrası kontrol" }, "duration": { "name": "süre" }, "prompt": { "name": "prompt", "tooltip": "Üretim için metin prompt'u" }, "ratio": { "name": "oran" }, "seed": { "name": "tohum", "tooltip": "Üretim için rastgele tohum değeri" }, "start_frame": { "name": "başlangıç_karesi", "tooltip": "Video için kullanılacak başlangıç karesi" } }, "outputs": { "0": { "tooltip": null } } };
const RunwayImageToVideoNodeGen4 = { "description": "Gen4 Turbo modelini kullanarak tek bir başlangıç karesinden video üretin. Başlamadan önce, girdi seçimlerinizin üretiminizi başarıya ulaştıracağından emin olmak için bu en iyi uygulamaları gözden geçirin: https://help.runwayml.com/hc/en-us/articles/37327109429011-Creating-with-Gen-4-Video.", "display_name": "Runway Görüntüden Videoya (Gen4 Turbo)", "inputs": { "control_after_generate": { "name": "üretim sonrası kontrol" }, "duration": { "name": "süre" }, "prompt": { "name": "prompt", "tooltip": "Üretim için metin prompt'u" }, "ratio": { "name": "oran" }, "seed": { "name": "tohum", "tooltip": "Rastgele üretim tohumu" }, "start_frame": { "name": "başlangıç_karesi", "tooltip": "Video için kullanılacak başlangıç karesi" } }, "outputs": { "0": { "tooltip": null } } };
const RunwayTextToImageNode = { "description": "Runway'nin Gen 4 modelini kullanarak bir metin isteminden görsel oluşturun. Ayrıca üretimi yönlendirmek için referans görsel de ekleyebilirsiniz.", "display_name": "Runway Metinden Görsele", "inputs": { "prompt": { "name": "istem", "tooltip": "Üretim için metin istemi" }, "ratio": { "name": "oran" }, "reference_image": { "name": "referans_görsel", "tooltip": "Üretimi yönlendirmek için isteğe bağlı referans görsel" } }, "outputs": { "0": { "tooltip": null } } };
const SDTurboScheduler = { "display_name": "SDTurboZamanlayıcı", "inputs": { "denoise": { "name": "gürültü_azaltma" }, "model": { "name": "model" }, "steps": { "name": "adımlar" } } };
const SD_4XUpscale_Conditioning = { "display_name": "SD_4X_Büyütme_Koşullandırma", "inputs": { "images": { "name": "görüntüler" }, "negative": { "name": "negatif" }, "noise_augmentation": { "name": "gürültü_artırımı" }, "positive": { "name": "pozitif" }, "scale_ratio": { "name": "ölçek_oranı" } }, "outputs": { "0": { "name": "pozitif", "tooltip": null }, "1": { "name": "negatif", "tooltip": null }, "2": { "name": "gizli", "tooltip": null } } };
const SV3D_Conditioning = { "display_name": "SV3D_Koşullandırma", "inputs": { "clip_vision": { "name": "clip_görü" }, "elevation": { "name": "yükseklik" }, "height": { "name": "yükseklik" }, "init_image": { "name": "başlangıç_görüntüsü" }, "vae": { "name": "vae" }, "video_frames": { "name": "video_kareleri" }, "width": { "name": "genişlik" } }, "outputs": { "0": { "name": "pozitif", "tooltip": null }, "1": { "name": "negatif", "tooltip": null }, "2": { "name": "gizli", "tooltip": null } } };
const SVD_img2vid_Conditioning = { "display_name": "SVD_görüntüden_videoya_Koşullandırma", "inputs": { "augmentation_level": { "name": "artırma_seviyesi" }, "clip_vision": { "name": "clip_görü" }, "fps": { "name": "fps" }, "height": { "name": "yükseklik" }, "init_image": { "name": "başlangıç_görüntüsü" }, "motion_bucket_id": { "name": "hareket_kovası_kimliği" }, "vae": { "name": "vae" }, "video_frames": { "name": "video_kareleri" }, "width": { "name": "genişlik" } }, "outputs": { "0": { "name": "pozitif" }, "1": { "name": "negatif" }, "2": { "name": "gizli" } } };
const SamplerCustom = { "display_name": "ÖzelÖrnekleyici", "inputs": { "add_noise": { "name": "gürültü_ekle" }, "cfg": { "name": "cfg" }, "control_after_generate": { "name": "oluşturduktan sonra kontrol et" }, "latent_image": { "name": "gizli_görüntü" }, "model": { "name": "model" }, "negative": { "name": "negatif" }, "noise_seed": { "name": "gürültü_tohumu" }, "positive": { "name": "pozitif" }, "sampler": { "name": "örnekleyici" }, "sigmas": { "name": "sigmalar" } }, "outputs": { "0": { "name": "çıktı" }, "1": { "name": "gürültüsü_alınmış_çıktı" } } };
const SamplerCustomAdvanced = { "display_name": "GelişmişÖzelÖrnekleyici", "inputs": { "guider": { "name": "rehber" }, "latent_image": { "name": "gizli_görüntü" }, "noise": { "name": "gürültü" }, "sampler": { "name": "örnekleyici" }, "sigmas": { "name": "sigmalar" } }, "outputs": { "0": { "name": "çıktı" }, "1": { "name": "gürültüsü_alınmış_çıktı" } } };
const SamplerDPMAdaptative = { "display_name": "UyarlanabilirDPMÖrnekleyici", "inputs": { "accept_safety": { "name": "kabul_güvenliği" }, "atol": { "name": "atol" }, "dcoeff": { "name": "dkatsayı" }, "eta": { "name": "eta" }, "h_init": { "name": "h_başlangıç" }, "icoeff": { "name": "ikatsayı" }, "order": { "name": "sıra" }, "pcoeff": { "name": "pkatsayı" }, "rtol": { "name": "rtol" }, "s_noise": { "name": "s_gürültü" } } };
const SamplerDPMPP_2M_SDE = { "display_name": "ÖrnekleyiciDPMPP_2M_SDE", "inputs": { "eta": { "name": "eta" }, "noise_device": { "name": "gürültü_cihazı" }, "s_noise": { "name": "s_gürültü" }, "solver_type": { "name": "çözücü_türü" } } };
const SamplerDPMPP_2S_Ancestral = { "display_name": "ÖrnekleyiciDPMPP_2S_Atasal", "inputs": { "eta": { "name": "eta" }, "s_noise": { "name": "s_gürültü" } } };
const SamplerDPMPP_3M_SDE = { "display_name": "ÖrnekleyiciDPMPP_3M_SDE", "inputs": { "eta": { "name": "eta" }, "noise_device": { "name": "gürültü_cihazı" }, "s_noise": { "name": "s_gürültü" } } };
const SamplerDPMPP_SDE = { "display_name": "ÖrnekleyiciDPMPP_SDE", "inputs": { "eta": { "name": "eta" }, "noise_device": { "name": "gürültü_cihazı" }, "r": { "name": "r" }, "s_noise": { "name": "s_gürültü" } } };
const SamplerER_SDE = { "display_name": "SamplerER_SDE", "inputs": { "eta": { "name": "eta", "tooltip": "Ters-zamanlı SDE'nin stokastik gücü.\neta=0 olduğunda deterministik ODE'ye indirgenir. Bu ayar ER-SDE çözücü tipi için geçerli değildir." }, "max_stage": { "name": "maksimum_aşama" }, "s_noise": { "name": "s_gürültü" }, "solver_type": { "name": "çözücü_tipi" } } };
const SamplerEulerAncestral = { "display_name": "Euler Atasal Örnekleyici", "inputs": { "eta": { "name": "eta" }, "s_noise": { "name": "s_gürültü" } } };
const SamplerEulerAncestralCFGPP = { "display_name": "Euler Atasal Örnekleyici CFG++", "inputs": { "eta": { "name": "eta" }, "s_noise": { "name": "s_gürültü" } } };
const SamplerEulerCFGpp = { "display_name": "Euler Örnekleyici CFG++", "inputs": { "version": { "name": "sürüm" } }, "outputs": { "0": { "tooltip": null } } };
const SamplerLCMUpscale = { "display_name": "LCM Büyütme Örnekleyici", "inputs": { "scale_ratio": { "name": "ölçek_oranı" }, "scale_steps": { "name": "ölçek_adımları" }, "upscale_method": { "name": "büyütme_yöntemi" } }, "outputs": { "0": { "tooltip": null } } };
const SamplerLMS = { "display_name": "LMS Örnekleyici", "inputs": { "order": { "name": "sıra" } } };
const SamplerSASolver = { "display_name": "SamplerSASolver", "inputs": { "corrector_order": { "name": "düzeltici_sırası" }, "eta": { "name": "eta" }, "model": { "name": "model" }, "predictor_order": { "name": "tahminci_sırası" }, "s_noise": { "name": "s_gürültü" }, "sde_end_percent": { "name": "sde_bitiş_yüzdesi" }, "sde_start_percent": { "name": "sde_başlangıç_yüzdesi" }, "simple_order_2": { "name": "basit_sıra_2" }, "use_pece": { "name": "pece_kullan" } } };
const SamplingPercentToSigma = { "display_name": "ÖrneklemeYüzdesiToSigma", "inputs": { "model": { "name": "model" }, "return_actual_sigma": { "name": "gerçek_sigma_değerini_döndür", "tooltip": "Aralık kontrolleri için kullanılan değer yerine gerçek sigma değerini döndür.\nBu yalnızca 0.0 ve 1.0'daki sonuçları etkiler." }, "sampling_percent": { "name": "örnekleme_yüzdesi" } }, "outputs": { "0": { "name": "sigma_değeri" } } };
const SaveAnimatedPNG = { "display_name": "Animasyonlu PNG Kaydet", "inputs": { "compress_level": { "name": "sıkıştırma_seviyesi" }, "filename_prefix": { "name": "dosyaadı_öneki" }, "fps": { "name": "fps" }, "images": { "name": "görüntüler" } } };
const SaveAnimatedWEBP = { "display_name": "Animasyonlu WEBP Kaydet", "inputs": { "filename_prefix": { "name": "dosyaadı_öneki" }, "fps": { "name": "fps" }, "images": { "name": "görüntüler" }, "lossless": { "name": "kayıpsız" }, "method": { "name": "yöntem" }, "quality": { "name": "kalite" } } };
const SaveAudio = { "display_name": "Sesi Kaydet", "inputs": { "audio": { "name": "ses" }, "audioUI": { "name": "sesArayüzü" }, "filename_prefix": { "name": "dosyaadı_öneki" } } };
const SaveAudioMP3 = { "display_name": "Ses Kaydet (MP3)", "inputs": { "audio": { "name": "ses" }, "audioUI": { "name": "sesArayüzü" }, "filename_prefix": { "name": "dosya_adı_ön_eki" }, "quality": { "name": "kalite" } } };
const SaveAudioOpus = { "display_name": "Sesi Kaydet (Opus)", "inputs": { "audio": { "name": "ses" }, "audioUI": { "name": "sesArayüzü" }, "filename_prefix": { "name": "dosya_adı_ön_eki" }, "quality": { "name": "kalite" } } };
const SaveGLB = { "display_name": "GLB Kaydet", "inputs": { "filename_prefix": { "name": "dosyaadı_öneki" }, "image": { "name": "görüntü" }, "mesh": { "name": "ağ" } } };
const SaveImage = { "description": "Giriş görüntülerini ComfyUI çıktı dizininize kaydeder.", "display_name": "Görüntüyü Kaydet", "inputs": { "filename_prefix": { "name": "dosyaadı_öneki", "tooltip": "Kaydedilecek dosyanın öneki. Bu, düğümlerden değerleri dahil etmek için %date:yyyy-MM-dd% veya %Empty Latent Image.width% gibi biçimlendirme bilgileri içerebilir." }, "images": { "name": "görüntüler", "tooltip": "Kaydedilecek görüntüler." } } };
const SaveImageWebsocket = { "display_name": "GörüntüyüWebsocketKaydet", "inputs": { "images": { "name": "görüntüler" } } };
const SaveLatent = { "display_name": "GizliDeğişkeniKaydet", "inputs": { "filename_prefix": { "name": "dosyaadı_öneki" }, "samples": { "name": "örnekler" } } };
const SaveSVGNode = { "description": "SVG dosyalarını diske kaydet.", "display_name": "SVGDüğümünüKaydet", "inputs": { "filename_prefix": { "name": "dosya_adı_ön_eki", "tooltip": "Kaydedilecek dosya için ön ek. Bu, düğümlerden gelen değerleri eklemek için %tarih:yyyy-MM-dd% veya %Boş Gizli Görüntü.genişlik% gibi biçimlendirme bilgileri içerebilir." }, "svg": { "name": "svg" } } };
const SaveVideo = { "description": "Giriş görüntülerini ComfyUI çıktı dizininize kaydeder.", "display_name": "Videoyu Kaydet", "inputs": { "codec": { "name": "codec", "tooltip": "Video için kullanılacak codec." }, "filename_prefix": { "name": "dosyaadı_öneki", "tooltip": "Kaydedilecek dosyanın öneki. Bu, düğümlerden değerleri dahil etmek için %date:yyyy-MM-dd% veya %Empty Latent Image.width% gibi biçimlendirme bilgileri içerebilir." }, "format": { "name": "format", "tooltip": "Videonun kaydedileceği format." }, "video": { "name": "video", "tooltip": "Kaydedilecek video." } } };
const SaveWEBM = { "display_name": "WEBM Kaydet", "inputs": { "codec": { "name": "codec" }, "crf": { "name": "crf", "tooltip": "Daha yüksek crf, daha küçük dosya boyutuyla daha düşük kalite anlamına gelir, daha düşük crf ise daha yüksek kalite daha yüksek dosya boyutu anlamına gelir." }, "filename_prefix": { "name": "dosyaadı_öneki" }, "fps": { "name": "fps" }, "images": { "name": "görüntüler" } } };
const ScaleROPE = { "description": "Modelin ROPE'sini ölçeklendir ve kaydır.", "display_name": "ROPEÖlçekle", "inputs": { "model": { "name": "model" }, "scale_t": { "name": "t_ölçeği" }, "scale_x": { "name": "x_ölçeği" }, "scale_y": { "name": "y_ölçeği" }, "shift_t": { "name": "t_kaydırma" }, "shift_x": { "name": "x_kaydırma" }, "shift_y": { "name": "y_kaydırma" } }, "outputs": { "0": { "tooltip": null } } };
const SelfAttentionGuidance = { "display_name": "Öz-Dikkat Rehberliği", "inputs": { "blur_sigma": { "name": "bulanıklık_sigma" }, "model": { "name": "model" }, "scale": { "name": "ölçek" } }, "outputs": { "0": { "tooltip": null } } };
const SetClipHooks = { "display_name": "CLIP Kancalarını Ayarla", "inputs": { "apply_to_conds": { "name": "koşullara_uygula" }, "clip": { "name": "clip" }, "hooks": { "name": "kancalar" }, "schedule_clip": { "name": "zamanlama_klibi" } } };
const SetFirstSigma = { "display_name": "İlkSigmayıAyarla", "inputs": { "sigma": { "name": "sigma" }, "sigmas": { "name": "sigmalar" } } };
const SetHookKeyframes = { "display_name": "Kanca Anahtar Karelerini Ayarla", "inputs": { "hook_kf": { "name": "kanca_kf" }, "hooks": { "name": "kancalar" } } };
const SetLatentNoiseMask = { "display_name": "Gizli Gürültü Maskesi Ayarla", "inputs": { "mask": { "name": "maske" }, "samples": { "name": "örnekler" } } };
const SetUnionControlNetType = { "display_name": "BileşimControlNetTürüAyarla", "inputs": { "control_net": { "name": "kontrol_ağı" }, "type": { "name": "tür" } }, "outputs": { "0": { "tooltip": null } } };
const SkipLayerGuidanceDiT = { "description": "Her DiT modelinde kullanılabilecek SkipLayerGuidance düğümünün genel bir sürümü.", "display_name": "KatmanAtlamaRehberliğiDiT", "inputs": { "double_layers": { "name": "çift_katmanlar" }, "end_percent": { "name": "bitiş_yüzdesi" }, "model": { "name": "model" }, "rescaling_scale": { "name": "yeniden_ölçeklendirme_ölçeği" }, "scale": { "name": "ölçek" }, "single_layers": { "name": "tek_katmanlar" }, "start_percent": { "name": "başlangıç_yüzdesi" } }, "outputs": { "0": { "tooltip": null } } };
const SkipLayerGuidanceDiTSimple = { "description": "Yalnızca koşulsuz geçişi değiştiren SkipLayerGuidanceDiT düğümünün basit versiyonu.", "display_name": "KatmanAtlamaRehberliğiDiTBasit", "inputs": { "double_layers": { "name": "çift_katmanlar" }, "end_percent": { "name": "bitiş_yüzdesi" }, "model": { "name": "model" }, "single_layers": { "name": "tek_katmanlar" }, "start_percent": { "name": "başlangıç_yüzdesi" } }, "outputs": { "0": { "tooltip": null } } };
const SkipLayerGuidanceSD3 = { "description": "Her DiT modelinde kullanılabilecek SkipLayerGuidance düğümünün genel bir sürümü.", "display_name": "KatmanAtlamaRehberliğiSD3", "inputs": { "end_percent": { "name": "bitiş_yüzdesi" }, "layers": { "name": "katmanlar" }, "model": { "name": "model" }, "scale": { "name": "ölçek" }, "start_percent": { "name": "başlangıç_yüzdesi" } }, "outputs": { "0": { "tooltip": null } } };
const SolidMask = { "display_name": "KatıMaske", "inputs": { "height": { "name": "yükseklik" }, "value": { "name": "değer" }, "width": { "name": "genişlik" } } };
const SplitAudioChannels = { "description": "Sesi sol ve sağ kanallara ayırır.", "display_name": "Ses Kanallarını Ayır", "inputs": { "audio": { "name": "ses" } }, "outputs": { "0": { "name": "sol" }, "1": { "name": "sağ" } } };
const SplitImageWithAlpha = { "display_name": "Görüntüyü Alfa ile Böl", "inputs": { "image": { "name": "görüntü" } }, "outputs": { "0": { "tooltip": null }, "1": { "tooltip": null } } };
const SplitSigmas = { "display_name": "SigmalarıBöl", "inputs": { "sigmas": { "name": "sigmalar" }, "step": { "name": "adım" } }, "outputs": { "0": { "name": "yüksek_sigmalar" }, "1": { "name": "düşük_sigmalar" } } };
const SplitSigmasDenoise = { "display_name": "SigmalarıGürültüAzaltmaBöl", "inputs": { "denoise": { "name": "gürültü_azaltma" }, "sigmas": { "name": "sigmalar" } }, "outputs": { "0": { "name": "yüksek_sigmalar" }, "1": { "name": "düşük_sigmalar" } } };
const StabilityAudioInpaint = { "description": "Mevcut ses örneğinin bir bölümünü metin talimatları kullanarak dönüştürür.", "display_name": "Stability AI Ses İç Boyama", "inputs": { "audio": { "name": "ses", "tooltip": "Ses 6 ile 190 saniye arasında olmalıdır." }, "control_after_generate": { "name": "oluşturduktan sonra kontrol et" }, "duration": { "name": "süre", "tooltip": "Oluşturulan sesin saniye cinsinden süresini kontrol eder." }, "mask_end": { "name": "maske_bitiş" }, "mask_start": { "name": "maske_başlangıç" }, "model": { "name": "model" }, "prompt": { "name": "komut" }, "seed": { "name": "tohum", "tooltip": "Oluşturma için kullanılan rastgele tohum değeri." }, "steps": { "name": "adımlar", "tooltip": "Örnekleme adımlarının sayısını kontrol eder." } }, "outputs": { "0": { "tooltip": null } } };
const StabilityAudioToAudio = { "description": "Mevcut ses örneklerini metin talimatları kullanarak yeni yüksek kaliteli kompozisyonlara dönüştürür.", "display_name": "Stability AI Ses'ten Ses'e", "inputs": { "audio": { "name": "ses", "tooltip": "Ses 6 ile 190 saniye arasında olmalıdır." }, "control_after_generate": { "name": "oluşturduktan sonra kontrol et" }, "duration": { "name": "süre", "tooltip": "Oluşturulan sesin saniye cinsinden süresini kontrol eder." }, "model": { "name": "model" }, "prompt": { "name": "komut" }, "seed": { "name": "tohum", "tooltip": "Oluşturma için kullanılan rastgele tohum değeri." }, "steps": { "name": "adımlar", "tooltip": "Örnekleme adımlarının sayısını kontrol eder." }, "strength": { "name": "güç", "tooltip": "Parametre, ses parametresinin oluşturulan ses üzerindeki etkisini kontrol eder." } }, "outputs": { "0": { "tooltip": null } } };
const StabilityStableImageSD_3_5Node = { "description": "İstem ve çözünürlüğe göre görüntüleri eşzamanlı olarak oluşturur.", "display_name": "Stability AI Stable Diffusion 3.5 Görüntü", "inputs": { "aspect_ratio": { "name": "en_boy_oranı", "tooltip": "Oluşturulan görüntünün en boy oranı." }, "cfg_scale": { "name": "cfg_ölçeği", "tooltip": "Difüzyon sürecinin istem metnine ne kadar sıkı bir şekilde bağlı kaldığı (daha yüksek değerler görüntünüzü isteminize daha yakın tutar)" }, "control_after_generate": { "name": "oluşturduktan sonra kontrol et" }, "image": { "name": "görüntü" }, "image_denoise": { "name": "görüntü_gürültü_azaltma", "tooltip": "Giriş görüntüsünün gürültüsünün azaltılması; 0.0 girdiyle aynı bir görüntü verir, 1.0 ise hiç görüntü sağlanmamış gibidir." }, "model": { "name": "model" }, "negative_prompt": { "name": "negatif_istem", "tooltip": "Çıktı görüntüsünde ne görmek istemediğinizin anahtar kelimeleri. Bu gelişmiş bir özelliktir." }, "prompt": { "name": "istem", "tooltip": "Çıktı görüntüsünde ne görmek istediğiniz. Öğeleri, renkleri ve konuları açıkça tanımlayan güçlü, açıklayıcı bir istem daha iyi sonuçlara yol açacaktır." }, "seed": { "name": "tohum", "tooltip": "Gürültüyü oluşturmak için kullanılan rastgele tohum." }, "style_preset": { "name": "stil_önayarı", "tooltip": "Oluşturulan görüntünün isteğe bağlı istenen stili." } }, "outputs": { "0": { "tooltip": null } } };
const StabilityStableImageUltraNode = { "description": "İstem ve çözünürlüğe göre görüntüleri eşzamanlı olarak oluşturur.", "display_name": "Stability AI Stable Image Ultra", "inputs": { "aspect_ratio": { "name": "en_boy_oranı", "tooltip": "Oluşturulan görüntünün en boy oranı." }, "control_after_generate": { "name": "oluşturduktan sonra kontrol et" }, "image": { "name": "görüntü" }, "image_denoise": { "name": "görüntü_gürültü_azaltma", "tooltip": "Giriş görüntüsünün gürültüsünün azaltılması; 0.0 girdiyle aynı bir görüntü verir, 1.0 ise hiç görüntü sağlanmamış gibidir." }, "negative_prompt": { "name": "negatif_istem", "tooltip": "Çıktı görüntüsünde ne görmek istemediğinizi anlatan bir metin. Bu gelişmiş bir özelliktir." }, "prompt": { "name": "istem", "tooltip": "Çıktı görüntüsünde ne görmek istediğiniz. Öğeleri, renkleri ve konuları açıkça tanımlayan güçlü, açıklayıcı bir istem daha iyi sonuçlara yol açacaktır. Belirli bir kelimenin ağırlığını kontrol etmek için (kelime:ağırlık) formatını kullanın, burada 'kelime' ağırlığını kontrol etmek istediğiniz kelime ve 'ağırlık' 0 ile 1 arasında bir değerdir. Örneğin: 'Gökyüzü berrak (mavi:0.3) ve (yeşil:0.8) idi' mavi ve yeşil bir gökyüzü, ancak maviden daha çok yeşil olduğunu ifade eder." }, "seed": { "name": "tohum", "tooltip": "Gürültüyü oluşturmak için kullanılan rastgele tohum." }, "style_preset": { "name": "stil_önayarı", "tooltip": "Oluşturulan görüntünün isteğe bağlı istenen stili." } }, "outputs": { "0": { "tooltip": null } } };
const StabilityTextToAudio = { "description": "Metin açıklamalarından yüksek kaliteli müzik ve ses efektleri üretir.", "display_name": "Stability AI Metin'den Ses'e", "inputs": { "control_after_generate": { "name": "üretim sonrası kontrol" }, "duration": { "name": "süre", "tooltip": "Üretilen sesin saniye cinsinden süresini kontrol eder." }, "model": { "name": "model" }, "prompt": { "name": "prompt" }, "seed": { "name": "tohum", "tooltip": "Üretim için kullanılan rastgele tohum değeri." }, "steps": { "name": "adımlar", "tooltip": "Örnekleme adımlarının sayısını kontrol eder." } }, "outputs": { "0": { "tooltip": null } } };
const StabilityUpscaleConservativeNode = { "description": "Görüntüyü minimum değişiklikle 4K çözünürlüğe büyütün.", "display_name": "Stability AI Büyütme Muhafazakar", "inputs": { "control_after_generate": { "name": "oluşturduktan sonra kontrol et" }, "creativity": { "name": "yaratıcılık", "tooltip": "Başlangıç görüntüsü tarafından yoğun bir şekilde koşullandırılmayan ek ayrıntılar oluşturma olasılığını kontrol eder." }, "image": { "name": "görüntü" }, "negative_prompt": { "name": "negatif_istem", "tooltip": "Çıktı görüntüsünde ne görmek istemediğinizin anahtar kelimeleri. Bu gelişmiş bir özelliktir." }, "prompt": { "name": "istem", "tooltip": "Çıktı görüntüsünde ne görmek istediğiniz. Öğeleri, renkleri ve konuları açıkça tanımlayan güçlü, açıklayıcı bir istem daha iyi sonuçlara yol açacaktır." }, "seed": { "name": "tohum", "tooltip": "Gürültüyü oluşturmak için kullanılan rastgele tohum." } }, "outputs": { "0": { "tooltip": null } } };
const StabilityUpscaleCreativeNode = { "description": "Görüntüyü minimum değişiklikle 4K çözünürlüğe büyütün.", "display_name": "Stability AI Büyütme Yaratıcı", "inputs": { "control_after_generate": { "name": "oluşturduktan sonra kontrol et" }, "creativity": { "name": "yaratıcılık", "tooltip": "Başlangıç görüntüsü tarafından yoğun bir şekilde koşullandırılmayan ek ayrıntılar oluşturma olasılığını kontrol eder." }, "image": { "name": "görüntü" }, "negative_prompt": { "name": "negatif_istem", "tooltip": "Çıktı görüntüsünde ne görmek istemediğinizin anahtar kelimeleri. Bu gelişmiş bir özelliktir." }, "prompt": { "name": "istem", "tooltip": "Çıktı görüntüsünde ne görmek istediğiniz. Öğeleri, renkleri ve konuları açıkça tanımlayan güçlü, açıklayıcı bir istem daha iyi sonuçlara yol açacaktır." }, "seed": { "name": "tohum", "tooltip": "Gürültüyü oluşturmak için kullanılan rastgele tohum." }, "style_preset": { "name": "stil_önayarı", "tooltip": "Oluşturulan görüntünün isteğe bağlı istenen stili." } }, "outputs": { "0": { "tooltip": null } } };
const StabilityUpscaleFastNode = { "description": "Stability API çağrısı aracılığıyla bir görüntüyü orijinal boyutunun 4 katına kadar hızlı bir şekilde büyütür; düşük kaliteli/sıkıştırılmış görüntüleri büyütmek için tasarlanmıştır.", "display_name": "Stability AI Hızlı Büyütme", "inputs": { "image": { "name": "görüntü" } }, "outputs": { "0": { "tooltip": null } } };
const StableCascade_EmptyLatentImage = { "display_name": "StabilKaskad_BoşGizliGörüntü", "inputs": { "batch_size": { "name": "toplu_boyut" }, "compression": { "name": "sıkıştırma" }, "height": { "name": "yükseklik" }, "width": { "name": "genişlik" } }, "outputs": { "0": { "name": "aşama_c", "tooltip": null }, "1": { "name": "aşama_b", "tooltip": null } } };
const StableCascade_StageB_Conditioning = { "display_name": "StabilKaskad_AşamaB_Koşullandırma", "inputs": { "conditioning": { "name": "koşullandırma" }, "stage_c": { "name": "aşama_c" } }, "outputs": { "0": { "tooltip": null } } };
const StableCascade_StageC_VAEEncode = { "display_name": "StabilKaskad_AşamaC_VAEKodlama", "inputs": { "compression": { "name": "sıkıştırma" }, "image": { "name": "görüntü" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "aşama_c", "tooltip": null }, "1": { "name": "aşama_b", "tooltip": null } } };
const StableCascade_SuperResolutionControlnet = { "display_name": "StabilKaskad_SüperÇözünürlükKontrolAğı", "inputs": { "image": { "name": "görüntü" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "kontrol_ağı_girişi", "tooltip": null }, "1": { "name": "aşama_c", "tooltip": null }, "2": { "name": "aşama_b", "tooltip": null } } };
const StableZero123_Conditioning = { "display_name": "StabilSıfır123_Koşullandırma", "inputs": { "azimuth": { "name": "azimut" }, "batch_size": { "name": "toplu_boyut" }, "clip_vision": { "name": "clip_görü" }, "elevation": { "name": "yükseklik" }, "height": { "name": "yükseklik" }, "init_image": { "name": "başlangıç_görüntüsü" }, "vae": { "name": "vae" }, "width": { "name": "genişlik" } }, "outputs": { "0": { "name": "pozitif", "tooltip": null }, "1": { "name": "negatif", "tooltip": null }, "2": { "name": "gizli", "tooltip": null } } };
const StableZero123_Conditioning_Batched = { "display_name": "StabilSıfır123_Koşullandırma_Toplu", "inputs": { "azimuth": { "name": "azimut" }, "azimuth_batch_increment": { "name": "azimut_toplu_artışı" }, "batch_size": { "name": "toplu_boyut" }, "clip_vision": { "name": "clip_görü" }, "elevation": { "name": "yükseklik" }, "elevation_batch_increment": { "name": "yükseklik_toplu_artışı" }, "height": { "name": "yükseklik" }, "init_image": { "name": "başlangıç_görüntüsü" }, "vae": { "name": "vae" }, "width": { "name": "genişlik" } }, "outputs": { "0": { "name": "pozitif", "tooltip": null }, "1": { "name": "negatif", "tooltip": null }, "2": { "name": "gizli", "tooltip": null } } };
const StringCompare = { "display_name": "Karşılaştır", "inputs": { "case_sensitive": { "name": "büyük/küçük harf duyarlı" }, "mode": { "name": "mod" }, "string_a": { "name": "dize_a" }, "string_b": { "name": "dize_b" } }, "outputs": { "0": { "tooltip": null } } };
const StringConcatenate = { "display_name": "Birleştir", "inputs": { "delimiter": { "name": "ayraç" }, "string_a": { "name": "dize_a" }, "string_b": { "name": "dize_b" } }, "outputs": { "0": { "tooltip": null } } };
const StringContains = { "display_name": "İçerir", "inputs": { "case_sensitive": { "name": "büyük/küçük harf duyarlı" }, "string": { "name": "dize" }, "substring": { "name": "alt_dize" } }, "outputs": { "0": { "name": "içerir", "tooltip": null } } };
const StringLength = { "display_name": "Uzunluk", "inputs": { "string": { "name": "dize" } }, "outputs": { "0": { "name": "uzunluk", "tooltip": null } } };
const StringReplace = { "display_name": "Değiştir", "inputs": { "find": { "name": "bul" }, "replace": { "name": "değiştir" }, "string": { "name": "dize" } }, "outputs": { "0": { "tooltip": null } } };
const StringSubstring = { "display_name": "Alt Dize", "inputs": { "end": { "name": "bitiş" }, "start": { "name": "başlangıç" }, "string": { "name": "dize" } }, "outputs": { "0": { "tooltip": null } } };
const StringTrim = { "display_name": "Kırp", "inputs": { "mode": { "name": "mod" }, "string": { "name": "dize" } }, "outputs": { "0": { "tooltip": null } } };
const StyleModelApply = { "display_name": "Stil Modeli Uygula", "inputs": { "clip_vision_output": { "name": "clip_görü_çıktısı" }, "conditioning": { "name": "koşullandırma" }, "strength": { "name": "güç" }, "strength_type": { "name": "güç_türü" }, "style_model": { "name": "stil_modeli" } } };
const StyleModelLoader = { "display_name": "Stil Modeli Yükle", "inputs": { "style_model_name": { "name": "stil_modeli_adı" } } };
const T5TokenizerOptions = { "display_name": "T5JetonlaştırıcıSeçenekleri", "inputs": { "clip": { "name": "clip" }, "min_length": { "name": "min_uzunluk" }, "min_padding": { "name": "min_dolgu" } }, "outputs": { "0": { "tooltip": null } } };
const TCFG = { "description": "TCFG – Teğetsel Sönümleme CFG (2503.18137)\n\nKaliteyi iyileştirmek için koşulsuz (negatif) ifadeyi koşullu (pozitif) ifadeyle hizalamak için rafine eder.", "display_name": "Teğetsel Sönümleme CFG", "inputs": { "model": { "name": "model" } }, "outputs": { "0": { "name": "yama_uygulanmış_model", "tooltip": null } } };
const TemporalScoreRescaling = { "description": "[CFG Sonrası İşlev]\nTSR - Zamansal Skor Yeniden Ölçeklendirme (2510.01184)\n\nÖrnekleme çeşitliliğini yönlendirmek için modelin skorunu veya gürültüsünü yeniden ölçeklendirir.", "display_name": "TSR - Zamansal Skor Yeniden Ölçeklendirme", "inputs": { "model": { "name": "model" }, "tsr_k": { "name": "tsr_k", "tooltip": "Yeniden ölçeklendirme gücünü kontrol eder.\nDaha düşük k değeri daha detaylı sonuçlar üretir; daha yüksek k değeri görüntü oluşturmada daha pürüzsüz sonuçlar üretir. k = 1 ayarı yeniden ölçeklendirmeyi devre dışı bırakır." }, "tsr_sigma": { "name": "tsr_sigma", "tooltip": "Yeniden ölçeklendirmenin ne zaman etkili olacağını kontrol eder.\nDaha büyük değerler daha erken etkili olur." } }, "outputs": { "0": { "name": "yama_uygulanmış_model", "tooltip": null } } };
const TextEncodeAceStepAudio = { "display_name": "TextEncodeAceStepAudio", "inputs": { "clip": { "name": "clip" }, "lyrics": { "name": "şarkı_sözleri" }, "lyrics_strength": { "name": "şarkı_sözleri_gücü" }, "tags": { "name": "etiketler" } }, "outputs": { "0": { "tooltip": null } } };
const TextEncodeHunyuanVideo_ImageToVideo = { "display_name": "MetinKodlamaHunyuanVideo_GörüntüdenVideoya", "inputs": { "clip": { "name": "clip" }, "clip_vision_output": { "name": "clip_görü_çıktısı" }, "image_interleave": { "name": "görüntü_serpiştirme", "tooltip": "Görüntünün metin istemine karşı ne kadar etkili olduğu. Daha yüksek sayı, metin isteminden daha fazla etki anlamına gelir." }, "prompt": { "name": "istem" } }, "outputs": { "0": { "tooltip": null } } };
const TextEncodeQwenImageEdit = { "display_name": "TextEncodeQwenImageEdit", "inputs": { "clip": { "name": "clip" }, "image": { "name": "görüntü" }, "prompt": { "name": "prompt" }, "vae": { "name": "vae" } }, "outputs": { "0": { "tooltip": null } } };
const TextEncodeQwenImageEditPlus = { "display_name": "TextEncodeQwenImageEditPlus", "inputs": { "clip": { "name": "clip" }, "image1": { "name": "görüntü1" }, "image2": { "name": "görüntü2" }, "image3": { "name": "görüntü3" }, "prompt": { "name": "prompt" }, "vae": { "name": "vae" } }, "outputs": { "0": { "tooltip": null } } };
const ThresholdMask = { "display_name": "EşikMaskesi", "inputs": { "mask": { "name": "maske" }, "value": { "name": "değer" } } };
const TomePatchModel = { "display_name": "Tome Model Yaması", "inputs": { "model": { "name": "model" }, "ratio": { "name": "oran" } }, "outputs": { "0": { "tooltip": null } } };
const TorchCompileModel = { "display_name": "Torch Model Derleme", "inputs": { "backend": { "name": "arka_uç" }, "model": { "name": "model" } }, "outputs": { "0": { "tooltip": null } } };
const TrainLoraNode = { "display_name": "LoRA Eğit", "inputs": { "algorithm": { "name": "algoritma", "tooltip": "Eğitim için kullanılacak algoritma." }, "batch_size": { "name": "toplu_iş_boyutu", "tooltip": "Eğitim için kullanılacak toplu iş boyutu." }, "control_after_generate": { "name": "oluşturduktan sonra kontrol et" }, "existing_lora": { "name": "mevcut_lora", "tooltip": "Eklenecek mevcut LoRA. Yeni LoRA için Yok olarak ayarlayın." }, "grad_accumulation_steps": { "name": "gradyan_birikim_adımları", "tooltip": "Eğitim için kullanılacak gradyan birikim adımlarının sayısı." }, "gradient_checkpointing": { "name": "gradyan_kontrol_noktası", "tooltip": "Eğitim için gradyan kontrol noktası kullan." }, "latents": { "name": "latents", "tooltip": "Eğitim için kullanılacak gizli tensörler, modelin veri seti/girdisi olarak hizmet eder." }, "learning_rate": { "name": "öğrenme_oranı", "tooltip": "Eğitim için kullanılacak öğrenme oranı." }, "lora_dtype": { "name": "lora_veri_tipi", "tooltip": "LoRA için kullanılacak veri tipi." }, "loss_function": { "name": "kayıp_işlevi", "tooltip": "Eğitim için kullanılacak kayıp işlevi." }, "model": { "name": "model", "tooltip": "LoRA'nın eğitileceği model." }, "optimizer": { "name": "optimize_edici", "tooltip": "Eğitim için kullanılacak optimize edici." }, "positive": { "name": "pozitif", "tooltip": "Eğitim için kullanılacak pozitif koşullandırma." }, "rank": { "name": "rütbe", "tooltip": "LoRA katmanlarının rütbesi." }, "seed": { "name": "tohum", "tooltip": "Eğitim için kullanılacak tohum (LoRA ağırlık başlatma ve gürültü örnekleme için üreteçte kullanılır)" }, "steps": { "name": "adımlar", "tooltip": "LoRA'nın eğitileceği adım sayısı." }, "training_dtype": { "name": "eğitim_veri_tipi", "tooltip": "Eğitim için kullanılacak veri tipi." } }, "outputs": { "0": { "name": "lora_ile_model" }, "1": { "name": "lora" }, "2": { "name": "kayıp" }, "3": { "name": "adımlar" } } };
const TrimAudioDuration = { "description": "Ses tensörünü seçilen zaman aralığına kırp.", "display_name": "Ses Süresini Kırp", "inputs": { "audio": { "name": "ses" }, "duration": { "name": "süre", "tooltip": "Saniye cinsinden süre" }, "start_index": { "name": "başlangıç_indeksi", "tooltip": "Saniye cinsinden başlangıç zamanı, sondan saymak için negatif olabilir (saniyenin alt birimlerini destekler)." } } };
const TrimVideoLatent = { "display_name": "VideoGizliDeğişkeniniKırp", "inputs": { "samples": { "name": "örnekler" }, "trim_amount": { "name": "kırpma_miktarı" } }, "outputs": { "0": { "tooltip": null } } };
const TripleCLIPLoader = { "description": "[Tarifler]\n\nsd3: clip-l, clip-g, t5", "display_name": "ÜçlüCLIPYükleyici", "inputs": { "clip_name1": { "name": "clip_adı1" }, "clip_name2": { "name": "clip_adı2" }, "clip_name3": { "name": "clip_adı3" } }, "outputs": { "0": { "tooltip": null } } };
const TripoConversionNode = { "display_name": "Tripo: Modeli Dönüştür", "inputs": { "face_limit": { "name": "yüz_sınırı" }, "format": { "name": "biçim" }, "original_model_task_id": { "name": "orijinal_model_görev_id" }, "quad": { "name": "dörtlü" }, "texture_format": { "name": "doku_biçimi" }, "texture_size": { "name": "doku_boyutu" } } };
const TripoImageToModelNode = { "display_name": "Tripo: Görüntüden Modele", "inputs": { "face_limit": { "name": "yüz_sınırı" }, "image": { "name": "görüntü" }, "model_seed": { "name": "model_tohumu" }, "model_version": { "name": "model_sürümü", "tooltip": "Oluşturma için kullanılacak model sürümü" }, "orientation": { "name": "yönlendirme" }, "pbr": { "name": "pbr" }, "quad": { "name": "dörtlü" }, "style": { "name": "stil" }, "texture": { "name": "doku" }, "texture_alignment": { "name": "doku_hizalama" }, "texture_quality": { "name": "doku_kalitesi" }, "texture_seed": { "name": "doku_tohumu" } }, "outputs": { "0": { "name": "model_dosyası", "tooltip": null }, "1": { "name": "model görev_id", "tooltip": null } } };
const TripoMultiviewToModelNode = { "display_name": "Tripo: Çok Bakışlıdan Modele", "inputs": { "face_limit": { "name": "yüz_sınırı" }, "image": { "name": "görüntü" }, "image_back": { "name": "arka_görüntü" }, "image_left": { "name": "sol_görüntü" }, "image_right": { "name": "sağ_görüntü" }, "model_seed": { "name": "model_tohumu" }, "model_version": { "name": "model_versiyonu", "tooltip": "Oluşturma için kullanılacak model versiyonu" }, "orientation": { "name": "yönlendirme" }, "pbr": { "name": "pbr" }, "quad": { "name": "dörtgen" }, "texture": { "name": "doku" }, "texture_alignment": { "name": "doku_hizalama" }, "texture_quality": { "name": "doku_kalitesi" }, "texture_seed": { "name": "doku_tohumu" } }, "outputs": { "0": { "name": "model_dosyası", "tooltip": null }, "1": { "name": "model görev_id", "tooltip": null } } };
const TripoRefineNode = { "description": "Sadece v1.4 Tripo modelleri tarafından oluşturulan taslak bir modeli iyileştirir.", "display_name": "Tripo: Taslak Modeli İyileştir", "inputs": { "model_task_id": { "name": "model_görev_id", "tooltip": "Bir v1.4 Tripo modeli olmalı" } }, "outputs": { "0": { "name": "model_dosyası", "tooltip": null }, "1": { "name": "model görev_id", "tooltip": null } } };
const TripoRetargetNode = { "display_name": "Tripo: Riglenmiş Modeli Yeniden Hedefle", "inputs": { "animation": { "name": "animasyon" }, "original_model_task_id": { "name": "orijinal_model_görev_id" } }, "outputs": { "0": { "name": "model_dosyası", "tooltip": null }, "1": { "name": "yeniden_hedefleme görev_id", "tooltip": null } } };
const TripoRigNode = { "display_name": "Tripo: Modeli Rigle", "inputs": { "original_model_task_id": { "name": "orijinal_model_görev_id" } }, "outputs": { "0": { "name": "model_dosyası", "tooltip": null }, "1": { "name": "rigleme görev_id", "tooltip": null } } };
const TripoTextToModelNode = { "display_name": "Tripo: Metinden Modele", "inputs": { "face_limit": { "name": "yüz_sınırı" }, "image_seed": { "name": "görüntü_tohumu" }, "model_seed": { "name": "model_tohumu" }, "model_version": { "name": "model_versiyonu" }, "negative_prompt": { "name": "olumsuz_istek" }, "pbr": { "name": "pbr" }, "prompt": { "name": "istek" }, "quad": { "name": "dörtgen" }, "style": { "name": "stil" }, "texture": { "name": "doku" }, "texture_quality": { "name": "doku_kalitesi" }, "texture_seed": { "name": "doku_tohumu" } }, "outputs": { "0": { "name": "model_dosyası", "tooltip": null }, "1": { "name": "model görev_id", "tooltip": null } } };
const TripoTextureNode = { "display_name": "Tripo: Doku modeli", "inputs": { "model_task_id": { "name": "model_görev_id" }, "pbr": { "name": "pbr" }, "texture": { "name": "doku" }, "texture_alignment": { "name": "doku_hizalama" }, "texture_quality": { "name": "doku_kalitesi" }, "texture_seed": { "name": "doku_tohumu" } }, "outputs": { "0": { "name": "model_dosyası", "tooltip": null }, "1": { "name": "model görev_id", "tooltip": null } } };
const UNETLoader = { "display_name": "Difüzyon Modeli Yükle", "inputs": { "unet_name": { "name": "unet_adı" }, "weight_dtype": { "name": "ağırlık_veri_türü" } } };
const UNetCrossAttentionMultiply = { "display_name": "UNetÇaprazDikkatÇarpımı", "inputs": { "k": { "name": "k" }, "model": { "name": "model" }, "out": { "name": "çıktı" }, "q": { "name": "q" }, "v": { "name": "v" } }, "outputs": { "0": { "tooltip": null } } };
const UNetSelfAttentionMultiply = { "display_name": "UNetÖzDikkatÇarpımı", "inputs": { "k": { "name": "k" }, "model": { "name": "model" }, "out": { "name": "çıktı" }, "q": { "name": "q" }, "v": { "name": "v" } }, "outputs": { "0": { "tooltip": null } } };
const UNetTemporalAttentionMultiply = { "display_name": "UNetZamansalDikkatÇarpımı", "inputs": { "cross_structural": { "name": "çapraz_yapısal" }, "cross_temporal": { "name": "çapraz_zamansal" }, "model": { "name": "model" }, "self_structural": { "name": "öz_yapısal" }, "self_temporal": { "name": "öz_zamansal" } }, "outputs": { "0": { "tooltip": null } } };
const USOStyleReference = { "display_name": "USOTarzReferansı", "inputs": { "clip_vision_output": { "name": "clip_vision_çıktısı" }, "model": { "name": "model" }, "model_patch": { "name": "model_yama" } } };
const UpscaleModelLoader = { "display_name": "Büyütme Modeli Yükle", "inputs": { "model_name": { "name": "model_adı" } }, "outputs": { "0": { "tooltip": null } } };
const VAEDecode = { "description": "Gizli görüntüleri tekrar piksel uzayı görüntülerine çözer.", "display_name": "VAE Kod Çözme", "inputs": { "samples": { "name": "örnekler", "tooltip": "Kodunun çözüleceği gizli değişken." }, "vae": { "name": "vae", "tooltip": "Gizli değişkenin kodunu çözmek için kullanılan VAE modeli." } }, "outputs": { "0": { "tooltip": "Kodu çözülmüş görüntü." } } };
const VAEDecodeAudio = { "display_name": "VAESesKodunuÇöz", "inputs": { "samples": { "name": "örnekler" }, "vae": { "name": "vae" } } };
const VAEDecodeHunyuan3D = { "display_name": "VAEKodÇözmeHunyuan3D", "inputs": { "num_chunks": { "name": "parça_sayısı" }, "octree_resolution": { "name": "sekizli_ağaç_çözünürlüğü" }, "samples": { "name": "örnekler" }, "vae": { "name": "vae" } } };
const VAEDecodeTiled = { "display_name": "VAE Kod Çözme (Döşemeli)", "inputs": { "overlap": { "name": "örtüşme" }, "samples": { "name": "örnekler" }, "temporal_overlap": { "name": "zamansal_örtüşme", "tooltip": "Yalnızca video VAE'leri için kullanılır: Örtüşecek kare sayısı." }, "temporal_size": { "name": "zamansal_boyut", "tooltip": "Yalnızca video VAE'leri için kullanılır: Bir seferde kodu çözülecek kare sayısı." }, "tile_size": { "name": "döşeme_boyutu" }, "vae": { "name": "vae" } } };
const VAEEncode = { "display_name": "VAE Kodlama", "inputs": { "pixels": { "name": "pikseller" }, "vae": { "name": "vae" } } };
const VAEEncodeAudio = { "display_name": "VAESesKodla", "inputs": { "audio": { "name": "ses" }, "vae": { "name": "vae" } } };
const VAEEncodeForInpaint = { "display_name": "VAE Kodlama (İç Boyama için)", "inputs": { "grow_mask_by": { "name": "maskeyi_büyüt" }, "mask": { "name": "maske" }, "pixels": { "name": "pikseller" }, "vae": { "name": "vae" } } };
const VAEEncodeTiled = { "display_name": "VAE Kodlama (Döşemeli)", "inputs": { "overlap": { "name": "örtüşme" }, "pixels": { "name": "pikseller" }, "temporal_overlap": { "name": "zamansal_örtüşme", "tooltip": "Yalnızca video VAE'leri için kullanılır: Örtüşecek kare sayısı." }, "temporal_size": { "name": "zamansal_boyut", "tooltip": "Yalnızca video VAE'leri için kullanılır: Bir seferde kodlanacak kare sayısı." }, "tile_size": { "name": "döşeme_boyutu" }, "vae": { "name": "vae" } } };
const VAELoader = { "display_name": "VAE Yükle", "inputs": { "vae_name": { "name": "vae_adı" } } };
const VAESave = { "display_name": "VAEKaydet", "inputs": { "filename_prefix": { "name": "dosyaadı_öneki" }, "vae": { "name": "vae" } } };
const VPScheduler = { "display_name": "VPZamanlayıcı", "inputs": { "beta_d": { "name": "beta_d" }, "beta_min": { "name": "beta_min" }, "eps_s": { "name": "eps_s" }, "steps": { "name": "adımlar" } } };
const Veo3VideoGenerationNode = { "description": "Google'ın Veo 3 API'sini kullanarak metin istemlerinden video oluşturur", "display_name": "Google Veo 3 Video Oluşturma", "inputs": { "aspect_ratio": { "name": "en_boy_oranı", "tooltip": "Çıktı videosunun en boy oranı" }, "control_after_generate": { "name": "oluşturma sonrası kontrol" }, "duration_seconds": { "name": "süre_saniye", "tooltip": "Çıktı videosunun saniye cinsinden süresi (Veo 3 yalnızca 8 saniyeyi destekler)" }, "enhance_prompt": { "name": "istem_geliştir", "tooltip": "İstemin AI yardımıyla geliştirilip geliştirilmeyeceği" }, "generate_audio": { "name": "ses_oluştur", "tooltip": "Video için ses oluştur. Tüm Veo 3 modelleri tarafından desteklenir." }, "image": { "name": "görsel", "tooltip": "Video oluşturmayı yönlendirmek için isteğe bağlı referans görsel" }, "model": { "name": "model", "tooltip": "Video oluşturma için kullanılacak Veo 3 modeli" }, "negative_prompt": { "name": "negatif_istem", "tooltip": "Videoda nelerden kaçınılacağını yönlendiren negatif metin istemi" }, "person_generation": { "name": "kişi_oluşturma", "tooltip": "Videoda insan oluşturmanın izin verilip verilmeyeceği" }, "prompt": { "name": "istem", "tooltip": "Videonun metin açıklaması" }, "seed": { "name": "tohum", "tooltip": "Video oluşturma için tohum (rastgele için 0)" } }, "outputs": { "0": { "tooltip": null } } };
const VeoVideoGenerationNode = { "description": "Google'ın Veo API'sini kullanarak metin istemlerinden videolar oluşturur", "display_name": "Google Veo2 Video Oluşturma", "inputs": { "aspect_ratio": { "name": "en_boy_oranı", "tooltip": "Çıktı videosunun en boy oranı" }, "control_after_generate": { "name": "oluşturduktan sonra kontrol et" }, "duration_seconds": { "name": "süre_saniye", "tooltip": "Çıktı videosunun saniye cinsinden süresi" }, "enhance_prompt": { "name": "istemi_geliştir", "tooltip": "İstemi yapay zeka yardımıyla geliştirip geliştirmeme" }, "image": { "name": "görüntü", "tooltip": "Video oluşturmayı yönlendirmek için isteğe bağlı referans görüntü" }, "model": { "name": "model", "tooltip": "Video oluşturma için kullanılacak Veo 2 modeli" }, "negative_prompt": { "name": "negatif_istem", "tooltip": "Videoda kaçınılması gerekenleri yönlendirmek için negatif metin istemi" }, "person_generation": { "name": "kişi_oluşturma", "tooltip": "Videoda insan oluşturmaya izin verip vermeme" }, "prompt": { "name": "istem", "tooltip": "Videonun metin açıklaması" }, "seed": { "name": "tohum", "tooltip": "Video oluşturma için tohum (rastgele için 0)" } }, "outputs": { "0": { "tooltip": null } } };
const VideoLinearCFGGuidance = { "display_name": "VideoDoğrusalCFGRehberliği", "inputs": { "min_cfg": { "name": "min_cfg" }, "model": { "name": "model" } } };
const VideoTriangleCFGGuidance = { "display_name": "VideoÜçgenCFGRehberliği", "inputs": { "min_cfg": { "name": "min_cfg" }, "model": { "name": "model" } } };
const ViduImageToVideoNode = { "description": "Görsel ve isteğe bağlı prompt'tan video oluştur", "display_name": "Vidu Görselden Video Oluşturma", "inputs": { "control_after_generate": { "name": "oluşturma sonrası kontrol" }, "duration": { "name": "süre", "tooltip": "Çıktı videosunun saniye cinsinden süresi" }, "image": { "name": "görsel", "tooltip": "Oluşturulan videonun başlangıç karesi olarak kullanılacak bir görsel" }, "model": { "name": "model", "tooltip": "Model adı" }, "movement_amplitude": { "name": "hareket_genliği", "tooltip": "Karedeki nesnelerin hareket genliği" }, "prompt": { "name": "prompt", "tooltip": "Video oluşturma için metinsel açıklama" }, "resolution": { "name": "çözünürlük", "tooltip": "Desteklenen değerler modele ve süreye göre değişebilir" }, "seed": { "name": "tohum", "tooltip": "Video oluşturma için tohum (rastgele için 0)" } }, "outputs": { "0": { "tooltip": null } } };
const ViduReferenceVideoNode = { "description": "Birden fazla görsel ve prompt'tan video oluştur", "display_name": "Vidu Referanstan Video Oluşturma", "inputs": { "aspect_ratio": { "name": "en-boy oranı", "tooltip": "Çıktı videosunun en-boy oranı" }, "control_after_generate": { "name": "oluşturma sonrası kontrol" }, "duration": { "name": "süre", "tooltip": "Çıktı videosunun saniye cinsinden süresi" }, "images": { "name": "görseller", "tooltip": "Tutarlı öznelerle video oluşturmak için referans olarak kullanılacak görseller (maksimum 7 görsel)." }, "model": { "name": "model", "tooltip": "Model adı" }, "movement_amplitude": { "name": "hareket genliği", "tooltip": "Kare içindeki nesnelerin hareket genliği" }, "prompt": { "name": "prompt", "tooltip": "Video oluşturma için metinsel açıklama" }, "resolution": { "name": "çözünürlük", "tooltip": "Desteklenen değerler modele ve süreye göre değişebilir" }, "seed": { "name": "tohum", "tooltip": "Video oluşturma için tohum değeri (rastgele için 0)" } }, "outputs": { "0": { "tooltip": null } } };
const ViduStartEndToVideoNode = { "description": "Başlangıç ve bitiş karelerinden ve bir istemden video oluştur", "display_name": "Vidu Başlangıç Bitiş ile Video Oluşturma", "inputs": { "control_after_generate": { "name": "oluşturma sonrası kontrol" }, "duration": { "name": "süre", "tooltip": "Çıktı videosunun saniye cinsinden süresi" }, "end_frame": { "name": "bitiş_karesi", "tooltip": "Bitiş karesi" }, "first_frame": { "name": "ilk_kare", "tooltip": "Başlangıç karesi" }, "model": { "name": "model", "tooltip": "Model adı" }, "movement_amplitude": { "name": "hareket genliği", "tooltip": "Kare içindeki nesnelerin hareket genliği" }, "prompt": { "name": "istem", "tooltip": "Video oluşturma için metinsel açıklama" }, "resolution": { "name": "çözünürlük", "tooltip": "Desteklenen değerler modele ve süreye göre değişebilir" }, "seed": { "name": "tohum", "tooltip": "Video oluşturma için tohum değeri (rastgele için 0)" } }, "outputs": { "0": { "tooltip": null } } };
const ViduTextToVideoNode = { "description": "Metin isteminden video oluştur", "display_name": "Vidu Metinden Video Oluşturma", "inputs": { "aspect_ratio": { "name": "aspect_ratio", "tooltip": "Çıktı videosunun en-boy oranı" }, "control_after_generate": { "name": "control after generate" }, "duration": { "name": "duration", "tooltip": "Çıktı videosunun saniye cinsinden süresi" }, "model": { "name": "model", "tooltip": "Model adı" }, "movement_amplitude": { "name": "movement_amplitude", "tooltip": "Karedeki nesnelerin hareket genliği" }, "prompt": { "name": "prompt", "tooltip": "Video oluşturma için metinsel açıklama" }, "resolution": { "name": "resolution", "tooltip": "Desteklenen değerler modele ve süreye göre değişebilir" }, "seed": { "name": "seed", "tooltip": "Video oluşturma için tohum değeri (0 rastgele)" } }, "outputs": { "0": { "tooltip": null } } };
const VoxelToMesh = { "display_name": "VokseldenAğa", "inputs": { "algorithm": { "name": "algoritma" }, "threshold": { "name": "eşik" }, "voxel": { "name": "voksel" } } };
const VoxelToMeshBasic = { "display_name": "TemelVokseldenAğa", "inputs": { "threshold": { "name": "eşik" }, "voxel": { "name": "voksel" } } };
const Wan22FunControlToVideo = { "display_name": "Wan22FunControlToVideo", "inputs": { "batch_size": { "name": "batch_size" }, "control_video": { "name": "control_video" }, "height": { "name": "height" }, "length": { "name": "length" }, "negative": { "name": "negative" }, "positive": { "name": "positive" }, "ref_image": { "name": "ref_image" }, "vae": { "name": "vae" }, "width": { "name": "width" } }, "outputs": { "0": { "name": "positive", "tooltip": null }, "1": { "name": "negative", "tooltip": null }, "2": { "name": "latent", "tooltip": null } } };
const Wan22ImageToVideoLatent = { "display_name": "Wan22ImageToVideoLatent", "inputs": { "batch_size": { "name": "batch_size" }, "height": { "name": "height" }, "length": { "name": "length" }, "start_image": { "name": "start_image" }, "vae": { "name": "vae" }, "width": { "name": "width" } }, "outputs": { "0": { "tooltip": null } } };
const WanAnimateToVideo = { "display_name": "WanAnimateToVideo", "inputs": { "background_video": { "name": "arka_plan_videosu" }, "batch_size": { "name": "toplu_iş_boyutu" }, "character_mask": { "name": "karakter_maskesi" }, "clip_vision_output": { "name": "clip_vision_çıkışı" }, "continue_motion": { "name": "devam_eden_hareket" }, "continue_motion_max_frames": { "name": "devam_eden_hareket_maksimum_kare_sayısı" }, "face_video": { "name": "yüz_videosu" }, "height": { "name": "yükseklik" }, "length": { "name": "uzunluk" }, "negative": { "name": "negatif" }, "pose_video": { "name": "poz_videosu" }, "positive": { "name": "positive" }, "reference_image": { "name": "referans_görsel" }, "vae": { "name": "vae" }, "video_frame_offset": { "name": "video_kare_konumu", "tooltip": "Tüm giriş videolarında atlanacak kare miktarı. Videoyu parçalar halinde uzatmak için kullanılır. Bir videoyu genişletmek için önceki düğümün video_kare_konumu çıkışına bağlayın." }, "width": { "name": "genişlik" } }, "outputs": { "0": { "name": "pozitif", "tooltip": null }, "1": { "name": "negatif", "tooltip": null }, "2": { "name": "gizli_uzay", "tooltip": null }, "3": { "name": "kırpılmış_gizli_uzay", "tooltip": null }, "4": { "name": "kırpılmış_görsel", "tooltip": null }, "5": { "name": "video_kare_konumu", "tooltip": null } } };
const WanCameraEmbedding = { "display_name": "WanKameraYerleştirme", "inputs": { "camera_pose": { "name": "kamera_pozisyonu" }, "cx": { "name": "cx" }, "cy": { "name": "cy" }, "fx": { "name": "fx" }, "fy": { "name": "fy" }, "height": { "name": "yükseklik" }, "length": { "name": "uzunluk" }, "speed": { "name": "hız" }, "width": { "name": "genişlik" } }, "outputs": { "0": { "name": "kamera_yerleştirme", "tooltip": null }, "1": { "name": "genişlik", "tooltip": null }, "2": { "name": "yükseklik", "tooltip": null }, "3": { "name": "uzunluk", "tooltip": null } } };
const WanCameraImageToVideo = { "display_name": "WanKameraGörüntüdenVideoya", "inputs": { "batch_size": { "name": "toplu_iş_boyutu" }, "camera_conditions": { "name": "kamera_koşulları" }, "clip_vision_output": { "name": "clip_vision_çıktısı" }, "height": { "name": "yükseklik" }, "length": { "name": "uzunluk" }, "negative": { "name": "negatif" }, "positive": { "name": "pozitif" }, "start_image": { "name": "başlangıç_görüntüsü" }, "vae": { "name": "vae" }, "width": { "name": "genişlik" } }, "outputs": { "0": { "name": "pozitif", "tooltip": null }, "1": { "name": "negatif", "tooltip": null }, "2": { "name": "latent", "tooltip": null } } };
const WanContextWindowsManual = { "description": "WAN benzeri modeller için bağlam pencerelerini manuel olarak ayarlayın (dim=2).", "display_name": "WAN Bağlam Pencereleri (Manuel)", "inputs": { "closed_loop": { "name": "kapalı_döngü", "tooltip": "Bağlam penceresi döngüsünün kapatılıp kapatılmayacağı; sadece döngülü çizelgeler için geçerlidir." }, "context_length": { "name": "bağlam_uzunluğu", "tooltip": "Bağlam penceresinin uzunluğu." }, "context_overlap": { "name": "bağlam_örtüşmesi", "tooltip": "Bağlam penceresinin örtüşme miktarı." }, "context_schedule": { "name": "bağlam_çizelgesi", "tooltip": "Bağlam penceresinin adım aralığı." }, "context_stride": { "name": "bağlam_adımı", "tooltip": "Bağlam penceresinin adım aralığı; sadece düzenli çizelgeler için geçerlidir." }, "fuse_method": { "name": "birleştirme_yöntemi", "tooltip": "Bağlam pencerelerini birleştirmek için kullanılacak yöntem." }, "model": { "name": "model", "tooltip": "Örnekleme sırasında bağlam pencerelerinin uygulanacağı model." } }, "outputs": { "0": { "tooltip": "Örnekleme sırasında bağlam pencereleri uygulanmış model." } } };
const WanFirstLastFrameToVideo = { "display_name": "WanİlkSonKaredenVideoya", "inputs": { "batch_size": { "name": "toplu_boyut" }, "clip_vision_end_image": { "name": "clip_görü_bitiş_görüntüsü" }, "clip_vision_start_image": { "name": "clip_görü_başlangıç_görüntüsü" }, "end_image": { "name": "bitiş_görüntüsü" }, "height": { "name": "yükseklik" }, "length": { "name": "uzunluk" }, "negative": { "name": "negatif" }, "positive": { "name": "pozitif" }, "start_image": { "name": "başlangıç_görüntüsü" }, "vae": { "name": "vae" }, "width": { "name": "genişlik" } }, "outputs": { "0": { "name": "pozitif", "tooltip": null }, "1": { "name": "negatif", "tooltip": null }, "2": { "name": "gizli", "tooltip": null } } };
const WanFunControlToVideo = { "display_name": "WanEğlenceKontroldenVideoya", "inputs": { "batch_size": { "name": "toplu_boyut" }, "clip_vision_output": { "name": "clip_görü_çıktısı" }, "control_video": { "name": "kontrol_videosu" }, "height": { "name": "yükseklik" }, "length": { "name": "uzunluk" }, "negative": { "name": "negatif" }, "positive": { "name": "pozitif" }, "start_image": { "name": "başlangıç_görüntüsü" }, "vae": { "name": "vae" }, "width": { "name": "genişlik" } }, "outputs": { "0": { "name": "pozitif", "tooltip": null }, "1": { "name": "negatif", "tooltip": null }, "2": { "name": "gizli", "tooltip": null } } };
const WanFunInpaintToVideo = { "display_name": "WanEğlenceİçBoyamadanVideoya", "inputs": { "batch_size": { "name": "toplu_boyut" }, "clip_vision_output": { "name": "clip_görü_çıktısı" }, "end_image": { "name": "bitiş_görüntüsü" }, "height": { "name": "yükseklik" }, "length": { "name": "uzunluk" }, "negative": { "name": "negatif" }, "positive": { "name": "pozitif" }, "start_image": { "name": "başlangıç_görüntüsü" }, "vae": { "name": "vae" }, "width": { "name": "genişlik" } }, "outputs": { "0": { "name": "pozitif", "tooltip": null }, "1": { "name": "negatif", "tooltip": null }, "2": { "name": "gizli", "tooltip": null } } };
const WanHuMoImageToVideo = { "display_name": "WanHuMoGörüntüdenVideoya", "inputs": { "audio_encoder_output": { "name": "ses_kodlayıcı_çıktısı" }, "batch_size": { "name": "toplu_iş_boyutu" }, "height": { "name": "yükseklik" }, "length": { "name": "uzunluk" }, "negative": { "name": "negatif" }, "positive": { "name": "pozitif" }, "ref_image": { "name": "referans_görsel" }, "vae": { "name": "vae" }, "width": { "name": "genişlik" } }, "outputs": { "0": { "name": "pozitif", "tooltip": null }, "1": { "name": "negatif", "tooltip": null }, "2": { "name": "gizli_uzay", "tooltip": null } } };
const WanImageToImageApi = { "description": "Bir veya iki giriş görselinden ve bir metin isteminden görsel oluşturur. Çıktı görseli şu anda 1,6 MP olarak sabittir; en-boy oranı giriş görsel(ler)ine uyum sağlar.", "display_name": "Wan Görselden Görsele", "inputs": { "control_after_generate": { "name": "oluşturma sonrası kontrol" }, "image": { "name": "görsel", "tooltip": "Tek görsel düzenleme veya çoklu görsel birleştirme, maksimum 2 görsel." }, "model": { "name": "model", "tooltip": "Kullanılacak model." }, "negative_prompt": { "name": "negatif_istem", "tooltip": "Nelerden kaçınılacağını yönlendirmek için kullanılan negatif metin istemi." }, "prompt": { "name": "istem", "tooltip": "Öğeleri ve görsel özellikleri tanımlamak için kullanılan istem, İngilizce/Çince destekler." }, "seed": { "name": "tohum", "tooltip": "Oluşturma için kullanılacak tohum değeri." }, "watermark": { "name": "filigran", "tooltip": 'Sonuca "Yapay zeka tarafından oluşturulmuştur" filigranı eklenip eklenmeyeceği.' } }, "outputs": { "0": { "tooltip": null } } };
const WanImageToVideo = { "display_name": "WanGörüntüdenVideoya", "inputs": { "batch_size": { "name": "toplu_boyut" }, "clip_vision_output": { "name": "clip_görü_çıktısı" }, "height": { "name": "yükseklik" }, "length": { "name": "uzunluk" }, "negative": { "name": "negatif" }, "positive": { "name": "pozitif" }, "start_image": { "name": "başlangıç_görüntüsü" }, "vae": { "name": "vae" }, "width": { "name": "genişlik" } }, "outputs": { "0": { "name": "pozitif", "tooltip": null }, "1": { "name": "negatif", "tooltip": null }, "2": { "name": "gizli", "tooltip": null } } };
const WanImageToVideoApi = { "description": "İlk kare ve metin istemine dayalı olarak video oluşturur.", "display_name": "Wan Görselden Videoya", "inputs": { "audio": { "name": "ses", "tooltip": "Ses, net, yüksek sesli bir konuşma içermeli, fazla gürültü ve arka plan müziği olmamalıdır." }, "control_after_generate": { "name": "oluşturma sonrası kontrol" }, "duration": { "name": "süre", "tooltip": "Mevcut süreler: 5 ve 10 saniye" }, "generate_audio": { "name": "ses_oluştur", "tooltip": "Eğer ses girişi yoksa, otomatik olarak ses oluştur." }, "image": { "name": "görsel" }, "model": { "name": "model", "tooltip": "Kullanılacak model." }, "negative_prompt": { "name": "negatif_istem", "tooltip": "Nelerden kaçınılacağını yönlendirmek için kullanılan negatif metin istemi." }, "prompt": { "name": "istem", "tooltip": "Öğeleri ve görsel özellikleri tanımlamak için kullanılan istem, İngilizce/Çince destekler." }, "prompt_extend": { "name": "prompt_genişlet", "tooltip": "İstemcinin AI yardımıyla geliştirilip geliştirilmeyeceği." }, "resolution": { "name": "çözünürlük" }, "seed": { "name": "tohum", "tooltip": "Oluşturma için kullanılacak tohum değeri." }, "watermark": { "name": "filigran", "tooltip": 'Sonuca "AI tarafından oluşturulmuştur" filigranı eklenip eklenmeyeceği.' } }, "outputs": { "0": { "tooltip": null } } };
const WanPhantomSubjectToVideo = { "display_name": "WanPhantomSubjectToVideo", "inputs": { "batch_size": { "name": "toplu_iş_boyutu" }, "height": { "name": "yükseklik" }, "images": { "name": "görseller" }, "length": { "name": "uzunluk" }, "negative": { "name": "negatif" }, "positive": { "name": "pozitif" }, "vae": { "name": "vae" }, "width": { "name": "genişlik" } }, "outputs": { "0": { "name": "pozitif", "tooltip": null }, "1": { "name": "negatif_metin", "tooltip": null }, "2": { "name": "negatif_img_metin", "tooltip": null }, "3": { "name": "gizli", "tooltip": null } } };
const WanSoundImageToVideo = { "display_name": "WanSoundImageToVideo", "inputs": { "audio_encoder_output": { "name": "ses_kodlayıcı_çıktısı" }, "batch_size": { "name": "toplu_iş_boyutu" }, "control_video": { "name": "control_video" }, "height": { "name": "yükseklik" }, "length": { "name": "uzunluk" }, "negative": { "name": "negatif" }, "positive": { "name": "pozitif" }, "ref_image": { "name": "ref_image" }, "ref_motion": { "name": "ref_motion" }, "vae": { "name": "vae" }, "width": { "name": "genişlik" } }, "outputs": { "0": { "name": "positive", "tooltip": null }, "1": { "name": "negative", "tooltip": null }, "2": { "name": "latent", "tooltip": null } } };
const WanSoundImageToVideoExtend = { "display_name": "WanSoundImageToVideoExtend", "inputs": { "audio_encoder_output": { "name": "audio_encoder_output" }, "control_video": { "name": "control_video" }, "length": { "name": "length" }, "negative": { "name": "negative" }, "positive": { "name": "positive" }, "ref_image": { "name": "ref_image" }, "vae": { "name": "vae" }, "video_latent": { "name": "video_latent" } }, "outputs": { "0": { "name": "positive", "tooltip": null }, "1": { "name": "negative", "tooltip": null }, "2": { "name": "latent", "tooltip": null } } };
const WanTextToImageApi = { "description": "Metin istemine dayalı görsel oluşturur.", "display_name": "Wan Metinden Görsele", "inputs": { "control_after_generate": { "name": "control after generate" }, "height": { "name": "height" }, "model": { "name": "model", "tooltip": "Kullanılacak model." }, "negative_prompt": { "name": "negative_prompt", "tooltip": "Nelerden kaçınılacağını yönlendirmek için negatif metin istemi." }, "prompt": { "name": "prompt", "tooltip": "Öğeleri ve görsel özellikleri tanımlamak için kullanılan istem, İngilizce/Çince destekler." }, "prompt_extend": { "name": "prompt_extend", "tooltip": "İstemin AI yardımıyla geliştirilip geliştirilmeyeceği." }, "seed": { "name": "seed", "tooltip": "Oluşturma için kullanılacak seed değeri." }, "watermark": { "name": "watermark", "tooltip": 'Sonuca "AI tarafından oluşturulmuştur" filigranı eklenip eklenmeyeceği.' }, "width": { "name": "width" } }, "outputs": { "0": { "tooltip": null } } };
const WanTextToVideoApi = { "description": "Metin istemine dayalı video oluşturur.", "display_name": "Wan Metinden Videoya", "inputs": { "audio": { "name": "audio", "tooltip": "Ses, dış gürültü ve arka plan müziği olmadan net, yüksek sesli bir ses içermelidir." }, "control_after_generate": { "name": "control after generate" }, "duration": { "name": "duration", "tooltip": "Mevcut süreler: 5 ve 10 saniye" }, "generate_audio": { "name": "generate_audio", "tooltip": "Eğer ses girişi yoksa, otomatik olarak ses oluştur." }, "model": { "name": "model", "tooltip": "Kullanılacak model." }, "negative_prompt": { "name": "negative_prompt", "tooltip": "Nelerden kaçınılacağını yönlendirmek için negatif metin istemi." }, "prompt": { "name": "prompt", "tooltip": "Öğeleri ve görsel özellikleri tanımlamak için kullanılan istem, İngilizce/Çince destekler." }, "prompt_extend": { "name": "prompt_extend", "tooltip": "İstemi AI yardımıyla geliştirip geliştirmeyeceği." }, "seed": { "name": "seed", "tooltip": "Oluşturma için kullanılacak seed değeri." }, "size": { "name": "size" }, "watermark": { "name": "watermark", "tooltip": 'Sonuca "AI tarafından oluşturuldu" filigranı eklenip eklenmeyeceği.' } }, "outputs": { "0": { "tooltip": null } } };
const WanTrackToVideo = { "display_name": "WanTrackToVideo", "inputs": { "batch_size": { "name": "batch_size" }, "clip_vision_output": { "name": "clip_vision_output" }, "height": { "name": "height" }, "length": { "name": "length" }, "negative": { "name": "negative" }, "positive": { "name": "positive" }, "start_image": { "name": "start_image" }, "temperature": { "name": "temperature" }, "topk": { "name": "topk" }, "tracks": { "name": "tracks" }, "vae": { "name": "vae" }, "width": { "name": "width" } }, "outputs": { "0": { "name": "pozitif", "tooltip": null }, "1": { "name": "negatif", "tooltip": null }, "2": { "name": "latent", "tooltip": null } } };
const WanVaceToVideo = { "display_name": "WanVace'denVideoya", "inputs": { "batch_size": { "name": "toplu_boyut" }, "control_masks": { "name": "kontrol_maskeleri" }, "control_video": { "name": "kontrol_videosu" }, "height": { "name": "yükseklik" }, "length": { "name": "uzunluk" }, "negative": { "name": "negatif" }, "positive": { "name": "pozitif" }, "reference_image": { "name": "referans_görüntüsü" }, "strength": { "name": "güç" }, "vae": { "name": "vae" }, "width": { "name": "genişlik" } }, "outputs": { "0": { "name": "pozitif", "tooltip": null }, "1": { "name": "negatif", "tooltip": null }, "2": { "name": "gizli", "tooltip": null }, "3": { "name": "gizliyi_kırp", "tooltip": null } } };
const WebcamCapture = { "display_name": "Webcam Yakalama", "inputs": { "capture_on_queue": { "name": "kuyrukta_yakala" }, "height": { "name": "yükseklik" }, "image": { "name": "görüntü" }, "waiting for camera___": {}, "width": { "name": "genişlik" } } };
const unCLIPCheckpointLoader = { "display_name": "unCLIPKontrolNoktasıYükleyici", "inputs": { "ckpt_name": { "name": "ckpt_adı" } } };
const unCLIPConditioning = { "display_name": "unCLIPKoşullandırma", "inputs": { "clip_vision_output": { "name": "clip_görü_çıktısı" }, "conditioning": { "name": "koşullandırma" }, "noise_augmentation": { "name": "gürültü_artırımı" }, "strength": { "name": "güç" } } };
const nodeDefs = {
  APG,
  AddNoise,
  AlignYourStepsScheduler,
  AudioAdjustVolume,
  AudioConcat,
  AudioEncoderEncode,
  AudioEncoderLoader,
  AudioMerge,
  BasicGuider,
  BasicScheduler,
  BetaSamplingScheduler,
  ByteDanceFirstLastFrameNode,
  ByteDanceImageEditNode,
  ByteDanceImageNode,
  ByteDanceImageReferenceNode,
  ByteDanceImageToVideoNode,
  ByteDanceSeedreamNode,
  ByteDanceTextToVideoNode,
  CFGGuider,
  CFGNorm,
  CFGZeroStar,
  CLIPAttentionMultiply,
  CLIPLoader,
  CLIPMergeAdd,
  CLIPMergeSimple,
  CLIPMergeSubtract,
  CLIPSave,
  CLIPSetLastLayer,
  CLIPTextEncode,
  CLIPTextEncodeControlnet,
  CLIPTextEncodeFlux,
  CLIPTextEncodeHiDream,
  CLIPTextEncodeHunyuanDiT,
  CLIPTextEncodeLumina2,
  CLIPTextEncodePixArtAlpha,
  CLIPTextEncodeSD3,
  CLIPTextEncodeSDXL,
  CLIPTextEncodeSDXLRefiner,
  CLIPVisionEncode,
  CLIPVisionLoader,
  Canny,
  CaseConverter,
  CheckpointLoader,
  CheckpointLoaderSimple,
  CheckpointSave,
  ChromaRadianceOptions,
  CombineHooks2,
  CombineHooks4,
  CombineHooks8,
  ConditioningAverage,
  ConditioningCombine,
  ConditioningConcat,
  ConditioningSetArea,
  ConditioningSetAreaPercentage,
  ConditioningSetAreaPercentageVideo,
  ConditioningSetAreaStrength,
  ConditioningSetDefaultCombine,
  ConditioningSetMask,
  ConditioningSetProperties,
  ConditioningSetPropertiesAndCombine,
  ConditioningSetTimestepRange,
  ConditioningStableAudio,
  ConditioningTimestepsRange,
  ConditioningZeroOut,
  ContextWindowsManual,
  ControlNetApply,
  ControlNetApplyAdvanced,
  ControlNetApplySD3,
  ControlNetInpaintingAliMamaApply,
  ControlNetLoader,
  CosmosImageToVideoLatent,
  CosmosPredict2ImageToVideoLatent,
  CreateHookKeyframe,
  CreateHookKeyframesFromFloats,
  CreateHookKeyframesInterpolated,
  CreateHookLora,
  CreateHookLoraModelOnly,
  CreateHookModelAsLora,
  CreateHookModelAsLoraModelOnly,
  CreateVideo,
  CropMask,
  DiffControlNetLoader,
  DifferentialDiffusion,
  DiffusersLoader,
  DisableNoise,
  DualCFGGuider,
  DualCLIPLoader,
  EasyCache,
  EmptyAceStepLatentAudio,
  EmptyAudio,
  EmptyChromaRadianceLatentImage,
  EmptyCosmosLatentVideo,
  EmptyHunyuanImageLatent,
  EmptyHunyuanLatentVideo,
  EmptyImage,
  EmptyLTXVLatentVideo,
  EmptyLatentAudio,
  EmptyLatentHunyuan3Dv2,
  EmptyLatentImage,
  EmptyMochiLatentVideo,
  EmptySD3LatentImage,
  "Epsilon Scaling": { "display_name": "Epsilon Ölçeklendirme", "inputs": { "model": { "name": "model" }, "scaling_factor": { "name": "ölçeklendirme_faktörü" } }, "outputs": { "0": { "tooltip": null } } },
  ExponentialScheduler,
  ExtendIntermediateSigmas,
  FeatherMask,
  FlipSigmas,
  FluxDisableGuidance,
  FluxGuidance,
  FluxKontextImageScale,
  FluxKontextMaxImageNode,
  FluxKontextMultiReferenceLatentMethod,
  FluxKontextProImageNode,
  FluxProExpandNode,
  FluxProFillNode,
  FluxProUltraImageNode,
  FreSca,
  FreeU,
  FreeU_V2,
  GITSScheduler,
  GLIGENLoader,
  GLIGENTextBoxApply,
  GeminiImageNode,
  GeminiInputFiles,
  GeminiNode,
  GetImageSize,
  GetVideoComponents,
  GrowMask,
  Hunyuan3Dv2Conditioning,
  Hunyuan3Dv2ConditioningMultiView,
  HunyuanImageToVideo,
  HunyuanRefinerLatent,
  HyperTile,
  HypernetworkLoader,
  IdeogramV1,
  IdeogramV2,
  IdeogramV3,
  ImageAddNoise,
  ImageBatch,
  ImageBlend,
  ImageBlur,
  ImageColorToMask,
  ImageCompositeMasked,
  ImageCrop,
  ImageFlip,
  ImageFromBatch,
  ImageInvert,
  ImageOnlyCheckpointLoader,
  ImageOnlyCheckpointSave,
  ImagePadForOutpaint,
  ImageQuantize,
  ImageRGBToYUV,
  ImageRotate,
  ImageScale,
  ImageScaleBy,
  ImageScaleToMaxDimension,
  ImageScaleToTotalPixels,
  ImageSharpen,
  ImageStitch,
  ImageToMask,
  ImageUpscaleWithModel,
  ImageYUVToRGB,
  InpaintModelConditioning,
  InstructPixToPixConditioning,
  InvertMask,
  JoinImageWithAlpha,
  KSampler,
  KSamplerAdvanced,
  KSamplerSelect,
  KarrasScheduler,
  KlingCameraControlI2VNode,
  KlingCameraControlT2VNode,
  KlingCameraControls,
  KlingDualCharacterVideoEffectNode,
  KlingImage2VideoNode,
  KlingImageGenerationNode,
  KlingLipSyncAudioToVideoNode,
  KlingLipSyncTextToVideoNode,
  KlingSingleImageVideoEffectNode,
  KlingStartEndFrameNode,
  KlingTextToVideoNode,
  KlingVideoExtendNode,
  KlingVirtualTryOnNode,
  LTXVAddGuide,
  LTXVConditioning,
  LTXVCropGuides,
  LTXVImgToVideo,
  LTXVPreprocess,
  LTXVScheduler,
  LaplaceScheduler,
  LatentAdd,
  LatentApplyOperation,
  LatentApplyOperationCFG,
  LatentBatch,
  LatentBatchSeedBehavior,
  LatentBlend,
  LatentComposite,
  LatentCompositeMasked,
  LatentConcat,
  LatentCrop,
  LatentCut,
  LatentFlip,
  LatentFromBatch,
  LatentInterpolate,
  LatentMultiply,
  LatentOperationSharpen,
  LatentOperationTonemapReinhard,
  LatentRotate,
  LatentSubtract,
  LatentUpscale,
  LatentUpscaleBy,
  LazyCache,
  Load3D,
  LoadAudio,
  LoadImage,
  LoadImageMask,
  LoadImageOutput,
  LoadLatent,
  LoadVideo,
  LoraLoader,
  LoraLoaderModelOnly,
  LoraModelLoader,
  LoraSave,
  LossGraphNode,
  LotusConditioning,
  LtxvApiImageToVideo,
  LtxvApiTextToVideo,
  LumaConceptsNode,
  LumaImageModifyNode,
  LumaImageNode,
  LumaImageToVideoNode,
  LumaReferenceNode,
  LumaVideoNode,
  Mahiro,
  MaskComposite,
  MaskPreview,
  MaskToImage,
  MinimaxHailuoVideoNode,
  MinimaxImageToVideoNode,
  MinimaxTextToVideoNode,
  ModelComputeDtype,
  ModelMergeAdd,
  ModelMergeAuraflow,
  ModelMergeBlocks,
  ModelMergeCosmos14B,
  ModelMergeCosmos7B,
  ModelMergeCosmosPredict2_14B,
  ModelMergeCosmosPredict2_2B,
  ModelMergeFlux1,
  ModelMergeLTXV,
  ModelMergeMochiPreview,
  ModelMergeQwenImage,
  ModelMergeSD1,
  ModelMergeSD2,
  ModelMergeSD35_Large,
  ModelMergeSD3_2B,
  ModelMergeSDXL,
  ModelMergeSimple,
  ModelMergeSubtract,
  ModelMergeWAN2_1,
  ModelPatchLoader,
  ModelSamplingAuraFlow,
  ModelSamplingContinuousEDM,
  ModelSamplingContinuousV,
  ModelSamplingDiscrete,
  ModelSamplingFlux,
  ModelSamplingLTXV,
  ModelSamplingSD3,
  ModelSamplingStableCascade,
  ModelSave,
  MoonvalleyImg2VideoNode,
  MoonvalleyTxt2VideoNode,
  MoonvalleyVideo2VideoNode,
  Morphology,
  OpenAIChatConfig,
  OpenAIChatNode,
  OpenAIDalle2,
  OpenAIDalle3,
  OpenAIGPTImage1,
  OpenAIInputFiles,
  OpenAIVideoSora2,
  OptimalStepsScheduler,
  PairConditioningCombine,
  PairConditioningSetDefaultCombine,
  PairConditioningSetProperties,
  PairConditioningSetPropertiesAndCombine,
  PatchModelAddDownscale,
  PerpNeg,
  PerpNegGuider,
  PerturbedAttentionGuidance,
  PhotoMakerEncode,
  PhotoMakerLoader,
  PixverseImageToVideoNode,
  PixverseTemplateNode,
  PixverseTextToVideoNode,
  PixverseTransitionVideoNode,
  PolyexponentialScheduler,
  PorterDuffImageComposite,
  Preview3D,
  PreviewAny,
  PreviewAudio,
  PreviewImage,
  PrimitiveBoolean,
  PrimitiveFloat,
  PrimitiveInt,
  PrimitiveString,
  PrimitiveStringMultiline,
  QuadrupleCLIPLoader,
  QwenImageDiffsynthControlnet,
  RandomNoise,
  RebatchImages,
  RebatchLatents,
  RecordAudio,
  RecraftColorRGB,
  RecraftControls,
  RecraftCreativeUpscaleNode,
  RecraftCrispUpscaleNode,
  RecraftImageInpaintingNode,
  RecraftImageToImageNode,
  RecraftRemoveBackgroundNode,
  RecraftReplaceBackgroundNode,
  RecraftStyleV3DigitalIllustration,
  RecraftStyleV3InfiniteStyleLibrary,
  RecraftStyleV3LogoRaster,
  RecraftStyleV3RealisticImage,
  RecraftTextToImageNode,
  RecraftTextToVectorNode,
  RecraftVectorizeImageNode,
  ReferenceLatent,
  RegexExtract,
  RegexMatch,
  RegexReplace,
  RenormCFG,
  RepeatImageBatch,
  RepeatLatentBatch,
  RescaleCFG,
  ResizeAndPadImage,
  Rodin3D_Detail,
  Rodin3D_Gen2,
  Rodin3D_Regular,
  Rodin3D_Sketch,
  Rodin3D_Smooth,
  RunwayFirstLastFrameNode,
  RunwayImageToVideoNodeGen3a,
  RunwayImageToVideoNodeGen4,
  RunwayTextToImageNode,
  SDTurboScheduler,
  SD_4XUpscale_Conditioning,
  SV3D_Conditioning,
  SVD_img2vid_Conditioning,
  SamplerCustom,
  SamplerCustomAdvanced,
  SamplerDPMAdaptative,
  SamplerDPMPP_2M_SDE,
  SamplerDPMPP_2S_Ancestral,
  SamplerDPMPP_3M_SDE,
  SamplerDPMPP_SDE,
  SamplerER_SDE,
  SamplerEulerAncestral,
  SamplerEulerAncestralCFGPP,
  SamplerEulerCFGpp,
  SamplerLCMUpscale,
  SamplerLMS,
  SamplerSASolver,
  SamplingPercentToSigma,
  SaveAnimatedPNG,
  SaveAnimatedWEBP,
  SaveAudio,
  SaveAudioMP3,
  SaveAudioOpus,
  SaveGLB,
  SaveImage,
  SaveImageWebsocket,
  SaveLatent,
  SaveSVGNode,
  SaveVideo,
  SaveWEBM,
  ScaleROPE,
  SelfAttentionGuidance,
  SetClipHooks,
  SetFirstSigma,
  SetHookKeyframes,
  SetLatentNoiseMask,
  SetUnionControlNetType,
  SkipLayerGuidanceDiT,
  SkipLayerGuidanceDiTSimple,
  SkipLayerGuidanceSD3,
  SolidMask,
  SplitAudioChannels,
  SplitImageWithAlpha,
  SplitSigmas,
  SplitSigmasDenoise,
  StabilityAudioInpaint,
  StabilityAudioToAudio,
  StabilityStableImageSD_3_5Node,
  StabilityStableImageUltraNode,
  StabilityTextToAudio,
  StabilityUpscaleConservativeNode,
  StabilityUpscaleCreativeNode,
  StabilityUpscaleFastNode,
  StableCascade_EmptyLatentImage,
  StableCascade_StageB_Conditioning,
  StableCascade_StageC_VAEEncode,
  StableCascade_SuperResolutionControlnet,
  StableZero123_Conditioning,
  StableZero123_Conditioning_Batched,
  StringCompare,
  StringConcatenate,
  StringContains,
  StringLength,
  StringReplace,
  StringSubstring,
  StringTrim,
  StyleModelApply,
  StyleModelLoader,
  T5TokenizerOptions,
  TCFG,
  TemporalScoreRescaling,
  TextEncodeAceStepAudio,
  TextEncodeHunyuanVideo_ImageToVideo,
  TextEncodeQwenImageEdit,
  TextEncodeQwenImageEditPlus,
  ThresholdMask,
  TomePatchModel,
  TorchCompileModel,
  TrainLoraNode,
  TrimAudioDuration,
  TrimVideoLatent,
  TripleCLIPLoader,
  TripoConversionNode,
  TripoImageToModelNode,
  TripoMultiviewToModelNode,
  TripoRefineNode,
  TripoRetargetNode,
  TripoRigNode,
  TripoTextToModelNode,
  TripoTextureNode,
  UNETLoader,
  UNetCrossAttentionMultiply,
  UNetSelfAttentionMultiply,
  UNetTemporalAttentionMultiply,
  USOStyleReference,
  UpscaleModelLoader,
  VAEDecode,
  VAEDecodeAudio,
  VAEDecodeHunyuan3D,
  VAEDecodeTiled,
  VAEEncode,
  VAEEncodeAudio,
  VAEEncodeForInpaint,
  VAEEncodeTiled,
  VAELoader,
  VAESave,
  VPScheduler,
  Veo3VideoGenerationNode,
  VeoVideoGenerationNode,
  VideoLinearCFGGuidance,
  VideoTriangleCFGGuidance,
  ViduImageToVideoNode,
  ViduReferenceVideoNode,
  ViduStartEndToVideoNode,
  ViduTextToVideoNode,
  VoxelToMesh,
  VoxelToMeshBasic,
  Wan22FunControlToVideo,
  Wan22ImageToVideoLatent,
  WanAnimateToVideo,
  WanCameraEmbedding,
  WanCameraImageToVideo,
  WanContextWindowsManual,
  WanFirstLastFrameToVideo,
  WanFunControlToVideo,
  WanFunInpaintToVideo,
  WanHuMoImageToVideo,
  WanImageToImageApi,
  WanImageToVideo,
  WanImageToVideoApi,
  WanPhantomSubjectToVideo,
  WanSoundImageToVideo,
  WanSoundImageToVideoExtend,
  WanTextToImageApi,
  WanTextToVideoApi,
  WanTrackToVideo,
  WanVaceToVideo,
  WebcamCapture,
  unCLIPCheckpointLoader,
  unCLIPConditioning
};
export {
  APG,
  AddNoise,
  AlignYourStepsScheduler,
  AudioAdjustVolume,
  AudioConcat,
  AudioEncoderEncode,
  AudioEncoderLoader,
  AudioMerge,
  BasicGuider,
  BasicScheduler,
  BetaSamplingScheduler,
  ByteDanceFirstLastFrameNode,
  ByteDanceImageEditNode,
  ByteDanceImageNode,
  ByteDanceImageReferenceNode,
  ByteDanceImageToVideoNode,
  ByteDanceSeedreamNode,
  ByteDanceTextToVideoNode,
  CFGGuider,
  CFGNorm,
  CFGZeroStar,
  CLIPAttentionMultiply,
  CLIPLoader,
  CLIPMergeAdd,
  CLIPMergeSimple,
  CLIPMergeSubtract,
  CLIPSave,
  CLIPSetLastLayer,
  CLIPTextEncode,
  CLIPTextEncodeControlnet,
  CLIPTextEncodeFlux,
  CLIPTextEncodeHiDream,
  CLIPTextEncodeHunyuanDiT,
  CLIPTextEncodeLumina2,
  CLIPTextEncodePixArtAlpha,
  CLIPTextEncodeSD3,
  CLIPTextEncodeSDXL,
  CLIPTextEncodeSDXLRefiner,
  CLIPVisionEncode,
  CLIPVisionLoader,
  Canny,
  CaseConverter,
  CheckpointLoader,
  CheckpointLoaderSimple,
  CheckpointSave,
  ChromaRadianceOptions,
  CombineHooks2,
  CombineHooks4,
  CombineHooks8,
  ConditioningAverage,
  ConditioningCombine,
  ConditioningConcat,
  ConditioningSetArea,
  ConditioningSetAreaPercentage,
  ConditioningSetAreaPercentageVideo,
  ConditioningSetAreaStrength,
  ConditioningSetDefaultCombine,
  ConditioningSetMask,
  ConditioningSetProperties,
  ConditioningSetPropertiesAndCombine,
  ConditioningSetTimestepRange,
  ConditioningStableAudio,
  ConditioningTimestepsRange,
  ConditioningZeroOut,
  ContextWindowsManual,
  ControlNetApply,
  ControlNetApplyAdvanced,
  ControlNetApplySD3,
  ControlNetInpaintingAliMamaApply,
  ControlNetLoader,
  CosmosImageToVideoLatent,
  CosmosPredict2ImageToVideoLatent,
  CreateHookKeyframe,
  CreateHookKeyframesFromFloats,
  CreateHookKeyframesInterpolated,
  CreateHookLora,
  CreateHookLoraModelOnly,
  CreateHookModelAsLora,
  CreateHookModelAsLoraModelOnly,
  CreateVideo,
  CropMask,
  DiffControlNetLoader,
  DifferentialDiffusion,
  DiffusersLoader,
  DisableNoise,
  DualCFGGuider,
  DualCLIPLoader,
  EasyCache,
  EmptyAceStepLatentAudio,
  EmptyAudio,
  EmptyChromaRadianceLatentImage,
  EmptyCosmosLatentVideo,
  EmptyHunyuanImageLatent,
  EmptyHunyuanLatentVideo,
  EmptyImage,
  EmptyLTXVLatentVideo,
  EmptyLatentAudio,
  EmptyLatentHunyuan3Dv2,
  EmptyLatentImage,
  EmptyMochiLatentVideo,
  EmptySD3LatentImage,
  ExponentialScheduler,
  ExtendIntermediateSigmas,
  FeatherMask,
  FlipSigmas,
  FluxDisableGuidance,
  FluxGuidance,
  FluxKontextImageScale,
  FluxKontextMaxImageNode,
  FluxKontextMultiReferenceLatentMethod,
  FluxKontextProImageNode,
  FluxProExpandNode,
  FluxProFillNode,
  FluxProUltraImageNode,
  FreSca,
  FreeU,
  FreeU_V2,
  GITSScheduler,
  GLIGENLoader,
  GLIGENTextBoxApply,
  GeminiImageNode,
  GeminiInputFiles,
  GeminiNode,
  GetImageSize,
  GetVideoComponents,
  GrowMask,
  Hunyuan3Dv2Conditioning,
  Hunyuan3Dv2ConditioningMultiView,
  HunyuanImageToVideo,
  HunyuanRefinerLatent,
  HyperTile,
  HypernetworkLoader,
  IdeogramV1,
  IdeogramV2,
  IdeogramV3,
  ImageAddNoise,
  ImageBatch,
  ImageBlend,
  ImageBlur,
  ImageColorToMask,
  ImageCompositeMasked,
  ImageCrop,
  ImageFlip,
  ImageFromBatch,
  ImageInvert,
  ImageOnlyCheckpointLoader,
  ImageOnlyCheckpointSave,
  ImagePadForOutpaint,
  ImageQuantize,
  ImageRGBToYUV,
  ImageRotate,
  ImageScale,
  ImageScaleBy,
  ImageScaleToMaxDimension,
  ImageScaleToTotalPixels,
  ImageSharpen,
  ImageStitch,
  ImageToMask,
  ImageUpscaleWithModel,
  ImageYUVToRGB,
  InpaintModelConditioning,
  InstructPixToPixConditioning,
  InvertMask,
  JoinImageWithAlpha,
  KSampler,
  KSamplerAdvanced,
  KSamplerSelect,
  KarrasScheduler,
  KlingCameraControlI2VNode,
  KlingCameraControlT2VNode,
  KlingCameraControls,
  KlingDualCharacterVideoEffectNode,
  KlingImage2VideoNode,
  KlingImageGenerationNode,
  KlingLipSyncAudioToVideoNode,
  KlingLipSyncTextToVideoNode,
  KlingSingleImageVideoEffectNode,
  KlingStartEndFrameNode,
  KlingTextToVideoNode,
  KlingVideoExtendNode,
  KlingVirtualTryOnNode,
  LTXVAddGuide,
  LTXVConditioning,
  LTXVCropGuides,
  LTXVImgToVideo,
  LTXVPreprocess,
  LTXVScheduler,
  LaplaceScheduler,
  LatentAdd,
  LatentApplyOperation,
  LatentApplyOperationCFG,
  LatentBatch,
  LatentBatchSeedBehavior,
  LatentBlend,
  LatentComposite,
  LatentCompositeMasked,
  LatentConcat,
  LatentCrop,
  LatentCut,
  LatentFlip,
  LatentFromBatch,
  LatentInterpolate,
  LatentMultiply,
  LatentOperationSharpen,
  LatentOperationTonemapReinhard,
  LatentRotate,
  LatentSubtract,
  LatentUpscale,
  LatentUpscaleBy,
  LazyCache,
  Load3D,
  LoadAudio,
  LoadImage,
  LoadImageMask,
  LoadImageOutput,
  LoadLatent,
  LoadVideo,
  LoraLoader,
  LoraLoaderModelOnly,
  LoraModelLoader,
  LoraSave,
  LossGraphNode,
  LotusConditioning,
  LtxvApiImageToVideo,
  LtxvApiTextToVideo,
  LumaConceptsNode,
  LumaImageModifyNode,
  LumaImageNode,
  LumaImageToVideoNode,
  LumaReferenceNode,
  LumaVideoNode,
  Mahiro,
  MaskComposite,
  MaskPreview,
  MaskToImage,
  MinimaxHailuoVideoNode,
  MinimaxImageToVideoNode,
  MinimaxTextToVideoNode,
  ModelComputeDtype,
  ModelMergeAdd,
  ModelMergeAuraflow,
  ModelMergeBlocks,
  ModelMergeCosmos14B,
  ModelMergeCosmos7B,
  ModelMergeCosmosPredict2_14B,
  ModelMergeCosmosPredict2_2B,
  ModelMergeFlux1,
  ModelMergeLTXV,
  ModelMergeMochiPreview,
  ModelMergeQwenImage,
  ModelMergeSD1,
  ModelMergeSD2,
  ModelMergeSD35_Large,
  ModelMergeSD3_2B,
  ModelMergeSDXL,
  ModelMergeSimple,
  ModelMergeSubtract,
  ModelMergeWAN2_1,
  ModelPatchLoader,
  ModelSamplingAuraFlow,
  ModelSamplingContinuousEDM,
  ModelSamplingContinuousV,
  ModelSamplingDiscrete,
  ModelSamplingFlux,
  ModelSamplingLTXV,
  ModelSamplingSD3,
  ModelSamplingStableCascade,
  ModelSave,
  MoonvalleyImg2VideoNode,
  MoonvalleyTxt2VideoNode,
  MoonvalleyVideo2VideoNode,
  Morphology,
  OpenAIChatConfig,
  OpenAIChatNode,
  OpenAIDalle2,
  OpenAIDalle3,
  OpenAIGPTImage1,
  OpenAIInputFiles,
  OpenAIVideoSora2,
  OptimalStepsScheduler,
  PairConditioningCombine,
  PairConditioningSetDefaultCombine,
  PairConditioningSetProperties,
  PairConditioningSetPropertiesAndCombine,
  PatchModelAddDownscale,
  PerpNeg,
  PerpNegGuider,
  PerturbedAttentionGuidance,
  PhotoMakerEncode,
  PhotoMakerLoader,
  PixverseImageToVideoNode,
  PixverseTemplateNode,
  PixverseTextToVideoNode,
  PixverseTransitionVideoNode,
  PolyexponentialScheduler,
  PorterDuffImageComposite,
  Preview3D,
  PreviewAny,
  PreviewAudio,
  PreviewImage,
  PrimitiveBoolean,
  PrimitiveFloat,
  PrimitiveInt,
  PrimitiveString,
  PrimitiveStringMultiline,
  QuadrupleCLIPLoader,
  QwenImageDiffsynthControlnet,
  RandomNoise,
  RebatchImages,
  RebatchLatents,
  RecordAudio,
  RecraftColorRGB,
  RecraftControls,
  RecraftCreativeUpscaleNode,
  RecraftCrispUpscaleNode,
  RecraftImageInpaintingNode,
  RecraftImageToImageNode,
  RecraftRemoveBackgroundNode,
  RecraftReplaceBackgroundNode,
  RecraftStyleV3DigitalIllustration,
  RecraftStyleV3InfiniteStyleLibrary,
  RecraftStyleV3LogoRaster,
  RecraftStyleV3RealisticImage,
  RecraftTextToImageNode,
  RecraftTextToVectorNode,
  RecraftVectorizeImageNode,
  ReferenceLatent,
  RegexExtract,
  RegexMatch,
  RegexReplace,
  RenormCFG,
  RepeatImageBatch,
  RepeatLatentBatch,
  RescaleCFG,
  ResizeAndPadImage,
  Rodin3D_Detail,
  Rodin3D_Gen2,
  Rodin3D_Regular,
  Rodin3D_Sketch,
  Rodin3D_Smooth,
  RunwayFirstLastFrameNode,
  RunwayImageToVideoNodeGen3a,
  RunwayImageToVideoNodeGen4,
  RunwayTextToImageNode,
  SDTurboScheduler,
  SD_4XUpscale_Conditioning,
  SV3D_Conditioning,
  SVD_img2vid_Conditioning,
  SamplerCustom,
  SamplerCustomAdvanced,
  SamplerDPMAdaptative,
  SamplerDPMPP_2M_SDE,
  SamplerDPMPP_2S_Ancestral,
  SamplerDPMPP_3M_SDE,
  SamplerDPMPP_SDE,
  SamplerER_SDE,
  SamplerEulerAncestral,
  SamplerEulerAncestralCFGPP,
  SamplerEulerCFGpp,
  SamplerLCMUpscale,
  SamplerLMS,
  SamplerSASolver,
  SamplingPercentToSigma,
  SaveAnimatedPNG,
  SaveAnimatedWEBP,
  SaveAudio,
  SaveAudioMP3,
  SaveAudioOpus,
  SaveGLB,
  SaveImage,
  SaveImageWebsocket,
  SaveLatent,
  SaveSVGNode,
  SaveVideo,
  SaveWEBM,
  ScaleROPE,
  SelfAttentionGuidance,
  SetClipHooks,
  SetFirstSigma,
  SetHookKeyframes,
  SetLatentNoiseMask,
  SetUnionControlNetType,
  SkipLayerGuidanceDiT,
  SkipLayerGuidanceDiTSimple,
  SkipLayerGuidanceSD3,
  SolidMask,
  SplitAudioChannels,
  SplitImageWithAlpha,
  SplitSigmas,
  SplitSigmasDenoise,
  StabilityAudioInpaint,
  StabilityAudioToAudio,
  StabilityStableImageSD_3_5Node,
  StabilityStableImageUltraNode,
  StabilityTextToAudio,
  StabilityUpscaleConservativeNode,
  StabilityUpscaleCreativeNode,
  StabilityUpscaleFastNode,
  StableCascade_EmptyLatentImage,
  StableCascade_StageB_Conditioning,
  StableCascade_StageC_VAEEncode,
  StableCascade_SuperResolutionControlnet,
  StableZero123_Conditioning,
  StableZero123_Conditioning_Batched,
  StringCompare,
  StringConcatenate,
  StringContains,
  StringLength,
  StringReplace,
  StringSubstring,
  StringTrim,
  StyleModelApply,
  StyleModelLoader,
  T5TokenizerOptions,
  TCFG,
  TemporalScoreRescaling,
  TextEncodeAceStepAudio,
  TextEncodeHunyuanVideo_ImageToVideo,
  TextEncodeQwenImageEdit,
  TextEncodeQwenImageEditPlus,
  ThresholdMask,
  TomePatchModel,
  TorchCompileModel,
  TrainLoraNode,
  TrimAudioDuration,
  TrimVideoLatent,
  TripleCLIPLoader,
  TripoConversionNode,
  TripoImageToModelNode,
  TripoMultiviewToModelNode,
  TripoRefineNode,
  TripoRetargetNode,
  TripoRigNode,
  TripoTextToModelNode,
  TripoTextureNode,
  UNETLoader,
  UNetCrossAttentionMultiply,
  UNetSelfAttentionMultiply,
  UNetTemporalAttentionMultiply,
  USOStyleReference,
  UpscaleModelLoader,
  VAEDecode,
  VAEDecodeAudio,
  VAEDecodeHunyuan3D,
  VAEDecodeTiled,
  VAEEncode,
  VAEEncodeAudio,
  VAEEncodeForInpaint,
  VAEEncodeTiled,
  VAELoader,
  VAESave,
  VPScheduler,
  Veo3VideoGenerationNode,
  VeoVideoGenerationNode,
  VideoLinearCFGGuidance,
  VideoTriangleCFGGuidance,
  ViduImageToVideoNode,
  ViduReferenceVideoNode,
  ViduStartEndToVideoNode,
  ViduTextToVideoNode,
  VoxelToMesh,
  VoxelToMeshBasic,
  Wan22FunControlToVideo,
  Wan22ImageToVideoLatent,
  WanAnimateToVideo,
  WanCameraEmbedding,
  WanCameraImageToVideo,
  WanContextWindowsManual,
  WanFirstLastFrameToVideo,
  WanFunControlToVideo,
  WanFunInpaintToVideo,
  WanHuMoImageToVideo,
  WanImageToImageApi,
  WanImageToVideo,
  WanImageToVideoApi,
  WanPhantomSubjectToVideo,
  WanSoundImageToVideo,
  WanSoundImageToVideoExtend,
  WanTextToImageApi,
  WanTextToVideoApi,
  WanTrackToVideo,
  WanVaceToVideo,
  WebcamCapture,
  nodeDefs as default,
  unCLIPCheckpointLoader,
  unCLIPConditioning
};
//# sourceMappingURL=nodeDefs-VZsNmhG7.js.map
