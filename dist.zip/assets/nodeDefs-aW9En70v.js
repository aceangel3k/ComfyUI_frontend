const APG = { "display_name": "Guía Adaptativa Proyectada", "inputs": { "eta": { "name": "eta", "tooltip": "Controla la escala del vector de guía paralelo. Comportamiento CFG predeterminado con un valor de 1." }, "model": { "name": "modelo" }, "momentum": { "name": "momento", "tooltip": "Controla un promedio móvil de la guía durante la difusión, se desactiva con un valor de 0." }, "norm_threshold": { "name": "umbral_norm", "tooltip": "Normaliza el vector de guía a este valor, la normalización se desactiva con un valor de 0." } }, "outputs": { "0": { "tooltip": null } } };
const AddNoise = { "display_name": "AñadirRuido", "inputs": { "latent_image": { "name": "imagen_latente" }, "model": { "name": "modelo" }, "noise": { "name": "ruido" }, "sigmas": { "name": "sigmas" } } };
const AlignYourStepsScheduler = { "display_name": "ProgramadorAlineaTusPasos", "inputs": { "denoise": { "name": "desruido" }, "model_type": { "name": "tipo_modelo" }, "steps": { "name": "pasos" } }, "outputs": { "0": { "tooltip": null } } };
const AudioAdjustVolume = { "display_name": "Ajustar Volumen de Audio", "inputs": { "audio": { "name": "audio" }, "volume": { "name": "volumen", "tooltip": "Ajuste de volumen en decibelios (dB). 0 = sin cambios, +6 = doble, -6 = mitad, etc." } } };
const AudioConcat = { "description": "Concatena el audio1 al audio2 en la dirección especificada.", "display_name": "Concatenar Audio", "inputs": { "audio1": { "name": "audio1" }, "audio2": { "name": "audio2" }, "direction": { "name": "dirección", "tooltip": "Si agregar audio2 después o antes de audio1." } } };
const AudioEncoderEncode = { "display_name": "CodificadorAudioCodificar", "inputs": { "audio": { "name": "audio" }, "audio_encoder": { "name": "codificador_audio" } }, "outputs": { "0": { "tooltip": null } } };
const AudioEncoderLoader = { "display_name": "CargadorCodificadorAudio", "inputs": { "audio_encoder_name": { "name": "nombre_codificador_audio" } }, "outputs": { "0": { "tooltip": null } } };
const AudioMerge = { "description": "Combina dos pistas de audio superponiendo sus formas de onda.", "display_name": "Combinar Audio", "inputs": { "audio1": { "name": "audio1" }, "audio2": { "name": "audio2" }, "merge_method": { "name": "método_combinación", "tooltip": "El método utilizado para combinar las formas de onda de audio." } } };
const BasicGuider = { "display_name": "GuíaBásica", "inputs": { "conditioning": { "name": "acondicionamiento" }, "model": { "name": "modelo" } } };
const BasicScheduler = { "display_name": "ProgramadorBásico", "inputs": { "denoise": { "name": "desruido" }, "model": { "name": "modelo" }, "scheduler": { "name": "programador" }, "steps": { "name": "pasos" } } };
const BetaSamplingScheduler = { "display_name": "ProgramadorMuestreoBeta", "inputs": { "alpha": { "name": "alfa" }, "beta": { "name": "beta" }, "model": { "name": "modelo" }, "steps": { "name": "pasos" } } };
const ByteDanceFirstLastFrameNode = { "description": "Generar video usando prompt y primer y último fotograma.", "display_name": "ByteDance Primer-Último-Fotograma a Video", "inputs": { "aspect_ratio": { "name": "relación_de_aspecto", "tooltip": "La relación de aspecto del video de salida." }, "camera_fixed": { "name": "cámara_fija", "tooltip": "Especifica si se debe fijar la cámara. La aplicación añade una instrucción para fijar la cámara a tu prompt, pero no garantiza el efecto real." }, "control_after_generate": { "name": "controlar después de generar" }, "duration": { "name": "duración", "tooltip": "La duración del video de salida en segundos." }, "first_frame": { "name": "primer_fotograma", "tooltip": "Primer fotograma que se utilizará para el video." }, "last_frame": { "name": "último_fotograma", "tooltip": "Último fotograma que se utilizará para el video." }, "model": { "name": "modelo" }, "prompt": { "name": "prompt", "tooltip": "El texto prompt utilizado para generar el video." }, "resolution": { "name": "resolución", "tooltip": "La resolución del video de salida." }, "seed": { "name": "semilla", "tooltip": "Semilla a utilizar para la generación." }, "watermark": { "name": "marca_de_agua", "tooltip": 'Si se debe añadir una marca de agua "Generado por IA" al video.' } }, "outputs": { "0": { "tooltip": null } } };
const ByteDanceImageEditNode = { "description": "Editar imágenes usando modelos ByteDance a través de API basado en prompt", "display_name": "Edición de Imágenes ByteDance", "inputs": { "control_after_generate": { "name": "controlar después de generar" }, "guidance_scale": { "name": "escala_de_guía", "tooltip": "Un valor más alto hace que la imagen siga más de cerca el prompt" }, "image": { "name": "imagen", "tooltip": "La imagen base para editar" }, "model": { "name": "modelo" }, "prompt": { "name": "prompt", "tooltip": "Instrucción para editar la imagen" }, "seed": { "name": "semilla", "tooltip": "Semilla a utilizar para la generación" }, "watermark": { "name": "marca_de_agua", "tooltip": 'Si se debe añadir una marca de agua "Generado por IA" a la imagen' } }, "outputs": { "0": { "tooltip": null } } };
const ByteDanceImageNode = { "description": "Generar imágenes usando modelos ByteDance a través de API basado en prompt", "display_name": "Imagen ByteDance", "inputs": { "control_after_generate": { "name": "control después de generar" }, "guidance_scale": { "name": "escala_de_guía", "tooltip": "Un valor más alto hace que la imagen siga más de cerca el prompt" }, "height": { "name": "alto", "tooltip": "Alto personalizado para la imagen. El valor solo funciona si `tamaño_predefinido` está establecido en `Personalizado`" }, "model": { "name": "modelo" }, "prompt": { "name": "prompt", "tooltip": "El prompt de texto utilizado para generar la imagen" }, "seed": { "name": "semilla", "tooltip": "Semilla a usar para la generación" }, "size_preset": { "name": "tamaño_predefinido", "tooltip": "Selecciona un tamaño recomendado. Elige Personalizado para usar el ancho y alto a continuación" }, "watermark": { "name": "marca_de_agua", "tooltip": 'Si añadir una marca de agua "Generado por IA" a la imagen' }, "width": { "name": "ancho", "tooltip": "Ancho personalizado para la imagen. El valor solo funciona si `tamaño_predefinido` está establecido en `Personalizado`" } }, "outputs": { "0": { "tooltip": null } } };
const ByteDanceImageReferenceNode = { "description": "Generar video usando prompt e imágenes de referencia.", "display_name": "ByteDance Referencia de Imágenes a Video", "inputs": { "aspect_ratio": { "name": "relación_de_aspecto", "tooltip": "La relación de aspecto del video de salida." }, "control_after_generate": { "name": "control después de generar" }, "duration": { "name": "duración", "tooltip": "La duración del video de salida en segundos." }, "images": { "name": "imágenes", "tooltip": "De una a cuatro imágenes." }, "model": { "name": "modelo" }, "prompt": { "name": "prompt", "tooltip": "El prompt de texto usado para generar el video." }, "resolution": { "name": "resolución", "tooltip": "La resolución del video de salida." }, "seed": { "name": "semilla", "tooltip": "Semilla a usar para la generación." }, "watermark": { "name": "marca_de_agua", "tooltip": 'Si añadir una marca de agua "Generado por IA" al video.' } }, "outputs": { "0": { "tooltip": null } } };
const ByteDanceImageToVideoNode = { "description": "Generar video usando modelos ByteDance via api basado en imagen y prompt", "display_name": "ByteDance Imagen a Video", "inputs": { "aspect_ratio": { "name": "relación_de_aspecto", "tooltip": "La relación de aspecto del video de salida." }, "camera_fixed": { "name": "cámara_fija", "tooltip": "Especifica si fijar la cámara. La plataforma añade una instrucción para fijar la cámara a tu prompt, pero no garantiza el efecto real." }, "control_after_generate": { "name": "control después de generar" }, "duration": { "name": "duración", "tooltip": "La duración del video de salida en segundos." }, "image": { "name": "imagen", "tooltip": "Primer fotograma a usar para el video." }, "model": { "name": "modelo" }, "prompt": { "name": "prompt", "tooltip": "El prompt de texto usado para generar el video." }, "resolution": { "name": "resolución", "tooltip": "La resolución del video de salida." }, "seed": { "name": "semilla", "tooltip": "Semilla a utilizar para la generación." }, "watermark": { "name": "marca_de_agua", "tooltip": 'Si añadir una marca de agua "Generado por IA" al video.' } }, "outputs": { "0": { "tooltip": null } } };
const ByteDanceSeedreamNode = { "description": "Generación unificada de texto a imagen y edición precisa de oraciones individuales con resolución de hasta 4K.", "display_name": "ByteDance Seedream 4", "inputs": { "control_after_generate": { "name": "control después de generar" }, "fail_on_partial": { "name": "fallar_en_parcial", "tooltip": "Si está habilitado, abortar la ejecución si faltan algunas imágenes solicitadas o devuelven un error." }, "height": { "name": "alto", "tooltip": "Alto personalizado para la imagen. El valor funciona solo si `predefinición_de_tamaño` está establecido en `Personalizado`." }, "image": { "name": "imagen", "tooltip": "Imagen(es) de entrada para generación de imagen a imagen. Lista de 1-10 imágenes para generación de referencia única o múltiple." }, "max_images": { "name": "imágenes_máximas", "tooltip": "Número máximo de imágenes a generar cuando generación_secuencial_de_imágenes='automático'. El total de imágenes (entrada + generadas) no puede exceder 15." }, "model": { "name": "modelo", "tooltip": "Nombre del modelo" }, "prompt": { "name": "prompt", "tooltip": "Prompt de texto para crear o editar una imagen." }, "seed": { "name": "semilla", "tooltip": "Semilla a utilizar para la generación." }, "sequential_image_generation": { "name": "generación_secuencial_de_imágenes", "tooltip": "Modo de generación grupal de imágenes. 'deshabilitado' genera una sola imagen. 'automático' permite al modelo decidir si generar múltiples imágenes relacionadas (ej., escenas de historia, variaciones de personajes)." }, "size_preset": { "name": "predefinición_de_tamaño", "tooltip": "Selecciona un tamaño recomendado. Elige Personalizado para usar el ancho y alto a continuación." }, "watermark": { "name": "marca_de_agua", "tooltip": 'Si añadir una marca de agua "Generado por IA" a la imagen.' }, "width": { "name": "ancho", "tooltip": "Ancho personalizado para la imagen. El valor funciona solo si `predefinición_de_tamaño` está establecido en `Personalizado`." } }, "outputs": { "0": { "tooltip": null } } };
const ByteDanceTextToVideoNode = { "description": "Generar video usando modelos de ByteDance mediante API basado en prompt", "display_name": "ByteDance Texto a Video", "inputs": { "aspect_ratio": { "name": "relación_de_aspecto", "tooltip": "La relación de aspecto del video de salida." }, "camera_fixed": { "name": "cámara_fija", "tooltip": "Especifica si fijar la cámara. La aplicación añade una instrucción para fijar la cámara a tu prompt, pero no garantiza el efecto real." }, "control_after_generate": { "name": "control después de generar" }, "duration": { "name": "duración", "tooltip": "La duración del video de salida en segundos." }, "model": { "name": "modelo" }, "prompt": { "name": "prompt", "tooltip": "El prompt de texto utilizado para generar el video." }, "resolution": { "name": "resolución", "tooltip": "La resolución del video de salida." }, "seed": { "name": "semilla", "tooltip": "Semilla a utilizar para la generación." }, "watermark": { "name": "marca_de_agua", "tooltip": 'Si añadir una marca de agua "Generado por IA" al video.' } }, "outputs": { "0": { "tooltip": null } } };
const CFGGuider = { "display_name": "GuíaCFG", "inputs": { "cfg": { "name": "cfg" }, "model": { "name": "modelo" }, "negative": { "name": "negativo" }, "positive": { "name": "positivo" } } };
const CFGNorm = { "display_name": "CFGNorm", "inputs": { "model": { "name": "modelo" }, "strength": { "name": "intensidad" } }, "outputs": { "0": { "name": "modelo_parcheado", "tooltip": null } } };
const CFGZeroStar = { "display_name": "CFGZeroStar", "inputs": { "model": { "name": "modelo" } }, "outputs": { "0": { "name": "modelo_modificado", "tooltip": null } } };
const CLIPAttentionMultiply = { "display_name": "MultiplicarAtenciónCLIP", "inputs": { "clip": { "name": "clip" }, "k": { "name": "k" }, "out": { "name": "salida" }, "q": { "name": "q" }, "v": { "name": "v" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPLoader = { "description": "[Recetas]\n\nstable_diffusion: clip-l\nstable_cascade: clip-g\nsd3: t5 xxl/ clip-g / clip-l\nstable_audio: t5 base\nmochi: t5 xxl\ncosmos: old t5 xxl\nlumina2: gemma 2 2B\nwan: umt5 xxl", "display_name": "Cargar CLIP", "inputs": { "clip_name": { "name": "nombre_clip" }, "device": { "name": "dispositivo" }, "type": { "name": "tipo" } } };
const CLIPMergeAdd = { "display_name": "CLIPMergeAdd", "inputs": { "clip1": { "name": "clip1" }, "clip2": { "name": "clip2" } } };
const CLIPMergeSimple = { "display_name": "CLIPMergeSimple", "inputs": { "clip1": { "name": "clip1" }, "clip2": { "name": "clip2" }, "ratio": { "name": "ratio" } } };
const CLIPMergeSubtract = { "display_name": "CLIPMergeSubtract", "inputs": { "clip1": { "name": "clip1" }, "clip2": { "name": "clip2" }, "multiplier": { "name": "multiplicador" } } };
const CLIPSave = { "display_name": "Guardar CLIP", "inputs": { "clip": { "name": "clip" }, "filename_prefix": { "name": "prefijo_nombre_archivo" } } };
const CLIPSetLastLayer = { "display_name": "Establecer Última Capa de CLIP", "inputs": { "clip": { "name": "clip" }, "stop_at_clip_layer": { "name": "detener_en_capa_clip" } } };
const CLIPTextEncode = { "description": "Codifica un prompt de texto utilizando un modelo CLIP en un embedding que se puede usar para guiar el modelo de difusión hacia la generación de imágenes específicas.", "display_name": "Codificar Texto CLIP (Prompt)", "inputs": { "clip": { "name": "clip", "tooltip": "El modelo CLIP utilizado para codificar el texto." }, "text": { "name": "texto", "tooltip": "El texto a codificar." } }, "outputs": { "0": { "tooltip": "Una condición que contiene el texto incrustado utilizado para guiar el modelo de difusión." } } };
const CLIPTextEncodeControlnet = { "display_name": "CodificarTextoCLIPControlnet", "inputs": { "clip": { "name": "clip" }, "conditioning": { "name": "condicionamiento" }, "text": { "name": "texto" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeFlux = { "display_name": "CodificarTextoCLIPFlux", "inputs": { "clip": { "name": "clip" }, "clip_l": { "name": "clip_l" }, "guidance": { "name": "orientación" }, "t5xxl": { "name": "t5xxl" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeHiDream = { "display_name": "CLIPTextEncodeHiDream", "inputs": { "clip": { "name": "clip" }, "clip_g": { "name": "clip_g" }, "clip_l": { "name": "clip_l" }, "llama": { "name": "llama" }, "t5xxl": { "name": "t5xxl" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeHunyuanDiT = { "display_name": "CodificarTextoCLIPHunyuanDiT", "inputs": { "bert": { "name": "bert" }, "clip": { "name": "clip" }, "mt5xl": { "name": "mt5xl" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeLumina2 = { "description": "Codifica un mensaje del sistema y un mensaje del usuario utilizando un modelo CLIP en un embedding que se puede usar para guiar el modelo de difusión hacia la generación de imágenes específicas.", "display_name": "CLIP Text Encode para Lumina2", "inputs": { "clip": { "name": "clip", "tooltip": "El modelo CLIP utilizado para codificar el texto." }, "system_prompt": { "name": "system_prompt", "tooltip": "Lumina2 proporciona dos tipos de mensajes del sistema: Superior: Eres un asistente diseñado para generar imágenes superiores con el grado superior de alineación imagen-texto basado en mensajes textuales o mensajes del usuario. Alineación: Eres un asistente diseñado para generar imágenes de alta calidad con el mayor grado de alineación imagen-texto basado en mensajes textuales." }, "user_prompt": { "name": "user_prompt", "tooltip": "El texto a codificar." } }, "outputs": { "0": { "tooltip": "Una condición que contiene el texto incrustado utilizado para guiar el modelo de difusión." } } };
const CLIPTextEncodePixArtAlpha = { "description": "Codifica el texto y establece la condición de resolución para PixArt Alpha. No se aplica a PixArt Sigma.", "display_name": "CLIPTextEncodePixArtAlpha", "inputs": { "clip": { "name": "clip" }, "height": { "name": "height" }, "text": { "name": "text" }, "width": { "name": "width" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeSD3 = { "display_name": "CLIPTextEncodeSD3", "inputs": { "clip": { "name": "clip" }, "clip_g": { "name": "clip_g" }, "clip_l": { "name": "clip_l" }, "empty_padding": { "name": "empty_padding" }, "t5xxl": { "name": "t5xxl" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeSDXL = { "display_name": "CLIPTextEncodeSDXL", "inputs": { "clip": { "name": "clip" }, "crop_h": { "name": "crop_h" }, "crop_w": { "name": "crop_w" }, "height": { "name": "height" }, "target_height": { "name": "target_height" }, "target_width": { "name": "target_width" }, "text_g": { "name": "text_g" }, "text_l": { "name": "text_l" }, "width": { "name": "width" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPTextEncodeSDXLRefiner = { "display_name": "CLIPTextEncodeSDXLRefiner", "inputs": { "ascore": { "name": "ascore" }, "clip": { "name": "clip" }, "height": { "name": "height" }, "text": { "name": "text" }, "width": { "name": "width" } }, "outputs": { "0": { "tooltip": null } } };
const CLIPVisionEncode = { "display_name": "CLIP Vision Encode", "inputs": { "clip_vision": { "name": "clip_vision" }, "crop": { "name": "crop" }, "image": { "name": "image" } } };
const CLIPVisionLoader = { "display_name": "Cargar CLIP Vision", "inputs": { "clip_name": { "name": "clip_name" } } };
const Canny = { "display_name": "Canny", "inputs": { "high_threshold": { "name": "umbral_alto" }, "image": { "name": "imagen" }, "low_threshold": { "name": "umbral_bajo" } }, "outputs": { "0": { "tooltip": null } } };
const CaseConverter = { "display_name": "Convertidor de Mayúsculas y Minúsculas", "inputs": { "mode": { "name": "modo" }, "string": { "name": "cadena" } }, "outputs": { "0": { "tooltip": null } } };
const CheckpointLoader = { "display_name": "Cargar Punto de Control Con Configuración (OBSOLETO)", "inputs": { "ckpt_name": { "name": "nombre_ckpt" }, "config_name": { "name": "nombre_configuración" } } };
const CheckpointLoaderSimple = { "description": "Carga un punto de control del modelo de difusión, los modelos de difusión se utilizan para desruidar latentes.", "display_name": "Cargar Punto de Control", "inputs": { "ckpt_name": { "name": "nombre_ckpt", "tooltip": "El nombre del punto de control (modelo) a cargar." } }, "outputs": { "0": { "tooltip": "El modelo utilizado para desruidar latentes." }, "1": { "tooltip": "El modelo CLIP utilizado para codificar textos de prompts." }, "2": { "tooltip": "El modelo VAE utilizado para codificar y decodificar imágenes a y desde el espacio latente." } } };
const CheckpointSave = { "display_name": "Guardar Punto de Control", "inputs": { "clip": { "name": "clip" }, "filename_prefix": { "name": "prefijo_nombre_archivo" }, "model": { "name": "modelo" }, "vae": { "name": "vae" } } };
const ChromaRadianceOptions = { "description": "Permite configurar opciones avanzadas para el modelo Chroma Radiance.", "display_name": "Opciones de Croma Radiance", "inputs": { "end_sigma": { "name": "sigma_final", "tooltip": "Último sigma para el cual estas opciones estarán en efecto." }, "model": { "name": "modelo" }, "nerf_tile_size": { "name": "tamaño_mosaico_nerf", "tooltip": "Permite anular el tamaño de mosaico NeRF predeterminado. -1 significa usar el predeterminado (32). 0 significa usar modo sin mosaicos (puede requerir mucha VRAM)." }, "preserve_wrapper": { "name": "preservar_envoltorio", "tooltip": "Cuando está habilitado, delegará a un envoltorio de función de modelo existente si existe. Generalmente debe dejarse habilitado." }, "start_sigma": { "name": "sigma_inicial", "tooltip": "Primer sigma para el cual estas opciones estarán en efecto." } }, "outputs": { "0": { "tooltip": null } } };
const CombineHooks2 = { "display_name": "Combinar Hooks [2]", "inputs": { "hooks_A": { "name": "hooks_A" }, "hooks_B": { "name": "hooks_B" } } };
const CombineHooks4 = { "display_name": "Combine Hooks [4]", "inputs": { "hooks_A": { "name": "hooks_A" }, "hooks_B": { "name": "hooks_B" }, "hooks_C": { "name": "hooks_C" }, "hooks_D": { "name": "hooks_D" } } };
const CombineHooks8 = { "display_name": "Combine Hooks [8]", "inputs": { "hooks_A": { "name": "hooks_A" }, "hooks_B": { "name": "hooks_B" }, "hooks_C": { "name": "hooks_C" }, "hooks_D": { "name": "hooks_D" }, "hooks_E": { "name": "hooks_E" }, "hooks_F": { "name": "hooks_F" }, "hooks_G": { "name": "hooks_G" }, "hooks_H": { "name": "hooks_H" } } };
const ConditioningAverage = { "display_name": "Promedio de Acondicionamiento", "inputs": { "conditioning_from": { "name": "acondicionamiento_de" }, "conditioning_to": { "name": "acondicionamiento_a" }, "conditioning_to_strength": { "name": "fuerza_de_acondicionamiento_a" } } };
const ConditioningCombine = { "display_name": "Acondicionamiento (Combinar)", "inputs": { "conditioning_1": { "name": "acondicionamiento_1" }, "conditioning_2": { "name": "acondicionamiento_2" } } };
const ConditioningConcat = { "display_name": "Acondicionamiento (Concatenar)", "inputs": { "conditioning_from": { "name": "acondicionamiento_de" }, "conditioning_to": { "name": "acondicionamiento_a" } } };
const ConditioningSetArea = { "display_name": "Acondicionamiento (Establecer Área)", "inputs": { "conditioning": { "name": "acondicionamiento" }, "height": { "name": "alto" }, "strength": { "name": "fuerza" }, "width": { "name": "ancho" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const ConditioningSetAreaPercentage = { "display_name": "Acondicionamiento (Establecer Área con Porcentaje)", "inputs": { "conditioning": { "name": "acondicionamiento" }, "height": { "name": "alto" }, "strength": { "name": "fuerza" }, "width": { "name": "ancho" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const ConditioningSetAreaPercentageVideo = { "display_name": "AcondicionamientoEstablecerAreaPorcentajeVideo", "inputs": { "conditioning": { "name": "acondicionamiento" }, "height": { "name": "alto" }, "strength": { "name": "fuerza" }, "temporal": { "name": "temporal" }, "width": { "name": "ancho" }, "x": { "name": "x" }, "y": { "name": "y" }, "z": { "name": "z" } } };
const ConditioningSetAreaStrength = { "display_name": "AcondicionamientoEstablecerFuerzaArea", "inputs": { "conditioning": { "name": "acondicionamiento" }, "strength": { "name": "fuerza" } } };
const ConditioningSetDefaultCombine = { "display_name": "Cond Establecer Combinación Predeterminada", "inputs": { "cond": { "name": "cond" }, "cond_DEFAULT": { "name": "cond_DEFAULT" }, "hooks": { "name": "hooks" } } };
const ConditioningSetMask = { "display_name": "Acondicionamiento (Establecer Máscara)", "inputs": { "conditioning": { "name": "acondicionamiento" }, "mask": { "name": "máscara" }, "set_cond_area": { "name": "establecer_area_cond" }, "strength": { "name": "fuerza" } } };
const ConditioningSetProperties = { "display_name": "Establecer Propiedades Cond", "inputs": { "cond_NEW": { "name": "cond_NEW" }, "hooks": { "name": "ganchos" }, "mask": { "name": "máscara" }, "set_cond_area": { "name": "establecer_area_cond" }, "strength": { "name": "fuerza" }, "timesteps": { "name": "pasos_de_tiempo" } } };
const ConditioningSetPropertiesAndCombine = { "display_name": "Establecer Propiedades Cond Combinar", "inputs": { "cond": { "name": "cond" }, "cond_NEW": { "name": "cond_NEW" }, "hooks": { "name": "ganchos" }, "mask": { "name": "máscara" }, "set_cond_area": { "name": "establecer_area_cond" }, "strength": { "name": "fuerza" }, "timesteps": { "name": "pasos_de_tiempo" } } };
const ConditioningSetTimestepRange = { "display_name": "Establecer Rango de Pasos de Tiempo de Acondicionamiento", "inputs": { "conditioning": { "name": "acondicionamiento" }, "end": { "name": "fin" }, "start": { "name": "inicio" } } };
const ConditioningStableAudio = { "display_name": "Acondicionamiento Audio Estable", "inputs": { "negative": { "name": "negativo" }, "positive": { "name": "positivo" }, "seconds_start": { "name": "segundos_inicio" }, "seconds_total": { "name": "segundos_total" } }, "outputs": { "0": { "name": "positivo" }, "1": { "name": "negativo" } } };
const ConditioningTimestepsRange = { "display_name": "Rango de Pasos de Tiempo", "inputs": { "end_percent": { "name": "porcentaje_fin" }, "start_percent": { "name": "porcentaje_inicio" } }, "outputs": { "1": { "name": "ANTES_DE_RANGO" }, "2": { "name": "DESPUÉS_DE_RANGO" } } };
const ConditioningZeroOut = { "display_name": "Acondicionamiento Cero", "inputs": { "conditioning": { "name": "acondicionamiento" } } };
const ContextWindowsManual = { "description": "Establecer manualmente las ventanas de contexto.", "display_name": "Ventanas de Contexto (Manual)", "inputs": { "closed_loop": { "name": "bucle_cerrado", "tooltip": "Si se debe cerrar el bucle de la ventana de contexto; solo aplicable a programaciones en bucle." }, "context_length": { "name": "longitud_contexto", "tooltip": "La longitud de la ventana de contexto." }, "context_overlap": { "name": "superposición_contexto", "tooltip": "La superposición de la ventana de contexto." }, "context_schedule": { "name": "programación_contexto", "tooltip": "El intervalo de la ventana de contexto." }, "context_stride": { "name": "paso_contexto", "tooltip": "El paso de la ventana de contexto; solo aplicable a programaciones uniformes." }, "dim": { "name": "dimensión", "tooltip": "La dimensión a la que aplicar las ventanas de contexto." }, "fuse_method": { "name": "método_de_fusión", "tooltip": "El método a utilizar para fusionar las ventanas de contexto." }, "model": { "name": "modelo", "tooltip": "El modelo al que aplicar ventanas de contexto durante el muestreo." } }, "outputs": { "0": { "tooltip": "El modelo con ventanas de contexto aplicadas durante el muestreo." } } };
const ControlNetApply = { "display_name": "Aplicar ControlNet (ANTIGUO)", "inputs": { "conditioning": { "name": "acondicionamiento" }, "control_net": { "name": "control_net" }, "image": { "name": "imagen" }, "strength": { "name": "fuerza" } } };
const ControlNetApplyAdvanced = { "display_name": "Aplicar ControlNet", "inputs": { "control_net": { "name": "control_net" }, "end_percent": { "name": "porcentaje_fin" }, "image": { "name": "imagen" }, "negative": { "name": "negativo" }, "positive": { "name": "positivo" }, "start_percent": { "name": "porcentaje_inicio" }, "strength": { "name": "fuerza" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "positivo" }, "1": { "name": "negativo" } } };
const ControlNetApplySD3 = { "display_name": "Aplicar Controlnet con VAE", "inputs": { "control_net": { "name": "control_net" }, "end_percent": { "name": "porcentaje_final" }, "image": { "name": "imagen" }, "negative": { "name": "negativo" }, "positive": { "name": "positivo" }, "start_percent": { "name": "porcentaje_inicio" }, "strength": { "name": "fuerza" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "positivo", "tooltip": null }, "1": { "name": "negativo", "tooltip": null } } };
const ControlNetInpaintingAliMamaApply = { "display_name": "ControlNetInpaintingAliMamaApply", "inputs": { "control_net": { "name": "control_net" }, "end_percent": { "name": "porcentaje_final" }, "image": { "name": "imagen" }, "mask": { "name": "máscara" }, "negative": { "name": "negativo" }, "positive": { "name": "positivo" }, "start_percent": { "name": "porcentaje_inicio" }, "strength": { "name": "fuerza" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "positivo", "tooltip": null }, "1": { "name": "negativo", "tooltip": null } } };
const ControlNetLoader = { "display_name": "Cargar Modelo ControlNet", "inputs": { "control_net_name": { "name": "nombre_control_net" } } };
const CosmosImageToVideoLatent = { "display_name": "CosmosImageToVideoLatent", "inputs": { "batch_size": { "name": "tamaño_lote" }, "end_image": { "name": "imagen_final" }, "height": { "name": "altura" }, "length": { "name": "longitud" }, "start_image": { "name": "imagen_inicio" }, "vae": { "name": "vae" }, "width": { "name": "ancho" } }, "outputs": { "0": { "tooltip": null } } };
const CosmosPredict2ImageToVideoLatent = { "display_name": "CosmosPredict2ImageToVideoLatent", "inputs": { "batch_size": { "name": "tamaño_del_lote" }, "end_image": { "name": "imagen_final" }, "height": { "name": "alto" }, "length": { "name": "longitud" }, "start_image": { "name": "imagen_inicial" }, "vae": { "name": "vae" }, "width": { "name": "ancho" } }, "outputs": { "0": { "tooltip": null } } };
const CreateHookKeyframe = { "display_name": "Crear Hook Keyframe", "inputs": { "prev_hook_kf": { "name": "prev_hook_kf" }, "start_percent": { "name": "porcentaje_inicio" }, "strength_mult": { "name": "multiplicador_fuerza" } }, "outputs": { "0": { "name": "HOOK_KF" } } };
const CreateHookKeyframesFromFloats = { "display_name": "Crear Hook Keyframes Desde Flotantes", "inputs": { "end_percent": { "name": "porcentaje_final" }, "floats_strength": { "name": "fuerza_flotantes" }, "prev_hook_kf": { "name": "prev_hook_kf" }, "print_keyframes": { "name": "imprimir_keyframes" }, "start_percent": { "name": "porcentaje_inicio" } }, "outputs": { "0": { "name": "HOOK_KF" } } };
const CreateHookKeyframesInterpolated = { "display_name": "Crear Hook Keyframes Interp.", "inputs": { "end_percent": { "name": "end_percent" }, "interpolation": { "name": "interpolación" }, "keyframes_count": { "name": "keyframes_count" }, "prev_hook_kf": { "name": "prev_hook_kf" }, "print_keyframes": { "name": "print_keyframes" }, "start_percent": { "name": "start_percent" }, "strength_end": { "name": "strength_end" }, "strength_start": { "name": "strength_start" } }, "outputs": { "0": { "name": "HOOK_KF" } } };
const CreateHookLora = { "display_name": "Crear Hook LoRA", "inputs": { "lora_name": { "name": "lora_name" }, "prev_hooks": { "name": "prev_hooks" }, "strength_clip": { "name": "strength_clip" }, "strength_model": { "name": "strength_model" } } };
const CreateHookLoraModelOnly = { "display_name": "Crear Hook LoRA (MO)", "inputs": { "lora_name": { "name": "lora_name" }, "prev_hooks": { "name": "prev_hooks" }, "strength_model": { "name": "strength_model" } } };
const CreateHookModelAsLora = { "display_name": "Crear Hook Model como LoRA", "inputs": { "ckpt_name": { "name": "ckpt_name" }, "prev_hooks": { "name": "prev_hooks" }, "strength_clip": { "name": "strength_clip" }, "strength_model": { "name": "strength_model" } } };
const CreateHookModelAsLoraModelOnly = { "display_name": "Crear Hook Model como LoRA (MO)", "inputs": { "ckpt_name": { "name": "ckpt_name" }, "prev_hooks": { "name": "prev_hooks" }, "strength_model": { "name": "strength_model" } } };
const CreateVideo = { "description": "Crea un video a partir de imágenes.", "display_name": "Crear video", "inputs": { "audio": { "name": "audio", "tooltip": "El audio que se añadirá al video." }, "fps": { "name": "fps" }, "images": { "name": "imágenes", "tooltip": "Las imágenes de las que se creará el video." } }, "outputs": { "0": { "tooltip": null } } };
const CropMask = { "display_name": "CropMask", "inputs": { "height": { "name": "altura" }, "mask": { "name": "máscara" }, "width": { "name": "ancho" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const DiffControlNetLoader = { "display_name": "Cargar Modelo ControlNet (diff)", "inputs": { "control_net_name": { "name": "control_net_name" }, "model": { "name": "modelo" } } };
const DifferentialDiffusion = { "display_name": "Difusión Diferencial", "inputs": { "model": { "name": "modelo" }, "strength": { "name": "intensidad" } }, "outputs": { "0": { "tooltip": null } } };
const DiffusersLoader = { "display_name": "Cargador de Difusores", "inputs": { "model_path": { "name": "ruta_del_modelo" } } };
const DisableNoise = { "display_name": "DesactivarRuido" };
const DualCFGGuider = { "display_name": "Guía Dual CFG", "inputs": { "cfg_cond2_negative": { "name": "cfg_cond2_negativo" }, "cfg_conds": { "name": "cfg_conds" }, "cond1": { "name": "cond1" }, "cond2": { "name": "cond2" }, "model": { "name": "modelo" }, "negative": { "name": "negativo" }, "style": { "name": "estilo" } } };
const DualCLIPLoader = { "description": "[Recetas]\n\nsdxl: clip-l, clip-g\nsd3: clip-l, clip-g / clip-l, t5 / clip-g, t5\nflux: clip-l, t5", "display_name": "DualCLIPLoader", "inputs": { "clip_name1": { "name": "clip_name1" }, "clip_name2": { "name": "clip_name2" }, "device": { "name": "dispositivo" }, "type": { "name": "tipo" } } };
const EasyCache = { "description": "Implementación nativa de EasyCache.", "display_name": "EasyCache", "inputs": { "end_percent": { "name": "porcentaje_final", "tooltip": "El paso de muestreo relativo para finalizar el uso de EasyCache." }, "model": { "name": "modelo", "tooltip": "El modelo al que añadir EasyCache." }, "reuse_threshold": { "name": "umbral_de_reutilización", "tooltip": "El umbral para reutilizar pasos en caché." }, "start_percent": { "name": "porcentaje_inicial", "tooltip": "El paso de muestreo relativo para comenzar a usar EasyCache." }, "verbose": { "name": "detallado", "tooltip": "Si se debe registrar información detallada." } }, "outputs": { "0": { "tooltip": "El modelo con EasyCache." } } };
const EmptyAceStepLatentAudio = { "display_name": "EmptyAceStepLatentAudio", "inputs": { "batch_size": { "name": "tamaño_del_lote", "tooltip": "El número de imágenes latentes en el lote." }, "seconds": { "name": "segundos" } }, "outputs": { "0": { "tooltip": null } } };
const EmptyAudio = { "display_name": "Audio Vacío", "inputs": { "channels": { "name": "canales", "tooltip": "Número de canales de audio (1 para mono, 2 para estéreo)." }, "duration": { "name": "duración", "tooltip": "Duración del clip de audio vacío en segundos." }, "sample_rate": { "name": "tasa_de_muestreo", "tooltip": "Tasa de muestreo del clip de audio vacío." } } };
const EmptyChromaRadianceLatentImage = { "display_name": "ImagenLatenteChromaRadianceVacía", "inputs": { "batch_size": { "name": "tamaño_lote" }, "height": { "name": "alto" }, "width": { "name": "ancho" } }, "outputs": { "0": { "tooltip": null } } };
const EmptyCosmosLatentVideo = { "display_name": "EmptyCosmosLatentVideo", "inputs": { "batch_size": { "name": "tamaño_del_lote" }, "height": { "name": "altura" }, "length": { "name": "longitud" }, "width": { "name": "ancho" } }, "outputs": { "0": { "tooltip": null } } };
const EmptyHunyuanImageLatent = { "display_name": "ImagenLatenteHunyuanVacía", "inputs": { "batch_size": { "name": "tamaño_lote" }, "height": { "name": "alto" }, "width": { "name": "ancho" } }, "outputs": { "0": { "tooltip": null } } };
const EmptyHunyuanLatentVideo = { "display_name": "EmptyHunyuanLatentVideo", "inputs": { "batch_size": { "name": "tamaño_del_lote" }, "height": { "name": "altura" }, "length": { "name": "longitud" }, "width": { "name": "ancho" } }, "outputs": { "0": { "tooltip": null } } };
const EmptyImage = { "display_name": "EmptyImage", "inputs": { "batch_size": { "name": "tamaño_del_lote" }, "color": { "name": "color" }, "height": { "name": "altura" }, "width": { "name": "ancho" } } };
const EmptyLTXVLatentVideo = { "display_name": "EmptyLTXVLatentVideo", "inputs": { "batch_size": { "name": "tamaño_del_lote" }, "height": { "name": "altura" }, "length": { "name": "longitud" }, "width": { "name": "ancho" } }, "outputs": { "0": { "tooltip": null } } };
const EmptyLatentAudio = { "display_name": "EmptyLatentAudio", "inputs": { "batch_size": { "name": "tamaño_del_lote", "tooltip": "El número de imágenes latentes en el lote." }, "seconds": { "name": "segundos" } } };
const EmptyLatentHunyuan3Dv2 = { "display_name": "EmptyLatentHunyuan3Dv2", "inputs": { "batch_size": { "name": "tamaño_del_lote", "tooltip": "El número de imágenes latentes en el lote." }, "resolution": { "name": "resolución" } } };
const EmptyLatentImage = { "description": "Crea un nuevo lote de imágenes latentes vacías para ser desruidadas mediante muestreo.", "display_name": "Imagen Latente Vacía", "inputs": { "batch_size": { "name": "tamaño_del_lote", "tooltip": "El número de imágenes latentes en el lote." }, "height": { "name": "altura", "tooltip": "La altura de las imágenes latentes en píxeles." }, "width": { "name": "ancho", "tooltip": "El ancho de las imágenes latentes en píxeles." } }, "outputs": { "0": { "tooltip": "El lote de imágenes latentes vacías." } } };
const EmptyMochiLatentVideo = { "display_name": "EmptyMochiLatentVideo", "inputs": { "batch_size": { "name": "tamaño_del_lote" }, "height": { "name": "altura" }, "length": { "name": "longitud" }, "width": { "name": "ancho" } }, "outputs": { "0": { "tooltip": null } } };
const EmptySD3LatentImage = { "display_name": "EmptySD3LatentImage", "inputs": { "batch_size": { "name": "tamaño_del_lote" }, "height": { "name": "altura" }, "width": { "name": "ancho" } }, "outputs": { "0": { "tooltip": null } } };
const ExponentialScheduler = { "display_name": "ExponentialScheduler", "inputs": { "sigma_max": { "name": "sigma_max" }, "sigma_min": { "name": "sigma_min" }, "steps": { "name": "pasos" } } };
const ExtendIntermediateSigmas = { "display_name": "ExtendIntermediateSigmas", "inputs": { "end_at_sigma": { "name": "terminar_en_sigma" }, "sigmas": { "name": "sigmas" }, "spacing": { "name": "espaciado" }, "start_at_sigma": { "name": "comenzar_en_sigma" }, "steps": { "name": "pasos" } } };
const FeatherMask = { "display_name": "FeatherMask", "inputs": { "bottom": { "name": "abajo" }, "left": { "name": "izquierda" }, "mask": { "name": "máscara" }, "right": { "name": "derecha" }, "top": { "name": "arriba" } } };
const FlipSigmas = { "display_name": "FlipSigmas", "inputs": { "sigmas": { "name": "sigmas" } } };
const FluxDisableGuidance = { "description": "Este nodo desactiva completamente la guía incrustada en Flux y modelos similares a Flux", "display_name": "FluxDisableGuidance", "inputs": { "conditioning": { "name": "acondicionamiento" } }, "outputs": { "0": { "tooltip": null } } };
const FluxGuidance = { "display_name": "FluxGuidance", "inputs": { "conditioning": { "name": "acondicionamiento" }, "guidance": { "name": "guía" } }, "outputs": { "0": { "tooltip": null } } };
const FluxKontextImageScale = { "description": "Este nodo redimensiona la imagen a una más óptima para flux kontext.", "display_name": "EscalaImagenFluxKontext", "inputs": { "image": { "name": "imagen" } }, "outputs": { "0": { "tooltip": null } } };
const FluxKontextMaxImageNode = { "description": "Edita imágenes usando Flux.1 Kontext [máx] mediante API basado en prompt y relación de aspecto.", "display_name": "Imagen Flux.1 Kontext [máx]", "inputs": { "aspect_ratio": { "name": "relación_aspecto", "tooltip": "Relación de aspecto de la imagen; debe estar entre 1:4 y 4:1." }, "control_after_generate": { "name": "control después de generar" }, "guidance": { "name": "guía", "tooltip": "Intensidad de guía para el proceso de generación de imagen" }, "input_image": { "name": "imagen_entrada" }, "prompt": { "name": "prompt", "tooltip": "Prompt para la generación de imagen - especifica qué y cómo editar." }, "prompt_upsampling": { "name": "muestreo_prompt", "tooltip": "Si realizar muestreo en el prompt. Si está activo, modifica automáticamente el prompt para una generación más creativa, pero los resultados son no deterministas (la misma semilla no producirá exactamente el mismo resultado)." }, "seed": { "name": "semilla", "tooltip": "La semilla aleatoria utilizada para crear el ruido." }, "steps": { "name": "pasos", "tooltip": "Número de pasos para el proceso de generación de imagen" } }, "outputs": { "0": { "tooltip": null } } };
const FluxKontextMultiReferenceLatentMethod = { "display_name": "MétodoLatenteReferenciaMúltipleFluxKontext", "inputs": { "conditioning": { "name": "acondicionamiento" }, "reference_latents_method": { "name": "método_latentes_referencia" } }, "outputs": { "0": { "tooltip": null } } };
const FluxKontextProImageNode = { "description": "Edita imágenes usando Flux.1 Kontext [pro] mediante API basado en prompt y relación de aspecto.", "display_name": "Imagen Flux.1 Kontext [pro]", "inputs": { "aspect_ratio": { "name": "relación_aspecto", "tooltip": "Relación de aspecto de la imagen; debe estar entre 1:4 y 4:1." }, "control_after_generate": { "name": "control después de generar" }, "guidance": { "name": "guía", "tooltip": "Intensidad de guía para el proceso de generación de imágenes" }, "input_image": { "name": "imagen de entrada" }, "prompt": { "name": "prompt", "tooltip": "Prompt para la generación de imagen - especifica qué y cómo editar." }, "prompt_upsampling": { "name": "remuestreo del prompt", "tooltip": "Si realizar remuestreo en el prompt. Si está activo, modifica automáticamente el prompt para una generación más creativa, pero los resultados son no deterministas (la misma semilla no producirá exactamente el mismo resultado)." }, "seed": { "name": "semilla", "tooltip": "La semilla aleatoria utilizada para crear el ruido." }, "steps": { "name": "pasos", "tooltip": "Número de pasos para el proceso de generación de imágenes" } }, "outputs": { "0": { "tooltip": null } } };
const FluxProExpandNode = { "description": "Expande la imagen según el prompt.", "display_name": "Flux.1 Expandir imagen", "inputs": { "bottom": { "name": "abajo", "tooltip": "Número de píxeles a expandir en la parte inferior de la imagen" }, "control_after_generate": { "name": "control después de generar" }, "guidance": { "name": "guía", "tooltip": "Fuerza de la guía para el proceso de generación de imagen" }, "image": { "name": "imagen" }, "left": { "name": "izquierda", "tooltip": "Número de píxeles a expandir en el lado izquierdo de la imagen" }, "prompt": { "name": "prompt", "tooltip": "Prompt para la generación de la imagen" }, "prompt_upsampling": { "name": "reescaleado de prompt", "tooltip": "Si se realiza reescaleado en el prompt. Si está activo, modifica automáticamente el prompt para una generación más creativa, pero los resultados son no deterministas (la misma semilla no producirá exactamente el mismo resultado)." }, "right": { "name": "derecha", "tooltip": "Número de píxeles a expandir en el lado derecho de la imagen" }, "seed": { "name": "semilla", "tooltip": "La semilla aleatoria utilizada para crear el ruido." }, "steps": { "name": "pasos", "tooltip": "Número de pasos para el proceso de generación de imagen" }, "top": { "name": "arriba", "tooltip": "Número de píxeles a expandir en la parte superior de la imagen" } }, "outputs": { "0": { "tooltip": null } } };
const FluxProFillNode = { "description": "Rellena la imagen según la mask y el prompt.", "display_name": "Flux.1 Rellenar Imagen", "inputs": { "control_after_generate": { "name": "controlar después de generar" }, "guidance": { "name": "guía", "tooltip": "Fuerza de la guía para el proceso de generación de imagen" }, "image": { "name": "imagen" }, "mask": { "name": "mask" }, "prompt": { "name": "prompt", "tooltip": "Prompt para la generación de la imagen" }, "prompt_upsampling": { "name": "re-muestreo de prompt", "tooltip": "Indica si se realiza re-muestreo en el prompt. Si está activo, modifica automáticamente el prompt para una generación más creativa, pero los resultados no son deterministas (la misma semilla no producirá exactamente el mismo resultado)." }, "seed": { "name": "semilla", "tooltip": "La semilla aleatoria utilizada para crear el ruido." }, "steps": { "name": "pasos", "tooltip": "Número de pasos para el proceso de generación de imagen" } }, "outputs": { "0": { "tooltip": null } } };
const FluxProUltraImageNode = { "description": "Genera imágenes usando Flux Pro 1.1 Ultra vía API basado en el prompt y la resolución.", "display_name": "Flux 1.1 [pro] Ultra Image", "inputs": { "aspect_ratio": { "name": "aspect_ratio", "tooltip": "Relación de aspecto de la imagen; debe estar entre 1:4 y 4:1." }, "control_after_generate": { "name": "control after generate" }, "image_prompt": { "name": "image_prompt" }, "image_prompt_strength": { "name": "image_prompt_strength", "tooltip": "Mezcla entre el prompt y el image prompt." }, "prompt": { "name": "prompt", "tooltip": "Prompt para la generación de la imagen" }, "prompt_upsampling": { "name": "prompt_upsampling", "tooltip": "Indica si se realiza upsampling en el prompt. Si está activo, modifica automáticamente el prompt para una generación más creativa, pero los resultados son no deterministas (la misma semilla no producirá exactamente el mismo resultado)." }, "raw": { "name": "raw", "tooltip": "Cuando es Verdadero, genera imágenes menos procesadas y de aspecto más natural." }, "seed": { "name": "seed", "tooltip": "La semilla aleatoria utilizada para crear el ruido." } }, "outputs": { "0": { "tooltip": null } } };
const FreSca = { "description": "Aplica un escalado dependiente de la frecuencia a la guía", "display_name": "FreSca", "inputs": { "freq_cutoff": { "name": "corte_frecuencia", "tooltip": "Número de índices de frecuencia alrededor del centro a considerar como baja frecuencia" }, "model": { "name": "modelo" }, "scale_high": { "name": "escala_alta", "tooltip": "Factor de escala para los componentes de alta frecuencia" }, "scale_low": { "name": "escala_baja", "tooltip": "Factor de escala para los componentes de baja frecuencia" } }, "outputs": { "0": { "tooltip": null } } };
const FreeU = { "display_name": "FreeU", "inputs": { "b1": { "name": "b1" }, "b2": { "name": "b2" }, "model": { "name": "modelo" }, "s1": { "name": "s1" }, "s2": { "name": "s2" } } };
const FreeU_V2 = { "display_name": "FreeU_V2", "inputs": { "b1": { "name": "b1" }, "b2": { "name": "b2" }, "model": { "name": "modelo" }, "s1": { "name": "s1" }, "s2": { "name": "s2" } } };
const GITSScheduler = { "display_name": "GITSScheduler", "inputs": { "coeff": { "name": "coef" }, "denoise": { "name": "denoise" }, "steps": { "name": "pasos" } }, "outputs": { "0": { "tooltip": null } } };
const GLIGENLoader = { "display_name": "GLIGENLoader", "inputs": { "gligen_name": { "name": "nombre_gligen" } } };
const GLIGENTextBoxApply = { "display_name": "GLIGENTextBoxApply", "inputs": { "clip": { "name": "clip" }, "conditioning_to": { "name": "acondicionamiento_a" }, "gligen_textbox_model": { "name": "modelo_caja_texto_gligen" }, "height": { "name": "altura" }, "text": { "name": "texto" }, "width": { "name": "ancho" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const GeminiImageNode = { "description": "Editar imágenes sincrónicamente mediante la API de Google.", "display_name": "Imagen de Google Gemini", "inputs": { "aspect_ratio": { "name": "relación de aspecto", "tooltip": "Por defecto, coincide con el tamaño de la imagen de salida con el de su imagen de entrada, o de lo contrario genera cuadrados 1:1." }, "control_after_generate": { "name": "control después de generar" }, "files": { "name": "archivos", "tooltip": "Archivo(s) opcional(es) para usar como contexto para el modelo. Acepta entradas desde el nodo Archivos de Entrada de Contenido Generado por Gemini." }, "images": { "name": "imágenes", "tooltip": "Imagen(es) opcional(es) para usar como contexto para el modelo. Para incluir múltiples imágenes, puede utilizar el nodo Imágenes por Lotes." }, "model": { "name": "modelo", "tooltip": "El modelo Gemini a utilizar para generar respuestas." }, "prompt": { "name": "prompt", "tooltip": "Prompt de texto para la generación" }, "seed": { "name": "semilla", "tooltip": "Cuando la semilla se fija a un valor específico, el modelo hace el mejor esfuerzo para proporcionar la misma respuesta para solicitudes repetidas. No se garantiza una salida determinista. Además, cambiar el modelo o la configuración de parámetros, como la temperatura, puede causar variaciones en la respuesta incluso cuando se utiliza el mismo valor de semilla. Por defecto, se utiliza un valor de semilla aleatorio." } }, "outputs": { "0": { "tooltip": null }, "1": { "tooltip": null } } };
const GeminiInputFiles = { "description": "Carga y prepara archivos de entrada para incluirlos como entradas para los nodos LLM de Gemini. Los archivos serán leídos por el modelo Gemini al generar una respuesta. El contenido del archivo de texto cuenta hacia el límite de tokens. 🛈 CONSEJO: Se puede encadenar con otros nodos de Archivos de Entrada de Gemini.", "display_name": "Archivos de Entrada de Gemini", "inputs": { "GEMINI_INPUT_FILES": { "name": "ARCHIVOS_DE_ENTRADA_GEMINI", "tooltip": "Un archivo(s) adicional(es) opcional(es) para agrupar junto con el archivo cargado desde este nodo. Permite encadenar archivos de entrada para que un solo mensaje pueda incluir múltiples archivos de entrada." }, "file": { "name": "archivo", "tooltip": "Archivos de entrada para incluir como contexto para el modelo. Por ahora solo acepta archivos de texto (.txt) y PDF (.pdf)." } }, "outputs": { "0": { "tooltip": null } } };
const GeminiNode = { "description": "Genera respuestas de texto con el modelo de IA Gemini de Google. Puede proporcionar múltiples tipos de entradas (texto, imágenes, audio, video) como contexto para generar respuestas más relevantes y significativas.", "display_name": "Google Gemini", "inputs": { "audio": { "name": "audio", "tooltip": "Audio opcional para usar como contexto para el modelo." }, "control_after_generate": { "name": "controlar después de generar" }, "files": { "name": "archivos", "tooltip": "Archivo(s) opcional(es) para usar como contexto para el modelo. Acepta entradas del nodo Archivos de Entrada de Contenido Generado por Gemini." }, "images": { "name": "imágenes", "tooltip": "Imagen(es) opcional(es) para usar como contexto para el modelo. Para incluir múltiples imágenes, puedes usar el nodo Imágenes por Lotes." }, "model": { "name": "modelo", "tooltip": "El modelo Gemini a utilizar para generar respuestas." }, "prompt": { "name": "prompt", "tooltip": "Entradas de texto al modelo, utilizadas para generar una respuesta. Puede incluir instrucciones detalladas, preguntas o contexto para el modelo." }, "seed": { "name": "semilla", "tooltip": "Cuando la semilla se fija a un valor específico, el modelo hace el mejor esfuerzo para proporcionar la misma respuesta para solicitudes repetidas. No se garantiza una salida determinista. Además, cambiar el modelo o la configuración de parámetros, como la temperatura, puede causar variaciones en la respuesta incluso cuando se utiliza el mismo valor de semilla. Por defecto, se utiliza un valor de semilla aleatorio." }, "video": { "name": "video", "tooltip": "Video opcional para usar como contexto para el modelo." } }, "outputs": { "0": { "tooltip": null } } };
const GetImageSize = { "description": "Devuelve el ancho y alto de la imagen, y la pasa sin cambios.", "display_name": "Obtener Tamaño de Imagen", "inputs": { "image": { "name": "imagen" } }, "outputs": { "0": { "name": "ancho" }, "1": { "name": "alto" }, "2": { "name": "tamaño_lote" } } };
const GetVideoComponents = { "description": "Extrae todos los componentes de un video: fotogramas, audio y velocidad de fotogramas.", "display_name": "Obtener componentes de video", "inputs": { "video": { "name": "video", "tooltip": "El video del que extraer los componentes." } }, "outputs": { "0": { "name": "imágenes", "tooltip": null }, "1": { "name": "audio", "tooltip": null }, "2": { "name": "fps", "tooltip": null } } };
const GrowMask = { "display_name": "GrowMask", "inputs": { "expand": { "name": "expandir" }, "mask": { "name": "máscara" }, "tapered_corners": { "name": "esquinas_afiladas" } } };
const Hunyuan3Dv2Conditioning = { "display_name": "Hunyuan3Dv2Conditioning", "inputs": { "clip_vision_output": { "name": "salida_vision_clip" } }, "outputs": { "0": { "name": "positivo" }, "1": { "name": "negativo" } } };
const Hunyuan3Dv2ConditioningMultiView = { "display_name": "Hunyuan3Dv2ConditioningMultiView", "inputs": { "back": { "name": "atrás" }, "front": { "name": "frente" }, "left": { "name": "izquierda" }, "right": { "name": "derecha" } }, "outputs": { "0": { "name": "positivo" }, "1": { "name": "negativo" } } };
const HunyuanImageToVideo = { "display_name": "HunyuanImageToVideo", "inputs": { "batch_size": { "name": "tamaño_del_lote" }, "guidance_type": { "name": "tipo_de_orientación" }, "height": { "name": "altura" }, "length": { "name": "longitud" }, "positive": { "name": "positivo" }, "start_image": { "name": "imagen_inicial" }, "vae": { "name": "vae" }, "width": { "name": "ancho" } }, "outputs": { "0": { "name": "positivo", "tooltip": null }, "1": { "name": "latente", "tooltip": null } } };
const HunyuanRefinerLatent = { "display_name": "HunyuanRefinerLatent", "inputs": { "latent": { "name": "latente" }, "negative": { "name": "negativo" }, "noise_augmentation": { "name": "aumento_ruido" }, "positive": { "name": "positivo" } }, "outputs": { "0": { "name": "positivo", "tooltip": null }, "1": { "name": "negativo", "tooltip": null }, "2": { "name": "latente", "tooltip": null } } };
const HyperTile = { "display_name": "HyperTile", "inputs": { "max_depth": { "name": "profundidad_máxima" }, "model": { "name": "modelo" }, "scale_depth": { "name": "escala_de_profundidad" }, "swap_size": { "name": "tamaño_de_intercambio" }, "tile_size": { "name": "tamaño_de_mosaico" } }, "outputs": { "0": { "tooltip": null } } };
const HypernetworkLoader = { "display_name": "CargadorHypernetwork", "inputs": { "hypernetwork_name": { "name": "nombre_hypernetwork" }, "model": { "name": "modelo" }, "strength": { "name": "fuerza" } }, "outputs": { "0": { "tooltip": null } } };
const IdeogramV1 = { "description": "Genera imágenes de forma sincrónica usando el modelo Ideogram V1.\n\nLos enlaces de las imágenes están disponibles por un período limitado; si deseas conservar la imagen, debes descargarla.", "display_name": "Ideogram V1", "inputs": { "aspect_ratio": { "name": "aspect_ratio", "tooltip": "La relación de aspecto para la generación de la imagen." }, "control_after_generate": { "name": "control after generate" }, "magic_prompt_option": { "name": "magic_prompt_option", "tooltip": "Determina si se debe usar MagicPrompt en la generación" }, "negative_prompt": { "name": "negative_prompt", "tooltip": "Descripción de lo que se debe excluir de la imagen" }, "num_images": { "name": "num_images" }, "prompt": { "name": "prompt", "tooltip": "Prompt para la generación de la imagen" }, "seed": { "name": "seed" }, "turbo": { "name": "turbo", "tooltip": "Indica si se debe usar el modo turbo (generación más rápida, potencialmente menor calidad)" } }, "outputs": { "0": { "tooltip": null } } };
const IdeogramV2 = { "description": "Genera imágenes de forma sincrónica usando el modelo Ideogram V2.\n\nLos enlaces de las imágenes están disponibles por un período limitado; si deseas conservar la imagen, debes descargarla.", "display_name": "Ideogram V2", "inputs": { "aspect_ratio": { "name": "aspect_ratio", "tooltip": "La relación de aspecto para la generación de la imagen. Se ignora si la resolución no está configurada en AUTO." }, "control_after_generate": { "name": "control after generate" }, "magic_prompt_option": { "name": "magic_prompt_option", "tooltip": "Determina si se debe usar MagicPrompt en la generación" }, "negative_prompt": { "name": "negative_prompt", "tooltip": "Descripción de lo que se debe excluir de la imagen" }, "num_images": { "name": "num_images" }, "prompt": { "name": "prompt", "tooltip": "Prompt para la generación de la imagen" }, "resolution": { "name": "resolution", "tooltip": "La resolución para la generación de la imagen. Si no está configurada en AUTO, esto sobrescribe el ajuste de aspect_ratio." }, "seed": { "name": "seed" }, "style_type": { "name": "style_type", "tooltip": "Tipo de estilo para la generación (solo V2)" }, "turbo": { "name": "turbo", "tooltip": "Indica si se debe usar el modo turbo (generación más rápida, potencialmente menor calidad)" } }, "outputs": { "0": { "tooltip": null } } };
const IdeogramV3 = { "description": "Genera imágenes de forma síncrona usando el modelo Ideogram V3.\n\nAdmite tanto la generación regular de imágenes a partir de indicaciones de texto como la edición de imágenes con mask.\nLos enlaces de las imágenes están disponibles por un período limitado; si deseas conservar la imagen, debes descargarla.", "display_name": "Ideogram V3", "inputs": { "aspect_ratio": { "name": "aspect_ratio", "tooltip": "La relación de aspecto para la generación de imagen. Se ignora si la resolución no está en Automático." }, "character_image": { "name": "imagen_personaje", "tooltip": "Imagen para usar como referencia del personaje." }, "character_mask": { "name": "máscara_personaje", "tooltip": "Máscara opcional para la imagen de referencia del personaje." }, "control_after_generate": { "name": "control after generate" }, "image": { "name": "image", "tooltip": "Imagen de referencia opcional para la edición de imagen." }, "magic_prompt_option": { "name": "magic_prompt_option", "tooltip": "Determina si MagicPrompt debe usarse en la generación" }, "mask": { "name": "mask", "tooltip": "Mask opcional para inpainting (las áreas blancas serán reemplazadas)" }, "num_images": { "name": "num_images" }, "prompt": { "name": "prompt", "tooltip": "Indicación para la generación o edición de la imagen" }, "rendering_speed": { "name": "rendering_speed", "tooltip": "Controla el equilibrio entre la velocidad de generación y la calidad" }, "resolution": { "name": "resolution", "tooltip": "La resolución para la generación de imagen. Si no está en Automático, esto sobrescribe la configuración de aspect_ratio." }, "seed": { "name": "seed" } }, "outputs": { "0": { "tooltip": null } } };
const ImageAddNoise = { "display_name": "ImagenAgregarRuido", "inputs": { "control_after_generate": { "name": "controlar después de generar" }, "image": { "name": "imagen" }, "seed": { "name": "semilla", "tooltip": "La semilla aleatoria utilizada para crear el ruido." }, "strength": { "name": "intensidad" } } };
const ImageBatch = { "display_name": "Lote de Imágenes", "inputs": { "image1": { "name": "imagen1" }, "image2": { "name": "imagen2" } } };
const ImageBlend = { "display_name": "Mezcla de Imágenes", "inputs": { "blend_factor": { "name": "factor_de_mezcla" }, "blend_mode": { "name": "modo_de_mezcla" }, "image1": { "name": "imagen1" }, "image2": { "name": "imagen2" } }, "outputs": { "0": { "tooltip": null } } };
const ImageBlur = { "display_name": "Desenfoque de Imagen", "inputs": { "blur_radius": { "name": "radio_de_desenfoque" }, "image": { "name": "imagen" }, "sigma": { "name": "sigma" } }, "outputs": { "0": { "tooltip": null } } };
const ImageColorToMask = { "display_name": "ImageColorToMask", "inputs": { "color": { "name": "color" }, "image": { "name": "imagen" } } };
const ImageCompositeMasked = { "display_name": "ImageCompositeMasked", "inputs": { "destination": { "name": "destino" }, "mask": { "name": "máscara" }, "resize_source": { "name": "redimensionar_fuente" }, "source": { "name": "fuente" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const ImageCrop = { "display_name": "Recorte de Imagen", "inputs": { "height": { "name": "altura" }, "image": { "name": "imagen" }, "width": { "name": "ancho" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const ImageFlip = { "display_name": "VoltearImagen", "inputs": { "flip_method": { "name": "método_volteo" }, "image": { "name": "imagen" } } };
const ImageFromBatch = { "display_name": "ImagenDeLote", "inputs": { "batch_index": { "name": "indice_lote" }, "image": { "name": "imagen" }, "length": { "name": "longitud" } } };
const ImageInvert = { "display_name": "Invertir Imagen", "inputs": { "image": { "name": "imagen" } } };
const ImageOnlyCheckpointLoader = { "display_name": "Cargador de Puntos de Control Solo de Imagen (modelo img2vid)", "inputs": { "ckpt_name": { "name": "nombre_ckpt" } } };
const ImageOnlyCheckpointSave = { "display_name": "GuardarPuntoDeControlSoloDeImagen", "inputs": { "clip_vision": { "name": "clip_vision" }, "filename_prefix": { "name": "prefijo_nombre_archivo" }, "model": { "name": "modelo" }, "vae": { "name": "vae" } } };
const ImagePadForOutpaint = { "display_name": "Rellenar Imagen para Pintar Fuera", "inputs": { "bottom": { "name": "abajo" }, "feathering": { "name": "difuminado" }, "image": { "name": "imagen" }, "left": { "name": "izquierda" }, "right": { "name": "derecha" }, "top": { "name": "arriba" } } };
const ImageQuantize = { "display_name": "Cuantizar Imagen", "inputs": { "colors": { "name": "colores" }, "dither": { "name": "difuminado" }, "image": { "name": "imagen" } }, "outputs": { "0": { "tooltip": null } } };
const ImageRGBToYUV = { "display_name": "ImageRGBToYUV", "inputs": { "image": { "name": "imagen" } }, "outputs": { "0": { "name": "Y", "tooltip": null }, "1": { "name": "U", "tooltip": null }, "2": { "name": "V", "tooltip": null } } };
const ImageRotate = { "display_name": "RotarImagen", "inputs": { "image": { "name": "imagen" }, "rotation": { "name": "rotación" } } };
const ImageScale = { "display_name": "Ampliar Imagen", "inputs": { "crop": { "name": "recorte" }, "height": { "name": "altura" }, "image": { "name": "imagen" }, "upscale_method": { "name": "metodo_ampliacion" }, "width": { "name": "ancho" } } };
const ImageScaleBy = { "display_name": "Ampliar Imagen Por", "inputs": { "image": { "name": "imagen" }, "scale_by": { "name": "escalar_por" }, "upscale_method": { "name": "metodo_ampliacion" } } };
const ImageScaleToMaxDimension = { "display_name": "EscalarImagenADimensiónMáxima", "inputs": { "image": { "name": "imagen" }, "largest_size": { "name": "tamaño_máximo" }, "upscale_method": { "name": "método_de_escalado" } } };
const ImageScaleToTotalPixels = { "display_name": "Escalar Imagen a Total de Pixeles", "inputs": { "image": { "name": "imagen" }, "megapixels": { "name": "megapixeles" }, "upscale_method": { "name": "metodo_ampliacion" } }, "outputs": { "0": { "tooltip": null } } };
const ImageSharpen = { "display_name": "Afinar Imagen", "inputs": { "alpha": { "name": "alfa" }, "image": { "name": "imagen" }, "sharpen_radius": { "name": "radio_afinado" }, "sigma": { "name": "sigma" } }, "outputs": { "0": { "tooltip": null } } };
const ImageStitch = { "description": "\nUne imagen2 a imagen1 en la dirección especificada.\nSi no se proporciona imagen2, devuelve imagen1 sin cambios.\nSe puede añadir espaciado opcional entre las imágenes.\n", "display_name": "Unión de Imágenes", "inputs": { "direction": { "name": "dirección" }, "image1": { "name": "imagen1" }, "image2": { "name": "imagen2" }, "match_image_size": { "name": "coincidir_tamaño_imagen" }, "spacing_color": { "name": "color_espaciado" }, "spacing_width": { "name": "ancho_espaciado" } } };
const ImageToMask = { "display_name": "Convertir Imagen a Máscara", "inputs": { "channel": { "name": "canal" }, "image": { "name": "imagen" } } };
const ImageUpscaleWithModel = { "display_name": "Ampliar Imagen (usando Modelo)", "inputs": { "image": { "name": "imagen" }, "upscale_model": { "name": "modelo_ampliacion" } }, "outputs": { "0": { "tooltip": null } } };
const ImageYUVToRGB = { "display_name": "ImageYUVToRGB", "inputs": { "U": { "name": "U" }, "V": { "name": "V" }, "Y": { "name": "Y" } }, "outputs": { "0": { "tooltip": null } } };
const InpaintModelConditioning = { "display_name": "InpaintModelConditioning", "inputs": { "mask": { "name": "máscara" }, "negative": { "name": "negativo" }, "noise_mask": { "name": "máscara de ruido", "tooltip": "Agrega una máscara de ruido al latente para que el muestreo solo ocurra dentro de la máscara. Puede mejorar los resultados o romper completamente las cosas dependiendo del modelo." }, "pixels": { "name": "píxeles" }, "positive": { "name": "positivo" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "positivo" }, "1": { "name": "negativo" }, "2": { "name": "latente" } } };
const InstructPixToPixConditioning = { "display_name": "InstructPixToPixConditioning", "inputs": { "negative": { "name": "negativo" }, "pixels": { "name": "píxeles" }, "positive": { "name": "positivo" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "positivo", "tooltip": null }, "1": { "name": "negativo", "tooltip": null }, "2": { "name": "latente", "tooltip": null } } };
const InvertMask = { "display_name": "InvertirMáscara", "inputs": { "mask": { "name": "máscara" } } };
const JoinImageWithAlpha = { "display_name": "Unir Imagen con Alfa", "inputs": { "alpha": { "name": "alfa" }, "image": { "name": "imagen" } }, "outputs": { "0": { "tooltip": null } } };
const KSampler = { "description": "Utiliza el modelo proporcionado, el acondicionamiento positivo y negativo para deshacer el ruido de la imagen latente.", "display_name": "KSampler", "inputs": { "cfg": { "name": "cfg", "tooltip": "La escala de Orientación Libre de Clasificador equilibra la creatividad y la adherencia al indicador. Los valores más altos resultan en imágenes que se asemejan más al indicador, sin embargo, valores demasiado altos afectarán negativamente la calidad." }, "control_after_generate": { "name": "control después de generar" }, "denoise": { "name": "deshacer_ruido", "tooltip": "La cantidad de eliminación de ruido aplicada, los valores más bajos mantendrán la estructura de la imagen inicial permitiendo el muestreo de imagen a imagen." }, "latent_image": { "name": "imagen_latente", "tooltip": "La imagen latente a deshacer el ruido." }, "model": { "name": "modelo", "tooltip": "El modelo utilizado para eliminar el ruido de la entrada latente." }, "negative": { "name": "negativo", "tooltip": "El acondicionamiento que describe los atributos que quieres excluir de la imagen." }, "positive": { "name": "positivo", "tooltip": "El acondicionamiento que describe los atributos que quieres incluir en la imagen." }, "sampler_name": { "name": "nombre_muestreador", "tooltip": "El algoritmo utilizado al muestrear, esto puede afectar la calidad, velocidad y estilo de la salida generada." }, "scheduler": { "name": "programador", "tooltip": "El programador controla cómo se elimina gradualmente el ruido para formar la imagen." }, "seed": { "name": "semilla", "tooltip": "La semilla aleatoria utilizada para crear el ruido." }, "steps": { "name": "pasos", "tooltip": "El número de pasos utilizados en el proceso de eliminación de ruido." } }, "outputs": { "0": { "tooltip": "El latente deshacer el ruido." } } };
const KSamplerAdvanced = { "display_name": "KSampler (Avanzado)", "inputs": { "add_noise": { "name": "añadir_ruido" }, "cfg": { "name": "cfg" }, "control_after_generate": { "name": "control_después_de_generar" }, "end_at_step": { "name": "terminar_en_paso" }, "latent_image": { "name": "imagen_latente" }, "model": { "name": "modelo" }, "negative": { "name": "negativo" }, "noise_seed": { "name": "semilla_de_ruido" }, "positive": { "name": "positivo" }, "return_with_leftover_noise": { "name": "devolver_con_ruido_sobrante" }, "sampler_name": { "name": "nombre_del_muestreador" }, "scheduler": { "name": "programador" }, "start_at_step": { "name": "comenzar_en_paso" }, "steps": { "name": "pasos" } } };
const KSamplerSelect = { "display_name": "KSamplerSelect", "inputs": { "sampler_name": { "name": "nombre_del_muestreador" } } };
const KarrasScheduler = { "display_name": "KarrasScheduler", "inputs": { "rho": { "name": "rho" }, "sigma_max": { "name": "sigma_max" }, "sigma_min": { "name": "sigma_min" }, "steps": { "name": "pasos" } } };
const KlingCameraControlI2VNode = { "description": "Transforma imágenes fijas en videos cinematográficos con movimientos de cámara profesionales que simulan la cinematografía del mundo real. Controla acciones de cámara virtual como zoom, rotación, paneo, inclinación y vista en primera persona, manteniendo el enfoque en tu imagen original.", "display_name": "Kling Imagen a Video (Control de Cámara)", "inputs": { "aspect_ratio": { "name": "aspect_ratio" }, "camera_control": { "name": "camera_control", "tooltip": "Puede ser creado usando el nodo Kling Camera Controls. Controla el movimiento y la acción de la cámara durante la generación del video." }, "cfg_scale": { "name": "cfg_scale" }, "negative_prompt": { "name": "negative_prompt", "tooltip": "Prompt de texto negativo" }, "prompt": { "name": "prompt", "tooltip": "Prompt de texto positivo" }, "start_frame": { "name": "start_frame", "tooltip": "Imagen de referencia - URL o cadena codificada en Base64, no puede exceder los 10MB, resolución no menor a 300*300px, relación de aspecto entre 1:2.5 ~ 2.5:1. Base64 no debe incluir el prefijo data:image." } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "video_id", "tooltip": null }, "2": { "name": "duration", "tooltip": null } } };
const KlingCameraControlT2VNode = { "description": "Transforma texto en videos cinematográficos con movimientos de cámara profesionales que simulan la cinematografía del mundo real. Controla acciones de cámara virtual como zoom, rotación, paneo, inclinación y vista en primera persona, manteniendo el enfoque en tu texto original.", "display_name": "Kling Texto a Video (Control de Cámara)", "inputs": { "aspect_ratio": { "name": "aspect_ratio" }, "camera_control": { "name": "camera_control", "tooltip": "Puede ser creado usando el nodo Kling Camera Controls. Controla el movimiento y la acción de la cámara durante la generación del video." }, "cfg_scale": { "name": "cfg_scale" }, "negative_prompt": { "name": "negative_prompt", "tooltip": "Prompt de texto negativo" }, "prompt": { "name": "prompt", "tooltip": "Prompt de texto positivo" } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "video_id", "tooltip": null }, "2": { "name": "duration", "tooltip": null } } };
const KlingCameraControls = { "description": "Permite especificar opciones de configuración para los Controles de Cámara Kling y efectos de control de movimiento.", "display_name": "Controles de Cámara Kling", "inputs": { "camera_control_type": { "name": "camera_control_type" }, "horizontal_movement": { "name": "horizontal_movement", "tooltip": "Controla el movimiento de la cámara a lo largo del eje horizontal (eje x). Negativo indica izquierda, positivo indica derecha." }, "pan": { "name": "pan", "tooltip": "Controla la rotación de la cámara en el plano vertical (eje x). Negativo indica rotación hacia abajo, positivo indica rotación hacia arriba." }, "roll": { "name": "roll", "tooltip": "Controla la cantidad de giro de la cámara (eje z). Negativo indica sentido antihorario, positivo indica sentido horario." }, "tilt": { "name": "tilt", "tooltip": "Controla la rotación de la cámara en el plano horizontal (eje y). Negativo indica rotación hacia la izquierda, positivo indica rotación hacia la derecha." }, "vertical_movement": { "name": "vertical_movement", "tooltip": "Controla el movimiento de la cámara a lo largo del eje vertical (eje y). Negativo indica hacia abajo, positivo indica hacia arriba." }, "zoom": { "name": "zoom", "tooltip": "Controla el cambio en la distancia focal de la cámara. Negativo indica un campo de visión más estrecho, positivo indica un campo de visión más amplio." } }, "outputs": { "0": { "name": "camera_control", "tooltip": null } } };
const KlingDualCharacterVideoEffectNode = { "description": "Logra diferentes efectos especiales al generar un video basado en el effect_scene. La primera imagen se posicionará en el lado izquierdo y la segunda en el lado derecho de la composición.", "display_name": "Efectos de Video de Doble Personaje Kling", "inputs": { "duration": { "name": "duración" }, "effect_scene": { "name": "effect_scene" }, "image_left": { "name": "imagen_izquierda", "tooltip": "Imagen del lado izquierdo" }, "image_right": { "name": "imagen_derecha", "tooltip": "Imagen del lado derecho" }, "mode": { "name": "modo" }, "model_name": { "name": "model_name" } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "duración", "tooltip": null } } };
const KlingImage2VideoNode = { "display_name": "Kling Imagen a Video", "inputs": { "aspect_ratio": { "name": "aspect_ratio" }, "cfg_scale": { "name": "cfg_scale" }, "duration": { "name": "duration" }, "mode": { "name": "mode" }, "model_name": { "name": "model_name" }, "negative_prompt": { "name": "negative_prompt", "tooltip": "Prompt de texto negativo" }, "prompt": { "name": "prompt", "tooltip": "Prompt de texto positivo" }, "start_frame": { "name": "start_frame", "tooltip": "Imagen de referencia - URL o cadena codificada en Base64, no puede exceder los 10MB, resolución no menor a 300*300px, relación de aspecto entre 1:2.5 ~ 2.5:1. El Base64 no debe incluir el prefijo data:image." } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "video_id", "tooltip": null }, "2": { "name": "duration", "tooltip": null } } };
const KlingImageGenerationNode = { "description": "Nodo de Generación de Imágenes Kling. Genera una imagen a partir de un prompt de texto con una imagen de referencia opcional.", "display_name": "Generación de Imágenes Kling", "inputs": { "aspect_ratio": { "name": "aspect_ratio" }, "human_fidelity": { "name": "human_fidelity", "tooltip": "Similitud de referencia del sujeto" }, "image": { "name": "image" }, "image_fidelity": { "name": "image_fidelity", "tooltip": "Intensidad de referencia para imágenes subidas por el usuario" }, "image_type": { "name": "image_type" }, "model_name": { "name": "model_name" }, "n": { "name": "n", "tooltip": "Número de imágenes generadas" }, "negative_prompt": { "name": "negative_prompt", "tooltip": "Prompt de texto negativo" }, "prompt": { "name": "prompt", "tooltip": "Prompt de texto positivo" } }, "outputs": { "0": { "tooltip": null } } };
const KlingLipSyncAudioToVideoNode = { "description": "Nodo de Sincronización Labial Kling de Audio a Video. Sincroniza los movimientos de la boca en un archivo de video con el contenido de audio de un archivo de audio.", "display_name": "Sincronización Labial Kling: Video con Audio", "inputs": { "audio": { "name": "audio" }, "video": { "name": "video" }, "voice_language": { "name": "idioma_de_voz" } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "id_de_video", "tooltip": null }, "2": { "name": "duración", "tooltip": null } } };
const KlingLipSyncTextToVideoNode = { "description": "Nodo Kling Lip Sync de Texto a Video. Sincroniza los movimientos de la boca en un archivo de video con un texto.", "display_name": "Sincronización Labial Kling Video con Texto", "inputs": { "text": { "name": "texto", "tooltip": "Contenido de texto para la generación de video con sincronización labial. Requerido cuando el modo es text2video. La longitud máxima es de 120 caracteres." }, "video": { "name": "video" }, "voice": { "name": "voz" }, "voice_speed": { "name": "velocidad_de_voz", "tooltip": "Velocidad del habla. Rango válido: 0.8~2.0, con una cifra decimal." } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "id_video", "tooltip": null }, "2": { "name": "duración", "tooltip": null } } };
const KlingSingleImageVideoEffectNode = { "description": "Logra diferentes efectos especiales al generar un video basado en el effect_scene.", "display_name": "Efectos de Video Kling", "inputs": { "duration": { "name": "duración" }, "effect_scene": { "name": "effect_scene" }, "image": { "name": "imagen", "tooltip": "Imagen de referencia. URL o cadena codificada en Base64 (sin el prefijo data:image). El tamaño del archivo no puede exceder los 10MB, la resolución no debe ser menor a 300*300px, y la relación de aspecto debe estar entre 1:2.5 y 2.5:1" }, "model_name": { "name": "model_name" } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "video_id", "tooltip": null }, "2": { "name": "duración", "tooltip": null } } };
const KlingStartEndFrameNode = { "description": "Genera una secuencia de video que transiciona entre las imágenes inicial y final proporcionadas. El nodo crea todos los fotogramas intermedios, produciendo una transformación suave desde el primer fotograma hasta el último.", "display_name": "Kling Fotograma Inicial-Final a Video", "inputs": { "aspect_ratio": { "name": "aspect_ratio" }, "cfg_scale": { "name": "cfg_scale" }, "end_frame": { "name": "end_frame", "tooltip": "Imagen de referencia - Control del fotograma final. URL o cadena codificada en Base64, no puede exceder los 10MB, resolución no menor a 300*300px. El Base64 no debe incluir el prefijo data:image." }, "mode": { "name": "mode", "tooltip": "La configuración a usar para la generación de video siguiendo el formato: modo / duración / nombre_del_modelo." }, "negative_prompt": { "name": "negative_prompt", "tooltip": "Prompt de texto negativo" }, "prompt": { "name": "prompt", "tooltip": "Prompt de texto positivo" }, "start_frame": { "name": "start_frame", "tooltip": "Imagen de referencia - URL o cadena codificada en Base64, no puede exceder los 10MB, resolución no menor a 300*300px, relación de aspecto entre 1:2.5 ~ 2.5:1. El Base64 no debe incluir el prefijo data:image." } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "video_id", "tooltip": null }, "2": { "name": "duration", "tooltip": null } } };
const KlingTextToVideoNode = { "description": "Nodo Kling Texto a Video", "display_name": "Kling Texto a Video", "inputs": { "aspect_ratio": { "name": "aspect_ratio" }, "cfg_scale": { "name": "cfg_scale" }, "mode": { "name": "mode", "tooltip": "La configuración a usar para la generación de video siguiendo el formato: modo / duración / nombre_del_modelo." }, "negative_prompt": { "name": "negative_prompt", "tooltip": "Prompt de texto negativo" }, "prompt": { "name": "prompt", "tooltip": "Prompt de texto positivo" } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "video_id", "tooltip": null }, "2": { "name": "duration", "tooltip": null } } };
const KlingVideoExtendNode = { "description": "Nodo Kling Video Extend. Extiende videos creados por otros nodos Kling. El video_id se crea utilizando otros nodos Kling.", "display_name": "Kling Video Extend", "inputs": { "cfg_scale": { "name": "cfg_scale" }, "negative_prompt": { "name": "negative_prompt", "tooltip": "Prompt de texto negativo para los elementos a evitar en el video extendido" }, "prompt": { "name": "prompt", "tooltip": "Prompt de texto positivo para guiar la extensión del video" }, "video_id": { "name": "video_id", "tooltip": "El ID del video a extender. Soporta videos generados por texto a video, imagen a video y operaciones previas de extensión de video. No puede exceder los 3 minutos de duración total después de la extensión." } }, "outputs": { "0": { "tooltip": null }, "1": { "name": "video_id", "tooltip": null }, "2": { "name": "duration", "tooltip": null } } };
const KlingVirtualTryOnNode = { "description": "Nodo Kling Virtual Try On. Ingresa una imagen de una persona y una imagen de una prenda para probar la prenda en la persona.", "display_name": "Kling Virtual Try On", "inputs": { "cloth_image": { "name": "cloth_image" }, "human_image": { "name": "human_image" }, "model_name": { "name": "model_name" } }, "outputs": { "0": { "tooltip": null } } };
const LTXVAddGuide = { "display_name": "LTXVAddGuide", "inputs": { "frame_idx": { "name": "indice_fotograma", "tooltip": "Índice de fotograma para comenzar la condición. Para imágenes de un solo fotograma o videos con 1-8 fotogramas, cualquier valor de indice_fotograma es aceptable. Para videos con 9+ fotogramas, indice_fotograma debe ser divisible por 8, de lo contrario se redondeará hacia abajo al múltiplo de 8 más cercano. Los valores negativos se cuentan desde el final del video." }, "image": { "name": "imagen", "tooltip": "Imagen o video para condicionar el video latente. Debe ser 8*n + 1 fotogramas. Si el video no es 8*n + 1 fotogramas, se recortará a los 8*n + 1 fotogramas más cercanos." }, "latent": { "name": "latente" }, "negative": { "name": "negativo" }, "positive": { "name": "positivo" }, "strength": { "name": "fuerza" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "positivo", "tooltip": null }, "1": { "name": "negativo", "tooltip": null }, "2": { "name": "latente", "tooltip": null } } };
const LTXVConditioning = { "display_name": "LTXVConditioning", "inputs": { "frame_rate": { "name": "tasa_fotogramas" }, "negative": { "name": "negativo" }, "positive": { "name": "positivo" } }, "outputs": { "0": { "name": "positivo", "tooltip": null }, "1": { "name": "negativo", "tooltip": null } } };
const LTXVCropGuides = { "display_name": "LTXVCropGuides", "inputs": { "latent": { "name": "latente" }, "negative": { "name": "negativo" }, "positive": { "name": "positivo" } }, "outputs": { "0": { "name": "positivo", "tooltip": null }, "1": { "name": "negativo", "tooltip": null }, "2": { "name": "latente", "tooltip": null } } };
const LTXVImgToVideo = { "display_name": "LTXVImgToVideo", "inputs": { "batch_size": { "name": "tamaño_lote" }, "height": { "name": "altura" }, "image": { "name": "imagen" }, "length": { "name": "longitud" }, "negative": { "name": "negativo" }, "positive": { "name": "positivo" }, "strength": { "name": "fuerza" }, "vae": { "name": "vae" }, "width": { "name": "ancho" } }, "outputs": { "0": { "name": "positivo", "tooltip": null }, "1": { "name": "negativo", "tooltip": null }, "2": { "name": "latente", "tooltip": null } } };
const LTXVPreprocess = { "display_name": "LTXVPreprocesar", "inputs": { "image": { "name": "imagen" }, "img_compression": { "name": "img_compresion", "tooltip": "Cantidad de compresión para aplicar en la imagen." } }, "outputs": { "0": { "name": "imagen_salida", "tooltip": null } } };
const LTXVScheduler = { "display_name": "LTXVProgramador", "inputs": { "base_shift": { "name": "base_desplazamiento" }, "latent": { "name": "latente" }, "max_shift": { "name": "max_desplazamiento" }, "steps": { "name": "pasos" }, "stretch": { "name": "estiramiento", "tooltip": "Estira las sigmas para estar en el rango [terminal, 1]." }, "terminal": { "name": "terminal", "tooltip": "El valor terminal de las sigmas después del estiramiento." } }, "outputs": { "0": { "tooltip": null } } };
const LaplaceScheduler = { "display_name": "LaplaceScheduler", "inputs": { "beta": { "name": "beta" }, "mu": { "name": "mu" }, "sigma_max": { "name": "sigma_max" }, "sigma_min": { "name": "sigma_min" }, "steps": { "name": "pasos" } } };
const LatentAdd = { "display_name": "LatentAdd", "inputs": { "samples1": { "name": "muestras1" }, "samples2": { "name": "muestras2" } }, "outputs": { "0": { "tooltip": null } } };
const LatentApplyOperation = { "display_name": "LatentApplyOperation", "inputs": { "operation": { "name": "operación" }, "samples": { "name": "muestras" } }, "outputs": { "0": { "tooltip": null } } };
const LatentApplyOperationCFG = { "display_name": "LatentApplyOperationCFG", "inputs": { "model": { "name": "modelo" }, "operation": { "name": "operación" } }, "outputs": { "0": { "tooltip": null } } };
const LatentBatch = { "display_name": "LatentBatch", "inputs": { "samples1": { "name": "muestras1" }, "samples2": { "name": "muestras2" } }, "outputs": { "0": { "tooltip": null } } };
const LatentBatchSeedBehavior = { "display_name": "LatentBatchSeedBehavior", "inputs": { "samples": { "name": "muestras" }, "seed_behavior": { "name": "comportamiento_de_semilla" } }, "outputs": { "0": { "tooltip": null } } };
const LatentBlend = { "display_name": "Mezcla Latente", "inputs": { "blend_factor": { "name": "factor_de_mezcla" }, "samples1": { "name": "muestras1" }, "samples2": { "name": "muestras2" } } };
const LatentComposite = { "display_name": "Compuesto Latente", "inputs": { "feather": { "name": "pluma" }, "samples_from": { "name": "muestras_de" }, "samples_to": { "name": "muestras_a" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const LatentCompositeMasked = { "display_name": "CompuestoLatenteEnmascarado", "inputs": { "destination": { "name": "destino" }, "mask": { "name": "máscara" }, "resize_source": { "name": "redimensionar_fuente" }, "source": { "name": "fuente" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const LatentConcat = { "display_name": "ConcatenaciónLatente", "inputs": { "dim": { "name": "dimensión" }, "samples1": { "name": "muestras1" }, "samples2": { "name": "muestras2" } }, "outputs": { "0": { "tooltip": null } } };
const LatentCrop = { "display_name": "Recortar Latente", "inputs": { "height": { "name": "altura" }, "samples": { "name": "muestras" }, "width": { "name": "ancho" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const LatentCut = { "display_name": "CorteLatente", "inputs": { "amount": { "name": "cantidad" }, "dim": { "name": "dimensión" }, "index": { "name": "índice" }, "samples": { "name": "muestras" } }, "outputs": { "0": { "tooltip": null } } };
const LatentFlip = { "display_name": "Voltear Latente", "inputs": { "flip_method": { "name": "método_volteo" }, "samples": { "name": "muestras" } } };
const LatentFromBatch = { "display_name": "Latente De Lote", "inputs": { "batch_index": { "name": "índice_lote" }, "length": { "name": "longitud" }, "samples": { "name": "muestras" } } };
const LatentInterpolate = { "display_name": "Interpolar Latente", "inputs": { "ratio": { "name": "proporción" }, "samples1": { "name": "muestras1" }, "samples2": { "name": "muestras2" } }, "outputs": { "0": { "tooltip": null } } };
const LatentMultiply = { "display_name": "Multiplicar Latente", "inputs": { "multiplier": { "name": "multiplicador" }, "samples": { "name": "muestras" } }, "outputs": { "0": { "tooltip": null } } };
const LatentOperationSharpen = { "display_name": "OperaciónAfiladoLatente", "inputs": { "alpha": { "name": "alfa" }, "sharpen_radius": { "name": "radio_afilado" }, "sigma": { "name": "sigma" } }, "outputs": { "0": { "tooltip": null } } };
const LatentOperationTonemapReinhard = { "display_name": "OperaciónTonemapReinhardLatente", "inputs": { "multiplier": { "name": "multiplicador" } }, "outputs": { "0": { "tooltip": null } } };
const LatentRotate = { "display_name": "Rotar Latente", "inputs": { "rotation": { "name": "rotación" }, "samples": { "name": "muestras" } } };
const LatentSubtract = { "display_name": "Restar Latente", "inputs": { "samples1": { "name": "muestras1" }, "samples2": { "name": "muestras2" } }, "outputs": { "0": { "tooltip": null } } };
const LatentUpscale = { "display_name": "Escalar Latente", "inputs": { "crop": { "name": "recorte" }, "height": { "name": "altura" }, "samples": { "name": "muestras" }, "upscale_method": { "name": "método_escala" }, "width": { "name": "ancho" } } };
const LatentUpscaleBy = { "display_name": "Escalar Latente Por", "inputs": { "samples": { "name": "muestras" }, "scale_by": { "name": "escalar_por" }, "upscale_method": { "name": "método_escala" } } };
const LazyCache = { "description": "Una versión casera de EasyCache - versión 'más fácil' de EasyCache para implementar. En general funciona peor que EasyCache, pero mejor en algunos casos raros Y compatibilidad universal con todo en ComfyUI.", "display_name": "CachéPerezoso", "inputs": { "end_percent": { "name": "porcentaje_fin", "tooltip": "El paso de muestreo relativo para finalizar el uso de CachéPerezoso." }, "model": { "name": "modelo", "tooltip": "El modelo al que añadir CachéPerezoso." }, "reuse_threshold": { "name": "umbral_reutilización", "tooltip": "El umbral para reutilizar pasos en caché." }, "start_percent": { "name": "porcentaje_inicio", "tooltip": "El paso de muestreo relativo para comenzar el uso de CachéPerezoso." }, "verbose": { "name": "detallado", "tooltip": "Si se debe registrar información detallada." } }, "outputs": { "0": { "tooltip": "El modelo con CachéPerezoso." } } };
const Load3D = { "display_name": "Cargar 3D", "inputs": { "clear": {}, "height": { "name": "alto" }, "image": { "name": "imagen" }, "model_file": { "name": "archivo_modelo" }, "upload 3d model": {}, "width": { "name": "ancho" } }, "outputs": { "0": { "name": "imagen" }, "1": { "name": "mask" }, "2": { "name": "ruta_malla" }, "3": { "name": "normal" }, "4": { "name": "lineart" }, "5": { "name": "info_cámara" } } };
const LoadAudio = { "display_name": "CargarAudio", "inputs": { "audio": { "name": "audio" }, "audioUI": { "name": "audioUI" }, "upload": { "name": "elige archivo para subir" } } };
const LoadImage = { "display_name": "Cargar Imagen", "inputs": { "image": { "name": "imagen" }, "upload": { "name": "elige archivo para subir" } } };
const LoadImageMask = { "display_name": "Cargar Imagen (como Máscara)", "inputs": { "channel": { "name": "canal" }, "image": { "name": "imagen" }, "upload": { "name": "elige archivo para subir" } } };
const LoadImageOutput = { "description": "Carga una imagen desde la carpeta de salida. Cuando se hace clic en el botón de actualizar, el nodo actualizará la lista de imágenes y seleccionará automáticamente la primera imagen, permitiendo una fácil iteración.", "display_name": "Cargar Imagen (desde Salidas)", "inputs": { "image": { "name": "imagen" }, "refresh": {}, "upload": { "name": "elige archivo para subir" } } };
const LoadLatent = { "display_name": "CargarLatente", "inputs": { "latent": { "name": "latente" } } };
const LoadVideo = { "display_name": "Cargar video", "inputs": { "file": { "name": "archivo" }, "upload": { "name": "elegir archivo para subir" } }, "outputs": { "0": { "tooltip": null } } };
const LoraLoader = { "description": "Las LoRAs se utilizan para modificar los modelos de difusión y CLIP, alterando la forma en que se desruidan los latentes, como la aplicación de estilos. Se pueden vincular varios nodos de LoRA.", "display_name": "Cargar LoRA", "inputs": { "clip": { "name": "clip", "tooltip": "El modelo CLIP al que se aplicará la LoRA." }, "lora_name": { "name": "nombre_lora", "tooltip": "El nombre de la LoRA." }, "model": { "name": "modelo", "tooltip": "El modelo de difusión al que se aplicará la LoRA." }, "strength_clip": { "name": "fuerza_clip", "tooltip": "Cuánto modificar el modelo CLIP. Este valor puede ser negativo." }, "strength_model": { "name": "fuerza_modelo", "tooltip": "Cuánto modificar el modelo de difusión. Este valor puede ser negativo." } }, "outputs": { "0": { "tooltip": "El modelo de difusión modificado." }, "1": { "tooltip": "El modelo CLIP modificado." } } };
const LoraLoaderModelOnly = { "description": "Las LoRAs se utilizan para modificar los modelos de difusión y CLIP, alterando la forma en que se desruidan los latentes, como la aplicación de estilos. Se pueden vincular varios nodos de LoRA.", "display_name": "CargadorLoRAModeloSolo", "inputs": { "lora_name": { "name": "nombre_lora" }, "model": { "name": "modelo" }, "strength_model": { "name": "fuerza_modelo" } }, "outputs": { "0": { "tooltip": "El modelo de difusión modificado." } } };
const LoraModelLoader = { "display_name": "Cargar Modelo LoRA", "inputs": { "lora": { "name": "lora", "tooltip": "El modelo LoRA a aplicar al modelo de difusión." }, "model": { "name": "modelo", "tooltip": "El modelo de difusión al que se aplicará el LoRA." }, "strength_model": { "name": "fuerza_modelo", "tooltip": "Qué tan fuerte modificar el modelo de difusión. Este valor puede ser negativo." } }, "outputs": { "0": { "tooltip": "El modelo de difusión modificado." } } };
const LoraSave = { "display_name": "Extraer y Guardar Lora", "inputs": { "bias_diff": { "name": "diferencia_sesgo" }, "filename_prefix": { "name": "prefijo_nombre_archivo" }, "lora_type": { "name": "tipo_lora" }, "model_diff": { "name": "diferencia_modelo", "tooltip": "La salida de ModelSubtract para ser convertida a una lora." }, "rank": { "name": "rango" }, "text_encoder_diff": { "name": "diferencia_codificador_texto", "tooltip": "La salida de CLIPSubtract para ser convertida a una lora." } } };
const LossGraphNode = { "display_name": "Graficar Pérdida", "inputs": { "filename_prefix": { "name": "prefijo_nombre_archivo" }, "loss": { "name": "pérdida" } } };
const LotusConditioning = { "display_name": "LotusConditioning", "outputs": { "0": { "name": "condicionamiento", "tooltip": null } } };
const LtxvApiImageToVideo = { "description": "Videos de calidad profesional con duración y resolución personalizables basados en la imagen inicial.", "display_name": "LTXV Imagen a Video", "inputs": { "duration": { "name": "duración" }, "fps": { "name": "fps" }, "generate_audio": { "name": "generar_audio", "tooltip": "Cuando es verdadero, el video generado incluirá audio generado por IA que coincide con la escena." }, "image": { "name": "imagen", "tooltip": "Primer fotograma a utilizar para el video." }, "model": { "name": "modelo" }, "prompt": { "name": "prompt" }, "resolution": { "name": "resolución" } }, "outputs": { "0": { "tooltip": null } } };
const LtxvApiTextToVideo = { "description": "Videos de calidad profesional con duración y resolución personalizables.", "display_name": "LTXV Texto a Video", "inputs": { "duration": { "name": "duración" }, "fps": { "name": "fps" }, "generate_audio": { "name": "generar_audio", "tooltip": "Cuando es verdadero, el video generado incluirá audio generado por IA que coincida con la escena." }, "model": { "name": "modelo" }, "prompt": { "name": "prompt" }, "resolution": { "name": "resolución" } }, "outputs": { "0": { "tooltip": null } } };
const LumaConceptsNode = { "description": "Contiene uno o más Conceptos de Cámara para usar con los nodos Luma Text to Video y Luma Image to Video.", "display_name": "Luma Concepts", "inputs": { "concept1": { "name": "concept1" }, "concept2": { "name": "concept2" }, "concept3": { "name": "concept3" }, "concept4": { "name": "concept4" }, "luma_concepts": { "name": "luma_concepts", "tooltip": "Conceptos de Cámara opcionales para añadir a los seleccionados aquí." } }, "outputs": { "0": { "name": "luma_concepts", "tooltip": null } } };
const LumaImageModifyNode = { "description": "Modifica imágenes de forma sincrónica según el prompt y la relación de aspecto.", "display_name": "Luma Imagen a Imagen", "inputs": { "control_after_generate": { "name": "controlar después de generar" }, "image": { "name": "imagen" }, "image_weight": { "name": "peso_imagen", "tooltip": "Peso de la imagen; cuanto más cerca de 1.0, menos se modificará la imagen." }, "model": { "name": "modelo" }, "prompt": { "name": "prompt", "tooltip": "Prompt para la generación de la imagen" }, "seed": { "name": "semilla", "tooltip": "Semilla para determinar si el nodo debe ejecutarse de nuevo; los resultados reales son no deterministas independientemente de la semilla." } }, "outputs": { "0": { "tooltip": null } } };
const LumaImageNode = { "description": "Genera imágenes de forma sincrónica según el prompt y la relación de aspecto.", "display_name": "Luma Texto a Imagen", "inputs": { "aspect_ratio": { "name": "aspect_ratio" }, "character_image": { "name": "character_image", "tooltip": "Imágenes de referencia de personaje; puede ser un lote de varias, se pueden considerar hasta 4 imágenes." }, "control_after_generate": { "name": "control after generate" }, "image_luma_ref": { "name": "image_luma_ref", "tooltip": "Conexión de nodo de referencia Luma para influir en la generación con imágenes de entrada; se pueden considerar hasta 4 imágenes." }, "model": { "name": "model" }, "prompt": { "name": "prompt", "tooltip": "Prompt para la generación de la imagen" }, "seed": { "name": "seed", "tooltip": "Semilla para determinar si el nodo debe ejecutarse de nuevo; los resultados reales son no deterministas independientemente de la semilla." }, "style_image": { "name": "style_image", "tooltip": "Imagen de referencia de estilo; solo se usará 1 imagen." }, "style_image_weight": { "name": "style_image_weight", "tooltip": "Peso de la imagen de estilo. Se ignora si no se proporciona style_image." } }, "outputs": { "0": { "tooltip": null } } };
const LumaImageToVideoNode = { "description": "Genera videos de forma sincrónica basados en el prompt, imágenes de entrada y output_size.", "display_name": "Luma Image to Video", "inputs": { "control_after_generate": { "name": "control después de generar" }, "duration": { "name": "duración" }, "first_image": { "name": "primera_imagen", "tooltip": "Primer fotograma del video generado." }, "last_image": { "name": "última_imagen", "tooltip": "Último fotograma del video generado." }, "loop": { "name": "bucle" }, "luma_concepts": { "name": "luma_concepts", "tooltip": "Conceptos de cámara opcionales para dictar el movimiento de cámara a través del nodo Luma Concepts." }, "model": { "name": "model" }, "prompt": { "name": "prompt", "tooltip": "Prompt para la generación de video" }, "resolution": { "name": "resolución" }, "seed": { "name": "semilla", "tooltip": "Semilla para determinar si el nodo debe ejecutarse de nuevo; los resultados reales son no deterministas independientemente de la semilla." } }, "outputs": { "0": { "tooltip": null } } };
const LumaReferenceNode = { "description": "Contiene una imagen y un peso para usar con el nodo Luma Generate Image.", "display_name": "Referencia Luma", "inputs": { "image": { "name": "imagen", "tooltip": "Imagen a usar como referencia." }, "luma_ref": { "name": "luma_ref" }, "weight": { "name": "peso", "tooltip": "Peso de la referencia de imagen." } }, "outputs": { "0": { "name": "luma_ref", "tooltip": null } } };
const LumaVideoNode = { "description": "Genera videos de forma sincrónica según el prompt y el tamaño de salida.", "display_name": "Luma Texto a Video", "inputs": { "aspect_ratio": { "name": "relación de aspecto" }, "control_after_generate": { "name": "control después de generar" }, "duration": { "name": "duración" }, "loop": { "name": "bucle" }, "luma_concepts": { "name": "luma_concepts", "tooltip": "Conceptos de cámara opcionales para dictar el movimiento de cámara a través del nodo Luma Concepts." }, "model": { "name": "modelo" }, "prompt": { "name": "prompt", "tooltip": "Prompt para la generación de video" }, "resolution": { "name": "resolución" }, "seed": { "name": "semilla", "tooltip": "Semilla para determinar si el nodo debe ejecutarse de nuevo; los resultados reales son no deterministas independientemente de la semilla." } }, "outputs": { "0": { "tooltip": null } } };
const Mahiro = { "description": "Modifica la guía para escalar más en la 'dirección' del indicador positivo en lugar de la diferencia entre el indicador negativo.", "display_name": "¡Mahiro es tan linda que merece una mejor función de guía!! (。・ω・。)", "inputs": { "model": { "name": "modelo" } }, "outputs": { "0": { "name": "modelo_parcheado", "tooltip": null } } };
const MaskComposite = { "display_name": "Composición de Máscara", "inputs": { "destination": { "name": "destino" }, "operation": { "name": "operación" }, "source": { "name": "fuente" }, "x": { "name": "x" }, "y": { "name": "y" } } };
const MaskPreview = { "description": "Guarda las imágenes de entrada en tu directorio de salida de ComfyUI.", "display_name": "MaskPreview", "inputs": { "mask": { "name": "mask" } } };
const MaskToImage = { "display_name": "Convertir Máscara a Imagen", "inputs": { "mask": { "name": "máscara" } } };
const MinimaxHailuoVideoNode = { "description": "Genera videos a partir de un prompt, con opción de usar un fotograma inicial utilizando el nuevo modelo MiniMax Hailuo-02.", "display_name": "MiniMax Hailuo Video", "inputs": { "control_after_generate": { "name": "controlar después de generar" }, "duration": { "name": "duración", "tooltip": "La longitud del video de salida en segundos." }, "first_frame_image": { "name": "imagen_primer_fotograma", "tooltip": "Imagen opcional para usar como primer fotograma y generar un video." }, "prompt_optimizer": { "name": "optimizador_de_prompt", "tooltip": "Optimiza el prompt para mejorar la calidad de generación cuando sea necesario." }, "prompt_text": { "name": "texto_del_prompt", "tooltip": "Prompt de texto para guiar la generación del video." }, "resolution": { "name": "resolución", "tooltip": "Las dimensiones de la pantalla del video. 1080p es 1920x1080, 768p es 1366x768." }, "seed": { "name": "semilla", "tooltip": "La semilla aleatoria utilizada para crear el ruido." } }, "outputs": { "0": { "tooltip": null } } };
const MinimaxImageToVideoNode = { "description": "Genera videos a partir de una imagen y prompts usando la API de MiniMax", "display_name": "MiniMax Imagen a Video", "inputs": { "control_after_generate": { "name": "control después de generar" }, "image": { "name": "imagen", "tooltip": "Imagen a usar como primer fotograma de la generación de video" }, "model": { "name": "modelo", "tooltip": "Modelo a usar para la generación de video" }, "prompt_text": { "name": "texto de prompt", "tooltip": "Prompt de texto para guiar la generación de video" }, "seed": { "name": "semilla", "tooltip": "La semilla aleatoria utilizada para crear el ruido." } }, "outputs": { "0": { "tooltip": null } } };
const MinimaxTextToVideoNode = { "description": "Genera videos a partir de indicaciones usando la API de MiniMax", "display_name": "MiniMax Texto a Video", "inputs": { "control_after_generate": { "name": "controlar después de generar" }, "model": { "name": "modelo", "tooltip": "Modelo a utilizar para la generación de video" }, "prompt_text": { "name": "texto_de_indicación", "tooltip": "Texto de indicación para guiar la generación del video" }, "seed": { "name": "semilla", "tooltip": "La semilla aleatoria utilizada para crear el ruido." } }, "outputs": { "0": { "tooltip": null } } };
const ModelComputeDtype = { "display_name": "ModeloCalcularDtype", "inputs": { "dtype": { "name": "dtype" }, "model": { "name": "modelo" } } };
const ModelMergeAdd = { "display_name": "ModeloFusionarAgregar", "inputs": { "model1": { "name": "modelo1" }, "model2": { "name": "modelo2" } } };
const ModelMergeAuraflow = { "display_name": "ModelMergeAuraflow", "inputs": { "cond_seq_linear_": { "name": "cond_seq_linear." }, "double_layers_0_": { "name": "capas_dobles.0." }, "double_layers_1_": { "name": "capas_dobles.1." }, "double_layers_2_": { "name": "capas_dobles.2." }, "double_layers_3_": { "name": "capas_dobles.3." }, "final_linear_": { "name": "final_linear." }, "init_x_linear_": { "name": "init_x_linear." }, "modF_": { "name": "modF." }, "model1": { "name": "modelo1" }, "model2": { "name": "modelo2" }, "positional_encoding": { "name": "codificación_posicional" }, "register_tokens": { "name": "registrar_tokens" }, "single_layers_0_": { "name": "capas_simples.0." }, "single_layers_10_": { "name": "capas_simples.10." }, "single_layers_11_": { "name": "capas_simples.11." }, "single_layers_12_": { "name": "capas_simples.12." }, "single_layers_13_": { "name": "capas_simples.13." }, "single_layers_14_": { "name": "capas_simples.14." }, "single_layers_15_": { "name": "capas_simples.15." }, "single_layers_16_": { "name": "capas_simples.16." }, "single_layers_17_": { "name": "capas_simples.17." }, "single_layers_18_": { "name": "capas_simples.18." }, "single_layers_19_": { "name": "capas_simples.19." }, "single_layers_1_": { "name": "capas_simples.1." }, "single_layers_20_": { "name": "capas_simples.20." }, "single_layers_21_": { "name": "capas_simples.21." }, "single_layers_22_": { "name": "capas_simples.22." }, "single_layers_23_": { "name": "capas_simples.23." }, "single_layers_24_": { "name": "capas_simples.24." }, "single_layers_25_": { "name": "capas_simples.25." }, "single_layers_26_": { "name": "capas_simples.26." }, "single_layers_27_": { "name": "capas_simples.27." }, "single_layers_28_": { "name": "capas_simples.28." }, "single_layers_29_": { "name": "capas_simples.29." }, "single_layers_2_": { "name": "capas_simples.2." }, "single_layers_30_": { "name": "capas_simples.30." }, "single_layers_31_": { "name": "capas_simples.31." }, "single_layers_3_": { "name": "capas_simples.3." }, "single_layers_4_": { "name": "capas_simples.4." }, "single_layers_5_": { "name": "capas_simples.5." }, "single_layers_6_": { "name": "capas_simples.6." }, "single_layers_7_": { "name": "capas_simples.7." }, "single_layers_8_": { "name": "capas_simples.8." }, "single_layers_9_": { "name": "capas_simples.9." }, "t_embedder_": { "name": "t_embedder." } } };
const ModelMergeBlocks = { "display_name": "ModelMergeBlocks", "inputs": { "input": { "name": "entrada" }, "middle": { "name": "medio" }, "model1": { "name": "modelo1" }, "model2": { "name": "modelo2" }, "out": { "name": "salida" } } };
const ModelMergeCosmos14B = { "display_name": "ModelMergeCosmos14B", "inputs": { "affline_norm_": { "name": "affline_norm." }, "blocks_block0_": { "name": "blocks.block0." }, "blocks_block10_": { "name": "blocks.block10." }, "blocks_block11_": { "name": "blocks.block11." }, "blocks_block12_": { "name": "blocks.block12." }, "blocks_block13_": { "name": "blocks.block13." }, "blocks_block14_": { "name": "blocks.block14." }, "blocks_block15_": { "name": "blocks.block15." }, "blocks_block16_": { "name": "blocks.block16." }, "blocks_block17_": { "name": "blocks.block17." }, "blocks_block18_": { "name": "blocks.block18." }, "blocks_block19_": { "name": "blocks.block19." }, "blocks_block1_": { "name": "blocks.block1." }, "blocks_block20_": { "name": "blocks.block20." }, "blocks_block21_": { "name": "blocks.block21." }, "blocks_block22_": { "name": "blocks.block22." }, "blocks_block23_": { "name": "blocks.block23." }, "blocks_block24_": { "name": "blocks.block24." }, "blocks_block25_": { "name": "blocks.block25." }, "blocks_block26_": { "name": "blocks.block26." }, "blocks_block27_": { "name": "blocks.block27." }, "blocks_block28_": { "name": "blocks.block28." }, "blocks_block29_": { "name": "blocks.block29." }, "blocks_block2_": { "name": "blocks.block2." }, "blocks_block30_": { "name": "blocks.block30." }, "blocks_block31_": { "name": "blocks.block31." }, "blocks_block32_": { "name": "blocks.block32." }, "blocks_block33_": { "name": "blocks.block33." }, "blocks_block34_": { "name": "blocks.block34." }, "blocks_block35_": { "name": "final_layer." }, "blocks_block3_": { "name": "blocks.block3." }, "blocks_block4_": { "name": "blocks.block4." }, "blocks_block5_": { "name": "blocks.block5." }, "blocks_block6_": { "name": "blocks.block6." }, "blocks_block7_": { "name": "blocks.block7." }, "blocks_block8_": { "name": "blocks.block8." }, "blocks_block9_": { "name": "blocks.block9." }, "extra_pos_embedder_": { "name": "extra_pos_embedder." }, "final_layer_": { "name": "capa_final." }, "model1": { "name": "model1" }, "model2": { "name": "model2" }, "pos_embedder_": { "name": "pos_embedder." }, "t_embedder_": { "name": "t_embedder." }, "x_embedder_": { "name": "x_embedder." } } };
const ModelMergeCosmos7B = { "display_name": "ModelMergeCosmos7B", "inputs": { "affline_norm_": { "name": "affline_norm." }, "blocks_block0_": { "name": "blocks.block0." }, "blocks_block10_": { "name": "blocks.block10." }, "blocks_block11_": { "name": "blocks.block11." }, "blocks_block12_": { "name": "blocks.block12." }, "blocks_block13_": { "name": "blocks.block13." }, "blocks_block14_": { "name": "blocks.block14." }, "blocks_block15_": { "name": "blocks.block15." }, "blocks_block16_": { "name": "blocks.block16." }, "blocks_block17_": { "name": "blocks.block17." }, "blocks_block18_": { "name": "blocks.block18." }, "blocks_block19_": { "name": "blocks.block19." }, "blocks_block1_": { "name": "blocks.block1." }, "blocks_block20_": { "name": "blocks.block20." }, "blocks_block21_": { "name": "blocks.block21." }, "blocks_block22_": { "name": "blocks.block22." }, "blocks_block23_": { "name": "blocks.block23." }, "blocks_block24_": { "name": "blocks.block24." }, "blocks_block25_": { "name": "blocks.block25." }, "blocks_block26_": { "name": "blocks.block26." }, "blocks_block27_": { "name": "blocks.block27." }, "blocks_block2_": { "name": "blocks.block2." }, "blocks_block3_": { "name": "blocks.block3." }, "blocks_block4_": { "name": "blocks.block4." }, "blocks_block5_": { "name": "blocks.block5." }, "blocks_block6_": { "name": "blocks.block6." }, "blocks_block7_": { "name": "blocks.block7." }, "blocks_block8_": { "name": "blocks.block8." }, "blocks_block9_": { "name": "blocks.block9." }, "extra_pos_embedder_": { "name": "extra_pos_embedder." }, "final_layer_": { "name": "final_layer." }, "model1": { "name": "model1" }, "model2": { "name": "model2" }, "pos_embedder_": { "name": "pos_embedder." }, "t_embedder_": { "name": "t_embedder." }, "x_embedder_": { "name": "x_embedder." } } };
const ModelMergeCosmosPredict2_14B = { "display_name": "ModelMergeCosmosPredict2_14B", "inputs": { "blocks_0_": { "name": "bloques.0." }, "blocks_10_": { "name": "bloques.10." }, "blocks_11_": { "name": "bloques.11." }, "blocks_12_": { "name": "bloques.12." }, "blocks_13_": { "name": "bloques.13." }, "blocks_14_": { "name": "bloques.14." }, "blocks_15_": { "name": "bloques.15." }, "blocks_16_": { "name": "bloques.16." }, "blocks_17_": { "name": "bloques.17." }, "blocks_18_": { "name": "bloques.18." }, "blocks_19_": { "name": "bloques.19." }, "blocks_1_": { "name": "bloques.1." }, "blocks_20_": { "name": "bloques.20." }, "blocks_21_": { "name": "bloques.21." }, "blocks_22_": { "name": "bloques.22." }, "blocks_23_": { "name": "bloques.23." }, "blocks_24_": { "name": "bloques.24." }, "blocks_25_": { "name": "bloques.25." }, "blocks_26_": { "name": "bloques.26." }, "blocks_27_": { "name": "bloques.27." }, "blocks_28_": { "name": "bloques.28." }, "blocks_29_": { "name": "bloques.29." }, "blocks_2_": { "name": "bloques.2." }, "blocks_30_": { "name": "bloques.30." }, "blocks_31_": { "name": "bloques.31." }, "blocks_32_": { "name": "bloques.32." }, "blocks_33_": { "name": "bloques.33." }, "blocks_34_": { "name": "bloques.34." }, "blocks_35_": { "name": "bloques.35." }, "blocks_3_": { "name": "bloques.3." }, "blocks_4_": { "name": "bloques.4." }, "blocks_5_": { "name": "bloques.5." }, "blocks_6_": { "name": "bloques.6." }, "blocks_7_": { "name": "bloques.7." }, "blocks_8_": { "name": "bloques.8." }, "blocks_9_": { "name": "bloques.9." }, "final_layer_": { "name": "capa_final." }, "model1": { "name": "modelo1" }, "model2": { "name": "modelo2" }, "pos_embedder_": { "name": "pos_embedder." }, "t_embedder_": { "name": "t_embedder." }, "t_embedding_norm_": { "name": "t_embedding_norm." }, "x_embedder_": { "name": "x_embedder." } } };
const ModelMergeCosmosPredict2_2B = { "display_name": "ModelMergeCosmosPredict2_2B", "inputs": { "blocks_0_": { "name": "bloques.0." }, "blocks_10_": { "name": "bloques.10." }, "blocks_11_": { "name": "bloques.11." }, "blocks_12_": { "name": "bloques.12." }, "blocks_13_": { "name": "bloques.13." }, "blocks_14_": { "name": "bloques.14." }, "blocks_15_": { "name": "bloques.15." }, "blocks_16_": { "name": "bloques.16." }, "blocks_17_": { "name": "bloques.17." }, "blocks_18_": { "name": "bloques.18." }, "blocks_19_": { "name": "bloques.19." }, "blocks_1_": { "name": "bloques.1." }, "blocks_20_": { "name": "bloques.20." }, "blocks_21_": { "name": "bloques.21." }, "blocks_22_": { "name": "bloques.22." }, "blocks_23_": { "name": "bloques.23." }, "blocks_24_": { "name": "bloques.24." }, "blocks_25_": { "name": "bloques.25." }, "blocks_26_": { "name": "bloques.26." }, "blocks_27_": { "name": "bloques.27." }, "blocks_2_": { "name": "bloques.2." }, "blocks_3_": { "name": "bloques.3." }, "blocks_4_": { "name": "bloques.4." }, "blocks_5_": { "name": "bloques.5." }, "blocks_6_": { "name": "bloques.6." }, "blocks_7_": { "name": "bloques.7." }, "blocks_8_": { "name": "bloques.8." }, "blocks_9_": { "name": "bloques.9." }, "final_layer_": { "name": "capa_final." }, "model1": { "name": "modelo1" }, "model2": { "name": "modelo2" }, "pos_embedder_": { "name": "incrustador_pos." }, "t_embedder_": { "name": "incrustador_t." }, "t_embedding_norm_": { "name": "norm_incrustacion_t." }, "x_embedder_": { "name": "incrustador_x." } } };
const ModelMergeFlux1 = { "display_name": "ModelMergeFlux1", "inputs": { "double_blocks_0_": { "name": "bloques_dobles.0." }, "double_blocks_10_": { "name": "bloques_dobles.10." }, "double_blocks_11_": { "name": "bloques_dobles.11." }, "double_blocks_12_": { "name": "bloques_dobles.12." }, "double_blocks_13_": { "name": "bloques_dobles.13." }, "double_blocks_14_": { "name": "bloques_dobles.14." }, "double_blocks_15_": { "name": "bloques_dobles.15." }, "double_blocks_16_": { "name": "bloques_dobles.16." }, "double_blocks_17_": { "name": "bloques_dobles.17." }, "double_blocks_18_": { "name": "bloques_dobles.18." }, "double_blocks_1_": { "name": "bloques_dobles.1." }, "double_blocks_2_": { "name": "bloques_dobles.2." }, "double_blocks_3_": { "name": "bloques_dobles.3." }, "double_blocks_4_": { "name": "bloques_dobles.4." }, "double_blocks_5_": { "name": "bloques_dobles.5." }, "double_blocks_6_": { "name": "bloques_dobles.6." }, "double_blocks_7_": { "name": "bloques_dobles.7." }, "double_blocks_8_": { "name": "bloques_dobles.8." }, "double_blocks_9_": { "name": "bloques_dobles.9." }, "final_layer_": { "name": "capa_final." }, "guidance_in": { "name": "orientación_in" }, "img_in_": { "name": "img_in." }, "model1": { "name": "model1" }, "model2": { "name": "model2" }, "single_blocks_0_": { "name": "bloques_simples.0." }, "single_blocks_10_": { "name": "bloques_simples.10." }, "single_blocks_11_": { "name": "bloques_simples.11." }, "single_blocks_12_": { "name": "bloques_simples.12." }, "single_blocks_13_": { "name": "bloques_simples.13." }, "single_blocks_14_": { "name": "bloques_simples.14." }, "single_blocks_15_": { "name": "bloques_simples.15." }, "single_blocks_16_": { "name": "bloques_simples.16." }, "single_blocks_17_": { "name": "bloques_simples.17." }, "single_blocks_18_": { "name": "bloques_simples.18." }, "single_blocks_19_": { "name": "bloques_simples.19." }, "single_blocks_1_": { "name": "bloques_simples.1." }, "single_blocks_20_": { "name": "bloques_simples.20." }, "single_blocks_21_": { "name": "bloques_simples.21." }, "single_blocks_22_": { "name": "bloques_simples.22." }, "single_blocks_23_": { "name": "bloques_simples.23." }, "single_blocks_24_": { "name": "bloques_simples.24." }, "single_blocks_25_": { "name": "bloques_simples.25." }, "single_blocks_26_": { "name": "bloques_simples.26." }, "single_blocks_27_": { "name": "bloques_simples.27." }, "single_blocks_28_": { "name": "bloques_simples.28." }, "single_blocks_29_": { "name": "bloques_simples.29." }, "single_blocks_2_": { "name": "bloques_simples.2." }, "single_blocks_30_": { "name": "bloques_simples.30." }, "single_blocks_31_": { "name": "bloques_simples.31." }, "single_blocks_32_": { "name": "bloques_simples.32." }, "single_blocks_33_": { "name": "bloques_simples.33." }, "single_blocks_34_": { "name": "bloques_simples.34." }, "single_blocks_35_": { "name": "bloques_simples.35." }, "single_blocks_36_": { "name": "bloques_simples.36." }, "single_blocks_37_": { "name": "bloques_simples.37." }, "single_blocks_3_": { "name": "bloques_simples.3." }, "single_blocks_4_": { "name": "bloques_simples.4." }, "single_blocks_5_": { "name": "bloques_simples.5." }, "single_blocks_6_": { "name": "bloques_simples.6." }, "single_blocks_7_": { "name": "bloques_simples.7." }, "single_blocks_8_": { "name": "bloques_simples.8." }, "single_blocks_9_": { "name": "bloques_simples.9." }, "time_in_": { "name": "time_in." }, "txt_in_": { "name": "txt_in." }, "vector_in_": { "name": "vector_in." } } };
const ModelMergeLTXV = { "display_name": "ModelMergeLTXV", "inputs": { "adaln_single_": { "name": "adaln_single." }, "caption_projection_": { "name": "caption_projection." }, "model1": { "name": "model1" }, "model2": { "name": "model2" }, "patchify_proj_": { "name": "patchify_proj." }, "proj_out_": { "name": "proj_out." }, "scale_shift_table": { "name": "scale_shift_table" }, "transformer_blocks_0_": { "name": "transformer_blocks.0." }, "transformer_blocks_10_": { "name": "transformer_blocks.10." }, "transformer_blocks_11_": { "name": "transformer_blocks.11." }, "transformer_blocks_12_": { "name": "transformer_blocks.12." }, "transformer_blocks_13_": { "name": "transformer_blocks.13." }, "transformer_blocks_14_": { "name": "transformer_blocks.14." }, "transformer_blocks_15_": { "name": "transformer_blocks.15." }, "transformer_blocks_16_": { "name": "transformer_blocks.16." }, "transformer_blocks_17_": { "name": "transformer_blocks.17." }, "transformer_blocks_18_": { "name": "transformer_blocks.18." }, "transformer_blocks_19_": { "name": "transformer_blocks.19." }, "transformer_blocks_1_": { "name": "transformer_blocks.1." }, "transformer_blocks_20_": { "name": "transformer_blocks.20." }, "transformer_blocks_21_": { "name": "transformer_blocks.21." }, "transformer_blocks_22_": { "name": "transformer_blocks.22." }, "transformer_blocks_23_": { "name": "transformer_blocks.23." }, "transformer_blocks_24_": { "name": "transformer_blocks.24." }, "transformer_blocks_25_": { "name": "transformer_blocks.25." }, "transformer_blocks_26_": { "name": "transformer_blocks.26." }, "transformer_blocks_27_": { "name": "transformer_blocks.27." }, "transformer_blocks_2_": { "name": "transformer_blocks.2." }, "transformer_blocks_3_": { "name": "transformer_blocks.3." }, "transformer_blocks_4_": { "name": "transformer_blocks.4." }, "transformer_blocks_5_": { "name": "transformer_blocks.5." }, "transformer_blocks_6_": { "name": "transformer_blocks.6." }, "transformer_blocks_7_": { "name": "transformer_blocks.7." }, "transformer_blocks_8_": { "name": "transformer_blocks.8." }, "transformer_blocks_9_": { "name": "transformer_blocks.9." } } };
const ModelMergeMochiPreview = { "display_name": "ModelMergeMochiPreview", "inputs": { "blocks_0_": { "name": "blocks.0." }, "blocks_10_": { "name": "blocks.10." }, "blocks_11_": { "name": "blocks.11." }, "blocks_12_": { "name": "blocks.12." }, "blocks_13_": { "name": "blocks.13." }, "blocks_14_": { "name": "blocks.14." }, "blocks_15_": { "name": "blocks.15." }, "blocks_16_": { "name": "blocks.16." }, "blocks_17_": { "name": "blocks.17." }, "blocks_18_": { "name": "blocks.18." }, "blocks_19_": { "name": "blocks.19." }, "blocks_1_": { "name": "blocks.1." }, "blocks_20_": { "name": "blocks.20." }, "blocks_21_": { "name": "blocks.21." }, "blocks_22_": { "name": "blocks.22." }, "blocks_23_": { "name": "blocks.23." }, "blocks_24_": { "name": "blocks.24." }, "blocks_25_": { "name": "blocks.25." }, "blocks_26_": { "name": "blocks.26." }, "blocks_27_": { "name": "blocks.27." }, "blocks_28_": { "name": "blocks.28." }, "blocks_29_": { "name": "blocks.29." }, "blocks_2_": { "name": "blocks.2." }, "blocks_30_": { "name": "blocks.30." }, "blocks_31_": { "name": "blocks.31." }, "blocks_32_": { "name": "blocks.32." }, "blocks_33_": { "name": "blocks.33." }, "blocks_34_": { "name": "blocks.34." }, "blocks_35_": { "name": "blocks.35." }, "blocks_36_": { "name": "blocks.36." }, "blocks_37_": { "name": "blocks.37." }, "blocks_38_": { "name": "blocks.38." }, "blocks_39_": { "name": "blocks.39." }, "blocks_3_": { "name": "blocks.3." }, "blocks_40_": { "name": "blocks.40." }, "blocks_41_": { "name": "blocks.41." }, "blocks_42_": { "name": "blocks.42." }, "blocks_43_": { "name": "blocks.43." }, "blocks_44_": { "name": "blocks.44." }, "blocks_45_": { "name": "blocks.45." }, "blocks_46_": { "name": "blocks.46." }, "blocks_47_": { "name": "blocks.47." }, "blocks_4_": { "name": "blocks.4." }, "blocks_5_": { "name": "blocks.5." }, "blocks_6_": { "name": "blocks.6." }, "blocks_7_": { "name": "blocks.7." }, "blocks_8_": { "name": "blocks.8." }, "blocks_9_": { "name": "blocks.9." }, "final_layer_": { "name": "final_layer." }, "model1": { "name": "model1" }, "model2": { "name": "model2" }, "pos_frequencies_": { "name": "pos_frequencies." }, "t5_y_embedder_": { "name": "t5_y_embedder." }, "t5_yproj_": { "name": "t5_yproj." }, "t_embedder_": { "name": "t_embedder." } } };
const ModelMergeQwenImage = { "display_name": "FusionarModeloQwenImage", "inputs": { "img_in_": { "name": "img_entrada." }, "model1": { "name": "modelo1" }, "model2": { "name": "modelo2" }, "pos_embeds_": { "name": "incrustaciones_pos." }, "proj_out_": { "name": "proyección_salida." }, "time_text_embed_": { "name": "incrustacion_texto_tiempo." }, "transformer_blocks_0_": { "name": "bloques_transformador.0." }, "transformer_blocks_10_": { "name": "bloques_transformador.10." }, "transformer_blocks_11_": { "name": "bloques_transformador.11." }, "transformer_blocks_12_": { "name": "bloques_transformador.12." }, "transformer_blocks_13_": { "name": "bloques_transformador.13." }, "transformer_blocks_14_": { "name": "bloques_transformadores.14." }, "transformer_blocks_15_": { "name": "bloques_transformadores.15." }, "transformer_blocks_16_": { "name": "bloques_transformadores.16." }, "transformer_blocks_17_": { "name": "bloques_transformadores.17." }, "transformer_blocks_18_": { "name": "bloques_transformadores.18." }, "transformer_blocks_19_": { "name": "bloques_transformadores.19." }, "transformer_blocks_1_": { "name": "bloques_transformador.1." }, "transformer_blocks_20_": { "name": "bloques_transformadores.20." }, "transformer_blocks_21_": { "name": "bloques_transformadores.21." }, "transformer_blocks_22_": { "name": "bloques_transformadores.22." }, "transformer_blocks_23_": { "name": "bloques_transformadores.23." }, "transformer_blocks_24_": { "name": "bloques_transformadores.24." }, "transformer_blocks_25_": { "name": "bloques_transformadores.25." }, "transformer_blocks_26_": { "name": "bloques_transformadores.26." }, "transformer_blocks_27_": { "name": "bloques_transformadores.27." }, "transformer_blocks_28_": { "name": "bloques_transformadores.28." }, "transformer_blocks_29_": { "name": "bloques_transformadores.29." }, "transformer_blocks_2_": { "name": "bloques_transformador.2." }, "transformer_blocks_30_": { "name": "bloques_transformadores.30." }, "transformer_blocks_31_": { "name": "bloques_transformadores.31." }, "transformer_blocks_32_": { "name": "bloques_transformadores.32." }, "transformer_blocks_33_": { "name": "bloques_transformadores.33." }, "transformer_blocks_34_": { "name": "bloques_transformadores.34." }, "transformer_blocks_35_": { "name": "bloques_transformadores.35." }, "transformer_blocks_36_": { "name": "bloques_transformadores.36." }, "transformer_blocks_37_": { "name": "bloques_transformadores.37." }, "transformer_blocks_38_": { "name": "bloques_transformadores.38." }, "transformer_blocks_39_": { "name": "bloques_transformadores.39." }, "transformer_blocks_3_": { "name": "bloques_transformador.3." }, "transformer_blocks_40_": { "name": "bloques_transformadores.40." }, "transformer_blocks_41_": { "name": "bloques_transformadores.41." }, "transformer_blocks_42_": { "name": "bloques_transformadores.42." }, "transformer_blocks_43_": { "name": "bloques_transformadores.43." }, "transformer_blocks_44_": { "name": "bloques_transformadores.44." }, "transformer_blocks_45_": { "name": "bloques_transformadores.45." }, "transformer_blocks_46_": { "name": "bloques_transformadores.46." }, "transformer_blocks_47_": { "name": "bloques_transformadores.47." }, "transformer_blocks_48_": { "name": "bloques_transformadores.48." }, "transformer_blocks_49_": { "name": "bloques_transformadores.49." }, "transformer_blocks_4_": { "name": "bloques_transformador.4." }, "transformer_blocks_50_": { "name": "bloques_transformadores.50." }, "transformer_blocks_51_": { "name": "bloques_transformadores.51." }, "transformer_blocks_52_": { "name": "bloques_transformadores.52." }, "transformer_blocks_53_": { "name": "bloques_transformadores.53." }, "transformer_blocks_54_": { "name": "bloques_transformadores.54." }, "transformer_blocks_55_": { "name": "bloques_transformadores.55." }, "transformer_blocks_56_": { "name": "bloques_transformadores.56." }, "transformer_blocks_57_": { "name": "bloques_transformadores.57." }, "transformer_blocks_58_": { "name": "bloques_transformadores.58." }, "transformer_blocks_59_": { "name": "bloques_transformadores.59." }, "transformer_blocks_5_": { "name": "bloques_transformador.5." }, "transformer_blocks_6_": { "name": "bloques_transformador.6." }, "transformer_blocks_7_": { "name": "bloques_transformador.7." }, "transformer_blocks_8_": { "name": "bloques_transformador.8." }, "transformer_blocks_9_": { "name": "bloques_transformador.9." }, "txt_in_": { "name": "txt_entrada." }, "txt_norm_": { "name": "txt_norm." } } };
const ModelMergeSD1 = { "display_name": "ModelMergeSD1", "inputs": { "input_blocks_0_": { "name": "input_blocks.0." }, "input_blocks_10_": { "name": "input_blocks.10." }, "input_blocks_11_": { "name": "input_blocks.11." }, "input_blocks_1_": { "name": "input_blocks.1." }, "input_blocks_2_": { "name": "input_blocks.2." }, "input_blocks_3_": { "name": "input_blocks.3." }, "input_blocks_4_": { "name": "input_blocks.4." }, "input_blocks_5_": { "name": "input_blocks.5." }, "input_blocks_6_": { "name": "input_blocks.6." }, "input_blocks_7_": { "name": "input_blocks.7." }, "input_blocks_8_": { "name": "input_blocks.8." }, "input_blocks_9_": { "name": "input_blocks.9." }, "label_emb_": { "name": "label_emb." }, "middle_block_0_": { "name": "middle_block.0." }, "middle_block_1_": { "name": "middle_block.1." }, "middle_block_2_": { "name": "middle_block.2." }, "model1": { "name": "model1" }, "model2": { "name": "model2" }, "out_": { "name": "out." }, "output_blocks_0_": { "name": "output_blocks.0." }, "output_blocks_10_": { "name": "output_blocks.10." }, "output_blocks_11_": { "name": "output_blocks.11." }, "output_blocks_1_": { "name": "output_blocks.1." }, "output_blocks_2_": { "name": "output_blocks.2." }, "output_blocks_3_": { "name": "output_blocks.3." }, "output_blocks_4_": { "name": "output_blocks.4." }, "output_blocks_5_": { "name": "output_blocks.5." }, "output_blocks_6_": { "name": "output_blocks.6." }, "output_blocks_7_": { "name": "output_blocks.7." }, "output_blocks_8_": { "name": "output_blocks.8." }, "output_blocks_9_": { "name": "output_blocks.9." }, "time_embed_": { "name": "time_embed." } } };
const ModelMergeSD2 = { "display_name": "ModelMergeSD2", "inputs": { "input_blocks_0_": { "name": "input_blocks.0." }, "input_blocks_10_": { "name": "input_blocks.10." }, "input_blocks_11_": { "name": "input_blocks.11." }, "input_blocks_1_": { "name": "input_blocks.1." }, "input_blocks_2_": { "name": "input_blocks.2." }, "input_blocks_3_": { "name": "input_blocks.3." }, "input_blocks_4_": { "name": "input_blocks.4." }, "input_blocks_5_": { "name": "input_blocks.5." }, "input_blocks_6_": { "name": "input_blocks.6." }, "input_blocks_7_": { "name": "input_blocks.7." }, "input_blocks_8_": { "name": "input_blocks.8." }, "input_blocks_9_": { "name": "input_blocks.9." }, "label_emb_": { "name": "label_emb." }, "middle_block_0_": { "name": "middle_block.0." }, "middle_block_1_": { "name": "middle_block.1." }, "middle_block_2_": { "name": "middle_block.2." }, "model1": { "name": "model1" }, "model2": { "name": "model2" }, "out_": { "name": "out." }, "output_blocks_0_": { "name": "output_blocks.0." }, "output_blocks_10_": { "name": "output_blocks.10." }, "output_blocks_11_": { "name": "output_blocks.11." }, "output_blocks_1_": { "name": "output_blocks.1." }, "output_blocks_2_": { "name": "output_blocks.2." }, "output_blocks_3_": { "name": "output_blocks.3." }, "output_blocks_4_": { "name": "output_blocks.4." }, "output_blocks_5_": { "name": "output_blocks.5." }, "output_blocks_6_": { "name": "output_blocks.6." }, "output_blocks_7_": { "name": "output_blocks.7." }, "output_blocks_8_": { "name": "output_blocks.8." }, "output_blocks_9_": { "name": "output_blocks.9." }, "time_embed_": { "name": "time_embed." } } };
const ModelMergeSD35_Large = { "display_name": "ModelMergeSD35_Large", "inputs": { "context_embedder_": { "name": "context_embedder." }, "final_layer_": { "name": "final_layer." }, "joint_blocks_0_": { "name": "joint_blocks.0." }, "joint_blocks_10_": { "name": "joint_blocks.10." }, "joint_blocks_11_": { "name": "joint_blocks.11." }, "joint_blocks_12_": { "name": "joint_blocks.12." }, "joint_blocks_13_": { "name": "joint_blocks.13." }, "joint_blocks_14_": { "name": "joint_blocks.14." }, "joint_blocks_15_": { "name": "joint_blocks.15." }, "joint_blocks_16_": { "name": "joint_blocks.16." }, "joint_blocks_17_": { "name": "joint_blocks.17." }, "joint_blocks_18_": { "name": "joint_blocks.18." }, "joint_blocks_19_": { "name": "joint_blocks.19." }, "joint_blocks_1_": { "name": "joint_blocks.1." }, "joint_blocks_20_": { "name": "joint_blocks.20." }, "joint_blocks_21_": { "name": "joint_blocks.21." }, "joint_blocks_22_": { "name": "joint_blocks.22." }, "joint_blocks_23_": { "name": "joint_blocks.23." }, "joint_blocks_24_": { "name": "joint_blocks.24." }, "joint_blocks_25_": { "name": "joint_blocks.25." }, "joint_blocks_26_": { "name": "joint_blocks.26." }, "joint_blocks_27_": { "name": "joint_blocks.27." }, "joint_blocks_28_": { "name": "joint_blocks.28." }, "joint_blocks_29_": { "name": "joint_blocks.29." }, "joint_blocks_2_": { "name": "joint_blocks.2." }, "joint_blocks_30_": { "name": "joint_blocks.30." }, "joint_blocks_31_": { "name": "joint_blocks.31." }, "joint_blocks_32_": { "name": "joint_blocks.32." }, "joint_blocks_33_": { "name": "joint_blocks.33." }, "joint_blocks_34_": { "name": "joint_blocks.34." }, "joint_blocks_35_": { "name": "joint_blocks.35." }, "joint_blocks_36_": { "name": "joint_blocks.36." }, "joint_blocks_37_": { "name": "joint_blocks.37." }, "joint_blocks_3_": { "name": "joint_blocks.3." }, "joint_blocks_4_": { "name": "joint_blocks.4." }, "joint_blocks_5_": { "name": "joint_blocks.5." }, "joint_blocks_6_": { "name": "joint_blocks.6." }, "joint_blocks_7_": { "name": "joint_blocks.7." }, "joint_blocks_8_": { "name": "joint_blocks.8." }, "joint_blocks_9_": { "name": "joint_blocks.9." }, "model1": { "name": "model1" }, "model2": { "name": "model2" }, "pos_embed_": { "name": "pos_embed." }, "t_embedder_": { "name": "t_embedder." }, "x_embedder_": { "name": "x_embedder." }, "y_embedder_": { "name": "y_embedder." } } };
const ModelMergeSD3_2B = { "display_name": "ModelMergeSD3_2B", "inputs": { "context_embedder_": { "name": "context_embedder." }, "final_layer_": { "name": "final_layer." }, "joint_blocks_0_": { "name": "joint_blocks.0." }, "joint_blocks_10_": { "name": "joint_blocks.10." }, "joint_blocks_11_": { "name": "joint_blocks.11." }, "joint_blocks_12_": { "name": "joint_blocks.12." }, "joint_blocks_13_": { "name": "joint_blocks.13." }, "joint_blocks_14_": { "name": "joint_blocks.14." }, "joint_blocks_15_": { "name": "joint_blocks.15." }, "joint_blocks_16_": { "name": "joint_blocks.16." }, "joint_blocks_17_": { "name": "joint_blocks.17." }, "joint_blocks_18_": { "name": "joint_blocks.18." }, "joint_blocks_19_": { "name": "joint_blocks.19." }, "joint_blocks_1_": { "name": "joint_blocks.1." }, "joint_blocks_20_": { "name": "joint_blocks.20." }, "joint_blocks_21_": { "name": "joint_blocks.21." }, "joint_blocks_22_": { "name": "joint_blocks.22." }, "joint_blocks_23_": { "name": "joint_blocks.23." }, "joint_blocks_2_": { "name": "joint_blocks.2." }, "joint_blocks_3_": { "name": "joint_blocks.3." }, "joint_blocks_4_": { "name": "joint_blocks.4." }, "joint_blocks_5_": { "name": "joint_blocks.5." }, "joint_blocks_6_": { "name": "joint_blocks.6." }, "joint_blocks_7_": { "name": "joint_blocks.7." }, "joint_blocks_8_": { "name": "joint_blocks.8." }, "joint_blocks_9_": { "name": "joint_blocks.9." }, "model1": { "name": "model1" }, "model2": { "name": "model2" }, "pos_embed_": { "name": "pos_embed." }, "t_embedder_": { "name": "t_embedder." }, "x_embedder_": { "name": "x_embedder." }, "y_embedder_": { "name": "y_embedder." } } };
const ModelMergeSDXL = { "display_name": "ModelMergeSDXL", "inputs": { "input_blocks_0": { "name": "input_blocks.0" }, "input_blocks_1": { "name": "input_blocks.1" }, "input_blocks_2": { "name": "input_blocks.2" }, "input_blocks_3": { "name": "input_blocks.3" }, "input_blocks_4": { "name": "input_blocks.4" }, "input_blocks_5": { "name": "input_blocks.5" }, "input_blocks_6": { "name": "input_blocks.6" }, "input_blocks_7": { "name": "input_blocks.7" }, "input_blocks_8": { "name": "input_blocks.8" }, "label_emb_": { "name": "label_emb." }, "middle_block_0": { "name": "middle_block.0" }, "middle_block_1": { "name": "middle_block.1" }, "middle_block_2": { "name": "middle_block.2" }, "model1": { "name": "model1" }, "model2": { "name": "model2" }, "out_": { "name": "out." }, "output_blocks_0": { "name": "output_blocks.0" }, "output_blocks_1": { "name": "output_blocks.1" }, "output_blocks_2": { "name": "output_blocks.2" }, "output_blocks_3": { "name": "output_blocks.3" }, "output_blocks_4": { "name": "output_blocks.4" }, "output_blocks_5": { "name": "output_blocks.5" }, "output_blocks_6": { "name": "output_blocks.6" }, "output_blocks_7": { "name": "output_blocks.7" }, "output_blocks_8": { "name": "output_blocks.8" }, "time_embed_": { "name": "time_embed." } } };
const ModelMergeSimple = { "display_name": "ModelMergeSimple", "inputs": { "model1": { "name": "model1" }, "model2": { "name": "model2" }, "ratio": { "name": "ratio" } } };
const ModelMergeSubtract = { "display_name": "ModelMergeSubtract", "inputs": { "model1": { "name": "model1" }, "model2": { "name": "model2" }, "multiplier": { "name": "multiplier" } } };
const ModelMergeWAN2_1 = { "description": "El modelo de 1.3B tiene 30 bloques, el modelo de 14B tiene 40 bloques. El modelo de imagen a video tiene el img_emb extra.", "display_name": "ModelMergeWAN2_1", "inputs": { "blocks_0_": { "name": "blocks.0." }, "blocks_10_": { "name": "blocks.10." }, "blocks_11_": { "name": "blocks.11." }, "blocks_12_": { "name": "blocks.12." }, "blocks_13_": { "name": "blocks.13." }, "blocks_14_": { "name": "blocks.14." }, "blocks_15_": { "name": "blocks.15." }, "blocks_16_": { "name": "blocks.16." }, "blocks_17_": { "name": "blocks.17." }, "blocks_18_": { "name": "blocks.18." }, "blocks_19_": { "name": "blocks.19." }, "blocks_1_": { "name": "blocks.1." }, "blocks_20_": { "name": "blocks.20." }, "blocks_21_": { "name": "blocks.21." }, "blocks_22_": { "name": "blocks.22." }, "blocks_23_": { "name": "blocks.23." }, "blocks_24_": { "name": "blocks.24." }, "blocks_25_": { "name": "blocks.25." }, "blocks_26_": { "name": "blocks.26." }, "blocks_27_": { "name": "blocks.27." }, "blocks_28_": { "name": "blocks.28." }, "blocks_29_": { "name": "blocks.29." }, "blocks_2_": { "name": "blocks.2." }, "blocks_30_": { "name": "blocks.30." }, "blocks_31_": { "name": "blocks.31." }, "blocks_32_": { "name": "blocks.32." }, "blocks_33_": { "name": "blocks.33." }, "blocks_34_": { "name": "blocks.34." }, "blocks_35_": { "name": "blocks.35." }, "blocks_36_": { "name": "blocks.36." }, "blocks_37_": { "name": "blocks.37." }, "blocks_38_": { "name": "blocks.38." }, "blocks_39_": { "name": "blocks.39." }, "blocks_3_": { "name": "blocks.3." }, "blocks_4_": { "name": "blocks.4." }, "blocks_5_": { "name": "blocks.5." }, "blocks_6_": { "name": "blocks.6." }, "blocks_7_": { "name": "blocks.7." }, "blocks_8_": { "name": "blocks.8." }, "blocks_9_": { "name": "blocks.9." }, "head_": { "name": "head." }, "img_emb_": { "name": "img_emb." }, "model1": { "name": "model1" }, "model2": { "name": "model2" }, "patch_embedding_": { "name": "patch_embedding." }, "text_embedding_": { "name": "text_embedding." }, "time_embedding_": { "name": "time_embedding." }, "time_projection_": { "name": "time_projection." } } };
const ModelPatchLoader = { "display_name": "Cargador de Parches de Modelo", "inputs": { "name": { "name": "nombre" } } };
const ModelSamplingAuraFlow = { "display_name": "ModelSamplingAuraFlow", "inputs": { "model": { "name": "model" }, "shift": { "name": "shift" } } };
const ModelSamplingContinuousEDM = { "display_name": "ModelSamplingContinuousEDM", "inputs": { "model": { "name": "model" }, "sampling": { "name": "muestreo" }, "sigma_max": { "name": "sigma_max" }, "sigma_min": { "name": "sigma_min" } } };
const ModelSamplingContinuousV = { "display_name": "ModelSamplingContinuousV", "inputs": { "model": { "name": "model" }, "sampling": { "name": "muestreo" }, "sigma_max": { "name": "sigma_max" }, "sigma_min": { "name": "sigma_min" } } };
const ModelSamplingDiscrete = { "display_name": "MuestreoDeModeloDiscreto", "inputs": { "model": { "name": "modelo" }, "sampling": { "name": "muestreo" }, "zsnr": { "name": "zsnr" } } };
const ModelSamplingFlux = { "display_name": "MuestreoDeModeloFlux", "inputs": { "base_shift": { "name": "desplazamiento_base" }, "height": { "name": "altura" }, "max_shift": { "name": "desplazamiento_max" }, "model": { "name": "modelo" }, "width": { "name": "ancho" } } };
const ModelSamplingLTXV = { "display_name": "MuestreoDeModeloLTXV", "inputs": { "base_shift": { "name": "desplazamiento_base" }, "latent": { "name": "latente" }, "max_shift": { "name": "desplazamiento_max" }, "model": { "name": "modelo" } }, "outputs": { "0": { "tooltip": null } } };
const ModelSamplingSD3 = { "display_name": "MuestreoDeModeloSD3", "inputs": { "model": { "name": "modelo" }, "shift": { "name": "desplazamiento" } } };
const ModelSamplingStableCascade = { "display_name": "MuestreoDeModeloStableCascade", "inputs": { "model": { "name": "modelo" }, "shift": { "name": "desplazamiento" } } };
const ModelSave = { "display_name": "GuardarModelo", "inputs": { "filename_prefix": { "name": "prefijo_nombre_archivo" }, "model": { "name": "modelo" } } };
const MoonvalleyImg2VideoNode = { "description": "Nodo Moonvalley Marey Imagen a Video", "display_name": "Moonvalley Marey Imagen a Video", "inputs": { "control_after_generate": { "name": "control después de generar" }, "image": { "name": "imagen", "tooltip": "La imagen de referencia utilizada para generar el video" }, "negative_prompt": { "name": "prompt_negativo", "tooltip": "Texto del prompt negativo" }, "prompt": { "name": "prompt" }, "prompt_adherence": { "name": "adherencia_al_prompt", "tooltip": "Escala de guía para control de generación" }, "resolution": { "name": "resolución", "tooltip": "Resolución del video de salida" }, "seed": { "name": "semilla", "tooltip": "Valor de semilla aleatoria" }, "steps": { "name": "pasos", "tooltip": "Número de pasos de eliminación de ruido" } }, "outputs": { "0": { "tooltip": null } } };
const MoonvalleyTxt2VideoNode = { "display_name": "Moonvalley Marey Texto a Video", "inputs": { "control_after_generate": { "name": "control después de generar" }, "negative_prompt": { "name": "prompt_negativo", "tooltip": "Texto del prompt negativo" }, "prompt": { "name": "prompt" }, "prompt_adherence": { "name": "adherencia_al_prompt", "tooltip": "Escala de guía para control de generación" }, "resolution": { "name": "resolución", "tooltip": "Resolución del video de salida" }, "seed": { "name": "semilla", "tooltip": "Valor de semilla aleatoria" }, "steps": { "name": "pasos", "tooltip": "Pasos de inferencia" } }, "outputs": { "0": { "tooltip": null } } };
const MoonvalleyVideo2VideoNode = { "display_name": "Moonvalley Marey Video a Video", "inputs": { "control_type": { "name": "tipo_control" }, "motion_intensity": { "name": "intensidad_movimiento", "tooltip": "Solo se usa si el tipo_control es 'Transferencia de Movimiento'" }, "negative_prompt": { "name": "prompt_negativo", "tooltip": "Texto del prompt negativo" }, "prompt": { "name": "prompt", "tooltip": "Describe el video a generar" }, "seed": { "name": "semilla", "tooltip": "Valor de semilla aleatoria" }, "steps": { "name": "pasos", "tooltip": "Número de pasos de inferencia" }, "video": { "name": "video", "tooltip": "El video de referencia utilizado para generar el video de salida. Debe tener al menos 5 segundos de duración. Los videos más largos de 5s se recortarán automáticamente. Solo se admite formato MP4." } }, "outputs": { "0": { "tooltip": null } } };
const Morphology = { "display_name": "MorfologiaDeImagen", "inputs": { "image": { "name": "imagen" }, "kernel_size": { "name": "tamaño_kernel" }, "operation": { "name": "operacion" } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIChatConfig = { "description": "Permite especificar opciones de configuración avanzada para los Nodos de Chat de OpenAI.", "display_name": "Opciones Avanzadas de OpenAI ChatGPT", "inputs": { "instructions": { "name": "instrucciones", "tooltip": "Instrucciones para el modelo sobre cómo generar la respuesta" }, "max_output_tokens": { "name": "tokens_salida_max", "tooltip": "Un límite superior para el número de tokens que se pueden generar para una respuesta, incluyendo tokens de salida visibles" }, "truncation": { "name": "truncamiento", "tooltip": "La estrategia de truncamiento a utilizar para la respuesta del modelo. auto: Si el contexto de esta respuesta y las anteriores excede el tamaño de la ventana de contexto del modelo, el modelo truncará la respuesta para ajustarse a la ventana de contexto eliminando elementos de entrada en medio de la conversación. deshabilitado: Si una respuesta del modelo excederá el tamaño de la ventana de contexto para un modelo, la solicitud fallará con un error 400" } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIChatNode = { "description": "Genera respuestas de texto desde un modelo de OpenAI.", "display_name": "OpenAI ChatGPT", "inputs": { "advanced_options": { "name": "opciones_avanzadas", "tooltip": "Configuración opcional para el modelo. Acepta entradas desde el nodo Opciones Avanzadas de Chat de OpenAI." }, "files": { "name": "archivos", "tooltip": "Archivo(s) opcional(es) para usar como contexto para el modelo. Acepta entradas desde el nodo Archivos de Entrada de Chat de OpenAI." }, "images": { "name": "imágenes", "tooltip": "Imagen(es) opcional(es) para usar como contexto para el modelo. Para incluir múltiples imágenes, puedes usar el nodo Lote de Imágenes." }, "model": { "name": "modelo", "tooltip": "El modelo utilizado para generar la respuesta" }, "persist_context": { "name": "persistir_contexto", "tooltip": "Este parámetro está obsoleto y no tiene efecto." }, "prompt": { "name": "prompt", "tooltip": "Entradas de texto al modelo, utilizadas para generar una respuesta." } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIDalle2 = { "description": "Genera imágenes de forma síncrona a través del endpoint DALL·E 2 de OpenAI.", "display_name": "OpenAI DALL·E 2", "inputs": { "control_after_generate": { "name": "controlar después de generar" }, "image": { "name": "imagen", "tooltip": "Imagen de referencia opcional para la edición de imágenes." }, "mask": { "name": "mask", "tooltip": "Máscara opcional para inpainting (las áreas blancas serán reemplazadas)" }, "n": { "name": "n", "tooltip": "Cuántas imágenes generar" }, "prompt": { "name": "prompt", "tooltip": "Texto de entrada para DALL·E" }, "seed": { "name": "seed", "tooltip": "aún no implementado en el backend" }, "size": { "name": "tamaño", "tooltip": "Tamaño de la imagen" } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIDalle3 = { "description": "Genera imágenes de forma sincrónica a través del endpoint DALL·E 3 de OpenAI.", "display_name": "OpenAI DALL·E 3", "inputs": { "control_after_generate": { "name": "controlar después de generar" }, "prompt": { "name": "prompt", "tooltip": "Texto de entrada para DALL·E" }, "quality": { "name": "calidad", "tooltip": "Calidad de la imagen" }, "seed": { "name": "seed", "tooltip": "aún no implementado en el backend" }, "size": { "name": "tamaño", "tooltip": "Tamaño de la imagen" }, "style": { "name": "estilo", "tooltip": "Vívido hace que el modelo tienda a generar imágenes hiperrealistas y dramáticas. Natural hace que el modelo produzca imágenes más naturales y menos hiperrealistas." } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIGPTImage1 = { "description": "Genera imágenes de forma síncrona a través del endpoint GPT Image 1 de OpenAI.", "display_name": "OpenAI GPT Image 1", "inputs": { "background": { "name": "background", "tooltip": "Devolver imagen con o sin fondo" }, "control_after_generate": { "name": "control after generate" }, "image": { "name": "image", "tooltip": "Imagen de referencia opcional para edición de imagen." }, "mask": { "name": "mask", "tooltip": "Máscara opcional para inpainting (las áreas blancas serán reemplazadas)" }, "n": { "name": "n", "tooltip": "Cuántas imágenes generar" }, "prompt": { "name": "prompt", "tooltip": "Texto de entrada para GPT Image 1" }, "quality": { "name": "quality", "tooltip": "Calidad de la imagen, afecta el costo y el tiempo de generación." }, "seed": { "name": "seed", "tooltip": "aún no implementado en el backend" }, "size": { "name": "size", "tooltip": "Tamaño de la imagen" } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIInputFiles = { "description": "Carga y prepara archivos de entrada (texto, pdf, etc.) para incluirlos como entradas para el Nodo de Chat de OpenAI. Los archivos serán leídos por el modelo de OpenAI al generar una respuesta. 🛈 CONSEJO: Se puede encadenar con otros nodos de Archivos de Entrada de OpenAI.", "display_name": "Archivos de Entrada de OpenAI ChatGPT", "inputs": { "OPENAI_INPUT_FILES": { "name": "ARCHIVOS_ENTRADA_OPENAI", "tooltip": "Un archivo(s) adicional(es) opcional(es) para agrupar junto con el archivo cargado desde este nodo. Permite encadenar archivos de entrada para que un solo mensaje pueda incluir múltiples archivos de entrada." }, "file": { "name": "archivo", "tooltip": "Archivos de entrada para incluir como contexto para el modelo. Por ahora solo acepta archivos de texto (.txt) y PDF (.pdf)." } }, "outputs": { "0": { "tooltip": null } } };
const OpenAIVideoSora2 = { "description": "Generación de video y audio de OpenAI.", "display_name": "OpenAI Sora - Video", "inputs": { "control_after_generate": { "name": "control después de generar" }, "duration": { "name": "duración" }, "image": { "name": "imagen" }, "model": { "name": "modelo" }, "prompt": { "name": "prompt", "tooltip": "Texto guía; puede estar vacío si hay una imagen de entrada." }, "seed": { "name": "semilla", "tooltip": "Semilla para determinar si el nodo debe volver a ejecutarse; los resultados reales son no deterministas independientemente de la semilla." }, "size": { "name": "tamaño" } }, "outputs": { "0": { "tooltip": null } } };
const OptimalStepsScheduler = { "display_name": "OptimalStepsScheduler", "inputs": { "denoise": { "name": "eliminar ruido" }, "model_type": { "name": "model_type" }, "steps": { "name": "pasos" } }, "outputs": { "0": { "tooltip": null } } };
const PairConditioningCombine = { "display_name": "CombinarCondPares", "inputs": { "negative_A": { "name": "negativo_A" }, "negative_B": { "name": "negativo_B" }, "positive_A": { "name": "positivo_A" }, "positive_B": { "name": "positivo_B" } }, "outputs": { "0": { "name": "positivo" }, "1": { "name": "negativo" } } };
const PairConditioningSetDefaultCombine = { "display_name": "CombinarCondParesEstablecerPorDefecto", "inputs": { "hooks": { "name": "ganchos" }, "negative": { "name": "negativo" }, "negative_DEFAULT": { "name": "negativo_POR_DEFECTO" }, "positive": { "name": "positivo" }, "positive_DEFAULT": { "name": "positivo_POR_DEFECTO" } }, "outputs": { "0": { "name": "positivo" }, "1": { "name": "negativo" } } };
const PairConditioningSetProperties = { "display_name": "EstablecerPropiedadesCondPares", "inputs": { "hooks": { "name": "ganchos" }, "mask": { "name": "mascara" }, "negative_NEW": { "name": "negativo_NUEVO" }, "positive_NEW": { "name": "positivo_NUEVO" }, "set_cond_area": { "name": "establecer_area_cond" }, "strength": { "name": "fuerza" }, "timesteps": { "name": "pasos_de_tiempo" } }, "outputs": { "0": { "name": "positivo" }, "1": { "name": "negativo" } } };
const PairConditioningSetPropertiesAndCombine = { "display_name": "Cond Pair Set Props Combine", "inputs": { "hooks": { "name": "ganchos" }, "mask": { "name": "máscara" }, "negative": { "name": "negativo" }, "negative_NEW": { "name": "negativo_NUEVO" }, "positive": { "name": "positivo" }, "positive_NEW": { "name": "positivo_NUEVO" }, "set_cond_area": { "name": "set_area_cond" }, "strength": { "name": "fuerza" }, "timesteps": { "name": "pasos_de_tiempo" } }, "outputs": { "0": { "name": "positivo" }, "1": { "name": "negativo" } } };
const PatchModelAddDownscale = { "display_name": "PatchModelAddDownscale (Kohya Deep Shrink)", "inputs": { "block_number": { "name": "numero_de_bloque" }, "downscale_after_skip": { "name": "reducción_después_de_omitir" }, "downscale_factor": { "name": "factor_de_reducción" }, "downscale_method": { "name": "método_de_reducción" }, "end_percent": { "name": "porcentaje_final" }, "model": { "name": "modelo" }, "start_percent": { "name": "porcentaje_inicial" }, "upscale_method": { "name": "método_de_ampliación" } }, "outputs": { "0": { "tooltip": null } } };
const PerpNeg = { "display_name": "Perp-Neg (DEPRECATED by PerpNegGuider)", "inputs": { "empty_conditioning": { "name": "condicionamiento_vacío" }, "model": { "name": "modelo" }, "neg_scale": { "name": "escala_neg" } }, "outputs": { "0": { "tooltip": null } } };
const PerpNegGuider = { "display_name": "PerpNegGuider", "inputs": { "cfg": { "name": "cfg" }, "empty_conditioning": { "name": "condicionamiento_vacío" }, "model": { "name": "modelo" }, "neg_scale": { "name": "escala_neg" }, "negative": { "name": "negativo" }, "positive": { "name": "positivo" } }, "outputs": { "0": { "tooltip": null } } };
const PerturbedAttentionGuidance = { "display_name": "PerturbedAttentionGuidance", "inputs": { "model": { "name": "modelo" }, "scale": { "name": "escala" } }, "outputs": { "0": { "tooltip": null } } };
const PhotoMakerEncode = { "display_name": "PhotoMakerEncode", "inputs": { "clip": { "name": "clip" }, "image": { "name": "imagen" }, "photomaker": { "name": "photomaker" }, "text": { "name": "texto" } }, "outputs": { "0": { "tooltip": null } } };
const PhotoMakerLoader = { "display_name": "PhotoMakerLoader", "inputs": { "photomaker_model_name": { "name": "nombre_del_modelo_photomaker" } }, "outputs": { "0": { "tooltip": null } } };
const PixverseImageToVideoNode = { "description": "Genera videos de forma sincrónica según el prompt y el tamaño de salida.", "display_name": "PixVerse Imagen a Video", "inputs": { "control_after_generate": { "name": "controlar después de generar" }, "duration_seconds": { "name": "duración_en_segundos" }, "image": { "name": "imagen" }, "motion_mode": { "name": "modo_de_movimiento" }, "negative_prompt": { "name": "prompt_negativo", "tooltip": "Una descripción opcional en texto de los elementos no deseados en una imagen." }, "pixverse_template": { "name": "plantilla_pixverse", "tooltip": "Una plantilla opcional para influir en el estilo de la generación, creada por el nodo PixVerse Template." }, "prompt": { "name": "prompt", "tooltip": "Prompt para la generación del video" }, "quality": { "name": "calidad" }, "seed": { "name": "semilla", "tooltip": "Semilla para la generación del video." } }, "outputs": { "0": { "tooltip": null } } };
const PixverseTemplateNode = { "display_name": "Plantilla de PixVerse", "inputs": { "template": { "name": "plantilla" } }, "outputs": { "0": { "name": "plantilla_pixverse", "tooltip": null } } };
const PixverseTextToVideoNode = { "description": "Genera videos de forma sincrónica basados en el prompt y el tamaño de salida.", "display_name": "PixVerse Texto a Video", "inputs": { "aspect_ratio": { "name": "relación_de_aspecto" }, "control_after_generate": { "name": "controlar después de generar" }, "duration_seconds": { "name": "duración_segundos" }, "motion_mode": { "name": "modo_de_movimiento" }, "negative_prompt": { "name": "prompt_negativo", "tooltip": "Una descripción opcional en texto de los elementos no deseados en una imagen." }, "pixverse_template": { "name": "plantilla_pixverse", "tooltip": "Una plantilla opcional para influir en el estilo de la generación, creada por el nodo PixVerse Template." }, "prompt": { "name": "prompt", "tooltip": "Prompt para la generación de video" }, "quality": { "name": "calidad" }, "seed": { "name": "semilla", "tooltip": "Semilla para la generación de video." } }, "outputs": { "0": { "tooltip": null } } };
const PixverseTransitionVideoNode = { "description": "Genera videos de forma sincrónica según el prompt y el tamaño de salida.", "display_name": "Video de Transición PixVerse", "inputs": { "control_after_generate": { "name": "controlar después de generar" }, "duration_seconds": { "name": "duración en segundos" }, "first_frame": { "name": "primer fotograma" }, "last_frame": { "name": "último fotograma" }, "motion_mode": { "name": "modo de movimiento" }, "negative_prompt": { "name": "prompt negativo", "tooltip": "Una descripción opcional en texto de los elementos no deseados en una imagen." }, "prompt": { "name": "prompt", "tooltip": "Prompt para la generación de video" }, "quality": { "name": "calidad" }, "seed": { "name": "semilla", "tooltip": "Semilla para la generación de video." } }, "outputs": { "0": { "tooltip": null } } };
const PolyexponentialScheduler = { "display_name": "PolyexponentialScheduler", "inputs": { "rho": { "name": "rho" }, "sigma_max": { "name": "sigma_max" }, "sigma_min": { "name": "sigma_min" }, "steps": { "name": "pasos" } } };
const PorterDuffImageComposite = { "display_name": "Composición de Imagen Porter-Duff", "inputs": { "destination": { "name": "destino" }, "destination_alpha": { "name": "alfa_destino" }, "mode": { "name": "modo" }, "source": { "name": "fuente" }, "source_alpha": { "name": "alfa_fuente" } }, "outputs": { "0": { "tooltip": null }, "1": { "tooltip": null } } };
const Preview3D = { "display_name": "Vista previa 3D", "inputs": { "camera_info": { "name": "camera_info" }, "image": { "name": "imagen" }, "model_file": { "name": "archivo_modelo" } } };
const PreviewAny = { "display_name": "Vista previa de cualquier", "inputs": { "preview": {}, "source": { "name": "fuente" } } };
const PreviewAudio = { "display_name": "Vista previa de audio", "inputs": { "audio": { "name": "audio" }, "audioUI": { "name": "interfaz_audio" } } };
const PreviewImage = { "description": "Guarda las imágenes de entrada en tu directorio de salida de ComfyUI.", "display_name": "Vista previa de imagen", "inputs": { "images": { "name": "imagenes" } } };
const PrimitiveBoolean = { "display_name": "Booleano", "inputs": { "value": { "name": "valor" } }, "outputs": { "0": { "tooltip": null } } };
const PrimitiveFloat = { "display_name": "Flotante", "inputs": { "value": { "name": "valor" } }, "outputs": { "0": { "tooltip": null } } };
const PrimitiveInt = { "display_name": "Int", "inputs": { "control_after_generate": { "name": "controlar después de generar" }, "value": { "name": "valor" } }, "outputs": { "0": { "tooltip": null } } };
const PrimitiveString = { "display_name": "Cadena", "inputs": { "value": { "name": "valor" } }, "outputs": { "0": { "tooltip": null } } };
const PrimitiveStringMultiline = { "display_name": "Cadena (Multilínea)", "inputs": { "value": { "name": "valor" } }, "outputs": { "0": { "tooltip": null } } };
const QuadrupleCLIPLoader = { "description": "[Recetas]\n\nhidream: long clip-l, long clip-g, t5xxl, llama_8b_3.1_instruct", "display_name": "QuadrupleCLIPLoader", "inputs": { "clip_name1": { "name": "clip_name1" }, "clip_name2": { "name": "clip_name2" }, "clip_name3": { "name": "clip_name3" }, "clip_name4": { "name": "clip_name4" } }, "outputs": { "0": { "tooltip": null } } };
const QwenImageDiffsynthControlnet = { "display_name": "QwenImageDiffsynthControlnet", "inputs": { "image": { "name": "imagen" }, "mask": { "name": "máscara" }, "model": { "name": "modelo" }, "model_patch": { "name": "parche_del_modelo" }, "strength": { "name": "intensidad" }, "vae": { "name": "vae" } } };
const RandomNoise = { "display_name": "Ruido aleatorio", "inputs": { "control_after_generate": { "name": "control después de generar" }, "noise_seed": { "name": "semilla_ruido" } } };
const RebatchImages = { "display_name": "Reagrupar imágenes", "inputs": { "batch_size": { "name": "tamaño_lote" }, "images": { "name": "imagenes" } }, "outputs": { "0": { "tooltip": null } } };
const RebatchLatents = { "display_name": "Reagrupar latentes", "inputs": { "batch_size": { "name": "tamaño_lote" }, "latents": { "name": "latentes" } }, "outputs": { "0": { "tooltip": null } } };
const RecordAudio = { "display_name": "Grabar Audio", "inputs": { "audio": { "name": "audio" } } };
const RecraftColorRGB = { "description": "Crea un Recraft Color eligiendo valores RGB específicos.", "display_name": "Recraft Color RGB", "inputs": { "b": { "name": "b", "tooltip": "Valor azul del color." }, "g": { "name": "g", "tooltip": "Valor verde del color." }, "r": { "name": "r", "tooltip": "Valor rojo del color." }, "recraft_color": { "name": "recraft_color" } }, "outputs": { "0": { "name": "recraft_color", "tooltip": null } } };
const RecraftControls = { "description": "Crea Controles de Recraft para personalizar la generación de Recraft.", "display_name": "Controles de Recraft", "inputs": { "background_color": { "name": "color_de_fondo" }, "colors": { "name": "colores" } }, "outputs": { "0": { "name": "controles_recraft", "tooltip": null } } };
const RecraftCreativeUpscaleNode = { "description": "Aumenta la imagen de forma sincrónica.\nMejora una imagen ráster dada utilizando la herramienta de ‘creative upscale’, aumentando la resolución con un enfoque en refinar pequeños detalles y rostros.", "display_name": "Recraft Creative Upscale Image", "inputs": { "image": { "name": "imagen" } }, "outputs": { "0": { "tooltip": null } } };
const RecraftCrispUpscaleNode = { "description": "Aumenta la imagen de forma sincrónica.\nMejora una imagen ráster dada usando la herramienta ‘crisp upscale’, aumentando la resolución de la imagen y haciéndola más nítida y clara.", "display_name": "Recraft Crisp Upscale Image", "inputs": { "image": { "name": "imagen" } }, "outputs": { "0": { "tooltip": null } } };
const RecraftImageInpaintingNode = { "description": "Modifica la imagen según el prompt y la mask.", "display_name": "Recraft Relleno de Imagen", "inputs": { "control_after_generate": { "name": "control después de generar" }, "image": { "name": "imagen" }, "mask": { "name": "mask" }, "n": { "name": "n", "tooltip": "El número de imágenes a generar." }, "negative_prompt": { "name": "negative_prompt", "tooltip": "Una descripción opcional en texto de los elementos no deseados en una imagen." }, "prompt": { "name": "prompt", "tooltip": "Prompt para la generación de la imagen." }, "recraft_style": { "name": "recraft_style" }, "seed": { "name": "semilla", "tooltip": "Semilla para determinar si el nodo debe ejecutarse de nuevo; los resultados reales son no deterministas independientemente de la semilla." } }, "outputs": { "0": { "tooltip": null } } };
const RecraftImageToImageNode = { "description": "Modifica la imagen según el prompt y la intensidad.", "display_name": "Recraft Imagen a Imagen", "inputs": { "control_after_generate": { "name": "control after generate" }, "image": { "name": "imagen" }, "n": { "name": "n", "tooltip": "El número de imágenes a generar." }, "negative_prompt": { "name": "negative_prompt", "tooltip": "Una descripción opcional en texto de los elementos no deseados en una imagen." }, "prompt": { "name": "prompt", "tooltip": "Prompt para la generación de la imagen." }, "recraft_controls": { "name": "recraft_controls", "tooltip": "Controles adicionales opcionales sobre la generación a través del nodo Recraft Controls." }, "recraft_style": { "name": "recraft_style" }, "seed": { "name": "semilla", "tooltip": "Semilla para determinar si el nodo debe volver a ejecutarse; los resultados reales son no deterministas independientemente de la semilla." }, "strength": { "name": "intensidad", "tooltip": "Define la diferencia con la imagen original, debe estar en [0, 1], donde 0 significa casi idéntica y 1 significa muy poca similitud." } }, "outputs": { "0": { "tooltip": null } } };
const RecraftRemoveBackgroundNode = { "description": "Elimina el fondo de la imagen y devuelve la imagen procesada y la máscara.", "display_name": "Recraft Remove Background", "inputs": { "image": { "name": "imagen" } }, "outputs": { "0": { "tooltip": null }, "1": { "tooltip": null } } };
const RecraftReplaceBackgroundNode = { "description": "Reemplaza el fondo de una imagen, basado en el prompt proporcionado.", "display_name": "Recraft Reemplazar Fondo", "inputs": { "control_after_generate": { "name": "control after generate" }, "image": { "name": "imagen" }, "n": { "name": "n", "tooltip": "El número de imágenes a generar." }, "negative_prompt": { "name": "negative_prompt", "tooltip": "Una descripción de texto opcional de los elementos no deseados en una imagen." }, "prompt": { "name": "prompt", "tooltip": "Prompt para la generación de la imagen." }, "recraft_style": { "name": "recraft_style" }, "seed": { "name": "semilla", "tooltip": "Semilla para determinar si el nodo debe ejecutarse de nuevo; los resultados reales son no deterministas independientemente de la semilla." } }, "outputs": { "0": { "tooltip": null } } };
const RecraftStyleV3DigitalIllustration = { "description": "Selecciona el estilo realistic_image y un subestilo opcional.", "display_name": "Estilo Recraft - Ilustración Digital", "inputs": { "substyle": { "name": "subestilo" } }, "outputs": { "0": { "name": "estilo_recraft", "tooltip": null } } };
const RecraftStyleV3InfiniteStyleLibrary = { "description": "Selecciona un estilo basado en el UUID preexistente de la Biblioteca de Estilos Infinita de Recraft.", "display_name": "Recraft Style - Biblioteca de Estilos Infinita", "inputs": { "style_id": { "name": "style_id", "tooltip": "UUID del estilo de la Biblioteca de Estilos Infinita." } }, "outputs": { "0": { "name": "recraft_style", "tooltip": null } } };
const RecraftStyleV3LogoRaster = { "description": "Selecciona el estilo realistic_image y un subestilo opcional.", "display_name": "Recraft Style - Logo Raster", "inputs": { "substyle": { "name": "subestilo" } }, "outputs": { "0": { "name": "recraft_style", "tooltip": null } } };
const RecraftStyleV3RealisticImage = { "description": "Selecciona el estilo realistic_image y un subestilo opcional.", "display_name": "Recraft Style - Imagen Realista", "inputs": { "substyle": { "name": "subestilo" } }, "outputs": { "0": { "name": "recraft_style", "tooltip": null } } };
const RecraftTextToImageNode = { "description": "Genera imágenes de forma sincrónica según el prompt y la resolución.", "display_name": "Recraft Texto a Imagen", "inputs": { "control_after_generate": { "name": "controlar después de generar" }, "n": { "name": "n", "tooltip": "La cantidad de imágenes a generar." }, "negative_prompt": { "name": "negative_prompt", "tooltip": "Una descripción opcional en texto de los elementos no deseados en una imagen." }, "prompt": { "name": "prompt", "tooltip": "Prompt para la generación de la imagen." }, "recraft_controls": { "name": "recraft_controls", "tooltip": "Controles adicionales opcionales sobre la generación a través del nodo Recraft Controls." }, "recraft_style": { "name": "recraft_style" }, "seed": { "name": "semilla", "tooltip": "Semilla para determinar si el nodo debe volver a ejecutarse; los resultados reales son no deterministas independientemente de la semilla." }, "size": { "name": "tamaño", "tooltip": "El tamaño de la imagen generada." } }, "outputs": { "0": { "tooltip": null } } };
const RecraftTextToVectorNode = { "description": "Genera SVG de forma sincrónica según el prompt y la resolución.", "display_name": "Recraft Texto a Vector", "inputs": { "control_after_generate": { "name": "control después de generar" }, "n": { "name": "n", "tooltip": "La cantidad de imágenes a generar." }, "negative_prompt": { "name": "negative_prompt", "tooltip": "Una descripción opcional en texto de los elementos no deseados en una imagen." }, "prompt": { "name": "prompt", "tooltip": "Prompt para la generación de la imagen." }, "recraft_controls": { "name": "recraft_controls", "tooltip": "Controles adicionales opcionales sobre la generación a través del nodo Recraft Controls." }, "seed": { "name": "semilla", "tooltip": "Semilla para determinar si el nodo debe ejecutarse de nuevo; los resultados reales son no deterministas independientemente de la semilla." }, "size": { "name": "tamaño", "tooltip": "El tamaño de la imagen generada." }, "substyle": { "name": "substyle" } }, "outputs": { "0": { "tooltip": null } } };
const RecraftVectorizeImageNode = { "description": "Genera SVG de forma sincrónica a partir de una imagen de entrada.", "display_name": "Recraft Vectorizar Imagen", "inputs": { "image": { "name": "imagen" } }, "outputs": { "0": { "tooltip": null } } };
const ReferenceLatent = { "description": "Este nodo establece el latente guía para un modelo de edición. Si el modelo lo admite, puedes encadenar varios para establecer múltiples imágenes de referencia.", "display_name": "Latente de Referencia", "inputs": { "conditioning": { "name": "condicionamiento" }, "latent": { "name": "latente" } }, "outputs": { "0": { "tooltip": null } } };
const RegexExtract = { "display_name": "Extracción Regex", "inputs": { "case_insensitive": { "name": "insensible_a_mayúsculas" }, "dotall": { "name": "dotall" }, "group_index": { "name": "índice_de_grupo" }, "mode": { "name": "modo" }, "multiline": { "name": "multilínea" }, "regex_pattern": { "name": "patrón_regex" }, "string": { "name": "cadena" } }, "outputs": { "0": { "tooltip": null } } };
const RegexMatch = { "display_name": "Coincidencia Regex", "inputs": { "case_insensitive": { "name": "insensible_a_mayúsculas" }, "dotall": { "name": "dotall" }, "multiline": { "name": "multilínea" }, "regex_pattern": { "name": "patrón_regex" }, "string": { "name": "cadena" } }, "outputs": { "0": { "name": "coincidencias", "tooltip": null } } };
const RegexReplace = { "description": "Buscar y reemplazar texto usando patrones regex.", "display_name": "Reemplazo Regex", "inputs": { "case_insensitive": { "name": "insensible_a_mayusculas" }, "count": { "name": "contador", "tooltip": "Número máximo de reemplazos a realizar. Establecer en 0 para reemplazar todas las ocurrencias (predeterminado). Establecer en 1 para reemplazar solo la primera coincidencia, 2 para las dos primeras coincidencias, etc." }, "dotall": { "name": "dotall", "tooltip": "Cuando está habilitado, el carácter punto (.) coincidirá con cualquier carácter incluyendo caracteres de nueva línea. Cuando está deshabilitado, los puntos no coincidirán con nuevas líneas." }, "multiline": { "name": "multilínea" }, "regex_pattern": { "name": "patron_regex" }, "replace": { "name": "reemplazar" }, "string": { "name": "cadena" } }, "outputs": { "0": { "tooltip": null } } };
const RenormCFG = { "display_name": "RenormCFG", "inputs": { "cfg_trunc": { "name": "cfg_trunc" }, "model": { "name": "modelo" }, "renorm_cfg": { "name": "renorm_cfg" } }, "outputs": { "0": { "tooltip": null } } };
const RepeatImageBatch = { "display_name": "Repetir lote de imágenes", "inputs": { "amount": { "name": "cantidad" }, "image": { "name": "imagen" } } };
const RepeatLatentBatch = { "display_name": "Repetir lote latente", "inputs": { "amount": { "name": "cantidad" }, "samples": { "name": "muestras" } } };
const RescaleCFG = { "display_name": "ReescalarCFG", "inputs": { "model": { "name": "modelo" }, "multiplier": { "name": "multiplicador" } } };
const ResizeAndPadImage = { "display_name": "RedimensionarYRellenarImagen", "inputs": { "image": { "name": "imagen" }, "interpolation": { "name": "interpolación" }, "padding_color": { "name": "color_relleno" }, "target_height": { "name": "alto_objetivo" }, "target_width": { "name": "ancho_objetivo" } } };
const Rodin3D_Detail = { "description": "Generar activos 3D usando la API de Rodin", "display_name": "Rodin 3D Generar - Generar Detalle", "inputs": { "Images": { "name": "Imágenes" }, "Material_Type": { "name": "Tipo_Material" }, "Polygon_count": { "name": "Recuento_Polígonos" }, "Seed": { "name": "Semilla" } }, "outputs": { "0": { "name": "Ruta Modelo 3D", "tooltip": null } } };
const Rodin3D_Gen2 = { "description": "Generar activos 3D usando la API de Rodin", "display_name": "Rodin 3D Generar - Generar Gen-2", "inputs": { "Images": { "name": "Imágenes" }, "Material_Type": { "name": "Tipo_Material" }, "Polygon_count": { "name": "Recuento_Polígonos" }, "Seed": { "name": "Semilla" }, "TAPose": { "name": "TAPose" } }, "outputs": { "0": { "name": "Ruta Modelo 3D", "tooltip": null } } };
const Rodin3D_Regular = { "description": "Generar activos 3D usando la API de Rodin", "display_name": "Rodin 3D Generar - Generar Regular", "inputs": { "Images": { "name": "Imágenes" }, "Material_Type": { "name": "Tipo_Material" }, "Polygon_count": { "name": "Recuento_Polígonos" }, "Seed": { "name": "Semilla" } }, "outputs": { "0": { "name": "Ruta Modelo 3D", "tooltip": null } } };
const Rodin3D_Sketch = { "description": "Generar activos 3D usando la API de Rodin", "display_name": "Rodin 3D Generar - Generar Boceto", "inputs": { "Images": { "name": "Imágenes" }, "Seed": { "name": "Semilla" } }, "outputs": { "0": { "name": "Ruta del modelo 3D", "tooltip": null } } };
const Rodin3D_Smooth = { "description": "Generar activos 3D usando la API de Rodin", "display_name": "Rodin 3D Generar - Generar Suavizado", "inputs": { "Images": { "name": "Imágenes" }, "Material_Type": { "name": "Tipo_de_Material" }, "Polygon_count": { "name": "Recuento_de_Polígonos" }, "Seed": { "name": "Semilla" } }, "outputs": { "0": { "name": "Ruta del modelo 3D", "tooltip": null } } };
const RunwayFirstLastFrameNode = { "description": "Sube los primeros y últimos fotogramas clave, redacta un prompt y genera un video. Las transiciones más complejas, como casos donde el último fotograma es completamente diferente del primero, pueden beneficiarse de la duración más larga de 10s. Esto le daría a la generación más tiempo para transicionar suavemente entre las dos entradas. Antes de comenzar, revisa estas mejores prácticas para asegurar que tus selecciones de entrada preparen tu generación para el éxito: https://help.runwayml.com/hc/en-us/articles/34170748696595-Creating-with-Keyframes-on-Gen-3.", "display_name": "Runway Primer-Fotograma-Último a Video", "inputs": { "control_after_generate": { "name": "control después de generar" }, "duration": { "name": "duración" }, "end_frame": { "name": "fotograma_final", "tooltip": "Fotograma final que se usará para el video. Solo compatible con gen3a_turbo." }, "prompt": { "name": "prompt", "tooltip": "Prompt de texto para la generación" }, "ratio": { "name": "relación" }, "seed": { "name": "semilla", "tooltip": "Semilla aleatoria para la generación" }, "start_frame": { "name": "fotograma_inicial", "tooltip": "Fotograma inicial que se usará para el video" } }, "outputs": { "0": { "tooltip": null } } };
const RunwayImageToVideoNodeGen3a = { "description": "Genera un video desde un único fotograma inicial usando el modelo Gen3a Turbo. Antes de comenzar, revisa estas mejores prácticas para asegurar que tus selecciones de entrada preparen tu generación para el éxito: https://help.runwayml.com/hc/en-us/articles/33927968552339-Creating-with-Act-One-on-Gen-3-Alpha-and-Turbo.", "display_name": "Runway Imagen a Video (Gen3a Turbo)", "inputs": { "control_after_generate": { "name": "control después de generar" }, "duration": { "name": "duración" }, "prompt": { "name": "prompt", "tooltip": "Prompt de texto para la generación" }, "ratio": { "name": "relación" }, "seed": { "name": "semilla", "tooltip": "Semilla aleatoria para la generación" }, "start_frame": { "name": "fotograma_inicial", "tooltip": "Fotograma inicial que se usará para el video" } }, "outputs": { "0": { "tooltip": null } } };
const RunwayImageToVideoNodeGen4 = { "description": "Genera un video desde un único fotograma inicial usando el modelo Gen4 Turbo. Antes de comenzar, revisa estas mejores prácticas para asegurar que tus selecciones de entrada preparen tu generación para el éxito: https://help.runwayml.com/hc/en-us/articles/37327109429011-Creating-with-Gen-4-Video.", "display_name": "Runway Imagen a Video (Gen4 Turbo)", "inputs": { "control_after_generate": { "name": "control después de generar" }, "duration": { "name": "duración" }, "prompt": { "name": "prompt", "tooltip": "Prompt de texto para la generación" }, "ratio": { "name": "proporción" }, "seed": { "name": "semilla", "tooltip": "Semilla aleatoria para la generación" }, "start_frame": { "name": "frame_inicial", "tooltip": "Frame inicial que se utilizará para el video" } }, "outputs": { "0": { "tooltip": null } } };
const RunwayTextToImageNode = { "description": "Genera una imagen a partir de un texto descriptivo utilizando el modelo Gen 4 de Runway. También puedes incluir una imagen de referencia para guiar la generación.", "display_name": "Runway Texto a Imagen", "inputs": { "prompt": { "name": "texto_descriptivo", "tooltip": "Texto descriptivo para la generación" }, "ratio": { "name": "proporción" }, "reference_image": { "name": "imagen_referencia", "tooltip": "Imagen de referencia opcional para guiar la generación" } }, "outputs": { "0": { "tooltip": null } } };
const SDTurboScheduler = { "display_name": "SDTurboScheduler", "inputs": { "denoise": { "name": "reducir_ruido" }, "model": { "name": "modelo" }, "steps": { "name": "pasos" } } };
const SD_4XUpscale_Conditioning = { "display_name": "SD_4XUpscale_Conditioning", "inputs": { "images": { "name": "imágenes" }, "negative": { "name": "negativo" }, "noise_augmentation": { "name": "aumento_ruido" }, "positive": { "name": "positivo" }, "scale_ratio": { "name": "relación_escala" } }, "outputs": { "0": { "name": "positivo", "tooltip": null }, "1": { "name": "negativo", "tooltip": null }, "2": { "name": "latente", "tooltip": null } } };
const SV3D_Conditioning = { "display_name": "SV3D_Acondicionamiento", "inputs": { "clip_vision": { "name": "clip_vision" }, "elevation": { "name": "elevación" }, "height": { "name": "altura" }, "init_image": { "name": "imagen_inicial" }, "vae": { "name": "vae" }, "video_frames": { "name": "cuadros_de_video" }, "width": { "name": "ancho" } }, "outputs": { "0": { "name": "positivo", "tooltip": null }, "1": { "name": "negativo", "tooltip": null }, "2": { "name": "latente", "tooltip": null } } };
const SVD_img2vid_Conditioning = { "display_name": "SVD_img2vid_Acondicionamiento", "inputs": { "augmentation_level": { "name": "nivel_de_aumento" }, "clip_vision": { "name": "clip_vision" }, "fps": { "name": "fps" }, "height": { "name": "altura" }, "init_image": { "name": "imagen_inicial" }, "motion_bucket_id": { "name": "id_del_cubeta_de_movimiento" }, "vae": { "name": "vae" }, "video_frames": { "name": "cuadros_de_video" }, "width": { "name": "ancho" } }, "outputs": { "0": { "name": "positivo" }, "1": { "name": "negativo" }, "2": { "name": "latente" } } };
const SamplerCustom = { "display_name": "Muestreador personalizado", "inputs": { "add_noise": { "name": "añadir_ruido" }, "cfg": { "name": "cfg" }, "control_after_generate": { "name": "control después de generar" }, "latent_image": { "name": "imagen_latente" }, "model": { "name": "modelo" }, "negative": { "name": "negativo" }, "noise_seed": { "name": "semilla_ruido" }, "positive": { "name": "positivo" }, "sampler": { "name": "muestreador" }, "sigmas": { "name": "sigmas" } }, "outputs": { "0": { "name": "salida" }, "1": { "name": "salida_denoisada" } } };
const SamplerCustomAdvanced = { "display_name": "SamplerCustomAdvanced", "inputs": { "guider": { "name": "guía" }, "latent_image": { "name": "imagen_latente" }, "noise": { "name": "ruido" }, "sampler": { "name": "muestreador" }, "sigmas": { "name": "sigmas" } }, "outputs": { "0": { "name": "salida" }, "1": { "name": "salida_denoised" } } };
const SamplerDPMAdaptative = { "display_name": "SamplerDPMAdaptative", "inputs": { "accept_safety": { "name": "aceptar_seguridad" }, "atol": { "name": "atol" }, "dcoeff": { "name": "dcoeff" }, "eta": { "name": "eta" }, "h_init": { "name": "h_init" }, "icoeff": { "name": "icoeff" }, "order": { "name": "orden" }, "pcoeff": { "name": "pcoeff" }, "rtol": { "name": "rtol" }, "s_noise": { "name": "s_ruido" } } };
const SamplerDPMPP_2M_SDE = { "display_name": "SamplerDPMPP_2M_SDE", "inputs": { "eta": { "name": "eta" }, "noise_device": { "name": "dispositivo_ruido" }, "s_noise": { "name": "s_ruido" }, "solver_type": { "name": "tipo_resolvedor" } } };
const SamplerDPMPP_2S_Ancestral = { "display_name": "SamplerDPMPP_2S_Ancestral", "inputs": { "eta": { "name": "eta" }, "s_noise": { "name": "s_ruido" } } };
const SamplerDPMPP_3M_SDE = { "display_name": "SamplerDPMPP_3M_SDE", "inputs": { "eta": { "name": "eta" }, "noise_device": { "name": "dispositivo_ruido" }, "s_noise": { "name": "s_ruido" } } };
const SamplerDPMPP_SDE = { "display_name": "SamplerDPMPP_SDE", "inputs": { "eta": { "name": "eta" }, "noise_device": { "name": "dispositivo_ruido" }, "r": { "name": "r" }, "s_noise": { "name": "s_ruido" } } };
const SamplerER_SDE = { "display_name": "SamplerER_SDE", "inputs": { "eta": { "name": "eta", "tooltip": "Fuerza estocástica de la EDE de tiempo inverso.\nCuando eta=0, se reduce a una EDO determinista. Esta configuración no se aplica al tipo de solucionador ER-SDE." }, "max_stage": { "name": "etapa_máxima" }, "s_noise": { "name": "s_ruido" }, "solver_type": { "name": "tipo_solucionador" } } };
const SamplerEulerAncestral = { "display_name": "SamplerEulerAncestral", "inputs": { "eta": { "name": "eta" }, "s_noise": { "name": "s_ruido" } } };
const SamplerEulerAncestralCFGPP = { "display_name": "SamplerEulerAncestralCFG++", "inputs": { "eta": { "name": "eta" }, "s_noise": { "name": "s_ruido" } } };
const SamplerEulerCFGpp = { "display_name": "SamplerEulerCFG++", "inputs": { "version": { "name": "versión" } }, "outputs": { "0": { "tooltip": null } } };
const SamplerLCMUpscale = { "display_name": "SamplerLCMUpscale", "inputs": { "scale_ratio": { "name": "relación_escala" }, "scale_steps": { "name": "pasos_escala" }, "upscale_method": { "name": "método_aumento_escala" } }, "outputs": { "0": { "tooltip": null } } };
const SamplerLMS = { "display_name": "SamplerLMS", "inputs": { "order": { "name": "orden" } } };
const SamplerSASolver = { "display_name": "SamplerSASolver", "inputs": { "corrector_order": { "name": "orden_corrector" }, "eta": { "name": "eta" }, "model": { "name": "modelo" }, "predictor_order": { "name": "orden_predictor" }, "s_noise": { "name": "s_ruido" }, "sde_end_percent": { "name": "porcentaje_fin_sde" }, "sde_start_percent": { "name": "porcentaje_inicio_sde" }, "simple_order_2": { "name": "orden_simple_2" }, "use_pece": { "name": "usar_pece" } } };
const SamplingPercentToSigma = { "display_name": "SamplingPercentToSigma", "inputs": { "model": { "name": "modelo" }, "return_actual_sigma": { "name": "devolver_sigma_real", "tooltip": "Devuelve el valor sigma real en lugar del valor utilizado para las comprobaciones de intervalo.\nEsto solo afecta los resultados en 0.0 y 1.0." }, "sampling_percent": { "name": "porcentaje_muestreo" } }, "outputs": { "0": { "name": "valor_sigma" } } };
const SaveAnimatedPNG = { "display_name": "GuardarPNGAnimado", "inputs": { "compress_level": { "name": "nivel_compresión" }, "filename_prefix": { "name": "prefijo_nombre_archivo" }, "fps": { "name": "fps" }, "images": { "name": "imágenes" } } };
const SaveAnimatedWEBP = { "display_name": "GuardarWEBPAnimado", "inputs": { "filename_prefix": { "name": "prefijo_nombre_archivo" }, "fps": { "name": "fps" }, "images": { "name": "imágenes" }, "lossless": { "name": "sin_pérdidas" }, "method": { "name": "método" }, "quality": { "name": "calidad" } } };
const SaveAudio = { "display_name": "GuardarAudio", "inputs": { "audio": { "name": "audio" }, "audioUI": { "name": "interfaz_audio" }, "filename_prefix": { "name": "prefijo_nombre_archivo" } } };
const SaveAudioMP3 = { "display_name": "Guardar Audio (MP3)", "inputs": { "audio": { "name": "audio" }, "audioUI": { "name": "Interfaz de audio" }, "filename_prefix": { "name": "prefijo_nombre_archivo" }, "quality": { "name": "calidad" } } };
const SaveAudioOpus = { "display_name": "Guardar audio (Opus)", "inputs": { "audio": { "name": "audio" }, "audioUI": { "name": "Interfaz de audio" }, "filename_prefix": { "name": "prefijo_nombre_archivo" }, "quality": { "name": "calidad" } } };
const SaveGLB = { "display_name": "GuardarGLB", "inputs": { "filename_prefix": { "name": "prefijo_nombre_archivo" }, "image": { "name": "imagen" }, "mesh": { "name": "malla" } } };
const SaveImage = { "description": "Guarda las imágenes de entrada en tu directorio de salida de ComfyUI.", "display_name": "Guardar Imagen", "inputs": { "filename_prefix": { "name": "prefijo_nombre_archivo", "tooltip": "El prefijo para el archivo a guardar. Esto puede incluir información de formato como %date:yyyy-MM-dd% o %Empty Latent Image.width% para incluir valores de los nodos." }, "images": { "name": "imágenes", "tooltip": "Las imágenes a guardar." } } };
const SaveImageWebsocket = { "display_name": "GuardarImagenWebsocket", "inputs": { "images": { "name": "imágenes" } } };
const SaveLatent = { "display_name": "GuardarLatente", "inputs": { "filename_prefix": { "name": "prefijo_nombre_archivo" }, "samples": { "name": "muestras" } } };
const SaveSVGNode = { "description": "Guardar archivos SVG en disco.", "display_name": "NodoGuardarSVG", "inputs": { "filename_prefix": { "name": "prefijo_nombre_archivo", "tooltip": "El prefijo para el archivo a guardar. Esto puede incluir información de formato como %date:yyyy-MM-dd% o %Empty Latent Image.width% para incluir valores de nodos." }, "svg": { "name": "svg" } } };
const SaveVideo = { "description": "Guarda las imágenes de entrada en tu directorio de salida de ComfyUI.", "display_name": "Guardar video", "inputs": { "codec": { "name": "códec", "tooltip": "El códec que se usará para el video." }, "filename_prefix": { "name": "prefijo_nombre_archivo", "tooltip": "El prefijo para el archivo a guardar. Esto puede incluir información de formato como %date:yyyy-MM-dd% o %Empty Latent Image.width% para incluir valores de los nodos." }, "format": { "name": "formato", "tooltip": "El formato en el que se guardará el video." }, "video": { "name": "video", "tooltip": "El video que se va a guardar." } } };
const SaveWEBM = { "display_name": "GuardarWEBM", "inputs": { "codec": { "name": "códec" }, "crf": { "name": "crf", "tooltip": "Un crf más alto significa menor calidad con un tamaño de archivo más pequeño, un crf más bajo significa mayor calidad con un tamaño de archivo más grande." }, "filename_prefix": { "name": "prefijo_nombre_archivo" }, "fps": { "name": "fps" }, "images": { "name": "imágenes" } } };
const ScaleROPE = { "description": "Escalar y desplazar el ROPE del modelo.", "display_name": "EscalarROPE", "inputs": { "model": { "name": "modelo" }, "scale_t": { "name": "escala_t" }, "scale_x": { "name": "escala_x" }, "scale_y": { "name": "escala_y" }, "shift_t": { "name": "desplazamiento_t" }, "shift_x": { "name": "desplazamiento_x" }, "shift_y": { "name": "desplazamiento_y" } }, "outputs": { "0": { "tooltip": null } } };
const SelfAttentionGuidance = { "display_name": "Orientación de Auto-Atención", "inputs": { "blur_sigma": { "name": "blur_sigma" }, "model": { "name": "modelo" }, "scale": { "name": "escala" } }, "outputs": { "0": { "tooltip": null } } };
const SetClipHooks = { "display_name": "Establecer Ganchos CLIP", "inputs": { "apply_to_conds": { "name": "aplicar_a_conds" }, "clip": { "name": "clip" }, "hooks": { "name": "ganchos" }, "schedule_clip": { "name": "programar_clip" } } };
const SetFirstSigma = { "display_name": "EstablecerPrimeraSigma", "inputs": { "sigma": { "name": "sigma" }, "sigmas": { "name": "sigmas" } } };
const SetHookKeyframes = { "display_name": "Establecer Fotogramas Clave de Gancho", "inputs": { "hook_kf": { "name": "gancho_kf" }, "hooks": { "name": "ganchos" } } };
const SetLatentNoiseMask = { "display_name": "Establecer Máscara de Ruido Latente", "inputs": { "mask": { "name": "máscara" }, "samples": { "name": "muestras" } } };
const SetUnionControlNetType = { "display_name": "EstablecerTipoDeRedDeControlUnion", "inputs": { "control_net": { "name": "controlnet" }, "type": { "name": "tipo" } }, "outputs": { "0": { "tooltip": null } } };
const SkipLayerGuidanceDiT = { "description": "Versión genérica del nodo de Orientación de Capa de Salto que se puede usar en cada modelo DiT.", "display_name": "Orientación de Capa de Salto DiT", "inputs": { "double_layers": { "name": "capas_dobles" }, "end_percent": { "name": "porcentaje_final" }, "model": { "name": "modelo" }, "rescaling_scale": { "name": "escala_reescalado" }, "scale": { "name": "escala" }, "single_layers": { "name": "capas_simples" }, "start_percent": { "name": "porcentaje_inicio" } }, "outputs": { "0": { "tooltip": null } } };
const SkipLayerGuidanceDiTSimple = { "description": "Versión simple del nodo OrientaciónSaltarCapaDiT que solo modifica el paso sin condición.", "display_name": "OrientaciónSaltarCapaDiTSimple", "inputs": { "double_layers": { "name": "capas_dobles" }, "end_percent": { "name": "porcentaje_fin" }, "model": { "name": "modelo" }, "single_layers": { "name": "capas_individuales" }, "start_percent": { "name": "porcentaje_inicio" } }, "outputs": { "0": { "tooltip": null } } };
const SkipLayerGuidanceSD3 = { "description": "Versión genérica del nodo de Orientación de Capa de Salto que se puede usar en cada modelo DiT.", "display_name": "Orientación de Capa de Salto SD3", "inputs": { "end_percent": { "name": "porcentaje_final" }, "layers": { "name": "capas" }, "model": { "name": "modelo" }, "scale": { "name": "escala" }, "start_percent": { "name": "porcentaje_inicio" } }, "outputs": { "0": { "tooltip": null } } };
const SolidMask = { "display_name": "Máscara Sólida", "inputs": { "height": { "name": "altura" }, "value": { "name": "valor" }, "width": { "name": "ancho" } } };
const SplitAudioChannels = { "description": "Separa el audio en canales izquierdo y derecho.", "display_name": "Separar canales de audio", "inputs": { "audio": { "name": "audio" } }, "outputs": { "0": { "name": "izquierdo" }, "1": { "name": "derecho" } } };
const SplitImageWithAlpha = { "display_name": "Dividir Imagen con Alfa", "inputs": { "image": { "name": "imagen" } }, "outputs": { "0": { "tooltip": null }, "1": { "tooltip": null } } };
const SplitSigmas = { "display_name": "DividirSigmas", "inputs": { "sigmas": { "name": "sigmas" }, "step": { "name": "paso" } }, "outputs": { "0": { "name": "sigmas_altas" }, "1": { "name": "sigmas_bajas" } } };
const SplitSigmasDenoise = { "display_name": "SplitSigmasDenoise", "inputs": { "denoise": { "name": "denoise" }, "sigmas": { "name": "sigmas" } }, "outputs": { "0": { "name": "high_sigmas" }, "1": { "name": "low_sigmas" } } };
const StabilityAudioInpaint = { "description": "Transforma parte de una muestra de audio existente usando instrucciones de texto.", "display_name": "Reconstrucción de audio Stability AI", "inputs": { "audio": { "name": "audio", "tooltip": "El audio debe tener una duración entre 6 y 190 segundos." }, "control_after_generate": { "name": "controlar después de generar" }, "duration": { "name": "duración", "tooltip": "Controla la duración en segundos del audio generado." }, "mask_end": { "name": "máscara_fin" }, "mask_start": { "name": "máscara_inicio" }, "model": { "name": "modelo" }, "prompt": { "name": "prompt" }, "seed": { "name": "semilla", "tooltip": "La semilla aleatoria utilizada para la generación." }, "steps": { "name": "pasos", "tooltip": "Controla el número de pasos de muestreo." } }, "outputs": { "0": { "tooltip": null } } };
const StabilityAudioToAudio = { "description": "Transforma muestras de audio existentes en nuevas composiciones de alta calidad usando instrucciones de texto.", "display_name": "Stability AI Audio a Audio", "inputs": { "audio": { "name": "audio", "tooltip": "El audio debe tener una duración entre 6 y 190 segundos." }, "control_after_generate": { "name": "controlar después de generar" }, "duration": { "name": "duración", "tooltip": "Controla la duración en segundos del audio generado." }, "model": { "name": "modelo" }, "prompt": { "name": "prompt" }, "seed": { "name": "semilla", "tooltip": "La semilla aleatoria utilizada para la generación." }, "steps": { "name": "pasos", "tooltip": "Controla el número de pasos de muestreo." }, "strength": { "name": "intensidad", "tooltip": "El parámetro controla cuánta influencia tiene el parámetro de audio en el audio generado." } }, "outputs": { "0": { "tooltip": null } } };
const StabilityStableImageSD_3_5Node = { "description": "Genera imágenes de forma sincrónica según el prompt y la resolución.", "display_name": "Stability AI Stable Diffusion 3.5 Imagen", "inputs": { "aspect_ratio": { "name": "aspect_ratio", "tooltip": "Relación de aspecto de la imagen generada." }, "cfg_scale": { "name": "cfg_scale", "tooltip": "Qué tan estrictamente el proceso de difusión se adhiere al texto del prompt (valores más altos mantienen la imagen más cercana a tu prompt)." }, "control_after_generate": { "name": "control after generate" }, "image": { "name": "image" }, "image_denoise": { "name": "image_denoise", "tooltip": "Reducción de ruido de la imagen de entrada; 0.0 produce una imagen idéntica a la entrada, 1.0 es como si no se hubiera proporcionado ninguna imagen." }, "model": { "name": "model" }, "negative_prompt": { "name": "negative_prompt", "tooltip": "Palabras clave de lo que no deseas ver en la imagen de salida. Esta es una función avanzada." }, "prompt": { "name": "prompt", "tooltip": "Lo que deseas ver en la imagen de salida. Un prompt fuerte y descriptivo que defina claramente los elementos, colores y sujetos dará mejores resultados." }, "seed": { "name": "seed", "tooltip": "La semilla aleatoria utilizada para crear el ruido." }, "style_preset": { "name": "style_preset", "tooltip": "Estilo opcional deseado para la imagen generada." } }, "outputs": { "0": { "tooltip": null } } };
const StabilityStableImageUltraNode = { "description": "Genera imágenes de forma sincrónica según el prompt y la resolución.", "display_name": "Stability AI Stable Image Ultra", "inputs": { "aspect_ratio": { "name": "aspect_ratio", "tooltip": "Relación de aspecto de la imagen generada." }, "control_after_generate": { "name": "control after generate" }, "image": { "name": "image" }, "image_denoise": { "name": "image_denoise", "tooltip": "Nivel de eliminación de ruido de la imagen de entrada; 0.0 produce una imagen idéntica a la entrada, 1.0 es como si no se hubiera proporcionado ninguna imagen." }, "negative_prompt": { "name": "negative_prompt", "tooltip": "Un texto que describe lo que no deseas ver en la imagen de salida. Esta es una función avanzada." }, "prompt": { "name": "prompt", "tooltip": "Lo que deseas ver en la imagen de salida. Un prompt fuerte y descriptivo que defina claramente los elementos, colores y sujetos dará mejores resultados. Para controlar el peso de una palabra usa el formato `(palabra:peso)`, donde `palabra` es la palabra cuyo peso deseas controlar y `peso` es un valor entre 0 y 1. Por ejemplo: `El cielo era de un (azul:0.3) y (verde:0.8) nítidos` indicará un cielo azul y verde, pero más verde que azul." }, "seed": { "name": "seed", "tooltip": "La semilla aleatoria utilizada para crear el ruido." }, "style_preset": { "name": "style_preset", "tooltip": "Estilo opcional deseado para la imagen generada." } }, "outputs": { "0": { "tooltip": null } } };
const StabilityTextToAudio = { "description": "Genera música y efectos de sonido de alta calidad a partir de descripciones de texto.", "display_name": "Stability AI Texto a Audio", "inputs": { "control_after_generate": { "name": "controlar después de generar" }, "duration": { "name": "duración", "tooltip": "Controla la duración en segundos del audio generado." }, "model": { "name": "modelo" }, "prompt": { "name": "prompt" }, "seed": { "name": "semilla", "tooltip": "La semilla aleatoria utilizada para la generación." }, "steps": { "name": "pasos", "tooltip": "Controla el número de pasos de muestreo." } }, "outputs": { "0": { "tooltip": null } } };
const StabilityUpscaleConservativeNode = { "description": "Aumenta la resolución de la imagen a 4K con alteraciones mínimas.", "display_name": "Stability AI Upscale Conservador", "inputs": { "control_after_generate": { "name": "controlar después de generar" }, "creativity": { "name": "creatividad", "tooltip": "Controla la probabilidad de crear detalles adicionales que no estén fuertemente condicionados por la imagen inicial." }, "image": { "name": "imagen" }, "negative_prompt": { "name": "prompt negativo", "tooltip": "Palabras clave de lo que no deseas ver en la imagen de salida. Esta es una función avanzada." }, "prompt": { "name": "prompt", "tooltip": "Lo que deseas ver en la imagen de salida. Un prompt fuerte y descriptivo que defina claramente los elementos, colores y sujetos dará mejores resultados." }, "seed": { "name": "semilla", "tooltip": "La semilla aleatoria utilizada para crear el ruido." } }, "outputs": { "0": { "tooltip": null } } };
const StabilityUpscaleCreativeNode = { "description": "Aumenta la resolución de la imagen a 4K con alteraciones mínimas.", "display_name": "Stability AI Upscale Creative", "inputs": { "control_after_generate": { "name": "controlar después de generar" }, "creativity": { "name": "creatividad", "tooltip": "Controla la probabilidad de crear detalles adicionales que no estén fuertemente condicionados por la imagen inicial." }, "image": { "name": "imagen" }, "negative_prompt": { "name": "prompt negativo", "tooltip": "Palabras clave de lo que no deseas ver en la imagen de salida. Esta es una función avanzada." }, "prompt": { "name": "prompt", "tooltip": "Lo que deseas ver en la imagen de salida. Un prompt fuerte y descriptivo que defina claramente los elementos, colores y sujetos dará mejores resultados." }, "seed": { "name": "semilla", "tooltip": "La semilla aleatoria utilizada para crear el ruido." }, "style_preset": { "name": "estilo predefinido", "tooltip": "Estilo opcional deseado para la imagen generada." } }, "outputs": { "0": { "tooltip": null } } };
const StabilityUpscaleFastNode = { "description": "Aumenta rápidamente una imagen a 4x su tamaño original mediante una llamada a la API de Stability; pensado para mejorar imágenes de baja calidad o comprimidas.", "display_name": "Stability AI Escalado Rápido", "inputs": { "image": { "name": "imagen" } }, "outputs": { "0": { "tooltip": null } } };
const StableCascade_EmptyLatentImage = { "display_name": "StableCascade_EmptyLatentImage", "inputs": { "batch_size": { "name": "tamaño_del_lote" }, "compression": { "name": "compresión" }, "height": { "name": "altura" }, "width": { "name": "ancho" } }, "outputs": { "0": { "name": "etapa_c", "tooltip": null }, "1": { "name": "etapa_b", "tooltip": null } } };
const StableCascade_StageB_Conditioning = { "display_name": "StableCascade_StageB_Conditioning", "inputs": { "conditioning": { "name": "acondicionamiento" }, "stage_c": { "name": "etapa_c" } }, "outputs": { "0": { "tooltip": null } } };
const StableCascade_StageC_VAEEncode = { "display_name": "StableCascade_StageC_VAEEncode", "inputs": { "compression": { "name": "compresión" }, "image": { "name": "imagen" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "etapa_c", "tooltip": null }, "1": { "name": "etapa_b", "tooltip": null } } };
const StableCascade_SuperResolutionControlnet = { "display_name": "StableCascade_SuperResolutionControlnet", "inputs": { "image": { "name": "imagen" }, "vae": { "name": "vae" } }, "outputs": { "0": { "name": "entrada_controlnet", "tooltip": null }, "1": { "name": "etapa_c", "tooltip": null }, "2": { "name": "etapa_b", "tooltip": null } } };
const StableZero123_Conditioning = { "display_name": "StableZero123_Conditioning", "inputs": { "azimuth": { "name": "acimut" }, "batch_size": { "name": "tamaño_del_lote" }, "clip_vision": { "name": "visión_clip" }, "elevation": { "name": "elevación" }, "height": { "name": "altura" }, "init_image": { "name": "imagen_inicial" }, "vae": { "name": "vae" }, "width": { "name": "ancho" } }, "outputs": { "0": { "name": "positivo", "tooltip": null }, "1": { "name": "negativo", "tooltip": null }, "2": { "name": "latente", "tooltip": null } } };
const StableZero123_Conditioning_Batched = { "display_name": "StableZero123_Conditioning_Batched", "inputs": { "azimuth": { "name": "acimut" }, "azimuth_batch_increment": { "name": "incremento_de_lote_de_acimut" }, "batch_size": { "name": "tamaño_del_lote" }, "clip_vision": { "name": "clip_vision" }, "elevation": { "name": "elevación" }, "elevation_batch_increment": { "name": "incremento_de_lote_de_elevación" }, "height": { "name": "altura" }, "init_image": { "name": "imagen_inicial" }, "vae": { "name": "vae" }, "width": { "name": "ancho" } }, "outputs": { "0": { "name": "positivo", "tooltip": null }, "1": { "name": "negativo", "tooltip": null }, "2": { "name": "latente", "tooltip": null } } };
const StringCompare = { "display_name": "Comparar", "inputs": { "case_sensitive": { "name": "distingue mayúsculas y minúsculas" }, "mode": { "name": "modo" }, "string_a": { "name": "cadena_a" }, "string_b": { "name": "cadena_b" } }, "outputs": { "0": { "tooltip": null } } };
const StringConcatenate = { "display_name": "Concatenar", "inputs": { "delimiter": { "name": "delimitador" }, "string_a": { "name": "cadena_a" }, "string_b": { "name": "cadena_b" } }, "outputs": { "0": { "tooltip": null } } };
const StringContains = { "display_name": "Contiene", "inputs": { "case_sensitive": { "name": "distingue mayúsculas y minúsculas" }, "string": { "name": "cadena" }, "substring": { "name": "subcadena" } }, "outputs": { "0": { "name": "contiene", "tooltip": null } } };
const StringLength = { "display_name": "Longitud", "inputs": { "string": { "name": "cadena" } }, "outputs": { "0": { "name": "longitud", "tooltip": null } } };
const StringReplace = { "display_name": "Reemplazar", "inputs": { "find": { "name": "buscar" }, "replace": { "name": "reemplazar" }, "string": { "name": "cadena" } }, "outputs": { "0": { "tooltip": null } } };
const StringSubstring = { "display_name": "Subcadena", "inputs": { "end": { "name": "fin" }, "start": { "name": "inicio" }, "string": { "name": "cadena" } }, "outputs": { "0": { "tooltip": null } } };
const StringTrim = { "display_name": "Recortar", "inputs": { "mode": { "name": "modo" }, "string": { "name": "cadena" } }, "outputs": { "0": { "tooltip": null } } };
const StyleModelApply = { "display_name": "Aplicar Modelo de Estilo", "inputs": { "clip_vision_output": { "name": "salida_de_clip_vision" }, "conditioning": { "name": "acondicionamiento" }, "strength": { "name": "fuerza" }, "strength_type": { "name": "tipo_de_fuerza" }, "style_model": { "name": "modelo_de_estilo" } } };
const StyleModelLoader = { "display_name": "Cargar Modelo de Estilo", "inputs": { "style_model_name": { "name": "nombre_del_modelo_de_estilo" } } };
const T5TokenizerOptions = { "display_name": "T5TokenizerOptions", "inputs": { "clip": { "name": "clip" }, "min_length": { "name": "mín_longitud" }, "min_padding": { "name": "mín_relleno" } }, "outputs": { "0": { "tooltip": null } } };
const TCFG = { "description": "TCFG – Amortiguación Tangencial CFG (2503.18137)\n\nRefina el uncond (negativo) para alinearlo con el cond (positivo) para mejorar la calidad.", "display_name": "Amortiguación Tangencial CFG", "inputs": { "model": { "name": "modelo" } }, "outputs": { "0": { "name": "modelo_modificado", "tooltip": null } } };
const TemporalScoreRescaling = { "description": "[Función Post-CFG]\nTSR - Reajuste de Puntuación Temporal (2510.01184)\n\nReajusta la puntuación o ruido del modelo para dirigir la diversidad del muestreo.", "display_name": "TSR - Reajuste de Puntuación Temporal", "inputs": { "model": { "name": "modelo" }, "tsr_k": { "name": "tsr_k", "tooltip": "Controla la fuerza del reajuste.\nUna k más baja produce resultados más detallados; una k más alta produce resultados más suaves en la generación de imágenes. Establecer k = 1 desactiva el reajuste." }, "tsr_sigma": { "name": "tsr_sigma", "tooltip": "Controla cuándo comienza a tener efecto el reajuste.\nValores más grandes toman efecto antes." } }, "outputs": { "0": { "name": "modelo_modificado", "tooltip": null } } };
const TextEncodeAceStepAudio = { "display_name": "TextEncodeAceStepAudio", "inputs": { "clip": { "name": "clip" }, "lyrics": { "name": "letras" }, "lyrics_strength": { "name": "intensidad_letras" }, "tags": { "name": "etiquetas" } }, "outputs": { "0": { "tooltip": null } } };
const TextEncodeHunyuanVideo_ImageToVideo = { "display_name": "TextEncodeHunyuanVideo_ImagenAVideo", "inputs": { "clip": { "name": "clip" }, "clip_vision_output": { "name": "salida_de_clip_vision" }, "image_interleave": { "name": "entrelazado_de_imagen", "tooltip": "Cuánto influye la imagen en las cosas frente al indicación de texto. Un número más alto significa más influencia del indicación de texto." }, "prompt": { "name": "indicación" } }, "outputs": { "0": { "tooltip": null } } };
const TextEncodeQwenImageEdit = { "display_name": "TextEncodeQwenImageEdit", "inputs": { "clip": { "name": "clip" }, "image": { "name": "imagen" }, "prompt": { "name": "prompt" }, "vae": { "name": "vae" } }, "outputs": { "0": { "tooltip": null } } };
const TextEncodeQwenImageEditPlus = { "display_name": "TextEncodeQwenImageEditPlus", "inputs": { "clip": { "name": "clip" }, "image1": { "name": "imagen1" }, "image2": { "name": "imagen2" }, "image3": { "name": "imagen3" }, "prompt": { "name": "prompt" }, "vae": { "name": "vae" } }, "outputs": { "0": { "tooltip": null } } };
const ThresholdMask = { "display_name": "Máscara de Umbral", "inputs": { "mask": { "name": "máscara" }, "value": { "name": "valor" } } };
const TomePatchModel = { "display_name": "Modelo de Parche Tome", "inputs": { "model": { "name": "modelo" }, "ratio": { "name": "ratio" } }, "outputs": { "0": { "tooltip": null } } };
const TorchCompileModel = { "display_name": "Modelo de Compilación Torch", "inputs": { "backend": { "name": "backend" }, "model": { "name": "modelo" } }, "outputs": { "0": { "tooltip": null } } };
const TrainLoraNode = { "display_name": "Entrenar LoRA", "inputs": { "algorithm": { "name": "algoritmo", "tooltip": "El algoritmo a usar para el entrenamiento." }, "batch_size": { "name": "tamaño_lote", "tooltip": "El tamaño de lote a utilizar para el entrenamiento." }, "control_after_generate": { "name": "controlar después de generar" }, "existing_lora": { "name": "lora_existente", "tooltip": "El LoRA existente al que añadir. Establecer en Ninguno para nuevo LoRA." }, "grad_accumulation_steps": { "name": "pasos_acumulación_gradiente", "tooltip": "El número de pasos de acumulación de gradiente a utilizar para el entrenamiento." }, "gradient_checkpointing": { "name": "verificación_gradiente", "tooltip": "Usar verificación de gradiente para el entrenamiento." }, "latents": { "name": "latentes", "tooltip": "Los latentes a utilizar para el entrenamiento, sirven como conjunto de datos/entrada del modelo." }, "learning_rate": { "name": "tasa_aprendizaje", "tooltip": "La tasa de aprendizaje a utilizar para el entrenamiento." }, "lora_dtype": { "name": "tipo_datos_lora", "tooltip": "El tipo de datos a usar para LoRA." }, "loss_function": { "name": "función_pérdida", "tooltip": "La función de pérdida a utilizar para el entrenamiento." }, "model": { "name": "modelo", "tooltip": "El modelo sobre el cual entrenar el LoRA." }, "optimizer": { "name": "optimizador", "tooltip": "El optimizador a utilizar para el entrenamiento." }, "positive": { "name": "positivo", "tooltip": "El condicionamiento positivo a utilizar para el entrenamiento." }, "rank": { "name": "rango", "tooltip": "El rango de las capas LoRA." }, "seed": { "name": "semilla", "tooltip": "La semilla a utilizar para el entrenamiento (utilizada en el generador para la inicialización de pesos LoRA y muestreo de ruido)." }, "steps": { "name": "pasos", "tooltip": "El número de pasos para entrenar el LoRA." }, "training_dtype": { "name": "tipo_datos_entrenamiento", "tooltip": "El tipo de datos a usar para el entrenamiento." } }, "outputs": { "0": { "name": "modelo_con_lora" }, "1": { "name": "lora" }, "2": { "name": "pérdida" }, "3": { "name": "pasos" } } };
const TrimAudioDuration = { "description": "Recortar tensor de audio al rango de tiempo elegido.", "display_name": "Recortar Duración de Audio", "inputs": { "audio": { "name": "audio" }, "duration": { "name": "duración", "tooltip": "Duración en segundos" }, "start_index": { "name": "índice_inicio", "tooltip": "Tiempo de inicio en segundos, puede ser negativo para contar desde el final (admite subsegundos)." } } };
const TrimVideoLatent = { "display_name": "TrimVideoLatent", "inputs": { "samples": { "name": "muestras" }, "trim_amount": { "name": "cantidad_de_recorte" } }, "outputs": { "0": { "tooltip": null } } };
const TripleCLIPLoader = { "description": "[Recetas]\n\nsd3: clip-l, clip-g, t5", "display_name": "Cargador Triple CLIP", "inputs": { "clip_name1": { "name": "nombre_clip1" }, "clip_name2": { "name": "nombre_clip2" }, "clip_name3": { "name": "nombre_clip3" } }, "outputs": { "0": { "tooltip": null } } };
const TripoConversionNode = { "display_name": "Tripo: Convertir modelo", "inputs": { "face_limit": { "name": "límite_caras" }, "format": { "name": "formato" }, "original_model_task_id": { "name": "id_tarea_modelo_original" }, "quad": { "name": "cuadrangular" }, "texture_format": { "name": "formato_textura" }, "texture_size": { "name": "tamaño_textura" } } };
const TripoImageToModelNode = { "display_name": "Tripo: Imagen a Modelo", "inputs": { "face_limit": { "name": "límite_de_caras" }, "image": { "name": "imagen" }, "model_seed": { "name": "semilla_modelo" }, "model_version": { "name": "versión_modelo", "tooltip": "La versión del modelo a usar para la generación" }, "orientation": { "name": "orientación" }, "pbr": { "name": "pbr" }, "quad": { "name": "cuadrilátero" }, "style": { "name": "estilo" }, "texture": { "name": "textura" }, "texture_alignment": { "name": "alineación_de_textura" }, "texture_quality": { "name": "calidad_textura" }, "texture_seed": { "name": "semilla_textura" } }, "outputs": { "0": { "name": "archivo_de_modelo", "tooltip": null }, "1": { "name": "ID_de_tarea_del_modelo", "tooltip": null } } };
const TripoMultiviewToModelNode = { "display_name": "Tripo: Multivista a Modelo", "inputs": { "face_limit": { "name": "límite_de_caras" }, "image": { "name": "imagen" }, "image_back": { "name": "imagen_posterior" }, "image_left": { "name": "imagen_izquierda" }, "image_right": { "name": "imagen_derecha" }, "model_seed": { "name": "semilla_del_modelo" }, "model_version": { "name": "versión_del_modelo", "tooltip": "La versión del modelo a utilizar para la generación" }, "orientation": { "name": "orientación" }, "pbr": { "name": "pbr" }, "quad": { "name": "cuadrilátero" }, "texture": { "name": "textura" }, "texture_alignment": { "name": "alineación_de_textura" }, "texture_quality": { "name": "calidad_de_textura" }, "texture_seed": { "name": "semilla_de_textura" } }, "outputs": { "0": { "name": "archivo_de_modelo", "tooltip": null }, "1": { "name": "ID_de_tarea_del_modelo", "tooltip": null } } };
const TripoRefineNode = { "description": "Refina un modelo borrador creado únicamente por modelos Tripo v1.4.", "display_name": "Tripo: Refinar modelo borrador", "inputs": { "model_task_id": { "name": "ID_de_tarea_del_modelo", "tooltip": "Debe ser un modelo Tripo v1.4" } }, "outputs": { "0": { "name": "archivo_de_modelo", "tooltip": null }, "1": { "name": "ID_de_tarea_del_modelo", "tooltip": null } } };
const TripoRetargetNode = { "display_name": "Tripo: Redireccionar modelo con rig", "inputs": { "animation": { "name": "animación" }, "original_model_task_id": { "name": "ID_de_tarea_del_modelo_original" } }, "outputs": { "0": { "name": "archivo_de_modelo", "tooltip": null }, "1": { "name": "ID_de_tarea_de_redireccionamiento", "tooltip": null } } };
const TripoRigNode = { "display_name": "Tripo: Modelo con rig", "inputs": { "original_model_task_id": { "name": "ID_de_tarea_del_modelo_original" } }, "outputs": { "0": { "name": "archivo_de_modelo", "tooltip": null }, "1": { "name": "ID_de_tarea_de_rig", "tooltip": null } } };
const TripoTextToModelNode = { "display_name": "Tripo: Texto a Modelo", "inputs": { "face_limit": { "name": "límite_de_caras" }, "image_seed": { "name": "semilla_de_imagen" }, "model_seed": { "name": "semilla_del_modelo" }, "model_version": { "name": "versión_del_modelo" }, "negative_prompt": { "name": "promoción_negativa" }, "pbr": { "name": "pbr" }, "prompt": { "name": "prompt" }, "quad": { "name": "cuadrante" }, "style": { "name": "estilo" }, "texture": { "name": "textura" }, "texture_quality": { "name": "calidad_de_textura" }, "texture_seed": { "name": "semilla_de_textura" } }, "outputs": { "0": { "name": "archivo_del_modelo", "tooltip": null }, "1": { "name": "tarea_del_modelo", "tooltip": null } } };
const TripoTextureNode = { "display_name": "Tripo: Modelo de textura", "inputs": { "model_task_id": { "name": "id_de_tarea_del_modelo" }, "pbr": { "name": "pbr" }, "texture": { "name": "textura" }, "texture_alignment": { "name": "alineación_de_textura" }, "texture_quality": { "name": "calidad_de_textura" }, "texture_seed": { "name": "semilla_de_textura" } }, "outputs": { "0": { "name": "archivo_del_modelo", "tooltip": null }, "1": { "name": "tarea_del_modelo", "tooltip": null } } };
const UNETLoader = { "display_name": "Cargar Modelo de Difusión", "inputs": { "unet_name": { "name": "nombre_unet" }, "weight_dtype": { "name": "tipo_dato_peso" } } };
const UNetCrossAttentionMultiply = { "display_name": "Multiplicación de Atención Cruzada UNet", "inputs": { "k": { "name": "k" }, "model": { "name": "modelo" }, "out": { "name": "salida" }, "q": { "name": "q" }, "v": { "name": "v" } }, "outputs": { "0": { "tooltip": null } } };
const UNetSelfAttentionMultiply = { "display_name": "Multiplicación de Auto Atención UNet", "inputs": { "k": { "name": "k" }, "model": { "name": "modelo" }, "out": { "name": "salida" }, "q": { "name": "q" }, "v": { "name": "v" } }, "outputs": { "0": { "tooltip": null } } };
const UNetTemporalAttentionMultiply = { "display_name": "Multiplicación de Atención Temporal UNet", "inputs": { "cross_structural": { "name": "cruz_estructural" }, "cross_temporal": { "name": "cruz_temporal" }, "model": { "name": "modelo" }, "self_structural": { "name": "auto_estructural" }, "self_temporal": { "name": "auto_temporal" } }, "outputs": { "0": { "tooltip": null } } };
const USOStyleReference = { "display_name": "ReferenciaDeEstiloUSO", "inputs": { "clip_vision_output": { "name": "salida_de_visión_clip" }, "model": { "name": "modelo" }, "model_patch": { "name": "parche_del_modelo" } } };
const UpscaleModelLoader = { "display_name": "Cargar Modelo de Escala Superior", "inputs": { "model_name": { "name": "nombre_modelo" } }, "outputs": { "0": { "tooltip": null } } };
const VAEDecode = { "description": "Decodifica imágenes latentes de nuevo en imágenes de espacio de píxeles.", "display_name": "Decodificación VAE", "inputs": { "samples": { "name": "muestras", "tooltip": "El latente a ser decodificado." }, "vae": { "name": "vae", "tooltip": "El modelo VAE utilizado para decodificar el latente." } }, "outputs": { "0": { "tooltip": "La imagen decodificada." } } };
const VAEDecodeAudio = { "display_name": "VAEDecodeAudio", "inputs": { "samples": { "name": "muestras" }, "vae": { "name": "vae" } } };
const VAEDecodeHunyuan3D = { "display_name": "VAEDecodeHunyuan3D", "inputs": { "num_chunks": { "name": "num_chunks" }, "octree_resolution": { "name": "resolución_octree" }, "samples": { "name": "muestras" }, "vae": { "name": "vae" } } };
const VAEDecodeTiled = { "display_name": "VAE Decodificar (Mosaico)", "inputs": { "overlap": { "name": "superposición" }, "samples": { "name": "muestras" }, "temporal_overlap": { "name": "superposición_temporal", "tooltip": "Solo se utiliza para VAEs de video: Cantidad de fotogramas para superponer." }, "temporal_size": { "name": "tamaño_temporal", "tooltip": "Solo se utiliza para VAEs de video: Cantidad de fotogramas para decodificar a la vez." }, "tile_size": { "name": "tamaño_mosaico" }, "vae": { "name": "vae" } } };
const VAEEncode = { "display_name": "VAE Codificar", "inputs": { "pixels": { "name": "píxeles" }, "vae": { "name": "vae" } } };
const VAEEncodeAudio = { "display_name": "VAEEncodeAudio", "inputs": { "audio": { "name": "audio" }, "vae": { "name": "vae" } } };
const VAEEncodeForInpaint = { "display_name": "VAE Codificar (para Inpainting)", "inputs": { "grow_mask_by": { "name": "crecer_máscara_por" }, "mask": { "name": "máscara" }, "pixels": { "name": "píxeles" }, "vae": { "name": "vae" } } };
const VAEEncodeTiled = { "display_name": "VAE Codificar (Mosaico)", "inputs": { "overlap": { "name": "superposición" }, "pixels": { "name": "píxeles" }, "temporal_overlap": { "name": "superposición_temporal", "tooltip": "Solo se utiliza para VAEs de video: Cantidad de fotogramas para superponer." }, "temporal_size": { "name": "tamaño_temporal", "tooltip": "Solo se utiliza para VAEs de video: Cantidad de fotogramas para codificar a la vez." }, "tile_size": { "name": "tamaño_mosaico" }, "vae": { "name": "vae" } } };
const VAELoader = { "display_name": "Cargar VAE", "inputs": { "vae_name": { "name": "nombre_vae" } } };
const VAESave = { "display_name": "GuardarVAE", "inputs": { "filename_prefix": { "name": "prefijo_nombre_archivo" }, "vae": { "name": "vae" } } };
const VPScheduler = { "display_name": "VPScheduler", "inputs": { "beta_d": { "name": "beta_d" }, "beta_min": { "name": "beta_min" }, "eps_s": { "name": "eps_s" }, "steps": { "name": "pasos" } } };
const Veo3VideoGenerationNode = { "description": "Genera videos a partir de descripciones de texto usando la API de Google Veo 3", "display_name": "Generación de video Google Veo 3", "inputs": { "aspect_ratio": { "name": "relación_de_aspecto", "tooltip": "Relación de aspecto del video de salida" }, "control_after_generate": { "name": "control después de generar" }, "duration_seconds": { "name": "duración_segundos", "tooltip": "Duración del video de salida en segundos (Veo 3 solo admite 8 segundos)" }, "enhance_prompt": { "name": "mejorar_promoción", "tooltip": "Si se debe mejorar la promoción con asistencia de IA" }, "generate_audio": { "name": "generar_audio", "tooltip": "Generar audio para el video. Compatible con todos los modelos Veo 3." }, "image": { "name": "imagen", "tooltip": "Imagen de referencia opcional para guiar la generación de video" }, "model": { "name": "modelo", "tooltip": "Modelo Veo 3 a utilizar para la generación de video" }, "negative_prompt": { "name": "promoción_negativa", "tooltip": "Promoción de texto negativa para guiar qué evitar en el video" }, "person_generation": { "name": "generación_de_personas", "tooltip": "Si se permite generar personas en el video" }, "prompt": { "name": "promoción", "tooltip": "Descripción de texto del video" }, "seed": { "name": "semilla", "tooltip": "Semilla para la generación de video (0 para aleatorio)" } }, "outputs": { "0": { "tooltip": null } } };
const VeoVideoGenerationNode = { "description": "Genera videos a partir de indicaciones de texto usando la API de Veo de Google", "display_name": "Generación de Video Google Veo2", "inputs": { "aspect_ratio": { "name": "aspect_ratio", "tooltip": "Relación de aspecto del video de salida" }, "control_after_generate": { "name": "control after generate" }, "duration_seconds": { "name": "duration_seconds", "tooltip": "Duración del video de salida en segundos" }, "enhance_prompt": { "name": "enhance_prompt", "tooltip": "Si se debe mejorar la indicación con asistencia de IA" }, "image": { "name": "image", "tooltip": "Imagen de referencia opcional para guiar la generación del video" }, "model": { "name": "modelo", "tooltip": "Modelo Veo 2 a utilizar para la generación de video" }, "negative_prompt": { "name": "negative_prompt", "tooltip": "Indicaciones negativas para guiar lo que se debe evitar en el video" }, "person_generation": { "name": "person_generation", "tooltip": "Si se permite generar personas en el video" }, "prompt": { "name": "prompt", "tooltip": "Descripción de texto del video" }, "seed": { "name": "seed", "tooltip": "Semilla para la generación de video (0 para aleatorio)" } }, "outputs": { "0": { "tooltip": null } } };
const VideoLinearCFGGuidance = { "display_name": "OrientaciónLinealCFGVideo", "inputs": { "min_cfg": { "name": "min_cfg" }, "model": { "name": "modelo" } } };
const VideoTriangleCFGGuidance = { "display_name": "OrientaciónTriangularCFGVideo", "inputs": { "min_cfg": { "name": "min_cfg" }, "model": { "name": "modelo" } } };
const ViduImageToVideoNode = { "description": "Generar video a partir de imagen y texto opcional", "display_name": "Generación de Video a partir de Imagen Vidu", "inputs": { "control_after_generate": { "name": "control después de generar" }, "duration": { "name": "duración", "tooltip": "Duración del video de salida en segundos" }, "image": { "name": "imagen", "tooltip": "Una imagen para usar como fotograma inicial del video generado" }, "model": { "name": "modelo", "tooltip": "Nombre del modelo" }, "movement_amplitude": { "name": "amplitud_movimiento", "tooltip": "La amplitud de movimiento de los objetos en el fotograma" }, "prompt": { "name": "texto", "tooltip": "Una descripción textual para la generación de video" }, "resolution": { "name": "resolución", "tooltip": "Los valores admitidos pueden variar según el modelo y la duración" }, "seed": { "name": "semilla", "tooltip": "Semilla para la generación de video (0 para aleatorio)" } }, "outputs": { "0": { "tooltip": null } } };
const ViduReferenceVideoNode = { "description": "Generar video a partir de múltiples imágenes y texto", "display_name": "Generación de Video a partir de Referencia Vidu", "inputs": { "aspect_ratio": { "name": "relación_de_aspecto", "tooltip": "La relación de aspecto del video de salida" }, "control_after_generate": { "name": "control después de generar" }, "duration": { "name": "duración", "tooltip": "Duración del video de salida en segundos" }, "images": { "name": "imágenes", "tooltip": "Imágenes para usar como referencias y generar un video con sujetos consistentes (máximo 7 imágenes)." }, "model": { "name": "modelo", "tooltip": "Nombre del modelo" }, "movement_amplitude": { "name": "amplitud_de_movimiento", "tooltip": "La amplitud de movimiento de los objetos en el cuadro" }, "prompt": { "name": "texto", "tooltip": "Una descripción textual para la generación de video" }, "resolution": { "name": "resolución", "tooltip": "Los valores admitidos pueden variar según el modelo y la duración" }, "seed": { "name": "semilla", "tooltip": "Semilla para la generación de video (0 para aleatorio)" } }, "outputs": { "0": { "tooltip": null } } };
const ViduStartEndToVideoNode = { "description": "Generar un video a partir de cuadros inicial y final y un prompt", "display_name": "Generación de Video Vidu de Inicio a Fin", "inputs": { "control_after_generate": { "name": "control después de generar" }, "duration": { "name": "duración", "tooltip": "Duración del video de salida en segundos" }, "end_frame": { "name": "cuadro_final", "tooltip": "Cuadro final" }, "first_frame": { "name": "primer_cuadro", "tooltip": "Cuadro inicial" }, "model": { "name": "modelo", "tooltip": "Nombre del modelo" }, "movement_amplitude": { "name": "amplitud_de_movimiento", "tooltip": "La amplitud de movimiento de los objetos en el cuadro" }, "prompt": { "name": "prompt", "tooltip": "Una descripción textual para la generación de video" }, "resolution": { "name": "resolución", "tooltip": "Los valores admitidos pueden variar según el modelo y la duración" }, "seed": { "name": "semilla", "tooltip": "Semilla para la generación de video (0 para aleatorio)" } }, "outputs": { "0": { "tooltip": null } } };
const ViduTextToVideoNode = { "description": "Generar video a partir de un prompt de texto", "display_name": "Generación de Video Vidu de Texto a Video", "inputs": { "aspect_ratio": { "name": "relación_de_aspecto", "tooltip": "La relación de aspecto del video de salida" }, "control_after_generate": { "name": "control después de generar" }, "duration": { "name": "duración", "tooltip": "Duración del video de salida en segundos" }, "model": { "name": "modelo", "tooltip": "Nombre del modelo" }, "movement_amplitude": { "name": "amplitud_movimiento", "tooltip": "La amplitud de movimiento de los objetos en el fotograma" }, "prompt": { "name": "prompt", "tooltip": "Una descripción textual para la generación de video" }, "resolution": { "name": "resolución", "tooltip": "Los valores admitidos pueden variar según el modelo y la duración" }, "seed": { "name": "semilla", "tooltip": "Semilla para la generación de video (0 para aleatorio)" } }, "outputs": { "0": { "tooltip": null } } };
const VoxelToMesh = { "display_name": "VoxelToMesh", "inputs": { "algorithm": { "name": "algoritmo" }, "threshold": { "name": "umbral" }, "voxel": { "name": "voxel" } } };
const VoxelToMeshBasic = { "display_name": "VoxelAMallaBásico", "inputs": { "threshold": { "name": "umbral" }, "voxel": { "name": "voxel" } } };
const Wan22FunControlToVideo = { "display_name": "Wan22FunControlToVideo", "inputs": { "batch_size": { "name": "tamaño_lote" }, "control_video": { "name": "video_control" }, "height": { "name": "alto" }, "length": { "name": "duración" }, "negative": { "name": "negativo" }, "positive": { "name": "positivo" }, "ref_image": { "name": "imagen_ref" }, "vae": { "name": "vae" }, "width": { "name": "ancho" } }, "outputs": { "0": { "name": "positivo", "tooltip": null }, "1": { "name": "negativo", "tooltip": null }, "2": { "name": "latente", "tooltip": null } } };
const Wan22ImageToVideoLatent = { "display_name": "Wan22ImageToVideoLatent", "inputs": { "batch_size": { "name": "tamaño_lote" }, "height": { "name": "alto" }, "length": { "name": "duración" }, "start_image": { "name": "imagen_inicio" }, "vae": { "name": "vae" }, "width": { "name": "ancho" } }, "outputs": { "0": { "tooltip": null } } };
const WanAnimateToVideo = { "display_name": "WanAnimateToVideo", "inputs": { "background_video": { "name": "video_fondo" }, "batch_size": { "name": "tamaño_lote" }, "character_mask": { "name": "máscara_personaje" }, "clip_vision_output": { "name": "salida_visión_clip" }, "continue_motion": { "name": "continuar_movimiento" }, "continue_motion_max_frames": { "name": "máximo_fotogramas_continuación_movimiento" }, "face_video": { "name": "video_rostro" }, "height": { "name": "alto" }, "length": { "name": "duración" }, "negative": { "name": "negativo" }, "pose_video": { "name": "video_pose" }, "positive": { "name": "positivo" }, "reference_image": { "name": "imagen_referencia" }, "vae": { "name": "vae" }, "video_frame_offset": { "name": "desplazamiento_fotograma_video", "tooltip": "La cantidad de fotogramas a buscar en todos los videos de entrada. Se utiliza para generar videos más largos por fragmentos. Conecte a la salida video_frame_offset del nodo anterior para extender un video." }, "width": { "name": "ancho" } }, "outputs": { "0": { "name": "positivo", "tooltip": null }, "1": { "name": "negativo", "tooltip": null }, "2": { "name": "latente", "tooltip": null }, "3": { "name": "recortar_latente", "tooltip": null }, "4": { "name": "recortar_imagen", "tooltip": null }, "5": { "name": "desplazamiento_fotograma_video", "tooltip": null } } };
const WanCameraEmbedding = { "display_name": "IncrustaciónCámaraWan", "inputs": { "camera_pose": { "name": "pose_cámara" }, "cx": { "name": "cx" }, "cy": { "name": "cy" }, "fx": { "name": "fx" }, "fy": { "name": "fy" }, "height": { "name": "alto" }, "length": { "name": "longitud" }, "speed": { "name": "velocidad" }, "width": { "name": "ancho" } }, "outputs": { "0": { "name": "incrustación_cámara", "tooltip": null }, "1": { "name": "ancho", "tooltip": null }, "2": { "name": "alto", "tooltip": null }, "3": { "name": "longitud", "tooltip": null } } };
const WanCameraImageToVideo = { "display_name": "WanCameraImageToVideo", "inputs": { "batch_size": { "name": "tamaño_lote" }, "camera_conditions": { "name": "condiciones_cámara" }, "clip_vision_output": { "name": "salida_visión_clip" }, "height": { "name": "alto" }, "length": { "name": "longitud" }, "negative": { "name": "negativo" }, "positive": { "name": "positivo" }, "start_image": { "name": "imagen_inicio" }, "vae": { "name": "vae" }, "width": { "name": "ancho" } }, "outputs": { "0": { "name": "positivo", "tooltip": null }, "1": { "name": "negativo", "tooltip": null }, "2": { "name": "latente", "tooltip": null } } };
const WanContextWindowsManual = { "description": "Establecer manualmente las ventanas de contexto para modelos tipo WAN (dim=2).", "display_name": "Ventanas de Contexto WAN (Manual)", "inputs": { "closed_loop": { "name": "closed_loop", "tooltip": "Si cerrar el bucle de la ventana de contexto; solo aplicable a programaciones en bucle." }, "context_length": { "name": "longitud_contexto", "tooltip": "La longitud de la ventana de contexto." }, "context_overlap": { "name": "context_overlap", "tooltip": "La superposición de la ventana de contexto." }, "context_schedule": { "name": "context_schedule", "tooltip": "El paso de la ventana de contexto." }, "context_stride": { "name": "context_stride", "tooltip": "El paso de la ventana de contexto; solo aplicable a programaciones uniformes." }, "fuse_method": { "name": "fuse_method", "tooltip": "El método a utilizar para fusionar las ventanas de contexto." }, "model": { "name": "modelo", "tooltip": "El modelo al que aplicar las ventanas de contexto durante el muestreo." } }, "outputs": { "0": { "tooltip": "El modelo con ventanas de contexto aplicadas durante el muestreo." } } };
const WanFirstLastFrameToVideo = { "display_name": "WanFirstLastFrameToVideo", "inputs": { "batch_size": { "name": "tamaño_lote" }, "clip_vision_end_image": { "name": "clip_vision_end_image" }, "clip_vision_start_image": { "name": "clip_vision_start_image" }, "end_image": { "name": "imagen_final" }, "height": { "name": "alto" }, "length": { "name": "longitud" }, "negative": { "name": "negativo" }, "positive": { "name": "positivo" }, "start_image": { "name": "imagen_inicial" }, "vae": { "name": "vae" }, "width": { "name": "ancho" } }, "outputs": { "0": { "name": "positivo", "tooltip": null }, "1": { "name": "negativo", "tooltip": null }, "2": { "name": "latente", "tooltip": null } } };
const WanFunControlToVideo = { "display_name": "WanFunControlToVideo", "inputs": { "batch_size": { "name": "tamaño_lote" }, "clip_vision_output": { "name": "clip_vision_output" }, "control_video": { "name": "control_video" }, "height": { "name": "alto" }, "length": { "name": "longitud" }, "negative": { "name": "negativo" }, "positive": { "name": "positivo" }, "start_image": { "name": "imagen_inicial" }, "vae": { "name": "vae" }, "width": { "name": "ancho" } }, "outputs": { "0": { "name": "positivo", "tooltip": null }, "1": { "name": "negativo", "tooltip": null }, "2": { "name": "latente", "tooltip": null } } };
const WanFunInpaintToVideo = { "display_name": "WanFunInpaintToVideo", "inputs": { "batch_size": { "name": "tamaño_de_lote" }, "clip_vision_output": { "name": "clip_vision_output" }, "end_image": { "name": "imagen_final" }, "height": { "name": "alto" }, "length": { "name": "longitud" }, "negative": { "name": "negativo" }, "positive": { "name": "positivo" }, "start_image": { "name": "imagen_inicial" }, "vae": { "name": "vae" }, "width": { "name": "ancho" } }, "outputs": { "0": { "name": "positivo", "tooltip": null }, "1": { "name": "negativo", "tooltip": null }, "2": { "name": "latente", "tooltip": null } } };
const WanHuMoImageToVideo = { "display_name": "WanHuMoImageToVideo", "inputs": { "audio_encoder_output": { "name": "salida_codificador_audio" }, "batch_size": { "name": "tamaño_lote" }, "height": { "name": "alto" }, "length": { "name": "longitud" }, "negative": { "name": "negativo" }, "positive": { "name": "positivo" }, "ref_image": { "name": "imagen_referencia" }, "vae": { "name": "vae" }, "width": { "name": "ancho" } }, "outputs": { "0": { "name": "positivo", "tooltip": null }, "1": { "name": "negativo", "tooltip": null }, "2": { "name": "latente", "tooltip": null } } };
const WanImageToImageApi = { "description": "Genera una imagen a partir de una o dos imágenes de entrada y un texto descriptivo. La imagen de salida tiene actualmente una resolución fija de 1,6 MP; su relación de aspecto coincide con la(s) imagen(es) de entrada.", "display_name": "Wan Image to Image", "inputs": { "control_after_generate": { "name": "controlar después de generar" }, "image": { "name": "imagen", "tooltip": "Edición de imagen única o fusión de múltiples imágenes, máximo 2 imágenes." }, "model": { "name": "modelo", "tooltip": "Modelo a utilizar." }, "negative_prompt": { "name": "texto_negativo", "tooltip": "Texto negativo para guiar lo que se debe evitar." }, "prompt": { "name": "texto_descriptivo", "tooltip": "Texto descriptivo utilizado para describir los elementos y características visuales, admite inglés/chino." }, "seed": { "name": "semilla", "tooltip": "Semilla a utilizar para la generación." }, "watermark": { "name": "marca_agua", "tooltip": 'Si agregar una marca de agua "Generado por IA" al resultado.' } }, "outputs": { "0": { "tooltip": null } } };
const WanImageToVideo = { "display_name": "WanImageToVideo", "inputs": { "batch_size": { "name": "tamaño_del_lote" }, "clip_vision_output": { "name": "salida_de_vision_clip" }, "height": { "name": "altura" }, "length": { "name": "longitud" }, "negative": { "name": "negativo" }, "positive": { "name": "positivo" }, "start_image": { "name": "imagen_inicial" }, "vae": { "name": "vae" }, "width": { "name": "ancho" } }, "outputs": { "0": { "name": "positivo", "tooltip": null }, "1": { "name": "negativo", "tooltip": null }, "2": { "name": "latente", "tooltip": null } } };
const WanImageToVideoApi = { "description": "Genera video basado en el primer fotograma y el texto de entrada.", "display_name": "Wan Imagen a Video", "inputs": { "audio": { "name": "audio", "tooltip": "El audio debe contener una voz clara y fuerte, sin ruido extraño ni música de fondo." }, "control_after_generate": { "name": "controlar después de generar" }, "duration": { "name": "duración", "tooltip": "Duración disponible: 5 y 10 segundos" }, "generate_audio": { "name": "generar_audio", "tooltip": "Si no hay entrada de audio, generar audio automáticamente." }, "image": { "name": "imagen" }, "model": { "name": "modelo", "tooltip": "Modelo a utilizar." }, "negative_prompt": { "name": "texto_negativo", "tooltip": "Texto negativo para guiar qué elementos evitar." }, "prompt": { "name": "texto", "tooltip": "Texto utilizado para describir los elementos y características visuales, admite inglés/chino." }, "prompt_extend": { "name": "extender_texto", "tooltip": "Si se debe mejorar el texto con asistencia de IA." }, "resolution": { "name": "resolución" }, "seed": { "name": "semilla", "tooltip": "Semilla a utilizar para la generación." }, "watermark": { "name": "marca_agua", "tooltip": 'Si se debe agregar una marca de agua "Generado por IA" al resultado.' } }, "outputs": { "0": { "tooltip": null } } };
const WanPhantomSubjectToVideo = { "display_name": "WanPhantomSubjectToVideo", "inputs": { "batch_size": { "name": "tamaño_lote" }, "height": { "name": "alto" }, "images": { "name": "imágenes" }, "length": { "name": "longitud" }, "negative": { "name": "negativo" }, "positive": { "name": "positivo" }, "vae": { "name": "vae" }, "width": { "name": "ancho" } }, "outputs": { "0": { "name": "positivo", "tooltip": null }, "1": { "name": "texto_negativo", "tooltip": null }, "2": { "name": "texto_img_negativa", "tooltip": null }, "3": { "name": "latente", "tooltip": null } } };
const WanSoundImageToVideo = { "display_name": "WanSoundImageToVideo", "inputs": { "audio_encoder_output": { "name": "salida_codificador_audio" }, "batch_size": { "name": "tamaño_lote" }, "control_video": { "name": "video_control" }, "height": { "name": "alto" }, "length": { "name": "longitud" }, "negative": { "name": "negativo" }, "positive": { "name": "positivo" }, "ref_image": { "name": "imagen_ref" }, "ref_motion": { "name": "movimiento_ref" }, "vae": { "name": "vae" }, "width": { "name": "ancho" } }, "outputs": { "0": { "name": "positivo", "tooltip": null }, "1": { "name": "negativo", "tooltip": null }, "2": { "name": "latente", "tooltip": null } } };
const WanSoundImageToVideoExtend = { "display_name": "WanSoundImageToVideoExtend", "inputs": { "audio_encoder_output": { "name": "salida_codificador_audio" }, "control_video": { "name": "video_control" }, "length": { "name": "longitud" }, "negative": { "name": "negativo" }, "positive": { "name": "positivo" }, "ref_image": { "name": "imagen_ref" }, "vae": { "name": "vae" }, "video_latent": { "name": "video_latente" } }, "outputs": { "0": { "name": "positivo", "tooltip": null }, "1": { "name": "negativo", "tooltip": null }, "2": { "name": "latente", "tooltip": null } } };
const WanTextToImageApi = { "description": "Genera imagen basada en texto de entrada.", "display_name": "Wan Texto a Imagen", "inputs": { "control_after_generate": { "name": "controlar después de generar" }, "height": { "name": "alto" }, "model": { "name": "modelo", "tooltip": "Modelo a utilizar." }, "negative_prompt": { "name": "texto_negativo", "tooltip": "Texto negativo que guía sobre qué evitar." }, "prompt": { "name": "texto_entrada", "tooltip": "Texto que describe los elementos y características visuales, admite inglés/chino." }, "prompt_extend": { "name": "extender_texto", "tooltip": "Si se debe mejorar el texto de entrada con asistencia de IA." }, "seed": { "name": "semilla", "tooltip": "Semilla a utilizar para la generación." }, "watermark": { "name": "marca_agua", "tooltip": 'Si se debe agregar una marca de agua "Generado por IA" al resultado.' }, "width": { "name": "ancho" } }, "outputs": { "0": { "tooltip": null } } };
const WanTextToVideoApi = { "description": "Genera video basado en un texto descriptivo.", "display_name": "Wan Text to Video", "inputs": { "audio": { "name": "audio", "tooltip": "El audio debe contener una voz clara y alta, sin ruido extraño ni música de fondo." }, "control_after_generate": { "name": "controlar después de generar" }, "duration": { "name": "duración", "tooltip": "Duración disponible: 5 y 10 segundos" }, "generate_audio": { "name": "generar_audio", "tooltip": "Si no hay entrada de audio, generar audio automáticamente." }, "model": { "name": "modelo", "tooltip": "Modelo a utilizar." }, "negative_prompt": { "name": "texto_negativo", "tooltip": "Texto negativo para guiar qué elementos evitar." }, "prompt": { "name": "texto_descriptivo", "tooltip": "Texto utilizado para describir los elementos y características visuales, admite inglés/chino." }, "prompt_extend": { "name": "extender_texto", "tooltip": "Si se debe mejorar el texto descriptivo con asistencia de IA." }, "seed": { "name": "semilla", "tooltip": "Semilla a utilizar para la generación." }, "size": { "name": "tamaño" }, "watermark": { "name": "marca_de_agua", "tooltip": 'Si se debe agregar una marca de agua "Generado por IA" al resultado.' } }, "outputs": { "0": { "tooltip": null } } };
const WanTrackToVideo = { "display_name": "WanTrackToVideo", "inputs": { "batch_size": { "name": "tamaño_lote" }, "clip_vision_output": { "name": "salida_vision_clip" }, "height": { "name": "alto" }, "length": { "name": "longitud" }, "negative": { "name": "negativo" }, "positive": { "name": "positivo" }, "start_image": { "name": "imagen_inicial" }, "temperature": { "name": "temperatura" }, "topk": { "name": "topk" }, "tracks": { "name": "pistas" }, "vae": { "name": "vae" }, "width": { "name": "ancho" } }, "outputs": { "0": { "name": "positivo", "tooltip": null }, "1": { "name": "negativo", "tooltip": null }, "2": { "name": "latente", "tooltip": null } } };
const WanVaceToVideo = { "display_name": "WanVaceToVideo", "inputs": { "batch_size": { "name": "tamaño_lote" }, "control_masks": { "name": "máscaras_de_control" }, "control_video": { "name": "control_video" }, "height": { "name": "alto" }, "length": { "name": "longitud" }, "negative": { "name": "negativo" }, "positive": { "name": "positivo" }, "reference_image": { "name": "imagen_de_referencia" }, "strength": { "name": "fuerza" }, "vae": { "name": "vae" }, "width": { "name": "ancho" } }, "outputs": { "0": { "name": "positivo", "tooltip": null }, "1": { "name": "negativo", "tooltip": null }, "2": { "name": "latente", "tooltip": null }, "3": { "name": "latente_recortado", "tooltip": null } } };
const WebcamCapture = { "display_name": "Captura de Webcam", "inputs": { "capture_on_queue": { "name": "captura_en_cola" }, "height": { "name": "altura" }, "image": { "name": "imagen" }, "waiting for camera___": {}, "width": { "name": "ancho" } } };
const unCLIPCheckpointLoader = { "display_name": "Cargador de Puntos de Control unCLIP", "inputs": { "ckpt_name": { "name": "nombre_ckpt" } } };
const unCLIPConditioning = { "display_name": "Acondicionamiento unCLIP", "inputs": { "clip_vision_output": { "name": "salida_vision_clip" }, "conditioning": { "name": "acondicionamiento" }, "noise_augmentation": { "name": "aumento_ruido" }, "strength": { "name": "fuerza" } } };
const nodeDefs = {
  APG,
  AddNoise,
  AlignYourStepsScheduler,
  AudioAdjustVolume,
  AudioConcat,
  AudioEncoderEncode,
  AudioEncoderLoader,
  AudioMerge,
  BasicGuider,
  BasicScheduler,
  BetaSamplingScheduler,
  ByteDanceFirstLastFrameNode,
  ByteDanceImageEditNode,
  ByteDanceImageNode,
  ByteDanceImageReferenceNode,
  ByteDanceImageToVideoNode,
  ByteDanceSeedreamNode,
  ByteDanceTextToVideoNode,
  CFGGuider,
  CFGNorm,
  CFGZeroStar,
  CLIPAttentionMultiply,
  CLIPLoader,
  CLIPMergeAdd,
  CLIPMergeSimple,
  CLIPMergeSubtract,
  CLIPSave,
  CLIPSetLastLayer,
  CLIPTextEncode,
  CLIPTextEncodeControlnet,
  CLIPTextEncodeFlux,
  CLIPTextEncodeHiDream,
  CLIPTextEncodeHunyuanDiT,
  CLIPTextEncodeLumina2,
  CLIPTextEncodePixArtAlpha,
  CLIPTextEncodeSD3,
  CLIPTextEncodeSDXL,
  CLIPTextEncodeSDXLRefiner,
  CLIPVisionEncode,
  CLIPVisionLoader,
  Canny,
  CaseConverter,
  CheckpointLoader,
  CheckpointLoaderSimple,
  CheckpointSave,
  ChromaRadianceOptions,
  CombineHooks2,
  CombineHooks4,
  CombineHooks8,
  ConditioningAverage,
  ConditioningCombine,
  ConditioningConcat,
  ConditioningSetArea,
  ConditioningSetAreaPercentage,
  ConditioningSetAreaPercentageVideo,
  ConditioningSetAreaStrength,
  ConditioningSetDefaultCombine,
  ConditioningSetMask,
  ConditioningSetProperties,
  ConditioningSetPropertiesAndCombine,
  ConditioningSetTimestepRange,
  ConditioningStableAudio,
  ConditioningTimestepsRange,
  ConditioningZeroOut,
  ContextWindowsManual,
  ControlNetApply,
  ControlNetApplyAdvanced,
  ControlNetApplySD3,
  ControlNetInpaintingAliMamaApply,
  ControlNetLoader,
  CosmosImageToVideoLatent,
  CosmosPredict2ImageToVideoLatent,
  CreateHookKeyframe,
  CreateHookKeyframesFromFloats,
  CreateHookKeyframesInterpolated,
  CreateHookLora,
  CreateHookLoraModelOnly,
  CreateHookModelAsLora,
  CreateHookModelAsLoraModelOnly,
  CreateVideo,
  CropMask,
  DiffControlNetLoader,
  DifferentialDiffusion,
  DiffusersLoader,
  DisableNoise,
  DualCFGGuider,
  DualCLIPLoader,
  EasyCache,
  EmptyAceStepLatentAudio,
  EmptyAudio,
  EmptyChromaRadianceLatentImage,
  EmptyCosmosLatentVideo,
  EmptyHunyuanImageLatent,
  EmptyHunyuanLatentVideo,
  EmptyImage,
  EmptyLTXVLatentVideo,
  EmptyLatentAudio,
  EmptyLatentHunyuan3Dv2,
  EmptyLatentImage,
  EmptyMochiLatentVideo,
  EmptySD3LatentImage,
  "Epsilon Scaling": { "display_name": "Escalado Épsilon", "inputs": { "model": { "name": "modelo" }, "scaling_factor": { "name": "factor_escala" } }, "outputs": { "0": { "tooltip": null } } },
  ExponentialScheduler,
  ExtendIntermediateSigmas,
  FeatherMask,
  FlipSigmas,
  FluxDisableGuidance,
  FluxGuidance,
  FluxKontextImageScale,
  FluxKontextMaxImageNode,
  FluxKontextMultiReferenceLatentMethod,
  FluxKontextProImageNode,
  FluxProExpandNode,
  FluxProFillNode,
  FluxProUltraImageNode,
  FreSca,
  FreeU,
  FreeU_V2,
  GITSScheduler,
  GLIGENLoader,
  GLIGENTextBoxApply,
  GeminiImageNode,
  GeminiInputFiles,
  GeminiNode,
  GetImageSize,
  GetVideoComponents,
  GrowMask,
  Hunyuan3Dv2Conditioning,
  Hunyuan3Dv2ConditioningMultiView,
  HunyuanImageToVideo,
  HunyuanRefinerLatent,
  HyperTile,
  HypernetworkLoader,
  IdeogramV1,
  IdeogramV2,
  IdeogramV3,
  ImageAddNoise,
  ImageBatch,
  ImageBlend,
  ImageBlur,
  ImageColorToMask,
  ImageCompositeMasked,
  ImageCrop,
  ImageFlip,
  ImageFromBatch,
  ImageInvert,
  ImageOnlyCheckpointLoader,
  ImageOnlyCheckpointSave,
  ImagePadForOutpaint,
  ImageQuantize,
  ImageRGBToYUV,
  ImageRotate,
  ImageScale,
  ImageScaleBy,
  ImageScaleToMaxDimension,
  ImageScaleToTotalPixels,
  ImageSharpen,
  ImageStitch,
  ImageToMask,
  ImageUpscaleWithModel,
  ImageYUVToRGB,
  InpaintModelConditioning,
  InstructPixToPixConditioning,
  InvertMask,
  JoinImageWithAlpha,
  KSampler,
  KSamplerAdvanced,
  KSamplerSelect,
  KarrasScheduler,
  KlingCameraControlI2VNode,
  KlingCameraControlT2VNode,
  KlingCameraControls,
  KlingDualCharacterVideoEffectNode,
  KlingImage2VideoNode,
  KlingImageGenerationNode,
  KlingLipSyncAudioToVideoNode,
  KlingLipSyncTextToVideoNode,
  KlingSingleImageVideoEffectNode,
  KlingStartEndFrameNode,
  KlingTextToVideoNode,
  KlingVideoExtendNode,
  KlingVirtualTryOnNode,
  LTXVAddGuide,
  LTXVConditioning,
  LTXVCropGuides,
  LTXVImgToVideo,
  LTXVPreprocess,
  LTXVScheduler,
  LaplaceScheduler,
  LatentAdd,
  LatentApplyOperation,
  LatentApplyOperationCFG,
  LatentBatch,
  LatentBatchSeedBehavior,
  LatentBlend,
  LatentComposite,
  LatentCompositeMasked,
  LatentConcat,
  LatentCrop,
  LatentCut,
  LatentFlip,
  LatentFromBatch,
  LatentInterpolate,
  LatentMultiply,
  LatentOperationSharpen,
  LatentOperationTonemapReinhard,
  LatentRotate,
  LatentSubtract,
  LatentUpscale,
  LatentUpscaleBy,
  LazyCache,
  Load3D,
  LoadAudio,
  LoadImage,
  LoadImageMask,
  LoadImageOutput,
  LoadLatent,
  LoadVideo,
  LoraLoader,
  LoraLoaderModelOnly,
  LoraModelLoader,
  LoraSave,
  LossGraphNode,
  LotusConditioning,
  LtxvApiImageToVideo,
  LtxvApiTextToVideo,
  LumaConceptsNode,
  LumaImageModifyNode,
  LumaImageNode,
  LumaImageToVideoNode,
  LumaReferenceNode,
  LumaVideoNode,
  Mahiro,
  MaskComposite,
  MaskPreview,
  MaskToImage,
  MinimaxHailuoVideoNode,
  MinimaxImageToVideoNode,
  MinimaxTextToVideoNode,
  ModelComputeDtype,
  ModelMergeAdd,
  ModelMergeAuraflow,
  ModelMergeBlocks,
  ModelMergeCosmos14B,
  ModelMergeCosmos7B,
  ModelMergeCosmosPredict2_14B,
  ModelMergeCosmosPredict2_2B,
  ModelMergeFlux1,
  ModelMergeLTXV,
  ModelMergeMochiPreview,
  ModelMergeQwenImage,
  ModelMergeSD1,
  ModelMergeSD2,
  ModelMergeSD35_Large,
  ModelMergeSD3_2B,
  ModelMergeSDXL,
  ModelMergeSimple,
  ModelMergeSubtract,
  ModelMergeWAN2_1,
  ModelPatchLoader,
  ModelSamplingAuraFlow,
  ModelSamplingContinuousEDM,
  ModelSamplingContinuousV,
  ModelSamplingDiscrete,
  ModelSamplingFlux,
  ModelSamplingLTXV,
  ModelSamplingSD3,
  ModelSamplingStableCascade,
  ModelSave,
  MoonvalleyImg2VideoNode,
  MoonvalleyTxt2VideoNode,
  MoonvalleyVideo2VideoNode,
  Morphology,
  OpenAIChatConfig,
  OpenAIChatNode,
  OpenAIDalle2,
  OpenAIDalle3,
  OpenAIGPTImage1,
  OpenAIInputFiles,
  OpenAIVideoSora2,
  OptimalStepsScheduler,
  PairConditioningCombine,
  PairConditioningSetDefaultCombine,
  PairConditioningSetProperties,
  PairConditioningSetPropertiesAndCombine,
  PatchModelAddDownscale,
  PerpNeg,
  PerpNegGuider,
  PerturbedAttentionGuidance,
  PhotoMakerEncode,
  PhotoMakerLoader,
  PixverseImageToVideoNode,
  PixverseTemplateNode,
  PixverseTextToVideoNode,
  PixverseTransitionVideoNode,
  PolyexponentialScheduler,
  PorterDuffImageComposite,
  Preview3D,
  PreviewAny,
  PreviewAudio,
  PreviewImage,
  PrimitiveBoolean,
  PrimitiveFloat,
  PrimitiveInt,
  PrimitiveString,
  PrimitiveStringMultiline,
  QuadrupleCLIPLoader,
  QwenImageDiffsynthControlnet,
  RandomNoise,
  RebatchImages,
  RebatchLatents,
  RecordAudio,
  RecraftColorRGB,
  RecraftControls,
  RecraftCreativeUpscaleNode,
  RecraftCrispUpscaleNode,
  RecraftImageInpaintingNode,
  RecraftImageToImageNode,
  RecraftRemoveBackgroundNode,
  RecraftReplaceBackgroundNode,
  RecraftStyleV3DigitalIllustration,
  RecraftStyleV3InfiniteStyleLibrary,
  RecraftStyleV3LogoRaster,
  RecraftStyleV3RealisticImage,
  RecraftTextToImageNode,
  RecraftTextToVectorNode,
  RecraftVectorizeImageNode,
  ReferenceLatent,
  RegexExtract,
  RegexMatch,
  RegexReplace,
  RenormCFG,
  RepeatImageBatch,
  RepeatLatentBatch,
  RescaleCFG,
  ResizeAndPadImage,
  Rodin3D_Detail,
  Rodin3D_Gen2,
  Rodin3D_Regular,
  Rodin3D_Sketch,
  Rodin3D_Smooth,
  RunwayFirstLastFrameNode,
  RunwayImageToVideoNodeGen3a,
  RunwayImageToVideoNodeGen4,
  RunwayTextToImageNode,
  SDTurboScheduler,
  SD_4XUpscale_Conditioning,
  SV3D_Conditioning,
  SVD_img2vid_Conditioning,
  SamplerCustom,
  SamplerCustomAdvanced,
  SamplerDPMAdaptative,
  SamplerDPMPP_2M_SDE,
  SamplerDPMPP_2S_Ancestral,
  SamplerDPMPP_3M_SDE,
  SamplerDPMPP_SDE,
  SamplerER_SDE,
  SamplerEulerAncestral,
  SamplerEulerAncestralCFGPP,
  SamplerEulerCFGpp,
  SamplerLCMUpscale,
  SamplerLMS,
  SamplerSASolver,
  SamplingPercentToSigma,
  SaveAnimatedPNG,
  SaveAnimatedWEBP,
  SaveAudio,
  SaveAudioMP3,
  SaveAudioOpus,
  SaveGLB,
  SaveImage,
  SaveImageWebsocket,
  SaveLatent,
  SaveSVGNode,
  SaveVideo,
  SaveWEBM,
  ScaleROPE,
  SelfAttentionGuidance,
  SetClipHooks,
  SetFirstSigma,
  SetHookKeyframes,
  SetLatentNoiseMask,
  SetUnionControlNetType,
  SkipLayerGuidanceDiT,
  SkipLayerGuidanceDiTSimple,
  SkipLayerGuidanceSD3,
  SolidMask,
  SplitAudioChannels,
  SplitImageWithAlpha,
  SplitSigmas,
  SplitSigmasDenoise,
  StabilityAudioInpaint,
  StabilityAudioToAudio,
  StabilityStableImageSD_3_5Node,
  StabilityStableImageUltraNode,
  StabilityTextToAudio,
  StabilityUpscaleConservativeNode,
  StabilityUpscaleCreativeNode,
  StabilityUpscaleFastNode,
  StableCascade_EmptyLatentImage,
  StableCascade_StageB_Conditioning,
  StableCascade_StageC_VAEEncode,
  StableCascade_SuperResolutionControlnet,
  StableZero123_Conditioning,
  StableZero123_Conditioning_Batched,
  StringCompare,
  StringConcatenate,
  StringContains,
  StringLength,
  StringReplace,
  StringSubstring,
  StringTrim,
  StyleModelApply,
  StyleModelLoader,
  T5TokenizerOptions,
  TCFG,
  TemporalScoreRescaling,
  TextEncodeAceStepAudio,
  TextEncodeHunyuanVideo_ImageToVideo,
  TextEncodeQwenImageEdit,
  TextEncodeQwenImageEditPlus,
  ThresholdMask,
  TomePatchModel,
  TorchCompileModel,
  TrainLoraNode,
  TrimAudioDuration,
  TrimVideoLatent,
  TripleCLIPLoader,
  TripoConversionNode,
  TripoImageToModelNode,
  TripoMultiviewToModelNode,
  TripoRefineNode,
  TripoRetargetNode,
  TripoRigNode,
  TripoTextToModelNode,
  TripoTextureNode,
  UNETLoader,
  UNetCrossAttentionMultiply,
  UNetSelfAttentionMultiply,
  UNetTemporalAttentionMultiply,
  USOStyleReference,
  UpscaleModelLoader,
  VAEDecode,
  VAEDecodeAudio,
  VAEDecodeHunyuan3D,
  VAEDecodeTiled,
  VAEEncode,
  VAEEncodeAudio,
  VAEEncodeForInpaint,
  VAEEncodeTiled,
  VAELoader,
  VAESave,
  VPScheduler,
  Veo3VideoGenerationNode,
  VeoVideoGenerationNode,
  VideoLinearCFGGuidance,
  VideoTriangleCFGGuidance,
  ViduImageToVideoNode,
  ViduReferenceVideoNode,
  ViduStartEndToVideoNode,
  ViduTextToVideoNode,
  VoxelToMesh,
  VoxelToMeshBasic,
  Wan22FunControlToVideo,
  Wan22ImageToVideoLatent,
  WanAnimateToVideo,
  WanCameraEmbedding,
  WanCameraImageToVideo,
  WanContextWindowsManual,
  WanFirstLastFrameToVideo,
  WanFunControlToVideo,
  WanFunInpaintToVideo,
  WanHuMoImageToVideo,
  WanImageToImageApi,
  WanImageToVideo,
  WanImageToVideoApi,
  WanPhantomSubjectToVideo,
  WanSoundImageToVideo,
  WanSoundImageToVideoExtend,
  WanTextToImageApi,
  WanTextToVideoApi,
  WanTrackToVideo,
  WanVaceToVideo,
  WebcamCapture,
  unCLIPCheckpointLoader,
  unCLIPConditioning
};
export {
  APG,
  AddNoise,
  AlignYourStepsScheduler,
  AudioAdjustVolume,
  AudioConcat,
  AudioEncoderEncode,
  AudioEncoderLoader,
  AudioMerge,
  BasicGuider,
  BasicScheduler,
  BetaSamplingScheduler,
  ByteDanceFirstLastFrameNode,
  ByteDanceImageEditNode,
  ByteDanceImageNode,
  ByteDanceImageReferenceNode,
  ByteDanceImageToVideoNode,
  ByteDanceSeedreamNode,
  ByteDanceTextToVideoNode,
  CFGGuider,
  CFGNorm,
  CFGZeroStar,
  CLIPAttentionMultiply,
  CLIPLoader,
  CLIPMergeAdd,
  CLIPMergeSimple,
  CLIPMergeSubtract,
  CLIPSave,
  CLIPSetLastLayer,
  CLIPTextEncode,
  CLIPTextEncodeControlnet,
  CLIPTextEncodeFlux,
  CLIPTextEncodeHiDream,
  CLIPTextEncodeHunyuanDiT,
  CLIPTextEncodeLumina2,
  CLIPTextEncodePixArtAlpha,
  CLIPTextEncodeSD3,
  CLIPTextEncodeSDXL,
  CLIPTextEncodeSDXLRefiner,
  CLIPVisionEncode,
  CLIPVisionLoader,
  Canny,
  CaseConverter,
  CheckpointLoader,
  CheckpointLoaderSimple,
  CheckpointSave,
  ChromaRadianceOptions,
  CombineHooks2,
  CombineHooks4,
  CombineHooks8,
  ConditioningAverage,
  ConditioningCombine,
  ConditioningConcat,
  ConditioningSetArea,
  ConditioningSetAreaPercentage,
  ConditioningSetAreaPercentageVideo,
  ConditioningSetAreaStrength,
  ConditioningSetDefaultCombine,
  ConditioningSetMask,
  ConditioningSetProperties,
  ConditioningSetPropertiesAndCombine,
  ConditioningSetTimestepRange,
  ConditioningStableAudio,
  ConditioningTimestepsRange,
  ConditioningZeroOut,
  ContextWindowsManual,
  ControlNetApply,
  ControlNetApplyAdvanced,
  ControlNetApplySD3,
  ControlNetInpaintingAliMamaApply,
  ControlNetLoader,
  CosmosImageToVideoLatent,
  CosmosPredict2ImageToVideoLatent,
  CreateHookKeyframe,
  CreateHookKeyframesFromFloats,
  CreateHookKeyframesInterpolated,
  CreateHookLora,
  CreateHookLoraModelOnly,
  CreateHookModelAsLora,
  CreateHookModelAsLoraModelOnly,
  CreateVideo,
  CropMask,
  DiffControlNetLoader,
  DifferentialDiffusion,
  DiffusersLoader,
  DisableNoise,
  DualCFGGuider,
  DualCLIPLoader,
  EasyCache,
  EmptyAceStepLatentAudio,
  EmptyAudio,
  EmptyChromaRadianceLatentImage,
  EmptyCosmosLatentVideo,
  EmptyHunyuanImageLatent,
  EmptyHunyuanLatentVideo,
  EmptyImage,
  EmptyLTXVLatentVideo,
  EmptyLatentAudio,
  EmptyLatentHunyuan3Dv2,
  EmptyLatentImage,
  EmptyMochiLatentVideo,
  EmptySD3LatentImage,
  ExponentialScheduler,
  ExtendIntermediateSigmas,
  FeatherMask,
  FlipSigmas,
  FluxDisableGuidance,
  FluxGuidance,
  FluxKontextImageScale,
  FluxKontextMaxImageNode,
  FluxKontextMultiReferenceLatentMethod,
  FluxKontextProImageNode,
  FluxProExpandNode,
  FluxProFillNode,
  FluxProUltraImageNode,
  FreSca,
  FreeU,
  FreeU_V2,
  GITSScheduler,
  GLIGENLoader,
  GLIGENTextBoxApply,
  GeminiImageNode,
  GeminiInputFiles,
  GeminiNode,
  GetImageSize,
  GetVideoComponents,
  GrowMask,
  Hunyuan3Dv2Conditioning,
  Hunyuan3Dv2ConditioningMultiView,
  HunyuanImageToVideo,
  HunyuanRefinerLatent,
  HyperTile,
  HypernetworkLoader,
  IdeogramV1,
  IdeogramV2,
  IdeogramV3,
  ImageAddNoise,
  ImageBatch,
  ImageBlend,
  ImageBlur,
  ImageColorToMask,
  ImageCompositeMasked,
  ImageCrop,
  ImageFlip,
  ImageFromBatch,
  ImageInvert,
  ImageOnlyCheckpointLoader,
  ImageOnlyCheckpointSave,
  ImagePadForOutpaint,
  ImageQuantize,
  ImageRGBToYUV,
  ImageRotate,
  ImageScale,
  ImageScaleBy,
  ImageScaleToMaxDimension,
  ImageScaleToTotalPixels,
  ImageSharpen,
  ImageStitch,
  ImageToMask,
  ImageUpscaleWithModel,
  ImageYUVToRGB,
  InpaintModelConditioning,
  InstructPixToPixConditioning,
  InvertMask,
  JoinImageWithAlpha,
  KSampler,
  KSamplerAdvanced,
  KSamplerSelect,
  KarrasScheduler,
  KlingCameraControlI2VNode,
  KlingCameraControlT2VNode,
  KlingCameraControls,
  KlingDualCharacterVideoEffectNode,
  KlingImage2VideoNode,
  KlingImageGenerationNode,
  KlingLipSyncAudioToVideoNode,
  KlingLipSyncTextToVideoNode,
  KlingSingleImageVideoEffectNode,
  KlingStartEndFrameNode,
  KlingTextToVideoNode,
  KlingVideoExtendNode,
  KlingVirtualTryOnNode,
  LTXVAddGuide,
  LTXVConditioning,
  LTXVCropGuides,
  LTXVImgToVideo,
  LTXVPreprocess,
  LTXVScheduler,
  LaplaceScheduler,
  LatentAdd,
  LatentApplyOperation,
  LatentApplyOperationCFG,
  LatentBatch,
  LatentBatchSeedBehavior,
  LatentBlend,
  LatentComposite,
  LatentCompositeMasked,
  LatentConcat,
  LatentCrop,
  LatentCut,
  LatentFlip,
  LatentFromBatch,
  LatentInterpolate,
  LatentMultiply,
  LatentOperationSharpen,
  LatentOperationTonemapReinhard,
  LatentRotate,
  LatentSubtract,
  LatentUpscale,
  LatentUpscaleBy,
  LazyCache,
  Load3D,
  LoadAudio,
  LoadImage,
  LoadImageMask,
  LoadImageOutput,
  LoadLatent,
  LoadVideo,
  LoraLoader,
  LoraLoaderModelOnly,
  LoraModelLoader,
  LoraSave,
  LossGraphNode,
  LotusConditioning,
  LtxvApiImageToVideo,
  LtxvApiTextToVideo,
  LumaConceptsNode,
  LumaImageModifyNode,
  LumaImageNode,
  LumaImageToVideoNode,
  LumaReferenceNode,
  LumaVideoNode,
  Mahiro,
  MaskComposite,
  MaskPreview,
  MaskToImage,
  MinimaxHailuoVideoNode,
  MinimaxImageToVideoNode,
  MinimaxTextToVideoNode,
  ModelComputeDtype,
  ModelMergeAdd,
  ModelMergeAuraflow,
  ModelMergeBlocks,
  ModelMergeCosmos14B,
  ModelMergeCosmos7B,
  ModelMergeCosmosPredict2_14B,
  ModelMergeCosmosPredict2_2B,
  ModelMergeFlux1,
  ModelMergeLTXV,
  ModelMergeMochiPreview,
  ModelMergeQwenImage,
  ModelMergeSD1,
  ModelMergeSD2,
  ModelMergeSD35_Large,
  ModelMergeSD3_2B,
  ModelMergeSDXL,
  ModelMergeSimple,
  ModelMergeSubtract,
  ModelMergeWAN2_1,
  ModelPatchLoader,
  ModelSamplingAuraFlow,
  ModelSamplingContinuousEDM,
  ModelSamplingContinuousV,
  ModelSamplingDiscrete,
  ModelSamplingFlux,
  ModelSamplingLTXV,
  ModelSamplingSD3,
  ModelSamplingStableCascade,
  ModelSave,
  MoonvalleyImg2VideoNode,
  MoonvalleyTxt2VideoNode,
  MoonvalleyVideo2VideoNode,
  Morphology,
  OpenAIChatConfig,
  OpenAIChatNode,
  OpenAIDalle2,
  OpenAIDalle3,
  OpenAIGPTImage1,
  OpenAIInputFiles,
  OpenAIVideoSora2,
  OptimalStepsScheduler,
  PairConditioningCombine,
  PairConditioningSetDefaultCombine,
  PairConditioningSetProperties,
  PairConditioningSetPropertiesAndCombine,
  PatchModelAddDownscale,
  PerpNeg,
  PerpNegGuider,
  PerturbedAttentionGuidance,
  PhotoMakerEncode,
  PhotoMakerLoader,
  PixverseImageToVideoNode,
  PixverseTemplateNode,
  PixverseTextToVideoNode,
  PixverseTransitionVideoNode,
  PolyexponentialScheduler,
  PorterDuffImageComposite,
  Preview3D,
  PreviewAny,
  PreviewAudio,
  PreviewImage,
  PrimitiveBoolean,
  PrimitiveFloat,
  PrimitiveInt,
  PrimitiveString,
  PrimitiveStringMultiline,
  QuadrupleCLIPLoader,
  QwenImageDiffsynthControlnet,
  RandomNoise,
  RebatchImages,
  RebatchLatents,
  RecordAudio,
  RecraftColorRGB,
  RecraftControls,
  RecraftCreativeUpscaleNode,
  RecraftCrispUpscaleNode,
  RecraftImageInpaintingNode,
  RecraftImageToImageNode,
  RecraftRemoveBackgroundNode,
  RecraftReplaceBackgroundNode,
  RecraftStyleV3DigitalIllustration,
  RecraftStyleV3InfiniteStyleLibrary,
  RecraftStyleV3LogoRaster,
  RecraftStyleV3RealisticImage,
  RecraftTextToImageNode,
  RecraftTextToVectorNode,
  RecraftVectorizeImageNode,
  ReferenceLatent,
  RegexExtract,
  RegexMatch,
  RegexReplace,
  RenormCFG,
  RepeatImageBatch,
  RepeatLatentBatch,
  RescaleCFG,
  ResizeAndPadImage,
  Rodin3D_Detail,
  Rodin3D_Gen2,
  Rodin3D_Regular,
  Rodin3D_Sketch,
  Rodin3D_Smooth,
  RunwayFirstLastFrameNode,
  RunwayImageToVideoNodeGen3a,
  RunwayImageToVideoNodeGen4,
  RunwayTextToImageNode,
  SDTurboScheduler,
  SD_4XUpscale_Conditioning,
  SV3D_Conditioning,
  SVD_img2vid_Conditioning,
  SamplerCustom,
  SamplerCustomAdvanced,
  SamplerDPMAdaptative,
  SamplerDPMPP_2M_SDE,
  SamplerDPMPP_2S_Ancestral,
  SamplerDPMPP_3M_SDE,
  SamplerDPMPP_SDE,
  SamplerER_SDE,
  SamplerEulerAncestral,
  SamplerEulerAncestralCFGPP,
  SamplerEulerCFGpp,
  SamplerLCMUpscale,
  SamplerLMS,
  SamplerSASolver,
  SamplingPercentToSigma,
  SaveAnimatedPNG,
  SaveAnimatedWEBP,
  SaveAudio,
  SaveAudioMP3,
  SaveAudioOpus,
  SaveGLB,
  SaveImage,
  SaveImageWebsocket,
  SaveLatent,
  SaveSVGNode,
  SaveVideo,
  SaveWEBM,
  ScaleROPE,
  SelfAttentionGuidance,
  SetClipHooks,
  SetFirstSigma,
  SetHookKeyframes,
  SetLatentNoiseMask,
  SetUnionControlNetType,
  SkipLayerGuidanceDiT,
  SkipLayerGuidanceDiTSimple,
  SkipLayerGuidanceSD3,
  SolidMask,
  SplitAudioChannels,
  SplitImageWithAlpha,
  SplitSigmas,
  SplitSigmasDenoise,
  StabilityAudioInpaint,
  StabilityAudioToAudio,
  StabilityStableImageSD_3_5Node,
  StabilityStableImageUltraNode,
  StabilityTextToAudio,
  StabilityUpscaleConservativeNode,
  StabilityUpscaleCreativeNode,
  StabilityUpscaleFastNode,
  StableCascade_EmptyLatentImage,
  StableCascade_StageB_Conditioning,
  StableCascade_StageC_VAEEncode,
  StableCascade_SuperResolutionControlnet,
  StableZero123_Conditioning,
  StableZero123_Conditioning_Batched,
  StringCompare,
  StringConcatenate,
  StringContains,
  StringLength,
  StringReplace,
  StringSubstring,
  StringTrim,
  StyleModelApply,
  StyleModelLoader,
  T5TokenizerOptions,
  TCFG,
  TemporalScoreRescaling,
  TextEncodeAceStepAudio,
  TextEncodeHunyuanVideo_ImageToVideo,
  TextEncodeQwenImageEdit,
  TextEncodeQwenImageEditPlus,
  ThresholdMask,
  TomePatchModel,
  TorchCompileModel,
  TrainLoraNode,
  TrimAudioDuration,
  TrimVideoLatent,
  TripleCLIPLoader,
  TripoConversionNode,
  TripoImageToModelNode,
  TripoMultiviewToModelNode,
  TripoRefineNode,
  TripoRetargetNode,
  TripoRigNode,
  TripoTextToModelNode,
  TripoTextureNode,
  UNETLoader,
  UNetCrossAttentionMultiply,
  UNetSelfAttentionMultiply,
  UNetTemporalAttentionMultiply,
  USOStyleReference,
  UpscaleModelLoader,
  VAEDecode,
  VAEDecodeAudio,
  VAEDecodeHunyuan3D,
  VAEDecodeTiled,
  VAEEncode,
  VAEEncodeAudio,
  VAEEncodeForInpaint,
  VAEEncodeTiled,
  VAELoader,
  VAESave,
  VPScheduler,
  Veo3VideoGenerationNode,
  VeoVideoGenerationNode,
  VideoLinearCFGGuidance,
  VideoTriangleCFGGuidance,
  ViduImageToVideoNode,
  ViduReferenceVideoNode,
  ViduStartEndToVideoNode,
  ViduTextToVideoNode,
  VoxelToMesh,
  VoxelToMeshBasic,
  Wan22FunControlToVideo,
  Wan22ImageToVideoLatent,
  WanAnimateToVideo,
  WanCameraEmbedding,
  WanCameraImageToVideo,
  WanContextWindowsManual,
  WanFirstLastFrameToVideo,
  WanFunControlToVideo,
  WanFunInpaintToVideo,
  WanHuMoImageToVideo,
  WanImageToImageApi,
  WanImageToVideo,
  WanImageToVideoApi,
  WanPhantomSubjectToVideo,
  WanSoundImageToVideo,
  WanSoundImageToVideoExtend,
  WanTextToImageApi,
  WanTextToVideoApi,
  WanTrackToVideo,
  WanVaceToVideo,
  WebcamCapture,
  nodeDefs as default,
  unCLIPCheckpointLoader,
  unCLIPConditioning
};
//# sourceMappingURL=nodeDefs-aW9En70v.js.map
