const Comfy_Canvas_BackgroundImage = { "name": "キャンバス背景画像", "tooltip": "キャンバスの背景画像のURLです。出力パネルで画像を右クリックし、「背景として設定」を選択すると使用できます。" };
const Comfy_Canvas_LeftMouseClickBehavior = { "name": "左クリックの動作", "options": { "Panning": "パン（移動）", "Select": "選択" } };
const Comfy_Canvas_MouseWheelScroll = { "name": "マウスホイールスクロール", "options": { "Panning": "パン（移動）", "Zoom in/out": "ズームイン/アウト" } };
const Comfy_Canvas_NavigationMode = { "name": "キャンバスナビゲーションモード", "options": { "Custom": "カスタム", "Drag Navigation": "ドラッグナビゲーション", "Standard (New)": "標準（新）" } };
const Comfy_Canvas_SelectionToolbox = { "name": "選択ツールボックスを表示" };
const Comfy_ConfirmClear = { "name": "ワークフローをクリアする際に確認を要求する" };
const Comfy_DOMClippingEnabled = { "name": "DOM要素のクリッピングを有効にする（有効にするとパフォーマンスが低下する可能性があります）" };
const Comfy_DevMode = { "name": "開発モードオプションを有効にする（API保存など）" };
const Comfy_DisableFloatRounding = { "name": "デフォルトの浮動小数点ウィジェットの丸めを無効にする。", "tooltip": "(ページの再読み込みが必要) バックエンドのノードで丸めが設定されている場合、丸めを無効にすることはできません。" };
const Comfy_DisableSliders = { "name": "ノードウィジェットスライダーを無効にする" };
const Comfy_EditAttention_Delta = { "name": "Ctrl+上/下の精度" };
const Comfy_EnableTooltips = { "name": "ツールチップを有効にする" };
const Comfy_EnableWorkflowViewRestore = { "name": "ワークフロー内のキャンバスの位置とズームレベルを保存および復元する" };
const Comfy_FloatRoundingPrecision = { "name": "浮動小数点ウィジェットの丸め小数点数 [0 = 自動]。", "tooltip": "(ページの再読み込みが必要)" };
const Comfy_Graph_CanvasInfo = { "name": "左下隅にキャンバス情報を表示する（fpsなど）" };
const Comfy_Graph_CanvasMenu = { "name": "グラフキャンバスメニューを表示する" };
const Comfy_Graph_CtrlShiftZoom = { "name": "ファストズームショートカットを有効にする（Ctrl + Shift + ドラッグ）" };
const Comfy_Graph_LinkMarkers = { "name": "リンク中点マーカー", "options": { "Arrow": "矢印", "Circle": "円", "None": "なし" } };
const Comfy_Graph_ZoomSpeed = { "name": "キャンバスズーム速度" };
const Comfy_GroupSelectedNodes_Padding = { "name": "選択したノードのパディング" };
const Comfy_Group_DoubleClickTitleToEdit = { "name": "グループタイトルをダブルクリックして編集" };
const Comfy_LinkRelease_Action = { "name": "リンクリリース時のアクション（修飾子なし）", "options": { "context menu": "コンテキストメニュー", "no action": "アクションなし", "search box": "検索ボックス" } };
const Comfy_LinkRelease_ActionShift = { "name": "リンクリリース時のアクション（Shift）", "options": { "context menu": "コンテキストメニュー", "no action": "アクションなし", "search box": "検索ボックス" } };
const Comfy_LinkRenderMode = { "name": "リンクレンダーモード", "options": { "Hidden": "隠す", "Linear": "リニア", "Spline": "スプライン", "Straight": "ストレート" } };
const Comfy_Load3D_3DViewerEnable = { "name": "3Dビューアーを有効化（ベータ）", "tooltip": "選択したノードで3Dビューアー（ベータ）を有効にします。この機能により、フルサイズの3Dビューアー内で3Dモデルを直接可視化し、操作できます。" };
const Comfy_Load3D_BackgroundColor = { "name": "初期背景色", "tooltip": "3Dシーンのデフォルト背景色を設定します。この設定は新しい3Dウィジェット作成時の背景の見た目を決定しますが、作成後に各ウィジェットごとに個別に調整できます。" };
const Comfy_Load3D_CameraType = { "name": "カメラタイプ", "options": { "orthographic": "オルソグラフィック", "perspective": "パースペクティブ" }, "tooltip": "新しい3Dウィジェットが作成されたときに、デフォルトでカメラが透視投影か平行投影かを制御します。このデフォルトは、作成後に各ウィジェットごとに個別に切り替えることができます。" };
const Comfy_Load3D_LightAdjustmentIncrement = { "name": "ライト調整増分", "tooltip": "3Dシーンでライトの強度を調整する際の増分サイズを制御します。ステップ値が小さいほど、照明調整をより細かく制御でき、大きい値では1回の調整ごとにより顕著な変化が得られます。" };
const Comfy_Load3D_LightIntensity = { "name": "初期ライト強度", "tooltip": "3Dシーン内の照明のデフォルトの明るさレベルを設定します。この値は新しい3Dウィジェット作成時にライトがオブジェクトをどれだけ強く照らすかを決定しますが、作成後に各ウィジェットごとに個別に調整できます。" };
const Comfy_Load3D_LightIntensityMaximum = { "name": "最大光度", "tooltip": "3Dシーンで許可される最大光度値を設定します。これは、3Dウィジェットで照明を調整する際に設定できる明るさの上限を定義します。" };
const Comfy_Load3D_LightIntensityMinimum = { "name": "光の強度の最小値", "tooltip": "3Dシーンで許可される光の強度の最小値を設定します。これは、3Dウィジェットで照明を調整する際に設定できる明るさの下限を定義します。" };
const Comfy_Load3D_ShowGrid = { "name": "グリッドを表示", "tooltip": "デフォルトでグリッドを表示するには切り替えます" };
const Comfy_Locale = { "name": "言語" };
const Comfy_MaskEditor_BrushAdjustmentSpeed = { "name": "ブラシ調整速度の倍率", "tooltip": "調整時にブラシのサイズと硬さがどれだけ速く変化するかを制御します。値が高いほど、変化が速くなります。" };
const Comfy_MaskEditor_UseDominantAxis = { "name": "ブラシ調整を優先軸に固定する", "tooltip": "有効にすると、ブラシの調整は、どの方向に多く動かすかに基づいて、サイズまたは硬さのいずれかにのみ影響します。" };
const Comfy_ModelLibrary_AutoLoadAll = { "name": "すべてのモデルフォルダーを自動的に読み込む", "tooltip": "trueの場合、モデルライブラリを開くとすぐにすべてのフォルダーが読み込まれます（これにより読み込み中に遅延が発生する可能性があります）。falseの場合、ルートレベルのモデルフォルダーはクリックするまで読み込まれません。" };
const Comfy_ModelLibrary_NameFormat = { "name": "モデルライブラリツリービューに表示する名前", "options": { "filename": "ファイル名", "title": "タイトル" }, "tooltip": '"ファイル名"を選択すると、モデルリストにディレクトリや".safetensors"拡張子なしの生のファイル名の簡略化されたビューが表示されます。"タイトル"を選択すると、設定可能なモデルメタデータタイトルが表示されます。' };
const Comfy_NodeBadge_NodeIdBadgeMode = { "name": "ノードIDバッジモード", "options": { "None": "なし", "Show all": "すべて表示" } };
const Comfy_NodeBadge_NodeLifeCycleBadgeMode = { "name": "ノードライフサイクルバッジモード", "options": { "None": "なし", "Show all": "すべて表示" } };
const Comfy_NodeBadge_NodeSourceBadgeMode = { "name": "ノードソースバッジモード", "options": { "Hide built-in": "組み込みを隠す", "None": "なし", "Show all": "すべて表示" } };
const Comfy_NodeBadge_ShowApiPricing = { "name": "APIノードの料金バッジを表示" };
const Comfy_NodeSearchBoxImpl = { "name": "ノード検索ボックスの実装", "options": { "default": "デフォルト", "litegraph (legacy)": "litegraph (レガシー)" } };
const Comfy_NodeSearchBoxImpl_NodePreview = { "name": "ノードプレビュー", "tooltip": "デフォルトの実装にのみ適用されます" };
const Comfy_NodeSearchBoxImpl_ShowCategory = { "name": "検索結果にノードカテゴリを表示", "tooltip": "デフォルトの実装にのみ適用されます" };
const Comfy_NodeSearchBoxImpl_ShowIdName = { "name": "検索結果にノードID名を表示", "tooltip": "デフォルトの実装にのみ適用されます" };
const Comfy_NodeSearchBoxImpl_ShowNodeFrequency = { "name": "検索結果にノード頻度を表示", "tooltip": "デフォルトの実装にのみ適用されます" };
const Comfy_NodeSuggestions_number = { "name": "ノード提案の数", "tooltip": "ライトグラフの検索ボックス/コンテキストメニュー専用" };
const Comfy_Node_AllowImageSizeDraw = { "name": "画像プレビューの下に幅×高さを表示する" };
const Comfy_Node_AutoSnapLinkToSlot = { "name": "ノードスロットにリンクを自動スナップ", "tooltip": "ノードの上にリンクをドラッグすると、リンクがノードの有効な入力スロットに自動的にスナップします" };
const Comfy_Node_BypassAllLinksOnDelete = { "name": "ノード削除時にすべてのリンクを保持", "tooltip": "ノードを削除する際、削除されたノードをバイパスしてすべての入力および出力リンクを再接続しようとします" };
const Comfy_Node_DoubleClickTitleToEdit = { "name": "ノードタイトルをダブルクリックして編集" };
const Comfy_Node_MiddleClickRerouteNode = { "name": "ミドルクリックで新しいリルートノードを作成" };
const Comfy_Node_Opacity = { "name": "ノードの不透明度" };
const Comfy_Node_ShowDeprecated = { "name": "検索で非推奨ノードを表示", "tooltip": "非推奨ノードはデフォルトでUIに隠されていますが、それを使用する既存のワークフローでは機能し続けます。" };
const Comfy_Node_ShowExperimental = { "name": "検索で実験的ノードを表示", "tooltip": "実験的ノードはUIでそのようにマークされており、将来のバージョンで大幅な変更や削除の対象となる可能性があります。生産ワークフローでの使用には注意が必要です" };
const Comfy_Node_SnapHighlightsNode = { "name": "スナップハイライトノード", "tooltip": "有効な入力スロットを持つノードの上にリンクをドラッグすると、ノードがハイライトされます" };
const Comfy_Notification_ShowVersionUpdates = { "name": "バージョン更新を表示", "tooltip": "新しいモデルや主要な新機能のアップデートを表示します。" };
const Comfy_Pointer_ClickBufferTime = { "name": "ポインタークリックドリフト遅延", "tooltip": "ポインターボタンを押した後、ポインタの動きが無視される最大時間（ミリ秒単位）です。\n\nクリック中にポインタが移動した場合、オブジェクトが意図せず動かされるのを防ぎます。" };
const Comfy_Pointer_ClickDrift = { "name": "ポインタークリックドリフト（最大距離）", "tooltip": "ボタンを押し続けている間にポインタがこの距離以上移動した場合、クリックではなくドラッグと見なされます。\n\nクリック中にポインタが移動した場合、オブジェクトが意図せず動かされるのを防ぎます。" };
const Comfy_Pointer_DoubleClickTime = { "name": "ダブルクリック間隔（最大）", "tooltip": "ダブルクリックの2回のクリック間の最大時間（ミリ秒単位）。この値を増やすことで、ダブルクリックが時々登録されない場合に助けになるかもしれません。" };
const Comfy_PreviewFormat = { "name": "プレビュー画像フォーマット", "tooltip": "画像ウィジェットでプレビューを表示する際、軽量画像に変換します（例：webp、jpeg、webp;50など）。" };
const Comfy_PromptFilename = { "name": "ワークフローを保存する際にファイル名を入力するよう促す" };
const Comfy_QueueButton_BatchCountLimit = { "name": "バッチ数制限", "tooltip": "1回のボタンクリックでキューに追加できるタスクの最大数" };
const Comfy_Queue_MaxHistoryItems = { "name": "キュー履歴サイズ", "tooltip": "キュー履歴に表示されるタスクの最大数。" };
const Comfy_Sidebar_Location = { "name": "サイドバーの位置", "options": { "left": "左", "right": "右" } };
const Comfy_Sidebar_Size = { "name": "サイドバーのサイズ", "options": { "normal": "通常", "small": "小" } };
const Comfy_Sidebar_Style = { "name": "サイドバーのスタイル", "options": { "connected": "接続", "floating": "フローティング" } };
const Comfy_Sidebar_UnifiedWidth = { "name": "サイドバーの幅を統一" };
const Comfy_SnapToGrid_GridSize = { "name": "グリッドサイズにスナップ", "tooltip": "シフトを押しながらノードをドラッグおよびサイズ変更すると、グリッドに整列されます。これにより、そのグリッドのサイズが制御されます。" };
const Comfy_TextareaWidget_FontSize = { "name": "テキストエリアウィジェットのフォントサイズ" };
const Comfy_TextareaWidget_Spellcheck = { "name": "テキストエリアウィジェットのスペルチェック" };
const Comfy_TreeExplorer_ItemPadding = { "name": "ツリーエクスプローラーアイテムのパディング" };
const Comfy_UseNewMenu = { "name": "新しいメニューを使用", "options": { "Disabled": "無効", "Top": "上" }, "tooltip": "メニューバーの位置。モバイルデバイスでは、メニューは常に上部に表示されます。" };
const Comfy_Validation_Workflows = { "name": "ワークフローを検証" };
const Comfy_VueNodes_AutoScaleLayout = { "name": "自動スケールレイアウト（Vueノード）", "tooltip": "Vueレンダリングに切り替えた際にノードの重なりを防ぐため、自動的にノード位置をスケーリングします" };
const Comfy_VueNodes_Enabled = { "name": "モダンノードデザイン（Vueノード）", "tooltip": "モダン：DOMベースのレンダリングで、操作性の向上、ネイティブブラウザ機能、最新のビジュアルデザインを実現。クラシック：従来のキャンバスレンダリング。" };
const Comfy_WidgetControlMode = { "name": "ウィジェット制御モード", "options": { "after": "後", "before": "前" }, "tooltip": "ウィジェットの値が更新されるタイミングを制御します（ランダム化/インクリメント/デクリメント）、プロンプトがキューに入れられる前または後のいずれかです。" };
const Comfy_Window_UnloadConfirmation = { "name": "ウィンドウを閉じるときに確認を表示" };
const Comfy_Workflow_AutoSave = { "name": "自動保存", "options": { "after delay": "遅延後", "off": "オフ" } };
const Comfy_Workflow_AutoSaveDelay = { "name": "自動保存遅延（ms）", "tooltip": "自動保存が「遅延後」に設定されている場合のみ適用されます。" };
const Comfy_Workflow_ConfirmDelete = { "name": "ワークフローを削除する際に確認を表示" };
const Comfy_Workflow_Persist = { "name": "ページ（再）ロード時にワークフローの状態を保持し、復元します" };
const Comfy_Workflow_ShowMissingModelsWarning = { "name": "欠落しているモデルの警告を表示" };
const Comfy_Workflow_ShowMissingNodesWarning = { "name": "欠落しているノードの警告を表示" };
const Comfy_Workflow_SortNodeIdOnSave = { "name": "ワークフローを保存する際にノードIDをソート" };
const Comfy_Workflow_WarnBlueprintOverwrite = { "name": "既存のサブグラフブループリントを上書きする際に確認を要求" };
const Comfy_Workflow_WorkflowTabsPosition = { "name": "開いているワークフローの位置", "options": { "Sidebar": "サイドバー", "Topbar": "トップバー" } };
const LiteGraph_Canvas_MaximumFps = { "name": "最大FPS", "tooltip": "キャンバスがレンダリングできる最大フレーム数です。スムーズさの代わりにGPU使用量を制限します。0の場合、画面のリフレッシュレートが使用されます。デフォルト：0" };
const LiteGraph_Canvas_MinFontSizeForLOD = { "name": "ズームノードの詳細レベル - フォントサイズしきい値", "tooltip": "ノードが低品質LODレンダリングに切り替わるタイミングを制御します。ピクセル単位のフォントサイズを使用して切り替えタイミングを決定します。0に設定すると無効になります。値1-24はLODの最小フォントサイズしきい値を設定します - 値が高いほど(24px) ズームアウト時にノードが簡略化されたレンダリングに早く切り替わり、値が低いほど(1px) 完全なノード品質がより長く維持されます。" };
const LiteGraph_ContextMenu_Scaling = { "name": "ズームイン時にノードコンボウィジェットメニュー（リスト）をスケーリングする" };
const LiteGraph_Node_DefaultPadding = { "name": "新しいノードを常に縮小", "tooltip": "ノード作成時に可能な限り小さいサイズにリサイズします。無効にすると、新しく追加されたノードはウィジェットの値が表示されるように少し幅広くなります。" };
const LiteGraph_Node_TooltipDelay = { "name": "ツールチップ遅延" };
const LiteGraph_Reroute_SplineOffset = { "name": "リルートスプラインオフセット", "tooltip": "リルート中心点からのベジエ制御点のオフセット" };
const pysssss_SnapToGrid = { "name": "常にグリッドにスナップ" };
const settings = {
  "Comfy-Desktop_AutoUpdate": { "name": "自動的に更新を確認する" },
  "Comfy-Desktop_SendStatistics": { "name": "匿名の使用統計を送信する" },
  "Comfy-Desktop_UV_PypiInstallMirror": { "name": "Pypi インストールミラー", "tooltip": "デフォルトの pip インストールミラー" },
  "Comfy-Desktop_UV_PythonInstallMirror": { "name": "Pythonインストールミラー", "tooltip": "管理されたPythonのインストールは、Astral python-build-standaloneプロジェクトからダウンロードされます。この変数は、Pythonのインストールのための異なるソースを使用するためのミラーURLに設定することができます。提供されたURLは、例えば、https://github.com/astral-sh/python-build-standalone/releases/download/20240713/cpython-3.12.4%2B20240713-aarch64-apple-darwin-install_only.tar.gzの中でhttps://github.com/astral-sh/python-build-standalone/releases/downloadを置き換えます。ディストリビューションは、file:// URLスキームを使用してローカルディレクトリから読み取ることができます。" },
  "Comfy-Desktop_UV_TorchInstallMirror": { "name": "Torchインストールミラー", "tooltip": "pytorchのpipインストールミラー" },
  "Comfy-Desktop_WindowStyle": { "name": "ウィンドウスタイル", "options": { "custom": "カスタム", "default": "デフォルト" }, "tooltip": "システムタイトルバーを非表示にするにはカスタムオプションを選択してください" },
  Comfy_Canvas_BackgroundImage,
  Comfy_Canvas_LeftMouseClickBehavior,
  Comfy_Canvas_MouseWheelScroll,
  Comfy_Canvas_NavigationMode,
  Comfy_Canvas_SelectionToolbox,
  Comfy_ConfirmClear,
  Comfy_DOMClippingEnabled,
  Comfy_DevMode,
  Comfy_DisableFloatRounding,
  Comfy_DisableSliders,
  Comfy_EditAttention_Delta,
  Comfy_EnableTooltips,
  Comfy_EnableWorkflowViewRestore,
  Comfy_FloatRoundingPrecision,
  Comfy_Graph_CanvasInfo,
  Comfy_Graph_CanvasMenu,
  Comfy_Graph_CtrlShiftZoom,
  Comfy_Graph_LinkMarkers,
  Comfy_Graph_ZoomSpeed,
  Comfy_GroupSelectedNodes_Padding,
  Comfy_Group_DoubleClickTitleToEdit,
  Comfy_LinkRelease_Action,
  Comfy_LinkRelease_ActionShift,
  Comfy_LinkRenderMode,
  Comfy_Load3D_3DViewerEnable,
  Comfy_Load3D_BackgroundColor,
  Comfy_Load3D_CameraType,
  Comfy_Load3D_LightAdjustmentIncrement,
  Comfy_Load3D_LightIntensity,
  Comfy_Load3D_LightIntensityMaximum,
  Comfy_Load3D_LightIntensityMinimum,
  Comfy_Load3D_ShowGrid,
  Comfy_Locale,
  Comfy_MaskEditor_BrushAdjustmentSpeed,
  Comfy_MaskEditor_UseDominantAxis,
  Comfy_ModelLibrary_AutoLoadAll,
  Comfy_ModelLibrary_NameFormat,
  Comfy_NodeBadge_NodeIdBadgeMode,
  Comfy_NodeBadge_NodeLifeCycleBadgeMode,
  Comfy_NodeBadge_NodeSourceBadgeMode,
  Comfy_NodeBadge_ShowApiPricing,
  Comfy_NodeSearchBoxImpl,
  Comfy_NodeSearchBoxImpl_NodePreview,
  Comfy_NodeSearchBoxImpl_ShowCategory,
  Comfy_NodeSearchBoxImpl_ShowIdName,
  Comfy_NodeSearchBoxImpl_ShowNodeFrequency,
  Comfy_NodeSuggestions_number,
  Comfy_Node_AllowImageSizeDraw,
  Comfy_Node_AutoSnapLinkToSlot,
  Comfy_Node_BypassAllLinksOnDelete,
  Comfy_Node_DoubleClickTitleToEdit,
  Comfy_Node_MiddleClickRerouteNode,
  Comfy_Node_Opacity,
  Comfy_Node_ShowDeprecated,
  Comfy_Node_ShowExperimental,
  Comfy_Node_SnapHighlightsNode,
  Comfy_Notification_ShowVersionUpdates,
  Comfy_Pointer_ClickBufferTime,
  Comfy_Pointer_ClickDrift,
  Comfy_Pointer_DoubleClickTime,
  Comfy_PreviewFormat,
  Comfy_PromptFilename,
  Comfy_QueueButton_BatchCountLimit,
  Comfy_Queue_MaxHistoryItems,
  Comfy_Sidebar_Location,
  Comfy_Sidebar_Size,
  Comfy_Sidebar_Style,
  Comfy_Sidebar_UnifiedWidth,
  Comfy_SnapToGrid_GridSize,
  Comfy_TextareaWidget_FontSize,
  Comfy_TextareaWidget_Spellcheck,
  Comfy_TreeExplorer_ItemPadding,
  Comfy_UseNewMenu,
  Comfy_Validation_Workflows,
  Comfy_VueNodes_AutoScaleLayout,
  Comfy_VueNodes_Enabled,
  Comfy_WidgetControlMode,
  Comfy_Window_UnloadConfirmation,
  Comfy_Workflow_AutoSave,
  Comfy_Workflow_AutoSaveDelay,
  Comfy_Workflow_ConfirmDelete,
  Comfy_Workflow_Persist,
  Comfy_Workflow_ShowMissingModelsWarning,
  Comfy_Workflow_ShowMissingNodesWarning,
  Comfy_Workflow_SortNodeIdOnSave,
  Comfy_Workflow_WarnBlueprintOverwrite,
  Comfy_Workflow_WorkflowTabsPosition,
  LiteGraph_Canvas_MaximumFps,
  LiteGraph_Canvas_MinFontSizeForLOD,
  LiteGraph_ContextMenu_Scaling,
  LiteGraph_Node_DefaultPadding,
  LiteGraph_Node_TooltipDelay,
  LiteGraph_Reroute_SplineOffset,
  pysssss_SnapToGrid
};
export {
  Comfy_Canvas_BackgroundImage,
  Comfy_Canvas_LeftMouseClickBehavior,
  Comfy_Canvas_MouseWheelScroll,
  Comfy_Canvas_NavigationMode,
  Comfy_Canvas_SelectionToolbox,
  Comfy_ConfirmClear,
  Comfy_DOMClippingEnabled,
  Comfy_DevMode,
  Comfy_DisableFloatRounding,
  Comfy_DisableSliders,
  Comfy_EditAttention_Delta,
  Comfy_EnableTooltips,
  Comfy_EnableWorkflowViewRestore,
  Comfy_FloatRoundingPrecision,
  Comfy_Graph_CanvasInfo,
  Comfy_Graph_CanvasMenu,
  Comfy_Graph_CtrlShiftZoom,
  Comfy_Graph_LinkMarkers,
  Comfy_Graph_ZoomSpeed,
  Comfy_GroupSelectedNodes_Padding,
  Comfy_Group_DoubleClickTitleToEdit,
  Comfy_LinkRelease_Action,
  Comfy_LinkRelease_ActionShift,
  Comfy_LinkRenderMode,
  Comfy_Load3D_3DViewerEnable,
  Comfy_Load3D_BackgroundColor,
  Comfy_Load3D_CameraType,
  Comfy_Load3D_LightAdjustmentIncrement,
  Comfy_Load3D_LightIntensity,
  Comfy_Load3D_LightIntensityMaximum,
  Comfy_Load3D_LightIntensityMinimum,
  Comfy_Load3D_ShowGrid,
  Comfy_Locale,
  Comfy_MaskEditor_BrushAdjustmentSpeed,
  Comfy_MaskEditor_UseDominantAxis,
  Comfy_ModelLibrary_AutoLoadAll,
  Comfy_ModelLibrary_NameFormat,
  Comfy_NodeBadge_NodeIdBadgeMode,
  Comfy_NodeBadge_NodeLifeCycleBadgeMode,
  Comfy_NodeBadge_NodeSourceBadgeMode,
  Comfy_NodeBadge_ShowApiPricing,
  Comfy_NodeSearchBoxImpl,
  Comfy_NodeSearchBoxImpl_NodePreview,
  Comfy_NodeSearchBoxImpl_ShowCategory,
  Comfy_NodeSearchBoxImpl_ShowIdName,
  Comfy_NodeSearchBoxImpl_ShowNodeFrequency,
  Comfy_NodeSuggestions_number,
  Comfy_Node_AllowImageSizeDraw,
  Comfy_Node_AutoSnapLinkToSlot,
  Comfy_Node_BypassAllLinksOnDelete,
  Comfy_Node_DoubleClickTitleToEdit,
  Comfy_Node_MiddleClickRerouteNode,
  Comfy_Node_Opacity,
  Comfy_Node_ShowDeprecated,
  Comfy_Node_ShowExperimental,
  Comfy_Node_SnapHighlightsNode,
  Comfy_Notification_ShowVersionUpdates,
  Comfy_Pointer_ClickBufferTime,
  Comfy_Pointer_ClickDrift,
  Comfy_Pointer_DoubleClickTime,
  Comfy_PreviewFormat,
  Comfy_PromptFilename,
  Comfy_QueueButton_BatchCountLimit,
  Comfy_Queue_MaxHistoryItems,
  Comfy_Sidebar_Location,
  Comfy_Sidebar_Size,
  Comfy_Sidebar_Style,
  Comfy_Sidebar_UnifiedWidth,
  Comfy_SnapToGrid_GridSize,
  Comfy_TextareaWidget_FontSize,
  Comfy_TextareaWidget_Spellcheck,
  Comfy_TreeExplorer_ItemPadding,
  Comfy_UseNewMenu,
  Comfy_Validation_Workflows,
  Comfy_VueNodes_AutoScaleLayout,
  Comfy_VueNodes_Enabled,
  Comfy_WidgetControlMode,
  Comfy_Window_UnloadConfirmation,
  Comfy_Workflow_AutoSave,
  Comfy_Workflow_AutoSaveDelay,
  Comfy_Workflow_ConfirmDelete,
  Comfy_Workflow_Persist,
  Comfy_Workflow_ShowMissingModelsWarning,
  Comfy_Workflow_ShowMissingNodesWarning,
  Comfy_Workflow_SortNodeIdOnSave,
  Comfy_Workflow_WarnBlueprintOverwrite,
  Comfy_Workflow_WorkflowTabsPosition,
  LiteGraph_Canvas_MaximumFps,
  LiteGraph_Canvas_MinFontSizeForLOD,
  LiteGraph_ContextMenu_Scaling,
  LiteGraph_Node_DefaultPadding,
  LiteGraph_Node_TooltipDelay,
  LiteGraph_Reroute_SplineOffset,
  settings as default,
  pysssss_SnapToGrid
};
//# sourceMappingURL=settings-BIdKi-OT.js.map
