const settings = {};
export {
  settings as default
};
//# sourceMappingURL=settings-BhbWhsRg.js.map
