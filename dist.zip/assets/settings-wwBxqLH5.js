const Comfy_Canvas_BackgroundImage = { "name": "畫布背景圖片", "tooltip": "畫布背景的圖片網址。你可以在輸出面板中右鍵點擊圖片並選擇「設為背景」來使用，或是使用上傳按鈕上傳你自己的圖片。" };
const Comfy_Canvas_LeftMouseClickBehavior = { "name": "左鍵點擊行為", "options": { "Panning": "平移", "Select": "選取" } };
const Comfy_Canvas_MouseWheelScroll = { "name": "滑鼠滾輪捲動", "options": { "Panning": "平移", "Zoom in/out": "縮放" } };
const Comfy_Canvas_NavigationMode = { "name": "畫布導航模式", "options": { "Custom": "自訂", "Drag Navigation": "拖曳導覽", "Standard (New)": "標準（新）" } };
const Comfy_Canvas_SelectionToolbox = { "name": "顯示選取工具箱" };
const Comfy_ConfirmClear = { "name": "清除工作流程時需要確認" };
const Comfy_DOMClippingEnabled = { "name": "啟用 DOM 元素裁剪（啟用後可能會降低效能）" };
const Comfy_DevMode = { "name": "啟用開發者模式選項（API 儲存等）" };
const Comfy_DisableFloatRounding = { "name": "停用預設浮點數元件四捨五入。", "tooltip": "（需重新載入頁面）當後端節點已設定四捨五入時，無法停用四捨五入。" };
const Comfy_DisableSliders = { "name": "停用節點元件滑桿" };
const Comfy_EditAttention_Delta = { "name": "Ctrl+上/下 精確調整" };
const Comfy_EnableTooltips = { "name": "啟用工具提示" };
const Comfy_EnableWorkflowViewRestore = { "name": "在工作流程中儲存並還原畫布位置與縮放等級" };
const Comfy_FloatRoundingPrecision = { "name": "浮點元件小數點位數 [0 = 自動]。", "tooltip": "（需重新載入頁面）" };
const Comfy_Graph_CanvasInfo = { "name": "在左下角顯示畫布資訊（fps 等）" };
const Comfy_Graph_CanvasMenu = { "name": "顯示圖形畫布選單" };
const Comfy_Graph_CtrlShiftZoom = { "name": "啟用快速縮放快捷鍵（Ctrl + Shift + 拖曳）" };
const Comfy_Graph_LinkMarkers = { "name": "連結中點標記", "options": { "Arrow": "箭頭", "Circle": "圓圈", "None": "無" } };
const Comfy_Graph_ZoomSpeed = { "name": "畫布縮放速度" };
const Comfy_GroupSelectedNodes_Padding = { "name": "群組所選節點間距" };
const Comfy_Group_DoubleClickTitleToEdit = { "name": "雙擊群組標題以編輯" };
const Comfy_LinkRelease_Action = { "name": "釋放連結時的動作（無修飾鍵）", "options": { "context menu": "右鍵選單", "no action": "無動作", "search box": "搜尋框" } };
const Comfy_LinkRelease_ActionShift = { "name": "連結釋放時的動作（Shift）", "options": { "context menu": "右鍵選單", "no action": "無動作", "search box": "搜尋框" } };
const Comfy_LinkRenderMode = { "name": "連結渲染模式", "options": { "Hidden": "隱藏", "Linear": "線性", "Spline": "曲線", "Straight": "直線" } };
const Comfy_Load3D_3DViewerEnable = { "name": "啟用 3D 檢視器（測試版）", "tooltip": "為所選節點啟用 3D 檢視器（測試版）。此功能可讓您在全尺寸 3D 檢視器中直接瀏覽與互動 3D 模型。" };
const Comfy_Load3D_BackgroundColor = { "name": "初始背景顏色", "tooltip": "控制 3D 場景的預設背景顏色。此設定決定新建立 3D 元件時的背景外觀，但每個元件在建立後都可單獨調整。" };
const Comfy_Load3D_CameraType = { "name": "初始相機類型", "options": { "orthographic": "正交", "perspective": "透視" }, "tooltip": "控制新建 3D 元件時，相機預設為透視或正交。此預設值在建立後仍可針對每個元件單獨切換。" };
const Comfy_Load3D_LightAdjustmentIncrement = { "name": "燈光調整增量", "tooltip": "控制在 3D 場景中調整燈光強度時的增量大小。較小的步進值可讓您更細緻地調整燈光，較大的值則每次調整會有更明顯的變化。" };
const Comfy_Load3D_LightIntensity = { "name": "初始光源強度", "tooltip": "設定 3D 場景中燈光的預設亮度等級。此數值決定新建立 3D 元件時燈光照亮物體的強度，但每個元件在建立後都可以個別調整。" };
const Comfy_Load3D_LightIntensityMaximum = { "name": "最大光照強度", "tooltip": "設定 3D 場景中允許的最大光照強度值。這會定義在調整任何 3D 小工具照明時可設定的最高亮度上限。" };
const Comfy_Load3D_LightIntensityMinimum = { "name": "光源強度下限", "tooltip": "設定 3D 場景中允許的最小光源強度值。這會定義在調整任何 3D 控制元件照明時可設定的最低亮度限制。" };
const Comfy_Load3D_ShowGrid = { "name": "初始網格可見性", "tooltip": "控制在建立新的 3D 元件時，網格是否預設可見。此預設值在建立後仍可針對每個元件單獨切換。" };
const Comfy_Locale = { "name": "語言" };
const Comfy_MaskEditor_BrushAdjustmentSpeed = { "name": "筆刷調整速度倍數", "tooltip": "控制調整筆刷大小與硬度時的變化速度。數值越高，變化越快。" };
const Comfy_MaskEditor_UseDominantAxis = { "name": "鎖定筆刷調整至主軸", "tooltip": "啟用後，筆刷調整只會根據你移動較多的方向，分別影響大小或硬度" };
const Comfy_ModelLibrary_AutoLoadAll = { "name": "自動載入所有模型資料夾", "tooltip": "若為開啟，當你打開模型庫時，所有資料夾將自動載入（這可能會導致載入時延遲）。若為關閉，只有在你點擊根目錄下的模型資料夾時才會載入。" };
const Comfy_ModelLibrary_NameFormat = { "name": "在模型庫樹狀檢視中顯示的名稱", "options": { "filename": "filename", "title": "title" }, "tooltip": "選擇「filename」可在模型清單中顯示簡化的原始檔名（不含目錄或「.safetensors」副檔名）。選擇「title」則顯示可設定的模型中繼資料標題。" };
const Comfy_NodeBadge_NodeIdBadgeMode = { "name": "節點 ID 標籤模式", "options": { "None": "無", "Show all": "全部顯示" } };
const Comfy_NodeBadge_NodeLifeCycleBadgeMode = { "name": "節點生命週期徽章模式", "options": { "None": "無", "Show all": "顯示全部" } };
const Comfy_NodeBadge_NodeSourceBadgeMode = { "name": "節點來源徽章模式", "options": { "Hide built-in": "隱藏內建", "None": "無", "Show all": "全部顯示" } };
const Comfy_NodeBadge_ShowApiPricing = { "name": "顯示 API 節點價格標籤" };
const Comfy_NodeSearchBoxImpl = { "name": "節點搜尋框實作", "options": { "default": "預設", "litegraph (legacy)": "litegraph（舊版）" } };
const Comfy_NodeSearchBoxImpl_NodePreview = { "name": "節點預覽", "tooltip": "僅適用於預設實作" };
const Comfy_NodeSearchBoxImpl_ShowCategory = { "name": "在搜尋結果中顯示節點分類", "tooltip": "僅適用於預設實作" };
const Comfy_NodeSearchBoxImpl_ShowIdName = { "name": "在搜尋結果中顯示節點 ID 名稱", "tooltip": "僅適用於預設實作" };
const Comfy_NodeSearchBoxImpl_ShowNodeFrequency = { "name": "在搜尋結果中顯示節點頻率", "tooltip": "僅適用於預設實作" };
const Comfy_NodeSuggestions_number = { "name": "節點建議數量", "tooltip": "僅適用於 litegraph 搜尋框／右鍵選單" };
const Comfy_Node_AllowImageSizeDraw = { "name": "在圖片預覽下方顯示寬度 × 高度" };
const Comfy_Node_AutoSnapLinkToSlot = { "name": "自動吸附連結到節點插槽", "tooltip": "拖曳連結到節點時，連結會自動吸附到節點上可用的輸入插槽" };
const Comfy_Node_BypassAllLinksOnDelete = { "name": "刪除節點時保留所有連結", "tooltip": "刪除節點時，嘗試自動重新連接其所有輸入與輸出連結（繞過被刪除的節點）" };
const Comfy_Node_DoubleClickTitleToEdit = { "name": "雙擊節點標題以編輯" };
const Comfy_Node_MiddleClickRerouteNode = { "name": "中鍵點擊建立新的重導節點" };
const Comfy_Node_Opacity = { "name": "節點不透明度" };
const Comfy_Node_ShowDeprecated = { "name": "在搜尋中顯示已棄用節點", "tooltip": "已棄用的節點在介面中預設隱藏，但在現有使用這些節點的工作流程中仍可運作。" };
const Comfy_Node_ShowExperimental = { "name": "在搜尋中顯示實驗性節點", "tooltip": "實驗性節點會在介面中標註，未來版本可能會有重大變動或被移除。請在正式工作流程中謹慎使用" };
const Comfy_Node_SnapHighlightsNode = { "name": "節點高亮顯示對齊", "tooltip": "當拖曳連結到具有可用輸入插槽的節點時，高亮顯示該節點" };
const Comfy_Notification_ShowVersionUpdates = { "name": "顯示版本更新", "tooltip": "顯示新模型和主要新功能的更新。" };
const Comfy_Pointer_ClickBufferTime = { "name": "指標點擊漂移延遲", "tooltip": "按下指標按鈕後，這是可忽略指標移動的最長時間（以毫秒為單位）。\n\n可防止在點擊時移動指標導致物件被意外推動。" };
const Comfy_Pointer_ClickDrift = { "name": "指標點擊漂移（最大距離）", "tooltip": "如果在按住按鈕時指標移動超過此距離，則視為拖曳（而非點擊）。\n\n可防止在點擊時不小心移動指標導致物件被意外推動。" };
const Comfy_Pointer_DoubleClickTime = { "name": "雙擊間隔（最大值）", "tooltip": "兩次點擊被視為雙擊的最長間隔時間（毫秒）。增加此數值可協助在雙擊有時未被辨識時改善操作體驗。" };
const Comfy_PreviewFormat = { "name": "預覽圖片格式", "tooltip": "在圖片元件中顯示預覽時，將其轉換為輕量級圖片格式，例如 webp、jpeg、webp;50 等。" };
const Comfy_PromptFilename = { "name": "儲存工作流程時提示輸入檔案名稱" };
const Comfy_QueueButton_BatchCountLimit = { "name": "批次數量上限", "tooltip": "每次按鈕點擊可加入佇列的最大任務數" };
const Comfy_Queue_MaxHistoryItems = { "name": "佇列歷史記錄大小", "tooltip": "佇列歷史中顯示的最大任務數量。" };
const Comfy_Sidebar_Location = { "name": "側邊欄位置", "options": { "left": "左側", "right": "右側" } };
const Comfy_Sidebar_Size = { "name": "側邊欄大小", "options": { "normal": "一般", "small": "小" } };
const Comfy_Sidebar_Style = { "name": "側邊欄樣式", "options": { "connected": "連接式", "floating": "浮動式" } };
const Comfy_Sidebar_UnifiedWidth = { "name": "統一側邊欄寬度" };
const Comfy_SnapToGrid_GridSize = { "name": "對齊至格線大小", "tooltip": "當按住 Shift 拖曳或調整節點大小時，節點會對齊到格線，此設定可調整格線的大小。" };
const Comfy_TextareaWidget_FontSize = { "name": "文字區塊元件字型大小" };
const Comfy_TextareaWidget_Spellcheck = { "name": "文字方塊小工具拼字檢查" };
const Comfy_TreeExplorer_ItemPadding = { "name": "樹狀瀏覽器項目間距" };
const Comfy_UseNewMenu = { "name": "使用新選單", "options": { "Disabled": "停用", "Top": "上方" }, "tooltip": "選單列位置。在行動裝置上，選單永遠顯示在頂部。" };
const Comfy_Validation_Workflows = { "name": "驗證工作流程" };
const Comfy_VueNodes_AutoScaleLayout = { "name": "自動縮放佈局 (Vue 節點)", "tooltip": "切換至 Vue 渲染時自動縮放節點位置以防止重疊" };
const Comfy_VueNodes_Enabled = { "name": "現代節點設計 (Vue 節點)", "tooltip": "現代：基於 DOM 的渲染，具備增強的互動性、原生瀏覽器功能和更新的視覺設計。經典：傳統畫布渲染。" };
const Comfy_WidgetControlMode = { "name": "元件控制模式", "options": { "after": "佇列後", "before": "佇列前" }, "tooltip": "控制元件數值何時更新（隨機、遞增、遞減），可選在提示加入佇列前或後進行。" };
const Comfy_Window_UnloadConfirmation = { "name": "關閉視窗時顯示確認提示" };
const Comfy_Workflow_AutoSave = { "name": "自動儲存", "options": { "after delay": "延遲後", "off": "關閉" } };
const Comfy_Workflow_AutoSaveDelay = { "name": "自動儲存延遲（毫秒）", "tooltip": "僅在自動儲存設為「延遲後」時適用。" };
const Comfy_Workflow_ConfirmDelete = { "name": "刪除工作流程時顯示確認視窗" };
const Comfy_Workflow_Persist = { "name": "保留工作流程狀態並於頁面重新載入時還原" };
const Comfy_Workflow_ShowMissingModelsWarning = { "name": "顯示缺少模型警告" };
const Comfy_Workflow_ShowMissingNodesWarning = { "name": "顯示缺少節點警告" };
const Comfy_Workflow_SortNodeIdOnSave = { "name": "儲存工作流程時排序節點 ID" };
const Comfy_Workflow_WarnBlueprintOverwrite = { "name": "覆蓋現有子圖藍圖前需要確認" };
const Comfy_Workflow_WorkflowTabsPosition = { "name": "已開啟工作流程的位置", "options": { "Sidebar": "側邊欄", "Topbar": "頂部欄" } };
const LiteGraph_Canvas_MaximumFps = { "name": "最大FPS", "tooltip": "畫布允許渲染的最大每秒幀數。限制GPU使用率，但可能影響流暢度。若設為0，則使用螢幕的更新率。預設值：0" };
const LiteGraph_Canvas_MinFontSizeForLOD = { "name": "縮放節點細節層級 - 字型大小閾值", "tooltip": "控制節點何時切換至低品質 LOD 渲染。使用像素字型大小來決定何時切換。設為 0 可停用。數值 1-24 設定 LOD 的最小字型大小閾值 - 較高的數值（24px）= 縮小時更早切換節點為簡化渲染，較低的數值（1px）= 較長時間維持完整節點品質。" };
const LiteGraph_ContextMenu_Scaling = { "name": "放大時縮放節點組合小工具選單（清單）" };
const LiteGraph_Node_DefaultPadding = { "name": "新增節點時自動縮小", "tooltip": "建立節點時自動調整為最小尺寸。若停用，新增的節點會略為加寬以顯示元件數值。" };
const LiteGraph_Node_TooltipDelay = { "name": "提示延遲" };
const LiteGraph_Reroute_SplineOffset = { "name": "重導樣條偏移", "tooltip": "貝茲控制點相對於重導中心點的偏移量" };
const pysssss_SnapToGrid = { "name": "總是對齊格線" };
const settings = {
  "Comfy-Desktop_AutoUpdate": { "name": "自動檢查更新" },
  "Comfy-Desktop_SendStatistics": { "name": "傳送匿名使用統計資料" },
  "Comfy-Desktop_UV_PypiInstallMirror": { "name": "PyPI 安裝鏡像站", "tooltip": "預設 pip 安裝鏡像站" },
  "Comfy-Desktop_UV_PythonInstallMirror": { "name": "Python 安裝鏡像站", "tooltip": "受管理的 Python 安裝檔會從 Astral 的 python-build-standalone 專案下載。這個變數可以設定為鏡像站的 URL，以便從不同來源下載 Python 安裝檔。所提供的 URL 會取代 https://github.com/astral-sh/python-build-standalone/releases/download，例如：https://github.com/astral-sh/python-build-standalone/releases/download/20240713/cpython-3.12.4%2B20240713-aarch64-apple-darwin-install_only.tar.gz。若要從本機目錄讀取發行版本，請使用 file:// URL 格式。" },
  "Comfy-Desktop_UV_TorchInstallMirror": { "name": "Torch 安裝鏡像站", "tooltip": "PyTorch 的 pip 安裝鏡像站" },
  "Comfy-Desktop_WindowStyle": { "name": "視窗樣式", "options": { "custom": "自訂", "default": "預設" }, "tooltip": "自訂：以 ComfyUI 的頂部選單取代系統標題列" },
  Comfy_Canvas_BackgroundImage,
  Comfy_Canvas_LeftMouseClickBehavior,
  Comfy_Canvas_MouseWheelScroll,
  Comfy_Canvas_NavigationMode,
  Comfy_Canvas_SelectionToolbox,
  Comfy_ConfirmClear,
  Comfy_DOMClippingEnabled,
  Comfy_DevMode,
  Comfy_DisableFloatRounding,
  Comfy_DisableSliders,
  Comfy_EditAttention_Delta,
  Comfy_EnableTooltips,
  Comfy_EnableWorkflowViewRestore,
  Comfy_FloatRoundingPrecision,
  Comfy_Graph_CanvasInfo,
  Comfy_Graph_CanvasMenu,
  Comfy_Graph_CtrlShiftZoom,
  Comfy_Graph_LinkMarkers,
  Comfy_Graph_ZoomSpeed,
  Comfy_GroupSelectedNodes_Padding,
  Comfy_Group_DoubleClickTitleToEdit,
  Comfy_LinkRelease_Action,
  Comfy_LinkRelease_ActionShift,
  Comfy_LinkRenderMode,
  Comfy_Load3D_3DViewerEnable,
  Comfy_Load3D_BackgroundColor,
  Comfy_Load3D_CameraType,
  Comfy_Load3D_LightAdjustmentIncrement,
  Comfy_Load3D_LightIntensity,
  Comfy_Load3D_LightIntensityMaximum,
  Comfy_Load3D_LightIntensityMinimum,
  Comfy_Load3D_ShowGrid,
  Comfy_Locale,
  Comfy_MaskEditor_BrushAdjustmentSpeed,
  Comfy_MaskEditor_UseDominantAxis,
  Comfy_ModelLibrary_AutoLoadAll,
  Comfy_ModelLibrary_NameFormat,
  Comfy_NodeBadge_NodeIdBadgeMode,
  Comfy_NodeBadge_NodeLifeCycleBadgeMode,
  Comfy_NodeBadge_NodeSourceBadgeMode,
  Comfy_NodeBadge_ShowApiPricing,
  Comfy_NodeSearchBoxImpl,
  Comfy_NodeSearchBoxImpl_NodePreview,
  Comfy_NodeSearchBoxImpl_ShowCategory,
  Comfy_NodeSearchBoxImpl_ShowIdName,
  Comfy_NodeSearchBoxImpl_ShowNodeFrequency,
  Comfy_NodeSuggestions_number,
  Comfy_Node_AllowImageSizeDraw,
  Comfy_Node_AutoSnapLinkToSlot,
  Comfy_Node_BypassAllLinksOnDelete,
  Comfy_Node_DoubleClickTitleToEdit,
  Comfy_Node_MiddleClickRerouteNode,
  Comfy_Node_Opacity,
  Comfy_Node_ShowDeprecated,
  Comfy_Node_ShowExperimental,
  Comfy_Node_SnapHighlightsNode,
  Comfy_Notification_ShowVersionUpdates,
  Comfy_Pointer_ClickBufferTime,
  Comfy_Pointer_ClickDrift,
  Comfy_Pointer_DoubleClickTime,
  Comfy_PreviewFormat,
  Comfy_PromptFilename,
  Comfy_QueueButton_BatchCountLimit,
  Comfy_Queue_MaxHistoryItems,
  Comfy_Sidebar_Location,
  Comfy_Sidebar_Size,
  Comfy_Sidebar_Style,
  Comfy_Sidebar_UnifiedWidth,
  Comfy_SnapToGrid_GridSize,
  Comfy_TextareaWidget_FontSize,
  Comfy_TextareaWidget_Spellcheck,
  Comfy_TreeExplorer_ItemPadding,
  Comfy_UseNewMenu,
  Comfy_Validation_Workflows,
  Comfy_VueNodes_AutoScaleLayout,
  Comfy_VueNodes_Enabled,
  Comfy_WidgetControlMode,
  Comfy_Window_UnloadConfirmation,
  Comfy_Workflow_AutoSave,
  Comfy_Workflow_AutoSaveDelay,
  Comfy_Workflow_ConfirmDelete,
  Comfy_Workflow_Persist,
  Comfy_Workflow_ShowMissingModelsWarning,
  Comfy_Workflow_ShowMissingNodesWarning,
  Comfy_Workflow_SortNodeIdOnSave,
  Comfy_Workflow_WarnBlueprintOverwrite,
  Comfy_Workflow_WorkflowTabsPosition,
  LiteGraph_Canvas_MaximumFps,
  LiteGraph_Canvas_MinFontSizeForLOD,
  LiteGraph_ContextMenu_Scaling,
  LiteGraph_Node_DefaultPadding,
  LiteGraph_Node_TooltipDelay,
  LiteGraph_Reroute_SplineOffset,
  pysssss_SnapToGrid
};
export {
  Comfy_Canvas_BackgroundImage,
  Comfy_Canvas_LeftMouseClickBehavior,
  Comfy_Canvas_MouseWheelScroll,
  Comfy_Canvas_NavigationMode,
  Comfy_Canvas_SelectionToolbox,
  Comfy_ConfirmClear,
  Comfy_DOMClippingEnabled,
  Comfy_DevMode,
  Comfy_DisableFloatRounding,
  Comfy_DisableSliders,
  Comfy_EditAttention_Delta,
  Comfy_EnableTooltips,
  Comfy_EnableWorkflowViewRestore,
  Comfy_FloatRoundingPrecision,
  Comfy_Graph_CanvasInfo,
  Comfy_Graph_CanvasMenu,
  Comfy_Graph_CtrlShiftZoom,
  Comfy_Graph_LinkMarkers,
  Comfy_Graph_ZoomSpeed,
  Comfy_GroupSelectedNodes_Padding,
  Comfy_Group_DoubleClickTitleToEdit,
  Comfy_LinkRelease_Action,
  Comfy_LinkRelease_ActionShift,
  Comfy_LinkRenderMode,
  Comfy_Load3D_3DViewerEnable,
  Comfy_Load3D_BackgroundColor,
  Comfy_Load3D_CameraType,
  Comfy_Load3D_LightAdjustmentIncrement,
  Comfy_Load3D_LightIntensity,
  Comfy_Load3D_LightIntensityMaximum,
  Comfy_Load3D_LightIntensityMinimum,
  Comfy_Load3D_ShowGrid,
  Comfy_Locale,
  Comfy_MaskEditor_BrushAdjustmentSpeed,
  Comfy_MaskEditor_UseDominantAxis,
  Comfy_ModelLibrary_AutoLoadAll,
  Comfy_ModelLibrary_NameFormat,
  Comfy_NodeBadge_NodeIdBadgeMode,
  Comfy_NodeBadge_NodeLifeCycleBadgeMode,
  Comfy_NodeBadge_NodeSourceBadgeMode,
  Comfy_NodeBadge_ShowApiPricing,
  Comfy_NodeSearchBoxImpl,
  Comfy_NodeSearchBoxImpl_NodePreview,
  Comfy_NodeSearchBoxImpl_ShowCategory,
  Comfy_NodeSearchBoxImpl_ShowIdName,
  Comfy_NodeSearchBoxImpl_ShowNodeFrequency,
  Comfy_NodeSuggestions_number,
  Comfy_Node_AllowImageSizeDraw,
  Comfy_Node_AutoSnapLinkToSlot,
  Comfy_Node_BypassAllLinksOnDelete,
  Comfy_Node_DoubleClickTitleToEdit,
  Comfy_Node_MiddleClickRerouteNode,
  Comfy_Node_Opacity,
  Comfy_Node_ShowDeprecated,
  Comfy_Node_ShowExperimental,
  Comfy_Node_SnapHighlightsNode,
  Comfy_Notification_ShowVersionUpdates,
  Comfy_Pointer_ClickBufferTime,
  Comfy_Pointer_ClickDrift,
  Comfy_Pointer_DoubleClickTime,
  Comfy_PreviewFormat,
  Comfy_PromptFilename,
  Comfy_QueueButton_BatchCountLimit,
  Comfy_Queue_MaxHistoryItems,
  Comfy_Sidebar_Location,
  Comfy_Sidebar_Size,
  Comfy_Sidebar_Style,
  Comfy_Sidebar_UnifiedWidth,
  Comfy_SnapToGrid_GridSize,
  Comfy_TextareaWidget_FontSize,
  Comfy_TextareaWidget_Spellcheck,
  Comfy_TreeExplorer_ItemPadding,
  Comfy_UseNewMenu,
  Comfy_Validation_Workflows,
  Comfy_VueNodes_AutoScaleLayout,
  Comfy_VueNodes_Enabled,
  Comfy_WidgetControlMode,
  Comfy_Window_UnloadConfirmation,
  Comfy_Workflow_AutoSave,
  Comfy_Workflow_AutoSaveDelay,
  Comfy_Workflow_ConfirmDelete,
  Comfy_Workflow_Persist,
  Comfy_Workflow_ShowMissingModelsWarning,
  Comfy_Workflow_ShowMissingNodesWarning,
  Comfy_Workflow_SortNodeIdOnSave,
  Comfy_Workflow_WarnBlueprintOverwrite,
  Comfy_Workflow_WorkflowTabsPosition,
  LiteGraph_Canvas_MaximumFps,
  LiteGraph_Canvas_MinFontSizeForLOD,
  LiteGraph_ContextMenu_Scaling,
  LiteGraph_Node_DefaultPadding,
  LiteGraph_Node_TooltipDelay,
  LiteGraph_Reroute_SplineOffset,
  settings as default,
  pysssss_SnapToGrid
};
//# sourceMappingURL=settings-wwBxqLH5.js.map
