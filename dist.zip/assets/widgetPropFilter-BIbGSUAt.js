var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });
const STANDARD_EXCLUDED_PROPS = [
  "style",
  "class",
  "dt",
  "pt",
  "ptOptions",
  "unstyled"
];
const INPUT_EXCLUDED_PROPS = [
  ...STANDARD_EXCLUDED_PROPS,
  "inputClass",
  "inputStyle"
];
const PANEL_EXCLUDED_PROPS = [
  ...STANDARD_EXCLUDED_PROPS,
  "panelClass",
  "panelStyle",
  "overlayClass"
];
const GALLERIA_EXCLUDED_PROPS = [
  ...STANDARD_EXCLUDED_PROPS,
  "thumbnailsPosition",
  "verticalThumbnailViewPortHeight",
  "indicatorsPosition",
  "maskClass",
  "containerStyle",
  "containerClass",
  "galleriaClass"
];
const BADGE_EXCLUDED_PROPS = [
  ...STANDARD_EXCLUDED_PROPS,
  "badgeClass"
];
function filterWidgetProps(props, excludeList) {
  if (!props) return {};
  const filtered = {};
  for (const [key, value] of Object.entries(props)) {
    if (!excludeList.includes(key)) {
      filtered[key] = value;
    }
  }
  return filtered;
}
__name(filterWidgetProps, "filterWidgetProps");
export {
  BADGE_EXCLUDED_PROPS as B,
  GALLERIA_EXCLUDED_PROPS as G,
  INPUT_EXCLUDED_PROPS as I,
  PANEL_EXCLUDED_PROPS as P,
  STANDARD_EXCLUDED_PROPS as S,
  filterWidgetProps as f
};
//# sourceMappingURL=widgetPropFilter-BIbGSUAt.js.map
