// Shim for extensions/core/clipspace.ts
console.warn('[ComfyUI Notice] "extensions/core/clipspace.js" is an internal module, not part of the public API. Future updates may break this import.');
export const ClipspaceDialog = window.comfyAPI.clipspace.ClipspaceDialog;
