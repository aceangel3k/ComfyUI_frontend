// Shim for extensions/core/groupNodeManage.ts
console.warn('[ComfyUI Deprecated] Importing from "extensions/core/groupNodeManage.js" is deprecated and will be removed in v1.34.');
export const ManageGroupDialog = window.comfyAPI.groupNodeManage.ManageGroupDialog;
