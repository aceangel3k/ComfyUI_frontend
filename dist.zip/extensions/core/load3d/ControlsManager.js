// Shim for extensions/core/load3d/ControlsManager.ts
console.warn('[ComfyUI Notice] "extensions/core/load3d/ControlsManager.js" is an internal module, not part of the public API. Future updates may break this import.');
export const ControlsManager = window.comfyAPI.ControlsManager.ControlsManager;
