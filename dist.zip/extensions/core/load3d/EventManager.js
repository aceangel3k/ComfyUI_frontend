// Shim for extensions/core/load3d/EventManager.ts
console.warn('[ComfyUI Notice] "extensions/core/load3d/EventManager.js" is an internal module, not part of the public API. Future updates may break this import.');
export const EventManager = window.comfyAPI.EventManager.EventManager;
