// Shim for extensions/core/load3d/ModelExporter.ts
console.warn('[ComfyUI Notice] "extensions/core/load3d/ModelExporter.js" is an internal module, not part of the public API. Future updates may break this import.');
export const ModelExporter = window.comfyAPI.ModelExporter.ModelExporter;
