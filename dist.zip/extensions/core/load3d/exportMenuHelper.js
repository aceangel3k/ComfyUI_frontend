// Shim for extensions/core/load3d/exportMenuHelper.ts
console.warn('[ComfyUI Notice] "extensions/core/load3d/exportMenuHelper.js" is an internal module, not part of the public API. Future updates may break this import.');
export const createExportMenuItems = window.comfyAPI.exportMenuHelper.createExportMenuItems;
