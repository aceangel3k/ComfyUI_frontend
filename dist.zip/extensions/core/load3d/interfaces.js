// Shim for extensions/core/load3d/interfaces.ts
console.warn('[ComfyUI Notice] "extensions/core/load3d/interfaces.js" is an internal module, not part of the public API. Future updates may break this import.');
export const SUPPORTED_EXTENSIONS = window.comfyAPI.interfaces.SUPPORTED_EXTENSIONS;
