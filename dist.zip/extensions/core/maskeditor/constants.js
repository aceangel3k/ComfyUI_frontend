// Shim for extensions/core/maskeditor/constants.ts
console.warn('[ComfyUI Notice] "extensions/core/maskeditor/constants.js" is an internal module, not part of the public API. Future updates may break this import.');
export const iconsHtml = window.comfyAPI.constants.iconsHtml;
