// Shim for extensions/core/maskeditor/types.ts
console.warn('[ComfyUI Notice] "extensions/core/maskeditor/types.js" is an internal module, not part of the public API. Future updates may break this import.');
export const BrushShape = window.comfyAPI.types.BrushShape;
export const Tools = window.comfyAPI.types.Tools;
export const allTools = window.comfyAPI.types.allTools;
export const CompositionOperation = window.comfyAPI.types.CompositionOperation;
export const MaskBlendMode = window.comfyAPI.types.MaskBlendMode;
export const ColorComparisonMethod = window.comfyAPI.types.ColorComparisonMethod;
