// Shim for scripts/metadata/avif.ts
console.warn('[ComfyUI Notice] "scripts/metadata/avif.js" is an internal module, not part of the public API. Future updates may break this import.');
export const getFromAvifFile = window.comfyAPI.avif.getFromAvifFile;
