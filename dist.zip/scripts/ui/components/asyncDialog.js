// Shim for scripts/ui/components/asyncDialog.ts
console.warn('[ComfyUI Deprecated] Importing from "scripts/ui/components/asyncDialog.js" is deprecated and will be removed in v1.34.');
export const ComfyAsyncDialog = window.comfyAPI.asyncDialog.ComfyAsyncDialog;
