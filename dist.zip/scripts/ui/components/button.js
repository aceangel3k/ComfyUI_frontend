// Shim for scripts/ui/components/button.ts
console.warn('[ComfyUI Deprecated] Importing from "scripts/ui/components/button.js" is deprecated and will be removed in v1.34.');
export const ComfyButton = window.comfyAPI.button.ComfyButton;
