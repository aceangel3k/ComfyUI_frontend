// Shim for scripts/ui/components/popup.ts
console.warn('[ComfyUI Deprecated] Importing from "scripts/ui/components/popup.js" is deprecated and will be removed in v1.34.');
export const ComfyPopup = window.comfyAPI.popup.ComfyPopup;
