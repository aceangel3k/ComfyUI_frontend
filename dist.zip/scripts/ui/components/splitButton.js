// Shim for scripts/ui/components/splitButton.ts
console.warn('[ComfyUI Deprecated] Importing from "scripts/ui/components/splitButton.js" is deprecated and will be removed in v1.34.');
export const ComfySplitButton = window.comfyAPI.splitButton.ComfySplitButton;
