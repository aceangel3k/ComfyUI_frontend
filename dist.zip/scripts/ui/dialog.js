// Shim for scripts/ui/dialog.ts
console.warn('[ComfyUI Deprecated] Importing from "scripts/ui/dialog.js" is deprecated and will be removed in v1.34.');
export const ComfyDialog = window.comfyAPI.dialog.ComfyDialog;
