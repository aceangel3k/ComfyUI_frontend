// Shim for scripts/ui/menu/index.ts
console.warn('[ComfyUI Deprecated] Importing from "scripts/ui/menu/index.js" is deprecated and will be removed in v1.34.');
export const ComfyAppMenu = window.comfyAPI.index.ComfyAppMenu;
