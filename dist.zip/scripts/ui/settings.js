// Shim for scripts/ui/settings.ts
console.warn('[ComfyUI Deprecated] Importing from "scripts/ui/settings.js" is deprecated and will be removed in v1.34.');
export const ComfySettingsDialog = window.comfyAPI.settings.ComfySettingsDialog;
