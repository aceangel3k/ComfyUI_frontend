// Shim for scripts/ui/toggleSwitch.ts
console.warn('[ComfyUI Deprecated] Importing from "scripts/ui/toggleSwitch.js" is deprecated and will be removed in v1.34.');
export const toggleSwitch = window.comfyAPI.toggleSwitch.toggleSwitch;
