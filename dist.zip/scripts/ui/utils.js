// Shim for scripts/ui/utils.ts
console.warn('[ComfyUI Deprecated] Importing from "scripts/ui/utils.js" is deprecated and will be removed in v1.34.');
export const applyClasses = window.comfyAPI.utils.applyClasses;
export const toggleElement = window.comfyAPI.utils.toggleElement;
